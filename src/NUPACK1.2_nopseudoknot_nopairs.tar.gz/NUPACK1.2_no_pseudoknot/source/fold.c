/*  fold.c by Robert Dirks 07/30/2001

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     


The purpose of this program is to calculate the energy of the most stable fold
over all secondary structures of a given strand of DNA/RNA, allowing for 
the simplest kinds of pseudoknots.  The energy algorithm will 
follow the general format of Zuker and later Hofacker.  
The inclusion of pseudoknots and their corresponding energies relies heavily
on the ideas presented by (Rivas and Eddy 1999, J Mol Bio, 285, 2053-68) 
although their notion of Gap matrices are not used.  
The reason for this is that
gap matrices allow a given secondary structure to be obtained in multiple 
ways via recursions, which leads to multiple possible energies per fold.  
The method used in this program will not allow for as general structures 
as Rivas and Eddy, but will have unique representations of each structure.  
This is accomplished by explicitly creating pseudoknots in the recursions.

Input:  Input will be a DNA/RNA sequence with or without spaces and on multiple
lines if necessary.  Lines beginning with > will be treated as a comment
The sequence can consist only of A,C,T (U),G (case insensitive).

Output:  The output will be the energy and structure (bracket notation)
of the mfe. 

Additional outputs include the files:
out.ene - input file for Energy.out
out.pair - explicit pairs in mfe structure

Running: To run, type Fold.out filename
Where filename is the name of the input file containing the sequence

*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#ifndef CONSTANTS_H
#include"constants.h"
#endif

#ifndef FUNCTIONS_H
#include"functions.h"
#endif

/* Declare Global Variables.  This will only include data to be read in from
   a file and used multiple times by energy evaluations */

#include "DNAGlobals.h"


char pairsFileName[] = "out.ene";
int containsPk;
/* End Global Variables */


/* ************************************************ */

int main( int argc, char *argv[] ) {

  char *seq;
  int seqlength = 0; 
  char *thefold; // string of type "...(...).." with () a pair
  int *thepairs; // thepairs[i] = j indicates base i is paired with j

  double *F, *Fb, *Fm;

#ifdef O_N3
  double *Fx, *Fx_1, *Fx_2;
  double *Fs, *Fms;
#endif //O_N3

  double *Fp, *Fz;  //O(N^2)
  double *Fg; //O(N^4)

#ifdef O_N5 
  double *FgIx, *FgIx_1, *FgIx_2;
  double *Fgls, *Fgrs;
  double *Fgl, *Fgr; //O(N^4) space
#endif //)_N5

  /*  F-type matrices are dynamically allocated matrices that
      contain minimum energies restricted to a subsequence of the
      strand.  Each of the above should be accessed by the call
      F[ pf_index(i, j, seqlength)] to indicate the partition function between
      i and j, inclusive. 
      
      Decscriptions of each are in the referenced paper (see pfunc.c)
  */

  int i, j; // the beginning and end bases for F
  long int maxIndex;
  int L; //This the length of the current subsequence
  double min_energy;
  int pf_ij;
  double tempMin;
 
  extern long int maxGapIndex;
#ifdef O_N5
  short *possiblePairs;
#endif

  extern char pairsFileName[];
  FILE *pairfile;

  header();
#ifndef PRINTRESULTSONLY
  printf("Fold.out Version 1.2: Complexity ");
#ifdef O_N3
  printf("O(N^3)\n");
#endif
#ifdef O_N4
  printf("O(N^4)\n");
#endif
#ifdef O_N5
  printf("O(N^5) (pseudoknots enabled)\n");
#endif
#ifdef O_N8
  printf("O(N^8) (pseudoknots enabled)\n");
#endif
#endif

  ReadSequence( &seqlength, &seq, argv[1]); 
  maxGapIndex = seqlength*(seqlength-1)*(seqlength-2)*(seqlength-3)/24;

  printf("Sequence Read.\n");
  //GetEnergyParameters();
#ifdef RNA
  LoadEnergyFromStandardFile( "dataS_G.rna");
#else
  LoadEnergyFromStandardFile( "dataS_G.dna");
#endif


#ifdef O_N5
  PrecomputeValues_fold( seqlength);
#endif

  printf("Energy Parameters Loaded\n");

  // Allocate and Initialize Matrices
  InitDoublesMatrix( &F, seqlength*(seqlength+1)/2 + (seqlength+1), "F");
  InitDoublesMatrix( &Fb, seqlength*(seqlength+1)/2+(seqlength+1), "Fb");
  InitDoublesMatrix( &Fm, seqlength*(seqlength+1)/2+(seqlength+1), "Fm");

#ifdef O_N3
  InitDoublesMatrix( &Fs, seqlength*(seqlength+1)/2+(seqlength+1), "Fs");
  InitDoublesMatrix( &Fms, seqlength*(seqlength+1)/2+(seqlength+1), "Fms");
#endif //O_N3
  
#ifdef PKNOTS
  InitDoublesMatrix( &Fp, seqlength*(seqlength+1)/2+(seqlength+1), "Fp");
  InitDoublesMatrix( &Fz, seqlength*(seqlength+1)/2+(seqlength+1), "Fz");
  InitDoublesMatrix( &Fg, seqlength*(seqlength-1)*(seqlength-2)*
			     (seqlength-3)/24, "Fg");
#ifdef O_N5
  InitDoublesMatrix( &Fgl, seqlength*(seqlength-1)*(seqlength-2)*
			     (seqlength-3)/24, "Fgl");
  InitDoublesMatrix( &Fgr, seqlength*(seqlength-1)*(seqlength-2)*
			     (seqlength-3)/24, "Fgr");
  InitDoublesMatrix( &Fgls, seqlength*(seqlength-1)*(seqlength-2)*
		     (seqlength-3)/24, "Fgls");
  InitDoublesMatrix( &Fgrs, seqlength*(seqlength-1)*(seqlength-2)*
		     (seqlength-3)/24, "Fgrs");
  CheckPossiblePairs( &possiblePairs, seqlength, seq);
#endif //O_N5
#endif //PKNOTS

  //Initialization to NAD_INFINITY
#ifndef PKNOTS
  maxIndex = seqlength*(seqlength+1)/2 + seqlength + 1;
#else
  maxIndex = seqlength*(seqlength-1)*(seqlength-2)*(seqlength-3)/24;
  //watch out for overflow!
#endif

  for( i = 0; i < maxIndex; i++) {    

    if(  i < seqlength*(seqlength+1)/2 + (seqlength+1) ) {
      
      F[i] = Fb[i] = Fm[i] = NAD_INFINITY; 
   
#ifdef O_N3
      Fs[i] = Fms[i] = NAD_INFINITY;
#endif
      
#ifdef PKNOTS
      Fp[i] = Fz[i] = NAD_INFINITY; 
#endif
    } 
#ifdef PKNOTS    
    Fg[i] = NAD_INFINITY;
#ifdef O_N5 
    Fgl[i] = Fgr[i] = NAD_INFINITY;
    Fgls[i] = Fgrs[i] = NAD_INFINITY;
#endif //)_N5
#endif //PKNOTS
  }
  for( i = 0; i <= seqlength; i++) {
    F[ pf_index(i, i-1, seqlength)] = DangleEnergy(i, i-1,seq, seqlength);
  }
#ifdef PKNOTS
  for( i = 0; i <= seqlength; i++) {
    Fz[ pf_index(i,i-1,seqlength)] = DangleEnergy(i, i-1,seq,seqlength);
  }
#endif

  InitFold( seqlength, &thefold, &thepairs);
  
  printf( "SeqLength = %d\n", seqlength);
  printf( "Sequence and a Minimum Energy Structure:\n");
  for( i = 0; i < seqlength; i++) {
    printf("%c", seq[i]);
  }
  printf("\n");

  for( L = 1; L <= seqlength; L++) {
    /* Calculate all sub energies for
       length = 0, then 1, then 2.... */

#ifdef O_N3
    manageFx( &Fx, &Fx_1, &Fx_2, L-1, seqlength);   
    //allocate/deallocate memory
#endif //O_N3

#ifdef O_N5
    manageFgIx( &FgIx, &FgIx_1, &FgIx_2, L-1, seqlength);
    //manageQgIx manages the temporary matrices needed for 
    //calculating Qg_closed in time n^5
#endif //O_N5


    for( i = 0; i <= seqlength - L; i++) {
      j = i + L - 1;
      pf_ij = pf_index( i, j, seqlength);
      //printf("%d, %d\n", i, j);

      /* Recursions for Fb */
      /* bp = base pairs, pk = pseudoknots */

      min_energy = NAD_INFINITY;
      if( CanPair( seq[ i], seq[ j]) == FALSE || j - i < 4) {
	Fb[ pf_ij] = NAD_INFINITY;
      }
      else {
	min_energy = HairpinEnergy( i, j, seq);
	// Exactly 1 bp
	
#if defined (O_N4) || defined (PKNOTS)
	tempMin = MinFb( i, j, seq, seqlength, Fm, Fb);
	min_energy = MIN( tempMin, min_energy);
	// Exactly 2 bp

#endif

#ifdef O_N3
	//Multiloop Case
	tempMin = MinMultiBp_N3(i, j, seq, Fms, Fm,
				seqlength); 	 	  
	min_energy = MIN( tempMin, min_energy);
#endif //O_N3

#ifdef PKNOTS	     
	tempMin = MinFb_Pk( i, j, seq, seqlength, Fp, Fm);
	min_energy = MIN( tempMin, min_energy);
#endif //PKNOTS
	
      }
#ifdef O_N3
      fastILoops_Fb( i, j, L, seqlength, seq, min_energy, Fb, Fx, Fx_2);      
#endif      
      Fb[pf_ij] = MIN( Fb[ pf_ij], min_energy);    

      // Recursions for Fg, Fgls, Fgrs, Fgl, Fgr
#ifdef O_N8
      MakeFg_N8( i, j, seq, seqlength, Fg, Fm);
#endif
      
#ifdef O_N5
      MakeFg_N5(i, j, seq, seqlength, Fg, Fm, Fgls, Fgrs, FgIx, FgIx_2,
		possiblePairs);
      
      MakeFgls( i, j, seq, seqlength, Fg, Fm, Fgls);
      MakeFgrs( i, j, seq, seqlength, Fg, Fm, Fgrs);
      MakeFgl(i, j, seq, seqlength, Fg, Fgl, Fz);
      MakeFgr(i, j, seq, seqlength, Fgr, Fgl, Fz);
     
#endif //O_N5


      /* Recursions for Fp */
#ifdef O_N8

      Fp[ pf_ij] = 
	MinFp_N8( i, j, seq, seqlength, Fg, Fz);
#endif //O_N8

#ifdef O_N5
      Fp[ pf_ij] = 
	MinFp_N5( i, j, seq, seqlength, Fgl, Fgr);
#endif //O_N5

#ifdef O_N3
      /* Recursions for Fms, Fs */
      MakeFs_Fms( i, j, seq, seqlength, Fs, Fms, Fb);
#endif //O_N3
      
#ifdef O_N3            
      MakeF_Fm_N3( i, j, seq, seqlength, F, Fs, Fms, Fm);
#endif //O_N3
      
#ifdef O_N4
      MakeF_Fm_N4( i, j, seq, seqlength, F, Fm, Fb);
#endif //O_N4

#ifdef PKNOTS      
      MakeF_Fm_Fz(i, j, seq, seqlength, F, Fm, Fz, Fb, Fp);
#endif //PKNOTS


    }
  } 

#ifdef SHOWFB  
  for( i = 0; i < seqlength; i++) {
    for( j = i; j < seqlength; j++) {
      printf("%d, %d: qb = %12.3f\n", 
	     i, j, Fb[pf_index(i, j, seqlength)]); 
    }
  }
#endif

#ifdef NOBACKTRACK  
  printf( "F[ 1..N] = %0.2f kcal/mol\n", 
	  F[ pf_index( 0, seqlength - 1, seqlength) ]);
  //printf( "Starting Backtrack\n");
#endif
#ifdef DEBUG
  printf( "F[ 1..N] = %0.2f kcal/mol\n", 
	  F[ pf_index( 0, seqlength - 1, seqlength) ]);
#endif


#ifndef NOBACKTRACK
  pairfile = fopen( pairsFileName, "w");
  for( i = 0; i < seqlength; i++) {
    fprintf( pairfile, "%c", seq[i]);
  }
  fprintf( pairfile, "\n.\n");
  fclose( pairfile);
  Backtrack( seqlength, thefold, thepairs, F, Fb, Fm, Fp, 
	     Fg, Fz, 
	     F[ pf_index( 0, seqlength - 1, seqlength)], seq);
  // backtrack finds a structure with min_energy
  if( containsPk == TRUE) {
    printf("pseudoknotted!\n");
  }
#endif

  return 1;
}






