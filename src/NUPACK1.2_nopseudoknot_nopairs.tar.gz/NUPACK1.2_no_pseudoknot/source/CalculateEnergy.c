/* CalculateEnergy.c  12/12/2001 by Robert Dirks

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     

This program is designed to take a given DNA sequence and a given graph of
the secondary structure and return the energy.

Energy calculations (except for pseudoknots) 
based on Michael Zuker's mfold program
Ref:  
Zuker, M., Stiegler, P.  Nucleic Acids Research, volume 9(1) 1981, 133-147

Input: file containing sequence and graph description.  See README

Any line starting with '>' will be ignored.
 
Each entry must be on a separate line.  The last line of the file must be
a period in the first space.  The rest of the line ignored. */ 

#ifndef CONSTANTS_H
#include "constants.h" //contains all constants
#endif /* Make sure this file isn't included multiple times */

#ifndef FUNCTIONS_H
#include "functions.h" //contains functions and structures
#endif // Make sure this file isn't included multiple times

#include<stdio.h>
#include<string.h>
#include<time.h>
#include<ctype.h>
#include<math.h>
#include<stdlib.h>
/* Declare Global Variables */

#include "DNAGlobals.h"

/* End Global Variables */

//***********************************************************

int main( int argc, char *argv[] ) {
  
  fold thefold;
  double energy;
  
  header();
  printf("Energy.out Version 1.1:\n");
  printf("Reading input file\n");
  
  // Get Energy parameters
#ifdef RNA
  LoadEnergyFromStandardFile( "dataS_G.rna");
#else
  LoadEnergyFromStandardFile( "dataS_G.dna");
#endif


  Getfold( &thefold, argv[1]); // get input file
  energy = GetEnergy( &thefold); //Calculates Energy  

  printf("Total Energy = %6.2f kcal/mol\n", energy);

  return 1;
}

/* ***************************************************** */

void Getfold( fold *thefold, char filename[]) {
  FILE *fp;
  char line[MAXLINE];
  int i; //position in line
  int linenumber; //line number
  int mode;  // mode = 0 means sequence being read, mode = 1 means graph
  int init; // loop index for initializations
  int done; // has all the necessary info been read?
  int line_done; //has a given line been completely read?
  
  int paira, pairb, helixlength; // graph property variables
  int pk1, pk2;
  
  char *tmp_fix;// fixed bases
  int indx; // index for some loops
  char tempSeq[ MAXSEQLENGTH];
  int pairsFromParens[ MAXSEQLENGTH];
  int foldInitialized = FALSE;

  pairsFromParens[0] = -5;
				  
  fp = fopen(filename, "r");
  if( fp == NULL) {  /* Make sure input file exits */
    printf("Error opening file %s!\n", filename);
    exit(0);  
  }
  
  thefold->seqlength = 0;

  linenumber = 0;
  mode = 0; //read in sequence
  done = FALSE;
  while( fgets(line, MAXLINE, fp)!= NULL && done == FALSE) {  // Read lines
    linenumber++;
    line_done = FALSE;
    i = 0;
    while( line[i] != '\0' && line[0] != '>' && line[i] != '\n'
	   && line_done == FALSE) {
      if( mode == 0) {  //read sequence
	line[i] = toupper( line[i] );
	if( line[i] == 'U') {
	  line[i] = 'T';
	}

	if( i == 0 && 
	    (line[0] == '.' || line[0] == '(' || line[0] == ')') &&
	    (line[1] == '.' || line[1] == '(' || line[1] == ')') ) {
	  getStructureFromParens( tempSeq, 
				  line, pairsFromParens,  
				  thefold->seqlength);
	  mode = 1;
	}
	else if( line[i] == '.') {
	  mode = 1; // go to next line and start reading
	  line_done = TRUE; //needed to exit loop
	}
	else if( line[i] != 'A' && line[i] != 'T' && line[i] != 'C'
	    && line[i] != 'G' && line[i] != ' ') {
	  printf("Invalid base at line %d, position %d\n", linenumber, i+1);
	  exit(0);
	}
	else if( line[i] != ' ') {
	  tempSeq[ thefold->seqlength] = line[i];
	  //	  thefold->seq[thefold->seqlength] = line[i];
	  thefold->seqlength++;
	  i++;
	}
	else {
	  i++;
	}
      }
      else if(mode == 1) {  //Read in graph properties

	if( foldInitialized == FALSE) {
	  thefold->pairs = 
	    (int*) calloc( thefold->seqlength+1, sizeof(int));
	  thefold->pknots = 
	    (int*) calloc( thefold->seqlength+1, sizeof(int));
	  thefold->seq = 
	    (char*) calloc( thefold->seqlength+1, sizeof(char));
	  tmp_fix = (char*) calloc( thefold->seqlength+1, sizeof(char));
	  
	  for( init = 0; init <= thefold->seqlength; init++) {
	    thefold->seq[init] = tempSeq[ init];
	    tmp_fix[init] = '0';
	    thefold->pairs[init] = -1;
	    thefold->pknots[init] = -1;
	  }
	  foldInitialized = TRUE;
	}

	if( pairsFromParens[0] != -5) {
	  for( init = 0; init <= thefold->seqlength - 1; init++) {
	    thefold->pairs[init] = pairsFromParens[init];
	  }

	  line_done = TRUE;
	  done = TRUE;
	}
	else if( sscanf( line, "p %d %d", &pk1, &pk2) == 2) {
	  pk1--;
	  pk2--;
	  if( thefold->pknots[pk1] == -1 && thefold->pknots[pk2] == -1) {
	    thefold->pknots[ pk1] = pk2;
	    thefold->pknots[ pk2] = pk1;
	    if( pk2 - pk1 < 8) {
	      printf("Error! Pseudoknot region too small! %d %d\n", 
		     pk1, pk2); 
	    }
	    line_done = TRUE;
	  }
	  else {
	    printf("Error! base %d or %d is the end of multiple pknots\n",
		   pk1, pk2);
	    exit(0);
	  }
	}
	else if( sscanf( line, "%d %d %d", &paira, &pairb, &helixlength) < 3
 	    && line[0] != '.') {
	  printf("error: 3 integers expected at line %d\n", linenumber);
	  exit(0);   //error if format is incorrect
	}
 	else if( line[0] != '.') {
	  if( (paira > 0) && (pairb > paira) && (helixlength > 0) && 
	      (pairb <= thefold->seqlength) ) {
	    paira--;
	    pairb--;
	    if( thefold->pairs[ paira] == -1 
		&& thefold->pairs[ pairb] == -1 && pairb - paira >= 4) {
	      if( CanPair( thefold->seq[ paira], 
			   thefold->seq[ pairb]) == TRUE) {
		thefold->pairs[ paira] = pairb; 
		thefold->pairs[ pairb] = paira;
	      }
	      else {
		printf("%c, %c  cannot pair at positions %d %d\n", 
		       thefold->seq[paira+1], thefold->seq[pairb+1], 
		       paira+1, pairb+1);
		exit(0);
	      }
	    
	      for( indx = 1; indx <= helixlength - 1; indx++) {
		if( thefold->pairs[ paira + indx] == -1 && 
		    thefold->pairs[ pairb - indx] == -1) {
		  if( CanPair( thefold->seq[ paira+indx], 
			       thefold->seq[ pairb-indx]) == TRUE) {
		    thefold->pairs[ paira + indx] = pairb - indx;
		    thefold->pairs[ pairb - indx] = paira + indx;
		  }
		  else {
		    printf("!!%c, %c  cannot pair at positions %d %d\n", 
		       thefold->seq[paira+indx], thefold->seq[pairb-indx], 
			   paira+indx+1, pairb-indx+1);
		    exit(0);
		  }
		}

		else {
		  printf("Base %d or %d assigned twice!\n",
			 paira + indx, pairb-indx);
		  exit(0);
		}
	      }
	    }
	    else {
	      printf("Base %d or %d assigned twice!, or too close\n", 
		     paira, pairb);
	      exit(0);
	    }
	  }
	  line_done = TRUE;
	}
	else {
	  line_done = TRUE; //needed to exit loop
	  done = TRUE;
	}
      }      
      else { //this should never happen
	printf("Illegal mode value at line %d\n", linenumber);
	exit(0);
      }
    }
  }
  fclose( fp);
  if( done == FALSE) { //make sure file ended appropriately
    printf("File terminated before final \".\" reached\n");
    exit(0);
  }

}

/* *********************** */
void getStructureFromParens( char *tempSeq, char *line, int *pairs, 
			     int seqlength) {
  
  int i;
  int braces[seqlength];
  int leftParenIndex = 0;

  for( i = 0; i <= seqlength-1; i++) {
    braces[i] = -5;
    pairs[i] = -1;
  }

  for( i = 0; i <= seqlength - 1; i++) {
    if( leftParenIndex < 0 || leftParenIndex >= seqlength) {
      printf("Too many ), not enough (!\n");
      exit(0);
    }
    if( line[i] == '(') {
      braces[ leftParenIndex++] = i;
    }
    else if( line[i] == ')') {
      pairs[ braces[ --leftParenIndex]] = i;
      pairs[ i] = braces[ leftParenIndex];
    }
  }

}

//***************************************************  

int Base2int( char base) {
  /* Convert A, C, G, T, U to 1,2,3,4 respectively */
  if( base == 'A') {
    return 1;
  }
  else if ( base == 'C') {
    return 2;
  }
  else if (base == 'G') {
    return 3;
  }
  else if (base == 'T' || base =='U') {
    return 4;
  }
  else {
    printf("Error in Converting base %c!\n", base);
    exit(0);
    return NAD_INFINITY; // never returns this
  }
}

/* ************************************** */

int GetMismatchShift( char base1, char base2) {
  /* base1 and base2 are basepaired. the returned value is needed to 
     index energy arrays
  */
  int shift;

  if( base1 == 'A') { /* this is for retrieving 
                            proper mismatch energy */
    shift = 0;
  }
  else if( base1 == 'C') {
    shift = 1;
  }
  else if( base1 == 'G' && base2 == 'C') {
    shift = 2;
  }
  else if( base1 == 'G' && (base2 == 'T'|| base2 == 'U') ) {
    shift = 4;
  }
  else if( (base1 == 'T'|| base1 == 'U') && base2 == 'A') {
    shift = 3;
  }
  else if( (base1 == 'T'|| base1 == 'U') && base2 == 'G') {
    shift = 5;
  }
  else {
    printf("Error in GetMismatchShift. %c and %c don't pair!\n", 
           base1, base2);
    exit(0);
  }
  return shift;
}

/* ************************************************** */
int GetPairType( char b) { //assume pair of b is the watson crick pair
  int shift;

  if( b == 'A') { 
    shift = 0;
  }
  else if( b == 'C') {
    shift = 1;
  }
  else if( b == 'G') {
    shift = 2;
  }
  else if( b == 'T'|| b == 'U') {
    shift = 3;
  }
  else {
    printf("Error in GetPairType!\n");
    exit(0);
  }
  return shift;
}
/* *************************************************** */

int CanPair( char i, char j) {
  // Can base i and j form a watson crick or wobble base pair?

  if( Base2int( i) + Base2int( j) == 5
#ifndef NOGU
      ||
      Base2int( i) + Base2int( j) == 7
#endif
      ) {
    return TRUE;
  }
  else {
    return FALSE;
  }
}

/* ********************************************* */
