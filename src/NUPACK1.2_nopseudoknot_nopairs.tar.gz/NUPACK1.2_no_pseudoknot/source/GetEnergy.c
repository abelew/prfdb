/*  GetEnergy.c  by Robert Dirks.  

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     


This program determines the energies of
substructures, mirroring the loops of Fold.out
and includes the function for determining energies.  03/15/2001  */


#ifndef CONSTANTS_H
#include "constants.h"
#endif // Make sure this file isn't included multiple times

#ifndef FUNCTIONS_H
#include "functions.h"
#endif // Make sure this file isn't included multiple times

#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include"DNAExternals.h"

/* ******************************** */
double GetEnergy( fold *thefold) {
  double energy;

  energy = EnergyF( 0, thefold->seqlength - 1, thefold);
  
  return energy;
}

/* ********************************* */
double EnergyF( int start, int stop, fold *thefold) {
  
  double energy = 0.0;
  int d; //Left end of rightmost pair or pk
  
  int j;
  double bp_penalty;

  j = stop; 
  while( j >= start) {

    if( thefold->pknots[ j] != -1) {
      d = thefold->pknots[ j];
      
      energy +=
	EnergyPk( d, j, thefold) + BETA_1 +
	DangleEnergyWithPairs( j+1, stop, thefold->pairs,
			       thefold->seq, thefold->seqlength);
 
      j = d-1;
      stop = j;
    }
    else if( thefold->pairs[ j] != -1) {
      d = thefold->pairs[ j];
      if( d > j) {
	printf("Error: Unclassified pknot!\n");
	exit(0);
      }
      bp_penalty = 0;
      if( thefold->seq[d] != 'C' && thefold->seq[j] != 'C') {
	bp_penalty = AT_PENALTY;
      }

      energy +=
	EnergyFb( d, j, thefold) + 
	DangleEnergyWithPairs( j+1, stop, thefold->pairs,
			       thefold->seq, thefold->seqlength) +
	bp_penalty;

      j = d-1;
      stop = j;
    }
    else {
      j--;
    }
  }

  
  energy += DangleEnergyWithPairs( start, stop, 
				   thefold->pairs,
				   thefold->seq, thefold->seqlength);
  /*  
  energy += DangleEnergy( start, stop, 
			  thefold->seq, thefold->seqlength);
  */  

  return energy;
}

/* *************************************** */
  
double EnergyFb( int start, int stop, fold *thefold) {
  
  double energy = 0.0;
  int d; //Left end of rightmost pair or pk
  
  int j;
  int hairpin = TRUE;
  int interiorLoop = FALSE;
  double interiorEnergy;
  double Fb;
  double bp_penalty;
  int firstStop = stop;
  int i1, i2;

#ifdef logML
  int loopSize = 0;
#endif

  int *pairs;
  int nPairs;
  int i;
  double multiDangles;

  pairs = (int*) malloc( (thefold->seqlength)*sizeof( int) );
  pairs[0] = start;
  pairs[1] = stop;
  nPairs = 1;
  for( i = 2; i <= thefold->seqlength - 1; i++) {
    pairs[i] = -1;
  }

  j = stop - 1; 
  stop = j;
  while( j >= start + 1) {
    
    if( thefold->pknots[ j] != -1) {
      
      hairpin = interiorLoop = FALSE;
      energy += 2*ALPHA_2;
          
      d = thefold->pknots[ j];
      
      pairs[2*nPairs] =  d;
      pairs[2*nPairs + 1] = j;
      nPairs++;

      energy +=
	EnergyPk( d, j, thefold) + BETA_1M +  
	(stop - j)*ALPHA_3;
      j = d-1;
      stop = j;
    }
    else if( thefold->pairs[ j] != -1) {
      d = thefold->pairs[ j];

      pairs[2*nPairs] =  d;
      pairs[2*nPairs + 1] = j;
      nPairs++;

      if( d > j) {
	printf("Error: Unclassified pknot!\n");
	exit(0);
      }
      if( interiorLoop == TRUE) {
	interiorLoop = FALSE;
      }
      if( hairpin == TRUE) {
	hairpin = FALSE;
	interiorLoop = TRUE;
	i1 = d;
	i2 = j;
      }

      //assume multiloop
      bp_penalty = 0;
      if( thefold->seq[ d] != 'C' && thefold->seq[j] != 'C') {
	bp_penalty = AT_PENALTY;
      }

      Fb = EnergyFb( d, j, thefold);
      if( interiorLoop == TRUE) {
	interiorEnergy = 
	  InteriorEnergy( start, firstStop, i1, i2, thefold->seq) +
	  Fb;
      }

      energy +=
	Fb  + (stop - j)*ALPHA_3 + ALPHA_2 + bp_penalty;

   
#ifdef logML
      loopSize += (stop - j);
#endif

      j = d-1;
      stop = j;


    }
    else {
      j--;
    }
  }

  if( hairpin == TRUE) {
    energy = HairpinEnergy( start, firstStop, thefold->seq);
  }
  else if( interiorLoop == TRUE) {
    energy = interiorEnergy;
  }
  else { //multiloop   

    bp_penalty = 0;
    if( thefold->seq[ start] != 'C' && 
	thefold->seq[ firstStop ] != 'C') {
      bp_penalty = AT_PENALTY;
    }

    multiDangles = 
      DangleEnergyWithPairs( pairs[0]+1, pairs[nPairs*2-2]-1, thefold->pairs,
			     thefold->seq, thefold->seqlength ) +
      DangleEnergyWithPairs( pairs[3]+1, pairs[1]-1, thefold->pairs,
			     thefold->seq, thefold->seqlength );
    
    for( i = 3; i <= nPairs; i++) {
      multiDangles += 
	DangleEnergyWithPairs( pairs[2*i-1]+1, pairs[2*i-4]-1, 
			       thefold->pairs, thefold->seq, 
			       thefold->seqlength );
    }

#if defined(COAXIAL) && !defined(NODANGLE)
    //printf("multiDangles = %f\n", multiDangles);
    multiDangles = minCoaxialStacking( thefold, nPairs, 
				       pairs, multiDangles);
#endif
      
    energy += multiDangles +
      ALPHA_1 + ALPHA_2 + ALPHA_3*(stop-j) + bp_penalty;
   
   
#ifdef logML
    loopSize += (stop - j);
    
    if(loopSize > 6) {
      energy += (loopSize - 6)*ALPHA_3 +
	(1.75*R_GAS*TEMP_K*log((double)loopSize/6.));
    }
#endif 

  }
#ifdef SHOWFB
  printf("start = %d stop = %d Fb = %f\n", start, firstStop, energy);
#endif
  return energy;
}

/* *************************************************** */
double EnergyPk( int i, int j, fold *thefold) {

  int a,b,c,d,e,f; //along with i,j these are the 
  //eight key points of a pseudoknots (see figure 20 of paper)
  
  double energy;
  int findCF, findAD;
  double bp_penalty;
  char *seq = thefold->seq;

  //  printf("Pk! %d %d\n", i, j);

  e = thefold->pairs[i]; //guaranteed
  b = thefold->pairs[j]; //guaranteed

  findCF = FALSE;
  f = e+1; //initial guess
  while( findCF == FALSE) {
    if( thefold->pairs[ f] != -1 && thefold->pairs[f] < e) {
      c = thefold->pairs[ f];
      findCF = TRUE;
    }
    else {
      f++;
      if( f >= j) {
	printf("Illegal Pseudoknot closed by %d-%d\n", i, j);
	exit(0);
      }
    }
  }

  
  findAD = FALSE;
  a = b - 1; //initial guess
  while( findAD == FALSE) {
 
    if( thefold->pairs[ a] != -1 && thefold->pairs[ a] >  c) {
      d = thefold->pairs[ a];
      findAD = TRUE;
    }
    else {
      a--;
      if( a <= i) {
	printf("Error: Can't locate inner pair in Pk!\n");
	exit(0);
      }
    }
  }

  bp_penalty = 0;
  if( seq[ thefold->pairs[ i]] != 'C' && seq[ thefold->pairs[ e]] != 'C') {
    bp_penalty += AT_PENALTY;
  }
  if( seq[ thefold->pairs[ a]] != 'C' && seq[ thefold->pairs[ d]] != 'C') {
    bp_penalty += AT_PENALTY;
  }
  if( seq[ thefold->pairs[ b]] != 'C' && seq[ thefold->pairs[ j]] != 'C') {
    bp_penalty += AT_PENALTY;
  }  
  if( seq[ thefold->pairs[ c]] != 'C' && seq[ thefold->pairs[ f]] != 'C') {
    bp_penalty += AT_PENALTY;
  }   

  energy = EnergyFg( i, a, d, e, thefold) + EnergyFg( b, c, f, j, thefold) +
    EnergyFz( a+1, b-1, thefold) + EnergyFz( c+1, d-1, thefold) + 
    EnergyFz( e+1, f-1, thefold) + 2*BETA_2 + bp_penalty;

  //printf("PkEnergy = %f\n", energy);
  return energy;
}

/* ****************************  */

double EnergyFg( int i, int d, int e, int j, fold *thefold) {

  double energy = 0.0;
  int c, f; //end of rightmost pair or pk
  
  double multi_bp_penalty;  //bp_penalty, for the multiloop case
  int multiloop = FALSE; //extended gap
  int interiorLoop = TRUE; //regular gap
  int noPairs = TRUE; //empty gap matrix
  double energyRight; //energy of right gap, in case it is a pk

  int span1, span2;  //pair that spans the gap
  int side = 1; //1 = between e and j, -1 = between i and d
  int stop;

  //  printf("Fg! %d %d %d %d\n", i,d,e,j);

  multi_bp_penalty = 0;
  f = j - 1;  
  stop = f;
  
  while( f >= i + 1) {
    //printf("f = %d\n", f);
    if( thefold->pknots[ f] != -1) {
      noPairs = FALSE;
      interiorLoop = FALSE;
      multiloop = TRUE;
      energy += 2*ALPHA_2;
      c = thefold->pknots[ f];
      if( c <= d && side == 1) {
	printf("Error: Pseudoknot spans a gap matrix!\n");
	exit(0);
      }

      energy +=
	EnergyPk( c, f, thefold) + BETA_1M +
	DangleEnergyWithPairs( f+1, stop, thefold->pairs, 
		      thefold->seq, thefold->seqlength) + 
	(stop - f)*ALPHA_3;
      f = c-1;
      stop = f;
    }
    else if( thefold->pairs[ f] != -1) {
      c = thefold->pairs[ f];
      if( c > f) {
	printf("Error: Unclassified pknot!\n");
	exit(0);
      }
      else if( side == 1 && c < d) {
	span1 = c; 
	span2 = f;
	noPairs = FALSE;
	side = -1;
	energy += EnergyFg( c,d,e,f, thefold);
	if( thefold->seq[c] != 'C' && thefold->seq[f] != 'C') {
	  multi_bp_penalty += AT_PENALTY;
	}
	energyRight = DangleEnergyWithPairs( f+1, stop, thefold->pairs,
					     thefold->seq, 
					     thefold->seqlength)
	  + (stop - f)*ALPHA_3;
	f = c-1;
	stop = f;
      }
      else if( side == 1 && c > e) {
	noPairs = FALSE;
	interiorLoop = FALSE;
	multiloop = TRUE;
	//printf("c = %d, f = %d, stop = %d\n", c,f,stop);
	energy += EnergyFb( c, f, thefold) + 
	  DangleEnergyWithPairs( f+1, stop, thefold->pairs,
				 thefold->seq, thefold->seqlength)
	  + (stop - f)*ALPHA_3 + ALPHA_2;
	if( thefold->seq[c] != 'C' && thefold->seq[f] != 'C') {
	  multi_bp_penalty += AT_PENALTY;
	}
	f = c-1;
	stop = f;
      }
      else if( side == -1) {
	noPairs = FALSE;
	interiorLoop = FALSE;
	multiloop = TRUE;
	energy += EnergyFb( c, f, thefold) + 
	  DangleEnergyWithPairs( f+1, stop, thefold->pairs,
				 thefold->seq, thefold->seqlength)
	  + (stop - f)*ALPHA_3 + ALPHA_2;
	if( thefold->seq[c] != 'C' && thefold->seq[f] != 'C') {
	  multi_bp_penalty += AT_PENALTY;
	}
	f = c-1;
	stop = f;
      }
      else if( c == d) {
	energyRight = 
	  DangleEnergyWithPairs( f+1, stop, thefold->pairs, 
			thefold->seq, thefold->seqlength)
	  + (stop - f)*ALPHA_3;

	side = -1;
	f = c - 1;
	stop = f;
      }
      else {
	printf("Impossible construction in pknot!\n");
	exit(0);
      }
    }
    else {
      f--;
    }
    /* 09/11/03
    if( f == e) { //jump the gap.
      //Is this needed?  the c == d case above should handle it
      energyRight = DangleEnergy( f+1, stop, thefold->seq, thefold->seqlength)
 	+ (stop - f)*ALPHA_3;
      f = d - 1;
      stop = f;
      side = -1;      
    } 
    */
  }

  if( noPairs == TRUE) {
    energy +=  InteriorEnergy( i, j, d, e, thefold->seq);
  }
  else if( interiorLoop == TRUE) {
    energy += InteriorEnergy( i, j, span1, span2, thefold->seq);
  }
  else if( multiloop == TRUE) {
    if( thefold->seq[ i] != 'C' && thefold->seq[j] != 'C') {
	multi_bp_penalty += AT_PENALTY;
    }

    energy += ALPHA_1 + multi_bp_penalty + 2*ALPHA_2 + 
      energyRight + DangleEnergyWithPairs( i+1, c-1, thefold->pairs,
					   thefold->seq, thefold->seqlength);
  }
  else {
    printf("Error in Fg!\n");
    exit(0);
  }
  
  return energy;
}

/* ******************************************** */

double EnergyFz( int start, int stop, fold *thefold) {
  
  double energy = 0.0;
  int d; //Left end of rightmost pair or pk
  
  double bp_penalty;
  int j; //right end of pair or pk

  //  printf("Fz %d %d\n", start, stop);

  j = stop; 
  while( j >= start) {
    if( thefold->pknots[ j] != -1) {
      d = thefold->pknots[ j];
      
      energy +=
	EnergyPk( d, j, thefold) + BETA_1P + 
	DangleEnergyWithPairs( j+1, stop, thefold->pairs,
			       thefold->seq, thefold->seqlength) +
	BETA_3*( stop - j) + 2*BETA_2;
 
      j = d-1;
      stop = j;
    }
    else if( thefold->pairs[ j] != -1) {
      d = thefold->pairs[ j];
      if( d > j) {
	printf("Error: Unclassified pknot!\n");
	exit(0);
      }
      bp_penalty = 0;
      if( thefold->seq[d] != 'C' && thefold->seq[j] != 'C') {
	bp_penalty = AT_PENALTY;
      }

      energy +=
	EnergyFb( d, j, thefold) + 
	DangleEnergyWithPairs( j+1, stop, thefold->pairs,
			       thefold->seq, thefold->seqlength) +
	bp_penalty + BETA_3*( stop - j) + BETA_2;

      j = d-1;
      stop = j;
    }
    else {
      j--;
    }
  }

  energy += DangleEnergyWithPairs( start, stop, thefold->pairs,
				   thefold->seq, thefold->seqlength) +
    BETA_3*(stop - start + 1);

  return energy;
}

/* *************************************** */

#ifdef COAXIAL
double minCoaxialStacking( fold *thefold, int nPairs, 
			   int *pairs, double nonStackDangle) {
  /*This function will determine the minimum coaxially stacking
    configuration for a multiloop
    pairs should be of the format
    for all even a:
    pairs[a] is paired to pairs[a+1] with pairs[a] < pairs[a+1]
    pairs[0]-pairs[1] is closing pair of multiloop, and remaining pairs
    pairs[2]-pairs[3] is the rightmost (3') pair in the multiloop, and
    successive pairs move from right to left

    nPairs is the number of pairs (including the closing one
    in the multiloop.
  */
  
  char *seq = thefold->seq;
  double minEnergy = nonStackDangle;
  double energy;

  if( nPairs <= 2) {
    printf("Error!  Non multiloop sent to coaxially stacking subroutine!");
    exit(0);
  }

  //first check if closing pair can stack with 5' pair
  if( pairs[0] == pairs[nPairs*2-2] - 1) {
    
    energy = CoaxEnergy( seq[pairs[0]], seq[pairs[1]],
			 seq[pairs[nPairs*2-2]], seq[pairs[nPairs*2-1]]) +
      minCoax( 2, TRUE, 5, nPairs, pairs, thefold);

    minEnergy = MIN( minEnergy, energy);
    //printf("+1 %f %f\n", energy, minEnergy);
  }

  //next check if closing pair can stack with 3' pair
  if( pairs[1] == pairs[ 3] + 1) {

    energy = CoaxEnergy( seq[pairs[0]], seq[pairs[1]], 
			 seq[pairs[2]], seq[pairs[3]] ) + 
      minCoax( 3, TRUE, 3, nPairs, pairs, thefold);
     
    minEnergy = MIN( minEnergy, energy);
    //printf("+2 %f %f\n", energy, minEnergy);
  }

  //next check the case where closing pair is not stacked
  energy = minCoax(2, FALSE, 0, nPairs, pairs, thefold);
  minEnergy = MIN( minEnergy, energy);
  //printf("+3 %f %f\n", energy, minEnergy);

  return minEnergy;
}

/* ******************************** */
double minCoax( int startPair, int isPreviousPairStacked, 
		int closingPairState,
		int nPairs, int *pairs, fold *thefold) {
  /* This function will determine whether or not the startPair should be
     stacked with the pair on its 5' side (find min energy).

     startPair is the current pair number being considered for stacking
     with a pair on its left.
     
     isPreviousPairStacked indicates whether the previous pair is stacked 
     or not.
     
     closingPairState = 0 if not stacked
                        3 if stacked on the 3' side
			5 if stacked on the 5' side
  */


  double minEnergy = NAD_INFINITY;
  double energy;
  int i, j, h, m;
  int whichDangle; //5 = 5' end only; 3 = 3' only, 53 = both  
  char *seq = thefold->seq;

  //printf("%d %d %d %d\n", startPair, isPreviousPairStacked, 
  //	 closingPairState, nPairs);

  if( startPair == nPairs) {
    h = pairs[startPair*2 - 1];
    if( closingPairState == 5) {
      energy = 0;
      if( isPreviousPairStacked == FALSE) {
	energy = CoaxDangle( 3, h+1, pairs[ startPair*2-4] - 1,
			     thefold->pairs, thefold->seq, 
			     thefold->seqlength);
      }
      //printf("- %d %d %f\n", h, pairs[ startPair*2-4], energy);
    }
    else {
      whichDangle = 53;
      if( isPreviousPairStacked == TRUE) {
	whichDangle = 5;
      }
   
      energy = CoaxDangle( whichDangle, h+1, pairs[ startPair*2-4] - 1,
			   thefold->pairs, thefold->seq, 
			   thefold->seqlength);
      //printf("energy= %d %d %d %f\n", whichDangle, h+1, 
      //pairs[ startPair*2-3] - 1, energy);

      whichDangle = 53;
      if( closingPairState == 3) {
	whichDangle = 3;
      }
      energy += CoaxDangle( whichDangle, pairs[0]+1, pairs[ startPair*2-2] - 1,
			    thefold->pairs, thefold->seq, 
			    thefold->seqlength);

    }
    minEnergy = MIN( energy, minEnergy);

  }
  else {
    if( pairs[startPair*2-2] == pairs[ startPair*2+1] + 1 &&
	(startPair != nPairs - 1 || closingPairState != 5) ) {
      //consider stacked case
      i = pairs[ startPair*2];
      j = pairs[ startPair*2+1];
      h = pairs[ startPair*2-2]; 
      m = pairs[ startPair*2-1];

      energy = CoaxEnergy( seq[m], seq[h], seq[i], seq[j]);
      
      if( isPreviousPairStacked == FALSE && startPair != 2) {
	energy += CoaxDangle( 3, m+1, pairs[ startPair*2-4] - 1,
			      thefold->pairs, thefold->seq, 
			      thefold->seqlength);
      }
      else if( isPreviousPairStacked == FALSE) {
	energy += CoaxDangle( 3, m+1, pairs[1] - 1,
			      thefold->pairs, thefold->seq, 
			      thefold->seqlength);
      }
      //if previous pair is stacked, there is no dangle
      
      if( startPair != nPairs - 1) {
	energy += minCoax( startPair+2, TRUE, closingPairState, nPairs,
			   pairs, thefold);
      }
      else if( closingPairState == 0) {
	energy += CoaxDangle( 5, pairs[0] + 1, pairs[ nPairs*2-2] - 1,
			      thefold->pairs, thefold->seq, 
			      thefold->seqlength);
      }
      //closingPairState == 3 then no dangle

      minEnergy = MIN( minEnergy, energy);
      //printf("test\n");
    }

    energy = 0;
    whichDangle = 53;
    if( isPreviousPairStacked == TRUE) {
      whichDangle = 5;
    }

    h = pairs[ startPair*2 -1]; //+1
    //consider unstacked case
    if( startPair != 2) {
      energy = CoaxDangle( whichDangle, h+1, pairs[ startPair*2-4] - 1,//-2
			    thefold->pairs, thefold->seq, 
			    thefold->seqlength);
    }
    else {
      energy = CoaxDangle( whichDangle, h+1, pairs[1] - 1,
			    thefold->pairs, thefold->seq, 
			    thefold->seqlength);
    }

    energy += minCoax( startPair+1, FALSE, closingPairState, nPairs,
		       pairs, thefold);
  
    minEnergy = MIN( minEnergy, energy);
  }

  //printf("return %f\n", energy);
  return minEnergy;
}

/* ***************************** */

double CoaxEnergy( char i, char j, char h, char m) {
  double energy;
  double bp_bonus = 0;

  //remove any AT_PENALTY if bases are stacked
  if( i != 'C' && j != 'C') {
    bp_bonus -= AT_PENALTY;
  }
  if( h != 'C' && m != 'C') {
    bp_bonus -= AT_PENALTY;
  }

  energy = HelixEnergy(i,j,h,m) + bp_bonus;  
  
  return energy;
}
   
/* ******************************** */
#endif
