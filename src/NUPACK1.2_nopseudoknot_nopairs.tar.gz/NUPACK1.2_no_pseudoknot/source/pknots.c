/* pknots.c by Robert Dirks 08/21/2001

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     

This contains subroutines for the folding and partition function algorithms 
found in "fold.c" and "pfunc.c".  The functions in this file will help 
generate and assign energies to pseudoknots involving two specified bases as 
the pknot's 5' and 3' ends.  

*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#ifndef CONSTANTS_H
#include"constants.h"
#endif

#ifndef FUNCTIONS_H
#include"functions.h"
#endif

#include "DNAExternals.h"
/* ********************************************* */
#ifdef PKNOTS
double MinFb_Pk( int i, int j, char seq[], int seqlength, 
			double Fp[], double Fm[] ) {
  // Determine all possible, rightmost pseudoknots 
  // contained in i,j "loop" and calculate SumExp
  

  double bp_penalty = 0;
  double min_energy = NAD_INFINITY;
  double tempMin;
  int d, e; //the left and right ends of a pseudoknot
  int pf_de;

  if( Base2int( seq[i]) + Base2int( seq[j]) != 5) {
    return NAD_INFINITY;
  }

  if( seq[i] != 'C'  && seq[j] != 'C') {
    bp_penalty = AT_PENALTY;
  }
  
  for( d = i+1; d <= j - 9; d++) {
    for( e = d + 8; e <= j - 1; e++) {
      pf_de = pf_index( d, e, seqlength);

      tempMin = 
	(BETA_1M + ALPHA_1 + 3*ALPHA_2 + 
	 (j-e-1 + d-i-1)*ALPHA_3 + bp_penalty) +
	DangleEnergy( i+1, d-1, seq, seqlength) +
	DangleEnergy( e+1, j-1, seq, seqlength) +
	Fp[ pf_de];

      min_energy = MIN( min_energy, tempMin);

      tempMin = Fm[ pf_index( i+1, d-1, seqlength)] + 
	Fp[ pf_de] + ( BETA_1M + ALPHA_1 + 3*ALPHA_2 + bp_penalty + 
		       (j - e - 1)*ALPHA_3 ) +
	DangleEnergy( e+1, j-1, seq, seqlength);

      min_energy = MIN( min_energy, tempMin);

    }
  }

  return min_energy;
}
#endif //PKNOTS

/* ***************************************** */
#ifdef O_N8
void MakeFg_N8( int i, int j, char seq[], int seqlength, double Fg[],
	     double Fm[]) {
  //  Make the gap matrix for Fg
  int c,d,e,f;
  int gap_idej;
  double IJ_bp_penalty = 0.0;
  double bp_penalty = 0;
  double tempMin;

  if( CanPair( seq[i], seq[j]) == FALSE) {
    return;
  }

  IJ_bp_penalty = 0.0;
  if( seq[i] != 'C' && seq[j] != 'C') {
    IJ_bp_penalty = AT_PENALTY;
  }


  //Case 1:  Terminal Inner Pair
  for( d = i+1; d <= j-5; d++) {
    for( e = d+4; e <= j-1; e++) {      
      if( CanPair( seq[d], seq[e] ) == TRUE) {	

	gap_idej = gap_index(i,d,e,j, seqlength);
	
	tempMin = InteriorEnergy( i, j, d, e, seq); 
	Fg[ gap_idej] =
	  MIN( tempMin, Fg[ gap_idej]);
	  
      }
    }
  }
  
  
  //Case 2:  Simple Interior Loop
  for( d = i+2; d <= j-6; d++) {
    for( e = d+4; e <= j-2; e++) {      
      gap_idej = gap_index(i,d,e,j,seqlength);
      if( CanPair( seq[d], seq[e] ) == TRUE) { 
	
	for( c = i+1; c <= d-1; c++) {
	  for( f = e+1; f <= j-1; f++) {
	    if( CanPair( seq[c], seq[f]) == TRUE) {

	      tempMin = 
		InteriorEnergy( i, j, c, f, seq) + 
		Fg[ gap_index( c, d, e, f, seqlength)];
	      Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]);
	      

	    }
	  }
	}
      }
    }
  }

  if( Base2int( seq[i]) + Base2int(seq[j]) == 5) {
  
    //Case 3:  Multiloop Left
    for( d = i+6; d <= j-5; d++) {
      for( e = d+4; e <= j-1; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE &&
	    Base2int( seq[d]) + Base2int( seq[e]) == 5) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }
	  
	  tempMin = 
	    Fm[ pf_index( i+1, d-1, seqlength)] +
	    (ALPHA_1 + 2*ALPHA_2 + (j-e-1)*ALPHA_3 + bp_penalty) +
	    DangleEnergy( e+1, j-1, seq, seqlength);
	  
	  Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]);
	  
	}
      }
    }
    
    //Case 4:  Multiloop Right
    for( d = i+1; d <= j-10; d++) {
      for( e = d+4; e <= j-6; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE &&
	    Base2int( seq[d]) + Base2int( seq[e]) == 5) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }
	  
	  tempMin = 
	    Fm[ pf_index( e+1, j-1, seqlength)] +
	    (ALPHA_1 + 2*ALPHA_2 + (d-i-1)*ALPHA_3 + bp_penalty) +
	    DangleEnergy( i+1, d-1, seq, seqlength);
	  Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]);
	  
	}
      }
    }
    
    
    //Case 5: Multiloop Both Sides
    for( d = i+6; d <= j-10; d++) {
      for( e = d+4; e <= j-6; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE && 
	    Base2int( seq[d]) + Base2int( seq[e]) == 5) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }
	  
	  tempMin = 
	    Fm[ pf_index( i+1, d-1, seqlength)] +
	    Fm[ pf_index( e+1, j-1, seqlength)] +
	    (ALPHA_1 + 2*ALPHA_2 + bp_penalty);
	  
	  Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]);
	}
      }
    }
    
    
    //Case 6: Multiloop Left + More Qg
    for( d = i+7; d <= j-6; d++) {
      for( e = d+4; e <= j-2; e++) {      
	gap_idej = gap_index(i,d,e,j,seqlength);
	if( CanPair( seq[d], seq[e] ) == TRUE ) { 
	  
	  for( c = i+6; c <= d-1; c++) {
	    for( f = e+1; f <= j-1; f++) {
	      if( CanPair( seq[c], seq[f]) == TRUE &&
		  Base2int( seq[c]) + Base2int( seq[f]) == 5) {
		
		bp_penalty = IJ_bp_penalty;
		if( seq[c] != 'C' && seq[f] != 'C') {
		  bp_penalty += AT_PENALTY;
		}
		
		tempMin = 
		  Fm[ pf_index( i+1, c-1, seqlength)] +
		  (ALPHA_1+2*ALPHA_2+(j-f-1)*ALPHA_3 + bp_penalty) + 
		  Fg[ gap_index( c, d, e, f, seqlength)] +
		  DangleEnergy( f+1, j-1, seq, seqlength);
		Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]);
		
	      }
	    }
	  }
	}
      }
    }
  
    
    //Case 7: Multiloop Right + More Qg
    for( d = i+2; d <= j-11; d++) {
      for( e = d+4; e <= j-7; e++) {      
	gap_idej = gap_index(i,d,e,j,seqlength);
	if( CanPair( seq[d], seq[e] ) == TRUE) { 
	  
	  for( c = i+1; c <= d-1; c++) {
	    for( f = e+1; f <= j-6; f++) {
	      if( CanPair( seq[c], seq[f]) == TRUE &&
		  Base2int( seq[c]) + Base2int( seq[f]) == 5) {
		
		bp_penalty = IJ_bp_penalty;
		if( seq[c] != 'C' && seq[f] != 'C') {
		  bp_penalty += AT_PENALTY;
		} 
		
		tempMin = 
		  Fm[ pf_index( f+1, j-1, seqlength)] +
		  (ALPHA_1+2*ALPHA_2+(c-i-1)*ALPHA_3+bp_penalty) + 
		  Fg[ gap_index( c, d, e, f, seqlength)] +
		  DangleEnergy( i+1, c-1, seq, seqlength);
		

		Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]);
		
	      }
	    }
	  }
	}
      }
    }
    
    
    //Case 8: Multiloop Both sides + More Qg
    for( d = i+7; d <= j-11; d++) {
      for( e = d+4; e <= j-7; e++) {      
	gap_idej = gap_index(i,d,e,j,seqlength);
	if( CanPair( seq[d], seq[e] ) == TRUE) { 
	  
	  for( c = i+6; c <= d-1; c++) {
	    for( f = e+1; f <= j-6; f++) {
	      if( CanPair( seq[c], seq[f]) == TRUE &&
		  Base2int( seq[c]) + Base2int( seq[f]) == 5) {
		
		bp_penalty = IJ_bp_penalty;
		if( seq[c] != 'C' && seq[f] != 'C') {
		  bp_penalty += AT_PENALTY;
		}
		
		tempMin = 
		  Fm[ pf_index( i+1, c-1, seqlength)] +
		  Fm[ pf_index( f+1, j-1, seqlength)] +
		  (ALPHA_1+2*ALPHA_2+bp_penalty) +
		  Fg[ gap_index( c, d, e, f, seqlength)];
		
		Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]);
	      }
	    }
	  }
	}
      }
    }
  }
}

#endif

/* ********************************** */
#ifdef O_N5
void MakeFg_N5( int i, int j, char seq[], int seqlength, double Fg[],
		double Fm[], double Fgls[], double Fgrs[], double FgIx[],
		double FgIx_2[], short possiblePairs[]) {
  //  Make the gap matrix for Qg
  int c,d,e,f;
  int gap_idej;
  double IJ_bp_penalty = 0.0;
  double bp_penalty = 0;
  double tempMin;

  IJ_bp_penalty = 0.0;
  if( seq[i] != 'C' && seq[j] != 'C') {
    IJ_bp_penalty = AT_PENALTY;
  }

  if( CanPair( seq[i], seq[j]) == TRUE) {
 
    //Case 1:  Terminal Inner Pair
    for( d = i+1; d <= j-5; d++) {
      for( e = d+4; e <= j-1; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE) {
	  
	  gap_idej = gap_index( i, d, e, j, seqlength);

	  tempMin = 
	    InteriorEnergy( i, j, d, e, seq);
	  Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]);

	}
      }
    }
  }

  fastIloop_Fg(i, j, seq, seqlength, Fg, FgIx, FgIx_2, possiblePairs);


  if( CanPair( seq[i], seq[j]) == TRUE && 
      Base2int( seq[i]) + Base2int( seq[j]) == 5) {
   
    //Case 2:  Multiloop Left
    for( d = i+6; d <= j-5; d++) {
      for( e = d+4; e <= j-1; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE 
	    && Base2int( seq[d]) + Base2int( seq[e]) == 5) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }
	  
	  tempMin = 
	    Fm[ pf_index( i+1, d-1, seqlength)] +
	    (ALPHA_1 + 2*ALPHA_2 + (j-e-1)*ALPHA_3 + bp_penalty) +
	    DangleEnergy( e+1, j-1, seq, seqlength);
	  Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]);
	}
      }
    }

    //Case 3:  Multiloop Right
    for( d = i+1; d <= j-10; d++) {
      for( e = d+4; e <= j-6; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE
	    && Base2int( seq[d]) + Base2int( seq[e]) == 5 
	    ) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }
	  
	  tempMin = 
	    Fm[ pf_index( e+1, j-1, seqlength)] +
	    (ALPHA_1 + 2*ALPHA_2 + (d-i-1)*ALPHA_3 + bp_penalty) +
	    DangleEnergy( i+1, d-1, seq, seqlength) ;
	  Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]);
	}
      }
    }

    //Case 4: Multiloop Both Sides
    for( d = i+6; d <= j-10; d++) {
      for( e = d+4; e <= j-6; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE
	    && Base2int( seq[d]) + Base2int( seq[e]) == 5
	    ) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }	
	  
	  tempMin = 
	    Fm[ pf_index( i+1, d-1, seqlength)] +
	    Fm[ pf_index( e+1, j-1, seqlength)] +
	    (ALPHA_1 + 2*ALPHA_2 + bp_penalty);
	  Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]);
	  
	}
      }
    }

    //Case 5: Interior loop + multi left
    for( d = i+7; d <= j-6; d++) {
      for( e = d+4; e <= j-2; e++) {      
	gap_idej = gap_index(i,d,e,j,seqlength);
	if( CanPair( seq[d], seq[e] ) == TRUE) {
	 
	  for( f = e+1; f <= j-1; f++) {
	    bp_penalty = IJ_bp_penalty;
	    
	    tempMin = 
	      (ALPHA_1+ALPHA_2 + (j-f-1)*ALPHA_3+ bp_penalty) + 
	      Fgls[ gap_index( i+1, d, e, f, seqlength)] +
	      DangleEnergy( f+1, j-1, seq, seqlength);
	    Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]);
	  }	
	}
      }
    }


    //Case6: Interior loop + multi right
    for( d = i+2; d <= j-11; d++) {
      for( e = d+4; e <= j-7; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE) {
      
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  for( c = i+1; c <= d-1; c++) {
	    bp_penalty = IJ_bp_penalty;
	    
	    tempMin = 
	      (ALPHA_1+ALPHA_2 + (c-i-1)*ALPHA_3 + 
		     bp_penalty) + 
	      Fgrs[ gap_index( c, d, e, j-1, seqlength)] +
	      DangleEnergy( i+1, c-1, seq, seqlength);
	    Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]);
	  }	
	}
      }
    }
   
    //Case 7: Interior loop + multi both sides
    for( d = i+7; d <= j-11; d++) {
      for( e = d+4; e <= j-7; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE) {
	
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  for( c = i+6; c <= d-1; c++) {	
	    bp_penalty = IJ_bp_penalty;
	    
	    tempMin = 
	      Fm[ pf_index( i+1, c-1, seqlength)] +
	      (ALPHA_1+ALPHA_2+bp_penalty) +
	      Fgrs[ gap_index( c, d, e, j-1, seqlength)];
	    Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]);

	  }	
	}
      }
    }
  } // Can Pair
}

/* ******************************************* */
void fastIloop_Fg(int i, int j, char seq[], int seqlength, 
		  double Fg[], double FgIx[], double FgIx_2[],
		  short possiblePairs[]) {
  
  int d, e, size;
  int L = j - i + 1;
  int pf_ij = pf_index(i, j, seqlength);
  int index;
  int gap_idej;
  double tempMin;

  //FgIx recurions
  //Explicitly add in base cases to QgIx (smallest extensible loops) 
  
  if( L >= 17 && possiblePairs[pf_ij] == TRUE) {
    makeNewFgIx( i, j, seq, seqlength, Fg, FgIx);
  }
  
  for( d = i+1; d <= j-5; d++) {
    for( e = d+4; e <= j-1; e++) {
      if(  CanPair( seq[d], seq[e]) == TRUE) {
		
	gap_idej = gap_index( i,d,e,j, seqlength);
	
	if( L>=17 &&  CanPair( seq[i], seq[j]) == TRUE) { 
	  
	  index = QgIxIndex( j-i, i, 8, d, e, seqlength);
	  
	  for( size = 8; size <= L - 9; size++) {
	    tempMin = FgIx[ index] + 
	      InteriorMM( seq[i], seq[j], seq[i+1], seq[j-1]);
	    Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]); 
	    index = index + (L-2)*(L-3)/2;
	  }
	  
	}
	
	if( i != 0 && j != seqlength - 1) {
	   extendOldFgIx( i, j, d, e, seq, seqlength, 
			  Fg, FgIx, FgIx_2);
	}
	

	tempMin = MinInextensibleIL_Fg( i, j, d, e, seq, seqlength,
					   Fg);
	Fg[ gap_idej] = MIN( tempMin, Fg[ gap_idej]);
      }
    }
  }
}

/* ************************************************* */
double MinInextensibleIL_Fg( int i, int j, int d, int e, 
				char seq[], int seqlength, 
				double Fg[]) {
  /* This finds the minimum energy IL that has a special energy 
     calculation, i.e. small loops, bulge loops or GAIL case */
    
  double energy;
  int c, f; //Internal pair.(c, f will be restricted to special cases)
  
  int L1, L2; //size parameters: L1 + L2 = size, L1 = c-i-1, L2 = j-f-1
 
  double tempMin;
  double min_energy = NAD_INFINITY;

  if( CanPair( seq[i], seq[j]) == FALSE) { 
    return NAD_INFINITY;
  }

  /* First consider small loops */
  // L1 <= 3, L2 <= 3
  for( L1 = 0; L1 <= MIN(3, d-i-2); L1++) {
    c = i + L1 + 1;
    for( L2 = 0; L2 <= MIN( 3, j-e-2); L2++) {      
      f = j - L2 - 1;
      if( CanPair( seq[c], seq[f]) == TRUE) { //c < d && f > e

	energy = InteriorEnergy( i, j, c, f, seq);

	tempMin = energy +
	  Fg[ gap_index( c, d, e, f, seqlength)];
	min_energy = MIN( tempMin, min_energy);

      }
    }
  }

  /* Next consider large bulges or large asymmetric loops */
  // Case 2a  L1 = 0,1,2,3, L2 >= 4;
  for( L1 = 0; L1 <= MIN(3, d-i-2); L1++) {
    c = i + L1 + 1;
    for( L2 = 4; L2 <= j - e - 2; L2++) {
      f = j - L2 - 1;
      if( CanPair( seq[c], seq[f]) == TRUE) { //c < d && f > e
	energy = InteriorEnergy( i, j, c, f, seq);	
	tempMin = energy +
	  Fg[ gap_index( c, d, e, f, seqlength)];
	min_energy = MIN( tempMin, min_energy);
      }
    }
  }

  // Case 2b L1 >= 4, L2 = 0,1,2,3;
  for( L2 = 0; L2 <= MIN(3,j-e-2) ; L2++) {
    f = j - L2 - 1;
    for( L1 = 4; L1 <= d-i-2; L1++) {
      c = i + L1 + 1;
      if( CanPair( seq[c], seq[f]) == TRUE) { //c < d && f > e
	
	energy = InteriorEnergy( i, j, c, f, seq);
	tempMin = energy + 
	  Fg[ gap_index( c, d, e, f, seqlength)];
	min_energy = MIN( tempMin, min_energy);

      }
    }
  }    

  return min_energy;

}  
/* *********************************************** */
 

void makeNewFgIx( int i, int j, char seq[], int seqlength, 
  double Fg[], double FgIx[]) {

 /*Determine the new entries of FgIx(i,j,d,e,size) that are not extended 
    versions of FgIx(i+1, j-1, h1, e, size-2) */
  
  extern double loop37[];
  extern double asymmetry_penalty[];
  extern double max_asymmetry;

  double energy;
  int c, f; //Internal pair.(c, f will be restricted to special cases)
  int d,e;// Internal pair of gap matrix (no restrictions);

  int size, L1, L2; //size parameters: L1 + L2 = size, L1 = c-i-1, L2 = j-f-1
  int asymmetry;
  int asymmetry_index;
  int partial_index; //used to limit calls to QgIxIndex
  int len1_len2 = (j-i-1)*(j-i-2)/2;
  double tempMin;

  //Add in all the cases that are not an extended version of an
  //extensible case.

  
  for( d = i + 6; d <= j - 10; d++) {
    for( e = d + 4; e <= j-6; e++) {
      if( CanPair( seq[d], seq[e]) ) {
	partial_index = QgIxIndex( j-i, i, 0, d, e, seqlength);

	//Case 1:  L1 = 4, L2 >= 4;
	L1 = 4;
	c= i + L1 + 1;
	for( L2 = 4; L2 <= j - e - 2; L2++) {
	  f = j - L2 - 1;
	  size = L1 + L2;
	  
	  if( CanPair( seq[c], seq[f]) == TRUE) {
	    asymmetry = abs( L1 - L2);
	    //Loop Size Energy
	    if( size <= 30) {
	      energy = loop37[ size - 1];
	    }
	    else {
	      energy = loop37[ 30 - 1];
	      energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
	    }
	    
	    //Asymmetry rountine copied from efn.f in Zuker's mfold package.
	    asymmetry_index = 4;
	    
	    if( asymmetry*asymmetry_penalty[ asymmetry_index - 1] < max_asymmetry ) {
	      energy += asymmetry*asymmetry_penalty[ asymmetry_index - 1];
	    }
	    else {
	      energy += max_asymmetry; // MAX asymmetry penalty
	    }
	    
	    energy += InteriorMM( seq[f], seq[c], seq[f+1], seq[c-1]);
	    /*Exclude the i-j stacking energy here, just in case i-j 
	      don't pair */
	    
	    tempMin = 
	      energy + Fg[ gap_index( c, d, e, f, seqlength)];

	    FgIx[ partial_index+size*len1_len2 ] = 
	      MIN( FgIx[ partial_index+size*len1_len2 ], tempMin); 
						       
	  }
	}    
	  
	//Case 2  L1 > 4, L2 = 4
	if( d >= i+7) {
	  L2 = 4;
	  f = j-L2-1;
	  for( L1 = 5; L1 <= d-i-2; L1++) {
	    c = i + L1 + 1;
	    size = L1 + L2;
	    
	    if( CanPair( seq[c], seq[f]) == TRUE) {
	      asymmetry = abs( L1 - L2);
	      //Loop Size Energy
	      if( size <= 30) {
		energy = loop37[ size - 1];
	      }
	      else {
		energy = loop37[ 30 - 1];
		energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
	      }
	      
	      
	      //Asymmetry rountine copied from efn.f in Zuker's mfold package.
	      asymmetry_index = 4;
	      
	      if( asymmetry*asymmetry_penalty[ asymmetry_index - 1] < max_asymmetry ) {
		energy += asymmetry*asymmetry_penalty[ asymmetry_index - 1];
	      }
	      else {
		energy += max_asymmetry; // MAX asymmetry penalty
	      }
	      energy += InteriorMM( seq[f], seq[c], seq[f+1], seq[c-1]);
	      /*Exclude the i-j stacking energy here, just in case i-j 
	      don't pair */
	    
	    
	      tempMin =
		energy + Fg[ gap_index( c, d,e,f, seqlength)];
	      
	      FgIx[ partial_index + size*len1_len2] =
		MIN( tempMin, FgIx[ partial_index + size*len1_len2]); 
	    
	    }
	  }
	}
      } 
    }
  }
 
}


/* ************ for FASTILOOP ************** */

void extendOldFgIx( int i, int j, int d, int e, char seq[], int seqlength, 
		    double Fg[], double FgIx[], double FgIx_2[]) {
  /* Extends all entries of FgIx */


  int L = j - i + 1;
  int size;
  extern double *sizeTerm; //precomputed
  
  //These following variables are to minimze calls to QgIxIndex;
  int partial_index, partial_index2;  
  int len_12 = (L-2)*(L-3)/2;
  int len10 = L*(L-1)/2;

  partial_index2 = QgIxIndex( j-i+2, i-1, 0, d, e, seqlength);
  partial_index = QgIxIndex( j-i, i, 0, d, e, seqlength);
  
  for( size = 8; size <= L - 9; size++) {
    FgIx_2[ partial_index2 + (size+2)*len10] = 
      FgIx[ partial_index + size*len_12] +
      sizeTerm[ size];    
  }
}


/* ************************************ */
  
void MakeFgls( int i, int j, char seq[], int seqlength, double Fg[], 
	       double Fm[],  double Fgls[]) {
  int c, d, e;
  int pf_ic1;
  double bp_penalty = 0;
  double tempMin;
  int gap_idej;

  for( c = i + 5; c <= j-6; c++) {
    if( CanPair( seq[c], seq[j]) == TRUE 
	 && Base2int( seq[c]) + Base2int( seq[j]) == 5 
	) {

      bp_penalty = 0.0;
      if( seq[c] != 'C' && seq[j] != 'C') {
	bp_penalty = AT_PENALTY;
      }

      pf_ic1 = pf_index( i, c-1, seqlength);
      for( d = c+1; d <= j-5; d++) {
	
	for( e = d+4; e <= j-1; e++) {
	  if( CanPair( seq[d], seq[e]) == TRUE) { 

	    // The d-e bp_penalty already counted in MakeQgl
	    gap_idej = gap_index( i, d, e, j, seqlength);

	    tempMin =
	      Fm[ pf_ic1] +
	      Fg[ gap_index(c, d, e, j, seqlength)] +
	      (ALPHA_2 + bp_penalty);

	    Fgls[ gap_idej] = 
	      MIN( tempMin, Fgls[ gap_idej]);
 
	  }
	}
      }
    }
  }
}
/* ************************** */
void MakeFgrs( int i, int j, char seq[], int seqlength, double Fg[], 
	       double Fm[], double Fgrs[]) {

  int d, e, f;
  int gap_idej;
  double bp_penalty = 0;
  double tempMin;
   
  for( d = i + 1; d <= j-10; d++) {
    for( e = d+4; e <= j-6; e++) {
      if( CanPair( seq[d], seq[e]) == TRUE ) {
	gap_idej = gap_index(i,d,e,j,seqlength);
	for( f = e+1; f <= j-5; f++) {
	  if( CanPair( seq[i], seq[f]) == TRUE &&
	      Base2int( seq[i]) + Base2int( seq[f]) == 5 
	      ) {
	
	    bp_penalty = 0;
	    if( seq[i] != 'C' && seq[f] != 'C') {
	      bp_penalty = AT_PENALTY;
	    }

	    tempMin = 
	      Fm[ pf_index( f+1, j, seqlength)] + 
	      Fg[ gap_index( i, d, e, f, seqlength)] +
	      (ALPHA_2 + bp_penalty);
	    Fgrs[ gap_idej] = MIN( tempMin, Fgrs[ gap_idej]);

	  }
	}
      }
    }
  }
}
/* *************************************** */

void MakeFgl( int i, int j, char seq[], int seqlength, 
	      double Fg[], double Fgl[], double Fz[]) {
  //make sure to call this AFTER MakeFg and BEFORE MakeFgr
  
  int d, e, f;
  int gap_idfj, gap_iefj;
  double bp_penalty = 0.0;
  double tempMin;
  
  for( d = i+1; d <= j-5; d++) {
    for( f = d+4; f <= j-1; f++) {
      if( CanPair( seq[d], seq[f]) == TRUE &&
	  Base2int( seq[d]) + Base2int( seq[f]) == 5
	  ) {
	bp_penalty = 0.0;
	if( seq[d] != 'C' && seq[f] != 'C') {
	  bp_penalty = AT_PENALTY;
	}
	
	gap_idfj =  gap_index(i, d, f, j, seqlength);
	for( e = d; e <= f-3; e++) {

	  gap_iefj = gap_index( i, e, f, j, seqlength);
	  tempMin = 
	    Fg[ gap_idfj]+Fz[ pf_index( d+1, e, seqlength)] +
	    (BETA_2 + bp_penalty);
	  Fgl[ gap_iefj ] =
	    MIN( tempMin, Fgl[ gap_iefj]);
	}
      }
    }
  }
}

/* ******************************** */

void MakeFgr( int i, int j, char seq[], int seqlength, 
	      double Fgr[], double Fgl[], double Fz[]) {
  
  //make sure to call this AFTER MakeQg and AFTER MakeQgl
  
  int d, e, f;
  int gap_idej;
  double tempMin;

  for( d = i+1; d <= j-4; d++) {
    for( e = d+3; e <= j-1; e++) {
      gap_idej =  gap_index(i, d, e, j, seqlength);
      for( f = e; f <= j-1; f++) {
	tempMin =
	  Fgl[ gap_index(i,d,f,j,seqlength)]+
	  Fz[ pf_index( e, f-1, seqlength)];
	Fgr[ gap_idej] = MIN( tempMin, Fgr[ gap_idej]);

      }
    }
  }  
}

#endif //O_N5
/* ********************************** */

#ifdef O_N8
double MinFp_N8( int i, int j, char seq[], int seqlength, 
		 double Fg[], double Fz[]) {

  // Add all pseudoknots with ends i, j.
  // No penalty for non-AT, terminal basepairs need to be added for the
  // i and j pairs because they are included elsewhere.  However,
  // non-AT penalty is calculated here for the two "interior" pairs.


  int a, d, c, f, e, b; // 4 pairs: i-e, a-d, b-j, c-f
  double bp_penalty = 0.0;
  double min_energy = NAD_INFINITY;
  double tempMin;

  if( j - i < 8) {// not enough room for pk
    return NAD_INFINITY;
  }
  for( a = i + 1; a <= j - 7; a++) {
    for( b = a+1; b <= j - 6; b++) {
      if( CanPair( seq[ b], seq[ j]) == TRUE	  
	  && Base2int( seq[b]) + Base2int( seq[j]) == 5) {
	for( c = b + 1; c <= j - 5; c++) {
	  for( d = MAX(c+1,a+4); d <= j - 3; d++) {
	    if( CanPair( seq[ a], seq[ d]) == TRUE
		&& Base2int( seq[a]) + Base2int( seq[d]) == 5) {
	      for( e = d+1; e <= j - 2; e++) {
		if( CanPair( seq[ i], seq[ e]) == TRUE
		    && Base2int( seq[i]) + Base2int( seq[e]) == 5) {
		  for( f = MAX(e+1,c+4); f <= j-1; f++) {
		    if( CanPair( seq[c], seq[f]) == TRUE
			&& Base2int( seq[c]) + Base2int( seq[f]) == 5) {
		      
		      bp_penalty = 0.0;
		      if( seq[a] != 'C' && seq[d] != 'C') {
			bp_penalty += AT_PENALTY;
		      }
		      if( seq[c] != 'C' && seq[f] != 'C') {
			bp_penalty += AT_PENALTY;
		      }
		      if( seq[i] != 'C' && seq[e] != 'C') {
			bp_penalty += AT_PENALTY;
		      }
		      if( seq[b] != 'C' && seq[j] != 'C') {
			bp_penalty += AT_PENALTY;
		      }

		      tempMin = 
			Fg[ gap_index( i, a, d, e, seqlength) ] +
			Fg[ gap_index( b, c, f, j, seqlength) ] +
			(bp_penalty + 2*BETA_2) +
			Fz[ pf_index( e + 1, f - 1, seqlength)]+
			Fz[ pf_index( c + 1, d - 1, seqlength)]+
			Fz[ pf_index( a + 1, b - 1, seqlength)];
		      min_energy = MIN( tempMin, min_energy);

		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    }
  }

  return min_energy;
}
#endif //O_N8

/* *************************************** */
#ifdef O_N5

double MinFp_N5( int i, int j, char seq[], int seqlength, 
		    double Fgl[], double Fgr[]) {
  
  int d, e, f;
  double bp_penalty, new_bp_penalty;
  double min_energy = NAD_INFINITY;
  double tempMin;

  if( j - i < 8) {// not enough room for pk
    return NAD_INFINITY;
  }
  for( d = i + 2; d <= j-4; d++) {
    if( CanPair( seq[d], seq[j]) == TRUE &&
	Base2int( seq[d]) + Base2int( seq[j]) == 5
	) {
      bp_penalty = 0;
      if( seq[d] != 'C' && seq[j] != 'C') {
	bp_penalty = AT_PENALTY;
      }

      for( e = MAX(d+2, i+5); e <= j-3; e++) {
	for( f = e+1; f <= j-2; f++) {
	  
	  if( CanPair( seq[i], seq[f]) == TRUE &&
	      Base2int( seq[i]) + Base2int( seq[f]) == 5
	      ) {
	    new_bp_penalty = bp_penalty;
	    if( seq[i] != 'C' && seq[f] != 'C') {
	      new_bp_penalty += AT_PENALTY;
	    }
	  
	    tempMin = Fgl[ gap_index(i, d-1, e, f, seqlength)] +
	      Fgr[ gap_index(d, e-1, f+1, j, seqlength)] +
	      (new_bp_penalty);
	    min_energy = MIN( tempMin, min_energy);

	  }
	}
      }
    }
  }

  return min_energy;
}


#endif //O_N5

/* ***************************** */

#ifdef PKNOTS
void MakeF_Fm_Fz( int i, int j, char seq[], int seqlength,
		  double F[], double Fm[], double Fz[],
		  double Fb[], double Fp[]) {
  
  int d, e; // d - e is internal basepair or pk boundary
  double bp_penalty;
  int pf_ij = pf_index(i, j, seqlength);
  int pf_de;
  double tempMin;

  F[ pf_ij] = DangleEnergy(i, j, seq, seqlength);  //Empty Graph

  
  if( i != 0 && j != seqlength - 1) { 
    Fz[ pf_ij] = DangleEnergy(i, j, seq, seqlength) +
      BETA_3*(j-i+1);
  }  

  for( d = i; d <= j - 4; d++) {
    for( e = d + 4; e <= j; e++) {
      if( CanPair( seq[d], seq[e]) == TRUE &&
	  Base2int( seq[d]) + Base2int( seq[e]) == 5 ) {
	bp_penalty = 0;
	if( seq[d] != 'C' && seq[e] != 'C') {
	  bp_penalty = AT_PENALTY;
	}

	pf_de = pf_index( d, e, seqlength);

	tempMin= F[ pf_index(i, d-1, seqlength)] +
	  Fb[ pf_de ] +
	  bp_penalty +
	  DangleEnergy( e+1, j, seq, seqlength); 
	F[ pf_ij] = MIN( F[ pf_ij], tempMin);

	if( i != 0 && j != seqlength - 1) {

	  
	  tempMin =
	    (ALPHA_2 + ALPHA_3*(d-i + j-e) + bp_penalty) +
	    Fb[ pf_de] +
	    DangleEnergy( e+1, j, seq, seqlength) +
	    DangleEnergy( i, d-1, seq, seqlength);
	  Fm[ pf_ij] = MIN( Fm[ pf_ij], tempMin);
	  
	  
	  if( d >= i+5) {
	    tempMin = Fm[ pf_index(i, d-1, seqlength)] +
	      Fb[ pf_de] +
	      (ALPHA_2 + ALPHA_3*(j-e) + bp_penalty) +
	      DangleEnergy( e+1, j, seq, seqlength);
	    Fm[ pf_ij] = MIN( Fm[ pf_ij], tempMin);
	  }
	  
	  
	  tempMin = Fz[ pf_index(i, d-1, seqlength)] + 
	    Fb[ pf_de] + (BETA_2 + BETA_3*(j-e) + bp_penalty) +
	    DangleEnergy( e+1, j, seq, seqlength);
	  Fz[ pf_ij] = MIN( Fz[ pf_ij], tempMin);
	}
	
      }
      
    }
  }

  for( d = i; d <= j - 8; d++) {
    for( e = d + 8; e <= j; e++) {
      
      pf_de = pf_index( d, e, seqlength);
      
      tempMin = F[ pf_index(i, d-1, seqlength)] +
	Fp[ pf_de ] +
	BETA_1 +
	DangleEnergy( e+1, j, seq, seqlength); 
      F[ pf_ij] = MIN( tempMin, F[pf_ij]);

      if( i != 0 && j != seqlength - 1) {
      
	tempMin =
	  (BETA_1M + 2*ALPHA_2 + ALPHA_3*(d-i + j-e)) +
	  Fp[ pf_de] +
	  DangleEnergy( e+1, j, seq, seqlength) +
	  DangleEnergy( i, d-1, seq, seqlength);
	Fm[ pf_ij] = MIN( Fm[ pf_ij], tempMin);
	   
	if( d >= i+5) {
	  tempMin = Fm[ pf_index(i, d-1, seqlength)] +
	    Fp[ pf_de] + (BETA_1M + 2*ALPHA_2 + ALPHA_3*(j-e)) +
	    DangleEnergy( e+1, j, seq, seqlength);
	  Fm[ pf_ij] = MIN( tempMin, Fm[ pf_ij]);
	}
      
	tempMin = Fz[ pf_index(i, d-1, seqlength)] +
	  Fp[ pf_de] + (BETA_1P + 2*BETA_2 + BETA_3*(j-e)) +
	  DangleEnergy( e+1, j, seq, seqlength) ;	
	Fz[ pf_ij] = MIN( tempMin, Fz[ pf_ij]);
      }
    }    
  }
}


#endif


