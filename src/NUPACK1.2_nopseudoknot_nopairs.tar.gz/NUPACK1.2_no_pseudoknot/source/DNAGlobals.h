/*
The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     
*/


double loop37[90];
int tloops[6*4096];//has tetra loop sequences+cp, (6 ints per tetra loop)
double tloop_energy[ 4096]; //energies of tetraloops
int triloops[5*1024]; //triloops equences + closing pairs
double triloop_energy[ 1024]; //number of triloops
//Mismatch energies  (see functions.h)
double MMEnergiesHP[6*16];
double MMEnergiesIL[256];
double IL_SInt2[16*36]; //Symmetric Interior Loops, size 2
double IL_SInt4[256*36]; // Symmetric Interior Loops, size 4
double IL_AsInt1x2[64*36]; // Asymmetric Interior Loop, size 3
double dangle_energy[48]; // Dangle Energies
double asymmetry_penalty[4]; // Asymmetric loop penalties
double max_asymmetry;
long int maxGapIndex;
double Stack[36];
double *sizeTerm;
double *pairPr;

double AT_PENALTY;
double POLYC3;
double POLYCSLOPE;
double POLYCINT;
double ALPHA_1; //multiloop penalties
double ALPHA_2;
double ALPHA_3;
double BETA_1; //pseudoknot penalties
double BETA_2;
double BETA_3;
double BETA_1M;
double BETA_1P;

