/* utils.c by Robert Dirks 07/24/2001

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     

   Utility functions for PFunc.c
*/

#ifndef CONSTANTS_H
#include"constants.h"
#endif


#ifndef FUNCTIONS_H
#include"functions.h"
#endif


#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<memory.h>

//#include "DNAExternals.h"
/* ********************************************** */
//Added 08/21/2001

int gap_index( int h, int r, int m, int s, int seqlength) {
  // index variable should actually be h..h1..m1..m, but i will use
  // the above indices for simplicity. 
  

  int n = seqlength;
  long int index;
  
  long int h2 = h*h;
  long int h3 = h2*h;
  long int h4 = h3*h;
  long int m2 = m*m;
  long int n2= n*n;
  long int n3 = n2*n;
  long int r2 = r*r;
  long int r3 = r2*r;

  extern long int maxGapIndex;
  
  if( h >= r || r >= m || m >= s || s >= seqlength) {
    printf("Illegal call to Gap_index! %d, %d, %d, %d\n", h, r, m, s);
    exit(0);
  }
  
  // the following indexing formula imitates 4 nested for loops
  
  index = (-24 - 50*h - 35*h2 - 10*h3 - h4 - 36*m -12*m2 +
	   12*n + 70*h*n + 30*h2*n + 4*h3*n + 24*m*n - 12*n2 -30*h*n2 -
	   6*h2*n2 + 4*h*n3 + 44*r - 48*n*r + 12*n2*r + 
	   24*r2 - 12*n*r2 +
	   4*r3 + 24*s)/24 ;

  if( index >= maxGapIndex) {
    printf("Gap Index too large! %ld %ld %d %d %d %d %d\n", 
	   index, maxGapIndex,
	   h,r,m,s,n);
    exit(0);
  }

  return index;
}

/* ******************************************** */
int Equal( double x, double y) {
  // Check if two real numbers are "equal"
  double absdiff;
  
  // debugging only (is energy < mfe?)
  if( x - y < -0.001) {
    printf( "Error: %f < %f\n", x, y);
    exit(0);
  }
  
  if( x - y >= 0.0) {
    absdiff = x-y;
  }
  else {
    absdiff = y-x;
  }
  if( absdiff < 0.0001) {
    return TRUE;
  }
  else {
    return FALSE;
  }
}


/* ******************************************** */
int pf_index( int i, int j, int N) {
  /* Calculate index for partition function array 
   N = sequence length */

  if( j == i - 1) {
    return N*(N+1)/2 + i;
  }

  if( i < 0 || j > N - 1 || j < i) {
    printf("Illegal partition function index!\n i = %d, j = %d, ind = %d\n",
	   i, j, N*(N+1)/2 - (N - i)*( N - i + 1)/2 + (j - i));
    exit(0);
  }

  return N*(N+1)/2 - (N - i)*( N - i + 1)/2 + (j - i);
  //return (N+1-i)*(N-i)/ 2 + N+1-j;
} 

/* **************************************** */

#ifdef O_N5
int QgIxIndex( int d, int i, int size, int h1, int m1, int N) {

  int index;
  int d1d2 = (d-1)*(d-2);
  int d5 = d-5;
  int h1_i_1 = h1-i-1;

  if( i < 0 || d < 0 || i + d > N-1 || size > d-6 || h1 <= i ||
      m1 >= i+d) {
    printf("Error in QgIxIndex %d %d %d %d %d %d\n", 
	   d, i, size, h1, m1, N);
    exit(0);
  }

  index = i*d5*d1d2/2 + size*d1d2/2 + 
    h1_i_1*(d-1) - h1_i_1*(h1 - i)/2 + m1 - h1 - 1;

  if( index >= (N-d)*d5*(d1d2/2) ) {
    printf( "%d >= %d\n", index, (N-d)*(d-5)*(d1d2/2) );
    exit(0);
  }

  return index;

}
#endif //O_N5

/* **************************************************** */



int Base2int( char base) {
  /* Convert A, C, G, T, U to 1,2,3,4 respectively */
  if( base == 'A') {
    return 1;
  }
  else if ( base == 'C') {
    return 2;
  }
  else if (base == 'G') {
    return 3;
  }
  else if (base == 'T' || base =='U') {
    return 4;
  }
  else {
    printf("Error in Converting base %c!\n", base);
    exit(0);
    return NAD_INFINITY; // never returns this
  }
}

/* *********************************************************** */ 
int GetMismatchShift( char base1, char base2) {
  /* base1 and base2 are basepaired. the returned value is needed to 
     index energy arrays
  */
  int shift;

  if( base1 == 'A') { /* this is for retrieving 
			    proper mismatch energy */
    shift = 0;
  }
  else if( base1 == 'C') {
    shift = 1;
  }
  else if( base1 == 'G' && base2 == 'C') {
    shift = 2;
  }
  else if( base1 == 'G' && (base2 == 'T'|| base2 == 'U') ) {
    shift = 4;
  }
  else if( (base1 == 'T'|| base1 == 'U') && base2 == 'A') {
    shift = 3;
  }
  else if( (base1 == 'T'|| base1 == 'U') && base2 == 'G') {
    shift = 5;
  }
  else {
    printf("Error in GetMismatchShift. %c and %c don't pair!\n", 
	   base1, base2);
    exit(0);
  }
  return shift;
}

/* ************************************************** */
int GetPairType( char b) { //assume pair of b is the watson crick pair
  int shift;

  if( b == 'A') { 
    shift = 0;
  }
  else if( b == 'C') {
    shift = 1;
  }
  else if( b == 'G') {
    shift = 2;
  }
  else if( b == 'T'|| b == 'U') {
    shift = 3;
  }
  else {
    printf("Error in GetPairType!\n");
    exit(0);
  }
  return shift;
}

/* *************************************************** */

int CanPair( char i, char j) {
  // Can base i and j form a watson crick or wobble base pair?

  if( Base2int( i) + Base2int( j) == 5
#ifndef NOGU
      ||
      Base2int( i) + Base2int( j) == 7
#endif
      ) {
    return TRUE;
  }
  else {
    return FALSE;
  }
}

/* **************************************************** */
#ifdef O_N5
void CheckPossiblePairs( short **possiblePairs, int seqlength, char seq[]) {
  int i, j, b;
  int outerPair;
  *possiblePairs = (short *) calloc( seqlength*(seqlength+1)/2, 
				     sizeof( short));

  if( *possiblePairs == NULL) {
    printf("Error in calloc for possiblePairs!\n");
  }

  for( i = 0; i < seqlength - 4; i++) {
    for( j = i+4; j < seqlength; j++) {
      if( (*possiblePairs)[ pf_index(i, j, seqlength)] == 0) {
	outerPair = -1;
	for( b = 0; b <= MIN( i, seqlength - 1 - j); b++) {
	  if( CanPair( seq[i-b], seq[j+b]) == TRUE  
	      //&& Base2int( seq[i-b]) + Base2int(seq[j+b]) == 5 
	      ) {
	    outerPair = b;
	  }
	}
	for( b = 0; b <= MIN( i, seqlength - 1 - j); b++) {
	  if( b <= outerPair) {
	    (*possiblePairs)[ pf_index(i-b, j+b, seqlength)] = TRUE;
	  }
	  else {
	    (*possiblePairs)[ pf_index(i-b, j+b, seqlength)] = -1;
	  }
	}
      }
    }
  }
}
#endif //O_N5
/* ******************************************** */

#ifdef O_N3

int fbixIndex( int d, int i, int size, int N ) {
 
  if( d < 0 || i < 0 || i + d >= N) {
    printf( "Error in fbixIndex %d %d %d %d\n", d, i, size, N);
  }
  if( i*(d-1) + size > (N-d)*(d-1) ) {
    printf(  "Error in fbixIndex! %d > %d, %d %d %d %d,\n", i*(d-1) + size,
             (N-1-d)*(d-1), d,i,size,N);
  }

  return i*(d-1) + size;
}

#endif







