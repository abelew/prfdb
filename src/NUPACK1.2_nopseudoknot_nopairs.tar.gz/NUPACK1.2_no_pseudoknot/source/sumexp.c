/* sumexp.c by Robert Dirks 07/24/2001

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     

This file contains the functions that calculate the sum of exponentials
in order to calculate a given partition function matrix. 

See functions.h for more specific descriptions of each function.
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#ifndef CONSTANTS_H
#include"constants.h"
#endif

#ifndef FUNCTIONS_H
#include"functions.h"
#endif

#include "DNAExternals.h"
/* *********************************************** */
/* Functions in Qb recursion */
#ifdef O_N3
double SumExpMultiBp_N3( int i, int j, char seq[], 
			 double Qms[], double Qm[], int seqlength){
// Decomposes the region inside pair i,j into multiloops, i.e.
// and excludes the possibility of "top level" pseudoknots

  double sum_exp = 0.0;
  double bp_penalty = 0.0;

  int d; // d is the left base of a rightmost paired base between i, j.
  
  if( Base2int( seq[i]) + Base2int( seq[j]) == 5) {
    for( d = i+6; d <= j - 5; d++) {
      //reset loop parameters
      bp_penalty = 0.0;
      
      if( seq[i] != 'C'  && seq[j] != 'C') {
	bp_penalty += AT_PENALTY;
      }
      
      sum_exp += Qm[ pf_index( i+1, d-1, seqlength)] *
	Qms[ pf_index(d, j-1, seqlength)] *
	exp( -( ALPHA_1 + ALPHA_2 + bp_penalty) / (R_GAS*TEMP_K) );
    }
  }

  return sum_exp;  
}

/* ***************************************** */
void fastILoops( int i, int j, int L, int seqlength, char seq[],  
		 double Qb[], double Qx[], double Qx_2[]) {
  
  int size;
  int pf_ij = pf_index( i, j, seqlength);

  if( L >= 15) {
    makeNewQx( i, j, seq, seqlength, Qb, Qx);
  }

  //Use extensible cases              
  if( CanPair( seq[ i], seq[j]) == TRUE) {
    for( size = 8; size <= L - 7; size++) {
      Qb[ pf_ij] += 
	Qx[ fbixIndex( j-i, i, size, seqlength)] * 
	exp( -InteriorMM( seq[i], seq[j], seq[i+1], 
			  seq[j-1])/(R_GAS*TEMP_K));
    }
  }
  
  if( L >= 15 && i != 0 && j != seqlength -1) {
    extendOldQx( i, j, seq, seqlength, Qb, Qx,
		 Qx_2);
  }
  
  /* Add in inextensible cases */  
  if( CanPair( seq[ i], seq[j]) == TRUE) {
    //first check inextensible cases
    Qb[ pf_ij] += 
      SumExpInextensibleIL( i,j, seq, seqlength, Qb);    
  } 

}


/* ******************************************************* */
/* Qs, Qms  Recursion */

void MakeQs_Qms( int i, int j, char seq[], int seqlength, 
		 double Qs[], double Qms[], double Qb[]) {
  /* Calculate the min values for the F_noPk matrix (no pseudoknots)
     Assume that j+1 is paired, unless j == seqlength - 1
  */  

  int d; //rightmost base pair is i,d
  double bp_penalty = 0.0;
  int pf_ij = pf_index( i, j, seqlength);

  for( d = i+4; d <= j; d++) {
    bp_penalty = 0.0;
    
    if( CanPair( seq[i], seq[ d]) == TRUE &&
	Base2int( seq[i]) + Base2int( seq[d]) == 5) {
      if( seq[i] != 'C' && seq[d] != 'C') {
	bp_penalty = AT_PENALTY;
      }
		
      Qs[ pf_ij] += Qb[ pf_index( i, d, seqlength) ] * 
	ExpDangle( d+1, j, seq, seqlength) *
	exp( -(bp_penalty)/(R_GAS*TEMP_K) );           
      Qms[ pf_ij] += Qb[ pf_index( i, d, seqlength) ] * 
	ExpDangle( d+1, j, seq, seqlength) * 
	exp( -(bp_penalty + ALPHA_2 + ALPHA_3*(j-d))/(R_GAS*TEMP_K) );        
      
    }
  }
}


/* ******************************* */
/* Q, Qm Recursions */
void MakeQ_Qm_N3( int i, int j, char seq[], int seqlength, 
		    double Q[], double Qs[], 
		    double Qms[], double Qm[]) {

  int d;//left base of rightmost base pair.
  int pf_ij = pf_index( i, j, seqlength);

  Q[ pf_ij] = //replace this with "ExpDangle"?
    ExpDangle(i, j, seq, seqlength);  //Empty Graph

  for( d = i; d <= j - 4; d++) {
    Q[ pf_ij] += Q[ pf_index(i, d-1, seqlength)] *
      Qs[ pf_index( d, j, seqlength)];
    
    
    Qm[ pf_ij] += Qms[ pf_index( d, j, seqlength)] *
      ExpDangle( i, d-1, seq, seqlength) *
      exp( -(ALPHA_3)*(d-i)/(R_GAS*TEMP_K)); //Single Pair

    
    if( d >= i+5) { //else Qm(i, d-1) = 0;
      Qm[ pf_ij]+= Qm[ pf_index( i, d - 1, seqlength) ] *
	Qms[ pf_index( d, j, seqlength) ];
    }
    
    
  }
}
#endif //O_N3

/* ******************************************* */

/* Functions in Q recursion */
// must be calculated after Qb, Qpk of same length

#ifdef O_N3
void makeNewQx( int i, int j, char seq[], int seqlength, 
		    double Qb[], double Qx[]) {

  /*Determine the new entries of Qx(i,j,size) that are not extended 
    versions of Qx(i+1, j-1, size-2) */
  
  extern double loop37[];
  extern double asymmetry_penalty[];
  extern double max_asymmetry;

  double energy;
  int d, e; //Internal pair.(d, e will be restricted to special cases)
  
  int size, L1, L2; //size parameters: L1 + L2 = size, L1 = h-i-1, L2 = j-m-1
  int asymmetry;
  int asymmetry_index;

  //Add in all the cases that are not an extended version of an
  //extensible case.

  //Case 1:  L1 = 4, L2 >= 4;
  L1 = 4;
  d = i + L1 + 1;
  for( L2 = 4; L2 <= j - d - 5; L2++) {
    size = L1 + L2;
    e = j - L2 - 1;
    
    if( CanPair( seq[d], seq[e]) == TRUE) {
      asymmetry = abs( L1 - L2);
      //Loop Size Energy
      if( size <= 30) {
	energy = loop37[ size - 1];
      }
      else {
	energy = loop37[ 30 - 1];
	energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
      }
      
      //Asymmetry rountine copied from efn.f in Zuker's mfold package.
      asymmetry_index = 4;
      
      if( asymmetry*asymmetry_penalty[ asymmetry_index - 1] < max_asymmetry ) {
	energy += asymmetry*asymmetry_penalty[ asymmetry_index - 1];
      }
      else {
	energy += max_asymmetry; // MAX asymmetry penalty
      }
      
      energy += InteriorMM( seq[e], seq[d], seq[e+1], seq[d-1]);
      /*Exclude the i-j stacking energy here, just in case i-j 
	don't pair */
  
      Qx[ fbixIndex( j-i, i, size, seqlength) ] += 
	exp(-energy/(R_GAS*TEMP_K))*Qb[ pf_index(d, e, seqlength)];

    }
  }
	
  //Case 2  L1 > 4, L2 = 4
  L2 = 4;
  e = j - L2 -1;
  for( L1 = 5; L1 <= e-i-5; L1++) {   
    size = L1 + L2;
    d = i + L1 + 1;
    
    if( CanPair( seq[d], seq[e]) == TRUE) {
      asymmetry = abs( L1 - L2);
      //Loop Size Energy
      if( size <= 30) {
	energy = loop37[ size - 1];
      }
      else {
	energy = loop37[ 30 - 1];
	energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
      }
      
      
      //Asymmetry rountine copied from efn.f in Zuker's mfold package.
      asymmetry_index = 4;
      
      if( asymmetry*asymmetry_penalty[ asymmetry_index - 1] < max_asymmetry ) {
	energy += asymmetry*asymmetry_penalty[ asymmetry_index - 1];
      }
      else {
	energy += max_asymmetry; // MAX asymmetry penalty
      }
      energy += InteriorMM( seq[e], seq[d], seq[e+1], seq[d-1]);
      /*Exclude the i-j stacking energy here, just in case i-j 
	don't pair */
      
      
      Qx[ fbixIndex( j-i, i, size, seqlength)] +=
	exp(-energy/(R_GAS*TEMP_K))*Qb[ pf_index(d, e, seqlength)];
      
    }
  }
    
}

/* ************************** */

void extendOldQx( int i, int j, char seq[], int seqlength, 
		    double Qb[], double Qx[], double Qx_2[]) {
  /* Extends all entries of Qx */

  extern double loop37[];
  int size;
  double oldSizeEnergy;
  double newSizeEnergy;

  for( size = 8; size <= (j - i + 1) - 7; size++) {
    if( size <= 30) {
      oldSizeEnergy = loop37[ size - 1];
    }
    else {
      oldSizeEnergy = loop37[ 30 - 1];
      oldSizeEnergy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
    }
    if( size + 2 <= 30) {
      newSizeEnergy = loop37[ size+2 - 1];
    }
    else {
      newSizeEnergy = loop37[ 30 - 1];
      newSizeEnergy += 1.75*R_GAS*TEMP_K*log( (size+2)/30.0); 
    }
    
    Qx_2[ fbixIndex( j-i+2, i-1, size+2, seqlength)] = 
      Qx[ fbixIndex( j-i, i, size, seqlength)] * 
      exp( -(newSizeEnergy - oldSizeEnergy)/(R_GAS*TEMP_K));
  }
}


/* ************************ */


double SumExpInextensibleIL( int i, int j, char seq[], int seqlength, 
			     double Qb[]) {
  /* This finds the minimum energy IL that has a special energy 
     calculation, i.e. small loops, bulge loops or GAIL case */

  double energy;
  int d, e; //Internal pair.(h, m will be restricted to special cases)  
  int L1, L2; //size parameters: L1 + L2 = size, L1 = h-i-1, L2 = j-m-1

  double sumexp = 0;
 
  /* Consider "small" loops with special energy functions */
  
  for( L1 = 0; L1 <= 3; L1++) {
    d = i + L1 + 1;
    for( L2 = 0; L2 <= MIN( 3, j-d-5); L2++) {
      e = j - L2 - 1;
   
      if( CanPair( seq[d], seq[e]) == TRUE) {
	
	energy = InteriorEnergy( i, j, d, e, seq);
	
	sumexp += exp( -energy/(R_GAS*TEMP_K)) *
	  Qb[ pf_index( d, e, seqlength)];
      }
    }
  }

  /* Next consider large bulges or large asymmetric loops */
  // Case 2a  L1 = 0,1,2,3, L2 >= 4;
  for( L1 = 0; L1 <= 3; L1++) {
    d = i + L1 + 1;
    for( L2 = 4; L2 <= j - d - 5; L2++) {
      e = j - L2 - 1;
      
      if( CanPair( seq[d], seq[e]) == TRUE) { 
	
	energy = InteriorEnergy( i, j, d, e, seq);	
	sumexp += exp( -energy/(R_GAS*TEMP_K)) *
	  Qb[ pf_index( d, e, seqlength)]; 
      }
    }
  }

  // Case 2b L1 >= 4, L2 = 0,1,2,3;
  for( L2 = 0; L2 <= 3; L2++) {
    e = j - L2 - 1;
    for( L1 = 4;  L1 <= e - i - 5; L1++) {
      d = i + L1 + 1;
   
      if( CanPair( seq[d], seq[e]) == TRUE) { 

	energy = InteriorEnergy( i, j, d, e, seq);
	sumexp += exp( -energy/(R_GAS*TEMP_K)) *
	  Qb[ pf_index( d, e, seqlength)];
     
      }
    }
  }    

  return sumexp;
}
#endif //O_N3  
/* ******************** */


#if defined (O_N4) || defined (PKNOTS)

double SumExpQb( int i, int j, char seq[], int seqlength, 
		 double Qm[], double Qb[] ){
// This finds all possible internal loops (no pseudoknots)
// closed on the "outside" by bases i and j, as well as all 
// multiloops


  double sum_exp = 0.0;
  int d, e; // d - e is internal basepair 
  double bp_penalty = 0;


  for( d = i+1; d <= j - 5; d++) {
    for( e = d + 4; e <= j - 1; e++) {
      if( CanPair( seq[d], seq[e]) == TRUE) {
	bp_penalty = 0.0;
			
	sum_exp += ExpInternal( i, j, d, e, seq)*
	  Qb[ pf_index( d, e, seqlength) ];
	
	if( seq[d] != 'C' && seq[e] != 'C') {
	  bp_penalty = AT_PENALTY;
	}
	if( seq[i] != 'C' && seq[j] != 'C') {
	  bp_penalty += AT_PENALTY;
	}
	
	if( d>= i+6 && Base2int( seq[d]) + Base2int( seq[e]) == 5 &&
	    Base2int( seq[i]) + Base2int( seq[j]) == 5) {
	  sum_exp += Qm[ pf_index(i+1, d-1, seqlength)] *
	    Qb[ pf_index( d, e, seqlength)] *
	    exp( -(ALPHA_1 + 2*ALPHA_2 + ALPHA_3*(j-e-1) + bp_penalty)/
		 (R_GAS*TEMP_K) )*
	    ExpDangle( e+1, j-1, seq, seqlength);
	}
      }
    }
    
  }

  return sum_exp;
}
/* *********************************************** */

void MakeQ_Qm_N4( int i, int j, char seq[], int seqlength, 
		      double Q[], double Qm[], double Qb[] ){

  int d, e; // d - e is internal basepair 
  double bp_penalty = 0;
  int pf_ij = pf_index(i, j, seqlength);

  Q[ pf_ij] = ExpDangle(i, j, seq, seqlength);  //Empty Graph

  for( d = i; d <= j - 4; d++) {
    for( e = d + 4; e <= j; e++) {
      if( CanPair( seq[d], seq[e]) == TRUE &&
	  Base2int( seq[d]) + Base2int( seq[e]) == 5 ) {
	bp_penalty = 0;
	if( seq[d] != 'C' && seq[e] != 'C') {
	  bp_penalty = AT_PENALTY;
	}

	Q[ pf_ij] += Q[ pf_index(i, d-1, seqlength)] *
	  Qb[ pf_index( d, e, seqlength) ] *
	  exp( -bp_penalty/(R_GAS*TEMP_K) ) *
	  ExpDangle( e+1, j, seq, seqlength); 

	
	Qm[ pf_ij] +=
	  exp( -(ALPHA_2 + ALPHA_3*(d-i + j-e) + bp_penalty)/
	       (R_GAS*TEMP_K) )*
	  Qb[ pf_index( d, e, seqlength)] *
	  ExpDangle( e+1, j, seq, seqlength) *
	  ExpDangle( i, d-1, seq, seqlength);

	
	if( d >= i+5) {
	  Qm[ pf_ij] += Qm[ pf_index(i, d-1, seqlength)] *
	    Qb[ pf_index( d, e, seqlength)] *
	    exp( -(ALPHA_2 + ALPHA_3*(j-e) + bp_penalty)/
		 (R_GAS*TEMP_K) )*
	    ExpDangle( e+1, j, seq, seqlength);
	}
	
      }
      
    }
  }


}
#endif //O_N4 || PKNOTS
