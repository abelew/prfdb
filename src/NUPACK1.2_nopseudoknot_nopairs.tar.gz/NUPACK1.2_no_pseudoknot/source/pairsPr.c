/*  pairsPr.c by Robert Dirks 08/04/2002

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     

Implementation of the base pairing probability matrix (McCaskill, 1990)

Originally, just for non-pseudoknotted case, but I have added the pseudoknot
version as well.  The pseudoknot pair probabilities algorithm is in the 
process of being prepared for publication.

*/


#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>

#ifndef CONSTANTS_H
#include"constants.h"
#endif

#ifndef FUNCTIONS_H
#include"functions.h"
#endif

#include "DNAExternals.h"

#ifdef PAIRPR
/* ************************ */
#ifdef O_N4
void calculatePairsN4( double Q[], double Qb[], double Qm[],
		       double Pb[], int seqlength,
		       char seq[]) {
  
  int L, i, j, a, b;
  int isWobble;
  double rowsum;
  int pf_ij;
  double prob; //probability
  FILE *fp;

  // Fill in pairsPrMatrix[start, stop]
  for( L = seqlength; L >= 1; L--) {
    /* Pb for [h,m] requires precalculation of pairsPrMatrix[i,j]
       for all (i,j) with i < h and j > l */
    for( i = 0; i <= seqlength - L; i++) {
      j = i + L - 1;

      isWobble = FALSE;
      if( Base2int( seq[i]) + Base2int( seq[j]) == 7) {
	isWobble = TRUE;
      }
      pf_ij = pf_index( i, j, seqlength);

      if( CanPair( seq[i], seq[j]) == TRUE && L>=5) { 
	/*  Consider i-j as a "top-level" pair, i.e. no pair contains it */ 

	prob = 0;
	if( isWobble == FALSE) {
	  prob = 
	    Q[ pf_index( 0, i - 1, seqlength)]*
	    Qb[ pf_ij]*
	    Q[ pf_index( j+1, seqlength - 1, seqlength)]/
	    Q[ pf_index( 0, seqlength -1, seqlength)];
	}
	
	if( seq[i] != 'C'  && seq[j] != 'C') { 
	  //Add AT termination penalty
	  prob *= 
	    exp( -AT_PENALTY/(R_GAS*TEMP_K) );
	}
	Pb[ pf_ij] = prob;
	
	// Next consider i-j as inner pair in an Interior Loop/BULGE
	for( a = 0; a <= i-1; a++) {
	  for( b = j+1; b <= seqlength-1; b++) {
	    if( CanPair( seq[a], seq[b]) == TRUE) {
	      prob =
		Pb[pf_index( a, b, seqlength)]*
		/* The following can be interpreted as the probability
		 i-j is in an interior loop, given an a-b pair */
		Qb[ pf_ij]/
		Qb[ pf_index( a, b, seqlength)]*
		ExpInternal( a, b, i, j, seq);
	      Pb[pf_ij] += prob;
	    }
	  }
	}
	if( Pb[ pf_ij] > 1) {
	  printf( "! %d %d %f\n", i, j, Pb[ pf_ij] );
	}

	if( isWobble == FALSE) {
	  // Next consider i-j as an inner pair in a multiloop
	  // Case 1:  Rightmost pair
	  prob = 0;
	  for( a = 0; a <= i - 6; a++) {
	    for( b = j+1; b <= seqlength-1; b++) {
	      if( CanPair( seq[a], seq[b]) == TRUE &&
		  Base2int( seq[a]) + Base2int( seq[b]) == 5) {
		
		prob +=
		  Pb[pf_index( a, b, seqlength)]*
		  /* The following can be interpreted as the probability 
		     i-j is rightmost pair in a multiloop, 
		     given an a-b closing pair */
		  rightmostInMulti( a, b, i,j, Qb, Qm, seq, 
				    seqlength)/
		  Qb[ pf_index( a, b, seqlength)];
	      }
	    }
	  }
	  Pb[ pf_ij] += prob;
	  
	  // Case 2:  Not Rightmost, Not Leftmost pair. Defined as "middle"
	  prob = 0;
	  for( a = 0; a <= i - 6; a++) {
	    for( b = j+6; b <= seqlength-1; b++) {
	      if( CanPair( seq[a], seq[b]) == TRUE &&
		  Base2int( seq[a]) + Base2int( seq[b]) == 5) {
		prob +=
		  Pb[pf_index( a, b, seqlength)]*
		  /* The following can be interpreted as the probability 
		     i-j is a "middle" pair in a multiloop, 
		     given an a-b closing pair */
		  middleInMulti( a, b, i, j, Qb, Qm, seq, seqlength)/
		  Qb[ pf_index( a, b, seqlength)];
	      }
	    }
	  }
	  Pb[ pf_ij] += prob;
	  
	  // Case 3:  Leftmost pair.
	  prob = 0;
	  for( a = 0; a <= i-1; a++) {
	    for( b = j+6; b <= seqlength-1; b++) {
	      if( CanPair( seq[a], seq[b]) == TRUE &&
		  Base2int( seq[a]) + Base2int( seq[b]) == 5 ) {
		prob +=
		  Pb[pf_index( a, b, seqlength)]*
		  /* The following can be interpreted as the probability 
		     start-stop is a leftmost pair in a multiloop, 
		     given an i-j closing pair */
		  leftmostInMulti( a,b, i,j, Qb, Qm, 
				   seq, seqlength)/
		  Qb[ pf_index( a, b, seqlength)];
	      }
	    }
	  }
	  Pb[ pf_ij] += prob;
	  //Done with multiloop possibility
	}

      }
    }
  }

  fp = fopen( "Pb_N4.txt", "w");

  for( i = 0; i <= seqlength - 1; i++) {
    for( j = 0; j <= seqlength - 1; j++) {      
      if ( i < j) {
	pf_ij = pf_index(i,j, seqlength);
	if( prob > 1) {
	  printf("Error!!! %d %d %f\n", i, j, 
		 Pb[ pf_ij]);
	}
	fprintf( fp, "%d %d %.6f %.6f %.6f\n", i+1, j+1,
		 Pb[ pf_ij], Pb[ pf_ij], 0 );
      }
      else {
	fprintf( fp, "%d %d %.6f %.6f %.6f\n", i+1, j+1,
		 Pb[ pf_index( j, i, seqlength)],
		 Pb[ pf_index( j, i, seqlength)], 
		 0.0);
      }
    }
  } 
 
  fclose( fp);
  
  
  //check rowsums:

  for( i = 0; i <= seqlength - 1; i++) {
    rowsum = 0;
    for ( j = 0; j <= seqlength - 1; j++) {
      if( i <= j) {
	rowsum += Pb[  pf_index(i, j, seqlength)];
      }
      else {
	rowsum += Pb[  pf_index(j, i, seqlength)];
      }
    }    
    //printf( "rs: %d %f\n", i, rowsum);
    if( rowsum > 1) {
      printf("Error!!!!\n");
      exit(0);
    }
  }
//  printf("Row sums < 1\n");

  
}

#endif
/* ****************************************** */
double rightmostInMulti( int a, int b, int i, int j, double Qb[],
			 double Qm[], char seq[], int seqlength) {
  /*
    assume a-b is the closing pair of a multiloop with i-j as the
    rightmost pair.  
  */

  //Based on SumExpMultiBp code

  double sum_exp = 0.0;
  double bp_penalty = 0.0;
  double dangle;

  if( seq[a] != 'C'  && seq[b] != 'C') {
    bp_penalty += AT_PENALTY;
  }
  
  if( CanPair( seq[i], seq[j]) == TRUE 
      && (Base2int( seq[i]) + Base2int( seq[j]) == 5) 
      ) {
    
    
    if( seq[i] != 'C'  && seq[j] != 'C') {
      bp_penalty += AT_PENALTY;
    }
    
    dangle = DangleEnergy( j+1, b-1, seq, seqlength);

    sum_exp = Qm[ pf_index( a+1, i-1, seqlength)] *  
      Qb[ pf_index(i, j, seqlength)] * 
      exp( -( ALPHA_1 + 2*ALPHA_2 + bp_penalty + 
	      dangle +(b - j - 1)*ALPHA_3) / (R_GAS*TEMP_K) );
    //2*ALPHA_2 comes from fact that 2 pairs are counted in this step
  }
  
  return sum_exp;  
}
/* **************************************** */


double middleInMulti( int a, int b, int i, int j, double Qb[],
		      double Qm[], char seq[], int seqlength) {
 
  /* The dangle energies are taken care of by the Qm terms!
     as is the term for unpaired bases */
  double sum_exp = 0.0;
  double bp_penalty = 0.0;


  bp_penalty = 0.0;
  
  if( seq[a] != 'C'  && seq[b] != 'C') {
    bp_penalty += AT_PENALTY;
  }
  
  if( CanPair( seq[i], seq[j]) == TRUE 
      && (Base2int( seq[i]) + Base2int( seq[j]) == 5)
      ) {

    if( seq[i] != 'C'  && seq[j] != 'C') {
      bp_penalty += AT_PENALTY;
    }
        
    sum_exp = Qm[ pf_index( a+1, i-1, seqlength)] *
      Qb[ pf_index(i, j, seqlength)] * 
      Qm[ pf_index(j+1, b-1, seqlength)]*
      exp( -( ALPHA_1 + 2*ALPHA_2 + bp_penalty) / (R_GAS*TEMP_K) );
    //2*ALPHA_2 comes from fact that 2 pairs are counted in this step

  }
  
  return sum_exp;  
}

/* ***************************** */
double leftmostInMulti( int a, int b, int i, int j, double Qb[],
			double Qm[], char seq[], int seqlength) {
 
  double sum_exp = 0.0;
  double bp_penalty = 0.0;
  double dangle;
 
  bp_penalty = 0.0;
  
  if( seq[a] != 'C'  && seq[b] != 'C') {
    bp_penalty += AT_PENALTY;
  }
  
  if( CanPair( seq[i], seq[j]) == TRUE 
      && (Base2int( seq[i]) + Base2int( seq[j]) == 5)
      ) {
    if( seq[i] != 'C'  && seq[j] != 'C') {
      bp_penalty += AT_PENALTY;
    }

    dangle = DangleEnergy( a+1, i-1, seq, seqlength);

    sum_exp = Qb[ pf_index(i, j, seqlength)] * 
      Qm[ pf_index(j+1, b-1, seqlength)]*
      exp( -( ALPHA_1 + 2*ALPHA_2 + bp_penalty + dangle +
	      (i - a - 1)*ALPHA_3 ) / (R_GAS*TEMP_K) );
    //2*ALPHA_2 comes from fact that 2 pairs are counted in this step

  }
 
  return sum_exp;  
}

/* *************************************** */
#ifdef O_N8

void calculatePairsN8( double Q[], double Qb[], double Qm[],
		       double Qp[], double Qz[], double Qg[],
		       double P[], 
		       double Pb[], double Pp[], double Pz[], 
		       double Pg[], double Pbg[],
		       double Pm[],
		       int seqlength,
		       char seq[]) {
  
  int L, i, j, d, e;
  double rowsum;
  int pf_ij, gap_idej;
  double prob; //probability
  FILE *fp;

  for( L = seqlength; L >= 1; L--) {
    for( i = 0; i <= seqlength - L; i++) {
      j = i + L - 1;
      pf_ij = pf_index(i, j, seqlength);

      MakeP_Pm_Pz( i, j, seq, seqlength,
		   Q, Qm, Qz, Qb, Qp, P, Pm, Pz, Pb, Pp);
      //requires Pp( i,j) is set.

      
      if( L >= 9) {
	PseudoknotLoop( i, j, pf_ij, Qg, Qz, Qp, Pp, Pz, Pg, Pbg, seq,
			seqlength);
      }

      
      //require Qg
      MakePg_N8( i, j, seq, seqlength, Qg, Qm, 
		     Pg, Pm);
            

      //require Pb
      MakePb_N5(  i, j, seq, seqlength, Qm, Qb, Qp, Pm, Pb, Pp);
    
      //Calculate Pbg
      if( CanPair( seq[i], seq[j]) == TRUE && L >= 7) { 

	for( d = i+1; d<= j-5; d++) {
	  for( e = d+4; e <= j-1; e++) {
	    if(  CanPair( seq[d], seq[e]) == TRUE) {
	      gap_idej = gap_index(i,d,e,j,seqlength);	      
	      Pbg[ pf_ij] += Pg[ gap_idej];

	    }
	  }
	}
      }


    }
  }

  fp = fopen( "Pb_N8.txt", "w");
  for( i = 0; i <= seqlength - 1; i++) {
    for( j = 0; j <= seqlength - 1; j++) {      
      if ( i < j) {
	pf_ij = pf_index(i,j, seqlength);
      
	prob = Pb[ pf_ij] + 
	  Pbg[ pf_ij];
	if( prob > 1) {
	  printf("Error!!! %d %d %f %f\n", i, j, 
		 Pb[ pf_ij], Pbg[ pf_ij]);
	}
	fprintf( fp, "%d %d %.6f %.6f %.6f\n", i+1, j+1, 
		 prob, Pb[ pf_ij],Pbg[ pf_ij]);
	
      }
      else {
	fprintf( fp, "%d %d %.6f %.6f %.6f\n", i+1, j+1, 
		 Pb[ pf_index( j, i, seqlength)] + 
		 Pbg[ pf_index( j, i, seqlength)],
		 Pb[ pf_index( j, i, seqlength)], 
		 Pbg[ pf_index( j, i, seqlength)]);
      }
    }
  } 
  fclose( fp);
  
  //check rowsums:
  for( i = 0; i <= seqlength - 1; i++) {
    rowsum = 0;
    for ( j = 0; j <= seqlength - 1; j++) {
      if( i <= j) {
	rowsum += Pb[  pf_index(i, j, seqlength)] + 
	  Pbg[ pf_index(i,j,seqlength)];
      }
      else {
	rowsum += Pb[  pf_index(j, i, seqlength)] + 
	  Pbg[ pf_index(j,i,seqlength)];
      }
    }    
    //printf( "rs: %d %f\n", i, rowsum);
    if( rowsum > 1) {
      printf("Error!!!!\n");
      exit(0);
    }
  }
  //  printf("Row sums < 1\n");

}

/* *********************************************** */


void PseudoknotLoop( int i, int j, int pf_ij, 
		     double Qg[], double Qz[], double Qp[], 
		     double Pp[], double Pz[], double Pg[], double Pbg[],
		     char seq[], int seqlength) {

  int a,b,c,d,e,f;
  double bp_penalty;
  double prob;

  for( a = i + 1; a <= j - 7; a++) {
    for( b = a+1; b <= j - 6; b++) {
      if( CanPair( seq[ b], seq[ j]) == TRUE	  
	  && Base2int( seq[b]) + Base2int( seq[j]) == 5) {
	for( c = b + 1; c <= j - 5; c++) {
	  for( d = MAX(c+1,a+4); d <= j - 3; d++) {
	    if( CanPair( seq[ a], seq[ d]) == TRUE
		&& Base2int( seq[a]) + Base2int( seq[d]) == 5) {
	      for( e = d+1; e <= j - 2; e++) {
		if( CanPair( seq[ i], seq[ e]) == TRUE
		    && Base2int( seq[i]) + Base2int( seq[e]) == 5) {
		  for( f = MAX(e+1,c+4); f <= j-1; f++) {
		    if( CanPair( seq[c], seq[f]) == TRUE
			&& Base2int( seq[c]) + Base2int( seq[f]) == 5) {
		      
		      bp_penalty = 0.0;
		      if( seq[a] != 'C' && seq[d] != 'C') {
			bp_penalty += AT_PENALTY;
		      }
		      if( seq[c] != 'C' && seq[f] != 'C') {
			bp_penalty += AT_PENALTY;
		      }
		      if( seq[i] != 'C' && seq[e] != 'C') {
			bp_penalty += AT_PENALTY;
		      }
		      if( seq[b] != 'C' && seq[j] != 'C') {
			bp_penalty += AT_PENALTY;
		      }
		      
		      prob = Pp[ pf_ij] * 
			Qg[ gap_index( i, a, d, e, seqlength) ] *
			Qg[ gap_index( b, c, f, j, seqlength) ] *
			exp( -(bp_penalty + 2*BETA_2)/
			     (R_GAS*TEMP_K) ) * 
			Qz[ pf_index( e + 1, f - 1, seqlength)]*
			Qz[ pf_index( c + 1, d - 1, seqlength)]*
			Qz[ pf_index( a + 1, b - 1, seqlength)]/
			Qp[ pf_ij];
		      
		      Pz[ pf_index( a+1,b-1,seqlength)] += prob;
		      Pz[ pf_index( c+1,d-1,seqlength)] += prob;
		      Pz[ pf_index( e+1,f-1,seqlength)] += prob;
		      Pg[ gap_index(i,a,d,e,seqlength)] += prob;
		      Pg[ gap_index(b,c,f,j,seqlength)] += prob;
		      Pbg[ pf_index(a, d, seqlength)] += prob;
		      Pbg[ pf_index(c, f, seqlength)] += prob;
		      
		      if( prob > 1) {
			printf("%d %d %d %d %d %d %d %d pk prob = %f\n", 
			       i,a,b,c,d,e,f,j,prob);
			exit(0);
		      }
		      
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    }
  }
}
#endif //O_N8
/* ******************************************** */
#ifdef O_N3
void calculatePairsN3( double Q[], double Qb[], double Qm[], double Qms[],
		       double Qs[], double **Qx, 
		       double **Qx_1, double **Qx_2,   
		       double P[], double Pb[], double Pm[], double Pms[], 
		       double Ps[], int seqlength,
		       char seq[]) {
  
  int L, i, j, d;
  double rowsum;
  int pf_ij, pf_id1, pf_dj, pf_id, pf_i1d1, pf_dj1;
  double pr; //probability
  double bp_penalty;
  FILE *fp;
  double *Px, *Px_1, *Px_2;
  Px = Px_1 = Px_2 = NULL;

  P[ pf_index(0, seqlength-1, seqlength)] = 1;
  for( L = seqlength; L >= 1; L--) {

    prManageQx( Qx, Qx_1, Qx_2, &Px, &Px_1, &Px_2, L-1, seqlength); 

    for( i = 0; i <= seqlength - L; i++) {
      j = i + L - 1;
      pf_ij = pf_index(i, j, seqlength);


      //Make P_Pm_N3
      for( d = i; d <= j - 4; d++) {
	pf_id1 = pf_index(i, d-1, seqlength);
	pf_dj = pf_index( d, j, seqlength);

	pr = P[ pf_ij]* Q[ pf_id1] *
	  Qs[ pf_dj ]/Q[pf_ij];
	P[ pf_id1] += pr;
	Ps[ pf_dj] += pr;
	
	pr = Pm[ pf_ij] *Qms[ pf_dj] *
	  ExpDangle( i, d-1, seq, seqlength) *
	  exp( -(ALPHA_3)*(d-i)/(R_GAS*TEMP_K)) / Qm[ pf_ij]; //Single Pair
	Pms[ pf_dj] += pr;
	
	if( d >= i+5) { //else Qm(i, d-1) = 0;
	  pr = Pm[ pf_ij]* Qm[ pf_id1 ] *
	    Qms[ pf_dj ]/Qm[ pf_ij];
	  Pm[ pf_id1] += pr;
	  Pms[ pf_dj] += pr;
	}
      }

      //Calculate Ps_Pms
      for( d = i+4; d <= j; d++) {
	bp_penalty = 0.0;
	
	if( CanPair( seq[i], seq[ d]) == TRUE &&
	    Base2int( seq[i]) + Base2int( seq[d]) == 5) {
	  if( seq[i] != 'C' && seq[d] != 'C') {
	    bp_penalty = AT_PENALTY;
	  }
	  pf_id = pf_index( i,d,seqlength);
	  
	  pr = Ps[ pf_ij] * Qb[ pf_id ] * 
	    ExpDangle( d+1, j, seq, seqlength) *
	    exp( -(bp_penalty)/(R_GAS*TEMP_K) )/ Qs[ pf_ij];
	  Pb[ pf_id] += pr;
	  
	  pr = Pms[ pf_ij]* Qb[ pf_id ] * 
	    ExpDangle( d+1, j, seq, seqlength) * 
	    exp( -(bp_penalty + ALPHA_2 + ALPHA_3*(j-d))/(R_GAS*TEMP_K) )/
	    Qms[ pf_ij];
	  Pb[ pf_id] += pr;

	}
      }
      
      prFastILoops( i, j, L, seqlength, seq, Qb, *Qx, *Qx_2, Pb, Px, Px_1,
		    Px_2);	

      if( CanPair( seq[i], seq[j]) == TRUE) {
		
	//Pb (multiloops)
	if( Base2int( seq[i]) + Base2int( seq[j]) == 5) {
	  for( d = i+6; d <= j - 5; d++) {
	    //reset loop parameters
	    bp_penalty = 0.0;
	    
	    if( seq[i] != 'C'  && seq[j] != 'C') {
	      bp_penalty += AT_PENALTY;
	    }
	    
	    pf_i1d1 = pf_index(i+1,d-1,seqlength);
	    pf_dj1 = pf_index(d,j-1,seqlength);
	    pr = Pb[ pf_ij]* Qm[ pf_i1d1] *
	      Qms[ pf_dj1] *
	      exp( -( ALPHA_1 + ALPHA_2 + bp_penalty) / (R_GAS*TEMP_K) )/
	      Qb[ pf_ij];
	    Pm[ pf_i1d1] += pr;
	    Pms[ pf_dj1] += pr;
	  }
	}
      }    
    }
  }
  
  fp = fopen( "Pb_N3.txt", "w");

  for( i = 0; i <= seqlength - 1; i++) {
    for( j = 0; j <= seqlength - 1; j++) {      
      if ( i < j) {
	pf_ij = pf_index(i,j, seqlength);
	if( Pb[pf_ij] > 1) {
	  printf("Error!!! %d %d %f\n", i, j, 
		 Pb[ pf_ij]);
	}
	fprintf( fp, "%d %d %.6f %.6f %.6f\n", i+1, j+1, 
		 Pb[ pf_ij], Pb[ pf_ij], 0.0 );

      }
      else {
	fprintf( fp, "%d %d %.6f %.6f %.6f\n", i+1, j+1,
		 Pb[ pf_index( j, i, seqlength)],
		 Pb[ pf_index( j, i, seqlength)],
		 0.0);
      }
    }
  } 

  fclose( fp);
  
  
  //check rowsums:

  for( i = 0; i <= seqlength - 1; i++) {
    rowsum = 0;
    for ( j = 0; j <= seqlength - 1; j++) {
      if( i <= j) {
	rowsum += Pb[  pf_index(i, j, seqlength)];
      }
      else {
	rowsum += Pb[  pf_index(j, i, seqlength)];
      }
    }    
    //printf( "rs: %d %f\n", i, rowsum);
    if( rowsum > 1) {
      printf("Error!!!!\n");
      exit(0);
    }
  }

  free( Px_1);
  free( Px_2);
  free( Px);

}

#endif

#if defined(OLD_N3PAIRS) && defined(O_N3)
void calculatePairsN3_OLD( double Q[], double Qb[], double Qm[], double Qms[],
			   double Pb[], double Pm[], double Pms[], 
			   int seqlength, char seq[]) {
  
  int L, i, j, a, b;
  int isWobble;
  double rowsum;
  int pf_ij;
  double prob; //probability
  double IJbp_penalty, bp_penalty;
  FILE *fp;

  // Fill in pairsPrMatrix[start, stop]
  for( L = seqlength; L >= 1; L--) {
    /* Pb for [h,m] requires precalculation of pairsPrMatrix[i,j]
       for all (i,j) with i < h and j > l */
    for( i = 0; i <= seqlength - L; i++) {
      j = i + L - 1;

      isWobble = FALSE;
      if( Base2int( seq[i]) + Base2int( seq[j]) == 7) {
	isWobble = TRUE;
      }
      pf_ij = pf_index( i, j, seqlength);

      if( i != 0 && j != seqlength - 1) {
	//Calculate Pm
	prob = 0;
	//Pm direct from multiloop
	for( a = j+6; a<=seqlength -1; a++) {
	  if( CanPair( seq[i-1], seq[a]) == TRUE && 
	      Base2int( seq[i-1]) + Base2int( seq[a]) == 5) {
	    bp_penalty = 0;
	    if( seq[i-1] != 'C' && seq[a] != 'C') {
	      bp_penalty = AT_PENALTY;
	    }
	    prob += Pb[ pf_index( i-1, a, seqlength)] *
	      Qms[ pf_index( j+1, a-1, seqlength)] *
	      Qm[ pf_ij] *
	      exp( -(ALPHA_1 + ALPHA_2 + bp_penalty)/(R_GAS*TEMP_K) ) /
	      Qb[ pf_index( i-1, a, seqlength)];
	  }
	}
	//Pm from a bigger Qm
	for( a = j+5; a<= seqlength-2; a++) {
	  prob += Pm[ pf_index( i, a, seqlength)] *
	    Qms[ pf_index( j+1, a, seqlength)] *
	    Qm[ pf_ij] /
	    Qm[ pf_index( i, a, seqlength)];
	}
	Pm[ pf_ij] += prob; 
	
	//Calculate Pms (requires Pm first)
	prob = 0;
	//Pms direct from multiloop
	for( a = 0; a <= i-6; a++) {
	  if( CanPair( seq[a], seq[j+1]) == TRUE && 
	      Base2int( seq[a]) + Base2int( seq[j+1]) == 5) {
	    bp_penalty = 0;
	    if( seq[a] != 'C' && seq[j+1] != 'C') {
	      bp_penalty = AT_PENALTY;
	    }
	    prob += Pb[ pf_index( a, j+1, seqlength)] * 
	      Qms[ pf_ij] * 
	      Qm[ pf_index( a+1, i-1, seqlength)] *
	      exp( -(ALPHA_1 + ALPHA_2 + bp_penalty)/(R_GAS*TEMP_K) ) /
	      Qb[ pf_index(a, j+1, seqlength)];
	  }
	}
	//Pms from Qm, requires Pm(i,j) first
	for( a = 1; a <= i; a++) { 
	  prob += Pm[ pf_index( a, j, seqlength)] * 
	    Qms[ pf_ij] * 
	    ( Qm[ pf_index( a, i-1, seqlength)] + 
	      exp( -ALPHA_3*(i-a)/(R_GAS*TEMP_K) )*
	      ExpDangle( a, i-1, seq, seqlength) ) /
	    Qm[ pf_index(a, j, seqlength)];

	}
	Pms[ pf_ij] += prob;
      }

      //Pb calculation.  Requires Pms(i,j) first
      if( CanPair( seq[i], seq[j]) == TRUE && L>=5) { 
	/*  Consider i-j as a "top-level" pair, i.e. no pair contains it */ 

	IJbp_penalty = 0;
	if( seq[i] != 'C'  && seq[j] != 'C') { 
	  IJbp_penalty = AT_PENALTY;
	}

	prob = 0;
	if( isWobble == FALSE) {
	  prob = 
	    Q[ pf_index( 0, i - 1, seqlength)]*
	    Qb[ pf_ij]*
	    exp( -IJbp_penalty/(R_GAS*TEMP_K) ) *
	    Q[ pf_index( j+1, seqlength - 1, seqlength)]/
	    Q[ pf_index( 0, seqlength -1, seqlength)];
	}
	Pb[ pf_ij] += prob;
	
	if( prob > 1) {
	  printf("external %d %d\n",i,j);
	  exit(0);
	}

	//Leave interior pair as O_N4 for now
	// Next consider i-j as inner pair in an Interior Loop/BULGE
	prob = 0;
	for( a = 0; a <= i-1; a++) {
	  for( b = j+1; b <= seqlength-1; b++) {
	    if( CanPair( seq[a], seq[b]) == TRUE) {
	      prob +=
		Pb[pf_index( a, b, seqlength)]*
		/* The following can be interpreted as the probability
		 i-j is in an interior loop, given an a-b pair */
		Qb[ pf_ij]/
		Qb[ pf_index( a, b, seqlength)]*
		ExpInternal( a, b, i, j, seq);
	      
	    
	    }
	  }
	}
	Pb[ pf_ij] += prob;

	if( Pb[ pf_ij] > 1) {
	  printf( "%d %d %f\n", i, j, Pb[ pf_ij] );
	}


	if( isWobble == FALSE && i != 0 && j != seqlength - 1) {
	  // Next consider i-j as an inner pair in a multiloop
	  prob = 0;
	  for( a = j; a <= seqlength-2; a++) {
	    prob +=
	      Pms[pf_index( i, a, seqlength)]*
	      Qb[ pf_ij] * 
	      exp( -(ALPHA_2 + ALPHA_3*(a-j) + IJbp_penalty)/(R_GAS*TEMP_K)) *
	      ExpDangle( j+1, a, seq, seqlength) / 
	      Qms[ pf_index( i,a, seqlength)];

	  }
	  Pb[ pf_ij] += prob;

	}
      }
    }
  }

  fp = fopen( "Pb_N3old.txt", "w");

  for( i = 0; i <= seqlength - 1; i++) {
    for( j = 0; j <= seqlength - 1; j++) {      
      if ( i < j) {
	pf_ij = pf_index(i,j, seqlength);
	if( Pb[ pf_ij] > 1) {
	  printf("Error!!! %d %d %f\n", i, j, 
		 Pb[ pf_ij]);
	}
	fprintf( fp, "%d %d %.6f %.6f %.6f\n", i+1, j+1,
		 Pb[ pf_ij],  Pb[ pf_ij], 0 );
      }
      else {
	fprintf( fp, "%d %d %.6f %.6f %.6f\n", i+1, j+1, 
		 Pb[ pf_index( j, i, seqlength)],
		 Pb[ pf_index( j, i, seqlength)], 0.0);
      }
    }
  } 
 
  fclose( fp);
  
  
  //check rowsums:

  for( i = 0; i <= seqlength - 1; i++) {
    rowsum = 0;
    for ( j = 0; j <= seqlength - 1; j++) {
      if( i <= j) {
	rowsum += Pb[  pf_index(i, j, seqlength)];
      }
      else {
	rowsum += Pb[  pf_index(j, i, seqlength)];
      }
    }    
    //printf( "rs: %d %f\n", i, rowsum);
    if( rowsum > 1) {
      printf("Error!!!!\n");
      exit(0);
    }
  }
  //  printf("Row sums < 1\n");

  
}

#endif //OLD_N3PAIRS

/* ****************************************** */

#if defined(OLD_N5PAIRS) && defined(O_N5)
void calculatePairsN5_old( double Q[], double Qb[], double Qm[],
		       double Qp[], double Qz[], double Qg[],
		       double Qgl[], double Qgr[], double Qgls[],
		       double Qgrs[], double P[], 
		       double Pb[], double Pp[], double Pz[], 
		       double Pg[], double Pbg[],
		       double Pm[], double Pgl[], double Pgr[], 
		       double Pgls[], double Pgrs[],
		       int seqlength,
		       char seq[]) {
  
  int L, i, j, d, e;
  double rowsum;
  int pf_ij, gap_idej;
  double prob; //probability
  FILE *fp;

  for( L = seqlength; L >= 1; L--) {
    for( i = 0; i <= seqlength - L; i++) {
      j = i + L - 1;
      pf_ij = pf_index(i, j, seqlength);

      MakeP_Pm_Pz( i, j, seq, seqlength,
		   Q, Qm, Qz, Qb, Qp, P, Pm, Pz, Pb, Pp);
    
      //requires Pp( i,j) is set.

      if( L >= 9) {
	PseudoknotLoopN5( i, j, pf_ij, Qp, Qgl, Qgr, 
			  Pp, Pgl, Pgr, seq, seqlength);
      }
    
      //requires Pgr(i,j) is set
      MakePgr(i, j, seq, seqlength, Qgr, Qgl, Qz, Pgr, Pgl, Pz);
      //require Pgl set
    
      MakePgl(i, j, seq, seqlength, Qg, Qgl, Qz, Pg, Pgl, Pz, Pbg);
    
      //require Pgrs set
      MakePgrs( i, j, seq, seqlength, Qg, Qm, Qgrs, Pg, Pm, Pgrs);
    
      //require Pgls 
      MakePgls( i, j, seq, seqlength, Qg, Qm, Qgls, Pg, Pm, Pgls);
      
      
      //require Qg
      MakePg_N5_old( i, j, seq, seqlength, Qg, Qm, Qgls, Qgrs, 
		     Pg, Pm, Pgls, Pgrs);
      

      //require Pb
      MakePb_N5(  i, j, seq, seqlength, Qm, Qb, Qp, Pm, Pb, Pp);
    
      //Calculate Pbg
      if( CanPair( seq[i], seq[j]) == TRUE && L >= 7) { 

	for( d = i+1; d<= j-5; d++) {
	  for( e = d+4; e <= j-1; e++) {
	    if(  CanPair( seq[d], seq[e]) == TRUE) {
	      gap_idej = gap_index(i,d,e,j,seqlength);	      
	      Pbg[ pf_ij] += Pg[ gap_idej];

	    }
	  }
	}
      }


    }
  }

  fp = fopen( "Pb_N5old.txt", "w");
  for( i = 0; i <= seqlength - 1; i++) {
    for( j = 0; j <= seqlength - 1; j++) {      
      if ( i < j) {
	pf_ij = pf_index(i,j, seqlength);
	prob = Pb[ pf_ij] + Pbg[ pf_ij];
	if( prob > 1) {
	  printf("Error!!! %d %d %f %f\n", i, j, 
		 Pb[ pf_ij], Pbg[ pf_ij]);
	}
	fprintf( fp, "%d %d %.6f %.6f %.6f\n", i+1, j+1, 
		 prob, Pb[ pf_ij], Pbg[pf_ij] );

      }
      else {
	fprintf( fp, "%d %d %.6f %.6f %.6f\n", i+1, j+1,
		 Pb[ pf_index( j, i, seqlength)] + 
		 Pbg[ pf_index( j, i, seqlength)],
		 Pb[ pf_index( j, i, seqlength)], 
		 Pbg[ pf_index( j, i, seqlength)]
		 );
      }
    }
  } 
  fclose( fp);
  
  //check rowsums:
  for( i = 0; i <= seqlength - 1; i++) {
    rowsum = 0;
    for ( j = 0; j <= seqlength - 1; j++) {
      if( i <= j) {
	rowsum += Pb[  pf_index(i, j, seqlength)] + 
	  Pbg[ pf_index(i,j,seqlength)];
      }
      else {
	rowsum += Pb[  pf_index(j, i, seqlength)] + 
	  Pbg[ pf_index(j,i,seqlength)];
      }
    }    
    //printf( "rs: %d %f\n", i, rowsum);
    if( rowsum > 1) {
      printf("Error!!!!\n");
      exit(0);
    }
  }
  //  printf("Row sums < 1\n");

}
#endif

#if defined(O_N5) && !defined(OLD_N5PAIRS)
void calculatePairsN5( double Q[], double Qb[], double Qm[],
		       double Qp[], double Qz[], double Qg[],
		       double Qgl[], double Qgr[], double Qgls[],
		       double Qgrs[], 
		       double **QgIx, double **QgIx_1, double **QgIx_2,
		       double P[], 
		       double Pb[], double Pp[], double Pz[], 
		       double Pg[], double Pbg[],
		       double Pm[], double Pgl[], double Pgr[], 
		       double Pgls[], double Pgrs[],
		       int seqlength,
		       char seq[]) {
  
  int L, i, j, d, e;
  double rowsum;
  int pf_ij, gap_idej;
  double prob; //probability
  FILE *fp;

  double *PgIx, *PgIx_1, *PgIx_2;
  PgIx = PgIx_1 = PgIx_2 = NULL;

  for( L = seqlength; L >= 1; L--) {
    
    prManageQgIx(  QgIx, QgIx_1, QgIx_2, &PgIx, &PgIx_1, &PgIx_2, L-1, 
		   seqlength); 
    
    for( i = 0; i <= seqlength - L; i++) {

      j = i + L - 1;
      pf_ij = pf_index(i, j, seqlength);

      MakeP_Pm_Pz( i, j, seq, seqlength,
		   Q, Qm, Qz, Qb, Qp, P, Pm, Pz, Pb, Pp);

      //requires Pp( i,j) is set.

      if( L >= 9) {
	PseudoknotLoopN5( i, j, pf_ij, Qp, Qgl, Qgr, 
			  Pp, Pgl, Pgr, seq, seqlength);
      }
    
      //requires Pgr(i,j) is set
      MakePgr(i, j, seq, seqlength, Qgr, Qgl, Qz, Pgr, Pgl, Pz);
      //require Pgl set
    
      MakePgl(i, j, seq, seqlength, Qg, Qgl, Qz, Pg, Pgl, Pz, Pbg);
    
      //require Pgrs set
      MakePgrs( i, j, seq, seqlength, Qg, Qm, Qgrs, Pg, Pm, Pgrs);
    
      //require Pgls 
      MakePgls( i, j, seq, seqlength, Qg, Qm, Qgls, Pg, Pm, Pgls);
      
    
      //require Qg
      MakePg_N5( i, j, seq, seqlength, Qg, Qm, Qgls, Qgrs, *QgIx,
		 *QgIx_2, Pg, Pm, Pgls, Pgrs, PgIx, PgIx_2);

      //require Pb
      MakePb_N5(  i, j, seq, seqlength, Qm, Qb, Qp, Pm, Pb, Pp);
    
      //Calculate Pbg
      if( CanPair( seq[i], seq[j]) == TRUE &&  L >= 7) { 

	for( d = i+1; d<= j-5; d++) {
	  for( e = d+4; e <= j-1; e++) {
	    if(  CanPair( seq[d], seq[e]) == TRUE) {
	      gap_idej = gap_index(i,d,e,j,seqlength);	      
	      Pbg[ pf_ij] += Pg[ gap_idej];
	      /*
	      printf("Pbg %d %d %d %d %f %f\n",i,j,d,e,Pbg[ pf_ij], 
		     Pg[ gap_idej]);
	      */ 
	    }
	  }
	}
      }

      /*
      printf("%d %d b %.10f p %.10f z %.10f\n", i, j, Pb[ pf_ij], Pp[ pf_ij], 
	     Pz[ pf_ij]); 
      */
      /*
      for( d = i+1; d <= j-5; d++) {
	for( e = d+4; e<=j-1;e++) {
	  printf("Pg[%d %d %d %d] = %.10f\n", i,d,e,j,
		 Pg[ gap_index(i,d,e,j,seqlength)]);
	}
	}*/

    }
  }


  fp = fopen( "Pb_N5.txt", "w");
  for( i = 0; i <= seqlength - 1; i++) {
    for( j = 0; j <= seqlength - 1; j++) {
      if ( i < j) {
	pf_ij = pf_index(i,j, seqlength);
	prob = 0;

#ifdef PAIRS_PB_ONLY
	prob += Pb[ pf_ij];
#elif defined(PAIRS_PBG_ONLY) 
	prob += Pbg[ pf_ij];
#else
	prob += Pb[ pf_ij] + Pbg[pf_ij];
#endif

	if( prob > 1) {
	  printf("Error!!! %d %d %f %f\n", i, j, 
		 Pb[ pf_ij], Pbg[ pf_ij]);
	}
	fprintf( fp, "%d %d %.6f %.6f %.6f\n", i+1, j+1, prob,
		 Pb[ pf_ij], Pbg[ pf_ij]);
      }
      else {
#ifdef PAIRS_PB_ONLY
	fprintf( fp, "%.10f\n", Pb[ pf_index( j, i, seqlength)]);
#elif defined(PAIRS_PBG_ONLY)
	fprintf( fp, "%.10f\n", 
		 Pbg[ pf_index( j, i, seqlength)]);
#else
	fprintf( fp, "%d %d %.6f %.6f %.6f\n", i+1, j+1,  
		 Pb[ pf_index( j, i, seqlength)] + 
		 Pbg[ pf_index( j, i, seqlength)],
		 Pb[ pf_index( j, i, seqlength)], 
		 Pbg[ pf_index( j, i, seqlength)]);
#endif
      }
    
    }



  } 
  fclose( fp);
  
  //check rowsums:
  for( i = 0; i <= seqlength - 1; i++) {
    rowsum = 0;
    for ( j = 0; j <= seqlength - 1; j++) {
      if( i <= j) {
	rowsum += Pb[  pf_index(i, j, seqlength)] + 
	  Pbg[ pf_index(i,j,seqlength)];
      }
      else {
	rowsum += Pb[  pf_index(j, i, seqlength)] + 
	  Pbg[ pf_index(j,i,seqlength)];
      }
    }    
    //printf( "rs: %d %f\n", i, rowsum);
    if( rowsum > 1) {
      printf("Error!!!!\n");
      exit(0);
    }
  }
  //  printf("Row sums < 1\n");

  if( PgIx != NULL) free( PgIx);
  if( PgIx_1 != NULL) free( PgIx_1);
  if( PgIx_2 != NULL) free( PgIx_2);

}
#endif

#if defined(O_N5)
/* ******************************************** */

void PseudoknotLoopN5( int i, int j, int pf_ij, 
		       double Qp[], double Qgl[], double Qgr[], 
		       double Pp[], double Pgl[], double Pgr[], 
		       char seq[], int seqlength) {

  int d,e,f;
  double bp_penalty, new_bp_penalty;
  double prob;

  for( d = i + 2; d <= j-4; d++) {
    if( CanPair( seq[d], seq[j]) == TRUE &&
	Base2int( seq[d]) + Base2int( seq[j]) == 5
	) {
      bp_penalty = 0;
      if( seq[d] != 'C' && seq[j] != 'C') {
	bp_penalty = AT_PENALTY;
      }

      for( e = MAX(d+2, i+5); e <= j-3; e++) {
	for( f = e+1; f <= j-2; f++) {
	  
	  if( CanPair( seq[i], seq[f]) == TRUE &&
	      Base2int( seq[i]) + Base2int( seq[f]) == 5
	      ) {
	    new_bp_penalty = bp_penalty;
	    if( seq[i] != 'C' && seq[f] != 'C') {
	      new_bp_penalty += AT_PENALTY;
	    }
	  
	    if( Pp[ pf_ij] > 0) {
	      prob = Pp[ pf_ij]*Qgl[ gap_index(i, d-1, e, f, seqlength)] *
		Qgr[ gap_index(d, e-1, f+1, j, seqlength)] *
		exp( -(new_bp_penalty)/(R_GAS*TEMP_K) ) /
		Qp[ pf_ij];

	      if( prob > 1) {
		printf("a %d %d %f\n", i, j, prob);
	      }
 
	      Pgl[ gap_index(i,d-1,e,f,seqlength)] += prob;
	      Pgr[ gap_index(d,e-1,f+1,j,seqlength)] += prob;
	    }
	  }
	}
      }
    }
  }

}
#endif
/* ******************************************** */
#ifdef PKNOTS
void MakeP_Pm_Pz( int i, int j, char seq[], int seqlength,
		  double Q[], double Qm[], double Qz[],
		  double Qb[], double Qp[], double P[],
		  double Pm[], double Pz[], double Pb[], 
		  double Pp[]) {
  
  int d, e; // d - e is internal basepair or pk boundary
  double bp_penalty;
  int pf_ij = pf_index(i, j, seqlength);
  int pf_de, pf_id1;
  double prob;

  for( d = i; d <= j - 4; d++) {
    pf_id1 = pf_index( i, d-1, seqlength);
    for( e = d + 4; e <= j; e++) {
      pf_de = pf_index( d, e, seqlength);
      if( CanPair( seq[d], seq[e]) == TRUE &&
	  Base2int( seq[d]) + Base2int( seq[e]) == 5 ) {
	bp_penalty = 0;
	if( seq[d] != 'C' && seq[e] != 'C') {
	  bp_penalty = AT_PENALTY;
	}

	if( P[ pf_ij] > 0) {
	  prob = P[ pf_ij]*Q[ pf_id1] *
	    Qb[ pf_de ] *
	    exp( -bp_penalty/(R_GAS*TEMP_K) ) *
	    ExpDangle( e+1, j, seq, seqlength) / Q[ pf_ij];
	  if( prob > 1) {
	    printf("b %d %d %f\n", i, j, prob);
	  }
 
	  P[ pf_id1] += prob;
	  Pb[ pf_de] += prob;
	  
	}

	if( i != 0 && j != seqlength - 1) {
	  if( Pm[ pf_ij] > 0) {
	    prob = Pm[ pf_ij] *
	      exp( -(ALPHA_2 + ALPHA_3*(d-i + j-e) + bp_penalty)/
		   (R_GAS*TEMP_K) )*
	      Qb[ pf_de] *
	      ExpDangle( e+1, j, seq, seqlength) *
	      ExpDangle( i, d-1, seq, seqlength) / Qm[ pf_ij];
	    if( prob > 1) {
	      printf("c %d %d %f\n", i, j, prob);
	    }
 
	    Pb[ pf_de] += prob;
	  }

	  if( d >= i+5) {
	    if( Pm[ pf_ij] > 0) { 
	      prob = Pm[ pf_ij]*Qm[ pf_id1] *
		Qb[ pf_de] *
		exp( -(ALPHA_2 + ALPHA_3*(j-e) + bp_penalty)/
		   (R_GAS*TEMP_K) )*
		ExpDangle( e+1, j, seq, seqlength) / Qm[ pf_ij];
	      Pm[ pf_id1] += prob;
	      Pb[ pf_de] += prob;
	      if( prob > 1) {
		printf("d %d %d %f\n", i, j, prob);
	      }
	    }
	  }
	  
	  if( Pz[ pf_ij] > 0) {
	    prob = Pz[ pf_ij] *Qz[ pf_id1]*
	      Qb[ pf_de] * exp( -(BETA_2 + BETA_3*(j-e) + bp_penalty)/
				(R_GAS*TEMP_K) )*
	      ExpDangle( e+1, j, seq, seqlength)/ Qz[ pf_ij];
	    Pz[ pf_id1] += prob;
	    Pb[ pf_de] += prob;
	    if( prob > 1) {
	      printf("e %d %d %f\n", i, j, prob);
	    }
	    
	  }
	}
	
      }
      
    }
  }

  for( d = i; d <= j - 8; d++) {
    pf_id1 = pf_index( i, d-1, seqlength);
    for( e = d + 8; e <= j; e++) {      
      pf_de = pf_index( d, e, seqlength);
     
      if( P[ pf_ij] > 0) {
	prob = P[ pf_ij] * Q[ pf_id1] *
	  Qp[ pf_de ] *
	  exp( -BETA_1/(R_GAS*TEMP_K) ) *
	  ExpDangle( e+1, j, seq, seqlength) / Q[ pf_ij];
	P[ pf_id1] += prob;
	Pp[ pf_de] += prob;

	if( prob > 1) {
	  printf("f %d %d %f\n", i, j, prob);
	}

      }

      if( i != 0 && j != seqlength - 1) {
	if( Pm[ pf_ij] > 0) {	
	  prob = Pm[ pf_ij] *
	    exp( -(BETA_1M + 2*ALPHA_2 + ALPHA_3*(d-i + j-e))/
		 (R_GAS*TEMP_K) )*
	    Qp[ pf_de] *
	    ExpDangle( e+1, j, seq, seqlength) *
	    ExpDangle( i, d-1, seq, seqlength) / Qm[ pf_ij];
	  Pp[ pf_de] += prob;
	  if( prob > 1) {
	    printf("g %d %d %f\n", i, j, prob);
	  }
	  
	}
	
	if( d >= i+5) {
	  if( Pm[ pf_ij] > 0) {
	    prob = Pm[ pf_ij] * Qm[ pf_id1] *
	      Qp[ pf_de] *
	      exp( -(BETA_1M + 2*ALPHA_2 + ALPHA_3*(j-e))/
		   (R_GAS*TEMP_K) )*
	      ExpDangle( e+1, j, seq, seqlength) / Qm[ pf_ij];
	    Pm[ pf_id1] += prob;
	    Pp[ pf_de] += prob;
	    
	   if( prob > 1) {
	      printf("h %d %d %f\n", i, j, prob);
	   }
	    
	  }
	}
      
	if( Pz[ pf_ij] > 0) {
	  prob = Pz[ pf_ij] *Qz[ pf_id1]*
	    Qp[ pf_de] * exp( -(BETA_1P + 2*BETA_2 + BETA_3*(j-e) )/
			      (R_GAS*TEMP_K) )*
	    ExpDangle( e+1, j, seq, seqlength)/ Qz[ pf_ij];
	  Pz[ pf_id1] += prob;
	  Pp[ pf_de] += prob;

	  if( prob > 1) {
	    printf("i %d %d %f\n", i, j, prob);
	  }
	  
	}
	
      }
    }    
  }
}
#endif
/* ****************************** */
#if defined(O_N5)
void MakePgr( int i, int j, char seq[], int seqlength, 
	      double Qgr[], double Qgl[], double Qz[],
	      double Pgr[], double Pgl[], double Pz[]) {
  
  //make sure to call this BEFORE MakeQg and MakeQgl
  
  int d, e, f;
  int gap_idej, gap_idfj, pf_ef1;
  double prob;

  for( d = i+1; d <= j-4; d++) {
    for( e = d+3; e <= j-1; e++) {
      gap_idej =  gap_index(i, d, e, j, seqlength);
      for( f = e; f <= j-1; f++) {
	gap_idfj = gap_index( i,d,f,j,seqlength);
	pf_ef1 = pf_index( e, f-1,seqlength);

	if( Pgr[ gap_idej] > 0) {
	  prob = Pgr[ gap_idej] *
	    Qgl[ gap_idfj]*
	    Qz[ pf_ef1]/ Qgr[ gap_idej];
	  Pgl[ gap_idfj] += prob;
	  Pz[ pf_ef1] += prob;

	  if( prob > 1) {
	    printf("j %d %d %f\n", i, j, prob);
	  }
	  
	}
      }
    }
  }  
}
/* ********************************** */

void MakePgl( int i, int j, char seq[], int seqlength, 
	      double Qg[], double Qgl[], double Qz[],
	      double Pg[], double Pgl[], double Pz[],
	      double Pbg[]) {
  //make sure to call this BEFORE MakeQg and AFTER MakeQgr
  
  int d, e, f;
  int gap_idfj, gap_iefj, pf_d1e, pf_df;
  double bp_penalty = 0.0;
  double prob;

  for( d = i+1; d <= j-5; d++) {
    for( f = d+4; f <= j-1; f++) {
      if( CanPair( seq[d], seq[f]) == TRUE &&
	  Base2int( seq[d]) + Base2int( seq[f]) == 5
	  ) {
	bp_penalty = 0.0;
	if( seq[d] != 'C' && seq[f] != 'C') {
	  bp_penalty = AT_PENALTY;
	}
	
	pf_df = pf_index(d, f, seqlength);
	gap_idfj =  gap_index(i, d, f, j, seqlength);
	for( e = d; e <= f-3; e++) {
	  gap_iefj = gap_index( i,e,f,j,seqlength);
	  pf_d1e = pf_index( d+1,e,seqlength);

	  if( Pgl[ gap_iefj] > 0) {
	    prob = Pgl[ gap_iefj] *
	      Qg[ gap_idfj]*Qz[ pf_d1e] *
	      exp( -(BETA_2 + bp_penalty)/(R_GAS*TEMP_K) ) /
	      Qgl[ gap_iefj];
	    Pg[ gap_idfj] += prob;
	    Pz[ pf_d1e] += prob;
	    Pbg[ pf_df] += prob;
	    if( prob > 1) {
	      printf("k %d %d %f\n", i, j, prob);
	    }

	    
	  }
	}
      }
    }
  }
}

/* ******************************** */

void MakePgrs( int i, int j, char seq[], int seqlength, double Qg[], 
	       double Qm[], double Qgrs[], double Pg[], double Pm[],
	       double Pgrs[]) {

  int d, e, f;
  int gap_idej, gap_idef, pf_f1j;
  double bp_penalty = 0;
  double prob;

  for( d = i + 1; d <= j-10; d++) {
    for( e = d+4; e <= j-6; e++) {
      if( CanPair( seq[d], seq[e]) == TRUE) {
	gap_idej = gap_index(i,d,e,j,seqlength);
	for( f = e+1; f <= j-5; f++) {
	  if( CanPair( seq[i], seq[f]) == TRUE &&
	      Base2int( seq[i]) + Base2int( seq[f]) == 5 
	      ) {
	
	    bp_penalty = 0;
	    if( seq[i] != 'C' && seq[f] != 'C') {
	      bp_penalty = AT_PENALTY;
	    }
	    pf_f1j = pf_index( f+1, j, seqlength);
	    gap_idef = gap_index( i,d,e,f,seqlength);
	    if( Pgrs[ gap_idej] > 0) {
	      prob = Pgrs[ gap_idej] *
		Qm[ pf_f1j] * 
		Qg[ gap_idef] *
		exp( -(ALPHA_2 + bp_penalty)/(R_GAS*TEMP_K) )/
		Qgrs[ gap_idej];
	      Pm[ pf_f1j] += prob;
	      Pg[ gap_idef] += prob;
	      if( prob > 1) {
		printf("l %d %d %f\n", i, j, prob);
	      }
 
	    }
	  }
	}
      }
    }
  }
}
/* *************************************** */
void MakePgls( int i, int j, char seq[], int seqlength, double Qg[], 
	       double Qm[],  double Qgls[], double Pg[], double Pm[],
	       double Pgls[]) {
  int c, d, e;
  int pf_ic1, gap_idej, gap_cdej;
  double bp_penalty = 0;
  double prob;

  for( c = i + 5; c <= j-6; c++) {
    if( CanPair( seq[c], seq[j]) == TRUE 
	 && Base2int( seq[c]) + Base2int( seq[j]) == 5 
	) {

      bp_penalty = 0.0;
      if( seq[c] != 'C' && seq[j] != 'C') {
	bp_penalty = AT_PENALTY;
      }

      pf_ic1 = pf_index( i, c-1, seqlength);
      for( d = c+1; d <= j-5; d++) {
	
	for( e = d+4; e <= j-1; e++) {
	  if( CanPair( seq[d], seq[e]) == TRUE) { 

	    gap_idej = gap_index( i,d,e,j,seqlength);
	    gap_cdej = gap_index( c,d,e,j, seqlength);

	    if( Pgls[ gap_idej] > 0) {
	      prob =
		Pgls[ gap_idej] *
		Qm[ pf_ic1] *
		Qg[ gap_cdej] *
		exp( -(ALPHA_2 + bp_penalty)/(R_GAS*TEMP_K) )/
		Qgls[ gap_idej];
	      Pm[ pf_ic1] += prob;
	      Pg[ gap_cdej] += prob;

	      if( prob > 1) {
		printf("m %d %d %f\n", i, j, prob);
	      }
 
	    }
	  }
	}
      }
    }
  }
}
/* ************************** */

void MakePg_N5_old( int i, int j, char seq[], int seqlength, double Qg[],
		    double Qm[], double Qgls[], double Qgrs[], 
		    double Pg[], double Pm[], double Pgls[], double Pgrs[]) {
  //  Make the gap matrix for Qg
  int c,d,e,f;
  int gap_idej, gap_cdef, pf_i1d1, pf_e1j1, gap_i1def, gap_cdej1, pf_i1c1;
  double IJ_bp_penalty = 0.0;
  double bp_penalty = 0;
  double prob;


  IJ_bp_penalty = 0.0;
  if( seq[i] != 'C' && seq[j] != 'C') {
    IJ_bp_penalty = AT_PENALTY;
  }
 
  if( CanPair( seq[i], seq[j]) == TRUE) {
   
    //Case 1:  Simple Interior Loop (O_N6)
    for( d = i+2; d <= j-6; d++) {
      for( e = d+4; e <= j-2; e++) {      
	gap_idej = gap_index(i,d,e,j,seqlength);
	if( CanPair( seq[d], seq[e] ) == TRUE ) { 
	  
	  for( c = i+1; c <= d-1; c++) {
	    for( f = e+1; f <= j-1; f++) {
	      if( CanPair( seq[c], seq[f]) == TRUE) {
		
		gap_cdef = gap_index( c,d,e,f,seqlength);
		if( Pg[ gap_idej] > 0) {
		  prob = Pg[ gap_idej] *
		    exp( -InteriorEnergy( i, j, c, f, seq)/(R_GAS*TEMP_K)) * 
		    Qg[ gap_cdef] /
		    Qg[ gap_idej];

		  Pg[ gap_cdef] += prob;
		  
		  
		  if( prob > 1) {
		    printf("n %d %d %f\n", i, j, prob);
		  }
		}
		
	      }
	    }
	  }
	}
      }
    }
  }

  if( CanPair( seq[i], seq[j]) == TRUE && 
      Base2int( seq[i]) + Base2int( seq[j]) == 5) {
    //Case 2:  Multiloop Left
    for( d = i+6; d <= j-5; d++) {
      pf_i1d1 = pf_index(i+1,d-1,seqlength);
      for( e = d+4; e <= j-1; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE 
	    && Base2int( seq[d]) + Base2int( seq[e]) == 5) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }

	  if( Pg[ gap_idej] > 0) {
	    prob = 
	      Pg[ gap_idej] *
	      Qm[ pf_i1d1] *
	      exp( -(ALPHA_1 + 2*ALPHA_2 + 
		     (j-e-1)*ALPHA_3 + bp_penalty)/(R_GAS*TEMP_K)) *
	      ExpDangle( e+1, j-1, seq, seqlength) /
	      Qg[ gap_idej];
	    Pm[ pf_i1d1] += prob;
	    if( prob > 1) {
	      printf("n %d %d %f\n", i, j, prob);
	    }
 
	  }
	}
      }
    }

    //Case 3:  Multiloop Right
    for( d = i+1; d <= j-10; d++) {
      for( e = d+4; e <= j-6; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE
	    && Base2int( seq[d]) + Base2int( seq[e]) == 5 
	    ) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }
	  pf_e1j1 = pf_index( e+1,j-1,seqlength);

	  if( Pg[ gap_idej] > 0) {
	    prob =
	      Pg[ gap_idej] *
	      Qm[ pf_e1j1] *
	      exp( -(ALPHA_1 + 2*ALPHA_2 + 
		     (d-i-1)*ALPHA_3 + bp_penalty)/(R_GAS*TEMP_K)) *
	      ExpDangle( i+1, d-1, seq, seqlength) /
	      Qg[ gap_idej];
	    Pm[ pf_e1j1] += prob;

	    if( prob > 1) {
	      printf("o %d %d %f\n", i, j, prob);
	    }
 
	  }
	}
      }
    }
     
    //Case 4: Multiloop Both Sides
    for( d = i+6; d <= j-10; d++) {
      pf_i1d1 = pf_index( i+1,d-1,seqlength);
      for( e = d+4; e <= j-6; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE
	    && Base2int( seq[d]) + Base2int( seq[e]) == 5
	    ) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }	

	  pf_e1j1 = pf_index( e+1,j-1,seqlength);
	
	  if( Pg[ gap_idej] > 0) {
	    prob =
	      Pg[ gap_idej] *
	      Qm[ pf_i1d1] *
	      Qm[ pf_e1j1] *
	      exp( -(ALPHA_1 + 2*ALPHA_2 + bp_penalty)/(R_GAS*TEMP_K)) /
	      Qg[ gap_idej];
	    Pm[ pf_i1d1] += prob;
	    Pm[ pf_e1j1] += prob;

	    if( prob > 1) {
	      printf("p %d %d %f\n", i, j, prob);
	    }
 
	  }
	}
      }
    }

    //Case 5: Interior loop + multi left
    for( d = i+7; d <= j-6; d++) {
      for( e = d+4; e <= j-2; e++) {      
	gap_idej = gap_index(i,d,e,j,seqlength);
	if( CanPair( seq[d], seq[e] ) == TRUE) {
	  	
	  for( f = e+1; f <= j-1; f++) {
	    bp_penalty = IJ_bp_penalty;
	    
	    gap_i1def = gap_index( i+1,d,e,f,seqlength);
	    if( Pg[ gap_idej] > 0) {
	      prob = 
		Pg[ gap_idej] *
		exp( -(ALPHA_1+ALPHA_2 + (j-f-1)*ALPHA_3+ bp_penalty)/
		     (R_GAS*TEMP_K)) * 
		Qgls[ gap_i1def] *
		ExpDangle( f+1, j-1, seq, seqlength)/
		Qg[ gap_idej];
	      Pgls[ gap_i1def] += prob;
	      if( prob > 1) {
		printf("q %d %d %f\n", i, j, prob);
	      }
	      
	    }
	  }	
	}
      }
    }

    //Case6: Interior loop + multi right
    for( d = i+2; d <= j-11; d++) {
      for( e = d+4; e <= j-7; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE) {
      
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  for( c = i+1; c <= d-1; c++) {
	    bp_penalty = IJ_bp_penalty;

	    gap_cdej1 = gap_index( c,d,e,j-1,seqlength);
	    if( Pg[ gap_idej] > 0) {
	      prob = 
		Pg[ gap_idej] *
		exp( -(ALPHA_1+ALPHA_2 + (c-i-1)*ALPHA_3 + 
		       bp_penalty)/(R_GAS*TEMP_K)) * 
		Qgrs[ gap_cdej1] *
		ExpDangle( i+1, c-1, seq, seqlength)/
		Qg[ gap_idej];
	      Pgrs[ gap_cdej1] += prob;
	      if( prob > 1) {
		printf("r %d %d %f\n", i, j, prob);
	      }
 

	    }	
	  }
	}
      }
    }

    //Case 7: Interior loop + multi both sides
    for( d = i+7; d <= j-11; d++) {
      for( e = d+4; e <= j-7; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE) {
	 
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  for( c = i+6; c <= d-1; c++) {	
	    bp_penalty = IJ_bp_penalty;

	    pf_i1c1 = pf_index( i+1,c-1,seqlength);
	    gap_cdej1 = gap_index( c,d,e,j-1,seqlength);
	    if( Pg[ gap_idej] > 0) {
	      prob =
		Pg[ gap_idej] *
		Qm[ pf_i1c1] *
		exp( -(ALPHA_1+ALPHA_2+bp_penalty)/(R_GAS*TEMP_K)) * 
		Qgrs[ gap_cdej1]/
		Qg[ gap_idej];
	      Pm[ pf_i1c1] += prob;
	      Pgrs[ gap_cdej1] += prob;
	      if( prob > 1) {
		printf("s %d %d %f\n", i, j, prob);
	      }
 
	    }
	  }	
	}
      }
    }

  } // Can Pair

}
/* ******************************************** */

void MakePg_N5( int i, int j, char seq[], int seqlength, double Qg[],
		   double Qm[], double Qgls[], double Qgrs[], double QgIx[],
		   double QgIx_2[],
		   double Pg[], double Pm[], double Pgls[], double Pgrs[],
		   double PgIx[], double PgIx_2[]) {
 
  //  Make the gap matrix for Qg
  int c,d,e,f;
  int gap_idej,  pf_i1d1, pf_e1j1, gap_i1def, gap_cdej1, pf_i1c1;
  double IJ_bp_penalty = 0.0;
  double bp_penalty = 0;
  double prob;

  IJ_bp_penalty = 0.0;
  if( seq[i] != 'C' && seq[j] != 'C') {
    IJ_bp_penalty = AT_PENALTY;
  }


  prFastILoopsN5(i, j, seq, seqlength, Qg, QgIx, QgIx_2, Pg, PgIx, PgIx_2);

  if( CanPair( seq[i], seq[j]) == TRUE && 
      Base2int( seq[i]) + Base2int( seq[j]) == 5) {
    //Case 2:  Multiloop Left
    for( d = i+6; d <= j-5; d++) {
      pf_i1d1 = pf_index(i+1,d-1,seqlength);
      for( e = d+4; e <= j-1; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE 
	    && Base2int( seq[d]) + Base2int( seq[e]) == 5) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }

	  if( Pg[ gap_idej] > 0) {
	    prob = 
	      Pg[ gap_idej] *
	      Qm[ pf_i1d1] *
	      exp( -(ALPHA_1 + 2*ALPHA_2 + 
		     (j-e-1)*ALPHA_3 + bp_penalty)/(R_GAS*TEMP_K)) *
	      ExpDangle( e+1, j-1, seq, seqlength) /
	      Qg[ gap_idej];
	    Pm[ pf_i1d1] += prob;
	    if( prob > 1) {
	      printf("n %d %d %f\n", i, j, prob);
	    }
 
	  }
	}
      }
    }

    //Case 3:  Multiloop Right
    for( d = i+1; d <= j-10; d++) {
      for( e = d+4; e <= j-6; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE
	    && Base2int( seq[d]) + Base2int( seq[e]) == 5 
	    ) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }
	  pf_e1j1 = pf_index( e+1,j-1,seqlength);

	  if( Pg[ gap_idej] > 0) {
	    prob =
	      Pg[ gap_idej] *
	      Qm[ pf_e1j1] *
	      exp( -(ALPHA_1 + 2*ALPHA_2 + 
		     (d-i-1)*ALPHA_3 + bp_penalty)/(R_GAS*TEMP_K)) *
	      ExpDangle( i+1, d-1, seq, seqlength) /
	      Qg[ gap_idej];
	    Pm[ pf_e1j1] += prob;

	    if( prob > 1) {
	      printf("o %d %d %f\n", i, j, prob);
	    }
 
	  }
	}
      }
    }
     
    //Case 4: Multiloop Both Sides
    for( d = i+6; d <= j-10; d++) {
      pf_i1d1 = pf_index( i+1,d-1,seqlength);
      for( e = d+4; e <= j-6; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE
	    && Base2int( seq[d]) + Base2int( seq[e]) == 5
	    ) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }	

	  pf_e1j1 = pf_index( e+1,j-1,seqlength);
	
	  if( Pg[ gap_idej] > 0) {
	    prob =
	      Pg[ gap_idej] *
	      Qm[ pf_i1d1] *
	      Qm[ pf_e1j1] *
	      exp( -(ALPHA_1 + 2*ALPHA_2 + bp_penalty)/(R_GAS*TEMP_K)) /
	      Qg[ gap_idej];
	    Pm[ pf_i1d1] += prob;
	    Pm[ pf_e1j1] += prob;

	    if( prob > 1) {
	      printf("p %d %d %f\n", i, j, prob);
	    }
 
	  }
	}
      }
    }

    //Case 5: Interior loop + multi left
    for( d = i+7; d <= j-6; d++) {
      for( e = d+4; e <= j-2; e++) {      
	gap_idej = gap_index(i,d,e,j,seqlength);
	if( CanPair( seq[d], seq[e] ) == TRUE) {
	  	
	  for( f = e+1; f <= j-1; f++) {
	    bp_penalty = IJ_bp_penalty;
	    
	    gap_i1def = gap_index( i+1,d,e,f,seqlength);
	    if( Pg[ gap_idej] > 0) {
	      prob = 
		Pg[ gap_idej] *
		exp( -(ALPHA_1+ALPHA_2 + (j-f-1)*ALPHA_3+ bp_penalty)/
		     (R_GAS*TEMP_K)) * 
		Qgls[ gap_i1def] *
		ExpDangle( f+1, j-1, seq, seqlength)/
		Qg[ gap_idej];
	      Pgls[ gap_i1def] += prob;
	      if( prob > 1) {
		printf("q %d %d %f\n", i, j, prob);
	      }
	      
	    }
	  }	
	}
      }
    }

    //Case6: Interior loop + multi right
    for( d = i+2; d <= j-11; d++) {
      for( e = d+4; e <= j-7; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE) {
      
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  for( c = i+1; c <= d-1; c++) {
	    bp_penalty = IJ_bp_penalty;

	    gap_cdej1 = gap_index( c,d,e,j-1,seqlength);
	    if( Pg[ gap_idej] > 0) {
	      prob = 
		Pg[ gap_idej] *
		exp( -(ALPHA_1+ALPHA_2 + (c-i-1)*ALPHA_3 + 
		       bp_penalty)/(R_GAS*TEMP_K)) * 
		Qgrs[ gap_cdej1] *
		ExpDangle( i+1, c-1, seq, seqlength)/
		Qg[ gap_idej];
	      Pgrs[ gap_cdej1] += prob;
	      if( prob > 1) {
		printf("r %d %d %f\n", i, j, prob);
	      }
 

	    }	
	  }
	}
      }
    }
   
    //Case 7: Interior loop + multi both sides
    for( d = i+7; d <= j-11; d++) {
      for( e = d+4; e <= j-7; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE) {
	 
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  for( c = i+6; c <= d-1; c++) {	
	    bp_penalty = IJ_bp_penalty;

	    pf_i1c1 = pf_index( i+1,c-1,seqlength);
	    gap_cdej1 = gap_index( c,d,e,j-1,seqlength);
	    if( Pg[ gap_idej] > 0) {
	      prob =
		Pg[ gap_idej] *
		Qm[ pf_i1c1] *
		exp( -(ALPHA_1+ALPHA_2+bp_penalty)/(R_GAS*TEMP_K)) * 
		Qgrs[ gap_cdej1]/
		Qg[ gap_idej];
	      Pm[ pf_i1c1] += prob;
	      Pgrs[ gap_cdej1] += prob;
	      if( prob > 1) {
		printf("s %d %d %f\n", i, j, prob);
	      }
 
	    }
	  }	
	}
      }
    }

  } // Can Pair

}
#endif //O_N5

#ifdef PKNOTS
/* ************************************** */
void MakePb_N5( int i, int j, char seq[], int seqlength, 
		  double Qm[], double Qb[], double Qp[], 
		  double Pm[], double Pb[], double Pp[]){
// This finds all possible internal loops (no pseudoknots)
// closed on the "outside" by bases i and j, as well as all 
// multiloops


  double prob;
  int d, e; // d - e is internal basepair 
  double bp_penalty = 0;
  int pf_ij = pf_index( i,j,seqlength);
  int pf_de, pf_i1d1;

  if( CanPair( seq[i], seq[j]) == TRUE && j-i+1 >= 5) {
    for( d = i+1; d <= j - 5; d++) {
      pf_i1d1 = pf_index( i+1,d-1,seqlength);
      for( e = d + 4; e <= j - 1; e++) {
	pf_de = pf_index( d,e,seqlength);

	if( CanPair( seq[d], seq[e]) == TRUE) {
	  bp_penalty = 0.0;	  	  
	  if( Pb[ pf_ij] > 0) {
	    prob = Pb[ pf_ij]*ExpInternal( i, j, d, e, seq)*
	      Qb[ pf_de ] / Qb[ pf_ij];
	    Pb[ pf_de] += prob;
	    if( prob > 1) {
	      printf("t %d %d %f\n", i, j, prob);
	    }
 
	  }

	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty = AT_PENALTY;
	  }
	  if( seq[i] != 'C' && seq[j] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }

	  if( d>= i+6 && Base2int( seq[d]) + Base2int( seq[e]) == 5 &&
	      Base2int( seq[i]) + Base2int( seq[j]) == 5) {
	    if( Pb[ pf_ij] > 0) {
	      prob = Pb[ pf_ij] * Qm[ pf_i1d1] *
		Qb[ pf_de] *
		exp( -(ALPHA_1 + 2*ALPHA_2 + ALPHA_3*(j-e-1) + bp_penalty)/
		     (R_GAS*TEMP_K) )*
		ExpDangle( e+1, j-1, seq, seqlength)/ Qb[ pf_ij];
	      Pm[ pf_i1d1] += prob;
	      Pb[ pf_de] += prob;
	      if( prob > 1) {
		printf("u %d %d %f\n", i, j, prob);
	      }
 	      
	    }
	  }
	}
	if( Base2int( seq[i]) + Base2int( seq[j]) == 5 && d<=j-9 &&
	    e >= d+8) {

	  bp_penalty = 0;
	  if( seq[i] != 'C' && seq[j] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }

	  if( Pb[ pf_ij] > 0) {
	    
	    prob =
	      Pb[ pf_ij] *
	      exp( -( BETA_1M + ALPHA_1 + 3*ALPHA_2 + 
		      (j-e-1 + d-i-1)*ALPHA_3 + bp_penalty)
		   /(R_GAS*TEMP_K) )*
	      ExpDangle( i+1, d-1, seq, seqlength) *
	      ExpDangle( e+1, j-1, seq, seqlength) *
	      Qp[ pf_de] / Qb[ pf_ij];
	    Pp[ pf_de] += prob;

	    if( prob > 1) {
	      printf("v %d %d %f\n", i, j, prob);
	    }

	    if( d>= i+6) {
	      prob = Pb[ pf_ij] * 
		Qm[ pf_i1d1] * 
		Qp[ pf_de] * 
		exp( -( BETA_1M + ALPHA_1 + 3*ALPHA_2 + bp_penalty + 
			(j - e - 1)*ALPHA_3) / (R_GAS*TEMP_K) ) *
		ExpDangle( e+1, j-1, seq, seqlength)/ Qb[ pf_ij];
	      
	      Pm[ pf_i1d1] += prob;
	      Pp[ pf_de] += prob;
	      
	      if( prob > 1) {
		printf("w %d %d %f\n", i, j, prob);
	      }
	    }
	    
	  }

	}
	  

      }
      
    }
  }

}
/* *********************************************** */
#endif
#ifdef O_N8

void MakePg_N8( int i, int j, char seq[], int seqlength, double Qg[],
		double Qm[], double Pg[], double Pm[]) {
  //  Make the gap matrix for Qg
  int c,d,e,f;
  int gap_idej, gap_cdef, pf_i1d1, pf_e1j1;
  double IJ_bp_penalty = 0.0;
  double bp_penalty = 0;
  double prob;


  IJ_bp_penalty = 0.0;
  if( seq[i] != 'C' && seq[j] != 'C') {
    IJ_bp_penalty = AT_PENALTY;
  }
 
  if( CanPair( seq[i], seq[j]) == TRUE) {
   
    //Case 1:  Simple Interior Loop (O_N6)
    for( d = i+2; d <= j-6; d++) {
      for( e = d+4; e <= j-2; e++) {      
	gap_idej = gap_index(i,d,e,j,seqlength);
	if( CanPair( seq[d], seq[e] ) == TRUE ) { 
	  
	  for( c = i+1; c <= d-1; c++) {
	    for( f = e+1; f <= j-1; f++) {
	      if( CanPair( seq[c], seq[f]) == TRUE) {
		
		gap_cdef = gap_index( c,d,e,f,seqlength);
		if( Pg[ gap_idej] > 0) {
		  prob = Pg[ gap_idej] *
		    exp( -InteriorEnergy( i, j, c, f, seq)/(R_GAS*TEMP_K)) * 
		    Qg[ gap_cdef] /
		    Qg[ gap_idej];

		  Pg[ gap_cdef] += prob;
		  
		  
		  if( prob > 1) {
		    printf("n %d %d %f\n", i, j, prob);
		  }
		}
		
	      }
	    }
	  }
	}
      }
    }
  }

  if( CanPair( seq[i], seq[j]) == TRUE && 
      Base2int( seq[i]) + Base2int( seq[j]) == 5) {
    //Case 2:  Multiloop Left
    for( d = i+6; d <= j-5; d++) {
      pf_i1d1 = pf_index(i+1,d-1,seqlength);

      for( e = d+4; e <= j-1; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE 
	    && Base2int( seq[d]) + Base2int( seq[e]) == 5) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }

	  if( Pg[ gap_idej] > 0) {
	    prob = 
	      Pg[ gap_idej] *
	      Qm[ pf_i1d1] *
	      exp( -(ALPHA_1 + 2*ALPHA_2 + 
		     (j-e-1)*ALPHA_3 + bp_penalty)/(R_GAS*TEMP_K)) *
	      ExpDangle( e+1, j-1, seq, seqlength) /
	      Qg[ gap_idej];
	    Pm[ pf_i1d1] += prob;
	    if( prob > 1) {
	      printf("n %d %d %f\n", i, j, prob);
	    }
 
	  }
	}
      }
    }

    //Case 3:  Multiloop Right
    for( d = i+1; d <= j-10; d++) {
      for( e = d+4; e <= j-6; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE
	    && Base2int( seq[d]) + Base2int( seq[e]) == 5 
	    ) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }
	  pf_e1j1 = pf_index( e+1,j-1,seqlength);

	  if( Pg[ gap_idej] > 0) {
	    prob =
	      Pg[ gap_idej] *
	      Qm[ pf_e1j1] *
	      exp( -(ALPHA_1 + 2*ALPHA_2 + 
		     (d-i-1)*ALPHA_3 + bp_penalty)/(R_GAS*TEMP_K)) *
	      ExpDangle( i+1, d-1, seq, seqlength) /
	      Qg[ gap_idej];
	    Pm[ pf_e1j1] += prob;

	    if( prob > 1) {
	      printf("o %d %d %f\n", i, j, prob);
	    }
 
	  }
	}
      }
    }
     
    //Case 4: Multiloop Both Sides
    for( d = i+6; d <= j-10; d++) {
      pf_i1d1 = pf_index( i+1,d-1,seqlength);
      for( e = d+4; e <= j-6; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE
	    && Base2int( seq[d]) + Base2int( seq[e]) == 5
	    ) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }	

	  pf_e1j1 = pf_index( e+1,j-1,seqlength);
	
	  if( Pg[ gap_idej] > 0) {
	    prob =
	      Pg[ gap_idej] *
	      Qm[ pf_i1d1] *
	      Qm[ pf_e1j1] *
	      exp( -(ALPHA_1 + 2*ALPHA_2 + bp_penalty)/(R_GAS*TEMP_K)) /
	      Qg[ gap_idej];
	    Pm[ pf_i1d1] += prob;
	    Pm[ pf_e1j1] += prob;

	    if( prob > 1) {
	      printf("p %d %d %f\n", i, j, prob);
	    }
 
	  }
	}
      }
    }
  
    //Case 5: Multiloop Left + More Qg
    for( d = i+7; d <= j-6; d++) {
      for( e = d+4; e <= j-2; e++) {      
	gap_idej = gap_index(i,d,e,j,seqlength);
	if( CanPair( seq[d], seq[e] ) == TRUE) { 
	  
	  for( c = i+6; c <= d-1; c++) {
	    for( f = e+1; f <= j-1; f++) {
	      if( CanPair( seq[c], seq[f]) == TRUE &&
		  Base2int( seq[c]) + Base2int( seq[f]) == 5) {
		
		bp_penalty = IJ_bp_penalty;
		if( seq[c] != 'C' && seq[f] != 'C') {
		  bp_penalty += AT_PENALTY;
		}
		
		if( Pg[ gap_idej] > 0) {
		  prob = Pg[ gap_idej]*  
		    Qm[ pf_index( i+1, c-1, seqlength)]*
		    exp( -(ALPHA_1+2*ALPHA_2+(j-f-1)*ALPHA_3 + bp_penalty)
			 /(R_GAS*TEMP_K)) * 
		    Qg[ gap_index( c, d, e, f, seqlength)] *
		    ExpDangle( f+1, j-1, seq, seqlength)/ Qg[gap_idej];
		  Pm[ pf_index( i+1, c-1, seqlength)] += prob;
		  Pg[ gap_index( c, d, e, f, seqlength)] += prob;
		}
		    
	      }
	    }
	  }
	}
	
      }
    }
    //Case 6: Multiloop Right + More Qg
    for( d = i+2; d <= j-11; d++) {
      for( e = d+4; e <= j-7; e++) {      
	gap_idej = gap_index(i,d,e,j,seqlength);
	if( CanPair( seq[d], seq[e] ) == TRUE) { 
	  
	  for( c = i+1; c <= d-1; c++) {
	    for( f = e+1; f <= j-6; f++) {
	      if( CanPair( seq[c], seq[f]) == TRUE &&
		  Base2int( seq[c]) + Base2int( seq[f]) == 5) {
		
		bp_penalty = IJ_bp_penalty;
		if( seq[c] != 'C' && seq[f] != 'C') {
		  bp_penalty += AT_PENALTY;
		} 
		
		if( Pg[ gap_idej] > 0) {
		  prob = Pg[ gap_idej] * 
		    Qm[ pf_index( f+1, j-1, seqlength)]*
		    exp( -(ALPHA_1+2*ALPHA_2+(c-i-1)*ALPHA_3+bp_penalty)
			 /(R_GAS*TEMP_K)) * 
		    Qg[ gap_index( c, d, e, f, seqlength)] *
		    ExpDangle( i+1, c-1, seq, seqlength) /Qg[ gap_idej];
		  Pm[  pf_index( f+1, j-1, seqlength)] += prob;
		  Pg[ gap_index( c, d, e, f, seqlength)] += prob;
		}
		  
	      }
	    }
	  }
	}
      }
    }
    
    
    //Case 7: Multiloop Both sides + More Qg
    for( d = i+7; d <= j-11; d++) {
      for( e = d+4; e <= j-7; e++) {      
	gap_idej = gap_index(i,d,e,j,seqlength);
	if( CanPair( seq[d], seq[e] ) == TRUE) { 
	  
	  for( c = i+6; c <= d-1; c++) {
	    for( f = e+1; f <= j-6; f++) {
	      if( CanPair( seq[c], seq[f]) == TRUE &&
		  Base2int( seq[c]) + Base2int( seq[f]) == 5) {
		
		bp_penalty = IJ_bp_penalty;
		if( seq[c] != 'C' && seq[f] != 'C') {
		  bp_penalty += AT_PENALTY;
		}
		
		if( Pg[ gap_idej] > 0) {
		  prob = Pg[ gap_idej] * 
		    Qm[ pf_index( i+1, c-1, seqlength)]*
		    Qm[ pf_index( f+1, j-1, seqlength)]*
		    exp( -(ALPHA_1+2*ALPHA_2+bp_penalty)
			 /(R_GAS*TEMP_K)) * 
		    Qg[ gap_index( c, d, e, f, seqlength)]/Qg[ gap_idej];
		  Pm[ pf_index( i+1, c-1, seqlength)] += prob;
		  Pm[ pf_index( f+1, j-1, seqlength)] += prob;
		  Pg[ gap_index( c, d, e, f, seqlength)] += prob;
		}

	      }
	    }
	  }
	}
      }
    }
    
  } // Can Pair
}
#endif //O_N8

/* ********************************************* */
#if defined (O_N3)

 
void prFastILoops( int i, int j, int L, int seqlength, char seq[], 
		   double *Qb, double *Qx, double *Qx_2, 
		   double *Pb, double *Px, double *Px_1, double *Px_2) {
  
  int d, e, L1, L2, pf_de;
  int pf_ij = pf_index(i,j,seqlength);
  double pr;
  int size;
  extern double loop37[];
  extern double asymmetry_penalty[];
  extern double max_asymmetry;
  double oldSizeEnergy;
  double newSizeEnergy;
  double energy;
  int asymmetry, asymmetry_index;
  int fbix, fbix2;

  //L1, L2 <= 3 (directly add to Pb)
  if( CanPair( seq[ i], seq[j]) == TRUE) {
    for( L1 = 0; L1 <= 3; L1++) {
      d = i + L1 + 1;
      for( L2 = 0; L2 <= MIN( 3, j-d-5); L2++) {
	e = j - L2 - 1;
	
	if( CanPair( seq[d], seq[e]) == TRUE) {
	  pf_de = pf_index( d, e, seqlength);
	  
	  energy = InteriorEnergy( i, j, d, e, seq);
	  
	  pr = Pb[ pf_ij] * exp( -energy/(R_GAS*TEMP_K)) *
	    Qb[ pf_de] / Qb[ pf_ij];
	  Pb[ pf_de] += pr;

	}
      }
    }

    /* Next consider large bulges or large asymmetric loops */
    // Case 2a  L1 = 0,1,2,3, L2 >= 4;
    for( L1 = 0; L1 <= 3; L1++) {
      d = i + L1 + 1;
      for( L2 = 4; L2 <= j - d - 5; L2++) {
	e = j - L2 - 1;
	
	if( CanPair( seq[d], seq[e]) == TRUE) { 
	  pf_de = pf_index( d,e,seqlength);
	  
	  energy = InteriorEnergy( i, j, d, e, seq);	
	  pr = Pb[ pf_ij] * exp( -energy/(R_GAS*TEMP_K)) *
	    Qb[ pf_de]/ Qb[ pf_ij];
	  Pb[ pf_de] += pr;
	  

	}
      }
    }
    
    // Case 2b L1 >= 4, L2 = 0,1,2,3;
    for( L2 = 0; L2 <= 3; L2++) {
      e = j - L2 - 1;
      for( L1 = 4;  L1 <= e - i - 5; L1++) {
	d = i + L1 + 1;
	
	if( CanPair( seq[d], seq[e]) == TRUE) { 
	  pf_de = pf_index( d,e,seqlength);
	  
	  energy = InteriorEnergy( i, j, d, e, seq);
	  pr = Pb[ pf_ij] * exp( -energy/(R_GAS*TEMP_K)) *
	    Qb[ pf_de]/ Qb[ pf_ij];
	  Pb[ pf_de] += pr;
	  
	  
	}
      }
    }    
  } //end canpair(i,j)


  //Add in special "root" cases ( i == 0 || j == seqlength - 1) to Qx
  if( (i == 0 || j == seqlength - 1) && j >= i+14 && L <= seqlength - 2) {

    for( d = i + 5; d <= j - 9; d++) {
      for( e = d + 4; e <= j - 5; e++) {
	if( CanPair( seq[d], seq[e]) == TRUE) {
	  L1 = d - i - 1;
	  L2 = j - e - 1;
	  size = L1 + L2;

	  pf_de = pf_index( d,e,seqlength);
	  asymmetry = abs( L1 - L2);
	  //Loop Size Energy
	  if( size <= 30) {
	    energy = loop37[ size - 1];
	  }
	  else {
	    energy = loop37[ 30 - 1];
	    energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
	  }
	  
	  //Asymmetry rountine copied from efn.f in Zuker's mfold package.
	  asymmetry_index = 4;
	  
	  if( asymmetry*asymmetry_penalty[ asymmetry_index - 1] < max_asymmetry ) {
	    energy += asymmetry*asymmetry_penalty[ asymmetry_index - 1];
	  }
	  else {
	    energy += max_asymmetry; // MAX asymmetry penalty
	  }
	  
	  energy += InteriorMM( seq[e], seq[d], seq[e+1], seq[d-1]);
	  /*Exclude the i-j stacking energy here, just in case i-j 
	    don't pair */
	  fbix =  fbixIndex( j-i, i, size, seqlength);
	
	  Qx[ fbix ] += 
	    exp(-energy/(R_GAS*TEMP_K))*Qb[ pf_de];

	}
      }
    }
  }//end special cases

  //use Qb to calculate Px
  if( CanPair( seq[ i], seq[j]) == TRUE) {
    for( size = 8; size <= L - 7; size++) {
     
      fbix =  fbixIndex( j-i, i, size, seqlength);
      pr = Pb[ pf_ij] * 
	Qx[ fbix ] * 
	exp( -InteriorMM( seq[i], seq[j], seq[i+1], 
			  seq[j-1])/(R_GAS*TEMP_K))/ Qb[ pf_ij];
      Px[ fbix] += pr;
    }
  }

  //Next calculate Pb using Px and Qx for L1 == 4 || L2 == 4 
  //Case 1:  L1 = 4, L2 >= 4; 
  if( L >= 15) {

    L1 = 4;
    d = i + L1 + 1;
    for( L2 = 4; L2 <= j - d - 5; L2++) {
      size = L1 + L2;
      e = j - L2 - 1;
      fbix =  fbixIndex( j-i, i, size, seqlength);
      
      if( CanPair( seq[d], seq[e]) == TRUE && Px[ fbix] > 0 ) {
	asymmetry = abs( L1 - L2);
	//Loop Size Energy
	if( size <= 30) {
	  energy = loop37[ size - 1];
	}
	else {
	  energy = loop37[ 30 - 1];
	  energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
	}
	
	//Asymmetry rountine copied from efn.f in Zuker's mfold package.
	asymmetry_index = 4;
	
	if( asymmetry*asymmetry_penalty[ asymmetry_index - 1] < max_asymmetry ) {
	  energy += asymmetry*asymmetry_penalty[ asymmetry_index - 1];
	}
	else {
	  energy += max_asymmetry; // MAX asymmetry penalty
	}
	
	energy += InteriorMM( seq[e], seq[d], seq[e+1], seq[d-1]);
	/*Exclude the i-j stacking energy here, just in case i-j 
	  don't pair */
	
	pf_de = pf_index(d,e,seqlength);
	pr = Px[ fbix ] * 
	  exp(-energy/(R_GAS*TEMP_K))*Qb[ pf_de] / Qx[ fbix];  
	Pb[ pf_de] += pr;
	       
	Px[ fbix] -= pr;

	//Recalculate Qx
	Qx[ fbix] -= 
	  exp(-energy/(R_GAS*TEMP_K))*Qb[ pf_de];

      }
    }

    //Case 2  L1 > 4, L2 = 4
    L2 = 4;
    e = j - L2 -1;
    for( L1 = 5; L1 <= e-i-5; L1++) {   
      size = L1 + L2;
      d = i + L1 + 1;
      fbix =  fbixIndex( j-i, i, size, seqlength);
      
      if( CanPair( seq[d], seq[e]) == TRUE && Px[ fbix] > 0) {
	asymmetry = abs( L1 - L2);
	//Loop Size Energy
	if( size <= 30) {
	  energy = loop37[ size - 1];
	}
	else {
	  energy = loop37[ 30 - 1];
	  energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
	}
	
	
	//Asymmetry rountine copied from efn.f in Zuker's mfold package.
	asymmetry_index = 4;
	
	if( asymmetry*asymmetry_penalty[ asymmetry_index - 1] < max_asymmetry ) {
	  energy += asymmetry*asymmetry_penalty[ asymmetry_index - 1];
	}
	else {
	  energy += max_asymmetry; // MAX asymmetry penalty
	}
	energy += InteriorMM( seq[e], seq[d], seq[e+1], seq[d-1]);
	/*Exclude the i-j stacking energy here, just in case i-j 
	  don't pair */
	
	pf_de = pf_index(d,e,seqlength);
	pr = Px[ fbix ] * 
	  exp(-energy/(R_GAS*TEMP_K))*Qb[ pf_de] / Qx[ fbix];
	Pb[ pf_de] += pr;	

	Px[ fbix] -= pr;

	Qx[ fbix] -= 
	  exp(-energy/(R_GAS*TEMP_K))*Qb[ pf_de];
      }
    }
  }

  for( size = 10; size <= L - 7; size++) {
    if( size <= 30) {
      oldSizeEnergy = loop37[ size - 1];
    }
    else {
      oldSizeEnergy = loop37[ 30 - 1];
      oldSizeEnergy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
    }
    if( size - 2 <= 30) {
      newSizeEnergy = loop37[ size-2 - 1];
    }
    else {
      newSizeEnergy = loop37[ 30 - 1];
      newSizeEnergy += 1.75*R_GAS*TEMP_K*log( (size-2)/30.0); 
    }
    
    fbix  = fbixIndex( j-i, i, size, seqlength);
    fbix2 = fbixIndex( j-i-2, i+1, size-2, seqlength);
    
    Qx_2[ fbix2] = 
      Qx[ fbix] * exp( -(newSizeEnergy - oldSizeEnergy)/(R_GAS*TEMP_K));
    
    
    Px_2[ fbix2] = Px[ fbix]; 
  }

}

/* ****************************************************** */

void prManageQx( double **Qx, double **Qx_1, 
		 double **Qx_2, double **Px, double **Px_1,
		 double **Px_2,
		 int len, int seqlength) {
  // Allocate and deallocate QbIx matrices
  // since flow is reversed in Pr calulations, Qx_1 and Qx_2 now
  // now represent values for L-1 and L-2 (rather than +1 and +2)

  int i;
  int maxStorage;
  double *temp;
  //  int c;

  maxStorage = (seqlength - len)*(len - 1);
  for( i = len-1; i >= len - 2; i--) {
    maxStorage = MAX( maxStorage, ( seqlength - i)*(i - 1) );
  }
 
  if( len == seqlength-1 && len >= 14) { //first use of these matrices
    
    //Qx, Qx_1 are already set
    if( *Qx_2 != NULL) free( *Qx_2);
    *Qx_2 = 
      (double *) calloc( maxStorage, sizeof( double));
    
    *Px = (double *) calloc( maxStorage, sizeof( double));
    *Px_1 = (double *) calloc( maxStorage, sizeof( double));
    *Px_2 = (double *) calloc( maxStorage, sizeof( double));
    
    
    if( *Qx_2 == NULL || *Px == NULL || *Px_1 == NULL || *Px_2 == NULL) {
      printf("Error in Qx_2, Px, Px_1, Px_2 allocation\n");
    }


  }
  else if( len >= 14) {

    temp = *Px;
    *Px = *Px_1;
    *Px_1 = *Px_2;
    free( temp);
   
    *Px_2 =
      (double *) calloc( maxStorage, sizeof( double));

    temp = *Qx;
    *Qx = *Qx_1;
    *Qx_1 = *Qx_2;

    free( temp);

    *Qx_2 =
      (double *) calloc( maxStorage, sizeof( double));
  
    if( *Qx_2 == NULL || *Px_2 == NULL) {
      printf("Error in Qx_2, Px_2 allocation\n");
    }
    
  }
}

#endif

/* ***************************************** */

#ifdef O_N5
void prManageQgIx( double **QgIx, double **QgIx_1, 
		   double **QgIx_2, double **PgIx, double **PgIx_1,
		   double **PgIx_2, int d, int seqlength) {
  // Allocate and deallocate QgIx matrices
  
  int maxStorage;
  int dTest;
  double *temp;
  
  maxStorage = 0;
  for( dTest = d; dTest >= d-2; dTest--) {
    maxStorage = MAX( maxStorage, (seqlength-dTest)*(dTest-5)*
		      ((dTest-1)*(dTest-2)/2) );
  }

  if( d == seqlength - 1 && d>=16) {
    //Qx, Qx_1 are already set
    free( *QgIx_2);
    *QgIx_2 = 
      (double *) calloc( maxStorage, sizeof( double));
    
    *PgIx = (double *) calloc( maxStorage, sizeof( double));
    *PgIx_1 = (double *) calloc( maxStorage, sizeof( double));
    *PgIx_2 = (double *) calloc( maxStorage, sizeof( double));
    
    if( *QgIx_2 == NULL || *PgIx == NULL || *PgIx_1 == NULL || 
	*PgIx_2 == NULL) {
      printf("Error in QgIx_2, PgIx, PgIx_1, PgIx_2 allocation\n");
      exit(0);
    }
  }
  else if( d >= 16) { // every case beyond the first
    
    temp = *QgIx;
    *QgIx = *QgIx_1;
    *QgIx_1 = *QgIx_2;
    free(temp);
    *QgIx_2 = (double *) calloc( maxStorage, sizeof(double) );

    temp = *PgIx;
    *PgIx = *PgIx_1;
    *PgIx_1 = *PgIx_2;
    free( temp);
    *PgIx_2 =
      (double *) calloc( maxStorage, sizeof( double));

    if( *QgIx_2 == NULL || *PgIx_2 == NULL) {
      printf("Error in QgIx_2, PgIx_2 allocation\n");
      exit(0);
    }

  }
}
#endif
/* ************************************************ */

#if defined (O_N5)

void prFastILoopsN5( int i, int j, char seq[], int seqlength, 
		     double Qg[], double QgIx[], double QgIx_2[],
		     double Pg[],
		     double PgIx[], double PgIx_2[]) {

  int d, e, size;
  int L = j - i + 1;
  int qgix, qgix2;
  double expInteriorMM;
  int gap_idej;
  double energy;
  int c, f; //Internal pair.(c, f will be restricted to special cases) 
  int L1, L2; //size parameters: L1 + L2 = size, L1 = c-i-1, L2 = j-f-1
  int gap_cdef;
  extern double loop37[];
  extern double asymmetry_penalty[];
  extern double max_asymmetry;
  int asymmetry, asymmetry_index;
  double pr;
  double oldSizeEnergy, newSizeEnergy;

  if( CanPair( seq[i], seq[j]) == TRUE) {
    expInteriorMM = exp( -InteriorMM( seq[i], seq[j], seq[i+1], 
				      seq[j-1])/(R_GAS*TEMP_K));
    
    for( d = i+1; d <= j-5; d++) {
      for( e = d+4; e <= j-1; e++) {
	if(  CanPair( seq[d], seq[e]) == TRUE) {
	  
	  gap_idej = gap_index( i,d,e,j, seqlength);
	  
	  MakePg_Inextensible( i,j,d,e, seq, seqlength, Qg, Pg);
	}
      }
    }
  }


  //Add in special "root" cases( i ==0 || j == selqength -1) to QgIx
  if( (i == 0 || j == seqlength - 1) && L>=17 && L <= seqlength - 2) {
    for( d = i+6; d <= j-10; d++) {
      for( e = d+4; e <= j-6; e++) {
	if(  CanPair( seq[d], seq[e]) == TRUE) {

	  for( c = i+5; c <= d-1; c++) {
	    for( f = e+1; f <= j - 5; f++) {
	      if( CanPair( seq[c], seq[f]) == TRUE) {
		
		L1 = c-i-1;
		L2 = j-f-1;
		size = L1 + L2;

		asymmetry = abs( L1 - L2);
		//Loop Size Energy
		if( size <= 30) {
		  energy = loop37[ size - 1];
		}
		else {
		  energy = loop37[ 30 - 1];
		  energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
		}
		
		asymmetry_index = 4;
		
		if( asymmetry*asymmetry_penalty[ asymmetry_index - 1] < max_asymmetry ) {
		  energy += asymmetry*asymmetry_penalty[ asymmetry_index - 1];
		}
		else {
		  energy += max_asymmetry; // MAX asymmetry penalty
		}
		
		energy += InteriorMM( seq[f], seq[c], seq[f+1], seq[c-1]);
		/*Exclude the i-j stacking energy here, just in case i-j 
		  don't pair */
		
		gap_cdef = gap_index( c,d,e,f, seqlength);
		qgix = QgIxIndex( j-i, i, size, d, e, seqlength);

		QgIx[ qgix ] += 
		  exp(-energy/(R_GAS*TEMP_K))*Qg[ gap_cdef];
	      }
	    }
	  }
	}
      }
    }
  }


  //Calculate PgIx using Pb
  if( CanPair(seq[i], seq[j]) == TRUE) {
    for( d = i+1; d <= j-5; d++) {
      for( e = d+4; e <= j-1; e++) {
	if(  CanPair( seq[d], seq[e]) == TRUE) {
	
	  gap_idej = gap_index( i,d,e,j, seqlength);
	
	  for( size = 8; size <= L - 9; size++) {
	    qgix = QgIxIndex( j-i,i,size,d,e,seqlength);

	    pr = Pg[ gap_idej]* QgIx[ qgix] * 
	      expInteriorMM / Qg[ gap_idej];
	    PgIx[ qgix] += pr;
	    
	  }
	}
      }
    }
  }
  
  if( L >= 17) {
    for( d = i+6; d <= j-10; d++) {
      for( e = d+4; e <= j-6; e++) {
	if(  CanPair( seq[d], seq[e]) == TRUE) {

	  //Next calculate Pb using PgIx and QgIx for L1 == 4 || L2 == 4 
	  //Case 1:  L1 = 4, L2 >= 4; 
	  L1 = 4;
	  c = i + L1 + 1;
	  for( L2 = 4; L2 <= j - e - 2; L2++) {
	    size = L1 + L2;
	    f = j - L2 - 1;
	    qgix =  QgIxIndex( j-i, i, size, d,e,seqlength);

	    if( CanPair( seq[c], seq[f]) == TRUE && PgIx[ qgix] > 0) {
	      
	      asymmetry = abs( L1 - L2);
	      //Loop Size Energy
	      if( size <= 30) {
		energy = loop37[ size - 1];
	      }
	      else {
		energy = loop37[ 30 - 1];
		energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
	      }
	
	      //Asymmetry rountine copied from efn.f in Zuker's mfold package.
	      asymmetry_index = 4;
	      
	      if( asymmetry*asymmetry_penalty[ asymmetry_index - 1] < max_asymmetry ) {
		energy += asymmetry*asymmetry_penalty[ asymmetry_index - 1];
	      }
	      else {
		energy += max_asymmetry; // MAX asymmetry penalty
	      }
	      
	      energy += InteriorMM( seq[f], seq[c], seq[f+1], seq[c-1]);
	      /*Exclude the i-j stacking energy here, just in case i-j 
		don't pair */
	      
	      gap_cdef = gap_index(c,d,e,f,seqlength);
	      pr = PgIx[ qgix ] * 
		exp(-energy/(R_GAS*TEMP_K))*Qg[ gap_cdef] / QgIx[ qgix];  
	      Pg[ gap_cdef] += pr;
	    
	      PgIx[ qgix] -= pr;
	      
	      //Recalculate Qx
	      QgIx[ qgix] -= 
		exp(-energy/(R_GAS*TEMP_K))*Qg[ gap_cdef];

	    }
	  }

	  //Case 2  L1 > 4, L2 = 4
	  L2 = 4;
	  f = j - L2 -1;
	  for( L1 = 5; L1 <= d-i-2; L1++) {   
	    size = L1 + L2;
	    c = i + L1 + 1;

	    qgix =  QgIxIndex( j-i, i, size, d,e,seqlength);
      
	    if( CanPair( seq[c], seq[f]) == TRUE && PgIx[ qgix] > 0) {
	      asymmetry = abs( L1 - L2);
	      //Loop Size Energy
	      if( size <= 30) {
		energy = loop37[ size - 1];
	      }
	      else {
		energy = loop37[ 30 - 1];
		energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
	      }
	      
	      
	      //Asymmetry rountine copied from efn.f in Zuker's mfold package.
	      asymmetry_index = 4;
	      
	      if( asymmetry*asymmetry_penalty[ asymmetry_index - 1] < max_asymmetry ) {
		energy += asymmetry*asymmetry_penalty[ asymmetry_index - 1];
	      }
	      else {
		energy += max_asymmetry; // MAX asymmetry penalty
	      }
	      energy += InteriorMM( seq[f], seq[c], seq[f+1], seq[c-1]);
	      /*Exclude the i-j stacking energy here, just in case i-j 
		don't pair */
	      
	      gap_cdef = gap_index(c,d,e,f,seqlength);
	      pr = PgIx[ qgix ] * 
		exp(-energy/(R_GAS*TEMP_K))*Qg[ gap_cdef] / QgIx[ qgix];
	      Pg[ gap_cdef] += pr;	
	      

	      PgIx[ qgix] -= pr;
	      
	      QgIx[ qgix] -= 
		exp(-energy/(R_GAS*TEMP_K))*Qg[ gap_cdef];
	    }
	  }
	}
   
	for( size = 10; size <= L - 9; size++) {
	  if( size <= 30) {
	    oldSizeEnergy = loop37[ size - 1];
	  }
	  else {
	    oldSizeEnergy = loop37[ 30 - 1];
	    oldSizeEnergy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
	  }
	  if( size - 2 <= 30) {
	    newSizeEnergy = loop37[ size-2 - 1];
	  }
	  else {
	    newSizeEnergy = loop37[ 30 - 1];
	    newSizeEnergy += 1.75*R_GAS*TEMP_K*log( (size-2)/30.0); 
	  }
	  
	  qgix  = QgIxIndex( j-i, i, size, d, e, seqlength);
	  qgix2 = QgIxIndex( j-i-2, i+1, size-2, d, e, seqlength);
	  
	  QgIx_2[ qgix2] = 
	    QgIx[ qgix] * 
	    exp( -(newSizeEnergy - oldSizeEnergy)/(R_GAS*TEMP_K));
	  
	  PgIx_2[ qgix2] = PgIx[ qgix];
	
	}
      }
    }
  }

}


/* *********************************** */

void MakePg_Inextensible( int i, int j,int d, int e, char seq[], int seqlength,
			  double *Qg, double *Pg) {
  
  double energy;
  int c, f; //Internal pair.(c, f will be restricted to special cases)  
  int L1, L2; //size parameters: L1 + L2 = size, L1 = c-i-1, L2 = j-f-1
  double pr;
  int gap_idej = gap_index(i,d,e,j,seqlength);
  int gap_cdef;

  if( CanPair( seq[i], seq[j]) == FALSE) { 
    return;
  }

  /* First consider small loops */
  // L1 <= 3, L2 <= 3
  for( L1 = 0; L1 <= MIN(3, d-i-2); L1++) {
    c = i + L1 + 1;
    for( L2 = 0; L2 <= MIN( 3, j-e-2); L2++) {      
      f = j - L2 - 1;
      if( CanPair( seq[c], seq[f]) == TRUE) { //c < d && f > e

          energy = InteriorEnergy( i, j, c, f, seq);
	  gap_cdef = gap_index(c,d,e,f,seqlength);
	
	  pr = Pg[ gap_idej]*exp( -energy/(R_GAS*TEMP_K)) *
	    Qg[ gap_cdef]/ Qg[ gap_idej];
	  Pg[ gap_cdef] += pr;

      }
    }
  }

  /* Next consider large bulges or large asymmetric loops */
  // Case 2a  L1 = 0,1,2,3, L2 >= 4;
  for( L1 = 0; L1 <= MIN(3, d-i-2); L1++) {
    c = i + L1 + 1;
    for( L2 = 4; L2 <= j - e - 2; L2++) {
      f = j - L2 - 1;
      if( CanPair( seq[c], seq[f]) == TRUE) { //c < d && f > e
	
	gap_cdef = gap_index(c,d,e,f,seqlength);

	energy = InteriorEnergy( i, j, c, f, seq);	
	pr = Pg[ gap_idej] * exp( -energy/(R_GAS*TEMP_K)) *
	  Qg[ gap_cdef]/Qg[ gap_idej];

	Pg[ gap_cdef] += pr;

      }
    }
  }

  // Case 2b L1 >= 4, L2 = 0,1,2,3;
  for( L2 = 0; L2 <= MIN(3,j-e-2) ; L2++) {
    f = j - L2 - 1;
    for( L1 = 4; L1 <= d-i-2; L1++) {
      c = i + L1 + 1;
      if( CanPair( seq[c], seq[f]) == TRUE) { //c < d && f > e
	
	gap_cdef = gap_index(c,d,e,f,seqlength);

	energy = InteriorEnergy( i, j, c, f, seq);
	pr = Pg[ gap_idej]*exp( -energy/(R_GAS*TEMP_K)) *
	  Qg[ gap_cdef]/Qg[ gap_idej];
	Pg[ gap_cdef] += pr;

      }
    }
  }    

}  
#endif
/* ****************************************** */

#endif //PAIRPR
