
// a simple driver for the pairfold

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

// include the pairfold library
#include "pairfold.h"
#include "externs.h"
#include "timer.h"

int dna_or_rna = RNA;
int num_suboptimals = 1;
double temperature = 37; 

void usage (const char *prog)
// PRE:  None
// POST: Prints the usage message and exits
{
    printf ("\nUsage: %s <sequence1> <sequence2> [options]\n", prog);
    
    printf ("  <sequence1> <sequence2> are the two sequences to fold, from 5' to 3'.\n");
    printf ("\tThe maximum length in total is %d.\n\n", MAXSLEN);    
    printf ("Options:\n");    
    printf ("  -m <molecule_type>\n");
    printf ("\tDNA or RNA. Default %s.\n", dna_or_rna==DNA?"DNA":"RNA");
    printf ("  -t <temperature>\n");
    printf ("\tThe temperature of reaction, in degrees Celsius. Default %g.\n", temperature);
//    printf ("  -n <number_suboptimals>\n");
//    printf ("\tThe number of suboptimal structures returned, including MFE. Default %d.\n\n", num_suboptimals);    
    printf ("  -h\n\tPrint this help message\n\n");
    printf ("Examples:\n");
    printf ("\t%s \"AAUAAACUCAACGGAGG\" \"CCUGCGUUCUGAUGAGUCCGUGAGGACGAAAGUUUAUU\" -t 30\n", prog);
    printf ("\t%s \"AAUAAACUCAACGGAGG\" \"CCUGCGUUCUGAUGAGUCCGUGAGGACGAAAGUUUAUU\" -t 70 -m RNA\n", prog);
    printf ("\t%s \"AAUAAACUCAACGGAGG\" \"CCUGCGUUCUGAUGAGUCCGUGAGGACGAAAGUUUAUU\" -m DNA\n", prog);
    exit (0);
}


void get_arguments (int argc, char *argv[])
// PRE:  None
// POST: Get the parameters from the command line
{
    int c;
    extern char *optarg;
    extern int optind;
    int errflag = 0;

    while ((c = getopt (argc, argv, "m:t:h?")) != -1)
    {
        switch (c)
        {
//             case 'n':
//                 num_suboptimals = atoi (optarg);
//                 break;
            case 't':
                temperature = atof (optarg);
                break;
            case 'm':
                if (strcmp (optarg, "DNA") == 0)        dna_or_rna = DNA;
                else if (strcmp (optarg, "RNA") == 0)   dna_or_rna = RNA;
                else    errflag = 1;
                break;
            case 'h':
            case '?':
                errflag = 1;
                break;
        }
    }
    if (errflag || argc < 3)
        usage (argv[0]);

}


int main (int argc, char *argv[])
{
    char sequence1[MAXSLEN], sequence2[MAXSLEN];
    char structure[2*MAXSLEN];
    double energy;
    int i;
    char structures[MAXSUBSTR][MAXSLEN];
    double energies[MAXSUBSTR];    
    timer stpw;
    //    double entropy, Tm, H, S;
    //    double target_conc1, target_conc2, salt_conc;
    //    int self_comp;    
  
    if (argc < 3)
    {
        usage (argv[0]);
        return 0;
    }    
    strcpy (sequence1, argv[1]);
    strcpy (sequence2, argv[2]);
    get_arguments (argc, argv);    

            
    // Before calling any function in the library, you have to initialize config_file, dna_or_rna, temperature
    //     and to call the function init_data, which loads the thermodynamic parameters into memory
    
    // configuration file, the path should relative to the location of this executable
    char config_file[200] = "params/multirnafold.conf";

    // what to fold: RNA or DNA

    // temperature: any integer or real number between 0 and 100
    // represents degrees Celsius
    
    // initialize the thermodynamic parameters
    // call init_data only once for the same dna_or_rna and same temperature
    // if one of them changes, call init_data again   
    init_data (argv[0], config_file, dna_or_rna, temperature);     
    
    if (num_suboptimals == 1)
    {
        stpw.reset();
        stpw.start();            
        energy = pairfold_mfe (sequence1, sequence2, structure);
        // You may want to check if the free energy of this structure was computed correctly
        //en2 = free_energy_pairfold (sequence1, sequence2, structure);
        stpw.stop();
        printf ("Seq: %s %s\nMFE: %s  %.2lf\n", sequence1, sequence2, structure, energy);
                
        // or you can call the function which doesn't allow intramolecular interactions
        //stpw.reset();
        //stpw.start();            
        //energy = pairfold_mfe_nointra (sequence1, sequence2, structure, 10);
        //stpw.stop();
        //printf ("%s %s\n%s  %.2lf\t%.2lf\n", sequence1, sequence2, structure, energy, stpw.elapsed());
        
    }
    else if (num_suboptimals > 1)
    {
        if (num_suboptimals > (MAXSUBSTR-2)/2)
        {
            printf ("Numer of suboptimals should be <= %d\n", (MAXSUBSTR-2)/2);
            printf ("If you need more, change the MAXSUBSTR constant in include/constants.h\n");
            exit(1);
        }
        printf ("%s %s\n", sequence1, sequence2);          
        pairfold_ordered_suboptimals (sequence1, sequence2, num_suboptimals, structures, energies);
        for (i=0; i < num_suboptimals; i++)
        {
            //en2 = free_energy_pairfold (sequence1, sequence2, structures[i]);
            printf ("%s  %.2lf\n", structures[i], energies[i]); 
        }
    }
    return 0;
}


 
