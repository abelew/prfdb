/***************************************************************************
                          p_multi_loop_sub.cpp  -  description
                             -------------------
    begin                : Mon Apr 15 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <stdio.h>
#include <malloc.h>

#include "externs.h"
#include "common.h"
#include "p_multi_loop_sub.h"
#include "pairfold.h"
#include "p_energy_matrix.h"

p_multi_loop_sub::p_multi_loop_sub (int *seq, int link, int length)
// The constructor
{
    int i;
    sequence = seq;
    seqlen = length;
    this->V = NULL;
    this->link = link;
    
    index = new int[length];
    //index = (int*) malloc (sizeof(int)*length);
    int total_length;
    total_length = (length *(length+1))/2;
    index[0] = 0;
    for (i=1; i < length; i++)
        index[i] = index[i-1]+length-i+1;

    FM = new PARAMTYPE [total_length];
    if (FM == NULL) giveup ("Cannot allocate memory", "p_multi_loop_sub");
    for (i=0; i < total_length; i++) FM[i] = INF;
    FM_link = new PARAMTYPE [total_length];
    if (FM_link == NULL) giveup ("Cannot allocate memory", "p_multi_loop_sub");
    for (i=0; i < total_length; i++) FM_link[i] = INF;
    FM1 = new PARAMTYPE [total_length];
    if (FM1 == NULL) giveup ("Cannot allocate memory", "p_multi_loop_sub");
    for (i=0; i < total_length; i++) FM1[i] = INF;
    FM1_link = new PARAMTYPE [total_length];
    if (FM1_link == NULL) giveup ("Cannot allocate memory", "p_multi_loop_sub");
    for (i=0; i < total_length; i++) FM1_link[i] = INF;

}

p_multi_loop_sub::~p_multi_loop_sub ()
// The destructor
{  
    delete [] index;
    delete [] FM;
    delete [] FM_link;
    delete [] FM1;
    delete [] FM1_link;  
}

void p_multi_loop_sub::compute_energy_FM1 (int j)
// PRE:  None
// POST:
// Note: NEED to change
{
    int i, tmp_k, ij, k;
    PARAMTYPE tmp, min_e;
        
    tmp=INF;
    for (i=j-1; i>=0; i--)
    {
        ij = index[i]+j-i;
        tmp_k = -1;
        tmp = INF;
        min_e = INF;
        for (k=i+1; k <= j; k++) // RANGE OF K<=j-TURN-2
          {
            if (link >= k && link <j)
              continue;
            tmp = V->get_energy(i, k) + (j-k)*misc.multi_free_base_penalty+ 
              misc.multi_helix_penalty+
              AU_penalty(sequence[i], sequence[k]);
            
            if(i>0)
              {
                tmp += dangle_bot [sequence[k]]  // M: changed: it was i,k,i-1
                  [sequence[i]]
                  [sequence[i-1]];
              }
            
            if(k<seqlen-1)
              {
                tmp += dangle_top [sequence [k]]  // M: changed: it was k,i,k+1
                  [sequence [i]]
                  [sequence [k+1]];
              }
            if (tmp < min_e)
              {
                min_e = tmp;
              }
          }// k for loop
        if(min_e < INF)
          {
            FM1[ij] = min_e;
          }
    }//i for loop
}


void p_multi_loop_sub::compute_energy_FM1_link (int j)
// PRE:  None
// POST:
// Note: the link is in the p_multi_loop_sub  
{
    int i, ij, k;
    PARAMTYPE tmp, min_e;
        
    tmp=INF;

    for (i=j-1; i>=0; i--)
    {
        ij = index[i]+j-i;
        tmp = INF;
        min_e = INF;

        if (i <= link && link < j)
          continue;

        for (k=i+1; k <= j; k++) // RANGE OF K<=j-TURN-2
          {
            tmp = V->get_energy(i,k) + AU_penalty(sequence[i], sequence[k]);
            if (i > 0)
              {
                tmp += dangle_bot [sequence[k]]
                  [sequence[i]]
                  [sequence[i-1]];
              }
            if(k<seqlen-1)
              {
                tmp += dangle_top [sequence[k]]
                  [sequence [i]]
                  [sequence [k+1]];
              }
            if (tmp < min_e)
              {
                min_e = tmp;
              }
          }// k for loop
        if(min_e < INF)
          {
            FM1_link[ij] = min_e;            
          }
    }//i for loop
}

void p_multi_loop_sub::compute_energy_FM (int j)
// PRE:  None
// POST:
// Note: FM(i, j) can be divided into FM(i, k)+FM1(k, j)
{
    int i, tmp_k, k, ij;
    PARAMTYPE tmp, min_e;

    for (i=j-1; i>=0; i--)
      {
        //    int ii = index[i]-i;
        ij = index[i]+j-i;
        tmp_k = -1;
        min_e = INF;

        // first branch
        for (k=i+1; k < j; k++)
          {
            if (k == link) continue;
            tmp = get_FM_energy (i,k) + get_FM1_energy (k+1,j);
            if (tmp < min_e)
                min_e = tmp;
          }// k for loop

        // second branch
        for (k=i; k < j; k++)
          {
            if (link >= i && link < k) continue;
            tmp = get_FM1_energy (k,j) + (k-i)*misc.multi_free_base_penalty; 
            if (tmp < min_e)
                min_e = tmp;
          }// k for loop

        if (min_e < INF)
          FM[ij] = min_e;
      }
}

void p_multi_loop_sub::compute_energy_FM_link (int j)
// PRE:  None
// POST:
// Note: FM(i, j) can be divided into FM(i, k)+FM1(k, j)
{
    int i, k, ij;
    PARAMTYPE tmp, min_e;

    for (i=j-1; i>=0; i--)
      {
        if (i <= link && link < j)
          continue;

        //    int ii = index[i]-i;
        ij = index[i]+j-i;
        min_e = INF;

        // first branch
        for (k=i+1; k < j; k++)
          {
            tmp = get_FM_link_energy (i,k) + get_FM1_link_energy (k+1,j);
            if (tmp < min_e)
                min_e = tmp;
          }// k for loop

        // second branch
        for (k=i; k < j; k++)
          {
            tmp = get_FM1_link_energy (k,j); 
            if (tmp < min_e)
                min_e = tmp;
          }// k for loop

        FM_link[ij] = min_e;
      }
}


//int p_multi_loop_sub::compute_energy (int i, int j, int &nexti, int &nextj, int &withlink)
PARAMTYPE p_multi_loop_sub::compute_energy (int i, int j)
{
    int k;
    PARAMTYPE min_en = INF;
    PARAMTYPE tmp;
    for(k=i+1; k<j; k++)
      {
        if (k == link)
          continue;
        tmp = get_FM_energy (i+1,k) + get_FM1_energy (k+1,j-1);
        if(tmp < min_en)
          {
            min_en = tmp;
          }                    
      }
    if(min_en < INF)
      {
        return min_en+misc.multi_offset+misc.multi_helix_penalty+
          AU_penalty (sequence[i], sequence[j])+
          dangle_top[sequence[i]][sequence[j]][sequence[i+1]]+
          dangle_bot[sequence[i]][sequence[j]][sequence[j-1]];
      }
    return INF;
}



//int p_multi_loop_sub::compute_energy (int i, int j, int &nexti, int &nextj, int &withlink)
PARAMTYPE p_multi_loop_sub::compute_energy_link (int i, int j)
{
    int k;
    PARAMTYPE min;
    PARAMTYPE tmp;

    min = INF;
    if (link < i || link >= j)
      return INF;

    tmp = get_FM_link_energy (i+1,link) + get_FM_link_energy (link+1,j-1);
    if (tmp < min)
      {
        min = tmp;
      }
    for (k = link+1; k < j; k++)
      {
        tmp = get_FM_link_energy (link+1,k) + get_FM1_link_energy (k+1,j-1);
        if (tmp < min)
          {
            min = tmp;
          }
      }
    for (k = i+1; k < link; k++)
      {
        tmp = get_FM_link_energy (i+1,k) + get_FM1_link_energy (k+1,link);
        if (tmp < min)
          {
            min = tmp;
          }
      }



    if(min < INF)
      {
        return min + misc.intermolecular_initiation+
          AU_penalty (sequence[i], sequence[j])+
          dangle_top[sequence[i]][sequence[j]][sequence[i+1]]+
          dangle_bot[sequence[i]][sequence[j]][sequence[j-1]];
      }
    return INF;
}

