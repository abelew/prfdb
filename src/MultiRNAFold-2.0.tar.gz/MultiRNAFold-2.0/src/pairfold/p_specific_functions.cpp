/***************************************************************************
                          p_specific_functions.cpp  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/


// This file contains common functions, that may be used throughout the library

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "constants.h"
#include "structs.h"
#include "externs.h"
#include "common.h"
#include "pairfold.h"
#include "p_min_folding.h"
#include "p_sub_folding.h"
#include "p_stacked_pair.h"
#include "p_specific_functions.h"



PARAMTYPE p_dangling_energy (int *sequence, int link, int i1, int i2, int i3, int i4)
//      (   )...(   )
//      i1..i1..i3..i4
// PRE:  (i1, i2) and (i3, i4) are pairs, i2 and i3 are neighbours, i2 < i3
// POST: return dangling energy between i2 and i3
{
    PARAMTYPE energy;
    PARAMTYPE d_top, d_bot;
    d_top = 0;
    d_bot = 0;

    if (i2 != link)
        //d_top = MIN (0, IGINF(dangle_top[sequence[i2]]
        d_top = IGINF(dangle_top[sequence[i2]]
                          [sequence[i1]]
                          [sequence[i2+1]]);
    if (i3-1 != link)                      
        d_bot = IGINF(dangle_bot[sequence[i4]]	// or MIN
                          [sequence[i3]]
                          [sequence[i3-1]]);
    if (i2+1 == i3-1 && i2 == link)
        energy = d_bot;
    else if (i2+1 == i3-1 && i3-1 == link)
        energy = d_top;     
    else if (i2+1 == i3-1)     // see which is smaller
    {
        energy = d_top < d_bot ? d_top : d_bot;
    }
    else if (i2+1 < i3-1)
    {
        energy = d_top + d_bot;
    }


    else // if there is no free base between the two branches, return 0
        energy = 0;
    return energy;
}


PARAMTYPE p_dangling_energy_left (int *sequence, int link, int i1, int i2, int i3, int i4)
//      (....(    )   )
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling energy between i1 and i3
{
    PARAMTYPE energy;
    PARAMTYPE d_top, d_bot;
    d_top = 0;
    d_bot = 0;

    // this will be used in multi-loops.
    // add the dangle_top, even if it is positive
    if (i1 != link)
        d_top = IGINF(dangle_top[sequence[i1]]	// or MIN
                          [sequence[i2]]
                          [sequence[i1+1]]);
    // in the other parts of the multi-loop, the dangles are added only if they are negative
    if (i3-1 != link)
        d_bot = IGINF(dangle_bot[sequence[i4]]	// or MIN
                          [sequence[i3]]
                          [sequence[i3-1]]);
    if (i1+1 == i3-1 && i1 == link)
        energy = d_bot;
    else if (i1+1 == i3-1 && i3-1 == link)
        energy = d_top;
    else if (i1+1 == i3-1)     // see which is smaller
    {
        energy = d_top < d_bot ? d_top : d_bot;
    }
    else if (i1+1 < i3-1)
    {
        energy = d_top + d_bot;
    }
    else // if there is no free base between the two branches, return 0
        energy = 0;
    return energy;
}


PARAMTYPE p_dangling_energy_right (int *sequence, int link, int i1, int i2, int i3, int i4)
//      (    (    )...)
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling energy between i4 and i2
{
    PARAMTYPE energy;
    PARAMTYPE d_top, d_bot;
    d_top = 0;
    d_bot = 0;

    if (i4 != link)
        d_top = IGINF(dangle_top[sequence[i4]]	// or MIN
                          [sequence[i3]]
                          [sequence[i4+1]]);
    if (i2-1 != link)
        d_bot = IGINF(dangle_bot[sequence[i1]]	// or MIN
                          [sequence[i2]]
                          [sequence[i2-1]]);
    if (i4+1 == i2-1 && i4 == link)
        energy = d_bot;
    else if (i4+1 == i2-1 && i2-1 == link)
        energy = d_top;
    else if (i4+1 == i2-1)     // see which is smaller
    {
        energy = d_top < d_bot ? d_top : d_bot;
    }
    else if (i4+1 < i2-1)
    {
        energy = d_top + d_bot;
    }
    else // if there is no free base between the two branches, return 0
        energy = 0;
    return energy;
}


PARAMTYPE p_dangling_enthalpy (int *sequence, int link, int i1, int i2, int i3, int i4)
//      (   )...(   )
//      i1..i1..i3..i4
// PRE:  (i1, i2) and (i3, i4) are pairs, i2 and i3 are neighbours, i2 < i3
// POST: return dangling energy between i2 and i3
{
    PARAMTYPE energy;
    PARAMTYPE d_top, d_bot;
    d_top = 0;
    d_bot = 0;

    if (i2 != link)
        d_top = enthalpy_dangle_top[sequence[i2]]	// or MIN
                          [sequence[i1]]
                          [sequence[i2+1]];
    if (i3-1 != link)
        d_bot = enthalpy_dangle_bot[sequence[i4]]	// or MIN
                          [sequence[i3]]
                          [sequence[i3-1]];
    if (i2+1 == i3-1 && i2 == link)
        energy = d_bot;
    else if (i2+1 == i3-1 && i3-1 == link)
        energy = d_top;
    else if (i2+1 == i3-1)     // see which is smaller
    {
        energy = d_top < d_bot ? d_top : d_bot;
    }
    else if (i2+1 < i3-1)
    {
        energy = d_top + d_bot;
    }

    else // if there is no free base between the two branches, return 0
        energy = 0;
    return energy;
}


PARAMTYPE p_dangling_enthalpy_left (int *sequence, int link, int i1, int i2, int i3, int i4)
//      (....(    )   )
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling energy between i1 and i3
{
    PARAMTYPE energy;
    PARAMTYPE d_top, d_bot;
    d_top = 0;
    d_bot = 0;

    // this will be used in multi-loops.
    // add the dangle_top, even if it is positive
    if (i1 != link)
        d_top = enthalpy_dangle_top[sequence[i1]]	// or MIN
                          [sequence[i2]]
                          [sequence[i1+1]];
    // in the other parts of the multi-loop, the dangles are added only if they are negative
    if (i3-1 != link)
        d_bot = enthalpy_dangle_bot[sequence[i4]]	// or MIN
                          [sequence[i3]]
                          [sequence[i3-1]];
    if (i1+1 == i3-1 && i1 == link)
        energy = d_bot;
    else if (i1+1 == i3-1 && i3-1 == link)
        energy = d_top;
    else if (i1+1 == i3-1)     // see which is smaller
    {
        energy = d_top < d_bot ? d_top : d_bot;
    }
    else if (i1+1 < i3-1)
    {
        energy = d_top + d_bot;
    }
    else // if there is no free base between the two branches, return 0
        energy = 0;
    return energy;
}


PARAMTYPE p_dangling_enthalpy_right (int *sequence, int link, int i1, int i2, int i3, int i4)
//      (    (    )...)
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling energy between i4 and i2
{
    PARAMTYPE energy;
    PARAMTYPE d_top, d_bot;
    d_top = 0;
    d_bot = 0;

    if (i4 != link)
        d_top = enthalpy_dangle_top[sequence[i4]]	// or MIN
                          [sequence[i3]]
                          [sequence[i4+1]];
    if (i2-1 != link)
        d_bot = enthalpy_dangle_bot[sequence[i1]]	// or MIN
                          [sequence[i2]]
                          [sequence[i2-1]];
    if (i4+1 == i2-1 && i4 == link)
        energy = d_bot;
    else if (i4+1 == i2-1 && i2-1 == link)
        energy = d_top;
    else if (i4+1 == i2-1)     // see which is smaller
    {
        energy = d_top < d_bot ? d_top : d_bot;
    }
    else if (i4+1 < i2-1)
    {
        energy = d_top + d_bot;
    }
    else // if there is no free base between the two branches, return 0
        energy = 0;
    return energy;
}


// ******************************
// entropy from parameters (begin)


// entropy parameters from MinSik
// Dan: parameters adjusted to [SantaLucia 2004] paper
double stacking_entropy[] = {-21.3, -20.4, -21.3, -22.7, -22.4, -21.0, -22.2, -27.2, -24.4, -19.9};
double stacking_enthalpy[] = {-7.6, -7.2, -7.2, -8.5, -8.4, -7.8, -8.2, -10.6, -9.8, -8.0};
double acc_entropy[] = {-5.7, 6.9, -1.4};
double acc_enthalpy[] = {0.2, 2.2, 0.0};

/*
double	THERMO_TABLE[MAX_THERMO_INTERACTION][MAX_THERMO_DELTA]	=	
{
	{-7.9,-22.2,-1.00},    //AA/TT
	{-7.2,-20.4,-0.88},    //AT/TA
	{-7.2,-21.3,-0.58},    //TA/AT
	{-8.5,-22.7,-1.45},    //TG/AC 
	{-8.4,-22.4,-1.44},    //GT/CA
	{-7.8,-21.0,-1.28},    //CT/GA
	{-8.2,-22.2,-1.30},    //GA/CT
	{-10.6,-27.2,-2.17},    //CG/GC
	{-9.8,-24.4,-2.24},    //GC/CG
	{-8.0,-19.9,-1.84}    //GG/CC
};
*/

int get_index (char s1, char s2)
{
    switch (s1)
    {
        case 'A': case 'a':
            switch (s2)
            {
                case 'A': case 'a': return 0;
                case 'T': case 't': case 'U': case 'u': return 1;
                case 'C': case 'c': return 4;
                default: return 5;
            }
        case 'T': case 't': case 'U': case 'u':
            switch (s2)
            {
                case 'A': case 'a': return 2;
                case 'T': case 't': case 'U': case 'u': return 0;
                case 'C': case 'c': return 6;
                default: return 3;
            }
        case 'C': case 'c':
            switch (s2)
            {
                case 'A': case 'a': return 3;
                case 'T': case 't': case 'U': case 'u': return 5;
                case 'C': case 'c': return 9;
                default: return 7;
            }
		default:
        //case 'G': case 'g':    
            switch (s2)
            {
                case 'A': case 'a': return 6;
                case 'T': case 't': case 'U': case 'u': return 4;
                case 'C': case 'c': return 8;
                default: return 9;
            }                         
    }
}
    
double calc_en_from_parameters_complementary (char *sequence, int self_comp, double stacking[], double acc[])
{
    double entropy;
    int i, len;
    entropy = 0;    
    len = strlen(sequence);
    for (i = 0; i < len-1; i++)
    {
        entropy += stacking[get_index (sequence[i], sequence[i+1])];
    }
    // correction depending on the first base pair
    entropy += acc[0];    
    //if (sequence[0] == 'G' || sequence[0] == 'C' || sequence[0] == 'g' || sequence[0] == 'c')
    //{
    //    entropy += acc[0];    
    //}
    if (sequence[0] == 'A' || sequence[0] == 'T' || sequence[0] == 'a' || sequence[0] == 't')
    //else
        entropy += acc[1];
    // correction depending on the last base pair        
    //if (sequence[len-1] == 'G' || sequence[len-1] == 'C' || sequence[len-1] == 'g' || sequence[len-1] == 'c')
    //{
    //    entropy += acc[0];    
    //}
    if (sequence[0] == 'A' || sequence[0] == 'T' || sequence[0] == 'a' || sequence[0] == 't')
    //else
        entropy += acc[1]; 
    // correction depending on whether this sequence is self-complementary or not           
    if (self_comp)
        entropy += acc[2];    
    return entropy;
}

double calc_Tm_complementary_with_entropy_santalucia_2004 (char* sequence, 
    double target_conc1, double target_conc2, double salt_conc)
// PRE:  The function init_data has been called
// POST: Calculates the melting temperature of this sequence, folded with its perfect
//       complement, assuming that they pair perfectly.
//       It uses some defined parameters directly
{
    double Tm;
    int self_comp;
    
    self_comp = self_complementary (sequence);
    double enthalpy, entropy;
    enthalpy = calc_en_from_parameters_complementary (sequence, self_comp, stacking_enthalpy, acc_enthalpy);
    entropy = calc_en_from_parameters_complementary (sequence, self_comp, stacking_entropy, acc_entropy);   
    entropy = entropy/1000.0;
    Tm = calc_Tm (enthalpy, entropy, target_conc1, target_conc2, self_comp, salt_conc);
    //printf ("enthalpy from para: %.5lf\n", enthalpy);
    //printf ("entropy from para: %.5lf\n", entropy);
    //printf ("Tm from para: %.5lf\n", Tm);
    return Tm;        
}




// entropy from parameters (end)
// ******************************


double calc_entropy (double energy, double enthalpy, double temperature)
// POST: Return the entropy, as a function of energy, enthalpy and the given temperature
// Note: If "temperature" is not 37, you have to call init_data before calling this
//       function, and then to call init_data with the original temperature
{
    return ((enthalpy-energy)/(temperature+273.15));
}

double calc_Tm (double enthalpy, double entropy, double target_conc1, double target_conc2,
    int self_comp, double salt_conc)
// POST: Return melting temperature, when we know enthalpy and entropy    
{
    double Tm;
    double min_conc, max_conc;
    double k;
    if (self_comp)
    {
        k = target_conc1 + target_conc2;
    }
    else
    {
        if (target_conc1 == target_conc2)
        {
            k = (target_conc1 + target_conc2)/4;
        }
        else
        {
            min_conc = MIN (target_conc1, target_conc2);
            max_conc = MAX (target_conc1, target_conc2);
            k = max_conc - min_conc/2; // in my thesis it's +, in Santalucia 98 (PNAS 95, 1460) it's -
        }
    }
    Tm = enthalpy/(entropy + 1.98717/1000 * log (k));
    Tm += 16.6 * log10 (salt_conc/(1+0.7*salt_conc)) + 3.825452 - 273.15;
    return Tm;
}


double calc_Tm_from_structure (char *sequence1, char *sequence2, char *structure, double energy,
    double temperature, double target_conc1, double target_conc2, int self_comp, double salt_conc)
// PRE:  A structure has been calculated and is given as input
// POST: Returns the melting temperature of the given sequences, when folded into
//       structure.
{
    double enthalpy, entropy, Tm;
    remove_space (structure);
    enthalpy = enthalpy_pairfold (sequence1, sequence2, structure);
    entropy =  calc_entropy (energy, enthalpy, temperature);
    Tm = calc_Tm (enthalpy, entropy, target_conc1, target_conc2, self_comp, salt_conc);
    return Tm;
}


double calc_FE_complementary (char *sequence)
// PRE:  The function init_data has been called
// POST: Calculates the free energy of this sequence, folded with its perfect
//       complement, assuming that they pair perfectly.
{
    char complement[MAXSLEN];
    char structure[2*MAXSLEN];
    double energy;
    int i, len;

    reverse_complement_of_seq (sequence, complement);
    len = strlen(sequence);
    for (i=0; i < len; i++)
    {
        structure[i] = '(';
        structure[len + i] = ')';    
    }
//    printf ("Co: %s\nSt: %s\n", complement, structure);
    structure[2*len] = '\0';
    energy = free_energy_pairfold (sequence, complement, structure);
    return energy;    
}


double calc_Tm_complementary (char* sequence, 
    double target_conc1, double target_conc2, double salt_conc)
// PRE:  The function init_data has been called
// POST: Calculates the melting temperature of this sequence, folded with its perfect
//       complement, assuming that they pair perfectly.
{
    char complement[MAXSLEN];
    char structure[2*MAXSLEN];
    double energy, Tm;
    int i, len;    
    int self_comp;
    
    self_comp = self_complementary (sequence);    
    reverse_complement_of_seq (sequence, complement);
    len = strlen(sequence);
    for (i=0; i < len; i++)
    {
        structure[i] = '(';
        structure[len + i] = ')';
    }
    structure[2*len] = '\0';    
//    printf ("Co: %s\nSt: %s\n", complement, structure);
    energy = free_energy_pairfold (sequence, complement, structure);
    if (self_comp) energy += 0.43;
    
    double enthalpy, entropy;
    remove_space (structure);
    enthalpy = enthalpy_pairfold (sequence, complement, structure);
    
    entropy =  calc_entropy (energy, enthalpy, 37.0);
    //printf ("Energy=%.2lf, enthalpy=%.2lf, entropy=%.6lf\n", energy, enthalpy, entropy);
    Tm = calc_Tm (enthalpy, entropy, target_conc1, target_conc2, self_comp, salt_conc);
    //Tm = calc_Tm_from_structure (sequence, complement, structure, energy,
    //    temperature, target_conc1, target_conc2, self_comp, salt_conc);
    return Tm;        
}


double calc_FE_almost_complementary (char *sequence1, char *sequence2,
    int num_unpaired_right, int num_unpaired_left)
// PRE:  The function init_data has been called; 2 sequences are given;
//       the number of unpaired base on the right side (i.e. at the 3' side of
//       the first sequence); same for the left side (i.e. at the 5' end at
//       the first seq)
//       e.g. 2, 1 corresponds to .(((((.. ..))))).
// POST: Returns the FE. Replaces mismatches with internal loops    
{
    char structure[2*MAXSLEN];
    int len1, len2, i;
    double energy;
    len1 = strlen(sequence1);
    len2 = strlen(sequence2);
    for (i=0; i < len1; i++)
    {
        structure[i] = '(';
        structure[len1 + i] = ')';
    }
    structure[len1+len2] = '\0';
    for (i=0; i < num_unpaired_right; i++)
    {      
        structure[len1-i-1] = '.';
        structure[len1+i] = '.';
    }
    for (i=0; i < num_unpaired_left; i++)
    {
        structure[i] = '.';
        structure[len1+len2-1-i] = '.';
    }
    // if a pair is not complementary, consider it as internal loop
    for (i=num_unpaired_left; i < len1-num_unpaired_right; i++)
      {
        if (!can_pair (nuc_to_int(sequence1[i]), nuc_to_int(sequence2[len2-i-1])))
          {
            structure[i] = '.';
            structure[len1+len2-1-i] = '.';
          }
      }
//    printf ("Almost complementary:\n%s\n", structure);
    energy = free_energy_pairfold (sequence1, sequence2, structure);
    return energy;      
}


double free_energy_pairfold (char *sequence1, char *sequence2, char *structure)
{
    int i;
    str_features *f;
    double energy;
    int *int_sequence;
    PARAMTYPE en;
    int link, nb_nucleotides;
    char sequence[MAXSLEN];    

    // take the space out of the structure
    remove_space (structure);

    strcpy (sequence, sequence1);
    strcat (sequence, sequence2);
    link = strlen(sequence1) - 1;
    nb_nucleotides = strlen(sequence);
    
    //str_features f[nb_nucleotides]; // this doesn't work on Windows
    f = new str_features[nb_nucleotides];
    if (f == NULL) giveup ("Cannot allocate memory", "str_features");
    // detect the structure features
    detect_structure_features (structure, f);

    //int int_sequence[nb_nucleotides];
    
    //int int_sequence[nb_nucleotides];  // this doesn't work on Windows
    int_sequence = new int[nb_nucleotides];
    if (int_sequence == NULL) giveup ("Cannot allocate memory", "energy");
    for (i=0; i < nb_nucleotides; i++) int_sequence[i] = nuc_to_int(sequence[i]);
    en = p_calculate_energy (link, int_sequence, sequence, f);
    energy = en/ 100.0;
    delete [] int_sequence;
    delete [] f;
    return energy;

}


double free_energy_pairfold_always_dangle (char *sequence1, char *sequence2, char *structure)
{
    int i;
    str_features *f;
    double energy;
    int *int_sequence;
    PARAMTYPE en;
    int link, nb_nucleotides;
    char sequence[MAXSLEN];    

    // take the space out of the structure
    remove_space (structure);

    strcpy (sequence, sequence1);
    strcat (sequence, sequence2);
    link = strlen(sequence1) - 1;
    nb_nucleotides = strlen(sequence);
    
    //    str_features f[nb_nucleotides];
    f = new str_features[nb_nucleotides];
    if (f == NULL) giveup ("Cannot allocate memory", "str_features");
    // detect the structure features
    detect_structure_features (structure, f);

    //int int_sequence[nb_nucleotides];

    int_sequence = new int[nb_nucleotides];
    if (int_sequence == NULL) giveup ("Cannot allocate memory", "energy");
    for (i=0; i < nb_nucleotides; i++) int_sequence[i] = nuc_to_int(sequence[i]);
    en = p_calculate_energy_always_dangle (link, int_sequence, sequence, f);
    energy = en/ 100.0;
    delete [] int_sequence;
    delete [] f;
    return energy;

}


double enthalpy_pairfold (char *sequence1, char *sequence2, char *structure)
{
    int i;
    str_features *f;

    double energy;
    int *int_sequence;
    PARAMTYPE en;
    int link, nb_nucleotides;
    char sequence[MAXSLEN];

    // TODO: take the space out of the structure

    strcpy (sequence, sequence1);
    strcat (sequence, sequence2);
    link = strlen(sequence1) - 1;
    nb_nucleotides = strlen(sequence);
    if ((f = new str_features[nb_nucleotides]) == NULL) giveup ("Cannot allocate memory", "str_features");
    // detect the structure features
    detect_structure_features (structure, f);

    int_sequence = new int[nb_nucleotides];
    if (int_sequence == NULL) giveup ("Cannot allocate memory", "energy");
    for (i=0; i < nb_nucleotides; i++) int_sequence[i] = nuc_to_int(sequence[i]);
    en = p_calculate_enthalpy (link, int_sequence, sequence, f);
    energy = en/ 100.0;
    delete [] int_sequence;    
    delete [] f;
    return energy;
}


PARAMTYPE p_calculate_energy (int link, int *sequence, char *csequence, str_features *f)
{
    int i;
    PARAMTYPE energy, en, AUpen;
    PARAMTYPE dang;
    PARAMTYPE misc_energy;
    int h,l, nb_nucleotides;    
    static int cannot_add_dangling[MAXSLEN];
    

    nb_nucleotides = strlen (csequence);
    for (i=0; i < nb_nucleotides; i++) cannot_add_dangling[i] = 0;

    energy = 0;
    AUpen = 0;
    
    for (i=0; i < nb_nucleotides; i++)
    {
    
        // add some AU_penalties
        if ((i==0 || (i-1 == link && !cannot_add_dangling[i-1] && f[i-1].pair == -1))
             && f[i].pair > i)
        {
            AUpen = AU_penalty (sequence[i], sequence[f[i].pair]);
            if (debug)
                printf ("%d - AUpen1 \t- add energy %6d\n", i, AUpen);
            energy += AUpen;            
        }            
        else if ( i > 0 && f[i].pair > i && f[i-1].pair < i-1 &&
             f[i-1].pair != -1 && !cannot_add_dangling[i])
            //  )(  
        {            
            AUpen = AU_penalty (sequence[i], sequence[f[i].pair]);
            if (debug)
                printf ("%d - AUpen2 \t- add energy %6d\n", i, AUpen);
            energy += AUpen;            
        }            
    
        // add dangling energies and AU_penalties
        if (f[i].pair == -1 && !cannot_add_dangling[i])
        {
            if ((i == 0 || i-1 == link || (i > 0 && f[i-1].pair == -1 && i != link)) &&
                 i < nb_nucleotides-1 && f[i+1].pair > i+1)
                // .( or ..(
            {
                dang = IGINF(dangle_bot [sequence[f[i+1].pair]] [sequence[i+1]] [sequence[i]]);		// or MIN
                AUpen = AU_penalty (sequence[i+1], sequence[f[i+1].pair]);
                if (debug)
                {
                    printf ("%d - dangle1 \t- add energy %6d\n", i, dang);
                    printf ("%d - AUpen3 \t- add energy %6d\n", i, AUpen);
                }                    
                energy += dang + AUpen;
            }
            else if ((i == nb_nucleotides-1 || i == link ||
                     (i < nb_nucleotides-1 && f[i+1].pair == -1 && i-1 != link)) &&
                     i > 0 && f[i-1].pair > -1 && f[i-1].pair < i-1)
                // ). or )..
            {
                dang = IGINF(dangle_top [sequence[i-1]] [sequence[f[i-1].pair]] [sequence[i]]);		// or MIN
                if (debug)                
                    printf ("%d - dangle2 \t- add energy %6d\n", i, dang);
                energy += dang;
            }
            else if (i < nb_nucleotides-1 && f[i+1].pair > i+1 && f[i-1].pair < i-1 && f[i-1].pair != -1)
               // ).( 
            {
                dang = IGINF(p_dangling_energy (sequence, link, f[i-1].pair, i-1, i+1, f[i+1].pair));	// or MIN
                AUpen = AU_penalty (sequence[i+1], sequence[f[i+1].pair]);
                if (debug)
                {              
                    printf ("%d - dangle1 \t- add energy %6d\n", i, dang);
                    printf ("%d - AUpen4 \t- add energy %6d\n", i, AUpen);
                }    
                energy += dang + AUpen;
            }
            else
            {
                continue;
            }
        }
        
        if (f[i].pair < i)
        {
            continue;
        }       

        if (f[i].type == STACK)
        {
            en = p_stacked_pair::get_energy (i, f[i].pair, sequence, link);
            if (debug)            
                printf ("%d stack \t- add energy %6d\n", i, en);        
            energy += en;
        }
        else if (f[i].type == HAIRP)
        {
            en = p_hairpin_loop::get_energy (i, f[i].pair, sequence, csequence, link);
            if (debug)
                printf ("%d hairpin \t- add energy %6d\n", i, en);
            energy += en;
        }
        else if (f[i].type == INTER)
        {
            int ip, jp;
            ip = f[i].bri[0];
            jp = f[f[i].bri[0]].pair;
            cannot_add_dangling[ip-1] = 1;
            cannot_add_dangling[jp+1] = 1;
            en = p_internal_loop::get_energy (i, f[i].pair, ip, jp, sequence, link);
            if (debug)
                printf ("%d internal \t- add energy %6d\n", i, en);        
            energy += en;
        }
        else  // (f[i].type == MULTI)
        {
            dang = 0;
            misc_energy = 0;
            AUpen = 0;
            int special;
            special = 0;
            // add the energies/enthalpies for free bases
            // first find out if it is a regular multi-loop or a special multi-loop
            l = i;

            while (l < f[i].bri[0] && !special)
                if (l++ == link) special = 1;
            h = 0;                
            while (h < f[i].num_branches-1 && !special)
            {
                l = f[f[i].bri[h]].pair;
                while (l < f[i].bri[h+1] && !special)
                    if (l++ == link) special = 1;
                h++;    
            }
            l = f[f[i].bri[f[i].num_branches-1]].pair;
            while (l < f[i].pair && !special)
                if (l++ == link) special = 1;
            // now we now if it a special multi-loop or not                                  

            if (!special)
            {
//                printf ("Regular ML\n");
                for (l=i+1; l < f[i].bri[0]; l++)
                    misc_energy += misc.multi_free_base_penalty;
                for (h=0; h < f[i].num_branches-1; h++)
                {
                    for (l = f[f[i].bri[h]].pair + 1; l < f[i].bri[h+1]; l++)
                        misc_energy += misc.multi_free_base_penalty;
                }
                for (l = f[f[i].bri[f[i].num_branches-1]].pair + 1; l < f[i].pair; l++)
                    misc_energy += misc.multi_free_base_penalty;
                
                misc_energy += misc.multi_offset;
                misc_energy += misc.multi_helix_penalty * (f[i].num_branches + 1);
            }
            else
            {
//                printf ("Special ML\n");            
                misc_energy = misc.intermolecular_initiation;
            }                
            // add AU_penalties for multi-loop
            AUpen += AU_penalty (sequence[i], sequence[f[i].pair]);
            for (h=0; h < f[i].num_branches; h++)
                AUpen += AU_penalty (sequence[f[i].bri[h]],sequence[f[f[i].bri[h]].pair]);
        
            // add dangling energies for multi-loop
            dang += p_dangling_energy_left (sequence, link, i, f[i].pair, f[i].bri[0], f[f[i].bri[0]].pair);
            for (l=0; l < f[i].num_branches - 1; l++)
                dang += p_dangling_energy (sequence, link, f[i].bri[l], f[f[i].bri[l]].pair, f[i].bri[l+1], f[f[i].bri[l+1]].pair);
            dang += p_dangling_energy_right (sequence, link, i, f[i].pair, f[i].bri[f[i].num_branches-1], f[f[i].bri[f[i].num_branches-1]].pair);

            // add "no-dangling" restriction                                    
            for (l=0; l < f[i].num_branches; l++)
            {
                cannot_add_dangling [f[i].bri[l] -1] = 1;
                cannot_add_dangling [f[f[i].bri[l]].pair + 1] = 1;
            }
            if (debug)
            {
                printf ("%d - multi m\t- add energy %6d\n", i, misc_energy);            
                printf ("%d - multi d\t- add energy %6d\n", i, dang);
                printf ("%d - multi AU\t- add energy %6d\n", i, AUpen);
            }                
            energy += misc_energy + dang + AUpen;                           
        }
    }
    return energy;
}



PARAMTYPE p_calculate_energy_always_dangle (int link, int *sequence, char *csequence, str_features *f)
// calculate the free energy, when the dangling energies are always added
{
    int i;
    PARAMTYPE energy, en, AUpen;
    PARAMTYPE dang;
    PARAMTYPE misc_energy;
    int h,l, nb_nucleotides;    
    static int cannot_add_dangling[MAXSLEN];
    

    nb_nucleotides = strlen (csequence);
    for (i=0; i < nb_nucleotides; i++) cannot_add_dangling[i] = 0;

    energy = 0;
    AUpen = 0;
    
    for (i=0; i < nb_nucleotides; i++)
    {
    
        // add some AU_penalties
        if ((i==0 || (i-1 == link && !cannot_add_dangling[i-1] && f[i-1].pair == -1))
             && f[i].pair > i)
        {
            AUpen = AU_penalty (sequence[i], sequence[f[i].pair]);
            if (debug)
                printf ("%d - AUpen1 \t- add energy %6d\n", i, AUpen);
            energy += AUpen;            
        }            
        else if ( i > 0 && f[i].pair > i && f[i-1].pair < i-1 &&
             f[i-1].pair != -1 && !cannot_add_dangling[i])
            //  )(  
        {            
            AUpen = AU_penalty (sequence[i], sequence[f[i].pair]);
            dang = IGINF (dangle_top [sequence[i-1]][sequence[f[i-1].pair]][sequence[i]]) + 	// or MIN
                        IGINF (dangle_bot [sequence[f[i].pair]][sequence[i]][sequence[i-1]]);	// or MIN
           if (debug)
                printf ("%d - AUpen2 \t- add energy %6d\n", i, AUpen);
            energy += dang + AUpen;            
        }            
    
        // add dangling energies and AU_penalties
        if (f[i].pair == -1 && !cannot_add_dangling[i])
        {
            if ((i == 0 || i-1 == link || (i > 0 && f[i-1].pair == -1 && i != link)) &&
                 i < nb_nucleotides-1 && f[i+1].pair > i+1)
                // .( or ..(
            {
                dang = IGINF(dangle_bot [sequence[f[i+1].pair]] [sequence[i+1]] [sequence[i]]);		// or MIN
                AUpen = AU_penalty (sequence[i+1], sequence[f[i+1].pair]);
                if (debug)
                {
                    printf ("%d - dangle1 \t- add energy %6d\n", i, dang);
                    printf ("%d - AUpen3 \t- add energy %6d\n", i, AUpen);
                }                    
                energy += dang + AUpen;
            }
            else if ((i == nb_nucleotides-1 || i == link ||
                     (i < nb_nucleotides-1 && f[i+1].pair == -1 && i-1 != link)) &&
                     i > 0 && f[i-1].pair > -1 && f[i-1].pair < i-1)
                // ). or )..
            {
                dang = IGINF(dangle_top [sequence[i-1]] [sequence[f[i-1].pair]] [sequence[i]]);		// or MIN
                if (debug)                
                    printf ("%d - dangle2 \t- add energy %6d\n", i, dang);
                energy += dang;
            }
            else if (i < nb_nucleotides-1 && f[i+1].pair > i+1 && f[i-1].pair < i-1 && f[i-1].pair != -1)
               // ).( 
              {
                dang = IGINF (dangle_top [sequence[i-1]][sequence[f[i-1].pair]][sequence[i]]) +		// or MIN
                          IGINF (dangle_bot [sequence[f[i+1].pair]][sequence[i+1]][sequence[i]]);	// or MIN
              //dang = MIN (0, IGINF(dangling_energy (sequence, link, f[i-1].pair, i-1, i+1, f[i+1].pair)));
                AUpen = AU_penalty (sequence[i+1], sequence[f[i+1].pair]);
                if (debug)
                {              
                    printf ("%d - dangle1 \t- add energy %6d\n", i, dang);
                    printf ("%d - AUpen4 \t- add energy %6d\n", i, AUpen);
                }    
                energy += dang + AUpen;
            }
            else
            {
                continue;
            }
        }
        
        if (f[i].pair < i)
        {
            continue;
        }       

        if (f[i].type == STACK)
        {
            en = p_stacked_pair::get_energy (i, f[i].pair, sequence, link);
            if (debug)            
                printf ("%d stack \t- add energy %6d\n", i, en);        
            energy += en;
        }
        else if (f[i].type == HAIRP)
        {
            en = p_hairpin_loop::get_energy (i, f[i].pair, sequence, csequence, link);
            if (debug)
                printf ("%d hairpin \t- add energy %6d\n", i, en);
            energy += en;
        }
        else if (f[i].type == INTER)
        {
            int ip, jp;
            ip = f[i].bri[0];
            jp = f[f[i].bri[0]].pair;
            cannot_add_dangling[ip-1] = 1;
            cannot_add_dangling[jp+1] = 1;
            en = p_internal_loop::get_energy (i, f[i].pair, ip, jp, sequence, link);
            if (debug)
                printf ("%d internal \t- add energy %6d\n", i, en);        
            energy += en;
        }
        else  // (f[i].type == MULTI)
        {
            dang = 0;
            misc_energy = 0;
            AUpen = 0;
            int special;
            special = 0;
            // add the energies/enthalpies for free bases
            // first find out if it is a regular multi-loop or a special multi-loop
            l = i;

            while (l < f[i].bri[0] && !special)
                if (l++ == link) special = 1;
            h = 0;                
            while (h < f[i].num_branches-1 && !special)
            {
                l = f[f[i].bri[h]].pair;
                while (l < f[i].bri[h+1] && !special)
                    if (l++ == link) special = 1;
                h++;    
            }
            l = f[f[i].bri[f[i].num_branches-1]].pair;
            while (l < f[i].pair && !special)
                if (l++ == link) special = 1;
            // now we now if it a special multi-loop or not                                  

            if (!special)
            {
//                printf ("Regular ML\n");
                for (l=i+1; l < f[i].bri[0]; l++)
                    misc_energy += misc.multi_free_base_penalty;
                for (h=0; h < f[i].num_branches-1; h++)
                {
                    for (l = f[f[i].bri[h]].pair + 1; l < f[i].bri[h+1]; l++)
                        misc_energy += misc.multi_free_base_penalty;
                }
                for (l = f[f[i].bri[f[i].num_branches-1]].pair + 1; l < f[i].pair; l++)
                    misc_energy += misc.multi_free_base_penalty;
                
                misc_energy += misc.multi_offset;
                misc_energy += misc.multi_helix_penalty * (f[i].num_branches + 1);
            }
            else
            {
//                printf ("Special ML\n");            
                misc_energy = misc.intermolecular_initiation;
            }                
            // add AU_penalties for multi-loop
            AUpen += AU_penalty (sequence[i], sequence[f[i].pair]);
            for (h=0; h < f[i].num_branches; h++)
                AUpen += AU_penalty (sequence[f[i].bri[h]],sequence[f[f[i].bri[h]].pair]);
        
            // add dangling energies for multi-loop
            //dang += dangling_energy_left (sequence, link, i, f[i].pair, f[i].bri[0], f[f[i].bri[0]].pair);
            int i0, j0, i1, j1;
            i0 = i;
            j0 = f[i].pair;
            i1 = f[i].bri[0];
            j1 = f[f[i].bri[0]].pair;
            dang += IGINF (dangle_top [sequence[i0]][sequence[j0]][sequence[i0+1]]) +		// or MIN
              IGINF (dangle_bot [sequence[j1]][sequence[i1]][sequence[i1-1]]);			// or MIN

            for (l=0; l < f[i].num_branches - 1; l++)
              {
                //dang += dangling_energy (sequence, link, f[i].bri[l], f[f[i].bri[l]].pair, f[i].bri[l+1], f[f[i].bri[l+1]].pair);
                int il, jl, im, jm;
                il = f[i].bri[l];
                jl = f[f[i].bri[l]].pair;
                im = f[i].bri[l+1];
                jm = f[f[i].bri[l+1]].pair;
                dang += IGINF (dangle_top [sequence[jl]][sequence[il]][sequence[jl+1]])+	// or MIN
                  IGINF (dangle_bot [sequence[jm]][sequence[im]][sequence[im-1]]);		// or MIN
              }

            //dang += dangling_energy_right (sequence, link, i, f[i].pair, f[i].bri[f[i].num_branches-1], f[f[i].bri[f[i].num_branches-1]].pair);
            i0 = i;
            j0 = f[i].pair;
            int in, jn;
            in = f[i].bri[f[i].num_branches-1];
            jn = f[f[i].bri[f[i].num_branches-1]].pair;
            dang += IGINF (dangle_top [sequence[jn]][sequence[in]][sequence[jn+1]]) +	// or MIN
              IGINF (dangle_bot [sequence[i0]][sequence[j0]][sequence[j0-1]]);		// or MIN

            // add "no-dangling" restriction                                    
            for (l=0; l < f[i].num_branches; l++)
            {
                cannot_add_dangling [f[i].bri[l] -1] = 1;
                cannot_add_dangling [f[f[i].bri[l]].pair + 1] = 1;
            }
            if (debug)
            {
                printf ("%d - multi m\t- add energy %6d\n", i, misc_energy);            
                printf ("%d - multi d\t- add energy %6d\n", i, dang);
                printf ("%d - multi AU\t- add energy %6d\n", i, AUpen);
            }                
            energy += misc_energy + dang + AUpen;                           
        }
    }
    return energy;
}



PARAMTYPE p_calculate_enthalpy (int link, int *sequence, char *csequence, str_features *f)
{
    int i;
    PARAMTYPE energy, en, AUpen;
    PARAMTYPE dang;
    PARAMTYPE misc_energy;
    int h,l, nb_nucleotides;
    static int cannot_add_dangling[MAXSLEN];


    nb_nucleotides = strlen (csequence);
    for (i=0; i < nb_nucleotides; i++) cannot_add_dangling[i] = 0;

    energy = 0;
    AUpen = 0;

    for (i=0; i < nb_nucleotides; i++)
    {

        // add some AU_penalties
        if ((i==0 || (i-1 == link && !cannot_add_dangling[i-1] && f[i-1].pair == -1))
             && f[i].pair > i)
        {
            AUpen = AU_penalty_enthalpy (sequence[i], sequence[f[i].pair]);
            if (debug)
                printf ("%d - AUpen1 \t- add energy %6d\n", i, AUpen);
            energy += AUpen;
        }
        else if ( i > 0 && f[i].pair > i && f[i-1].pair < i-1 &&
             f[i-1].pair != -1 && !cannot_add_dangling[i])
            //  )(
        {
            AUpen = AU_penalty_enthalpy (sequence[i], sequence[f[i].pair]);
            if (debug)
                printf ("%d - AUpen2 \t- add energy %6d\n", i, AUpen);
            energy += AUpen;
        }

        // add dangling energies and AU_penalties
        if (f[i].pair == -1 && !cannot_add_dangling[i])
        {
            if ((i == 0 || i-1 == link || (i > 0 && f[i-1].pair == -1 && i != link)) &&
                 i < nb_nucleotides-1 && f[i+1].pair > i+1)
                // .( or ..(
            {
                dang = enthalpy_dangle_bot [sequence[f[i+1].pair]] [sequence[i+1]] [sequence[i]];	// or MIN
                AUpen = AU_penalty_enthalpy (sequence[i+1], sequence[f[i+1].pair]);
                if (debug)
                {
                    printf ("%d - dangle1 \t- add energy %6d\n", i, dang);
                    printf ("%d - AUpen3 \t- add energy %6d\n", i, AUpen);
                }
                energy += dang + AUpen;
            }
            else if ((i == nb_nucleotides-1 || i == link ||
                     (i < nb_nucleotides-1 && f[i+1].pair == -1 && i-1 != link)) &&
                     i > 0 && f[i-1].pair > -1 && f[i-1].pair < i-1)
                // ). or )..
            {
                dang = enthalpy_dangle_top [sequence[i-1]] [sequence[f[i-1].pair]] [sequence[i]];	// or MIN
                if (debug)
                    printf ("%d - dangle2 \t- add energy %6d\n", i, dang);
                energy += dang;
            }
            else if (i < nb_nucleotides-1 && f[i+1].pair > i+1 && f[i-1].pair < i-1 && f[i-1].pair != -1)
               // ).(
            {
                dang = p_dangling_enthalpy (sequence, link, f[i-1].pair, i-1, i+1, f[i+1].pair);	// or MIN
                AUpen = AU_penalty_enthalpy (sequence[i+1], sequence[f[i+1].pair]);
                if (debug)
                {
                    printf ("%d - dangle1 \t- add energy %6d\n", i, dang);
                    printf ("%d - AUpen4 \t- add energy %6d\n", i, AUpen);
                }
                energy += dang + AUpen;
            }
            else
            {
                continue;
            }
        }

        if (f[i].pair < i)
        {
            continue;
        }

        if (f[i].type == STACK)
        {
            en = p_stacked_pair::get_enthalpy (i, f[i].pair, sequence, link);
            if (debug)
                printf ("%d stack \t- add energy %6d\n", i, en);
            energy += en;
        }
        else if (f[i].type == HAIRP)
        {
            en = p_hairpin_loop::get_enthalpy (i, f[i].pair, sequence, csequence, link);
            if (debug)
                printf ("%d hairpin \t- add energy %6d\n", i, en);
            energy += en;
        }
        else if (f[i].type == INTER)
        {
            int ip, jp;
            ip = f[i].bri[0];
            jp = f[f[i].bri[0]].pair;
            cannot_add_dangling[ip-1] = 1;
            cannot_add_dangling[jp+1] = 1;
            en = p_internal_loop::get_enthalpy (i, f[i].pair, ip, jp, sequence, link);
            if (debug)
                printf ("%d internal \t- add energy %6d\n", i, en);
            energy += en;
        }
        else  // (f[i].type == MULTI)
        {
            dang = 0;
            misc_energy = 0;
            AUpen = 0;
            int special;
            special = 0;
            // add the energies/enthalpies for free bases
            // first find out if it is a regular multi-loop or a special multi-loop
            l = i;
            while (l < f[i].bri[0] && !special)
                if (l++ == link) special = 1;
            h = 0;
            while (h < f[i].num_branches-1 && !special)
            {
                l = f[f[i].bri[h]].pair;
                while (l < f[i].bri[h+1] && !special)
                    if (l++ == link) special = 1;
                h++;
            }
            l = f[f[i].bri[f[i].num_branches-1]].pair;
            while (l < f[i].pair && !special)
                if (l++ == link) special = 1;
            // now we now if it a special multi-loop or not

            if (!special)
            {
//                printf ("Regular ML\n");
                for (l=i+1; l < f[i].bri[0]; l++)
                    misc_energy += enthalpy_misc.multi_free_base_penalty;
                for (h=0; h < f[i].num_branches-1; h++)
                {
                    for (l = f[f[i].bri[h]].pair + 1; l < f[i].bri[h+1]; l++)
                        misc_energy += enthalpy_misc.multi_free_base_penalty;
                }
                for (l = f[f[i].bri[f[i].num_branches-1]].pair + 1; l < f[i].pair; l++)
                    misc_energy += enthalpy_misc.multi_free_base_penalty;


                misc_energy += enthalpy_misc.multi_offset;
                misc_energy += enthalpy_misc.multi_helix_penalty * (f[i].num_branches + 1);
            }
            else
            {
//                printf ("Special ML\n");
                misc_energy = enthalpy_misc.intermolecular_initiation;
            }
            // add AU_penalties for multi-loop
            AUpen += AU_penalty_enthalpy (sequence[i], sequence[f[i].pair]);
            for (h=0; h < f[i].num_branches; h++)
                AUpen += AU_penalty_enthalpy (sequence[f[i].bri[h]],sequence[f[f[i].bri[h]].pair]);

            // add dangling energies for multi-loop
            dang += p_dangling_enthalpy_left (sequence, link, i, f[i].pair, f[i].bri[0], f[f[i].bri[0]].pair);
            for (l=0; l < f[i].num_branches - 1; l++)
                dang += p_dangling_enthalpy (sequence, link, f[i].bri[l], f[f[i].bri[l]].pair, f[i].bri[l+1], f[f[i].bri[l+1]].pair);
            dang += p_dangling_enthalpy_right (sequence, link, i, f[i].pair, f[i].bri[f[i].num_branches-1], f[f[i].bri[f[i].num_branches-1]].pair);

            // add "no-dangling" restriction
            for (l=0; l < f[i].num_branches; l++)
            {
                cannot_add_dangling [f[i].bri[l] -1] = 1;
                cannot_add_dangling [f[f[i].bri[l]].pair + 1] = 1;
            }
            if (debug)
            {
                printf ("%d - multi m\t- add energy %6d\n", i, misc_energy);
                printf ("%d - multi d\t- add energy %6d\n", i, dang);
                printf ("%d - multi AU\t- add energy %6d\n", i, AUpen);
            }
            energy += misc_energy + dang + AUpen;
        }
    }
    return energy;
}



double pairfold_mfe (char *sequence1, char *sequence2, char *structure)
{
    double min_energy;
    p_min_folding *min_fold = new p_min_folding (sequence1, sequence2, structure);
    min_energy = min_fold->pairfold();
    if (structure != NULL)
    {
        //min_fold->return_structure (structure);
    }    
    delete min_fold;
    return min_energy;
}    


double pairfold_mfe_nointra (char *sequence1, char *sequence2, char *structure, int max_internal_loop_size)
{
    double min_energy;
    max_internal_loop = max_internal_loop_size;
    p_min_folding *min_fold = new p_min_folding (sequence1, sequence2, structure);
    min_energy = min_fold->pairfold_nointra();
    if (structure != NULL)
    {
        //min_fold->return_structure (structure);
    }    
    delete min_fold;
    return min_energy;
}    


double simfold_slow (char *sequence, char *structure)
{
    double min_energy;
    p_min_folding *min_fold = new p_min_folding (sequence);
    min_energy = min_fold->simfold_slow();
    min_fold->return_structure (structure);
    delete min_fold;
    return min_energy;
}

long pairfold_ordered_suboptimals (char *sequence1, char *sequence2, int number, char structures[][MAXSLEN], double energies[])
{
    int i, actual_num_str;
    char structure[MAXSLEN];
    double min_energy, enthalpy;

    int positions[2*MAXSUBSTR];
    char tmp_structures[2*MAXSUBSTR][MAXSLEN];
    double tmp_energies[2*MAXSUBSTR];
    // stack allocation with a variable doesn't work in windows
    //int positions[number*2];
    //char tmp_structures[2*number][MAXSLEN];
    //double tmp_energies[2*number];
    long thrown;
    p_sub_folding* pair_seq;

/*
    char **tmp_structures;
    (*tmp_structures) = new char[number];
    len = strlen (sequence1) + strlen (sequence2);
    for (i=0; i < number; i++)
    {
          tmp_structures[i] = new char[len+1];
    }        
*/
    p_min_folding *min_fold = new p_min_folding (sequence1, sequence2, structure);
    min_energy = min_fold->pairfold();
    min_fold->return_structure (structure);

    delete min_fold;
  
    //printf ("%s %s\n%s\t%.2lf (%.2lf) (%.2lf)\n", sequence1, sequence2, structure, min_energy, free_energy_pairfold (sequence1, sequence2, structure), free_energy_pairfold_always_dangle (sequence1, sequence2, structure)); 

    
    if (number == 1)
      {
        strcpy (structures[0], structure);
        energies[0] = min_energy;
      }
    else
      {    
        //printf ("R1: %s %d\nR2: %s %d\n\n", sequence1, strlen(sequence1), sequence2, strlen(sequence2));
        pair_seq = new p_sub_folding(sequence1, sequence2, 50000);
        pair_seq->set_limit(2*number);
        pair_seq->pairfold (enthalpy);
        thrown = pair_seq->get_num_partial_structures_thrown_away();
        actual_num_str = pair_seq->return_structures(tmp_structures, tmp_energies);
        printf ("Actual ordered: %d\n", actual_num_str);
        delete pair_seq;            
        
        for (i=0; i < actual_num_str; i++)
          {
            tmp_energies[i] = free_energy_pairfold (sequence1, sequence2, tmp_structures[i]);
          }
        
        get_sorted_positions (actual_num_str, tmp_energies, positions);
        int MFE_there, ii;
        MFE_there = 0;
        ii = 0;
        
        if (min_energy != tmp_energies[positions[0]])
          {
            //printf ("MFE1 %s    %.2lf \n =======\n", i+1, structure, energy);
            strcpy (structures[ii], structure);
            energies[ii] = min_energy;
            ii++;
          }
        else 
          {
            i = 0;
            while (tmp_energies[positions[i]] == min_energy)
              {
                if (strcmp (structure, tmp_structures[positions[i]]) == 0)
                  {
                    MFE_there = 1;
                    //printf ("MFE is subseq: ordered=%d, original=%d\n", i, positions[i]);
                    break;
                  }
                i++;
              }
            if (!MFE_there)
              {
                //printf ("MFE2 %s    %.2lf \n =======\n", i+1, structure, energy);
                strcpy (structures[ii], structure);
                energies[ii] = min_energy;
                ii++;
              }
          }

        for (i=0; i < actual_num_str; i++)
          {
            //printf ("%2d  %s    %.2lf \n =======\n", i+1, tmp_structures[positions[i]], tmp_energies[positions[i]]);
            strcpy (structures[ii], tmp_structures[positions[i]]);
            energies[ii] = tmp_energies[positions[i]];
            ii++;
          }                
      }
   return thrown;        
}


int pairfold_ordered_suboptimals_range (char *sequence1, char *sequence2, double energy_range, char structures[][MAXSLEN], double energies[])
// input: sequence1, sequence2, energy range
// output: structures, energies
// returns: number of structures that were found between the predicted MFE and MFE + energy_range
{
    int i;
    int actual_num_str;
    int number;
    char structure[MAXSLEN];
    double min_energy, enthalpy;

    p_sub_folding* pair_seq = new p_sub_folding(sequence1, sequence2, (int) (energy_range*100));
    pair_seq->pairfold (enthalpy);
    number = pair_seq->return_structures(structures, energies);
    delete pair_seq;
    
    int positions[2*MAXSUBSTR];
    char tmp_structures[2*MAXSUBSTR][MAXSLEN];
    double tmp_energies[2*MAXSUBSTR];

    //char tmp_structures[2*number][MAXSLEN];
    //double tmp_energies[2*number];
    //int positions[number*2];


    p_min_folding *min_fold = new p_min_folding (sequence1, sequence2, structure);
    min_energy = min_fold->pairfold();
    min_fold->return_structure (structure);

    delete min_fold;
  
    //printf ("%s %s\n%s\t%.2lf (%.2lf) (%.2lf)\n", sequence1, sequence2, structure, min_energy, free_energy_pairfold (sequence1, sequence2, structure), free_energy_pairfold_always_dangle (sequence1, sequence2, structure)); 

    
    if (number == 1)
      {
        strcpy (structures[0], structure);
        energies[0] = min_energy;
      }
    else
      {

    
        //printf ("R1: %s %d\nR2: %s %d\n\n", sequence1, strlen(sequence1), sequence2, strlen(sequence2));
        p_sub_folding* pair_seq = new p_sub_folding(sequence1, sequence2, 5* (int) (energy_range*100));
        pair_seq->set_limit(2*number);
        pair_seq->pairfold (enthalpy);
        actual_num_str = pair_seq->return_structures(tmp_structures, tmp_energies);
        //        printf ("Actual ordered: %d\n", actual_num_str);
        
        for (i=0; i < actual_num_str; i++)
          {
            tmp_energies[i] = free_energy_pairfold (sequence1, sequence2, tmp_structures[i]);
          }
        delete pair_seq;  
        
        get_sorted_positions (actual_num_str, tmp_energies, positions);
        int MFE_there, ii;
        MFE_there = 0;
        ii = 0;
        
        if (min_energy != tmp_energies[positions[0]])
          {
            //printf ("MFE1 %s    %.2lf \n =======\n", i+1, structure, energy);
            strcpy (structures[ii], structure);
            energies[ii] = min_energy;
            ii++;
          }
        else 
          {
            i = 0;
            while (tmp_energies[positions[i]] == min_energy)
              {
                if (strcmp (structure, tmp_structures[positions[i]]) == 0)
                  {
                    MFE_there = 1;
                    //printf ("MFE is subseq: ordered=%d, original=%d\n", i, positions[i]);
                    break;
                  }
                i++;
              }
            if (!MFE_there)
              {
                //printf ("MFE2 %s    %.2lf \n =======\n", i+1, structure, energy);
                strcpy (structures[ii], structure);
                energies[ii] = min_energy;
                ii++;
              }
          }

        number = 0;
        i=0;
        while (tmp_energies[positions[i]] <= min_energy + energy_range)
          {
            //printf ("%2d  %s    %.2lf \n =======\n", i+1, tmp_structures[positions[i]], tmp_energies[positions[i]]);
            strcpy (structures[ii], tmp_structures[positions[i]]);
            energies[ii] = tmp_energies[positions[i]];
            ii++;
            i++;
            number++;
          }
      }
   return number;        
}




void pairfold_unordered_suboptimals (char *sequence1, char *sequence2, int number, char structures[][MAXSLEN], double energies[])
{
    int actual_num_str;
    char structure[MAXSLEN];
    double min_energy, enthalpy;

    p_min_folding *min_fold = new p_min_folding (sequence1, sequence2, structure);
    min_energy = min_fold->pairfold();
    min_fold->return_structure (structure);

    delete min_fold;
  
    //printf ("%s %s\n%s\t%.2lf (%.2lf) (%.2lf)\n", sequence1, sequence2, structure, min_energy, free_energy_pairfold (sequence1, sequence2, structure), free_energy_pairfold_always_dangle (sequence1, sequence2, structure)); 

    
    if (number == 1)
      {
        strcpy (structures[0], structure);
        energies[0] = min_energy;
      }
    else
      {    
        //printf ("R1: %s %d\nR2: %s %d\n\n", sequence1, strlen(sequence1), sequence2, strlen(sequence2));
        p_sub_folding* pair_seq = new p_sub_folding(sequence1, sequence2, 5000);
        pair_seq->set_limit(number);
        pair_seq->pairfold (enthalpy);
        actual_num_str = pair_seq->return_structures(structures, energies);
        //        printf ("Actual unordered: %d\n", actual_num_str);
        delete pair_seq;
      }

}



int simfold_slow_unordered_suboptimals (char *sequence, int number, char structures[][MAXSLEN], double energies[])
{
    int actual_num_str;
    char structure[MAXSLEN];
    double min_energy, enthalpy;

    p_min_folding *min_fold = new p_min_folding (sequence);
    min_energy = min_fold->simfold_slow();
    min_fold->return_structure (structure);

    delete min_fold;
  
    //printf ("%s %s\n%s\t%.2lf (%.2lf) (%.2lf)\n", sequence1, sequence2, structure, min_energy, free_energy_pairfold (sequence1, sequence2, structure), free_energy_pairfold_always_dangle (sequence1, sequence2, structure)); 

    
    if (number == 1)
      {
        strcpy (structures[0], structure);
        energies[0] = min_energy;
      }
    else
      {    
        //printf ("R1: %s %d\nR2: %s %d\n\n", sequence1, strlen(sequence1), sequence2, strlen(sequence2));
        p_sub_folding* pair_seq = new p_sub_folding(sequence, 5000);
        pair_seq->set_limit(number);
        pair_seq->p_simfold_slow (enthalpy);
        actual_num_str = pair_seq->return_structures(structures, energies);
        //        printf ("Actual unordered: %d\n", actual_num_str);
        delete pair_seq;
      }
    return actual_num_str;
      
}



