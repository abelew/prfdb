/***************************************************************************
                          p_min_folding.cpp  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// Supposing we have the energy matrixes constructed, we compute the MFE

#include <stdio.h>
#include <string.h>

#include "p_min_folding.h"
#include "constants.h"
#include "structs.h"
#include "externs.h"
#include "common.h"
#include "pairfold.h"
#include "p_hairpin_loop.h"
#include "p_stacked_pair.h"
#include "p_multi_loop.h"
#include "p_energy_matrix.h"


 
p_min_folding::p_min_folding (char *sequence)
{
    check_sequence (sequence);
    this->sequence = sequence;
    link = -1;
    allocate_space();
}


p_min_folding::p_min_folding (char *sequence1, char *sequence2, char *structure)
{
    check_sequence (sequence1);
    check_sequence (sequence2);
    sequence = new char [strlen(sequence1)+strlen(sequence2)+1];
    strcpy (sequence, sequence1);
    strcat (sequence, sequence2);
    link = strlen(sequence1)-1;
    this->structure = structure;
    allocate_space();
}


void p_min_folding::allocate_space()
{
    int i;
    self_comp = 0;
    nb_nucleotides = strlen(sequence);
    // allocate the necessary memory
    f = new minimum_fold [nb_nucleotides];
    if (f == NULL) giveup ("Cannot allocate memory", "energy");
    W = new PARAMTYPE [nb_nucleotides];
    if (W == NULL) giveup ("Cannot allocate memory", "energy");
    for (i=0; i < nb_nucleotides; i++) W[i] = 0;

    int_sequence = new int[nb_nucleotides];
    if (int_sequence == NULL) giveup ("Cannot allocate memory", "energy");
    for (i=0; i < nb_nucleotides; i++) int_sequence[i] = nuc_to_int(sequence[i]);

    H = new p_hairpin_loop (sequence, int_sequence, link, nb_nucleotides);
    if (H == NULL) giveup ("Cannot allocate memory", "energy");
    S = new p_stacked_pair (int_sequence, link, nb_nucleotides);
    if (S == NULL) giveup ("Cannot allocate memory", "energy");
    VBI = new p_internal_loop (int_sequence, link, nb_nucleotides);
    if (VBI == NULL) giveup ("Cannot allocate memory", "energy");
    VM = new p_multi_loop (int_sequence, link, nb_nucleotides);
    if (VM == NULL) giveup ("Cannot allocate memory", "energy");
    V = new p_energy_matrix (int_sequence, link, nb_nucleotides);
    if (V == NULL) giveup ("Cannot allocate memory", "energy");

    // initialize the structure

    if (structure != NULL)
    {
        //structure = new char[nb_nucleotides+2];    // the structure is allocated anyway
        for (i=0; i<nb_nucleotides; i++)  structure[i] = '.';
        structure[nb_nucleotides] = '\0';
    }    

    S->set_energy_matrix (V);
    VBI->set_energy_matrix (V);
    VM->set_energy_matrix (V);
    V->set_loops (H, S, VBI, VM, NULL);

}


p_min_folding::~p_min_folding()
{
    delete V;
    delete VM;
    delete VBI;
    delete S;
    delete H;
    delete [] f;
    delete [] W;
    delete [] int_sequence;
    //delete [] structure;
    if (link > -1)
        delete [] sequence;
    // releasing stack_interval list    
    // the stack interval is already empty at this stage
    /*
    seq_interval *tmp;
    tmp = stack_interval;
    while (tmp != NULL)
    {
        stack_interval = tmp->next;
        delete tmp;
        tmp = stack_interval;
    } 
    */   
}


double p_min_folding::simfold_slow ()
// PRE:  None
// POST: fold sequence
{
    double energy;
    energy = fold_sequence ();
    return energy;
}


double p_min_folding::pairfold ()
// PRE:  None
// POST: fold sequence
{
    double energy;
    energy = fold_sequence ();
    if (structure != NULL)
    {
        insert_space (structure, link);
    }    
    //printf ("Structure in pairfold function\n%s\n", structure);
    if (self_comp) energy += 0.43;
    return energy;
}

double p_min_folding::pairfold_nointra ()
// PRE:  None
// POST: fold sequence
{
    double energy;
    energy = fold_sequence_nointra ();
    if (structure != NULL)
    {
        insert_space (structure, link);
    }    
    //printf ("Structure in pairfold function\n%s\n", structure);
    if (self_comp) energy += 0.43;
    return energy;
}



double p_min_folding::fold_sequence ()
{
    double energy;
    int i, j;

    for (j=0; j < nb_nucleotides; j++)
    {
        for (i=0; i<j; i++)
        {
            V->compute_energy (i,j);
        }
        // if I put this be    e V calculation, WM(i,j) cannot be calculated, because it returns infinity

        VM->compute_energy_WM (j);
        if (link > 0)
            VM->compute_energy_WM_link (j);            
    }

    for (j=1; j < nb_nucleotides; j++)
    {
        compute_W (j);
    }

    energy = W[nb_nucleotides-1]/100.0;
    //printf ("Energy: %lf\n---\nNow backtracking...\n", energy);

    // backtrack

    // first add (0,n-1) on the stack

    if (structure != NULL)
    {
        stack_interval = new seq_interval;
        stack_interval->i = 0;
        stack_interval->j = nb_nucleotides - 1;
        stack_interval->energy = W[nb_nucleotides-1]; 
        stack_interval->type = FREE;
        stack_interval->next = NULL;
    
        seq_interval *cur_interval = stack_interval;
    
        while ( cur_interval != NULL)
        { 
            stack_interval = stack_interval->next;
            backtrack (cur_interval);
            delete cur_interval;
            //printf ("Releasing stack_interval\n");
            cur_interval = stack_interval;
        }
    
        if (debug)
        {
            print_result ();
        }
    }    
    return energy;
}


double p_min_folding::fold_sequence_nointra ()
// j will only go inside sequence2, and i will only go inside sequence1
{
    double energy;
    int i, j;

    for (j=link+1; j < nb_nucleotides; j++)
    {
        for (i=0; i <= link; i++)
        {
            V->compute_energy (i,j);
        }
        // no multi-loops can be formed
    }    
        
    for (j=1; j < nb_nucleotides; j++)
    {
        compute_W_nointra (j);
    }
    energy = W[nb_nucleotides-1]/100.0;    
    
    if (structure != NULL)
    {
        stack_interval = new seq_interval;
        stack_interval->i = 0;
        stack_interval->j = nb_nucleotides - 1;
        stack_interval->energy = W[nb_nucleotides-1]; 
        stack_interval->type = FREE;
        stack_interval->next = NULL;
    
        seq_interval *cur_interval = stack_interval;
    
        while ( cur_interval != NULL)
        { 
            stack_interval = stack_interval->next;
            backtrack (cur_interval);
            delete cur_interval;
            //printf ("Releasing stack_interval\n");
            cur_interval = stack_interval;
        }
    
        if (debug)
        {
            print_result ();
        }
    }    
    return energy;
}



void p_min_folding::insert_node (int i, int j, char type)
  // insert at the beginning
{  
    //printf ("adding to stack_interval\n");
    seq_interval *tmp;
    tmp = new seq_interval;
    tmp->i = i;
    tmp->j = j;
    tmp->type = type;
    tmp->next = stack_interval;
    stack_interval = tmp;
    //printf ("");  //what's wrong???
}



void p_min_folding::backtrack (seq_interval *cur_interval)
// PRE:  All matrixes V, VM, WM and W have been filled
// POST: Discover the MFE path
{
    char type;
    int i, j, k;

    if(cur_interval->type == LOOP)
    {
        i = cur_interval->i;
        j = cur_interval->j;
        f[i].pair = j;
        f[j].pair = i;
        structure[i] = '(';
        structure[j] = ')';
      
        type = V->get_type (i,j);
        if (debug) 
            printf ("\t(%d,%d) LOOP - type %c\n", i,j,type);
        if (type == STACK)
        {
            f[i].type = STACK;
            f[j].type = STACK;
            insert_node (i+1, j-1, LOOP);
        }
        else if (type == HAIRP)
        {
            f[i].type = HAIRP;
            f[j].type = HAIRP;
        }
        else if (type == INTER) 
        {
            f[i].type = INTER;
            f[j].type = INTER;
            // detect the other closing pair
            int ip, jp, best_ip, best_jp, minq;
            PARAMTYPE tmp, min;
            min = INF;
            for (ip = i+1; ip <= MIN(j-2,i+max_internal_loop+1); ip++) 
            {
                minq = MAX (j-i+ip-max_internal_loop-2, ip+1);    
                for (jp = minq; jp < j; jp++)
                {
                    tmp = VBI->get_energy_str (i,j,ip,jp);
                    if (tmp < min)
                    {
                        min = tmp;
                        best_ip = ip;
                        best_jp = jp;
                    }
                }
            }
            insert_node (best_ip, best_jp, LOOP);
        }
        else if (type == MULTI)
        {
            f[i].type = MULTI;
            f[j].type = MULTI;
            int k, best_k, best_row;
            PARAMTYPE tmp, min;
            min = INF;
            for (k = i+TURN+1; k <= j-TURN-2; k++)
              {
                tmp = VM->get_energy_WM (i+1,k) + VM->get_energy_WM (k+1, j-1);
                if (tmp < min)
                  {
                    min = tmp;
                    best_k = k;
                    best_row = 1;
                  }
                tmp = VM->get_energy_WM (i+2,k) + VM->get_energy_WM (k+1, j-1) + 
                  dangle_top [int_sequence[i]][int_sequence[j]][int_sequence[i+1]] + 
                  misc.multi_free_base_penalty;
                if (tmp < min)
                  {
                    min = tmp;
                    best_k = k;
                    best_row = 2;
                  }
                tmp = VM->get_energy_WM (i+1,k) + VM->get_energy_WM (k+1, j-2) + 
                  dangle_bot [int_sequence[i]][int_sequence[j]][int_sequence[j-1]] + 
                  misc.multi_free_base_penalty;
                if (tmp < min)
                  {
                    min = tmp;
                    best_k = k;
                    best_row = 3;
                  }
                tmp = VM->get_energy_WM (i+2,k) + VM->get_energy_WM (k+1, j-2) + 
                  dangle_top [int_sequence[i]][int_sequence[j]][int_sequence[i+1]] + 
                  dangle_bot [int_sequence[i]][int_sequence[j]][int_sequence[j-1]] + 
                  2*misc.multi_free_base_penalty;
                if (tmp < min)
                  {
                    min = tmp;
                    best_k = k;
                    best_row = 4;
                  }
              }
            switch (best_row)
              {
              case 1: insert_node (i+1, best_k, M_WM);
                insert_node (best_k+1, j-1, M_WM); break;
              case 2: insert_node (i+2, best_k, M_WM);
                insert_node (best_k+1, j-1, M_WM); break;
              case 3: insert_node (i+1, best_k, M_WM);
                insert_node (best_k+1, j-2, M_WM); break;
              case 4: insert_node (i+2, best_k, M_WM);
                insert_node (best_k+1, j-2, M_WM); break;
              }
          }

        else if (type == MULTI_LINK)
          {
            f[i].type = MULTI_LINK;
            f[j].type = MULTI_LINK;

            int best_row, best_k;
            PARAMTYPE tmp, min;
            min = INF;
            tmp = VM->get_energy_WM_link (i+1, link) + VM->get_energy_WM_link (link+1, j-1);
            if (tmp < min)
              {
                min = tmp;
                best_row = 1;
              }
            tmp = VM->get_energy_WM_link (i+2, link) + VM->get_energy_WM_link (link+1, j-1) +
              dangle_top [int_sequence[i]][int_sequence[j]][int_sequence[i+1]];
            if (tmp < min)
              {
                min = tmp;
                best_row = 2;
              }
            tmp = VM->get_energy_WM_link (i+1, link) + VM->get_energy_WM_link (link+1, j-2) +
              dangle_bot [int_sequence[i]][int_sequence[j]][int_sequence[j-1]];
            if (tmp < min)
              {
                min = tmp;
                best_row = 3;
              }
            tmp = VM->get_energy_WM_link (i+2, link) + VM->get_energy_WM_link (link+1, j-2) +
              dangle_top [int_sequence[i]][int_sequence[j]][int_sequence[i+1]] + 
              dangle_bot [int_sequence[i]][int_sequence[j]][int_sequence[j-1]];
            if (tmp < min)
              {
                min = tmp;
                best_row = 4;
              }
            for (k = link+TURN+2; k <= j-TURN-2; k++)
              {
                tmp = VM->get_energy_WM_link (link+1,k) + VM->get_energy_WM_link (k+1,j-1);
                if (link != i) 
                  tmp += dangle_top[int_sequence[i]][int_sequence[j]][int_sequence[i+1]];
                if (tmp < min)
                  {
                    min = tmp;
                    best_k = k;
                    best_row = 5;
                  }
              }    
              for (k = link+TURN+2; k <= j-TURN-3; k++)
              {
                tmp = VM->get_energy_WM_link (link+1,k) + VM->get_energy_WM_link (k+1,j-2) +
                  dangle_bot [int_sequence[i]][int_sequence[j]][int_sequence[j-1]];
                if (link != i) 
                  tmp += dangle_top[int_sequence[i]][int_sequence[j]][int_sequence[i+1]];
                if (tmp < min)
                  {
                    min = tmp;
                    best_k = k;
                    best_row = 6;
                  }
              }            
              for (k = i+TURN+2; k <= link-TURN-1; k++)
              {
                tmp = VM->get_energy_WM_link (i+1,k) + VM->get_energy_WM_link (k+1,link);
                if (link != j-1) 
                  tmp += dangle_bot [int_sequence[i]][int_sequence[j]][int_sequence[j-1]];
                if (tmp < min)
                  {
                    min = tmp;
                    best_k = k;
                    best_row = 7;
                  }
              }            
              for (k = i+TURN+3; k <= link-TURN-1; k++)
              {
                tmp = VM->get_energy_WM_link (i+2,k) + VM->get_energy_WM_link (k+1,link) + 
                  dangle_top[int_sequence[i]][int_sequence[j]][int_sequence[i+1]];
                if (link != j-1) 
                  tmp += dangle_bot [int_sequence[i]][int_sequence[j]][int_sequence[j-1]];
                if (tmp < min)
                  {
                    min = tmp;
                    best_k = k;
                    best_row = 8;
                  }
              }

            switch (best_row)
              {
              case 1: insert_node (i+1, link, M_WM_LINK);
                insert_node (link+1, j-1, M_WM_LINK); break;
              case 2: insert_node (i+2, link, M_WM_LINK);
                insert_node (link+1, j-1, M_WM_LINK); break;
              case 3: insert_node (i+1, link, M_WM_LINK);
                insert_node (link+1, j-2, M_WM_LINK); break;
              case 4: insert_node (i+2, link, M_WM_LINK);
                insert_node (link+1, j-2, M_WM_LINK); break;
              case 5: insert_node (link+1, best_k, M_WM_LINK);
                insert_node (best_k+1, j-1, M_WM_LINK); break;
              case 6: insert_node (link+1, best_k, M_WM_LINK);
                insert_node (best_k+1, j-2, M_WM_LINK); break;
              case 7: insert_node (i+1, best_k, M_WM_LINK);
                insert_node (best_k+1, link, M_WM_LINK); break;
              case 8: insert_node (i+2, best_k, M_WM_LINK);
                insert_node (best_k+1, link, M_WM_LINK); break;
              }
          }
    }
  else if(cur_interval->type == FREE)
    {
      j = cur_interval->j;

      if (j <= TURN) return; 
      
      PARAMTYPE min, tmp, acc, energy_ij;
      int best_row, i, best_i;
      min = INF;

      if (debug)
        printf ("\t(0,%d) FREE\n", j);
      tmp = W[j-1];
      if (tmp < min)
        {
          min = tmp;          
          best_row = 0;
        }
      for (i=0; i<=j-TURN-1; i++)
        {
          acc = (i-1>0) ? W[i-1] : 0;          
          energy_ij = V->get_energy(i,j);
          if (energy_ij < INF)
            {
              tmp = energy_ij + AU_penalty (int_sequence[i],int_sequence[j]) + acc;
              if (tmp < min)
                {
                  min = tmp;
                  best_i = i;
                  best_row = 1;
                }
            }        
          energy_ij = V->get_energy(i+1,j);            
          if (energy_ij < INF)
            {
              tmp = energy_ij + AU_penalty (int_sequence[i+1],int_sequence[j]) + acc;
              if (i != link)
                tmp += dangle_bot [int_sequence[j]]
                  [int_sequence[i+1]]
                  [int_sequence[i]];
              if (tmp < min)
                {
                  min = tmp;
                  best_i = i;
                  best_row = 2;
                }
            }          
          energy_ij = V->get_energy(i,j-1);
          if (energy_ij < INF)
            {
              tmp = energy_ij + AU_penalty (int_sequence[i],int_sequence[j-1]) + acc;
              if (j-1 != link)
                tmp += dangle_top [int_sequence[j-1]]
                  [int_sequence[i]]
                  [int_sequence[j]];
              if (tmp < min)
                {
                  min = tmp;
                  best_i = i;
                  best_row = 3;
                }
            }                  
          energy_ij = V->get_energy(i+1,j-1);
          if (energy_ij < INF)
            {
              tmp = energy_ij + AU_penalty (int_sequence[i+1],int_sequence[j-1]) + acc;
              if (i != link)
                tmp += dangle_bot [int_sequence[j-1]]
                  [int_sequence[i+1]]
                  [int_sequence[i]];
              if (j-1 != link)
                tmp += dangle_top [int_sequence[j-1]]
                  [int_sequence[i+1]]
                  [int_sequence[j]];
              if (tmp < min)
                {
                  min = tmp;
                  best_i = i;
                  best_row = 4;
                }
            }
        }
      switch (best_row)
        {
        case 0: insert_node (0, j-1, FREE); break;
        case 1: insert_node (best_i, j, LOOP); 
          if (best_i-1 > TURN) 
            insert_node (0, best_i-1, FREE); 
          break;
        case 2: insert_node (best_i+1, j, LOOP); 
          if (best_i-1 > TURN) 
            insert_node (0, best_i-1, FREE); 
          break;
        case 3: insert_node (best_i, j-1, LOOP); 
          if (best_i-1 > TURN) 
            insert_node (0, best_i-1, FREE); 
          break;
        case 4: insert_node (best_i+1, j-1, LOOP); 
          if (best_i-1 > TURN) 
            insert_node (0, best_i-1, FREE); 
          break;
        }
    }
  else if(cur_interval->type == M_WM)
    {
      i = cur_interval->i;
      j = cur_interval->j;
      PARAMTYPE tmp, min;
      int best_k, best_row;
      min = INF;

      if (debug)
        printf ("\t (%d,%d) M_WM\n", i,j);

      tmp = V->get_energy(i,j) +
        AU_penalty (int_sequence[i], int_sequence[j]) +
        misc.multi_helix_penalty;
      if (tmp < min)
        {
          min = tmp;
          best_row = 1;
        }

      if ( i != link)
        {
          tmp = V->get_energy(i+1,j) +
            AU_penalty (int_sequence[i+1], int_sequence[j]) +
            dangle_bot [int_sequence[j]]
            [int_sequence[i+1]]
            [int_sequence[i]] +
            misc.multi_helix_penalty +
            misc.multi_free_base_penalty;
          if (tmp < min)
            {
              min = tmp;
              best_row = 2;
            }
        }
      if (j != link+1)
        {
          tmp = V->get_energy(i,j-1) +
                  AU_penalty (int_sequence[i], int_sequence[j-1]) +
                  dangle_top [int_sequence[j-1]]
                             [int_sequence[i]]
                             [int_sequence[j]] +
                  misc.multi_helix_penalty +
                  misc.multi_free_base_penalty;
          if (tmp < min)
            {
              min = tmp;
              best_row = 3;
            }
        }
      if (i != link && j != link+1)
        {
          tmp = V->get_energy(i+1,j-1) +
                  AU_penalty (int_sequence[i+1], int_sequence[j-1]) +
                  dangle_bot [int_sequence[j-1]]
                             [int_sequence[i+1]]
                             [int_sequence[i]] +
                  dangle_top [int_sequence[j-1]]
                             [int_sequence[i+1]]
                             [int_sequence[j]] +
                  misc.multi_helix_penalty +
                  2*misc.multi_free_base_penalty;
          if (tmp < min)
            {
              min = tmp;
              best_row = 4;
            }
        }
      if (link != i)
        {
          tmp = VM->get_energy_WM (i+1,j) + misc.multi_free_base_penalty;
          if (tmp < min)
            {
              min = tmp;
              best_row = 5;
            }
        }
      if (link != j-1)
        {
          tmp = VM->get_energy_WM (i,j-1) + misc.multi_free_base_penalty;
          if (tmp < min)
            {
              min = tmp;
              best_row = 6;
            }
        }

        for (int k=i; k < j; k++)
          {
            if (link == k) continue;
            tmp = VM->get_energy_WM (i, k) + VM->get_energy_WM (k+1, j);
            if (tmp < min)
              {
                min = tmp;
                best_k = k;
                best_row = 7;
              }
          }
        switch (best_row)
          {
          case 1: insert_node (i, j, LOOP); break;
          case 2: insert_node (i+1, j, LOOP); break;
          case 3: insert_node (i, j-1, LOOP); break;
          case 4: insert_node (i+1, j-1, LOOP); break;
          case 5: 
            if (j-i-1 > TURN)
              insert_node (i+1, j, M_WM);
            break;
          case 6:
            if (j-1-i > TURN)
              insert_node (i, j-1, M_WM);
            break;            
          case 7: 
            if (best_k-i > TURN) 
              insert_node (i, best_k, M_WM);
            if (j-best_k-1 > TURN)
              insert_node (best_k+1, j, M_WM); 
            break;
          }        
    }

  else if(cur_interval->type == M_WM_LINK)
    {
      i = cur_interval->i;
      j = cur_interval->j;
      PARAMTYPE tmp, min;
      int best_k, best_row;
      min = INF;

      if (debug)
        printf ("\t (%d,%d) M_WM_LINK\n", i,j);

      tmp = V->get_energy(i,j) + AU_penalty (int_sequence[i], int_sequence[j]);
      if (tmp < min)
        {
          min = tmp;
          best_row = 1;
        }

      tmp = V->get_energy(i+1,j) + AU_penalty (int_sequence[i+1], int_sequence[j]) + 
        dangle_bot [int_sequence[j]][int_sequence[i+1]][int_sequence[i]];
      if (tmp < min)
        {
          min = tmp;
          best_row = 2;
        }

      tmp = V->get_energy(i,j-1) + AU_penalty (int_sequence[i], int_sequence[j-1]) + 
        dangle_top [int_sequence[j-1]][int_sequence[i]][int_sequence[j]];
      if (tmp < min)
        {
          min = tmp;
          best_row = 3;
        }

      tmp = V->get_energy(i+1,j-1) +
        AU_penalty (int_sequence[i+1], int_sequence[j-1]) + 
                   dangle_bot [int_sequence[j-1]]
                              [int_sequence[i+1]]
                              [int_sequence[i]] +
                   dangle_top [int_sequence[j-1]]
                              [int_sequence[i+1]]
                              [int_sequence[j]];
      if (tmp < min)
        {
          min = tmp;
          best_row = 4;
        }
      
      tmp = VM->get_energy_WM_link (i+1,j);
      if (tmp < min)
        {
          min = tmp;
          best_row = 5;
        }

      tmp = VM->get_energy_WM_link (i,j-1);
      if (tmp < min)
        {
          min = tmp;
          best_row = 6;
        }

      for (int k=i; k < j; k++)
        {
          tmp = VM->get_energy_WM_link (i, k) + VM->get_energy_WM_link (k+1, j);
          if (tmp < min)
            {
              min = tmp;
              best_k = k;
              best_row = 7;
            }
        }
        switch (best_row)
          {
          case 1: insert_node (i, j, LOOP); break;
          case 2: insert_node (i+1, j, LOOP); break;
          case 3: insert_node (i, j-1, LOOP); break;
          case 4: insert_node (i+1, j-1, LOOP); break;
          case 5: 
            if (j-i-1 > TURN)
              insert_node (i+1, j, M_WM_LINK);
            break;
          case 6:
            if (j-1-i > TURN)
              insert_node (i, j-1, M_WM_LINK);
            break;
          case 7: 
            if (best_k-i > TURN)
              insert_node (i, best_k, M_WM_LINK);
            if (j-best_k-1 > TURN)
              insert_node (best_k+1, j, M_WM_LINK); 
            break;
          }


    }
}



PARAMTYPE p_min_folding::compute_W_br2 (int j)
// POST: The second branch of W     mula.
//       This branch has to consider the AU_penalties and the dangling energies.
{
    PARAMTYPE min, tmp, energy_ij, acc;
    int i;

    min = INF; energy_ij = INF;
    for (i=0; i<=j-TURN-1; i++)
    {  
        acc = (i-1>0) ? W[i-1] : 0;
        
        energy_ij = V->get_energy(i,j);
        if (energy_ij < INF)
        {
            tmp = energy_ij + AU_penalty (int_sequence[i],int_sequence[j]) + acc;
            if (tmp < min)
            {
                min = tmp;
            }
        }
        
        energy_ij = V->get_energy(i+1,j);            
        if (energy_ij < INF)
        {
            tmp = energy_ij + AU_penalty (int_sequence[i+1],int_sequence[j]) + acc;
            if (i != link)
                tmp += dangle_bot [int_sequence[j]]
                             [int_sequence[i+1]]
                             [int_sequence[i]];
            if (tmp < min)
            {
                min = tmp;
            }
        }
        
        energy_ij = V->get_energy(i,j-1);
        if (energy_ij < INF)
        {
            tmp = energy_ij + AU_penalty (int_sequence[i],int_sequence[j-1]) + acc;
            if (j-1 != link)
                tmp += dangle_top [int_sequence[j-1]]
                             [int_sequence[i]]
                             [int_sequence[j]];
            if (tmp < min)
            {
                min = tmp;
            }
        }

        
        energy_ij = V->get_energy(i+1,j-1);
        if (energy_ij < INF)
        {
            tmp = energy_ij + AU_penalty (int_sequence[i+1],int_sequence[j-1]) + acc;
            if (i != link)
                tmp += dangle_bot [int_sequence[j-1]]
                             [int_sequence[i+1]]
                             [int_sequence[i]];
            if (j-1 != link)
                tmp += dangle_top [int_sequence[j-1]]
                             [int_sequence[i+1]]
                             [int_sequence[j]];
            if (tmp < min)
            {
                min = tmp;
            }
        }
    }
    return min;    
}


PARAMTYPE p_min_folding::compute_W_br2_nointra (int j)
// POST: The second branch of W     mula.
//       This branch has to consider the AU_penalties and the dangling energies.
{
    PARAMTYPE min, tmp, energy_ij, acc;
    int i;

    min = INF; energy_ij = INF;
    for (i=0; i <= link; i++)
    {  
        acc = (i-1>0) ? W[i-1] : 0;
        
        energy_ij = V->get_energy(i,j);
        if (energy_ij < INF)
        {
            tmp = energy_ij + AU_penalty (int_sequence[i],int_sequence[j]) + acc;
            if (tmp < min)
            {
                min = tmp;
            }
        }
        
        energy_ij = V->get_energy(i+1,j);            
        if (energy_ij < INF)
        {
            tmp = energy_ij + AU_penalty (int_sequence[i+1],int_sequence[j]) + acc;
            if (i != link)
                tmp += dangle_bot [int_sequence[j]]
                             [int_sequence[i+1]]
                             [int_sequence[i]];
            if (tmp < min)
            {
                min = tmp;
            }
        }
        
        energy_ij = V->get_energy(i,j-1);
        if (energy_ij < INF)
        {
            tmp = energy_ij + AU_penalty (int_sequence[i],int_sequence[j-1]) + acc;
            if (j-1 != link)
                tmp += dangle_top [int_sequence[j-1]]
                             [int_sequence[i]]
                             [int_sequence[j]];
            if (tmp < min)
            {
                min = tmp;
            }
        }

        
        energy_ij = V->get_energy(i+1,j-1);
        if (energy_ij < INF)
        {
            tmp = energy_ij + AU_penalty (int_sequence[i+1],int_sequence[j-1]) + acc;
            if (i != link)
                tmp += dangle_bot [int_sequence[j-1]]
                             [int_sequence[i+1]]
                             [int_sequence[i]];
            if (j-1 != link)
                tmp += dangle_top [int_sequence[j-1]]
                             [int_sequence[i+1]]
                             [int_sequence[j]];
            if (tmp < min)
            {
                min = tmp;
            }
        }
    }
    return min;    
}





void p_min_folding::compute_W (int j)
// compute W(j)
{

    PARAMTYPE m1, m2;;
    m1 = W[j-1];
    m2 = compute_W_br2(j);
    if ((m1 < m2) || (m1 >= MAXENERGY && m2 >= MAXENERGY))
    {
        W[j] = m1;
    }
    else
    {
        W[j] = m2;
    }
}


void p_min_folding::compute_W_nointra (int j)
// compute W(j)
{

    PARAMTYPE m1, m2;
    m1 = W[j-1];
    m2 = compute_W_br2_nointra (j);
    if ((m1 < m2) || (m1 >= MAXENERGY && m2 >= MAXENERGY))
    {
        W[j] = m1;
    }
    else
    {
        W[j] = m2;
    }
}



void p_min_folding::print_result ()
// PRE:  The matrix was calculated and the results written in f
// POST: Prints results
{
    int i;
    PARAMTYPE energy, sum;
    energy = INF;
    printf ("Minimum energy: %d\n", W[nb_nucleotides-1]);        
    sum = 0;

    for (i=0; i< nb_nucleotides; i++)
    {
        if (f[i].pair > i)
        {
            if (f[i].type == HAIRP)
                energy = V->get_energy(i, f[i].pair);
            else if (f[i].type == STACK)
                energy = V->get_energy(i, f[i].pair) - V->get_energy(i+1, f[i+1].pair);

            /*
            else if (f[i].type == INTER)
            {
                V_node = V->get_node(i, f[i].pair);        
                energy = V_node->energy - V->get_energy (((internal_details *)V_node->details)->prime.i,
                                                         ((internal_details *)V_node->details)->prime.j);
            }

            else if (f[i].type == MULTI)
            {
                multi_details *m_node;
                V_node = V->get_node(i, f[i].pair);        
                m_node = (multi_details*)V_node->details;
                energy = V_node->energy;
                     (k=0; k< m_node->num_branches; k++)
                {
                    pair branch = m_node->branches[k];
                    energy -= V->get_energy (branch.i, branch.j);
                }
            }
            */

            printf ("Pair (%d,%d), type %c,\tenergy %6d\n", i, f[i].pair, f[i].type, energy);
            sum += energy;
        }
    }
    printf ("0....,....1....,....2....,....3....,....4....,....5....,....6....,....7....,....8\n");
    printf ("%s\n", sequence);
    printf ("%s\n", structure);

}
