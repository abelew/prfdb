/***************************************************************************
                          p_energy_matrix.h  -  description
                             -------------------
    begin                : Fri Apr 12 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef P_ENERGY_MATRIX_H
#define P_ENERGY_MATRIX_H

#include "p_stacked_pair.h"
#include "p_hairpin_loop.h"
#include "p_internal_loop.h"
#include "p_multi_loop.h"
#include "p_multi_loop_sub.h"


class p_energy_matrix
{
    public:

        friend class p_stacked_pair;
        friend class p_internal_loop;
        friend class p_multi_loop;
        friend class p_multi_loop_sub;

        p_energy_matrix (int *seq, int link, int length);
        // The constructor

        ~p_energy_matrix ();
        // The destructor

        void set_loops (p_hairpin_loop *H, p_stacked_pair *S,
                        p_internal_loop *VBI, p_multi_loop *VM, p_multi_loop_sub *VM_sub)
        // Set the local loops to the given values
        {
            this->H = H;
            this->S = S;
            this->VBI = VBI;
            this->VM = VM;        
            this->VM_sub = VM_sub;
        }

        void compute_energy (int i, int j);
        // MFE computation for V(i,j)
        
        void compute_energy_sub (int i, int j);
        // suboptimals computation for V(i,j)        
        
        void compute_energy_simplified (int i, int j);
        // MFE computation for V(i,j), only H and S loops are included

        PARAMTYPE get_energy (int i, int j) { if (i>=j) return INF; int ij = index[i]+j-i; return nodes[ij].energy; }
        // return the energy of V(i,j)

        char get_type (int i, int j) { if (i>=j) return NONE; int ij = index[i]+j-i; return nodes[ij].type; }
        // return the type of V(i,j)


    private:
        p_hairpin_loop *H;
        p_stacked_pair *S;
        p_internal_loop *VBI;
        p_multi_loop *VM;
        p_multi_loop_sub *VM_sub;

        int *sequence;             // the entire sequence for which we compute the energy
        int seqlen;                 // sequence length
        int *index;
        int link;
        free_energy_node *nodes;  // hairpin nodes in a 1D array


};



#endif
