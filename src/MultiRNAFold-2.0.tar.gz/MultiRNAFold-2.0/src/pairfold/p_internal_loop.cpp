/***************************************************************************
                          p_internal_loop.cpp  -  description
                             -------------------
    begin                : Fri Apr 12 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

//#include <iostream.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "p_internal_loop.h"
#include "externs.h"
#include "common.h"
#include "pairfold.h"
#include "p_specific_functions.h"



p_internal_loop::p_internal_loop (int *seq, int link, int length)
// The constructor
{
    seqlen = length;
    sequence = seq;
    this->V = NULL;
    this->link = link;  
}


p_internal_loop::~p_internal_loop ()
// The destructor
{
}


PARAMTYPE p_internal_loop::compute_energy (int i, int j)
// computes the MFE of the structure closed by the internal loop closed at (i,j)   
{

    int ip, jp, minq;
    PARAMTYPE tmp, min;
    PARAMTYPE d_top, d_bot;
    PARAMTYPE penalty_size, asym_penalty, ip_jp_energy, i_j_energy, en;
    int branch1, branch2, l;

    min = INF;
    for (ip = i+1; ip <= MIN(j-2,i+max_internal_loop+1) ; ip++)  // j-2-TURN
    {
        minq = MAX (j-i+ip-max_internal_loop-2, ip+1);    // ip+1+TURN);
        for (jp = minq; jp < j; jp++)
        {
            // could replace the code from now to the end of the function, by get_energy_str
            // it's very redundant (duplicated code) as it is now, but it's faster.
            if (can_pair (sequence[ip], sequence[jp]))
            {
                branch1 = ip-i-1;
                branch2 = j-jp-1;
                if (branch1 == 0 && branch2 == 0)
                    continue;
                
                if (i <= link && link < ip)
                {
                    d_top=0; d_bot=0;
                    if (i < link)
                        d_top = dangle_top [sequence[i]] [sequence[j]] [sequence[i+1]];
                    if (link+1 < ip)
                        d_top += dangle_bot [sequence[jp]] [sequence[ip]] [sequence[ip-1]];
                    d_bot = p_dangling_energy (sequence, link, ip, jp, j, i);    
                        
                    tmp = d_top + d_bot +
                                 misc.intermolecular_initiation +
                                 AU_penalty (sequence[i],sequence[j]) +                    
                                 AU_penalty (sequence[ip], sequence[jp]) +
                                 V->get_energy (ip, jp);
                    if (tmp < min)
                    {
                        min = tmp;
                    }
                    continue;                               
                }
                else if (jp <= link && link < j)
                {
                    d_top=0; d_bot=0;
                    if (jp < link)
                        d_bot = dangle_top [sequence[jp]] [sequence[ip]] [sequence[jp+1]];
                    if (link+1 < j)
                        d_bot += dangle_bot [sequence[i]] [sequence[j]] [sequence[j-1]];
                    d_top = p_dangling_energy (sequence, link, j, i, ip, jp);

                    tmp = d_top + d_bot +
                                 misc.intermolecular_initiation +                    
                                 AU_penalty (sequence[i],sequence[j]) +
                                 AU_penalty (sequence[ip], sequence[jp]) +
                                 V->get_energy (ip, jp);
                    if (tmp < min)
                    {
                        min = tmp;
                    }
                    continue;
                }
                
                if (branch1 != 0 || branch2 != 0)
                {
                    // check if it is a bulge loop of size 1
                    // check if it is int11 or int21 or int22
                    if (branch1 == 1 && branch2 == 1)     // it is int11
                    {
                        // int11[i][j][i+1][j-1][ip][jp]
                        en = int11 [sequence[i]][sequence[j]]
                                   [sequence[i+1]][sequence[j-1]]
                                   [sequence[ip]][sequence[jp]];
                        tmp = en + V->get_energy (ip, jp);
                    }
                    else if (branch1 == 1 && branch2 == 2)
                    {
                        // int21[i][j][i+1][j-1][ip][jp][jp+1]
                        en = int21 [sequence[i]][sequence[j]]
                                   [sequence[i+1]][sequence[j-1]]
                                   [sequence[ip]][sequence[jp]]
                                   [sequence[jp+1]];
                        tmp = en + V->get_energy (ip, jp);
                    }
                    else if(branch1 == 2 && branch2 == 1)
                    {
                        // after rotation: int21[jp][ip][j-1][ip-1][j][i][i+1]
                        en = int21 [sequence[jp]][sequence[ip]]
                                   [sequence[j-1]][sequence[ip-1]]
                                   [sequence[j]][sequence[i]]
                                   [sequence[i+1]];
                        tmp = en + V->get_energy (ip, jp);
                    }
                    else if (branch1 == 2 && branch2 == 2)
                    {
                        // int22[i][j][i+1][j-1][ip][jp][ip-1][jp+1]
                        en = int22 [sequence[i]][sequence[j]]
                                   [sequence[i+1]][sequence[j-1]]
                                   [sequence[ip]][sequence[jp]]
                                   [sequence[ip-1]][sequence[jp+1]];
                        tmp = en + V->get_energy (ip, jp);
                    }
                    else
                    {
                        // this case is not int11, int21, int22

                        // check if it is a bulge
                        if (branch1 == 0 || branch2 == 0)
                        {
                            l = branch1+branch2;
                            penalty_size = penalty_by_size (l, 'B');
                            if (l == 1)
                            {
                                // bulge of size 1
                                // stack[i][j][i+1][j-1]
                                en = stack [sequence[i]][sequence[j]]
                                           [sequence[ip]][sequence[jp]];
                                tmp = en + penalty_size + V->get_energy (ip, jp);
                            }
                            else
                            {
                                // bulge of size bigger than 1
                                // check if (i,j) and (ip,jp) can pair
                                tmp = penalty_size +
                                    AU_penalty (sequence[i],sequence[j]) +
                                    AU_penalty (sequence[ip], sequence[jp]) +
                                    V->get_energy (ip, jp);
                            }
                        }
                        // it is an internal loop (not a bulge)
                        else
                        {
                            l = branch1+branch2;
                            penalty_size = penalty_by_size (l, 'I');
                            asym_penalty = asymmetry_penalty (branch1, branch2);

                            if ((branch1 == 1 || branch2 == 1) && misc.gail_rule)
                            // If gail_rule is set to 1 in miscloop file,
                            // i_j_energy and ip_jp_energy will be calculated as if it was a loop of As
                            {
                                i_j_energy  =  tstacki[sequence[i]][sequence[j]]
                                                      [0][0];
                                ip_jp_energy = tstacki[sequence[jp]][sequence[ip]]
                                                      [0][0];
                            }
                            else
                            {
                                i_j_energy   = tstacki[sequence[i]][sequence[j]]
                                                      [sequence[i+1]][sequence[j-1]];
                                ip_jp_energy = tstacki[sequence[jp]][sequence[ip]]
                                                      [sequence[jp+1]][sequence[ip-1]];
                            }
                            tmp = i_j_energy + ip_jp_energy + penalty_size +
                                         asym_penalty + V->get_energy (ip, jp);
                        }
                    }

                    if (tmp < min)
                    {
                        min = tmp;
                    }            
                }
            }
        }
    }
    return min;
}


PARAMTYPE p_internal_loop::get_energy_str (int i, int j, int ip, int jp)
// returns the free energy of the structure closed by the internal loop (i,j,ip,jp)  
// this function is most of compute_energy, but the minimization is faster if I keep this function separate
{
    PARAMTYPE tmp;
    PARAMTYPE penalty_size, asym_penalty, ip_jp_energy, i_j_energy, en;
    int branch1, branch2, l;
    PARAMTYPE d_top, d_bot;
    tmp = INF;
 
    if (can_pair(sequence[ip], sequence[jp]))
    {
        if (i <= link && link < ip)
        {
            d_top=0; d_bot=0;
                if (i < link)
                    d_top = dangle_top [sequence[i]] [sequence[j]] [sequence[i+1]];
                if (link+1 < ip)
                    d_top += dangle_bot [sequence[jp]] [sequence[ip]] [sequence[ip-1]];
                d_bot = p_dangling_energy (sequence, link, ip, jp, j, i);    
                        
                tmp = d_top + d_bot +
                        misc.intermolecular_initiation +
                        AU_penalty (sequence[i],sequence[j]) +                    
                        AU_penalty (sequence[ip], sequence[jp]) +
                        V->get_energy(ip, jp);               
        }
        else if (jp <= link && link < j)
        {
            d_top=0; d_bot=0;
            if (jp < link)
            d_bot = dangle_top [sequence[jp]] [sequence[ip]] [sequence[jp+1]];
            if (link+1 < j)
                d_bot += dangle_bot [sequence[i]] [sequence[j]] [sequence[j-1]];
            d_top = p_dangling_energy (sequence, link, j, i, ip, jp);

            tmp = d_top + d_bot +
                    misc.intermolecular_initiation +                    
                    AU_penalty (sequence[i],sequence[j]) +
                    AU_penalty (sequence[ip], sequence[jp]) +
                    V->get_energy (ip, jp);
        }// END B: link is between jp and j
        else 
        {
            branch1 = ip-i-1;
            branch2 = j-jp-1;
                 
            // C: One branch !=0 
            if (branch1 != 0 || branch2 != 0)
            {
                // check if it is a bulge loop of size 1
                // check if it is int11 or int21 or int22
                 if (branch1 == 1 && branch2 == 1)     // it is int11
                 {
                     // int11[i][j][i+1][j-1][ip][jp]
                     en = int11 [sequence[i]][sequence[j]]
                             [sequence[i+1]][sequence[j-1]]
                             [sequence[ip]][sequence[jp]];
                 tmp = en + V->get_energy (ip, jp);
             }
             else if (branch1 == 1 && branch2 == 2)
             {
                  // int21[i][j][i+1][j-1][ip][jp][jp+1]
                  en = int21 [sequence[i]][sequence[j]]
                             [sequence[i+1]][sequence[j-1]]
                             [sequence[ip]][sequence[jp]]
                             [sequence[jp+1]];
                  tmp = en + V->get_energy (ip, jp);
             }
             else if(branch1 == 2 && branch2 == 1)
             {
                  // after rotation: int21[jp][ip][j-1][ip-1][j][i][i+1]
                  en = int21 [sequence[jp]][sequence[ip]]
                             [sequence[j-1]][sequence[ip-1]]
                             [sequence[j]][sequence[i]]
                             [sequence[i+1]];
                  tmp = en + V->get_energy (ip, jp);
             }
             else if (branch1 == 2 && branch2 == 2)
             {
                // int22[i][j][i+1][j-1][ip][jp][ip-1][jp+1]
                  en = int22 [sequence[i]][sequence[j]]
                             [sequence[i+1]][sequence[j-1]]
                             [sequence[ip]][sequence[jp]]
                             [sequence[ip-1]][sequence[jp+1]];
                  tmp = en + V->get_energy (ip, jp);
             }
             else
             {
                        // this case is not int11, int21, int22
                        // check if it is a bulge
                 if (branch1 == 0 || branch2 == 0)
                 {
                       l = branch1+branch2;
                       penalty_size = penalty_by_size (l, 'B');
                       if (l == 1)
                       {
                           // bulge of size 1
                                // stack[i][j][i+1][j-1]
                           en = stack [sequence[i]][sequence[j]]
                                      [sequence[ip]][sequence[jp]];
                           tmp = en + penalty_size + V->get_energy (ip, jp);
                       }
                       else
                       {
                                // bulge of size bigger than 1
                                // check if (i,j) and (ip,jp) can pair
                            tmp = penalty_size +
                                    AU_penalty (sequence[i],sequence[j]) +
                                    AU_penalty (sequence[ip], sequence[jp]) +
                                    V->get_energy (ip, jp);
                       }
                  }
                  // it is an internal loop (not a bulge)
                  else
                  {
                            l = branch1+branch2;
                            penalty_size = penalty_by_size (l, 'I');
                            asym_penalty = asymmetry_penalty (branch1, branch2);
                            if ((branch1 == 1 || branch2 == 1) && misc.gail_rule)
                            // If gail_rule is set to 1 in miscloop file,
                            // i_j_energy and ip_jp_energy will be calculated as if it was a loop of As
                            {
                                i_j_energy  =  tstacki[sequence[i]][sequence[j]]
                                                      [0][0];
                                ip_jp_energy = tstacki[sequence[jp]][sequence[ip]]
                                                      [0][0];
                            }
                            else
                            {
                                i_j_energy   = tstacki[sequence[i]][sequence[j]]
                                                      [sequence[i+1]][sequence[j-1]];
                                ip_jp_energy = tstacki[sequence[jp]][sequence[ip]]
                                                      [sequence[jp+1]][sequence[ip-1]];
                            }
                            tmp = i_j_energy + ip_jp_energy + penalty_size +
                                         asym_penalty + V->get_energy (ip, jp);
                     }// else
                }//else                        
            }
        }//END C: branch1 !=0, branch2!=0;
    }// can_pair(ip, jp);

    if (tmp < INF/2)
      return tmp;
    return INF;
}



PARAMTYPE p_internal_loop::get_energy (int i, int j, int ip, int jp, int *sequence, int link)
// returns the free energy of the internal loop closed at (i,j)  
{
    PARAMTYPE energy;
    PARAMTYPE penalty_size, asym_penalty, ip_jp_energy, i_j_energy;
    int branch1, branch2, l;
    PARAMTYPE d_top, d_bot;

    if (i <= link && link < ip)
    {
        d_top=0; d_bot=0;
        if (i < link)
            d_top = IGINF(dangle_top [sequence[i]] [sequence[j]] [sequence[i+1]]);
        if (link+1 < ip)
            d_top += IGINF(dangle_bot [sequence[jp]] [sequence[ip]] [sequence[ip-1]]);
        d_bot = p_dangling_energy (sequence, link, ip, jp, j, i);

        energy = d_top + d_bot +
                 misc.intermolecular_initiation +
                 AU_penalty (sequence[i], sequence[j]) +
                 AU_penalty (sequence[ip], sequence[jp]);

        return energy;
    }

    if (jp <= link && link < j)
    {
        d_top=0; d_bot=0;
        if (jp < link)
            d_bot = IGINF(dangle_top [sequence[jp]] [sequence[ip]] [sequence[jp+1]]);
        if (link+1 < j)
            d_bot += IGINF(dangle_bot [sequence[i]] [sequence[j]] [sequence[j-1]]);
        d_top = p_dangling_energy (sequence, link, j, i, ip, jp);

        energy = d_top + d_bot +
                 misc.intermolecular_initiation +
                 AU_penalty (sequence[i], sequence[j]) +
                 AU_penalty (sequence[ip], sequence[jp]);
        return energy;
    }

    branch1 = ip-i-1;
    branch2 = j-jp-1;

    if (branch1 != 0 || branch2 != 0)
    {
        // check if it is a bulge loop of size 1
        // check if it is int11 or int21 or int22
        if (branch1 == 1 && branch2 == 1)     // it is int11
        {
                        // int11[i][j][i+1][j-1][ip][jp]
            energy = IGINF(int11 [sequence[i]][sequence[j]]
                           [sequence[i+1]][sequence[j-1]]
                           [sequence[ip]][sequence[jp]]);
        }
        else if (branch1 == 1 && branch2 == 2)
        {
            // int21[i][j][i+1][j-1][ip][jp][jp+1]
            energy = IGINF(int21 [sequence[i]][sequence[j]]
                           [sequence[i+1]][sequence[j-1]]
                           [sequence[ip]][sequence[jp]]
                           [sequence[jp+1]]);
        }
        else if(branch1 == 2 && branch2 == 1)
        {
            // after rotation: int21[jp][ip][j-1][ip-1][j][i][i+1]
            energy = IGINF(int21 [sequence[jp]][sequence[ip]]
                           [sequence[j-1]][sequence[ip-1]]
                           [sequence[j]][sequence[i]]
                           [sequence[i+1]]);
        }
        else if (branch1 == 2 && branch2 == 2)
        {
            // int22[i][j][i+1][j-1][ip][jp][ip-1][jp+1]
            energy = IGINF(int22 [sequence[i]][sequence[j]]
                           [sequence[i+1]][sequence[j-1]]
                           [sequence[ip]][sequence[jp]]
                           [sequence[ip-1]][sequence[jp+1]]);
        }
        else
        {
            // this case is not int11, int21, int22

            // check if it is a bulge
            if (branch1 == 0 || branch2 == 0)
            {
                l = branch1+branch2;
                penalty_size = penalty_by_size (l, 'B');
                if (l == 1)
                {
                    // bulge of size 1
                    // stack[i][j][i+1][j-1]
                    energy = IGINF(stack [sequence[i]][sequence[j]]
                                   [sequence[ip]][sequence[jp]]) +
                               penalty_size;
                }
                else
                {
                    // bulge of size bigger than 1
                    // check if (i,j) and (ip,jp) can pair
                    energy = penalty_size +
                               AU_penalty (sequence[i],sequence[j]) +
                               AU_penalty (sequence[ip], sequence[jp]);
                }
            }
            // it is an internal loop (not a bulge)
            else
            {
                l = branch1+branch2;
                penalty_size = penalty_by_size (l, 'I');
                asym_penalty = asymmetry_penalty (branch1, branch2);

                if ((branch1 == 1 || branch2 == 1) && misc.gail_rule)
                // If gail_rule is set to 1 in miscloop file,
                // i_j_energy and ip_jp_energy will be calculated as if it was a loop of As
                {
                    i_j_energy  =  IGINF(tstacki[sequence[i]][sequence[j]]
                                          [0][0]);
                    ip_jp_energy = IGINF(tstacki[sequence[jp]][sequence[ip]]
                                          [0][0]);
                }
                else
                {
                    i_j_energy   = IGINF(tstacki[sequence[i]][sequence[j]]
                                          [sequence[i+1]][sequence[j-1]]);
                    ip_jp_energy = IGINF(tstacki[sequence[jp]][sequence[ip]]
                                          [sequence[jp+1]][sequence[ip-1]]);
                }
                energy = i_j_energy + ip_jp_energy + penalty_size +
                                         asym_penalty;
            }
        }
    }
    return energy;
}


PARAMTYPE p_internal_loop::get_enthalpy (int i, int j, int ip, int jp, int *sequence, int link)
// returns the enthalpy of the internal loop closed at (i,j)  
{
    PARAMTYPE energy;
    PARAMTYPE penalty_size, asym_penalty, ip_jp_energy, i_j_energy;
    int branch1, branch2, l;
    PARAMTYPE d_top, d_bot;

    if (i <= link && link < ip)
    {
        d_top=0; d_bot=0;
        if (i < link)
            d_top = enthalpy_dangle_top [sequence[i]] [sequence[j]] [sequence[i+1]];
        if (link+1 < ip)
            d_top += enthalpy_dangle_bot [sequence[jp]] [sequence[ip]] [sequence[ip-1]];
        d_bot = p_dangling_enthalpy (sequence, link, ip, jp, j, i);

        energy = d_top + d_bot +
                 enthalpy_misc.intermolecular_initiation +
                 AU_penalty_enthalpy (sequence[i], sequence[j]) +
                 AU_penalty_enthalpy (sequence[ip], sequence[jp]);

        return energy;
    }

    if (jp <= link && link < j)
    {
        d_top=0; d_bot=0;
        if (jp < link)
            d_bot = enthalpy_dangle_top [sequence[jp]] [sequence[ip]] [sequence[jp+1]];
        if (link+1 < j)
            d_bot += enthalpy_dangle_bot [sequence[i]] [sequence[j]] [sequence[j-1]];
        d_top = p_dangling_enthalpy (sequence, link, j, i, ip, jp);

        energy = d_top + d_bot +
                 enthalpy_misc.intermolecular_initiation +
                 AU_penalty_enthalpy (sequence[i], sequence[j]) +
                 AU_penalty_enthalpy (sequence[ip], sequence[jp]);
        return energy;
    }

    branch1 = ip-i-1;
    branch2 = j-jp-1;

    if (branch1 != 0 || branch2 != 0)
    {
        // check if it is a bulge loop of size 1
        // check if it is int11 or int21 or int22
        if (branch1 == 1 && branch2 == 1)     // it is int11
        {
                        // int11[i][j][i+1][j-1][ip][jp]
            energy = enthalpy_int11 [sequence[i]][sequence[j]]
                           [sequence[i+1]][sequence[j-1]]
                           [sequence[ip]][sequence[jp]];
        }
        else if (branch1 == 1 && branch2 == 2)
        {
            // int21[i][j][i+1][j-1][ip][jp][jp+1]
            energy = enthalpy_int21 [sequence[i]][sequence[j]]
                           [sequence[i+1]][sequence[j-1]]
                           [sequence[ip]][sequence[jp]]
                           [sequence[jp+1]];
        }
        else if(branch1 == 2 && branch2 == 1)
        {
            // after rotation: int21[jp][ip][j-1][ip-1][j][i][i+1]
            energy = enthalpy_int21 [sequence[jp]][sequence[ip]]
                           [sequence[j-1]][sequence[ip-1]]
                           [sequence[j]][sequence[i]]
                           [sequence[i+1]];
        }
        else if (branch1 == 2 && branch2 == 2)
        {
            // int22[i][j][i+1][j-1][ip][jp][ip-1][jp+1]
            energy = enthalpy_int22 [sequence[i]][sequence[j]]
                           [sequence[i+1]][sequence[j-1]]
                           [sequence[ip]][sequence[jp]]
                           [sequence[ip-1]][sequence[jp+1]];
        }
        else
        {
            // this case is not int11, int21, int22

            // check if it is a bulge
            if (branch1 == 0 || branch2 == 0)
            {
                l = branch1+branch2;
                penalty_size = penalty_by_size_enthalpy (l, 'B');
                if (l == 1)
                {
                    // bulge of size 1
                    // stack[i][j][i+1][j-1]
                    energy = enthalpy_stack [sequence[i]][sequence[j]]
                                   [sequence[ip]][sequence[jp]] +
                               penalty_size;
                }
                else
                {
                    // bulge of size bigger than 1
                    // check if (i,j) and (ip,jp) can pair
                    energy = penalty_size +
                               AU_penalty_enthalpy (sequence[i],sequence[j]) +
                               AU_penalty_enthalpy (sequence[ip], sequence[jp]);
                }
            }
            // it is an internal loop (not a bulge)
            else
            {
                l = branch1+branch2;
                penalty_size = penalty_by_size_enthalpy (l, 'I');
                asym_penalty = asymmetry_penalty_enthalpy (branch1, branch2);

                if ((branch1 == 1 || branch2 == 1) && enthalpy_misc.gail_rule)
                // If gail_rule is set to 1 in miscloop file,
                // i_j_energy and ip_jp_energy will be calculated as if it was a loop of As
                {
                    i_j_energy  =  enthalpy_tstacki[sequence[i]][sequence[j]]
                                          [0][0];
                    ip_jp_energy = enthalpy_tstacki[sequence[jp]][sequence[ip]]
                                          [0][0];
                }
                else
                {
                    i_j_energy   = enthalpy_tstacki[sequence[i]][sequence[j]]
                                          [sequence[i+1]][sequence[j-1]];
                    ip_jp_energy = enthalpy_tstacki[sequence[jp]][sequence[ip]]
                                          [sequence[jp+1]][sequence[ip-1]];
                }
                energy = i_j_energy + ip_jp_energy + penalty_size +
                                         asym_penalty;
            }
        }
    }
    return energy;
}
