/***************************************************************************
                          m_multi_loop.cpp  -  description
                             -------------------
    begin                : Mon Apr 15 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <stdio.h>
#include <malloc.h>

#include "externs.h"
#include "common.h"
#include "m_multi_loop.h"
#include "multifold.h"
#include "m_energy_matrix.h"
#include "m_specific_functions.h"

m_multi_loop::m_multi_loop (int *seq, int num_b, int *b, int length)
// The constructor
{
    int i;
    sequence = seq;
    seqlen = length;
    this->V = NULL;
    this->b = b;
    this->num_b = num_b;
    
    index = new int[length]; //(int*) malloc (sizeof(int)*length);
    int total_length = (length *(length+1))/2;
    index[0] = 0;
    for (i=1; i < length; i++)
        index[i] = index[i-1]+length-i+1;

    WM = new PARAMTYPE [total_length];
    if (WM == NULL) giveup ("Cannot allocate memory", "m_multi_loop");
    for (i=0; i < total_length; i++) 
      {
        WM[i] = INF;
      }
                                    
    WM_link = new PARAMTYPE [total_length];
    if (WM_link == NULL) giveup ("Cannot allocate memory", "m_multi_loop");
    for (i=0; i < total_length; i++) 
      {
        WM_link[i] = INF;
      }        
}



m_multi_loop::~m_multi_loop ()
// The destructor
{
    delete [] index;
    delete [] WM;
    delete [] WM_link;
}


void m_multi_loop::compute_energy_WM (int j)
// computes MFE of a regular multi-loop fragment closed by (i,j)
{
    int i;
    PARAMTYPE tmp;

    for (i=j-TURN-1; i>=0; i--)
    {
        int ij = index[i]+j-i;
        int iplus1j = index[i+1]+j-i-1;
        int ijminus1 = index[i]+j-1-i;


        tmp = V->get_energy(i,j) +
                   AU_penalty (sequence[i], sequence[j]) +
                   misc.multi_helix_penalty;
        if (tmp < WM[ij])
          {
            WM[ij] = tmp;
          }

        if (forall_not_equal (num_b, b, i))  //i != link)
        {
            tmp = V->get_energy(i+1,j) +
                  AU_penalty (sequence[i+1], sequence[j]) +
                  dangle_bot [sequence[j]]
                             [sequence[i+1]]
                             [sequence[i]] +
                  misc.multi_helix_penalty +
                  misc.multi_free_base_penalty;
            if (tmp < WM[ij])
            {
                WM[ij] = tmp;
            }
        }

        if (forall_not_equal (num_b, b, j-1))  //j != link+1)

        {
            tmp = V->get_energy(i,j-1) +
                  AU_penalty (sequence[i], sequence[j-1]) +
                  dangle_top [sequence [j-1]]
                             [sequence [i]]
                             [sequence [j]] +
                  misc.multi_helix_penalty +
                  misc.multi_free_base_penalty;
            if (tmp < WM[ij])
            {
                WM[ij] = tmp;
            }
        }

        if (forall_not_equal (num_b, b, i) && forall_not_equal (num_b, b, j-1))  //i != link && j != link+1)
        {
            tmp = V->get_energy(i+1,j-1) +
                  AU_penalty (sequence[i+1], sequence[j-1]) +
                  dangle_bot [sequence[j-1]]
                             [sequence[i+1]]
                             [sequence[i]] +
                  dangle_top [sequence [j-1]]
                             [sequence [i+1]]
                             [sequence [j]] +
                  misc.multi_helix_penalty +
                  2*misc.multi_free_base_penalty;
            if (tmp < WM[ij])
            {
                WM[ij] = tmp;
            }
        }
        if (forall_not_equal (num_b, b, i))  //link != i)
          {
            tmp = WM[iplus1j] + misc.multi_free_base_penalty;            
            if (tmp < WM[ij])
              {
                WM[ij] = tmp;
              }
          }
        if (forall_not_equal (num_b, b, j-1))  //link != j-1)
          {
            tmp = WM[ijminus1] + misc.multi_free_base_penalty;
            if (tmp < WM[ij])
              {
                WM[ij] = tmp;
              }
          }

        for (int k=i; k < j; k++)
          {
            if (exists_equal (num_b, b, k))  //link == k) 
              continue;
            int ik = index[i]+k-i;
            int kplus1j = index[k+1]+j-k-1;
            tmp = WM[ik] + WM[kplus1j];
            if (tmp < WM[ij])
              {
                WM[ij] = tmp;
              }
          }

    }
}


void m_multi_loop::compute_energy_WM_link (int j)
// computes MFE of a special multi-loop fragment closed by (i,j)
{
    int i;
    PARAMTYPE tmp;
  
    for (i=j-TURN-1; i>=0; i--)
    {
            
        int ij = index[i]+j-i;
        int iplus1j = index[i+1]+j-i-1;
        int ijminus1 = index[i]+j-1-i;

        // added Jan 26, 2004
        // if i <= b < j, return infinity
        
        if (exists_greater_and_less (num_b, b, i-1, j))  //i <= link && link < j)
        {
            WM_link[ij] = INF;
            continue;
        }                                
        
        // calculate WM[i][j]
        tmp = V->get_energy(i,j) + AU_penalty (sequence[i], sequence[j]);
        if (tmp < WM_link[ij])
          {
            WM_link[ij] = tmp;
          }

        tmp = V->get_energy(i+1,j) + AU_penalty (sequence[i+1], sequence[j]) + 
          dangle_bot [sequence[j]][sequence[i+1]][sequence[i]];
        if (tmp < WM_link[ij])
          {
            WM_link[ij] = tmp;
          }

        tmp = V->get_energy(i,j-1) + AU_penalty (sequence[i], sequence[j-1]) + 
          dangle_top [sequence [j-1]][sequence [i]][sequence [j]];
        if (tmp < WM_link[ij])
          {
            WM_link[ij] = tmp;
          }

        tmp = V->get_energy(i+1,j-1) +
              AU_penalty (sequence[i+1], sequence[j-1]) + 
                   dangle_bot [sequence[j-1]]
                              [sequence[i+1]]
                              [sequence[i]] +
                   dangle_top [sequence [j-1]]
                              [sequence [i+1]]
                              [sequence [j]];
        if (tmp < WM_link[ij])
          {
            WM_link[ij] = tmp;
          }

        tmp = WM_link[iplus1j];
        if (tmp < WM_link[ij])
          {
            WM_link[ij] = tmp;
          }

        tmp = WM_link[ijminus1];
        if (tmp < WM_link[ij])
          {
            WM_link[ij] = tmp;
          }

        for (int k=i; k < j; k++)
          {
            int ik = index[i]+k-i;
            int kplus1j = index[k+1]+j-k-1;
            tmp = WM_link[ik] + WM_link[kplus1j];
            if (tmp < WM_link[ij])
              {
                WM_link[ij] = tmp;
              }
          }

    }
}


PARAMTYPE m_multi_loop::compute_energy_regular (int i, int j)
// computes MFE of a regular multi-loop closed by (i,j)
{
    PARAMTYPE min = INF, tmp;
    int k;
    int iplus1k;
    int kplus1jminus1;
    int iplus2k;
    int kplus1jminus2;

    if (exists_equal (num_b, b, i) || exists_equal (num_b, b, j-1))  //i == link || j-1 == link) 
      return INF;

    for (k = i+TURN+1; k <= j-TURN-2; k++)
      {
        iplus1k = index[i+1] + k -i-1;
        kplus1jminus1 = index[k+1] + j-1 -k-1;
        iplus2k = index[i+2] + k -i-2;
        kplus1jminus2 = index[k+1] + j-2 -k-1;
        
        if (forall_not_equal (num_b, b, k))  //link != k)
          {
            tmp = WM[iplus1k] + WM[kplus1jminus1];
            if (tmp < min)
              min = tmp;
          }
        if (forall_not_equal (num_b, b, i+1) && forall_not_equal (num_b, b, k))  //link != i+1 && link != k)
          {
            tmp = WM[iplus2k] + WM[kplus1jminus1] + 
              dangle_top [sequence [i]]
              [sequence [j]]
              [sequence [i+1]] + 
              misc.multi_free_base_penalty;
            if (tmp < min)
              min = tmp;
          }
        if (forall_not_equal (num_b, b, k) && forall_not_equal (num_b, b, j-2))  //link != k && link != j-2)
          {
            tmp = WM[iplus1k] + WM[kplus1jminus2] + 
              dangle_bot [sequence[i]]
              [sequence[j]]
              [sequence[j-1]] + 
              misc.multi_free_base_penalty;
            if (tmp < min)
              min = tmp;
          }
        if (forall_not_equal (num_b, b, i+1) && forall_not_equal (num_b, b, k) &&
            forall_not_equal (num_b, b, j-2))   //link != i+1 && link != k && link != j-2)
          {
            tmp = WM[iplus2k] + WM[kplus1jminus2] + 
              dangle_top [sequence [i]]
              [sequence [j]]
              [sequence [i+1]] +  
              dangle_bot [sequence[i]]
              [sequence[j]]
              [sequence[j-1]] + 
              2 * misc.multi_free_base_penalty;
              
            // moved this inside the brackets on Jan 21, 2005    
            if (tmp < min)
              min = tmp;              
          }
      }
                              
    min += misc.multi_helix_penalty + misc.multi_offset +
           AU_penalty (sequence[i], sequence[j]);
    return min;
}



PARAMTYPE m_multi_loop::compute_energy_link (int i, int j)
// computes MFE of a special multi-loop closed by (i,j)
{
  int k;
    PARAMTYPE min = INF, tmp;
    int q;

    if (forall_less (num_b, b, i) || forall_greater (num_b, b, j-1))  //link < i || link >= j)
        return INF;

    for (q = 0; q < num_b; q++)
      {
        if (b[q] >= i && b[q] < j)
          {

            tmp = get_energy_WM_link (i+1,b[q]) + get_energy_WM_link (b[q]+1,j-1);      
            if (tmp < min)
              {
                min = tmp;
              }
    
            tmp = get_energy_WM_link (i+2,b[q]) + get_energy_WM_link (b[q]+1,j-1);
            if (forall_not_equal (num_b, b, i))
              tmp += dangle_top [sequence[i]][sequence[j]][sequence[i+1]];
            if (tmp < min)
              {
                min = tmp;
              }
        
            tmp = get_energy_WM_link (i+1, b[q]) + get_energy_WM_link (b[q]+1,j-2);
            if (forall_not_equal (num_b, b, j-1))
              tmp += dangle_bot [sequence[i]][sequence[j]][sequence[j-1]];
            if (tmp < min)
              {
                min = tmp;
              }
        
            tmp = get_energy_WM_link (i+2,b[q]) + get_energy_WM_link (b[q]+1,j-2);
            if (forall_not_equal (num_b, b, i))
              tmp += dangle_top [sequence[i]][sequence[j]][sequence[i+1]];
            if (forall_not_equal (num_b, b, j-1))
              tmp += dangle_bot [sequence[i]][sequence[j]][sequence[j-1]];
            if (tmp < min)
              {
                min = tmp;
              }

            for (k = b[q]+1; k < j; k++)
              {
                tmp = get_energy_WM_link (b[q]+1,k) + get_energy_WM_link (k+1,j-1);
                if (forall_not_equal (num_b, b, i)) 
                  tmp += dangle_top[sequence[i]][sequence[j]][sequence[i+1]];
                if (tmp < min)
                  {
                    min = tmp;
                  }
              }
    
            for (k = b[q]+1; k < j; k++)
              {
                tmp = get_energy_WM_link (b[q]+1,k) + get_energy_WM_link (k+1,j-2);
                if (forall_not_equal (num_b, b, i)) 
                  tmp += dangle_top[sequence[i]][sequence[j]][sequence[i+1]];
                if (forall_not_equal (num_b, b, j-1))
                  tmp += dangle_bot [sequence[i]][sequence[j]][sequence[j-1]];
                if (tmp < min)
                  {
                    min = tmp;
                  }
              }

            for (k = i+1; k < b[q]; k++)
              {
                tmp = get_energy_WM_link (i+1,k) + get_energy_WM_link (k+1,b[q]);
                if (forall_not_equal (num_b, b, j-1)) 
                  tmp += dangle_bot [sequence[i]][sequence[j]][sequence[j-1]];
                if (tmp < min)
                  {
                    min = tmp;
                  }
              }
            
            for (k = i+1; k < b[q]; k++)
              {
                tmp = get_energy_WM_link (i+2,k) + get_energy_WM_link (k+1,b[q]);
                if (forall_not_equal (num_b, b, i))
                  tmp += dangle_top[sequence[i]][sequence[j]][sequence[i+1]];
                if (forall_not_equal (num_b, b, j-1))
                  tmp += dangle_bot [sequence[i]][sequence[j]][sequence[j-1]];
                if (tmp < min)
                  {
                    min = tmp;
                  }
              }
          }
      }            

    min += misc.intermolecular_initiation + AU_penalty (sequence[i], sequence[j]);
    if (min < INF)
      return min;   
    return INF;
}

