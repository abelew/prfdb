
//////////////////////////////////////////////////


    int ARN_structure::Ajouter_Paire(int e1, int e2){
        
		Actualiser_Paires_Ajout( e1, e2 );
        return (Energie_Ajouter_Michael(e1,e2));

    };


//////////////////////////////////////////////////

    int ARN_structure::Retirer_Paire( int e1, int e2 ){
		
		Actualiser_Paires_Retrait(e1,e2);
       	return (Energie_Retirer_Michael(e1,e2));
	};

  
//////////////////////////////////////////////////////////////

	int Resout_Conflits_Deux(int helmax1, int helmax2, const tab2& H_Exclusions){
		if(H_Exclusions[helmax1][helmax2]==0) return -1;
		return 2;
    };


//////////////////////////////////////////////////////////////////



inline int ARN_structure::Remplacer_Paire(int e1, int e2, int e3, int e4){
	
	Actualiser_Paires_Retrait(e1,e2);
	Actualiser_Paires_Ajout(e3,e4);
	return 0;
} 

//////////////////////////////////////////////////////////////////

