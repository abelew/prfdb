
void Initialise_Modele_Energie_Moi_3(){
    Initialise_Enthalpie_Moi_3();
	Initialise_Enthalpie_I_Moi_3();
	Initialise_Enthalpie_T_Moi_3();
	Initialise_Entropie_Moi_3();
	Initialise_Entropie_I_Moi_3();
	Initialise_Entropie_T_Moi_3();
    Initialise_Enthalpie_Stack_T_Moi_3();
	Initialise_Entropie_Stack_T_Moi_3();
	Initialise_Enthalpie_Stack_Terminal_Base_Modifiee_D();
	Initialise_Entropie_Stack_Terminal_Base_Modifiee_D();
	Initialise_Enthalpie_Boucle_Interne();
    Initialise_Entropie_Boucle_Interne();
	Initialise_Enthalpie_Bulge();

}

////////////////////////////////////////////////

void Initialise_Entropie_Moi_3(){
    Entropie[0][3][0][3] = 0;
	Entropie[0][3][1][2] = 0;
	Entropie[0][3][2][1] = 0;
	Entropie[0][3][3][0] = 0;
	Entropie[0][3][2][3] = 0;
	Entropie[0][3][3][2] = 0;
	Entropie[1][2][0][3] = 0;
	Entropie[1][2][1][2] = 0;
	Entropie[1][2][2][1] = 0;
	Entropie[1][2][3][0] = 0;
	Entropie[1][2][2][3] = 0;
	Entropie[1][2][3][2] = 0;
	Entropie[2][1][0][3] = 0;
	Entropie[2][1][1][2] = 0;
	Entropie[2][1][2][1] = 0;
	Entropie[2][1][3][0] = 0;
	Entropie[2][1][2][3] = 0;
	Entropie[2][1][3][2] = 0;
	Entropie[3][0][0][3] = 0;
	Entropie[3][0][1][2] = 0;
	Entropie[3][0][2][1] = 0;
	Entropie[3][0][3][0] = 0;
	Entropie[3][0][2][3] = 0;
	Entropie[3][0][3][2] = 0;
	Entropie[2][3][0][3] = 0;
	Entropie[2][3][1][2] = 0;
	Entropie[2][3][2][1] = 0;
	Entropie[2][3][3][0] = 0;
	Entropie[2][3][2][3] = 0;
	Entropie[2][3][3][2] = 0;
	Entropie[3][2][0][3] = 0;
	Entropie[3][2][1][2] = 0;
	Entropie[3][2][2][1] = 0;
	Entropie[3][2][3][0] = 0;
	Entropie[3][2][2][3] = 0;
	Entropie[3][2][3][2] = 0;
	
}

//////////////////////////////////////////////////////////

void Initialise_Enthalpie_Bulge(){

	fstream f("Modele_Energie_Moi_3_Bulge.txt",fstream::in);
	if(!f.is_open()) cerr<<"Missing bulg energy file !"<<endl;
  
	double d;
  
    f>>d; Enthalpie_Bulge[0] = (int)(d*precision);
	f>>d; Enthalpie_Bulge[1] = (int)(d*precision);
	f>>d; Enthalpie_Bulge[2] = (int)(d*precision);
	f>>d; Enthalpie_Bulge[3] = (int)(d*precision);
	Enthalpie_Bulge[4] = (int)(10.0*precision);
	f>>d; Enthalpie_Bulge[5] = (int)(d*precision); 

}

/////////////////////////////////////////////////////



void Initialise_Entropie_I_Moi_3(){
    Entropie_I[0][3] = 0;
	Entropie_I[1][2] = 0;
	Entropie_I[2][1] = 0;
	Entropie_I[3][0] = 0;
	Entropie_I[2][3] = 0;
	Entropie_I[3][2] = 0;
}


////////////////////////////////////////////////////


void Initialise_Entropie_T_Moi_3(){
    Entropie_T[0][3] = 0;
	Entropie_T[1][2] = 0;
	Entropie_T[2][1] = 0;
	Entropie_T[3][0] = 0;
	Entropie_T[2][3] = 0;
	Entropie_T[3][2] = 0;
}

////////////////////////////////////////////////////


void Initialise_Enthalpie_Boucle_Interne(){
  
	fstream f("Modele_Energie_Moi_3_Interne.txt",fstream::in);
	if(!f.is_open()) cerr<<"Missing intenal loops energy file !"<<endl;
  
	double i11,i12,i13,i23,i22;
  
	f>>i11 ; f>>i12 ; f>>i22 ; f>>i13 ; f>>i23 ;
  
	Enthalpie_Boucle_Interne[0][0]=0;
	Enthalpie_Boucle_Interne[0][1]=0;
	Enthalpie_Boucle_Interne[0][2]=0;
	Enthalpie_Boucle_Interne[0][3]=0;
	Enthalpie_Boucle_Interne[1][0]=0;
	
	Enthalpie_Boucle_Interne[1][1] = (int)(i11*precision);
	
	Enthalpie_Boucle_Interne[1][2]= (int)(i12*precision);
	Enthalpie_Boucle_Interne[1][3]= (int)(i13*precision);
	Enthalpie_Boucle_Interne[2][0]=0;
	Enthalpie_Boucle_Interne[2][1]= (int)(i12*precision);
	Enthalpie_Boucle_Interne[2][2]= (int)(i22*precision);
	Enthalpie_Boucle_Interne[2][3]= (int)(i23*precision);
	Enthalpie_Boucle_Interne[3][0]=0;
	Enthalpie_Boucle_Interne[3][1]= (int)(i13*precision);
	Enthalpie_Boucle_Interne[3][2]= (int)(i23*precision);
	Enthalpie_Boucle_Interne[3][3]=0;
	f.close();

}

////////////////////////////////////////////////////

void Initialise_Enthalpie_Stack_T_Moi_3(){
    fstream f("Modele_Energie_Moi_3_Stack_Terminal.txt",fstream::in);
	if(!f.is_open()){
		for(int i = 0 ; i<4 ; i++){
	        for(int j = 0 ; j<4 ; j++){
		        for(int k = 0 ; k<4 ; k++){
			        for(int l = 0 ; l<4 ; l++){
				        Enthalpie_Stack_T[i][j][k][l] = Enthalpie_I[i][j];
				    }
			    }
		    }
	    }
	}
	
	else{
	    int a,i,j,k; double val;
		while(f.good()){
		    f>>a ; f>>val ;
			i = a/1000;
			a-=i*1000;
			j = a/100;
			a-=j*100;
			k = a/10;
			a-=k*10;
			--i; --j; --k; --a;
			Enthalpie_Stack_T[i][j][k][a] = (int)(val*precision);
		}
	}
}

///////////////////////////////////////////////////

void Initialise_Entropie_Stack_T_Moi_3(){
    for(int i = 0 ; i<4 ; i++){
	    for(int j = 0 ; j<4 ; j++){
		    for(int k = 0 ; k<4 ; k++){
			    for(int l = 0 ; l<4 ; l++){
				    Entropie_Stack_T[i][j][k][l] = Entropie_I[i][j];
				}
			}
		}
	}
}

///////////////////////////////////////////////////


void Initialise_Enthalpie_Moi_3(){

	fstream f("Modele_Energie_Moi_3_Stack.txt",fstream::in);
    int a ; double val;
	int i,j,k,l;
    while(f.good()){
	    f>>a ;  f>>val;
		if( a/10 ==1){ i=0 ; j=3; }
		else if( a/10 ==2){ i=1 ; j=2; }
		else if( a/10 ==3){ i=2 ; j=3; }
		else if( a/10 ==4){ i=3 ; j=2; }
		else if( a/10 ==5){ i=2 ; j=1; }
		else if( a/10 ==6){ i=3 ; j=0; }
		if( a%10 ==1){ k=0 ; l=3; }
		else if( a%10 ==2){ k=1 ; l=2; }
		else if( a%10 ==3){ k=2 ; l=3; }
		else if( a%10 ==4){ k=3 ; l=2; }
		else if( a%10 ==5){ k=2 ; l=1; }
		else if( a%10 ==6){ k=3 ; l=0; }
		Enthalpie[i][j][k][l]=(int)(val*precision);
	}
}


/////////////////////////////////////////////////////////


void Initialise_Enthalpie_I_Moi_3(){
    
	fstream f("Modele_Energie_Moi_3_Term.txt",fstream::in);
    int a ; double val;
	int i,j;
    while(f.good()){
	    f>>a ;  f>>val;
		if( a ==1){ i=0 ; j=3; }
		else if( a ==2){ i=1 ; j=2; }
		else if( a ==3){ i=2 ; j=3; }
		else if( a ==4){ i=3 ; j=2; }
		else if( a ==5){ i=2 ; j=1; }
		else if( a ==6){ i=3 ; j=0; }
		Enthalpie_I[i][j]=(int)(val*precision);
	}
}	


/////////////////////////////////////////////////////////


void Initialise_Enthalpie_T_Moi_3(){

fstream f("Modele_Energie_Moi_3_Term.txt",fstream::in);
    int a ; double val;
	int i,j;
    while(f.good()){
	    f>>a ;  f>>val;
		if( a ==1){ i=0 ; j=3; }
		else if( a ==2){ i=1 ; j=2; }
		else if( a ==3){ i=2 ; j=3; }
		else if( a ==4){ i=3 ; j=2; }
		else if( a ==5){ i=2 ; j=1; }
		else if( a ==6){ i=3 ; j=0; }
		Enthalpie_T[j][i]=(int)(val*precision);
	}
}
