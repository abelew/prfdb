	Helice2::~Helice2(){
	};
    bool Helice2::Est_Dans(Paire P){
	    for(V_P::iterator p = LP.begin() ; p!= LP.end(); p++){
			if(P==(*p)) return true;
		}
		return false;
	}
	void Helice2::Afficher(){
	    for(V_P::iterator p = LP.begin() ; p != LP.end() ; p++) (*p).Afficher_P();
		cout<<"G = "<<G<<endl;
	}
	bool Helice2::Meme(Helice2 R){
	    for(V_P::iterator p = (R.LP).begin() ; p != (R.LP).end() ; p++){
		    for(V_P::iterator q = LP.begin() ; q != LP.end() ; q++){
			    if( ((*p).b_amont == (*q).b_amont) && ((*p).b_aval == (*q).b_aval) ) return true; 
			}    
		}
		return false;
	}
    bool Helice2::Helices_Se_Chevauchent(const Helice2& R){
		int a1 = LP.front().b_amont;
		int a2 = LP.front().b_aval;
		int b1 = LP.back().b_amont;
		int b2 = LP.back().b_aval;		
		int e1 = R.LP.front().b_amont;
		int e2 = R.LP.front().b_aval;
		int f1 = R.LP.back().b_amont;
		int f2 = R.LP.back().b_aval;
		if( (a1<=e1 && e1<=b1) || (b2<=e1 && e1<=a2) ||  (a1<=e2 && e2<=b1) || (b2<=e2 && e2<=a2) )
		    return true;		
		if( (a1<=f1 && f1<=b1) || (b2<=f1 && f1<=a2) ||  (a1<=f2 && f2<=b1) || (b2<=f2 && f2<=a2) )
		    return true;		
		if( (e1<=a1 && a1<=f1) || (f2<=a1 && a1<=e2) ||  (e1<=a2 && a2<=f1) || (f2<=a2 && a2<=e2) )
		    return true;		
		if( (e1<=b1 && b1<=f1) || (f2<=b1 && b1<=e2) ||  (e1<=b2 && b2<=f1) || (f2<=b2 && b2<=e2) )
		    return true;
		if( a1>f1 && a1-f1-1<=t_boucle_interne && f2>a2 && f2-a2-1<=t_boucle_interne) return true;
		if( a1==f1+1 && f2>a2 && f2-a2-1<=t_bulge_max) return true;
		if( a1>f1 && a1-f1-1<=t_bulge_max && f2==a2+1 ) return true;		
		if( e1>b1 && e1-b1-1<=t_boucle_interne && b2>e2 && b2-e2-1<=t_boucle_interne) return true;
		if( e1==b1+1 && b2>e2 && b2-e2-1<=t_bulge_max) return true;
		if( e1>b1 && e1-b1-1<=t_bulge_max && b2==e2+1 ) return true;
		return false;		
	}
	bool Helice2::Test_ABAB_Noeud_Foireux(const Helice2& R){
		int a1 = LP.front().b_amont;
		int a2 = LP.front().b_aval;
		int e1 = R.LP.front().b_amont;
		int e2 = R.LP.front().b_aval;		
		if( e1>a2 || a1>e2) return false;
		if( (a1-e1)*(a2-e2)<0 )  return false;
		int b1 = LP.back().b_amont;
		int b2 = LP.back().b_aval;		
		int f1 = R.LP.back().b_amont;
		int f2 = R.LP.back().b_aval;
		int mou=0;	
		if( e1>b1 && e1<b2 ){
			if( f1-e1+2 >= b2-b1-mou) return true;
			if( a2-b2+2 >= f2-f1-mou) return true;
			if( (e1-b1) + (b2-f1) +(f2-a2) +3 < LP.size() && (e1-b1) + (b2-f1) +(f2-a2) +3 < R.LP.size() ) return true; //test st�rique 
		}		
		else{
		    if( b1-a1+2 >= f2-f1-mou) return true;
			if( e2-f2+2 >= b2-b1-mou) return true;
			if( (a1-f1) + (f2-b1) + (b2-e2) +3 < LP.size() && (a1-f1) + (f2-b1) + (b2-e2) +3 < R.LP.size() ) return true;
		}	
		if(LP.size()>10 && R.LP.size()>10) return true;		
		return false;	
	}
    int Helice2::Compatible(Helice2 R){
		if (Helices_Se_Chevauchent(R)) return 0;		
		int a1 = LP.front().b_amont;
		int a2 = LP.front().b_aval;
		int b1 = LP.back().b_amont;
		int b2 = LP.back().b_aval;		
		int e1 = R.LP.front().b_amont;
		int e2 = R.LP.front().b_aval;
		int f1 = R.LP.back().b_amont;
		int f2 = R.LP.back().b_aval;		
		if( (a1<e1 && e1<a2 && a2<e2) || (e1<a1) && (a1<e2) && (e2<a2) ){
			if( LP.size() > 10 && R.LP.size() > 10) return 0;
			int l1, l2, l3;		
			if(a1<e1) {
				l1 = e1-b1;
				l2 = b2-f1;
				l3 = f2-a2;
			}		
			else {
				l1 = a1-f1;
				l2 = f2-b1;
				l3 = b2-e2;
			}		
			if( l1+l3<t_sterique+2 ) return 0;			
		}	
		else{			
			int l1,l2,l3;		
			if( a2<e1 || e2<a1 ) return 3; 
			if(a1<e1){
				l1 = e1-b1;
				l2 = b2-e2;
			}			
			else{
				l1 = a1-f1;
				l2 = f2-a2;
			}		
			if(l1<=t_boucle_interne && l2<=t_boucle_interne) return 0;
			if( ( l1==1 && l2<t_bulge_max+2 ) || ( l2==1 && l1<t_bulge_max+2 ) ) return 0;
			return 1;
		}		
		return 3;
	}
 	void Construit_H_Exclusions( tab2& H_Exclusions){	
		fflush(stdout);
		time_t t_secondes = time(NULL);
		H_Exclusions = tab2(n_helice_favorable, tab(n_helice_favorable,0));
		for(int i = 0 ; i < n_helice_favorable ; i++){ 
			for(int j = i+1 ; j<n_helice_favorable ; j++){
				if(!HELICE[i].Helices_Se_Chevauchent(HELICE[j]) && !HELICE[i].Test_ABAB_Noeud_Foireux(HELICE[j]) ){
					H_Exclusions[i][j] = 3;
					H_Exclusions[j][i] = 3;
				}
			}}}
int ARN_structure::Rajoute_Helice2(int n){
    int dG=0;
	V_P::iterator p = (HELICE[n].LP).begin() ;
	V_P::iterator q = (HELICE[n].LP).end() ;
	for(p ; p!=q ; p++){
		dG+=Ajouter_Paire((*p).b_amont , (*p).b_aval);		
	}
	return dG;
}
int ARN_structure::Enleve_Helice2(int n){
    int dG=0;
	V_P::iterator p = (HELICE[n].LP).begin() ;
	V_P::iterator q = (HELICE[n].LP).end() ;
	for(p ; p!=q ; p++){
		dG+=Retirer_Paire((*p).b_amont , (*p).b_aval);
	}
	return dG;
}
