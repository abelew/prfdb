Graphe_Final::Graphe_Final(int l_sequence){
	genre=0;
	l_seq=2*l_sequence;
	E_totale=0;
	Prepare_Les_Partitions();
	Initialise_Seq_Chaine_Suivant();
	Mem_seq_chaine = TabOptConst(l_seq);
}

void Graphe_Final::Prepare_Les_Partitions(){
	tab2 H_Exclusions;
	Construit_H_Exclusions(H_Exclusions);
	Prepare_CC1();
	Prepare_CC2(H_Exclusions);
}
void Graphe_Final::Prepare_CC1(){
    CC1.resize(n_helice_max);
	for(int i =0 ; i<n_helice_max ; ++i){
	    CC1[i].resize(4);
		CC1[i][0] = i;
		CC1[i][1] = HELICE[i].G;
		CC1[i][2] = 2*HELICE[i].LP.front().b_amont;
		CC1[i][3] = 2*HELICE[i].LP.front().b_aval;
	}
}
void Graphe_Final::Prepare_CC2(const tab2& H_Exclusions){
	int compt=0;
	int compt2=0;
	CC2.resize(n_helice_max);
	for(int i = 0; i<n_helice_max ; ++i){
		CC2[i].resize(n_helice_max);
		for(int j= 0 ; j<n_helice_max ; ++j){
		    CC2[i][j].resize(3);
		}
	}
	for(int i = 0; i<n_helice_max ; ++i){	
		for(int j = i+1 ; j<n_helice_max ; ++j){
			int Cij = Resout_Conflits_Deux(i,j, H_Exclusions);
			if(Cij!=-1){
					CC2[i][j][0] = n_helice_favorable;
					CC2[i][j][1] = n_helice_favorable;
					CC2[i][j][2] = CC1[i][1]+CC1[j][1]; 
					CC2[j][i][0] = n_helice_favorable;
					CC2[j][i][1] = n_helice_favorable;
					CC2[j][i][2] = CC1[i][1]+CC1[j][1]; 
			}
			else{
				CC2[i][j][0] = -1;
				CC2[i][j][1] = -1;
				CC2[i][j][2] = 0;
				CC2[j][i][0] = -1;
				CC2[j][i][1] = -1;
				CC2[j][i][2] = 0;
				++compt2;
			}
		}
	}
}	
void Graphe_Final::Initialise_Seq_Chaine_Suivant(){
	seq_chaine_suivant=tab(l_seq+1,-1);
	seq_chaine_suivant[l_seq] = l_seq+1;  
};
void Graphe_Final::Ajouter_Seq_Chaine_Suivant(int e1, int e2){ 
	seq_chaine_suivant[e1]=e2+1;
	seq_chaine_suivant[e2]=e1+1;
    int i = l_seq;
	while(seq_chaine_suivant[i]<e1) i=seq_chaine_suivant[i]+1;	
	if(seq_chaine_suivant[i] > e2){
		seq_chaine_suivant[e1+1]=e2;
		seq_chaine_suivant[e2+1]=seq_chaine_suivant[i];
		seq_chaine_suivant[i]=e1;
		Mem_seq_chaine.push_back(-1);
		Mem_seq_chaine.push_back(i);
		return;
	}	
	seq_chaine_suivant[e1+1]=seq_chaine_suivant[i];
	seq_chaine_suivant[i]=e1;
	Mem_seq_chaine.push_back(i);
	i=seq_chaine_suivant[e1+1]+1;
	while(seq_chaine_suivant[i]<e2) i=seq_chaine_suivant[i]+1;	
	seq_chaine_suivant[e2+1] = seq_chaine_suivant[i];
	seq_chaine_suivant[i] = e2;
	Mem_seq_chaine.push_back(i);

};
inline void Graphe_Final::Retirer_Seq_Chaine_Suivant(int e1, int e2){
	seq_chaine_suivant[Mem_seq_chaine.back()] = seq_chaine_suivant[e2+1];
	Mem_seq_chaine.pop_back();
	if(Mem_seq_chaine.back()!=-1) seq_chaine_suivant[Mem_seq_chaine.back()] = seq_chaine_suivant[e1+1];
	Mem_seq_chaine.pop_back();
}
inline void Graphe_Final::Retirer_Genre(){
    if(Mem_genre.back()==1){
	    --genre;
		E_totale-=mu;
	}
	Mem_genre.pop_back();
}
bool Graphe_Final::Delta_Genre_Repense_ABCABC_Ajout(const int e1, const int e2){
	int i =seq_chaine_suivant[l_seq]+1;	
	int precedent = l_seq;	
	while (i<e1) {
		precedent=i;
		i=seq_chaine_suivant[i]+1;
	}	
	if(i>e2) {	
	    seq_chaine_suivant[e1]=e2+1;
	    seq_chaine_suivant[e2]=e1+1;
	    seq_chaine_suivant[e1+1]=e2;
	    seq_chaine_suivant[e2+1]=i-1;
	    seq_chaine_suivant[precedent]=e1;
	    Mem_seq_chaine.push_back(-1);
	    Mem_seq_chaine.push_back(precedent);
		Mem_genre.push_back(0);
	    return true;
	}
	const int d1 = i-1;
	int d2;	
	if(genre!=0){
	    int droite_a_battre = l_seq+1;
	    int gauche_a_battre = e1;
 	    bool milieu = false;	
	    for( ; i<e2 ; i=seq_chaine_suivant[i]+1 ){
		    d2=i;
			if(seq_chaine_suivant[i-1]>e2){
			    if(seq_chaine_suivant[i-1]>droite_a_battre) return false;
			    milieu=true;
			    droite_a_battre=seq_chaine_suivant[i-1];
		    }
		
		    else if( seq_chaine_suivant[i-1]<e1 ){
			    if(seq_chaine_suivant[i-1]>gauche_a_battre) return false;
			    if(milieu) return false;
			    gauche_a_battre=seq_chaine_suivant[i-1];
		    }
	    }}	
	else {
	    while(seq_chaine_suivant[i]<e2) i=seq_chaine_suivant[i]+1;
	    d2=i;
	}	
	i=seq_chaine_suivant[d1];	
	while( i!=l_seq+1 && i!=d2 && i!=d1 ) i=seq_chaine_suivant[i];	
	if(i!=d2){
	    if(i==d1){
		    if(genre==gmax) return false;
			++genre;
			Mem_genre.push_back(1);
			E_totale+=mu;
		}	
	    else{
		    i = seq_chaine_suivant[l_seq];
	        while(i!=d2 && i!=d1){
		        i = seq_chaine_suivant[i];
	        }
		    if(i!=d2){
			    if(genre==gmax) return false;
				++genre;
				Mem_genre.push_back(1);
				E_totale+=mu;
			}
			else Mem_genre.push_back(0);
		}
	}
	else Mem_genre.push_back(0);	
	seq_chaine_suivant[e1]=e2+1;
	seq_chaine_suivant[e2]=e1+1;
	seq_chaine_suivant[e1+1]=d1;
	seq_chaine_suivant[precedent]=e1;
	Mem_seq_chaine.push_back(precedent);
	seq_chaine_suivant[e2+1] = seq_chaine_suivant[d2];
	seq_chaine_suivant[d2] = e2;
	Mem_seq_chaine.push_back(d2);	
};
	bool Graphe_Final::Partition_Ajout(const int e1){
		const tab::iterator q = L_che.end();
		for(tab::iterator p=L_che.begin(); p!=q ; ++p){
			if(CC2[*p][e1][0] == -1) {
				return false;
			}
		}			
		if(!Delta_Genre_Repense_ABCABC_Ajout(CC1[e1][2],CC1[e1][3])) return false;			
		E_totale += CC1[e1][1];
		L_che.push_back(e1);
		return true;
	};
bool Graphe_Final::Partition_Retrait(const int e1){
	L_che.pop_back();
	Retirer_Seq_Chaine_Suivant(CC1[e1][2],CC1[e1][3]);
	Retirer_Genre();
	E_totale -=  CC1[e1][1];
			
	return true;
}
inline int Graphe_Final::Remplacer_Paire(int e1, int e2, int e3, int e4){
	++n_remplacements;
	int i = l_seq;
	if(e1!=e3){
	    while(seq_chaine_suivant[i]!=e1) i=seq_chaine_suivant[i]+1;
		seq_chaine_suivant[i]=e3;
		seq_chaine_suivant[e3+1]=seq_chaine_suivant[e1+1];
	}
	if(e2!=e4){
	    while(seq_chaine_suivant[i]!=e2) {
		    i=seq_chaine_suivant[i]+1;
		}
		seq_chaine_suivant[i]=e4;
		seq_chaine_suivant[e4+1]=seq_chaine_suivant[e2+1];
	}
	seq_chaine_suivant[e3]=e4+1;
	seq_chaine_suivant[e4]=e3+1;
	return 0;
} 

void Graphe_Final::Prolonge_Max_Heur(const int n){    
	if( E_totale + H1[n] > Top_G.back() ) return;	
	if(Partition_Ajout(n)){	
		if(E_totale < Top_G.back() ){ 
			Inserer_Dans_Top(Top_St, Top_G);
			G_min = E_totale;
		}	
		const int nh = n_helice_max;
	    for(int i = n+1 ; i<nh ; ++i){
			Prolonge_Max_Heur(i);
		}		
		Partition_Retrait(n); 
		++n_baquetraque;
	
	}
};
void Graphe_Final::Prolonge_Max_Heur_Verif_Doublon(const int n){    
	if( E_totale + H1[n] > Top_G.back() ) return;	
	if(Partition_Ajout(n)){	
		if(E_totale < Top_G.back() ){ 
			Inserer_Dans_Top_Verif_Doublon(Top_St, Top_G);
			G_min = E_totale;
		}	
		const int nh = n_helice_max;
	    for(int i = n+1 ; i<nh ; ++i){
			Prolonge_Max_Heur_Verif_Doublon(i);
		}		
		Partition_Retrait(n); 
		++n_baquetraque;
	
	}
};
void Graphe_Final::Prolonge_Max_Heur2(const int n){    
	if( E_totale + H2[n] > Top2_G.back() ) return;	
	if(Partition_Ajout(n)){	
		if(E_totale < Top2_G.back() ){ 
			Inserer_Dans_Top(Top2_St, Top2_G);
			G_min = E_totale;
		}	
	    for(int i = n+1 ; i<H2_limite ; ++i){
			Prolonge_Max_Heur2(i);
		}		
		Partition_Retrait(n); 
		++n_baquetraque;	
	}
};
void Graphe_Final::Prolonge_Max_Heur2_Muet(const int n){    
	if( E_totale + H2[n] > G_min ) return;	
	if(Partition_Ajout(n)){	
		if(E_totale < G_min ){ 
			G_min = E_totale;
		}	
	    for(int i = n+1 ; i<H2_limite ; ++i){
			Prolonge_Max_Heur2_Muet(i);
		}		
		Partition_Retrait(n);
		++n_baquetraque;	
	}
};
void Graphe_Final::Construit_H2_Optim(const int m){
	time_t t_seconds = time(NULL);		  
	int mu_sauvegarde = mu;
	mu=0;		  
	G_min=100;
	H2.resize(H2_limite,0);
	cout<<endl<<endl<<"Branch-and-bound for heuristic : "<<endl;
	for(int i = H2_limite-1 ; i>=H2_limite-1-m && i>=0 ; --i){
		Compteur_Classe(H2_limite-1-i,m);
		Prolonge_Max_Heur2_Muet(i);
		H2[i]=G_min;
		G_min=1000;
	}	
	for(int i = H2_limite-2-m; i>=0 ; --i){
		int GG =0;
		for(int j = i+1 ; j<H2_limite ; ++j){
			if(CC2[i][j][0]!=-1 && H2[j] + CC2[i][j][2] - CC1[j][1]<GG) GG = H2[j] + CC2[i][j][2] - CC1[j][1];
		}
		H2[i]=GG;
	}		  
	mu=mu_sauvegarde;		  
	cout<<"    --->    "<<time(NULL) - t_seconds<<" secondes"<<endl; fflush(stdout);		  
}
void Graphe_Final::Construit_Amorces(const int prof2){
	cout<<"///////////"<<n_baquetraque<<"/////////////"<<endl;
	for(int i = 0; i<prof2 ; ++i){
		Prolonge_Max_Heur2(i);
		cout<<"///////////"<<n_baquetraque<<"/////////////"<<endl;
	}
}
void Graphe_Final::Prolonge_Amorces(){
	cout<<"Saturation des amorces : "<<endl;
	LT::iterator p = Top2_St.begin();
	for(int i = 0 ; i<Top2_G.size() ; ++i ){
		Compteur_Classe(i,Top2_G.size());
	    tab::iterator pp = (*p).begin();
		const tab::iterator qq = (*p).end();
		for(;pp!=qq;++pp){
			Partition_Ajout(*pp);
		}		
		if(E_totale<Top_G.back()){
			Inserer_Dans_Top_Verif_Doublon(Top_St, Top_G);
		}		
		for(int i = (*p).back()+1 ; i<n_helice_max ; ++i){
		    Prolonge_Max_Heur_Verif_Doublon(i);
		}		
		tab::reverse_iterator ppp= (*p).rbegin();
		const tab::reverse_iterator qqq= (*p).rend();
		for(;ppp!=qqq;++ppp){
			Partition_Retrait(*ppp);
		}	
		++p;
	}
	cout<<endl;
}
void Graphe_Final::Gere_H2(const int H2l, const int seep2, const int prof2, const int n_am){
	H2_limite = H2l;
	Construit_H2_Optim(seep2);
	Top2_G = liste(n_am, 1000);
	Top2_St = LT(n_am);
	Construit_Amorces(prof2);
	
}
void Graphe_Final::Construit_H1_Optim(const int m){
	time_t t_seconds = time(NULL);		  
	int mu_sauvegarde = mu;
	mu=0;		  
	G_min=100;
	H1.resize(n_helice_max,0);
	cout<<endl<<endl<<"Preparation of branch-and-bound : "<<endl;
	for(int i = n_helice_max-1 ; i>=n_helice_max-1-m && i>=0 && time(NULL)<t_seconds+t_attente ; --i){
		Compteur_Classe(n_helice_max-1-i,m);
		Prolonge_Max_Heur_Muet(i);
		H1[i]=G_min;
		G_min=1000;
	}
	for(int i = n_helice_max-2-m; i>=0 ; --i){
		int GG =0;
		for(int j = i+1 ; j<n_helice_max ; ++j){
			if(CC2[i][j][0]!=-1 && H1[j] + CC2[i][j][2] - CC1[j][1]<GG) GG = H1[j] + CC2[i][j][2] - CC1[j][1];
		}
		H1[i]= GG;
	}		  
	mu=mu_sauvegarde;		  
	cout<<"    --->    "<<time(NULL) - t_seconds<<" secondes"<<endl;		  
}

void Graphe_Final::Prolonge_Max_Heur_Muet(const int n){    
	if(E_totale + H1[n] > G_min) return;	
	if(Partition_Ajout(n)){	    
		if(E_totale < G_min){ 
			G_min = E_totale;
		}	
		for(int i = n+1 ; i<n_helice_max ; ++i){
			Prolonge_Max_Heur_Muet(i);
		}			
		Partition_Retrait(n);
		++n_baquetraque;
	}	
};
void Graphe_Final::Inserer_Dans_Top(LT& top_st, liste& top_g){
	liste::iterator p = top_g.begin();
	LT::iterator pp = top_st.begin();
	while(E_totale > *p ) {
		++p;  ++pp;
	}

	top_g.insert( p , E_totale);
	top_st.insert( pp , L_che);
	top_g.pop_back();
	top_st.pop_back();	
}
void Graphe_Final::Inserer_Dans_Top_Verif_Doublon(LT& top_st, liste& top_g){
	liste::iterator p = top_g.begin();
	LT::iterator pp = top_st.begin();
	while(E_totale > *p ) {
		++p;  ++pp;
	}

	while(E_totale == *p  ){
	    if( pp->size() == L_che.size() ){
		    const int ll = L_che.size();
		    bool different = false;
		    for(int i = 0 ; i<ll && !different ; ++i){        
                if( (*pp)[i]!=L_che[i] ) different=true;
            }
		    if(!different) return;
		}
		++p; ++pp;
	}

	top_g.insert( p , E_totale);
	top_st.insert( pp , L_che);
	top_g.pop_back();
	top_st.pop_back();	
}
void Graphe_Final::Ecrit_Structure(tab& L, string& nom, const string& a, ARN_structure* AA, int energie){
	tab::iterator p,q;
	q=L.end();
	for(p=L.begin() ; p!=q ; ++p){
		Partition_Ajout(*p);
	}
	//cout<<endl;	
	tab J;	
	for(p=L.begin() ; p!=q ; ++p){
		J.push_back(CC1[*p][0]);
	}
	//cout<<endl;	
	tab::reverse_iterator boz = L.rend();
	for(tab::reverse_iterator boooz=L.rbegin() ; boooz!=boz ; ++boooz){
		Partition_Retrait(*boooz);
	}
	q=J.end();
	cout<<"indices of helipoints of the structure : ";
	for(p=J.begin() ; p!=q ; ++p){
		cout<<*p<<"  ";
	    AA->Rajoute_Helice2(*p);
	}
	cout<<endl;
	string j = string(nom+'_'+a);
	AA->Ecrit_Structure_Annotee((j+".txt").c_str(), energie);

    AA->Ecrit_Structure_Bpseq((j+".bpseq").c_str());
    AA->Ecrit_Structure_CT((j+".ct").c_str(), energie);
	
	for(p=J.begin() ; p!=q ; ++p){
		AA->Enleve_Helice2(*p);
	}	
}

