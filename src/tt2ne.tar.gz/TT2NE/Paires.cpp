  void Paire::Afficher_P(){
        cout<<"( "<<b_amont<<", "<<b_aval<<") ; ";
    };
    
    Paire::~Paire(){
    };
	
	
//////////////////////////////////////////////////////////

char ARN_structure::Base(int i){
    if(B(i)==0) return 'A';
	if(B(i)==1) return 'C';
	if(B(i)==2) return 'G';
	if(B(i)==3) return 'U';
	if(B(i)==6) return 'a';
	if(B(i)==7) return 'c';
	if(B(i)==8) return 'g';
	if(B(i)==9) return 'u';
	if(B(i)==10) return 'D';
	else return 'X';
}

//////////////////////////////////////////////////////////


 void ARN_structure::Afficher_Paires(){
        cout<<endl<<"Paires : il y en a "<<t_Paires<<endl;
        for(int i = 0;i<l_sequence;i++){
            if(Est_Amont(i)) cout<<"( "<<i<<","<<paires[i][1]<<","<<Base(i)<<Base(aval(i))<<" ), ";
        }
        cout<<endl;
    };
	
	
//////////////////////////////////////////////////////////



bool ARN_structure::Initialise_Appariements(const char* s){
	  
	 //on va d'abord compter le nombre de trucs parce qu'apparemment ca marche pas terrible
	 
	int c = 0;
	ifstream f(s,fstream::in);
	if(!f.is_open()) cerr<<"le fichier de sequence n'est pas ouvert"<<endl;
	char ch;
	while(f.good()){
		f.get(ch);
		if(ch!=' ' && ch!='\n' && ch!='\t'){
		    c++;
			while(f.good() && ch!=' ' && ch!='\n' && ch!='\t'){
			    f.get(ch);
			}
		}
	}
	
	f.close();
	 
	  
	   
	
	 int i,j;
	 int t = 0;
	 int r = 0;
	 fstream ficIn(s,fstream::in);
	 if(!ficIn.is_open()) {
	     cout<<"fichier pas ouvert"<<endl;   
		 return false;
	 }
	 if(!ficIn.good()) return false;
	 ficIn>>i; c-- ; ficIn>>j; c--;
	 while (c>=0) {
	     
		 cout<<i<<"  "<<j<<"  "<<Base(i)<<"  "<<Base(j)<<endl;
		 
		 if(i>j && Conditions_steriques(j,i) ) Ajouter_Paire(j,i);
		 else if(i<j && Conditions_steriques(i,j) )Ajouter_Paire(i,j);
		 t=0; r=0;
		 for(int u =0; u<l_sequence ;u++){
		     t+=SI[u]+ST[u]+S[u];
			 r+=HI[u]+HT[u]+H[u]; 
		 }
		 ficIn>>i; c--;
		 ficIn>>j; c--;
	 }
	 ficIn.close();
	 return true;
}


////////////////////////////////////////////////////////


inline bool ARN_structure::Conditions_steriques(int e1, int e2){
    if (sequence[e1]+sequence[e2] != 3 && sequence[e1]+sequence[e2] != 5) return false;
    
	if(e2-e1<t_sterique) return false;

    return true;
}


/////////////////////////////////////////////////////////////



 inline int ARN_structure::Precedent_Apparie(int e1){
		if(SEQ0==-1) return -1;
		int i = SEQ1;
		while(i!=-1 && i>e1) i=seq_chaine[i][0];
        return i;
    }
   
	
////////////////////////////////////////////////////////////

    
    inline int ARN_structure::Suivant_Apparie(int e1){
        if(SEQ0==-1) return l_sequence;
		int i = SEQ0;
		while(i!=l_sequence && i<e1) i=seq_chaine[i][1];
		return i;
    } 


////////////////////////////////////////////////////////////


    inline bool ARN_structure::Apparie(int i){
        return (paires[i][0]!=-1);
    }   
	
	
/////////////////////////////////////////////////////////////


    
    inline int ARN_structure::amont(int i){
        return paires[i][0];
    };   
    
	
/////////////////////////////////////////////////////////////
	
	
 inline int ARN_structure::aval(int i){
        return paires[i][1];
    };    


/////////////////////////////////////////////////////////////



    void ARN_structure::Actualiser_Paires_Retrait( int e1, int e2 ){
		//cout<<"je debute paires retrait "<<e1<<"  "<<e2<<endl; fflush(stdout);
        paires[e1][0]=-1;
        paires[e1][1]=-1;
        paires[e2][0]=-1;
        paires[e2][1]=-1;

        t_Paires--;
		//cout<<"presque "<<endl; fflush(stdout);
        Retirer_Seq_Chaine(e1);
        Retirer_Seq_Chaine(e2);
		//cout<<"et voila c'est torche "<<endl; fflush(stdout);
    };


//////////////////////////////////////////////////////////////


    void ARN_structure::Actualiser_Paires_Ajout( int e1, int e2){

        paires[e1][0]=e1;
        paires[e1][1]=e2;
        paires[e2][0]=e1;
        paires[e2][1]=e2;

        t_Paires++;
        
        Ajouter_Seq_Chaine(e1);
        Ajouter_Seq_Chaine(e2);

    };


///////////////////////////////////////////////////////////////



inline bool ARN_structure::Est_Amont(int e1){
	return (e1==paires[e1][0]);
};
	
	
////////////////////////////////////////////////////////////////

