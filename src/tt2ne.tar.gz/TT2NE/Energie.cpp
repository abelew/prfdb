

//////////////////////////////////////////////////////////

void Initialise_Enthalpie_Stack_Terminal_Base_Modifiee_D(){
     for(int i = 0; i<5 ; i++){
	     for(int j = 0; j<5 ; j++){
		     for(int k = 0; k<5 ; k++){
		         Enthalpie_Stack_T[4][i][j][k]=(int)(15.0*precision);
				 Enthalpie_Stack_T[i][4][j][k]=(int)(15.0*precision);
				 Enthalpie_Stack_T[i][j][4][k]=(int)(15.0*precision);
				 Enthalpie_Stack_T[i][j][k][4]=(int)(15.0*precision);
			}
		}
	}
}

inline int ARN_structure::H_Bulge(int e1,int e2, int e3, int e4){
    
	
	int tb = e2-e4-1;
	if(tb==0) return 0;
	if(tb==1){
	    return Enthalpie_Bulge[sequence[e2-1]%6];
	}
	
	return (Enthalpie_Bulge[0]+tb*Enthalpie_Bulge[5]);

}

///////////////////////////////////////////////////////////////////////////////

inline int ARN_structure::Entropie_Bulge(int e1,int e2, int e3, int e4){
    return 0;
}

///////////////////////////////////////////////////////////////////////////////

inline int ARN_structure::Enthalpie_Stack_Terminal(int e1, int e2, int e3, int e4){
    if( e3==-1 || e4==l_sequence ){
	    return Enthalpie_I[e1][e2];
	}
	else return Enthalpie_Stack_T[e1][e2][e3][e4];
}

///////////////////////////////////////////////////////////////////////////////

inline int ARN_structure::Entropie_Stack_Terminal(int e1, int e2, int e3, int e4){
    return Entropie_Stack_T[e1][e2][e3][e4];
}


int ARN_structure::Energie_Ajouter_Michael(int e1, int e2){
    
   int dH=0;
   int dS=0;
   bool isole_gauche = true;
   bool isole_droite = true;
   
    //1)
 	if(e1!=0 && e2!=l_sequence-1) HI[e1]=Enthalpie_Stack_Terminal( B(e1), B(e2), B_pour_T(e1-1), B_pour_T(e2+1) );
	else HI[e1]=Enthalpie_I[B(e1)][B(e2)];
	HT[e1]=Enthalpie_Stack_Terminal( B(e2), B(e1), B_pour_T(e2-1), B_pour_T(e1+1) );
	dH+=HI[e1]+HT[e1];
	
	if(e1!=0 && e2!=l_sequence-1) SI[e1]=Entropie_Stack_Terminal( B(e1), B(e2), B_pour_T(e1-1), B_pour_T(e2+1) );
	else SI[e1]=Entropie_I[B(e1)][B(e2)];
	ST[e1]=Entropie_Stack_Terminal( B(e2), B(e1), B_pour_T(e2-1), B_pour_T(e1+1) );
	dS+=SI[e1]+ST[e1];

   if(e1!=0  && paires[e1-1][1]>=e2+1 && paires[e1-1][1]<=e2+1+t_bulge_max){
	   isole_gauche = false;
	   
	   dH-=H[e1-1]+HT[e1-1]+HI[e1];
	   H[e1-1] = Enthalpie[B(e1-1)][B(paires[e1-1][1])][B(e1)][B(e2)] + H_Bulge(e1-1,paires[e1-1][1],e1,e2);
	   HT[e1-1]=0;
	   HI[e1]=0;
	   dH+=H[e1-1];
	   
	   dS-=ST[e1-1]+SI[e1];
	   S[e1-1] = Entropie[B(e1-1)][B(paires[e1-1][1])][B(e1)][B(e2)] + Entropie_Bulge(e1-1,paires[e1-1][1],e1,e2);
	   ST[e1-1]=0;
	   SI[e1]=0;
	   dS+=S[e1-1];
   }

   else if(e2!=l_sequence-1 &&  paires[e2+1][0]>=e1-1-t_bulge_max && paires[e2+1][0]<=e1-1 && paires[e2+1][0]>-1){
	   isole_gauche = false;
	   
	   int c = paires[e2+1][0];
       dH-=H[c]+HT[c]+HI[e1];
	   H[c] = Enthalpie[B(c)][B(e2+1)][B(e1)][B(e2)] + H_Bulge(e2,e1,e2+1,c);
	   HT[c]=0;
	   HI[e1]=0;
	   dH+=H[c];
	   
	   dS-=ST[c]+SI[e1];
	   S[c] = Entropie[B(c)][B(e2+1)][B(e1)][B(e2)] + Entropie_Bulge(e2,e1,e2+1,c);
	   ST[c]=0;
	   SI[e1]=0;
	   dS+=S[c];
   }

    if( paires[e1+1][1]>=e2-1-t_bulge_max && paires[e1+1][1]<=e2-1 ){
       
	   isole_droite = false;
       
	   dH-=HI[e1+1]+HT[e1];
	   H[e1]=Enthalpie[B(e1)][B(e2)][B(e1+1)][B(paires[e1+1][1])] + H_Bulge(e1,e2,e1+1,paires[e1+1][1]);
	   HI[e1+1]=0;
	   HT[e1]=0;
	   dH+=H[e1];
	   
	   dS-=SI[e1+1]+ST[e1];
	   S[e1]=Entropie[B(e1)][B(e2)][B(e1+1)][B(paires[e1+1][1])] + Entropie_Bulge(e1,e2,e1+1,paires[e1+1][1]);
	   SI[e1+1]=0;
	   ST[e1]=0;
	   dS+=S[e1];
   }
   
   else if( paires[e2-1][0]>=e1+1 && paires[e2-1][0]<=e1+1+t_bulge_max){
       
	   isole_droite = false;
	   
	   int c = paires[e2-1][0];
	   dH-=HI[c]+HT[e1];
	   H[e1]=Enthalpie[B(e1)][B(e2)][B(c)][B(e2-1)] + H_Bulge(e2-1,c,e2,e1);
	   HI[c]=0;
	   HT[e1]=0;
	   dH+=H[e1];
	   
	   dS-=SI[c]+ST[e1];
	   S[e1]=Entropie[B(e1)][B(e2)][B(c)][B(e2-1)] + Entropie_Bulge(e2-1,c,e2,e1);
	   SI[c]=0;
	   ST[e1]=0;
	   dS+=S[e1];
   }
  
 	if(isole_gauche && t_boucle_interne>0){
	
		int prec = seq_chaine[e1][0];
	    int suiv = seq_chaine[e2][1];
	
        if(prec!=-1 && e1-prec <= t_boucle_interne+1 && suiv != l_sequence && suiv-e2 <= t_boucle_interne+1 && paires[prec][1]==suiv){
			
			dH-=H[prec];
			H[prec] = Enthalpie_Boucle_Interne[e1-prec-1][suiv-e2-1];
			dH+=H[prec];
	   
			dS-=S[prec];
			S[prec] = Entropie_Boucle_Interne[e1-prec-1][suiv-e2-1];
			dS+=S[prec];
		}
	}
	
	if(isole_droite && t_boucle_interne>0){
	
		int	prec = seq_chaine[e2][0];
		int suiv = seq_chaine[e1][1];
		
		if(e2-prec <= t_boucle_interne+1 && suiv-e1 <= t_boucle_interne+1 && paires[suiv][1]==prec){
			
			H[e1] = Enthalpie_Boucle_Interne[suiv-e1-1][e2-prec-1];
			dH+=H[e1];
			
			S[e1] = Entropie_Boucle_Interne[suiv-e1-1][e2-prec-1];
			dS+=S[e1];
			
		}
   
	}
	
	
   S_totale += dS;
   E_totale += dH;
   return dH-T*dS;

}   


///////////////////////////////////////////////////////////

int ARN_structure::Energie_Retirer_Michael(int e1, int e2){

    bool isole = true;
	
    int dH=-H[e1]-HI[e1]-HT[e1];
	int dS=-S[e1]-SI[e1]-ST[e1];
	H[e1]=0; HI[e1]=0; HT[e1]=0;
	S[e1]=0; SI[e1]=0; ST[e1]=0;
    
	if(e1!=0 && paires[e1-1][1]>=e2+1 && paires[e1-1][1]<=e2+1+t_bulge_max){
	    isole = false;
		dH-=H[e1-1];
		dS-=S[e1-1];
		H[e1-1]=0;
		S[e1-1]=0;
		HT[e1-1]=Enthalpie_Stack_Terminal( B(paires[e1-1][1]) , B(e1-1) , B_pour_T(paires[e1-1][1]-1) , B_pour_T(e1) );
		dH+=HT[e1-1];
		ST[e1-1]= Entropie_Stack_Terminal( B(paires[e1-1][1]) , B(e1-1) , B_pour_T(paires[e1-1][1]-1) , B_pour_T(e1) );
		dS+=ST[e1-1];
	}
	
	else if(e2!=l_sequence-1 &&  paires[e2+1][0]>=e1-1-t_bulge_max && paires[e2+1][0]<=e1-1 && paires[e2+1][0]>-1){
	    int c = paires[e2+1][0];
		isole = false;
		dH-=H[c];
		dS-=S[c];
		H[c]=0;
		S[c]=0;
		HT[c]=Enthalpie_Stack_Terminal( B(e2+1) , B(c) , B_pour_T(e2) , B_pour_T(c+1) );
		dH+=HT[c];
		ST[c]= Entropie_Stack_Terminal( B(e2+1) , B(c) , B_pour_T(e2) , B_pour_T(c+1) );
		dS+=ST[c];
	
	}
	
    if(paires[e1+1][1]>=e2-1-t_bulge_max && paires[e1+1][1]<=e2-1){
	    isole = false;
	    HI[e1+1]=Enthalpie_Stack_Terminal( B(e1+1) , B(paires[e1+1][1]) , B_pour_T(e1) , B_pour_T(paires[e1+1][1]+1) ) ;
		dH+=HI[e1+1];
		SI[e1+1]= Entropie_Stack_Terminal( B(e1+1) , B(paires[e1+1][1]) , B_pour_T(e1) , B_pour_T(paires[e1+1][1]+1) ) ;
		dS+=SI[e1+1];
	}
	
	else if(paires[e2-1][0]>=e1+1 && paires[e2-1][0]<=e1+1+t_bulge_max){
	    isole = false;
	    int c = paires[e2-1][0];
	    HI[c]=Enthalpie_Stack_Terminal( B(c) , B(e2-1) , B_pour_T(c-1) , B_pour_T(e2) );
		dH+=HI[c];
		SI[c]= Entropie_Stack_Terminal( B(c) , B(e2-1) , B_pour_T(c-1) , B_pour_T(e2) );
		dS+=SI[c];
	}
	
	if(t_boucle_interne>0){
	    int e1_prec = Precedent_Apparie(e1);
	    int e1_suiv = Suivant_Apparie(e1);
	    int e2_prec = Precedent_Apparie(e2);
	    int e2_suiv = Suivant_Apparie(e2);
		if(e1_prec!=-1 && e2_suiv!=l_sequence && (e1_suiv-e1_prec<=t_boucle_interne+1) && (e2_suiv-e2_prec<=t_boucle_interne) && (paires[e1_prec][1]==e2_suiv) && (paires[e1_suiv][1]==e2_prec) ){
		
		    dH-=H[e1_prec];
			H[e1_prec]=Enthalpie_Boucle_Interne[e1_suiv-e1_prec-1][e2_suiv-e2_prec-1];
			dH+=H[e1_prec];
		    
			dS-=S[e1_prec];
			S[e1_prec]=Entropie_Boucle_Interne[e1_suiv-e1_prec-1][e2_suiv-e2_prec-1];
			dS+=S[e1_prec];
		     
		}
	}
	
	S_totale += dS;
	E_totale += dH;
    return dH-T*dS;

}


