
//////////////////////////////////////////////////////////

void Initialise_Entropie_Stack_Terminal_Base_Modifiee_D(){
     for(int i = 0; i<5 ; i++){
	     for(int j = 0; j<5 ; j++){
		     for(int k = 0; k<5 ; k++){
		         Entropie_Stack_T[4][i][j][k]=0;
				 Entropie_Stack_T[i][4][j][k]=0;
				 Entropie_Stack_T[i][j][4][k]=0;
				 Entropie_Stack_T[i][j][k][4]=0;
			}
		}
	}
}


//////////////////////////////////////////////////////////

void Initialise_Entropie_Boucle_Interne(){
    Entropie_Boucle_Interne[0][0]=0;
	Entropie_Boucle_Interne[0][1]=0;
	Entropie_Boucle_Interne[0][2]=0;
	Entropie_Boucle_Interne[0][3]=0;
	Entropie_Boucle_Interne[1][0]=0;
	Entropie_Boucle_Interne[1][1]=0;
	Entropie_Boucle_Interne[1][2]=0;
	Entropie_Boucle_Interne[1][3]=0;
	Entropie_Boucle_Interne[2][0]=0;
	Entropie_Boucle_Interne[2][1]=0;
	Entropie_Boucle_Interne[2][2]=0;
	Entropie_Boucle_Interne[2][3]=0;
	Entropie_Boucle_Interne[3][0]=0;
	Entropie_Boucle_Interne[3][1]=0;
	Entropie_Boucle_Interne[3][2]=0;
	Entropie_Boucle_Interne[3][3]=0;

}

/////////////////////////////////////////////////////////

