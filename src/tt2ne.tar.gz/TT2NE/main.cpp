#include "TT2NE.h"
#include "Divers.cpp"
#include "Entropie.cpp"
#include "Structure.cpp"
#include "Energie.cpp"
#include "Paires.cpp"
#include "Fonctions_Principales.cpp"
#include "Helice2.cpp"
#include "Modele_Energie_Moi_3.cpp"
#include "Graphe_Final.cpp"

int main(int argc, char** argv){

    if(argc != 5) {
	    
		cout<<"Wrong number of input files"<<endl;
	    return 0;
	}

	Initialise_Parametres(argv[2], argv[3], argv[4]);
        
        string sz;
        fstream fzs(argv[argc-1], fstream::in);
        fzs >> sz;
        fzs.close();

        string ssz = "tt2ne_"+sz+"_message";
        fstream fssz(ssz.c_str(), fstream::out);


	
	Initialise_Modele_Energie_Moi_3();
	Initialise_Enthalpie_Bulge();
	
    srand((unsigned) time(NULL));
    ARN_structure* AA = new ARN_structure(argv[1]);
    
    if(AA->sequence.size() == 0 || AA->sequence[AA->sequence.size()-1]>=208){
        fssz << "Problem with the sequence" <<endl;
        fssz << "Invalid character \""<<char(AA->sequence[AA->sequence.size()-1] - 208 )<<"\" detected"<<endl;
        fssz.close();
        return 0;
    }
    if(AA->l_sequence > 225 ){
        fssz << "Sequence length = "<<AA->l_sequence<<endl<<"The sequence is too long : limited to 225 "<<endl;
        fssz.close();
        return 0;
    }

		
	cout<<endl<<"Sequence length of "<<argv[1]<<" : "<<AA->l_sequence<<endl<<endl;
	
	for(int i = 0;i<AA->l_sequence;i++){
		if(AA->sequence[i]==0) cout<<"A";
		else if(AA->sequence[i]==1) cout<<"C";
		else if(AA->sequence[i]==2) cout<<"G";
		else if(AA->sequence[i]==3) cout<<"U";
		else if(AA->sequence[i]%6==0) cout<<"a";
		else if(AA->sequence[i]%6==1) cout<<"c";
		else if(AA->sequence[i]%6==2) cout<<"g";
		else if(AA->sequence[i]%6==3) cout<<"u";
		else if(AA->sequence[i]==10) cout<<"D";
		if (i%100==99) cout<<endl;
		else if (i%10==9 ) cout<<' ';
		
	}
	cout<<endl<<endl;
    
	time_t seconds = time(NULL);
	
	AA->Construction_Des_Helices_Possibles_Fusion(argv[1]);
	if(n_helice_favorable==0){
			fssz<<"No favorable helipoint was found for this sequence ! "<<endl;
			fssz.close();
			return 0;
    }  
	
	cout<<"Select mode"<<endl;
	cout<<"    1->exhaustive search"<<endl;
	cout<<"    2->heuristic search "<<endl;
	cout<<" mode = ";
	int mode ;
	cin>>mode;

      

    if (mode==2){
	
	   	
		n_helice_max=n_helice_favorable;
			
		Graphe_Final GGG = Graphe_Final(AA->l_sequence);
			
		clock_t start_time;
		clock_t end_time;
		
		if( n_helice_max < 350) mode=1;
		else{
		    int seep = 100;
		    int H2L = 350;
	
		int seep2 = 175;
		int prof2 = 20;
		int n_am = 300;
			
		struct tms start_tms;
		struct tms end_tms;
		start_time = times( & start_tms);
		
		GGG.Gere_H2(H2L,seep2,prof2,n_am);
		GGG.Construit_H1_Optim(seep);	
			
		Top_G = liste(n_sous_optimal, 1000);
		Top_St = LT(n_sous_optimal);
						
		GGG.Prolonge_Amorces();
			
		end_time = times(& end_tms);

		printf("Runtime in seconds : %li\n", (end_tms.tms_utime - start_tms.tms_utime)/(sysconf(_SC_CLK_TCK))); 
		cout<<endl<<endl;
		int oo =0;
		string nom = string(argv[1]);
		liste::iterator iii = Top_G.begin();
		for(LT::iterator i = Top_St.begin() ; i!=Top_St.end() ; i++){
			ostringstream os;
			os << oo;
			string sortie("sortie");
			sortie=nom + "_" + sortie;
			string numero = os.str();
			cout<<"Structure "<<oo<<endl;
			GGG.Ecrit_Structure(*i,sortie,numero, AA, *iii);
			++oo; ++iii;
		}		
		fssz<<"Sequence length = "<<AA->l_sequence<<endl<<"No heuristic was used"<<endl;
		fssz.close();	
		}
	}

	if (mode==1){
	
	    n_helice_max=n_helice_favorable;
			
		Graphe_Final GGG = Graphe_Final(AA->l_sequence);
			
		clock_t start_time;
		clock_t end_time;
		
		int seep;
		int H2L;
			
		if(n_helice_max<300){
			seep = n_helice_max/2;
			H2L=-1;
		}
		else {
			seep = n_helice_max/3 + 100;
			H2L=-1;
		}
																									  							  			  	  
		int prof=15;
				
		struct tms start_tms;
		struct tms end_tms;
		start_time = times( & start_tms);
		
		GGG.Construit_H1_Optim(seep);		
		
		Top_G = liste(n_sous_optimal, 1000);
		Top_St = LT(n_sous_optimal);
		
		cout<<"///////////"<<n_baquetraque<<"/////////////"<<endl;
		time_t tt = time(NULL);
		
		for(int i = 0; i<prof ; i++){
			GGG.Prolonge_Max_Heur(i);
			cout<<"///////////"<<n_baquetraque<<"/////////////"<<endl;
		}
		
		end_time = times(& end_tms);

		printf("Runtime in seconds : %li\n", (end_tms.tms_utime - start_tms.tms_utime)/(sysconf(_SC_CLK_TCK))); 
		cout<<endl<<endl;
		int oo =0;
		string nom = string(argv[1]);
		liste::iterator iii = Top_G.begin();
		for(LT::iterator i = Top_St.begin() ; i!=Top_St.end() ; i++){
		    ostringstream os;
		    os << oo;
		    string sortie("out");
		    sortie="tt2ne_" + nom + "_" + sortie;
		    string numero = os.str();
		    cout<<"Structure "<<oo<<endl;
			GGG.Ecrit_Structure(*i,sortie,numero, AA, *iii);
		    ++oo; ++iii;
        }
		
		fssz<<"Sequence length = "<<AA->l_sequence<<endl<<"No heuristic was used"<<endl;
		fssz.close();	
	}
		
	
		
	if(mode!=1 && mode!=2) {
		cerr<<"Did not understand selected mode"<<endl;
		return 0;
	}
	    
	seconds = time(NULL) - seconds;
    
	delete AA;
	
	return 0;

}
