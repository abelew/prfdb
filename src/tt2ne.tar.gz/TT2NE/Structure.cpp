inline int ARN_structure::B_pour_T(int e1){
    return sequence[e1]%6;
};
inline int ARN_structure::B(int e1){
    return sequence[e1];
};

inline void ARN_structure::Ajouter_Seq_Chaine(int e1){
    int a = Precedent_Apparie(e1);
    int b = Suivant_Apparie(e1);
    if(a==-1 && b==l_sequence){
        seq_chaine[e1][0]=-1;
        seq_chaine[e1][1]=l_sequence;
        SEQ0 = e1;
        SEQ1 = e1;
    }
    else if(a==-1){
        seq_chaine[e1][0]=-1;
        seq_chaine[e1][1]=b;
        SEQ0 = e1;
        seq_chaine[b][0] = e1;
    }
    else if(b==l_sequence){
        seq_chaine[e1][1]=l_sequence;
        seq_chaine[e1][0]=a;
        SEQ1 = e1;
        seq_chaine[a][1]=e1;
    }
    else{
        seq_chaine[e1][0]=a;
        seq_chaine[e1][1]=b;
        seq_chaine[a][1]=e1;
        seq_chaine[b][0]=e1;
    }
};
inline void ARN_structure::Retirer_Seq_Chaine(int e1){
        if(SEQ0==SEQ1 && e1==SEQ0){
            seq_chaine[e1][0]=-1;
            seq_chaine[e1][1]=-1;
            SEQ0=-1;
            SEQ1=l_sequence;
        }
        else if(e1==SEQ0){
        seq_chaine[ seq_chaine[e1][1] ][0]=-1;
            SEQ0 = seq_chaine[e1][1];
            seq_chaine[e1][1]=-1;
        }
        else if(e1==SEQ1){
            seq_chaine[ seq_chaine[e1][0] ][1] = l_sequence;
            SEQ1=seq_chaine[e1][0];
            seq_chaine[e1][0] = -1;
        }
        else{
            seq_chaine[ seq_chaine[e1][0] ][1] = seq_chaine[e1][1];
            seq_chaine[ seq_chaine[e1][1] ][0] = seq_chaine[e1][0];
            seq_chaine[e1][1] = -1;
            seq_chaine[e1][0] = -1;
        }
    };

    inline bool ARN_structure::Appariable(int i, int j){
        return (B(i)+B(j)==3 || B(i)+B(j)==5);
    }
void ARN_structure::Une_Paire_De_Plus_Fusion_Iteratif(int e1, int e2, VH2& fus_h , tabd2& fus_e, tab2& fus_qual, tab& fus_i){
    if(!Appariable(e1,e2) || e2<=e1+t_sterique) return ;
    V_P A_Faire;
    A_Faire.push_back(Paire(e1,e2));
    tab n_bulge_courant;
    n_bulge_courant.push_back(0);
    tab n_interne_courant;
    n_interne_courant.push_back(0);
    tab e_min;
    e_min.push_back(seuil);
    V_P Hel;
    while(!A_Faire.empty()){
        int i = A_Faire.back().b_amont;
        int j = A_Faire.back().b_aval;
        int nb = n_bulge_courant.back();
        int ni = n_interne_courant.back();
        int e = e_min.back();
        A_Faire.pop_back();
        n_bulge_courant.pop_back();
        n_interne_courant.pop_back();
        e_min.pop_back();
        if(j<0){
            Retirer_Paire(-i,-j);
            Hel.pop_back();
        }
        else if( Appariable(i,j) && j>i+t_sterique && nb<=n_max_bulge && ni<=n_max_boucle_interne) {
            Ajouter_Paire(i,j);
            Hel.push_back(Paire(i,j));
            if(E_totale-T*S_totale <=e   && Hel.size()>2 ){
                n_helice ++;
                e = E_totale-T*S_totale;


                if(fus_e[i-e1][e2-j]<0){
                    fus_h[i-e1][e2-j]= Helice2(Hel , 0);
                    fus_qual[i-e1][e2-j]=nb+ni;
                    fus_i.push_back((i-e1)+l_sequence*(e2-j));
                    }
                else if( fus_e[i-e1][e2-j]<exp(- (double)(E_totale-T*(S_totale))*beta/precision ) ){
                    fus_h[i-e1][e2-j]= Helice2(Hel , 0);
                    fus_qual[i-e1][e2-j]=nb+ni;
                }


                    fus_e[i-e1][e2-j]+=exp(- (double)(E_totale-T*(S_totale))*beta/precision );
            }
            A_Faire.push_back(Paire(-i,-j));
            n_bulge_courant.push_back(-1);
            n_interne_courant.push_back(-1);
            e_min.push_back(e);
            if(Appariable(i+1,j-1)){
                A_Faire.push_back(Paire(i+1,j-1));
                n_bulge_courant.push_back(nb);
                n_interne_courant.push_back(ni);
                e_min.push_back(e);
            }
            else{
                for(int k = 1 ; k<=t_boucle_interne ; ++k){
                    for(int l = 1 ; l<=t_boucle_interne ; ++l){
                        A_Faire.push_back(Paire(i+1+k,j-1-l));
                        n_bulge_courant.push_back(nb);
                        n_interne_courant.push_back(ni+1);
                        e_min.push_back(e);
                }}}
            for(int k = 1 ; k<=t_bulge_max ; ++k) {
                A_Faire.push_back(Paire(i+1+k,j-1));
                n_bulge_courant.push_back(nb+1);
                n_interne_courant.push_back(ni);
                e_min.push_back(e);
                A_Faire.push_back(Paire(i+1,j-k-1));
                n_bulge_courant.push_back(nb+1);
                n_interne_courant.push_back(ni);
                e_min.push_back(e);
            }
        }}}

    int ARN_structure::Construction_Des_Helices_Possibles_Fusion(char* s){
       L_H L_parf = L_H();
        L_H L_imp = L_H();
        VH L_Verlan_parf;
        VH L_Verlan_imp;
        int n_total=0;
        int k,l,compt;
            VH2 fus_h;
        tabd2 fus_e;
        tab2 fus_qual;
        tab fus_i;
        fus_h.resize(40);
        fus_qual.resize(40);
        fus_e.resize(40);
        for(int i = 0; i<40 ; i++){
            fus_h[i].resize(40);
            fus_e[i] = tabd(40, -0.000001);
            fus_qual[i].resize(40);
        }
        time_t t_secondes = time(NULL);
        for(int i = 0; i<l_sequence ; i++){
            for(int j = l_sequence-1 ; j>i+t_sterique ; j--){
                if(Appariable(i,j) && j>i+t_sterique){
                    Une_Paire_De_Plus_Fusion_Iteratif(i,j,fus_h,fus_e,fus_qual,fus_i);
                    while(!fus_i.empty()){
                        int k = fus_i.back()%l_sequence;
                        int l = fus_i.back()/l_sequence;
                        fus_h[k][l].G = (int)(-log(fus_e[k][l])*precision/beta);
                        if(fus_qual[k][l]==0) L_parf.push_back(fus_h[k][l]);
                        else L_imp.push_back(fus_h[k][l]);
                        fus_e[k][l]=-0.000001;
                        fus_i.pop_back();
                    }
                }}}
        L_parf.sort();
        L_imp.sort();
        Elagage_Integriste(L_parf,L_imp, L_parf);
        Elagage_Integriste(L_imp,L_imp);
        L_parf.merge(L_imp);
        t_secondes = time(NULL);
        n_helice_favorable = L_parf.size();
        HELICE.resize(n_helice_favorable);
        L_H::iterator p = L_parf.begin();
        compt = 0;
        string ss(s);
        fstream fout(("Helices_"+ss).c_str() , fstream::out);
        for( int i = 0 ; i<n_helice_favorable ; i++){
            HELICE[i] =  *p;
            p++;
            fout<<"# "<<i<<endl<<(double)(HELICE[i].G)/precision<<"  "<<HELICE[i].LP.size()<<endl;
            for(V_P::iterator g = HELICE[i].LP.begin() ; g!= HELICE[i].LP.end() ; ++g){
                fout<<(*g).b_amont<<"  "<<(*g).b_aval<<endl;
            }
            fout<<endl;
        }
        cout<<endl<<"There are "<<n_helice_favorable<<" favorable helipoints (listed in Helices_"<<ss<<")"<<endl;
      
        fout.close();
        cout<<endl;
        return n_total;
    }


void Comparaison_de_Liste(L_H& L1, VH& L2){
    L_H::iterator deb = L1.begin();
    L_H::iterator fin = L1.end();
    VH::iterator debV = L2.begin();
    VH::iterator finV = L2.end();
    int compt= 0;
    while(deb!=fin && debV!=finV){
        if((*deb).G == (*debV).G && (*deb).LP.front()==(*debV).LP.back() && (*deb).LP.back()==(*debV).LP.front() ){
            ++deb;
            ++debV;
        }
        else if((*deb)<(*debV)) {
            ++compt;
            L1.erase(deb++);
        }
        else if((*deb)>(*debV)){
            ++debV;
    }}
    cout<<compt<<endl;
}
void ARN_structure::Elagage_Integriste(L_H& L_imp , L_H& L_parf){
    VH3 Range_L_Parf;
    Range_L_Parf.resize(l_sequence);
    for(int i = 0 ; i<l_sequence-t_sterique-1 ; i++){
        Range_L_Parf[i].resize(l_sequence);
    }
    L_H::iterator deb = L_parf.begin();
    L_H::iterator fin = L_parf.end();
    for(deb;deb!=fin;++deb){
        Range_L_Parf[(*deb).LP.front().b_amont][(*deb).LP.front().b_aval].push_back(*deb);
    }
    deb = L_imp.begin();
    fin = L_imp.end();
    while(deb!=fin){
        int e1 = (*deb).LP.front().b_amont;
        int e4 = (*deb).LP.front().b_aval;
        int e2 = (*deb).LP.back().b_amont;
        int e3 = (*deb).LP.back().b_aval;
        bool survit = true;
        for(int i = e1 ; i<e2 && survit ; ++i){
            for(int j = e4 ; j>e3 && survit; --j){
                if(!Range_L_Parf[i][j].empty() && Range_L_Parf[i][j].front().G < (*deb).G){
                    VH::iterator zob = Range_L_Parf[i][j].begin();
                    VH::iterator zobi = Range_L_Parf[i][j].end();
                    while(zob!=zobi && (*zob).G<(*deb).G){
                        if((*zob).LP.back().b_amont <=e2 && (*zob).LP.back().b_aval >=e3) {
                            survit=false;
                            break;
                        }
                        else ++zob;
                    }
        }}}
        if(survit) ++deb;
        else{
            L_imp.erase(deb++);
        }
    }
}
void ARN_structure::Elagage_Integriste(L_H& L_imp, L_H& L_imp2, L_H& L_parf){
        VH3 Range_L_Parf;
    Range_L_Parf.resize(l_sequence);
    for(int i = 0 ; i<l_sequence-t_sterique-1 ; i++){
        Range_L_Parf[i].resize(l_sequence);
    }
    L_H::iterator deb = L_parf.begin();
    L_H::iterator fin = L_parf.end();
    for(deb;deb!=fin;++deb){
        Range_L_Parf[(*deb).LP.front().b_amont][(*deb).LP.front().b_aval].push_back(*deb);
    }
    deb = L_imp.begin();
    fin = L_imp.end();
    while(deb!=fin){
        int e1 = (*deb).LP.front().b_amont;
        int e4 = (*deb).LP.front().b_aval;
        int e2 = (*deb).LP.back().b_amont;
        int e3 = (*deb).LP.back().b_aval;
        bool survit = true;
        for(int i = e1 ; i<e2 && survit ; ++i){
            for(int j = e4 ; j>e3 && survit; --j){
                if(!Range_L_Parf[i][j].empty() && Range_L_Parf[i][j].front().G < (*deb).G){
                    VH::iterator zob = Range_L_Parf[i][j].begin();
                    VH::iterator zobi = Range_L_Parf[i][j].end();
                    while(zob!=zobi && (*zob).G<(*deb).G){
                        if((*zob).LP.back().b_amont <=e2 && (*zob).LP.back().b_aval >=e3) {
                            survit=false;
                            break;
                        }
                        else ++zob;
                    }
                }
            }
        }
        if(survit) ++deb;
        else{
            L_imp.erase(deb++);
        }
    }
    deb = L_imp2.begin();
    fin = L_imp2.end();
    while(deb!=fin){
        int e1 = (*deb).LP.front().b_amont;
        int e4 = (*deb).LP.front().b_aval;
        int e2 = (*deb).LP.back().b_amont;
        int e3 = (*deb).LP.back().b_aval;
        bool survit = true;
        for(int i = e1 ; i<e2 && survit ; ++i){
            for(int j = e4 ; j>e3 && survit; --j){
                if(!Range_L_Parf[i][j].empty() && Range_L_Parf[i][j].front().G < (*deb).G){
                    VH::iterator zob = Range_L_Parf[i][j].begin();
                    VH::iterator zobi = Range_L_Parf[i][j].end();
                    while(zob!=zobi && (*zob).G<(*deb).G){
                        if((*zob).LP.back().b_amont <=e2 && (*zob).LP.back().b_aval >=e3) {
                            survit=false;
                            break;
                        }
                        else ++zob;
                    }
                }
            }
        }
        if(survit) ++deb;
        else{
            L_imp2.erase(deb++);
        }
    }
}
