#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <vector>
#include<iostream>
#include<time.h>
#include<fstream>
#include <list>
#include <string>
#include<sstream>


#include<sys/times.h>

using namespace std;
//using namespace math;

#define C_max 2
typedef list<int> liste;
typedef vector<int> tab;
typedef vector<tab> tab2;
typedef vector<tab2> tab3;
typedef vector<double> tabd;
typedef vector<tabd> tabd2;
typedef vector<bool> tabb;
static int n_baquetraque=0;
static int n_remplacements=0;
static int n_sous_optimal=3;
static int gmax = 3;
static int modele_energie;

static double precision = 1000.0;
static int T = 310 ;
static int T2 =310 ;
const int R= (int) (8.31451*0.2388459*0.001*precision) ;
static double beta = 1/(1.987*0.001*(double)T);
static int mu = (int) (0*precision) ;
const int Pi = (int) (3.141592*precision) ;
const int Deux_Pi = 2*Pi ;
static int Gmin = (int)( 1000.0 * precision);
static int G_min = (int) ( 1000.0*precision);
static int seuil = (int) ( -0.2*precision);
time_t t_attente = 300;

static int t_sterique = 4;
static int n_amorces =100 ;
static int t_bulge_max = 1;
static int n_max_bulge= 2;
static int t_boucle_interne = 1;
static int n_max_boucle_interne = 1;
static int Enthalpie[4][4][4][4];
static int Entropie[4][4][4][4];
static int Enthalpie_I[4][4];
static int Entropie_I[4][4];
static int Enthalpie_T[4][4];
static int Entropie_T[4][4];
static int Enthalpie_Stack_T[5][5][5][5];
static int Entropie_Stack_T[5][5][5][5];
static int Enthalpie_Boucle_Interne[3][3];
static int Entropie_Boucle_Interne[3][3];
static int Enthalpie_Bulge[5];

void Initialise_Modele_Energie_Moi_3();
void Initialise_Enthalpie_Moi_3();
void Initialise_Enthalpie_I_Moi_3();
void Initialise_Enthalpie_T_Moi_3();
void Initialise_Entropie_Moi_3();
void Initialise_Entropie_I_Moi_3();
void Initialise_Entropie_T_Moi_3();
void Initialise_Enthalpie_Stack_T_Moi_3();
void Initialise_Entropie_Stack_T_Moi_3();
void Initialise_Enthalpie_Bulge();
void Initialise_Enthalpie_Stack_Terminal_Base_Modifiee_D();  
void Initialise_Entropie_Stack_Terminal_Base_Modifiee_D();   
void Initialise_Enthalpie_Boucle_Interne();
void Initialise_Entropie_Boucle_Interne();
bool Initialise_Parametres(char* s1, char* s2, char* s3);
void wait(long sec);
void Compteur_Classe(int i , int max);
class TabOptConst {
    public:
	int* t;
	int i_t;
	TabOptConst():i_t(0){}
	TabOptConst(const int n){
	    i_t = 0;
		t = new int[n];
	}	
	~TabOptConst(){
	};	
	inline void push_back(int a){
		t[i_t++]=a;
	}
	inline void pop_back(){
	   --i_t; 
	}
	inline bool empty(){
	    return i_t==0;
	}
	inline int back(){
		return t[i_t-1];
	}	
	inline tab Vrai(){
		tab tt;
		for(int i = 0 ; i<i_t ; ++i) tt.push_back(t[i]);
	    return tt;
	}
};
static tab L_chemin;
class Paire{
    public:
    int b_amont;
    int b_aval;
    Paire();
    Paire( int a, int b, int c, int d, int e, int f);
    Paire ( int a, int b ):b_amont(a),b_aval(b){};
	Paire( const Paire& P):b_amont(P.b_amont),b_aval(P.b_aval){};	
    void Afficher_P();
    ~Paire();	
	const bool operator == (const Paire& P) const{
	    return ( (b_amont == P.b_amont) && (b_aval==P.b_aval) );
	}	
	const bool operator != (const Paire& P) const{
	    return ( (b_amont != P.b_amont) || (b_aval!=P.b_aval) );
	}
};
typedef list<Paire> L_P;
typedef vector<Paire> V_P;
class Helice2{
    public:	
	int G;
	V_P LP;
	Helice2():LP(V_P()),G(0){};
	Helice2(const V_P& ll, const int g):LP(ll),G(g){};
	Helice2(const Helice2& H):LP(H.LP),G(H.G){};
	virtual ~Helice2();	
	const bool operator < ( const Helice2& R) const{
		if( G != R.G) return (G<R.G);
		if(LP.front()!=R.LP.front()){
			if(LP.front().b_amont != R.LP.front().b_amont) return (LP.front().b_amont < R.LP.front().b_amont);
			return (LP.front().b_aval < R.LP.front().b_aval);
		}
		if(LP.back()!=R.LP.back()){
			if(LP.back().b_amont != R.LP.back().b_amont) return (LP.back().b_amont < R.LP.back().b_amont);
			return (LP.back().b_aval < R.LP.back().b_aval);
		}
		return false;		
	};	
	const bool operator > (const Helice2& R) const{	    
		if( G != R.G) return (G>R.G);
		if(LP.front()!=R.LP.front()){
			if(LP.front().b_amont != R.LP.front().b_amont) return (LP.front().b_amont > R.LP.front().b_amont);
			return (LP.front().b_aval > R.LP.front().b_aval);
		}
		if(LP.back()!=R.LP.back()){
			if(LP.back().b_amont != R.LP.back().b_amont) return (LP.back().b_amont > R.LP.back().b_amont);
			return (LP.back().b_aval > R.LP.back().b_aval);
		}
		return false;	
	};
	void Afficher();	
	int Energie_Libre();	
	bool Meme(Helice2 R);	
	bool Helices_Se_Chevauchent(const Helice2& R);	
	int Compatible(Helice2 R);
	bool Est_Dans(Paire P);
	bool Test_ABAB_Noeud_Foireux(const Helice2& R);
};
typedef list<Helice2> L_H;
typedef vector<Helice2> VH;
typedef vector<VH> VH2;
typedef vector<VH2> VH3;
typedef list<tab> LT;
static LT Top_St;
static liste Top_G;
static LT Top2_St;
static liste Top2_G;
liste** Top_St_Amorces;
int* Top_G_Amorces;
static VH HELICE;
int Resout_Conflits_Deux(int helmax1, int helmax2, const tab2& H_Exclusions);
int Resout_Conflits_Trois(int helmax1, int helmax2, int helmax3, const tab2& H_Exclusions);
static int n_helice = 0;
static int n_helice_favorable = 0;
static int n_helice_max = 0;
bool Verif_Doublon(liste* ref, liste* comp);
void Construit_H_Exclusions(tab2& H_Exclusions);

class ARN_structure{
public :
int l_sequence;
tab sequence ; 
tab2 paires ;
tab2 seq_chaine; 
tab H;
tab HI;
tab HT;
tab S;
tab SI;
tab ST;
tab Partition; 
tab2 Liste_Partition;
tab Cardinal_Partition;
tab Energie_Partition;
int t_Paires         ;
int SEQ0;
int SEQ1;
int genre;
int S_totale;
int E_totale;
~ARN_structure();
ARN_structure(const char* fichier_sequence);
void Afficher();
void Afficher_Paires();
char Base(int i);
bool Initialise_Appariements(const char* s);
inline bool Conditions_steriques(int e1, int e2);
inline int Precedent_Apparie(int e1);
inline int Suivant_Apparie(int e1);
inline bool Apparie(int i);
inline int amont(int i);
inline int aval(int i);
void Actualiser_Paires_Retrait( int e1, int e2 );
void Actualiser_Paires_Ajout( int e1, int e2);
inline bool Est_Amont(int e1);
inline int B(int e1);
inline int B_pour_T(int e1);
inline void Ajouter_Seq_Chaine(int e1);
inline void Retirer_Seq_Chaine(int e1);
int Construction_Des_Helices_Possibles_Fusion(char* s);
bool Appariable(int i, int j);
inline int H_Bulge(int e1,int e2, int e3, int e4);
inline int Entropie_Bulge(int e1,int e2, int e3, int e4);
int Energie_Ajouter_Michael(int e1, int e2);
int Energie_Retirer_Michael(int e1, int e2);
inline int Enthalpie_Stack_Terminal(int e1, int e2, int e3, int e4);
inline int Entropie_Stack_Terminal(int e1, int e2, int e3, int e4);
int Ajouter_Paire(int e1, int e2);
int Retirer_Paire( int e1, int e2 );
int Ajouter_Helice_Optimise(int i);
int Enlever_Helice_Optimise(int i);
int Remplacer_Paire(int e1, int e2, int e3, int e4);
void Une_Paire_De_Plus_Fusion_Iteratif(int e1, int e2, VH2& fus_h, tabd2& fus_e, tab2& fus_qual, tab& fus_i);
void Elagage_Integriste(L_H& L_imp , L_H& L_parf);
void Elagage_Integriste(L_H& L_imp, L_H& L_imp2, L_H& L_parf);
int Rajoute_Helice2(int n);
int Enleve_Helice2(int n);
void Ecrit_Structure_Annotee(const char* s, int energie);
void Ecrit_Structure_Bpseq(const char* s);
void Ecrit_Structure_CT(const char* s, int energie);
};


class Graphe_Final{
public : 		
int l_seq;
int genre;
int E_totale;
int H2_limite;		
tab2 CC1;
tab3 CC2;
tab seq_chaine_suivant;
TabOptConst Mem_seq_chaine;
tab Mem_genre;
tab L_che;
tab H1;
tab H2;		
Graphe_Final(int l_sequence);		
void Prepare_Les_Partitions();
void Prepare_CC1();
void Prepare_CC2(const tab2& H_Exclusions);
void Initialise_Seq_Chaine_Suivant();
void Ajouter_Seq_Chaine_Suivant(int e1, int e2);
inline void Retirer_Seq_Chaine_Suivant(int e1, int e2);
bool Partition_Ajout(int e1);
bool Partition_Retrait(int e1);
inline int Remplacer_Paire(int e1, int e2, int e3, int e4);
void Prolonge_Max_Heur(const int n, const int profondeur, const tab& Tab_Heuristique);
void Prolonge_Max_Heur_Verif_Doublon(const int n);
void Prolonge_Max_Heur(const int n);
void Construit_H1_Optim(const int m);
void Prolonge_Max_Heur_Muet(const int n);
void Inserer_Dans_Top(LT& top_st, liste& top_g);
void Inserer_Dans_Top_Verif_Doublon(LT& top_st, liste& top_g);
void Ecrit_Structure(tab& L, string& nom, const string& a, ARN_structure* AA, int energie);
bool Delta_Genre_Repense_ABCABC_Ajout(const int e1, const int e2);
inline void Retirer_Genre();
void Prolonge_Max_Heur2(const int n);
void Prolonge_Max_Heur2_Muet(const int n);
void Construit_H2_Optim(const int m);
void Construit_Amorces(const int m);
void Prolonge_Amorces();
void Gere_H2(const int H2l, const int seep2, const int prof2, const int n_am);
};

