 
 
inline void Compteur_Classe(int i, int max){
    if(max<10) printf("\b\b\b%d/%d",i,max);
	else if(max<100) printf("\b\b\b\b\b%2d/%d",i,max);
	else if(max<1000) printf("\b\b\b\b\b\b\b%3d/%d",i,max);
	else if(max<10000) printf("\b\b\b\b\b\b\b\b\b%4d/%d",i,max);
	else if(max<100000) printf("\b\b\b\b\b\b\b\b\b\b\b%5d/%d",i,max);
	else if(max<1000000) printf("\b\b\b\b\b\b\b\b\b\b\b\b\b%6d/%d",i,max);
	
	else cout<<i<<"  ";
	fflush(stdout);
}
 
 
/////////////////////////////////////////// 

 void wait(long sec) {

     long start, courante;
     time(&start) ;
     time(&courante) ;

     while((courante-start)<sec){
         time(&courante) ;
     }
}


////////////////////////////////////////////


 ARN_structure::~ARN_structure(){
 };


////////////////////////////////////////////////////


	ARN_structure::ARN_structure(const char* fichier_sequence){
		fstream ficIn(fichier_sequence , fstream::in);
		if(!ficIn.is_open()) cerr<<"sequence file not open !"<<endl;
		char ch;
		
		while(ficIn.good()){
			ficIn.get(ch);
			if(ch!=' ' && ch!='\n' && ch!='\t'){
				if(ch=='D') {sequence.push_back(10);}
				else if(ch=='A'|| ch=='a') {sequence.push_back(0);}
				else if(ch=='C' || ch=='c') {sequence.push_back(1);}
				else if(ch=='G' || ch=='g'|| ch=='W' || ch=='Q') {sequence.push_back(2);}
				else if(ch=='u' || ch=='U' || ch=='t'|| ch=='T' || ch=='Y' || ch=='I') {sequence.push_back(3);}
				else {
					sequence.push_back(208+ch);
					return;
				}
     		}
		}
		ficIn.close();
		const int l = sequence.size(); 
		l_sequence=l;
        sequence.resize(l);
        paires.resize(l);
        seq_chaine.resize(l);
        H.resize(l);
		HI.resize(l);
		HT.resize(l);
		S.resize(l);
		SI.resize(l);
		ST.resize(l);
		
		t_Paires = 0     ;
        SEQ0 = -1;
        SEQ1 = l;
        genre=0;
        E_totale = 0;
        S_totale=0;

        for( int i = 0 ; i < l ; ++i){

            paires[i].resize(2);
            paires[i][0]=-1;
            paires[i][1]=-1;
            
            seq_chaine[i].resize(l);
            seq_chaine[i][0] = -1;
            seq_chaine[i][1] = -1;

            H[i]=0;
			HI[i]=0;
			HT[i]=0;
			S[i]=0;
			SI[i]=0;
			ST[i]=0;
			
        }
		
	};


////////////////////////////////////////////////////////////////

    void ARN_structure::Ecrit_Structure_Bpseq(const char* s){
		
		FILE* f =fopen(s,"w");
		
		for(int i=0 ; i<l_sequence; ++i){
			
			int zob=0;
			
			if(Apparie(i)){
				if(Est_Amont(i)) zob = aval(i)+1;
				else zob = amont(i)+1;
			}

			fprintf(f, "%3d  %c  %3d \n", i+1, Base(i), zob); 
			
		}

	}

////////////////////////////////////////////////////////////////

    void ARN_structure::Ecrit_Structure_CT(const char* s, int energie){
		
		FILE* f =fopen(s,"w");
		fprintf(f, "ENERGY = %f \n", (double)(energie)/precision );
		for(int i=0 ; i<l_sequence; ++i){
			
			int zob=0;
			
			if(Apparie(i)){
				if(Est_Amont(i)) zob = aval(i)+1;
				else zob = amont(i)+1;
			}

			fprintf(f, "%3d  %c  %3d  %3d  %3d  %3d \n", i+1, Base(i), i, i+2, zob, i+1); 
			 
		}

	}

////////////////////////////////////////////////////////////////

	void ARN_structure::Ecrit_Structure_Annotee(const char* s, int energie){
		
		fstream f(s,fstream::out);
		char symbole[10] = {'(', ')' , '[', ']', '{','}','!','?','+','-'};
		tab2 l_symb = tab2(5,tab());
		vector<char> annote = vector<char>(l_sequence,'.');
		
		for(int i = 0 ; i<l_sequence ; i++){
			if(Apparie(i)){
			    if(Est_Amont(i)){
					int j = 0;
					bool fait = false;
					while(!fait && j<5){
						if((l_symb[j]).empty() || aval(i)<l_symb[j].back()){
							fait = true;
							annote[i]=symbole[2*j];
							annote[aval(i)]=symbole[2*j+1];
							l_symb[j].push_back(aval(i));
						}
						else{
							++j;
						}
					}
				}
				else{
				
					int j = 0;
					bool fait = false;
					while(!fait && j<5){
						if(!l_symb[j].empty() && l_symb[j].back()==i){
							l_symb[j].pop_back();
							fait=true;
						}
						++j;
					}
				}
			}
		}
		
		cout<<"F = "<<(double)(energie)/precision<<endl;
		cout<<"genus = "<<genre<<endl;
		f<<"F = "<<(double)(energie)/precision<<endl<<endl;;
		f<<"genus = "<<genre<<endl<<endl<<endl;
		
		for(int i = 0 ; i<l_sequence ; i++){
			cout<<Base(i);
			f<<Base(i);
		}
		cout<<endl;
		f<<endl;
		for(int i = 0 ; i<l_sequence ; i++){
			cout<<annote[i];
			f<<annote[i];
		}
		cout<<endl<<endl;
		f.close();
	}
	
///////////////////////////////////////////////////////////////////////

bool Initialise_Parametres(char* s1, char* s2, char* s3){
	    fstream fmu(s1,fstream::in);
		fstream fgmax(s2,fstream::in);
		fstream fnm(s3,fstream::in);
		char mot[50];
		char k;
		if( !(fmu.is_open() && fgmax.is_open() && fnm.is_open() ) ){
		    cout<<"Problem opening paremeter files"<<endl;
			return false;
		}
	    
		double li;
		
		T = 310;
		beta = 1/(1.987*0.001*(double)T);
		t_bulge_max = 1 ;
		n_max_bulge = 2 ;
		t_boucle_interne = 1 ;
		n_max_boucle_interne = 1 ;
		
		seuil = (int)(-0.2 * precision) ;
		modele_energie = 3 ;
		t_sterique = 4;
		t_attente = 180 ;
		
		fmu>>li ; mu=(int)(li*precision);
		fgmax>>gmax;
		fnm>>n_sous_optimal;
		
		return true;
	}
