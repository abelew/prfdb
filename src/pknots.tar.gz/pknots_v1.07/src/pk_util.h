/* from pk_utl.c
 */
extern void pk_fatal(char *format, ...);
extern void IntizeSequence(char *seq, int len, int *iseq);
