extern void    Parameters2_Zkn(struct rnapar_2 **ret_rnapar);
extern int   **ParamIntSCFG(struct rnapar_2 *rnapar);
extern int     IntizeScale (double val);

