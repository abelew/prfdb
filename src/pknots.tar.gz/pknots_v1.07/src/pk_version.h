/* version.h
 * 
 */

#define RELEASE   "1.07"    
#define RELEASEDATE "2011"  

