/* version.h
 * 
 */

#define RELEASE   "1.05"    
#define RELEASEDATE "Thu Aug 11 11:25:58 CDT 2005"  

