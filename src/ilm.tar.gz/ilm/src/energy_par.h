/* 
   prototypes for energy_par.c
*/

#include "energy_const.h"

extern int stack37[NBPAIRS+1][NBPAIRS+1];

extern int mismatchI37[NBPAIRS+1][5][5];  /* interior loop mismatches */
extern int mismatchH37[NBPAIRS+1][5][5];  /* same for hairpins */

extern int dangle5_37[NBPAIRS+1][5];      /* 5' dangle exterior of pair */
extern int dangle3_37[NBPAIRS+1][5];      /* 3' dangle */
