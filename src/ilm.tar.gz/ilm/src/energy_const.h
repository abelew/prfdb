/*

   energy constants, formerly defined in
             energy_par.h

   customized for use with RNAedit by
   S.Kopp, IMB-Jena, Germany, Mar 1996
   
*/

#ifndef _ENERGY_CONST_H
#define _ENERGY_CONST_H 1

#define INF 0
#define NBPAIRS 7

#endif
