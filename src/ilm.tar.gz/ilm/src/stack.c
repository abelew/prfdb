/* stack.c
 * An implementation of stack for integers. 
 * J. Ruan
 */ 

#include <stdlib.h>
#include "stack.h"

stack* createStack() {
  stack* s;
  s = malloc(sizeof(stack));
  if (s == NULL) return NULL;
  s->memblock = 100;
  s->nalloc = s->memblock;
  s->data = malloc(sizeof(int)* s->nalloc);
  if (s->data == NULL) { 
     free(s); 
     return NULL; 
  }
  s->n = 0;
  return s;
}

int pushStack(stack *s, int n) {
  int *ptr;
  if (s->n == s->nalloc) {
    s->nalloc += s->memblock;
    ptr = realloc(s->data, sizeof(int) * s->nalloc);
    if (ptr == NULL) 
      return 0; 
    else 
      s->data = ptr;
  }
  s->data[s->n] = n;
  s->n++;
  return 1;
}

int popStack(stack *s, int *n) {
  if (s->n == 0) {
    *n = 0; 
    return 0;
  }
  s->n--;
  *n = s->data[s->n];
  return 1;
}

void freeStack(stack *s) {
  free(s->data);
  free(s);
}

int stackIsEmpty(stack *s) {
  if (s->n == 0) 
    return 1;
  else 
    return 0;
}
