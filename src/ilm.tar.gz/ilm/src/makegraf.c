#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "grafio.h"

#define BINARY 0
#define TEXT   1

int main(int argc, char *argv[])
{
  FILE *infile;
  struct Graph main_graph, add_graph;
  char graph_name[80];
  char buffer[81];
  float scalar;
  int offset = 0;
  char file_flag = 0;
  int size_check;
  char *curr_arg;
  int output_mode = BINARY;
  int i, j;

  i = 0;
  for (;;) {
    if (++i > argc - 1) {
      fprintf(stderr, "\nUsage: makegraf [-option] datafile\n");
      fprintf(stderr, "  Option:\n");
      fprintf(stderr, "    -t: Write output in text format\n");
      fprintf(stderr, "          (Default = Binary format)\n\n");
      exit(EXIT_FAILURE);
    }

    curr_arg = argv[i];
    if (curr_arg[0] != '-')
      break;

    switch (curr_arg[1])
      {
      case 't':
	output_mode = TEXT;
	break;
      default :
        fprintf(stderr, "\nUnknown switch: %s\n\n", curr_arg);
        exit(EXIT_FAILURE);
      }
  }

  if ((infile = fopen(argv[i], "rt")) == NULL) {
    fprintf(stderr, "\nCannot open %s\n\n", argv[i]);
    exit(EXIT_FAILURE);
  }

  for (;;) {
    fgets(buffer, 81, infile);
    if (feof(infile))
      break;

    if (sscanf(buffer, "%s %f", graph_name, &scalar) != 2) {
      fprintf(stderr, "\nCannot parse line: %s\n\n", buffer);
      exit(EXIT_FAILURE);
    }

    if (strcmp(graph_name, "offset") == 0)
      offset = scalar;
    else {
      if (!ReadGraf(graph_name, &add_graph))
	exit(EXIT_FAILURE);

      if (file_flag == 0) {
	MakeGraf(&main_graph, add_graph.n_vert);
	main_graph.n_edge = CountMaxEdges(&main_graph);
	size_check = main_graph.n_vert;
	file_flag = 1;
      }
      else
	if (add_graph.n_vert != size_check) {
	  fprintf(stderr, "\nDifferent graph size in file %s\n\n", graph_name);
	  exit(EXIT_FAILURE);
	}

      for (i = 2; i <= main_graph.n_vert; i++)
	for (j = 1; j < i; j++)
	  Edge(main_graph, i, j) += (int) ( ((float) Edge(add_graph, i, j))
					   *scalar );

      FreeGraf(&add_graph);
    }
  }

  fclose(infile);

  if (file_flag) {
    for (i = 2; i <= main_graph.n_vert; i++)
      for (j = 1; j < i; j++)
	Edge(main_graph,i, j) += offset;

    if (output_mode == BINARY)
      WriteBinGraf(stdout, &main_graph);
    else
      WriteTextGraf(stdout, &main_graph, ALL_EDGES);
  }
  else
    fprintf(stderr, "\nError: No graph files specified in data file\n\n");

  return EXIT_SUCCESS;
}
