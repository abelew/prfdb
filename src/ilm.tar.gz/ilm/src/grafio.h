#include <stdio.h>

#ifndef GRAFIOH
#define GRAFIOH 1

#define FORMAT_NOT_RECOGNIZED -1

#define ALL_EDGES     0
#define POSITIVE_ONLY 1

#define Min(x, y) ((x) < (y)) ? (x) : (y)
#define Max(x, y) ((x) > (y)) ? (x) : (y)
#define Edge(g, x, y) ((g).edges)[Max((x), (y))][Min((x), (y))]

struct Graph {
  int **edges;
  int n_vert;
  int n_edge;
};

int  MakeGraf(struct Graph *g, int nvert);
void FreeGraf(struct Graph *g);

int CountPositiveEdges(struct Graph *g);
int CountMaxEdges(struct Graph *g);

int WriteBinGraf(FILE *outfile, struct Graph *g);
int ReadBinGraf(FILE *infile, struct Graph *g);
int WriteTextGraf(FILE *outfile, struct Graph *g, char edge_set);
int ReadTextGraf(FILE *infile, struct Graph *g);

int ReadGraf(char *filename, struct Graph *g);

#endif
