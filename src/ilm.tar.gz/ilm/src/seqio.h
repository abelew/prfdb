#include <stdio.h>

#ifndef SEQIOH
#define SEQIOH 1

struct Sequence {
  FILE *source_file;
  int hdr_len;
  char *hdr;
  int seq_len;
  char *seq;
};

int OpenSeq(struct Sequence *seq, char *filename);
int GetSeq(struct Sequence *seq);
int WriteSeq(struct Sequence *seq, FILE *outfile);
int CountSeq(struct Sequence *seq);
void CloseSeq(struct Sequence *seq);
void RewindSeq(struct Sequence *seq);

#endif
