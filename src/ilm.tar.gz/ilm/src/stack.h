/* stack.h
 * An implementation of stacks for integers
 * J. Ruan
 */
#ifndef STACK_H_
#define STACK_H_

typedef struct stackStru {
  int *data;		/* the data array*/
  int  n;		/* current (topmost) elem in data  */
  int  nalloc;		/* # of elems allocated right now  */
  int  memblock;	/* memory allocation block size, # of elems */
} stack;

stack*    createStack(void);
int       pushStack(stack *s, int n);
int       popStack(stack *s,  int *n);
void      freeStack(stack *s);
int       stackIsEmpty(stack *ns);

#endif
