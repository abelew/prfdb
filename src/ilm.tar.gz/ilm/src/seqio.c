#include <stdio.h>
#include <stdlib.h>
#include "seqio.h"

int OpenSeq(struct Sequence *seq, char *filename)
{
  int p1, p2, p3;

  if ((seq->source_file = fopen(filename, "rt")) == NULL) {
    fprintf(stderr, "\nCannot open %s\n\n", filename);
    return 0;
  }

  fscanf(seq->source_file, "%*[^:]%n:%n%*s%n", &p1, &p2, &p3);
  seq->hdr_len = p1;
  seq->seq_len = p3 - p2;

  if ((seq->hdr_len < 1) || (seq->seq_len < 1)) {
    fprintf(stderr, "\nCannot read sequences in file %s\n\n", filename);
    return 0;
  }

  seq->hdr = (char*)malloc((seq->hdr_len + 2)*sizeof(char));
  seq->seq = (char*)malloc((seq->seq_len + 2)*sizeof(char));

  if ((seq->hdr == NULL) || (seq->seq == NULL)) {
    fprintf(stderr, "Could not allocate memory for sequence buffer\n");
    return 0;
  }

  seq->hdr[0] = seq->seq[0] = ' ';

  rewind(seq->source_file);
  return 1;
}

int GetSeq(struct Sequence *seq)
{
  if (fscanf(seq->source_file, "%[^:]:%s%*c", &(seq->hdr[1]), &(seq->seq[1]))
      != 2) {
    if (feof(seq->source_file))
      return 0;
    else
      fprintf(stderr, "\nRead error in sequence file\n\n");
  }

  return 1;
}

int WriteSeq(struct Sequence *seq, FILE *outfile)
{
  if (fprintf(outfile, "%*s:%*s\n", seq->hdr_len, seq->hdr,
	      seq->seq_len, seq->seq) < 0) {
    fprintf(stderr, "\nWrite error in sequence output\n\n");
    return 0;
  }

  return 1;
}

int CountSeq(struct Sequence *seq)
{
  int i = 0;

  rewind(seq->source_file);
  while (GetSeq(seq))
    i++;
  rewind(seq->source_file);

  return i;
}

void CloseSeq(struct Sequence *seq)
{
  if (seq->hdr != NULL)
    free(seq->hdr);
  if (seq->seq != NULL)
    free(seq->seq);
  if (seq->source_file != NULL)
    fclose(seq->source_file);
}

void RewindSeq(struct Sequence *seq)
{
  rewind(seq->source_file);
}
