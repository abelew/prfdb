#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include "seqio.h"
#include "grafio.h"
#include "energy_par.h"

/* Default parameters */
#define DEFAULT_MIN_LOOP 3
#define DEFAULT_MIN_HLX  2

/* Default scores */
#define DEFAULT_BAD_PAIR 200 
#define DEFAULT_PAIRED_GAP 500 
#define CG 80
#define AU 50 
#define GU 30

/* Flags */
#define GAP    1
#define NO_GAP 0
#define ON     1
#define OFF    0

/* Utility variables */
struct Graph  Graf;
int *Translate;
char *code_seq;

/* Parameters */
int    MinLoop = DEFAULT_MIN_LOOP;
int    MinHlx  = DEFAULT_MIN_HLX;
int    TxtMode = OFF;
int    NO_CLOSING_GU = 0; 


/* Scores */
int   BadPair   = DEFAULT_BAD_PAIR;
int   PairedGap = DEFAULT_PAIRED_GAP;

char Encode(char base)
{
  char ret;

  switch (toupper(base))
  {
    case 'A': ret = 1; break;
    case 'C': ret = 2; break;
    case 'G': ret = 3; break;
    case 'T':
    case 'U': ret = 4; break;
    default : ret = 0;
  }

  return ret;
}

int unitScore[7] = {0, CG, CG, GU, GU, AU, AU};

int pairType[5][5] = { /*   A  C  G  U   */
			{0, 0, 0, 0, 0}, 
	/* A */		{0, 0, 0, 0, 5},  /* AU */
	/* C */		{0, 0, 0, 1, 0},  /* CG */
	/* G */		{0, 0, 2, 0, 3},  /* GC, GU */
	/* U */		{0, 6, 0, 4, 0}   /* UA, UG */
};

void DoHelix(int start5, int stop5, int start3, int stop3)
{
  int hlx_len = stop5 - start5 - 1;
  int totalScore;
  int pairScore;
  int previousScore;
  int i, j;
  int type;
  int nextType;

  if (NO_CLOSING_GU) {
     if (pairType[code_seq[start5+1]][code_seq[start3-1]] == 3 || 
              pairType[code_seq[start5+1]][code_seq[start3-1]] == 4) {
         Edge(Graf, Translate[start5+1], Translate[start3-1]) -= BadPair;
         start5++;
         start3--;
         hlx_len--; 
     } 
     if (pairType[code_seq[stop5-1]][code_seq[stop3+1]] == 3 || 
              pairType[code_seq[stop5-1]][code_seq[stop3+1]] == 4) {
         Edge(Graf, Translate[stop5-1], Translate[stop3+1]) -= BadPair;
         stop5--;
         stop3++;
         hlx_len--; 
     } 
  }

  if (hlx_len < MinHlx) {
     totalScore = -BadPair;
  } else {
     totalScore = 0;
     previousScore = 0;
     type = pairType[code_seq[start5+1]][code_seq[start3-1]];
     for(i = start5 + 1, j = start3 - 1; i < stop5-1; i++, j--) {
        nextType = pairType[code_seq[i+1]][code_seq[j-1]];
        pairScore = -stack37[type][nextType];
        totalScore += pairScore;
        Edge(Graf, Translate[i], Translate[j]) += unitScore[type];
        type = nextType; 
        previousScore = pairScore;
     }

     if (stop3 - stop5 < 10) {
        pairScore = -mismatchH37[type][code_seq[stop5]][code_seq[stop3]];
     } else {
        pairScore = -mismatchI37[type][code_seq[stop5]][code_seq[stop3]];
     }

     Edge(Graf, Translate[i], Translate[j]) += unitScore[type];
     totalScore += pairScore;
     totalScore = (int)(totalScore/sqrt(hlx_len));
  }

  for(i = start5 + 1, j = start3 - 1; i < stop5; i++, j--) {
     Edge(Graf, Translate[i], Translate[j]) += totalScore;
  }
  
  if (stop3 - stop5 > MinLoop)
    Edge(Graf, Translate[stop5], Translate[stop3]) -= BadPair;
}

int main(int argc, char *argv[])
{
  struct Sequence seq;
  int code_len;
  char *gap_list;
  char *curr_arg;
  char c;
  int i, j, k;
  int oldj, oldk;
  int nSeq = 0;

  i = 0;
  for (;;) {
    if (++i > argc - 1) {
      fprintf(stderr, "\nUsage: xhlxplot [-options] filename\n");
      fprintf(stderr, "  Options:\n");
      fprintf(stderr, "    -b B: Set bad pair penalty to B\n");
      fprintf(stderr, "            (Default = %d)\n", BadPair);
      fprintf(stderr, "    -h H: Set minimum helix length to H\n");
      fprintf(stderr, "            (Default = %d)\n", MinHlx);
      fprintf(stderr, "    -l L: Set minimum loop length to L\n");
      fprintf(stderr, "            (Default = %d)\n", MinLoop);
      fprintf(stderr, "    -x X: Set paired gap penalty to X\n");
      fprintf(stderr, "            (Default = %d)\n\n", PairedGap);
      fprintf(stderr, "    -t  : Write output in text format\n");
      fprintf(stderr, "            (Default = Binary format)\n");
      fprintf(stderr, "    -c  : No Closing GU\n");
      fprintf(stderr, "            (Default = allows closing GU)\n");
      exit(EXIT_FAILURE);
    }

    curr_arg = argv[i];
    if (curr_arg[0] != '-')
      break;

    switch (curr_arg[1])
      {
      case 'b':
	curr_arg = argv[++i];
	if (!isdigit(curr_arg[0])) {
	  fprintf(stderr, "\nError: Bad pair penalty not specified ");
	  fprintf(stderr, "after -b\n\n");
	  exit(EXIT_FAILURE);
	}
	BadPair = atoi(curr_arg);
	break;
      case 'h':
	curr_arg = argv[++i];
	if (!isdigit(curr_arg[0])) {
	  fprintf(stderr, "\nError: Minimum helix length not specified after");
	  fprintf(stderr, " -h\n\n");
	  exit(EXIT_FAILURE);
	}
	MinHlx = atoi(curr_arg);
	break;
      case 'l':
	curr_arg = argv[++i];
	if (!isdigit(curr_arg[0])) {
	  fprintf(stderr, "\nError: Minimum loop length not specified after");
	  fprintf(stderr, " -l\n\n");
	  exit(EXIT_FAILURE);
	}
	MinLoop = atoi(curr_arg);
	break;
      case 't':
	TxtMode = ON;
	break;
      case 'c':
        NO_CLOSING_GU = 1;
        break;
      case 'x':
	curr_arg = argv[++i];
	if (!isdigit(curr_arg[0])) {
	  fprintf(stderr, "\nError: Paired gap penalty not specified after");
	  fprintf(stderr, " -x\n\n");
	  exit(EXIT_FAILURE);
	}
	PairedGap = atoi(curr_arg);
	break;
      default :
	fprintf(stderr, "\nUnknown switch: %s\n\n", curr_arg);
	exit(EXIT_FAILURE);
      }
  }

  if (!OpenSeq(&seq, argv[i]))
    exit(EXIT_FAILURE);

  if (!MakeGraf(&Graf, seq.seq_len))
    exit(EXIT_FAILURE);
  Graf.n_edge = CountMaxEdges(&Graf);

  code_seq  = (char *) malloc((seq.seq_len + 2)*sizeof(char));
  Translate = (int *)  malloc((seq.seq_len + 2)*sizeof(int));
  gap_list  = (char *) malloc((seq.seq_len + 2)*sizeof(char));
  if ((code_seq == NULL) || (Translate == NULL) || (gap_list == NULL)) {
    fprintf(stderr, "\nCannot allocate memory\n\n");
    exit(EXIT_FAILURE);
  }

  for (;;) {
    if (!GetSeq(&seq))
      break;

    nSeq++;
    for (i = 1, code_len = 0; i <= seq.seq_len; i++) {
      c = Encode(seq.seq[i]);
      if (c == 0)
        gap_list[i] = GAP;
      else {
        code_seq[++code_len] = c;
        Translate[code_len] = i;
        gap_list[i] = NO_GAP;
      }
    }

    for (i = MinLoop + 2*MinHlx; i < code_len; i++) {
      for (j = i, k = 1, oldj = j + 1, oldk = 0;
	   j - k > MinLoop; j--, k++)
        if (!pairType[code_seq[j]][code_seq[k]]) {
          DoHelix(oldk, k, oldj, j);
          oldj = j;
          oldk = k;
        }
      DoHelix(oldk, k, oldj, j);
    }

    for (i = 1; i < code_len - MinLoop - 2*(MinHlx - 1); i++) {
      for (j = code_len, k = i, oldj = j + 1, oldk = k - 1;
	   j - k > MinLoop; j--, k++)
        if (!pairType[code_seq[j]][code_seq[k]]) {
          DoHelix(oldk, k, oldj, j);
          oldj = j;
          oldk = k;
        }
      DoHelix(oldk, k, oldj, j);
    }

    for (i = 1; i <= seq.seq_len; i++)
      if (gap_list[i] == GAP)
        for (j = 1; j <= seq.seq_len; j++)
          if (gap_list[j] == NO_GAP)
            Edge(Graf, i, j) -= PairedGap;
  }

  for(i = 1; i <= seq.seq_len; i++) {
     for(j = i + MinLoop; j <= seq.seq_len; j++) {
         Edge(Graf, i, j) = Edge(Graf, i, j) / (nSeq);
     }
  }

  if (TxtMode == OFF)
    WriteBinGraf(stdout, &Graf);
  else
    WriteTextGraf(stdout, &Graf, ALL_EDGES);

  CloseSeq(&seq);

  return (EXIT_SUCCESS);
}
