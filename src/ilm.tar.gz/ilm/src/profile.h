#ifndef PROFILE_H_
#define PROFILE_H_

#define DEFAULT_MIN_LOOP_LEN 3
#define DEFAULT_MIN_VLOOP_LEN 2
#define DEFAULT_MIN_HLX_LEN 3
#define DEFAULT_HLX_PER_ITER 1
#define DEFAULT_ITER_BEF_STOP 0

int min_loop_len = DEFAULT_MIN_LOOP_LEN;
int min_vloop_len = DEFAULT_MIN_VLOOP_LEN;
int min_hlx_len = DEFAULT_MIN_HLX_LEN;
int hlx_per_iter = DEFAULT_HLX_PER_ITER;
int iter_bef_stop = DEFAULT_ITER_BEF_STOP;

#endif
