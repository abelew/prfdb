#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include "grafio.h"

int MakeGraf(struct Graph *g, int nvert)
{
  int size;
  int i;

  g->n_vert = nvert;
  size = CountMaxEdges(g);

  if ((g->edges = (int **) malloc((nvert + 1)*sizeof(int *))) == NULL) {
    fprintf(stderr, "\nCannot allocate memory\n\n");
    return 0;
  }

  if ( ( (g->edges)[2] = (int *) calloc(size + 1, sizeof(int)) ) == NULL) {
    fprintf(stderr, "\nCannot allocate memory\n\n");
    return 0;
  }

  for (i = 3; i <= nvert; i++)
    (g->edges)[i] = &((g->edges)[i - 1][i - 2]);

  return 1;
}


void FreeGraf(struct Graph *g)
{
  free(g->edges[2]);
  free(g->edges);
}


int CountPositiveEdges(struct Graph *g)
{
  int i, j, count = 0;

  for (i = 2; i <= g->n_vert; i++)
    for (j = 1; j < i; j++)
      if (Edge(*g, i, j) > 0)
	count++;

  return count;
}


int CountMaxEdges(struct Graph *g)
{
  int x;

  x = g->n_vert;
  return (x*(x - 1))/2;
}


int WriteBinGraf(FILE *outfile, struct Graph *g)
{
  int i;
  int write_ok;
  int *row;
  unsigned char magic[4];
  int firstline[3];

  /* Stupid non-ANSI C compilers!!! */
  magic[0] = 0x07;
  magic[1] = 0x08;
  magic[2] = 0x64;
  magic[3] = 0x96;

  firstline[0] = sizeof(int);
  firstline[1] = g->n_vert;
  firstline[2] = g->n_edge;

  /* Note that I'm using a side effect of the && operator to */
  /* stop writing if an I/O error occurs. Shame on me. :^(   */

  write_ok = (fwrite(magic, sizeof(char), 4, outfile) == 4);
  write_ok = write_ok && (fwrite(firstline, sizeof(int), 3, outfile) == 3);

  for (i = g->n_vert; i > 1; i--) {
    row = (g->edges)[i];
    write_ok = write_ok &&
                 (fwrite(&(row[1]), sizeof(int), i - 1, outfile) == i - 1);
  }

  if (!write_ok) {
    fprintf(stderr, "\nWrite error in binary output file\n\n");
    return 0;
  }

  return 1;
}


int ReadBinGraf(FILE *infile, struct Graph *g)
{
  int i;
  int read_ok;
  int *row;
  unsigned char magic[4];
  int firstline[3];

  magic[0] = magic[1] = magic[2] = magic[3] = 0;

  read_ok = fread(magic, sizeof(char), 4, infile) == 4;
  if ((magic[0] != (unsigned char) 0x07) ||
      (magic[1] != (unsigned char) 0x08) ||
      (magic[2] != (unsigned char) 0x64) ||
      (magic[3] != (unsigned char) 0x96))
    return FORMAT_NOT_RECOGNIZED;

  firstline[0] = 0;

  /* More operator abuse */

  read_ok = read_ok && (fread(firstline, sizeof(int), 3, infile) == 3);
  if (firstline[0] != sizeof(int)) {
    fprintf(stderr, "\nBinary input file is incompatible with this ");
    fprintf(stderr, "architecture\n\n");
    return 0;
  }

  if (!MakeGraf(g, firstline[1]))
    return 0;
  g->n_edge = firstline[2];

  for (i = g->n_vert; i > 1; i--) {
    row = (g->edges)[i];
    read_ok = read_ok &&
                (fread(&(row[1]), sizeof(int), i - 1, infile) == i - 1);
  }

  if (!read_ok) {
    fprintf(stderr, "\nRead error in binary input file\n\n");
    return 0;
  }

  return 1;
}


int WriteTextGraf(FILE *outfile, struct Graph *g, char edge_set)
{
  int degree;
  int i, j;
  int write_ok;

  write_ok = fprintf(outfile, "%d %d U\n", g->n_vert, g->n_edge) >= 0;

  for (i = 1; i <= g->n_vert; i++) {
    if (edge_set == ALL_EDGES)
      degree = g->n_vert - 1;
    else {
      degree = 0;
      for (j = 1; j <= g->n_vert; j++)
	if ((i != j) && (Edge(*g, i, j) > 0))
	  degree++;
    }
    write_ok = write_ok &&
                 (fprintf(outfile, "%d %d 0 0\n", degree, i) >= 0);

    for (j = 1; j <= g->n_vert; j++)
      if ( (i != j) && ( (Edge(*g, i, j) > 0) || (edge_set == ALL_EDGES) ) )
	write_ok = write_ok &&
	            (fprintf(outfile, "%d %d\n", j, Edge(*g, i, j)) >= 0);
  }

  if (!write_ok) {
    fprintf(stderr, "\nWrite error in text output file\n\n");
    return 0;
  }

  return 1;
}


int ReadTextGraf(FILE *infile, struct Graph *g)
{
  char yoo = ' ';
  int nvert, nedge;
  int i, j;
  int degree, mate, weight;
  int read_ok;
  char buffer[80];

  read_ok = fgets(buffer, 80, infile) != NULL;
  i = sscanf(buffer, "%d %d %c", &nvert, &nedge, &yoo);

  if ((i != 3) || (toupper(yoo) != 'U'))
    return FORMAT_NOT_RECOGNIZED;

  if (!MakeGraf(g, nvert))
    return 0;
  g->n_edge = nedge;

  for (i = 1; i <= nvert; i++) {
    read_ok = read_ok && (fgets(buffer, 80, infile) != NULL);
    read_ok = read_ok && (sscanf(buffer, "%d", &degree) == 1);

    for (j = 0; j < degree; j++) {
      read_ok = read_ok && (fgets(buffer, 80, infile) != NULL);
      read_ok = read_ok && (sscanf(buffer, "%d %d", &mate, &weight) == 2);
      if (i > mate)
	Edge(*g, i, mate) = weight;
    }
  }

  if (!read_ok) {
    fprintf(stderr, "\nRead error in text input file\n\n");
    return 0;
  }

  return 1;
}


int ReadGraf(char *filename, struct Graph *g)
{
  FILE *infile;
  int flag;

  if ((infile = fopen(filename, "rb")) == NULL) {
    fprintf(stderr, "\nCannot open file %s\n\n", filename);
    return 0;
  }

  if ( !(flag = ReadBinGraf(infile, g)) )
    return 0;

  if (flag == FORMAT_NOT_RECOGNIZED) {
    fclose(infile);

    if ((infile = fopen(filename, "rt")) == NULL) {
      fprintf(stderr, "\nCannot open file %s\n\n", filename);
      return 0;
    }

    if ( !(flag = ReadTextGraf(infile, g)) )
      return 0;

    if (flag == FORMAT_NOT_RECOGNIZED) {
      fprintf(stderr, "\nFile %s does not appear to contain a graph\n\n",
	      filename);
      fclose(infile);
      return 0;
    }
  }

  fclose(infile);
  return 1;
}
