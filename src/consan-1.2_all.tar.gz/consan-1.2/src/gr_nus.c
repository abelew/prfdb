/* gr_nus.c
 * Sun Feb 16 19:13:22 CST 2003 
 *
 * Implementations of the grammar specific functions 
 * for the basic Sankoff (NUS based)
 *
 * These implementations assume a diaitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "consan.h"
#include "ngmr.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"
#include "dps.h"

/*****************************************/
/* Unconstrained Sankoff:: CYK algorithm */
/*****************************************/

/* Function: cykInitNUS
 * Date:     Sun Feb 16 19:14:43 CST 2003 [St Louis]
 *
 * Purpose:  Initialize CYK fill matrix for NUS grammar
 * Assumption: Fill matrix already allocated 
 *
 * Args:     
 * 	seqs	sequences info
 * 	model	parameter and grammar info
 * 	mx	fill matrix
 *
 * Returns:  -- void -- 
 */
   void
cykInitNUS(SEQUENCE *seqX, SEQUENCE *seqY, INTMOD *model, int grammar, int *****mx)
{
   int j, dx;
   int l, dy;
   int Xlen, Ylen;

   Xlen = seqX->len;
   Ylen = seqY->len;

   /* As written, the initialize steps only look at positions where
    * either dx = 0 or dy = 0 or both. Consequently, while written
    * as an N^4 algorithm.  It executes as N^3 + N^2.  */
   for (dx = 0; dx <= Xlen; dx++) { 
      for (j = (dx > 0? dx-1: dx); j < Xlen; j++) {
	 for (dy = 0; (dx > 0? dy < 1: dy <= Ylen); dy++) {  
	    for (l = (dy > 0? dy-1: dy); l < Ylen; l++) {
	       mx[dpS][j][dx][l][dy] = -BIGINT; 
	       mx[dpLm][j][dx][l][dy] = -BIGINT; 
	       mx[dpLx][j][dx][l][dy] = -BIGINT; 
	       mx[dpLy][j][dx][l][dy] = -BIGINT; 
	       if (grammar != NUS) {
		  mx[dpP][j][dx][l][dy] = -BIGINT;
		  mx[dpN][j][dx][l][dy] = -BIGINT;
	       }
	       /* Transitions to an end are only legal if 
		* we don't have anymore sequence to emit 
		*/
	       if ((dx == 0) && (dy == 0)) {
		  mx[dpRy][j][dx][l][dy] = model->transitions[TRYE];
		  mx[dpRx][j][dx][l][dy] = model->transitions[TRXE];
		  mx[dpRm][j][dx][l][dy] = model->transitions[TRME];
	       } else {
		  mx[dpRx][j][dx][l][dy] = -BIGINT; 
		  mx[dpRy][j][dx][l][dy] = -BIGINT; 
		  mx[dpRm][j][dx][l][dy] = -BIGINT; 
	       }
	    }
	 }
      }
   }
}

/* Function: cykFillNUS
 * Date:     Sun Feb 16 19:15:06 CST 2003 [St Louis]
 *
 * Purpose:  Fills CYK matrix for NUS grammar
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 * 	seqs	sequences info
 * 	model	parameter and grammar info
 * 	mx	fill matrix
 *
 * Returns:  void 
 */
   void
cykFillNUS(SEQUENCE *seqX, SEQUENCE *seqY, INTMOD *model, int grammar, int *****mx)
{
   int i, j, dx, a;	/* Sequence x indicies */
   int k, l, dy, b;	/* Sequence y indicies */
   int max, bifmax, cursc;      
   int Sap, Lm, Lx, Ly, Rm, Rx, Ry;
   int Xlen, Ylen, stackvalue;
   int debug = FALSE;

   Xlen = seqX->len;
   Ylen = seqY->len;

   if (debug) { printf("X len %d Ylen %d\n", Xlen, Ylen); }

   /* Recursion */
   for (dx = 1; dx <= Xlen; dx++) {
      if (debug) { printf("increment dx %d\n", dx); }
      for (j = dx-1; j < Xlen; j++) { 
	 if (debug) { printf("increment j %d\n", j); }
	 i = j - dx + 1; 
	 for (dy = 1; dy <= Ylen; dy++) {
	    if (debug) { printf("increment dy %d\n", dy); }
	    for (l = dy-1; l < Ylen; l++) { 
	       k = l - dy + 1; 

	       /* (-y)Ly */
	       Ly = mx[dpLy][j][dx][l][dy-1] + model->emissions[eSS((int)seqY->dseq[k])];

	       /* (x-)Lx */
	       Lx = mx[dpLx][j][dx-1][l][dy] + model->emissions[eSS((int)seqX->dseq[i])];

	       /* (xy)Lm */
	       Lm = mx[dpLm][j][dx-1][l][dy-1] 
		  + model->emissions[eAL(seqX->dseq[i],seqY->dseq[k])];

	       /* Rx(x-) */
	       if (j == 0) Rx = mx[dpRx][0][dx-1][l][dy] 
		  	+ model->emissions[eSS((int)seqX->dseq[j])];
	       else Rx = mx[dpRx][j-1][dx-1][l][dy] 
		  	+ model->emissions[eSS((int)seqX->dseq[j])];

	       /* Ry(-y) */
	       if (l == 0) Ry = mx[dpRy][j][dx][0][dy-1] 
		  	+ model->emissions[eSS((int)seqY->dseq[l])];
	       else Ry = mx[dpRy][j][dx][l-1][dy-1] 
		  	+ model->emissions[eSS((int)seqY->dseq[l])];

	       /* Rm(xy) */
	       if ((j == 0) && (l == 0)) Rm = mx[dpRm][0][dx-1][0][dy-1] 
		  + model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])];
	       else if (j == 0) Rm = mx[dpRm][0][dx-1][l-1][dy-1] 
		  + model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])];
	       else if (l == 0) Rm = mx[dpRm][j-1][dx-1][0][dy-1] 
		  + model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])];
	       else Rm = mx[dpRm][j-1][dx-1][l-1][dy-1] 
		  + model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])];

	       /* (xy)S/P(x'y') */
	       if ((l > 0) && (j > 0) && (dx > 1) && (dy > 1)) {
		  if (grammar == NUS) {
		     Sap = mx[dpS][j-1][dx-2][l-1][dy-2];
		  } else {
		     Sap = mx[dpP][j-1][dx-2][l-1][dy-2];
		  }
		  Sap += model->emissions[ePR(idx(seqX->dseq[i],seqX->dseq[j]),idx(seqY->dseq[k],seqY->dseq[l]))]; 
	       } else { Sap = -BIGINT; }
	       /* S -> (xy)S(x'y') | (xy)Lm | (x-)Lx | (-y)Ly | Rm(xy) | Rx(x-) | Ry(-y) | LmS */
	       max = -BIGINT;
	       cursc = Sap + model->transitions[TSS];
	       if (cursc > max) max = cursc;
	       cursc = Lm + model->transitions[TSLM];
	       if (cursc > max) max = cursc;
	       cursc = Lx + model->transitions[TSLX];
	       if (cursc > max) max = cursc;
	       cursc = Ly + model->transitions[TSLY];
	       if (cursc > max) max = cursc;
	       cursc = Rm + model->transitions[TSRM];
	       if (cursc > max) max = cursc;
	       cursc = Rx + model->transitions[TSRX];
	       if (cursc > max) max = cursc;
	       cursc = Ry + model->transitions[TSRY];
	       if (cursc > max) max = cursc;
	       /* S -> LmS 
		* Note: S can "disappear" in one or the other
		* (but not both) of the sequences as it can be
		* consumed completely by Rx or Ry. */
	       bifmax = -BIGINT;
	       for (a = i; a <= j; a++) {
		  for (b = k; b <= l; b++) {
		     if (!(a == j) && (b == l)) {
			cursc = mx[dpLm][a][dist(i,a)][b][dist(k,b)] 
			   + mx[dpS][j][dist(a+1,j)][l][dist(b+1,j)]
			   + model->transitions[TSB];
			if (cursc > bifmax) bifmax = cursc;
		     }
		  }
	       }
	       if (bifmax > max) max = bifmax;
	       bifmax -= model->transitions[TSB];
	       /* S -> (xy)S(x'y') | (xy)Lm | (x-)Lx | (-y)Ly | Rm(xy) | Rx(x-) | Ry(-y) | LmS */
	       mx[dpS][j][dx][l][dy] = max;
	       if (debug) { printf("Finished dpS\n"); fflush(stdout); }

	       if (grammar != NUS) {
		  /* N -> (xy)Lm | (x-)Lx | (-y)Ly | 
		   * 	  Rm(xy) | Rx(x-) | Ry(-y) | LmS */
		  max = -BIGINT;
		  cursc = Lm + model->transitions[TNLM];
		  if (cursc > max) max = cursc;
		  cursc = Lx + model->transitions[TNLX];
		  if (cursc > max) max = cursc;
		  cursc = Ly + model->transitions[TNLY];
		  if (cursc > max) max = cursc;
		  cursc = Rm + model->transitions[TNRM];
		  if (cursc > max) max = cursc;
		  cursc = Rx + model->transitions[TNRX];
		  if (cursc > max) max = cursc;
		  cursc = Ry + model->transitions[TNRY];
		  if (cursc > max) max = cursc;
		  /* N -> LmS */
		  bifmax += model->transitions[TNB];
		  if (bifmax > max) max = bifmax;
		  /* N -> (xy)Lm | (x-)Lx | (-y)Ly | 
		   *      Rm(xy) | Rx(x-) | Ry(-y) | LmS */
		  mx[dpN][j][dx][l][dy] = max;
		  if (debug) { printf("Finished dpN\n"); fflush(stdout); }

		  /* P -> (xy)P(x'y') | (xy)N(x'y') */
		  max = -BIGINT;
		  /* Can't stack at edges */
		  if ((i == 0) || (k == 0) || (j == Xlen-1) || (l == Ylen-1))
		     stackvalue = -BIGINT;
		  else
		     stackvalue = model->emissions[
			ePRN(seqX->dseq[i],seqX->dseq[j],\
			   seqY->dseq[k],seqY->dseq[l])];

		  if ((l > 0) && (j > 0) && (dx > 1) && (dy > 1))
		     cursc = mx[dpP][j-1][dx-2][l-1][dy-2] + model->transitions[TPP]
			+ stackvalue;
		  else cursc = -BIGINT;
		  if (cursc > max) max = cursc;

		  if (grammar == YRN) {
		     /* (xy)N(x'y') */
		     if ((l > 0) && (j > 0) && (dx > 1) && (dy > 1))
			cursc = mx[dpN][j-1][dx-2][l-1][dy-2] + model->transitions[TPN]
			   + stackvalue;
		     else cursc = -BIGINT;
		  } else {
		     /* N */
		     cursc = mx[dpN][j][dx][l][dy] + model->transitions[TPN];
		  }
		  if (cursc > max) max = cursc;
		  /* P -> (xy)P(x'y') | (xy)N(x'y') */
		  mx[dpP][j][dx][l][dy] = max;
		  if (debug) { printf("Finished dpP\n"); fflush(stdout); }
	       }

	       /* Lm -> (xy)S(x'y') | (xy)Lm | (x-)Lx | (-y)Ly */
	       max = -BIGINT;
	       cursc = Sap + model->transitions[TLMS];
	       if (cursc > max) max = cursc;
	       cursc = Lm + model->transitions[TLMM];
	       if (cursc > max) max = cursc;
	       cursc = Lx + model->transitions[TLMX];
	       if (cursc > max) max = cursc;
	       cursc = Ly + model->transitions[TLMY];
	       if (cursc > max) max = cursc;
	       /* Lm -> (xy)S(x'y') | (xy)Lm | (x-)Lx | (-y)Ly */
	       mx[dpLm][j][dx][l][dy] = max;
	       if (debug) { printf("Finished dpLm\n"); fflush(stdout); }

	       /* Lx -> (xy)S(x'y') | (xy)Lm | (x-)Lx */ 
	       max = -BIGINT;
	       cursc = Sap + model->transitions[TLXS];
	       if (cursc > max) max = cursc;
	       cursc = Lm + model->transitions[TLXM];
	       if (cursc > max) max = cursc;
	       cursc = Lx + model->transitions[TLXX];
	       if (cursc > max) max = cursc;
	       /* Lx -> (xy)S(x'y') | (xy)Lm | (x-)Lx */
	       mx[dpLx][j][dx][l][dy] = max;
	       if (debug) { printf("Finished dpLx\n"); fflush(stdout); }

	       /* Ly -> (xy)S(x'y') | (xy)Lm | (-y)Ly */
	       max = -BIGINT; 
	       cursc = Sap + model->transitions[TLYS];
	       if (cursc > max) max = cursc;
	       cursc = Lm + model->transitions[TLYM];
	       if (cursc > max) max = cursc;
	       cursc = Ly + model->transitions[TLYY];
	       if (cursc > max) max = cursc;
	       /* Ly -> (xy)S(x'y') | (xy)Lm | (-y)Ly */
	       mx[dpLy][j][dx][l][dy] = max;
	       if (debug) { printf("Finished dpLy\n"); fflush(stdout); }

	       /* Rm -> Rx(x-) | Ry(-y) | Rm(xy) */
	       max = -BIGINT; 
	       cursc = Rm + model->transitions[TRMM];
	       if (cursc > max) max = cursc;
	       cursc = Rx + model->transitions[TRMX];
	       if (cursc > max) max = cursc;
	       cursc = Ry + model->transitions[TRMY];
	       if (cursc > max) max = cursc;
	       /* Rm -> Rm(xy) | Rx(x-) | Ry(-y) | end */
	       mx[dpRm][j][dx][l][dy] = max;
	       if (debug) { printf("Finished dpRm\n"); fflush(stdout); }

	       /* Rx -> Rm(xy) | Rx(x-) | end */
	       max = -BIGINT; 
	       cursc = Rm + model->transitions[TRXM];
	       if (cursc > max) max = cursc;
	       cursc = Rx + model->transitions[TRXX];
	       if (cursc > max) max = cursc;
	       /* Rx -> Rm(xy) | Rx(x-) | end */
	       mx[dpRx][j][dx][l][dy] = max;
	       if (debug) { printf("Finished dpRx\n"); fflush(stdout); }

	       /* Ry -> Rm(xy) | Ry(-y) | end */
	       max = -BIGINT; 
	       cursc = Rm + model->transitions[TRYM];
	       if (cursc > max) max = cursc;
	       cursc = Ry + model->transitions[TRYY];
	       if (cursc > max) max = cursc;
	       /* Ry -> Rm(xy) | Ry(-y) | end */
	       mx[dpRy][j][dx][l][dy] = max;
	       if (debug) { printf("Finished dpRy\n"); fflush(stdout); }
	    }
	 }
	 if (debug) printYFoldMx(stdout, mx, seqX, seqY, dpRx, j, dx, NUS);
	 if (debug) printYFoldMx(stdout, mx, seqX, seqY, dpLy, j, dx, NUS);
      }
   }
   if (debug) printf("Finished Fill\n");
}

/* Function: cykTraceNUS
 * Date:     Sun Feb 16 19:16:04 CST 2003 [St Louis]
 *
 * Purpose:  Build traceback tree for scoring NUSsinov 
 * Assumption: Fill matrix already allocated, initialized, and filled
 *
 * Args:
 * 	seqs	sequences info
 * 	model	parameter and grammar info
 * 	mx	fill matrix
 *
 * Returns: traceback tree
 */
   struct trace_s *
cykTraceNUS(SEQUENCE *seqX, SEQUENCE *seqY, INTMOD *model, int grammar, int *****mx)
{
   struct trace_s *parsetree;     /* Head of parse tree */
   struct trace_s *curr;          /* Current node in parse tree */
   struct tracestack_s *stack;    /* Stack for doing traceback */
   int i, j, dx, a;	/* Sequence x indicies */
   int k, l, dy, b;	/* Sequence y indicies */
   int mtx;
   int debug = FALSE;
   int Xlen, Ylen;

   Xlen = seqX->len;
   Ylen = seqY->len;

   /* Initialization of Traceback stuff */
   parsetree = InitTrace();
   stack = InitTracestack();

   /* Push initialization elements onto stack */
   PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (Xlen-1), 0, (Ylen-1), NTRANS));

   /* Repeat until stack is empty */
   while ((curr = PopTracestack(stack))) {
      /* Set indicies from item in stack */
      mtx = curr->nonterminal; 
      i = curr->emitLx; j = curr->emitRx; 
      k = curr->emitLy; l = curr->emitRy; 
      dx = j - i + 1; dy = l - k + 1;

      if (debug) {
	 printf("mtx %s: (i %d, j %d; dx %d) (k %d, l %d, dy %d)\n",
	       dpNAME[Gtype[grammar]][mtx], i, j, dx, k, l, dy); fflush(stdout); 
      }

      switch (mtx) {
	 case dpS: 
	    if ((i > j) && (k > l)) {
	       printf("\nSHIT: Bad transition from S\n");
	       PushTracestack(stack, AttachTrace(curr, dpRm, i, j, k, l, NTRANS));
	       /* We have to check for the case where S reduces to to
		* a single stranded reaion. */
	    } else if (i > j) { /* Only single stranded in Y left */
	       /* (mx[dpRy][j][dx][l-1][dy-1] + model->emissions[eSS((int)seqY->dseq[l])] 
		  + model->transitions[TSRY] == mx[dpS][j][dx][l][dy]) */
	       curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1; 
	       curr->transition = TSRY;
	       PushTracestack(stack, AttachTrace(curr, dpRy, i, j, k, l-1, NTRANS));
	    } else if (k > l) {	/* Only single stranded in X left */
	       /* (mx[dpRx][j-1][dx-1][l][dy] + model->emissions[eSS((int)seqX->dseq[j])] 
		  + model->transitions[TSRX] == mx[dpS][j][dx][l][dy]) */ 
	       curr->emitLx = -1; curr->emitLy = -1; curr->emitRy = -1;
	       curr->transition = TSRX;
	       PushTracestack(stack, AttachTrace(curr, dpRx, i, j-1, k, l, NTRANS));
	    } else if (mx[dpRm][j-1][dx-1][l-1][dy-1] 
		  + model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])] 
		  + model->transitions[TSRM] == mx[dpS][j][dx][l][dy]) {
	       curr->emitLx = -1; curr->emitLy = -1; curr->transition = TSRM;
	       PushTracestack(stack, AttachTrace(curr, dpRm, i, j-1, k, l-1, NTRANS));
	    } else if (mx[dpRx][j-1][dx-1][l][dy] + model->emissions[eSS((int)seqX->dseq[j])] 
		  + model->transitions[TSRX] == mx[dpS][j][dx][l][dy]) {
	       curr->emitLx = -1; curr->emitLy = -1; curr->emitRy = -1;
	       curr->transition = TSRX;
	       PushTracestack(stack, AttachTrace(curr, dpRx, i, j-1, k, l, NTRANS));
	    } else if (mx[dpRy][j][dx][l-1][dy-1] + model->emissions[eSS((int)seqY->dseq[l])] 
		  + model->transitions[TSRY] == mx[dpS][j][dx][l][dy]) {
	       curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1; 
	       curr->transition = TSRY;
	       PushTracestack(stack, AttachTrace(curr, dpRy, i, j, k, l-1, NTRANS));
	    } else if (mx[dpLm][j][dx-1][l][dy-1] + model->transitions[TSLM]
		  + model->emissions[eAL(seqX->dseq[i],seqY->dseq[k])] == mx[dpS][j][dx][l][dy]) {
	       curr->emitRx = -1; curr->emitRy = -1; curr->transition = TSLM;
	       PushTracestack(stack, AttachTrace(curr, dpLm, i+1, j, k+1, l, NTRANS));
	    } else if (mx[dpLx][j][dx-1][l][dy] + model->transitions[TSLX]
		  + model->emissions[eSS((int)seqX->dseq[i])] == mx[dpS][j][dx][l][dy]) {
	       curr->emitRx = -1; curr->emitLy = -1; curr->emitRy = -1;
	       curr->transition = TSLX;
	       PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	    } else if (mx[dpLy][j][dx][l][dy-1] + model->transitions[TSLY]
		  + model->emissions[eSS((int)seqY->dseq[k])] == mx[dpS][j][dx][l][dy]) {
	       curr->transition = TSLY;
	       curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	       PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));

	       /* Depending on the grammar, check the correct TSS matrix */
	    } else if ((grammar == NUS) && 
		  (mx[dpS][j-1][dx-2][l-1][dy-2] + model->transitions[TSS] 
		   + model->emissions[ePR(idx(seqX->dseq[i],seqX->dseq[j]),idx(seqY->dseq[k],seqY->dseq[l]))] 
		   == mx[dpS][j][dx][l][dy])) {
	       curr->transition = TSS;
	       PushTracestack(stack, AttachTrace(curr, dpS, i+1, j-1, k+1, l-1, NTRANS));
	    } else if ((grammar != NUS) && 
		  (mx[dpP][j-1][dx-2][l-1][dy-2] + model->transitions[TSP]
		   + model->emissions[ePR(idx(seqX->dseq[i],seqX->dseq[j]),idx(seqY->dseq[k],seqY->dseq[l]))]
		   == mx[dpS][j][dx][l][dy])) {
	       curr->transition = TSP;
	       PushTracestack(stack, AttachTrace(curr, dpP, i+1, j-1, k+1, l-1, NTRANS));

	       /* We want to do this state last so we minimize the number of
		* times we're doing this internal loop */
	    } else {
	       for (a = i; a <= j; a++) {
		  for (b = k; b <= l; b++) {
		     if (!((a == j) && (b == l))) {
			if (mx[dpLm][a][dist(i,a)][b][dist(k,b)] 
			      + mx[dpS][j][dist(a+1,j)][l][dist(b+1,j)] 
			      + model->transitions[TSB]
			      == mx[dpS][j][dx][l][dy]) {
			   curr->emitLx = -1; curr->emitRx = -1; 
			   curr->emitLy = -1; curr->emitRy = -1;
			   curr->transition = TSB;
			   PushTracestack(stack, AttachTrace(curr, dpS, a+1, j, b+1, l, NTRANS));
			   PushTracestack(stack, AttachTrace(curr, dpLm, i, a, k, b, NTRANS));
			   b = l+1; a = j+1; 	/* Short circuit */
			}
		     }
		  }
	       }
	    }
	    break;

	 case dpP:
	    if ((i > j) || (k > l)) {
	       printf("\nSHIT: Bad transition from N\n");
	       PushTracestack(stack, AttachTrace(curr, dpRm, i, j, k, l, NTRANS));
	       	/* Must check for case of i == j || k == l as will 
		 * seg fault on this test */
	    } else if ((i < j) && (k < l) && 
	       (mx[dpP][j-1][dx-2][l-1][dy-2] + model->transitions[TPP]
		  + model->emissions[ePRN(seqX->dseq[i],seqX->dseq[j],\
		     seqY->dseq[k],seqY->dseq[l])]
		  == mx[dpP][j][dx][l][dy])) {
	       curr->transition = TPP;
	       PushTracestack(stack, AttachTrace(curr, dpP, i+1, j-1, k+1, l-1, NTRANS));
	    } else {
	       if (grammar == YRN) {
		  curr->transition = TPN;
		  PushTracestack(stack, AttachTrace(curr, dpN, i+1, j-1, k+1, l-1, NTRANS));
	       } else {
		  curr->transition = TPN;
		  curr->emitLx = -1; curr->emitLy = -1;
		  curr->emitRx = -1; curr->emitRy = -1;
		  PushTracestack(stack, AttachTrace(curr, dpN, i, j, k, l, NTRANS));
	       }
	    }
	    break;

	 case dpN:
	    if ((i > j) || (k > l)) {
	       printf("\nSHIT: Bad transition from N\n");
	       PushTracestack(stack, AttachTrace(curr, dpRm, i, j, k, l, NTRANS));
	    } else if (mx[dpRm][j-1][dx-1][l-1][dy-1]
		  + model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		  + model->transitions[TNRM] == mx[dpN][j][dx][l][dy]) {
	       curr->emitLx = -1; curr->emitLy = -1; curr->transition = TNRM;
	       PushTracestack(stack, AttachTrace(curr, dpRm, i, j-1, k, l-1, NTRANS));
	    } else if (mx[dpRx][j-1][dx-1][l][dy] + model->emissions[eSS((int)seqX->dseq[j])]
		  + model->transitions[TNRX] == mx[dpN][j][dx][l][dy]) {
	       curr->emitLx = -1; curr->emitLy = -1; curr->emitRy = -1;
	       curr->transition = TNRX;
	       PushTracestack(stack, AttachTrace(curr, dpRx, i, j-1, k, l, NTRANS));
	    } else if (mx[dpRy][j][dx][l-1][dy-1] + model->emissions[eSS((int)seqY->dseq[l])]
		  + model->transitions[TNRY] == mx[dpN][j][dx][l][dy]) {
	       curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1;
	       curr->transition = TNRY;
	       PushTracestack(stack, AttachTrace(curr, dpRy, i, j, k, l-1, NTRANS));
	    } else if (mx[dpLm][j][dx-1][l][dy-1] + model->transitions[TNLM]
		  + model->emissions[eAL(seqX->dseq[i],seqY->dseq[k])] == mx[dpN][j][dx][l][dy]) {
	       curr->emitRx = -1; curr->emitRy = -1; curr->transition = TNLM;
	       PushTracestack(stack, AttachTrace(curr, dpLm, i+1, j, k+1, l, NTRANS));
	    } else if (mx[dpLx][j][dx-1][l][dy] + model->transitions[TNLX]
		  + model->emissions[eSS((int)seqX->dseq[i])] == mx[dpN][j][dx][l][dy]) {
	       curr->emitRx = -1; curr->emitLy = -1; curr->emitRy = -1;
	       curr->transition = TNLX;
	       PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	    } else if (mx[dpLy][j][dx][l][dy-1] + model->transitions[TNLY]
		  + model->emissions[eSS((int)seqY->dseq[k])] == mx[dpN][j][dx][l][dy]) {
	       curr->transition = TNLY;
	       curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	       PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));
	       /* We want to do this state last so we minimize the number of
		* times we're doing this internal loop */
	    } else {
	       for (a = i; a <= j; a++) {
		  for (b = k; b <= l; b++) {
		     if (!((a == j) && (b == l))) {
			if (mx[dpLm][a][dist(i,a)][b][dist(k,b)] 
			      + mx[dpS][j][dist(a+1,j)][l][dist(b+1,j)] 
			      + model->transitions[TNB]
			      == mx[dpN][j][dx][l][dy]) {
			   curr->emitLx = -1; curr->emitRx = -1; 
			   curr->emitLy = -1; curr->emitRy = -1;
			   curr->transition = TNB;
			   PushTracestack(stack, AttachTrace(curr, dpS, a+1, j, b+1, l, NTRANS));
			   PushTracestack(stack, AttachTrace(curr, dpLm, i, a, k, b, NTRANS));
			   b = l+1; a = j+1; 	/* Short circuit */
			}
		     }
		  }
	       }
	    }
	    break;

	 case dpLm: 
	    if ((i > j) || (k > l)) {
	       printf("\nSHIT: Bad transition from Lm\n");
	       PushTracestack(stack, AttachTrace(curr, dpRm, i, j, k, l, NTRANS));
	    } else if (mx[dpLm][j][dx-1][l][dy-1] + model->emissions[eAL(seqX->dseq[i],seqY->dseq[k])] 
		  + model->transitions[TLMM] == mx[dpLm][j][dx][l][dy]) {
	       curr->emitRx = -1; curr->emitRy = -1;
	       curr->transition = TLMM;
	       PushTracestack(stack, AttachTrace(curr, dpLm, i+1, j, k+1, l, NTRANS));
	    } else if (mx[dpLx][j][dx-1][l][dy] + model->emissions[eSS((int)seqX->dseq[i])] 
		  + model->transitions[TLMX] == mx[dpLm][j][dx][l][dy]) {
	       curr->emitRx = -1; curr->emitLy = -1; curr->emitRy = -1;
	       curr->transition = TLMX;
	       PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	    } else if (mx[dpLy][j][dx][l][dy-1] + model->emissions[eSS((int)seqY->dseq[k])] 
		  + model->transitions[TLMY] == mx[dpLm][j][dx][l][dy]) {
	       curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	       curr->transition = TLMY;
	       PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));
	    } else {
	       if (grammar == NUS) {
		  curr->transition = TLMS;
		  PushTracestack(stack, AttachTrace(curr, dpS, i+1, j-1, k+1, l-1, NTRANS));
	       } else {
		  curr->transition = TLMP;
		  PushTracestack(stack, AttachTrace(curr, dpP, i+1, j-1, k+1, l-1, NTRANS));
	       }
	    }
	    break;
	 case dpLx: 
	    if ((i > j) || (k > l)) {
	       printf("\nSHIT: Bad transition from Lx\n");
	       PushTracestack(stack, AttachTrace(curr, dpRm, i, j, k, l, NTRANS));
	    } else if (mx[dpLm][j][dx-1][l][dy-1] + model->emissions[eAL(seqX->dseq[i],seqY->dseq[k])]
		  + model->transitions[TLXM] == mx[dpLx][j][dx][l][dy]) {
	       curr->emitRx = -1; curr->emitRy = -1;
	       curr->transition = TLXM;
	       PushTracestack(stack, AttachTrace(curr, dpLm, i+1, j, k+1, l, NTRANS));
	    } else if (mx[dpLx][j][dx-1][l][dy] + model->emissions[eSS((int)seqX->dseq[i])] 
		  + model->transitions[TLXX] == mx[dpLx][j][dx][l][dy]) {
	       curr->emitRx = -1; curr->emitLy = -1; curr->emitRy = -1;
	       curr->transition = TLXX;
	       PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	    } else {
	       if (grammar == NUS) {
		  curr->transition = TLXS;
		  PushTracestack(stack, AttachTrace(curr, dpS, i+1, j-1, k+1, l-1, NTRANS));
	       } else {
		  curr->transition = TLXP;
		  PushTracestack(stack, AttachTrace(curr, dpP, i+1, j-1, k+1, l-1, NTRANS));
	       }
	    }
	    break;
	 case dpLy: 
	    if ((i > j) || (k > l)) {
	       printf("\nSHIT: Bad transition from Ly\n");
	       PushTracestack(stack, AttachTrace(curr, dpRm, i, j, k, l, NTRANS));
	    } else if (mx[dpLm][j][dx-1][l][dy-1] + model->emissions[eAL(seqX->dseq[i],seqY->dseq[k])]
		  + model->transitions[TLYM] == mx[dpLy][j][dx][l][dy]) {
	       curr->emitRx = -1; curr->emitRy = -1;
	       curr->transition = TLYM;
	       PushTracestack(stack, AttachTrace(curr, dpLm, i+1, j, k+1, l, NTRANS));
	    } else if (mx[dpLy][j][dx][l][dy-1] + model->emissions[eSS((int)seqY->dseq[k])] 
		  + model->transitions[TLYY] == mx[dpLy][j][dx][l][dy]) {
	       curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	       curr->transition = TLYY;
	       PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));
	    } else {
	       if (grammar == NUS) {
		  curr->transition = TLYS;
		  PushTracestack(stack, AttachTrace(curr, dpS, i+1, j-1, k+1, l-1, NTRANS));
	       } else {
		  curr->transition = TLYP;
		  PushTracestack(stack, AttachTrace(curr, dpP, i+1, j-1, k+1, l-1, NTRANS));
	       }
	    }
	    break;
	 case dpRm: 
	    /* We need to check for each 
	     * possible case of single stranded: (X, Y, both) ? */
	    if ((i > j) && (k > l)) {	/* Ran out of both sequences */
	       curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1; curr->emitRy = -1;
	       curr->transition = TRME;
	    } else if (i > j) {		/* Ran out of X, more Y exists */
	       curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1; 
	       curr->transition = TRMY;
	       PushTracestack(stack, AttachTrace(curr, dpRy, i, j, k, l-1, NTRANS));
	    } else if (k > l) {		/* Ran out of Y, more X exists */
	       curr->emitLx = -1; curr->emitLy = -1; curr->emitRy = -1;
	       curr->transition = TRMX;
	       PushTracestack(stack, AttachTrace(curr, dpRy, i, j-1, k, l, NTRANS));

	    } else if ((i == j) || (k == l)) {
	       curr->emitLx = -1; curr->emitLy = -1; 
	       curr->transition = TRMM;
	       PushTracestack(stack, AttachTrace(curr, dpRm, i, j-1, k, l-1, NTRANS));
	    } else if (mx[dpRx][j-1][dx-1][l][dy] + model->emissions[eSS((int)seqX->dseq[j])]
		  + model->transitions[TRMX] == mx[dpRm][j][dx][l][dy]) {
	       curr->emitLx = -1; curr->emitLy = -1; curr->emitRy = -1;
	       curr->transition = TRMX;
	       PushTracestack(stack, AttachTrace(curr, dpRx, i, j-1, k, l, NTRANS));
	    } else if (mx[dpRy][j][dx][l-1][dy-1] + model->emissions[eSS((int)seqY->dseq[l])] 
		  + model->transitions[TRMY] == mx[dpRm][j][dx][l][dy])  {
	       curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1; 
	       curr->transition = TRMY;
	       PushTracestack(stack, AttachTrace(curr, dpRy, i, j, k, l-1, NTRANS));
	    } else {
	       curr->emitLx = -1; curr->emitLy = -1; 
	       curr->transition = TRMM;
	       PushTracestack(stack, AttachTrace(curr, dpRm, i, j-1, k, l-1, NTRANS));
	    }
	    break;
	 case dpRx: 
	    if (i > j) {
	       curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1; curr->emitRy = -1;
	       curr->transition = TRXE;
	    } else if (k > l) {
	       curr->emitLx = -1; curr->emitLy = -1; curr->emitRy = -1;
	       curr->transition = TRXX;
	       PushTracestack(stack, AttachTrace(curr, dpRx, i, j-1, k, l, NTRANS));
	    } else if (mx[dpRm][j-1][dx-1][l-1][dy-1] + model->transitions[TRXM] 
		  + model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		  == mx[dpRx][j][dx][l][dy]) { 
	       curr->emitLx = -1; curr->emitLy = -1; 
	       curr->transition = TRXM;
	       PushTracestack(stack, AttachTrace(curr, dpRm, i, j-1, k, l-1, NTRANS));
	    } else { 
	       curr->emitLx = -1; curr->emitLy = -1; curr->emitRy = -1;
	       curr->transition = TRXX;
	       PushTracestack(stack, AttachTrace(curr, dpRx, i, j-1, k, l, NTRANS));
	    }
	    break;
	 case dpRy: 
	    if (k > l) {
	       curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1; curr->emitRy = -1;
	       curr->transition = TRYE;
	    } else if (i > j) {
	       curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1; 
	       curr->transition = TRYY;
	       PushTracestack(stack, AttachTrace(curr, dpRy, i, j, k, l-1, NTRANS));
	    } else if (mx[dpRm][j-1][dx-1][l-1][dy-1] + model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		  + model->transitions[TRYM] == mx[dpRy][j][dx][l][dy]) {
	       curr->emitLx = -1; curr->emitLy = -1; 
	       curr->transition = TRYM;
	       PushTracestack(stack, AttachTrace(curr, dpRm, i, j-1, k, l-1, NTRANS));
	    } else {
	       curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1; 
	       curr->transition = TRYY;
	       PushTracestack(stack, AttachTrace(curr, dpRy, i, j, k, l-1, NTRANS));
	    }
	    break;
	 default: 
	    break;
      }
   } /* end while stack not empty*/
   FreeTracestack(stack);
   return parsetree;
}

/***************************** TRAIN ********************************/
/* Function: khs2traceNUS 
 * Date:     RDD, Mon Jul 14 15:12:41 CDT 2003 [St Louis]
 *
 * Purpose: Convert KHS to traceback tree properly 
 * 	labeled for NUS+ grammar.
 *
 * Args:     
 *	dolist  Traceback tree to build from KHS	
 *	ct	KHS info represented as ct format
 *	Xseq	ALIGNED sequence X
 *	Yseq	ALIGNED sequence Y
 *
 * Note: Xseq and Yseq may contain gaps and must be of the same length
 * 		(same length as ct)
 *
 * Returns: FALSE if error encountered
 * 	TRUE otherwise
 *  ** traceback tree in unaligned coordinates **
 */
   int
khs2traceNUS(struct tracestack_s *dolist, int *ct, char *Xseq, char *Yseq)
{
   struct trace_s      *cur;
   int ai, aj, amid;
   int i, j, a, k, l, b;

   while ((cur = PopTracestack(dolist)) != NULL) {
      ai = cur->emitl;           /* 0..len-1 */
      aj = cur->emitr;           /* 0..len-1 */
      i = cur->emitLx; j = cur->emitRx;
      k = cur->emitLy; l = cur->emitRy;

      /* printf("%s (ai, aj) = (%d, %d) X(i, j) = (%d, %d) Y(k, l) = (%d, %d)\n",
	 dpNAME[NUS][cur->nonterminal], ai, aj, i, j, k, l);
	 */
      if (ai > aj) {		/* no more alignment */
	 if (cur->nonterminal == dpRm) {
	    cur->transition = TRME;
	    cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
	 } else if (cur->nonterminal == dpRx) {
	    cur->transition = TRXE;
	    cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
	 } else {
	    cur->transition = TRYE;
	    cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
	 }
      } else if (ct[aj] == -1) {   /* aj unpaired: single strand right */
	 if (isRstate(cur->nonterminal)) {	/* right single stranded */
	    if (cur->nonterminal == dpRm) {
	       if (isgap(Xseq[aj])) {        /* TRMY */
		  cur->transition = TRMY;
		  cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRy, ai, aj-1, i, j, k, l-1, NTRANS));
	       } else if (isgap(Yseq[aj])) { /* TRMX */
		  cur->transition = TRMX;
		  cur->emitLx = -1; cur->emitLy = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRx, ai, aj-1, i, j-1, k, l, NTRANS));
	       } else { /* TRMM */
		  cur->transition = TRMM;
		  cur->emitLx = -1; cur->emitLy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRm, ai, aj-1, i, j-1, k, l-1, NTRANS));
	       }
	    } else if (cur->nonterminal == dpRx) {
	       if (isgap(Yseq[aj])) {        /* TRXX */
		  cur->transition = TRXX;
		  cur->emitLx = -1; cur->emitLy = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRx, ai, aj-1, i, j-1, k, l, NTRANS));
	       } else { /* TRXM */
		  cur->transition = TRXM;
		  cur->emitLx = -1; cur->emitLy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRm, ai, aj-1, i, j-1, k, l-1, NTRANS));
	       }
	    } else { /* dpRy */
	       if (isgap(Xseq[aj])) {        /* TRYY */
		  cur->transition = TRYY;
		  cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRy, ai, aj-1, i, j, k, l-1, NTRANS));
	       } else { /* TRMM */
		  cur->transition = TRYM;
		  cur->emitLx = -1; cur->emitLy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRm, ai, aj-1, i, j-1, k, l-1, NTRANS));
	       }
	    }
	 } else {
	    amid = find_split(ct, ai, aj);
	    if (amid  < 0) {   /* no pairs, open right string */
	       if (isgap(Xseq[aj])) /* TSRY */ {
		  cur->transition = TSRY;
		  cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRy, ai, aj-1, i, j, k, l-1, NTRANS));
	       } else if (isgap(Yseq[aj])) /* TSRX */ {
		  cur->transition = TSRX;
		  cur->emitLx = -1; cur->emitLy = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRx, ai, aj-1, i, j-1, k, l, NTRANS));
	       } else { /* TSRM */
		  cur->transition = TSRM;
		  cur->emitLx = -1; cur->emitLy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRm, ai, aj-1, i, j-1, k, l-1, NTRANS));
	       }
	    } else {        /* pairs exist, must bifurcate */
	       cur->transition = TSB;
	       cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
	       /* We must find mid for each sequence */
	       a = dealignedCoord(Xseq, ai, amid, i);
	       b = dealignedCoord(Yseq, ai, amid, k);
	       PushTracestack(dolist, 
		     AttachATrace(cur, dpS, amid+1, aj, a+1, j, b+1, l, NTRANS));
	       PushTracestack(dolist, 
		     AttachATrace(cur, dpLm, ai, amid, i, a, k, b, NTRANS));
	    }
	 }
      } else if (ct[ai] == -1) {   /* ai unpaired; single strand left */
	 if (isLstate(cur->nonterminal)) {
	    if (cur->nonterminal == dpLm) {
	       if (isgap(Xseq[ai])) {
		  cur->transition = TLMY;
		  cur->emitLx = -1; cur->emitRx = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLy, ai+1, aj, i, j, k+1, l, NTRANS));
	       } else if (isgap(Yseq[ai])) {
		  cur->transition = TLMX;
		  cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLx, ai+1, aj, i+1, j, k, l, NTRANS));
	       } else { /* TLMM */
		  cur->transition = TLMM;
		  cur->emitRx = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLm, ai+1, aj, i+1, j, k+1, l, NTRANS));
	       }
	    } else  if (cur->nonterminal == dpLx) {
	       if (isgap(Yseq[ai])) {
		  cur->transition = TLXX;
		  cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLx, ai+1, aj, i+1, j, k, l, NTRANS));
	       } else { /* TLXM */
		  cur->transition = TLXM;
		  cur->emitRx = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLm, ai+1, aj, i+1, j, k+1, l, NTRANS));
	       }
	    } else  {        /* dpLy */
	       if (isgap(Xseq[ai])) {
		  cur->transition = TLYY;
		  cur->emitLx = -1; cur->emitRx = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLy, ai+1, aj, i, j, k+1, l, NTRANS));
	       } else { /* TLYM */
		  cur->transition = TLYM;
		  cur->emitRx = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLm, ai+1, aj, i+1, j, k+1, l, NTRANS));
	       }
	    }

	 } else {               /* Must be in S */
	    amid = find_split(ct, ai, aj);
	    if (amid < aj) {              /* Must bifurcate */
	       cur->transition = TSB;
	       cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
	       /* We must find mid for each sequence */
	       a = dealignedCoord(Xseq, ai, amid, i);
	       b = dealignedCoord(Yseq, ai, amid, k);
	       PushTracestack(dolist, 
		     AttachATrace(cur, dpS, amid+1, aj, a+1, j, b+1, l, NTRANS));
	       PushTracestack(dolist, 
		     AttachATrace(cur, dpLm, ai, amid, i, a, k, b, NTRANS));
	    } else {            /* S->L */
	       if (isgap(Xseq[ai])) /* TSLY */ {
		  cur->transition = TSLY;
		  cur->emitLx = -1; cur->emitRx = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLy, ai+1, aj, i, j, k+1, l, NTRANS));
	       } else if (isgap(Yseq[ai])) /* TSLX */ {
		  cur->transition = TSLX;
		  cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLx, ai+1, aj, i+1, j, k, l, NTRANS));
	       } else { /* TSLM */
		  cur->transition = TSLM;
		  cur->emitRx = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLm, ai+1, aj, i+1, j, k+1, l, NTRANS));
	       }
	    }
	 }
      } else if (ct[ai] == aj) {    /* ai,aj paired to each other */
	 if (isLstate(cur->nonterminal)) {
	    if (cur->nonterminal == dpLm) {
	       cur->transition = TLMS;
	    } else  if (cur->nonterminal == dpLx) {
	       cur->transition = TLXS;
	    } else {
	       cur->transition = TLYS;
	    }
	 } else {
	    cur->transition = TSS;
	 }
	 PushTracestack(dolist, 
	       AttachATrace(cur, dpS, ai+1, aj-1, i+1, j-1, k+1, l-1, NTRANS));
      } else {            /* ai, aj paired but not to each other */
	 cur->transition = TSB;
	 cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
	 /* We must find mid for each sequence */
	 amid = find_split(ct, ai, aj);
	 a = dealignedCoord(Xseq, ai, amid, i);
	 b = dealignedCoord(Yseq, ai, amid, k);
	 PushTracestack(dolist, 
	       AttachATrace(cur, dpS, amid+1, aj, a+1, j, b+1, l, NTRANS));
	 PushTracestack(dolist, 
	       AttachATrace(cur, dpLm, ai, amid, i, a, k, b, NTRANS));

      }
      /*
      fprintf(stdout, "(%#12x) %2d  %5d   %5d  %5d  %5d  %5d  %5d  %3d  %#10x  %#10x  \n",
	     (int) cur, cur->nonterminal, cur->emitl, cur->emitr, 
	     cur->emitLx, cur->emitRx, cur->emitLy, cur->emitRy, cur->transition, 
	     (int) cur->nxtl, (int) cur->nxtr);
	     */
   }   /* while something's on dolist stack */
   return 1;
}

/* Function: khs2traceYRN
 * Date:     RDD, Tue Jul 15 16:00:59 CDT 2003 [St Louis]
 *
 * Purpose: Convert KHS to traceback tree properly 
 * 	labeled for NUS+ grammar.
 *
 * Args:     
 *	dolist  Traceback tree to build from KHS	
 *	ct	KHS info represented as ct format
 *	grammar	NUS, YRN, or YR2
 *	Xseq	ALIGNED sequence X
 *	Yseq	ALIGNED sequence Y
 *
 * Note: Xseq and Yseq may contain gaps and must be of the same length
 * 		(same length as ct)
 *
 * Returns: FALSE if error encountered
 * 	TRUE otherwise
 *  ** traceback tree in unaligned coordinates **
 */
   int
khs2traceYRN(struct tracestack_s *dolist, int *ct, int grammar, char *Xseq, char *Yseq)
{
   struct trace_s      *cur;
   int ai, aj, amid;
   int i, j, a, k, l, b;

   while ((cur = PopTracestack(dolist)) != NULL) {
      ai = cur->emitl;           /* 0..len-1 */
      aj = cur->emitr;           /* 0..len-1 */
      i = cur->emitLx; j = cur->emitRx;
      k = cur->emitLy; l = cur->emitRy;

      /* printf("%s (ai, aj) = (%d, %d) X(i, j) = (%d, %d) Y(k, l) = (%d, %d)\n",
	 dpNAME[grammar][cur->nonterminal], ai, aj, i, j, k, l);
	 */
      if (ai > aj) {		/* no more alignment */
	 if (cur->nonterminal == dpRm) {
	    cur->transition = TRME;
	    cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
	 } else if (cur->nonterminal == dpRx) {
	    cur->transition = TRXE;
	    cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
	 } else {
	    cur->transition = TRYE;
	    cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
	 }
      } else if (ct[aj] == -1) {   /* aj unpaired: single strand right */
	 if (isRstate(cur->nonterminal)) {	/* right single stranded */
	    if (cur->nonterminal == dpRm) {
	       if (isgap(Xseq[aj])) {        /* TRMY */
		  cur->transition = TRMY;
		  cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRy, ai, aj-1, i, j, k, l-1, NTRANS));
	       } else if (isgap(Yseq[aj])) { /* TRMX */
		  cur->transition = TRMX;
		  cur->emitLx = -1; cur->emitLy = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRx, ai, aj-1, i, j-1, k, l, NTRANS));
	       } else { /* TRMM */
		  cur->transition = TRMM;
		  cur->emitLx = -1; cur->emitLy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRm, ai, aj-1, i, j-1, k, l-1, NTRANS));
	       }
	    } else if (cur->nonterminal == dpRx) {
	       if (isgap(Yseq[aj])) {        /* TRXX */
		  cur->transition = TRXX;
		  cur->emitLx = -1; cur->emitLy = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRx, ai, aj-1, i, j-1, k, l, NTRANS));
	       } else { /* TRXM */
		  cur->transition = TRXM;
		  cur->emitLx = -1; cur->emitLy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRm, ai, aj-1, i, j-1, k, l-1, NTRANS));
	       }
	    } else { /* dpRy */
	       if (isgap(Xseq[aj])) {        /* TRYY */
		  cur->transition = TRYY;
		  cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRy, ai, aj-1, i, j, k, l-1, NTRANS));
	       } else { /* TRMM */
		  cur->transition = TRYM;
		  cur->emitLx = -1; cur->emitLy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRm, ai, aj-1, i, j-1, k, l-1, NTRANS));
	       }
	    }
	 } else if (cur->nonterminal == dpP) {
	    /* Technically only legal in YR2; Hack for YRN grammars */
	    cur->transition = TPN; 
	    cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		  AttachATrace(cur, dpN, ai, aj, i, j, k, l, NTRANS));
	 } else {
	    amid = find_split(ct, ai, aj);
	    if (amid  < 0) {   /* no pairs, open right string */
	       if (isgap(Xseq[aj])) /* TSRY */ {
		  if (cur->nonterminal == dpS) cur->transition = TSRY;
		  else cur->transition = TNRY;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRy, ai, aj-1, i, j, k, l-1, NTRANS));
	       } else if (isgap(Yseq[aj])) /* TSRX */ {
		  if (cur->nonterminal == dpS) cur->transition = TSRX;
		  else cur->transition = TNRX;
		  cur->emitLx = -1; cur->emitLy = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRx, ai, aj-1, i, j-1, k, l, NTRANS));
	       } else { /* TSRM */
		  if (cur->nonterminal == dpS) cur->transition = TSRM;
		  else cur->transition = TNRM;
		  cur->emitLx = -1; cur->emitLy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpRm, ai, aj-1, i, j-1, k, l-1, NTRANS));
	       }
	    } else {        /* pairs exist, must bifurcate */
	       if (cur->nonterminal == dpS) cur->transition = TSB;
	       else cur->transition = TNB;
	       cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
	       /* We must find mid for each sequence */
	       a = dealignedCoord(Xseq, ai, amid, i);
	       b = dealignedCoord(Yseq, ai, amid, k);
	       PushTracestack(dolist, 
		     AttachATrace(cur, dpS, amid+1, aj, a+1, j, b+1, l, NTRANS));
	       PushTracestack(dolist, 
		     AttachATrace(cur, dpLm, ai, amid, i, a, k, b, NTRANS));
	    }
	 }
      } else if (ct[ai] == -1) {   /* ai unpaired; single strand left */
	 if (isLstate(cur->nonterminal)) {
	    if (cur->nonterminal == dpLm) {
	       if (isgap(Xseq[ai])) {
		  cur->transition = TLMY;
		  cur->emitLx = -1; cur->emitRx = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLy, ai+1, aj, i, j, k+1, l, NTRANS));
	       } else if (isgap(Yseq[ai])) {
		  cur->transition = TLMX;
		  cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLx, ai+1, aj, i+1, j, k, l, NTRANS));
	       } else { /* TLMM */
		  cur->transition = TLMM;
		  cur->emitRx = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLm, ai+1, aj, i+1, j, k+1, l, NTRANS));
	       }
	    } else  if (cur->nonterminal == dpLx) {
	       if (isgap(Yseq[ai])) {
		  cur->transition = TLXX;
		  cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLx, ai+1, aj, i+1, j, k, l, NTRANS));
	       } else { /* TLXM */
		  cur->transition = TLXM;
		  cur->emitRx = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLm, ai+1, aj, i+1, j, k+1, l, NTRANS));
	       }
	    } else  {        /* dpLy */
	       if (isgap(Xseq[ai])) {
		  cur->transition = TLYY;
		  cur->emitLx = -1; cur->emitRx = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLy, ai+1, aj, i, j, k+1, l, NTRANS));
	       } else { /* TLYM */
		  cur->transition = TLYM;
		  cur->emitRx = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLm, ai+1, aj, i+1, j, k+1, l, NTRANS));
	       }
	    }
	 } else if (cur->nonterminal == dpP) {
	    /* Technically only valid in YR2; Hack for YRN */
	    cur->transition = TPN;
	    cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		  AttachATrace(cur, dpN, ai, aj, i, j, k, l, NTRANS));
	 } else {               /* Must be in S or N */
	    amid = find_split(ct, ai, aj);
	    if (amid < aj) {              /* Must bifurcate */
	       if (cur->nonterminal == dpS) cur->transition = TSB;
	       else cur->transition = TNB;
	       cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
	       /* We must find mid for each sequence */
	       a = dealignedCoord(Xseq, ai, amid, i);
	       b = dealignedCoord(Yseq, ai, amid, k);
	       PushTracestack(dolist, 
		     AttachATrace(cur, dpS, amid+1, aj, a+1, j, b+1, l, NTRANS));
	       PushTracestack(dolist, 
		     AttachATrace(cur, dpLm, ai, amid, i, a, k, b, NTRANS));
	    } else {            /* S/N->L */
	       if (isgap(Xseq[ai])) /* TSLY */ {
		  if (cur->nonterminal == dpS) cur->transition = TSLY;
		  else cur->transition = TNLY;
		  cur->emitLx = -1; cur->emitRx = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLy, ai+1, aj, i, j, k+1, l, NTRANS));
	       } else if (isgap(Yseq[ai])) /* TSLX */ {
		  if (cur->nonterminal == dpS) cur->transition = TSLX;
		  else cur->transition = TNLX;
		  cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLx, ai+1, aj, i+1, j, k, l, NTRANS));
	       } else { /* TSLM */
		  if (cur->nonterminal == dpS) cur->transition = TSLM;
		  else cur->transition = TNLM;
		  cur->emitRx = -1; cur->emitRy = -1;
		  PushTracestack(dolist, 
			AttachATrace(cur, dpLm, ai+1, aj, i+1, j, k+1, l, NTRANS));
	       }
	    }
	 }
      } else if (ct[ai] == aj) {    /* ai,aj paired to each other */
	 /* Determine which transition we'll use */
	 if (isLstate(cur->nonterminal)) {
	    if (cur->nonterminal == dpLm) {
	       cur->transition = TLMP;
	    } else  if (cur->nonterminal == dpLx) {
	       cur->transition = TLXP;
	    } else {
	       cur->transition = TLYP;
	    }
	 } else if (cur->nonterminal == dpS) {
	    cur->transition = TSP;
	 } else {	/* dpP */
	    if (grammar == YRN) {
	       /* This is the only pairing state which doesn't 
		* lead into a dpP state */
	       if (ct[ai+1] != aj-1) cur->transition = TPN;
	       else cur->transition = TPP;
	    } else {
	       cur->transition = TPP;
	    }
	 }
	 /* Given our transition, we move onto the next state */
	 if (cur->transition != TPN) {
	    PushTracestack(dolist, 
		  AttachATrace(cur, dpP, ai+1, aj-1, i+1, j-1, k+1, l-1, NTRANS));
	 } else {
	    PushTracestack(dolist, 
		  AttachATrace(cur, dpN, ai+1, aj-1, i+1, j-1, k+1, l-1, NTRANS));
	 }
      } else {            /* ai, aj paired but not to each other */
	 if ((grammar == YR2) && (cur->nonterminal == dpP)) {
	    cur->transition = TPN;
	    cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		  AttachATrace(cur, dpN, ai, aj, i, j, k, l, NTRANS));
	 } else {
	    if (cur->nonterminal == dpS) cur->transition = TSB;
	    else cur->transition = TNB;
	    cur->emitLx = -1; cur->emitRx = -1; cur->emitLy = -1; cur->emitRy = -1;
	    /* We must find mid for each sequence */
	    amid = find_split(ct, ai, aj);
	    a = dealignedCoord(Xseq, ai, amid, i);
	    b = dealignedCoord(Yseq, ai, amid, k);
	    PushTracestack(dolist, 
		  AttachATrace(cur, dpS, amid+1, aj, a+1, j, b+1, l, NTRANS));
	    PushTracestack(dolist, 
		  AttachATrace(cur, dpLm, ai, amid, i, a, k, b, NTRANS));
	 }

      }
      /*
      fprintf(stdout, "(%#12x) %2d  %5d   %5d  %5d  %5d  %5d  %5d  %3d  %#10x  %#10x  \n",
	     (int) cur, cur->nonterminal, cur->emitl, cur->emitr, 
	     cur->emitLx, cur->emitRx, cur->emitLy, cur->emitRy, cur->transition, 
	     (int) cur->nxtl, (int) cur->nxtr);
	     */
   }   /* while something's on dolist stack */
   return 1;
}

void
hcTransNUS(INTMOD *sc)
{
   /* Transitions : Adapted (loosely) on conus' unaY16S.mod */
   sc->transitions[TSS] = asIntLog(0.7596);
   sc->transitions[TSLM] = asIntLog(0.01475);
   sc->transitions[TSLX] = asIntLog(0.007375);
   sc->transitions[TSLY] = asIntLog(0.007375);
   sc->transitions[TSRM] = asIntLog(0.01585);
   sc->transitions[TSRX] = asIntLog(0.007925);
   sc->transitions[TSRY] = asIntLog(0.007925);
   sc->transitions[TSB] = asIntLog(0.1792);

   sc->transitions[TLMS] = asIntLog(0.2363);
   sc->transitions[TLMM] = asIntLog(0.38185);
   sc->transitions[TLMX] = asIntLog(0.190925);
   sc->transitions[TLMY] = asIntLog(0.190925);

   sc->transitions[TLXS] = asIntLog(0.2363);
   sc->transitions[TLXM] = asIntLog(0.5091);
   sc->transitions[TLXX] = asIntLog(0.2546);

   sc->transitions[TLYS] = asIntLog(0.2363);
   sc->transitions[TLYM] = asIntLog(0.5091);
   sc->transitions[TLYY] = asIntLog(0.2546);

   sc->transitions[TRMM] = asIntLog(0.3811);
   sc->transitions[TRMX] = asIntLog(0.19055);
   sc->transitions[TRMY] = asIntLog(0.19055);
   sc->transitions[TRME] = asIntLog(0.2378);

   sc->transitions[TRXE] = asIntLog(0.2378);
   sc->transitions[TRXM] = asIntLog(0.5081);
   sc->transitions[TRXX] = asIntLog(0.2541);

   sc->transitions[TRYE] = asIntLog(0.2378);
   sc->transitions[TRYM] = asIntLog(0.5081);
   sc->transitions[TRYY] = asIntLog(0.2541);

   sc->emissions[eSS(ntA)] = asIntLog(0.3944);
   sc->emissions[eSS(ntC)] = asIntLog(0.1540);
   sc->emissions[eSS(ntG)] = asIntLog(0.2354);
   sc->emissions[eSS(ntU)] = asIntLog(0.2161);
}

void
hcTransYRN(INTMOD *sc)
{
   /* Transitions : */
   sc->transitions[TSP] = asIntLog(0.7596);
   sc->transitions[TSLM] = asIntLog(0.01475);
   sc->transitions[TSLX] = asIntLog(0.007375);
   sc->transitions[TSLY] = asIntLog(0.007375);
   sc->transitions[TSRM] = asIntLog(0.01585);
   sc->transitions[TSRX] = asIntLog(0.007925);
   sc->transitions[TSRY] = asIntLog(0.007925);
   sc->transitions[TSB] = asIntLog(0.1792);

   sc->transitions[TLMP] = asIntLog(0.2363);
   sc->transitions[TLMM] = asIntLog(0.38185);
   sc->transitions[TLMX] = asIntLog(0.190925);
   sc->transitions[TLMY] = asIntLog(0.190925);

   sc->transitions[TLXP] = asIntLog(0.2363);
   sc->transitions[TLXM] = asIntLog(0.5091);
   sc->transitions[TLXX] = asIntLog(0.2546);

   sc->transitions[TLYP] = asIntLog(0.2363);
   sc->transitions[TLYM] = asIntLog(0.5091);
   sc->transitions[TLYY] = asIntLog(0.2546);

   sc->transitions[TRMM] = asIntLog(0.3811);
   sc->transitions[TRMX] = asIntLog(0.19055);
   sc->transitions[TRMY] = asIntLog(0.19055);
   sc->transitions[TRME] = asIntLog(0.2378);

   sc->transitions[TRXE] = asIntLog(0.2378);
   sc->transitions[TRXM] = asIntLog(0.5081);
   sc->transitions[TRXX] = asIntLog(0.2541);

   sc->transitions[TRYE] = asIntLog(0.2378);
   sc->transitions[TRYM] = asIntLog(0.5081);
   sc->transitions[TRYY] = asIntLog(0.2541);

   sc->transitions[TPP] = asIntLog(0.66);
   sc->transitions[TPN] = asIntLog(0.34);

   sc->transitions[TNLM] = asIntLog(0.061356);
   sc->transitions[TNLX] = asIntLog(0.030678);
   sc->transitions[TNLY] = asIntLog(0.030678);
   sc->transitions[TNRM] = asIntLog(0.065932);
   sc->transitions[TNRX] = asIntLog(0.032966);
   sc->transitions[TNRY] = asIntLog(0.032966);
   sc->transitions[TNB] = asIntLog(0.254576);

   sc->emissions[eSS(ntA)] = asIntLog(0.3944);
   sc->emissions[eSS(ntC)] = asIntLog(0.1540);
   sc->emissions[eSS(ntG)] = asIntLog(0.2354);
   sc->emissions[eSS(ntU)] = asIntLog(0.2161);
}

