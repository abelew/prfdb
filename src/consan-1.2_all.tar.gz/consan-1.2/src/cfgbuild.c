/* cfgbuild.c 
 *
 * Meta-functions for training, 
 * gathering statistics, and
 * setting up a model.
 */

#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"cfg.h"
#include"options.h"

/* Function: setupModel
 * Date:     Tue Apr  8 13:20:45 CDT 2003 [St Louis]
 *
 * Purpose: Using command line parameters, setup models. 
 *
 * Args:    
 *     options		command line selections
 *     model		The model parameters set
 *
 * Returns:  void.
 */
void
setupModel(OPTS *options, MODEL **loaded)
{
  FILE *ifp;
  FILE *ofp;
  MODEL *cfg;

  /* If a model is specified then should use the grammar 
   * and scoring scheme of the model */
  if (options->modelfile != NULL) {
    if (options->verbose) 
       printf("Loading a saved model %s\n", options->modelfile); fflush(stdout);
    ifp = fopen(options->modelfile, "r");
    ReadSCFG(ifp, &cfg);
    fclose(ifp);
    options->grammar = cfg->grammar;
    if (options->verbose) printf("Using %s grammar\n", grNAME[cfg->grammar]); 
    /* Set option parameters based on loaded model */
    if ((options->parameterout)) printModel(options->ofp, PRINT_FLT, cfg);
    fflush(stdout);

  /* Else use standard Nussinov scoring scheme */
  } else {
    printf("Using standard STA scoring\n"); fflush(stdout);
    allocModel(&cfg);
    handCodedModel(&(cfg->imod));   
    InvLogifySCFG(STA, &(cfg->imod), &(cfg->fmod));
    if (options->verbose) fprintf(options->ofp, 
	  "Using Scoring Nussinov parameters\n");
    if ((options->parameterout)) printModel(options->ofp, PRINT_BTH, cfg);
  }
    
  /* If asked to save the model, do so now. */
  if (options->savefile != NULL) {
    ofp = fopen(options->savefile, "w");
    SaveSCFG(ofp, cfg);
    fclose(ofp);
  } 

  *loaded = cfg;
}

/* Setup without ANY output -- regardless of options in settings */
void
setupModelQuiet(OPTS *options, MODEL **loaded)
{
  int parameterout;
  int verbose;

  parameterout = options->parameterout;
  verbose = options->verbose;
  options->parameterout = FALSE;
  options->verbose = FALSE;
  setupModel(options, loaded);
  options->parameterout = parameterout;
  options->verbose = verbose;
}


/* Function: Joint2Model
 * Date: RDD, Mon Sep 13 15:23:23 CDT 2004 [St Louis]
 *
 * Purpose: Convert matricies of joint probabilities
 * (typically from evolutionary models as described 
 * in matrix.c and evolve.c) into a MODEL for use in CYK.
 *
 * Args:
 *   transitions	array of transition probs  [NTRANS]
 *   gaps		P(a -) or P(- a)  [A C G U]
 *   singles		P(a b)		  [4 x 4]
 *   pairs		P(a b, c d)	  [16 x 16]
 *   ret_mod		Parameterized Model (allocated here)
 *
 * Returns:  TRUE if no problem
 * 	FALSE if problem found
 */
int
Joint2Model(float *transitions, 
    double *gaps, double *singles, double *pairs, MODEL **ret_mod)
{
  MODEL *mod;
  int i, j, k, l;

  allocModel(&mod);
  for (i = 0; i < NTRANS; i++) {
    mod->fmod.transitions[i] = transitions[i];
  }
  for (i = 0; i < ALPHA; i++) {
    mod->fmod.emissions[eSS(i)] = (float)gaps[i];
  }
  for (i = 0; i < ALPHA; i++) {
    for (j = 0; j < ALPHA; j++) {
      mod->fmod.emissions[eAL(i,j)] = (float)singles[i*ALPHA+j];
    }
  }
  for (i = 0; i < ALPHA; i++) {
    for (j = 0; j < ALPHA; j++) {
      for (k = 0; k < ALPHA; k++) {
	for (l = 0; l < ALPHA; l++) {
	  /* Translating between Elena's P matrix and 
	   * my pairing matrix */
	  mod->fmod.emissions[ePRN(i,j,k,l)] = 
	    (float)pairs[(idx(j,i))*PAIR+(idx(l,k))];
	}
      }
    }
  }

  *ret_mod = mod;
  /* Can we do some checks ?*/
  return 1;
}

