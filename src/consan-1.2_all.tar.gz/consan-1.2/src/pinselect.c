/* pinselect.c
 * Sat Jul 10 09:51:06 CDT 2004
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h> /* toupper */
#include <string.h> /* strchr */
#include <math.h> /* log */

#include "squid.h"
#include "cfg.h"
#include "consan.h"
#include "alphabet.h"
#include "options.h"

int setupPins(OPTS settings, SEQPR *rnas);
int fit2mem(OPTS settings, int lenX, int lenY, float **ptable, 
    SEQPR *opair, COORDS **ret_pins, int MBytes);

/**************** Setup Pins ***************/
/* Function: setupPins
 *
 * Purpose: Select appropriate pins given all of 
 * the command line designations.
 *
 * Args:
 *   settings	command line settings
 *   rnas	sequences of interest (unaligned)
 *
 * Return: 
 *   percent identity of optimal accuracy alignment */
int
setupPins(OPTS settings, SEQPR *rnas)
{
  int ncord;
  COORDS *pins;                 /* Pins to use in constrained Sankoff */
  CNSRNT *cnst;                 /* Same pins, in constraint format */
  SEQPR  *opair;                /* Optimal Accuracy Alignment if pred pins */
  float **ptable;               /* Posterior Table if we predict pins */
  float oaid;
  int cando = TRUE;

  /* Never overwrite any info we already have */
  if (rnas->c_info != NULL) return 0;

  pins = NULL;

  /* Given ptable? */
  if (settings.tablefile != NULL) {
    readPosteriors(settings.tablefile, rnas->sequence[SEQX]->len, 
	rnas->sequence[SEQY]->len, &ptable);
  } else {
    /* Given alignment? */
    if (settings.usegiven) { /* Use given alignment */
      getPTable(rnas->alignment, &ptable);
    } else {
      runHolmes(rnas, (settings.verbose || settings.debugg), !(settings.debugg), &ptable, &opair);
    }
  } 
  /* Optimal Accuracy Alignment Score */
  if (opair->alignment != NULL) 
    oaid = opair->alignment->aliid;
  else oaid = -1.0;

  /* Selection Method */
  if (settings.pinfile != NULL) {
    /* If using a specified pin file */
  } else if (settings.pinopt == QUALITY) {
    if (!settings.zset) settings.Zoption = 0.95; /* default */
    if (!settings.suppress) {
      printCNTMethod(settings.pinopt);
      printf(" Better than %1.4f!\n", settings.Zoption); 
    }
    ncord = qualityPins(ptable, opair->alignment, settings.Zoption, &pins);
    if (settings.verbose) 
      printf("%1.6f\t%d\n", opair->alignment->aliid, ncord);
  } else if (settings.pinopt == XBEST) {
    if (!settings.suppress) {
      printCNTMethod(settings.pinopt);
      printf(" (Num %d)!\n", settings.Poption); 
    }
    if (!settings.pset) settings.Poption = 3; /* default */
    alignPostBest(ptable, opair->alignment, settings.Poption, &pins);
  } else if (settings.pinopt == GALIGN) {
    if (!settings.suppress) {
      printCNTMethod(settings.pinopt);
      printf(" (Num %d)!\n", settings.Coption); 
    }
    if (!settings.cset) settings.Coption = 3; /* default */
    alignPostBest(ptable, rnas->alignment, settings.Coption, &pins);
  } else if (settings.pinopt == SPACED) {
    if (!settings.pset) settings.Poption = 5; /* default */
    if (!settings.wset) settings.Woption = 25; /* default */
    if (!settings.suppress) {
      printCNTMethod(settings.pinopt);
      printf(" (BEST %d SPACED %d) !\n",
	  settings.Poption, settings.Woption); 
    }
    alignSpaced(opair->alignment, ptable, settings.Poption, 
	settings.Woption, &pins);
  } else if (settings.pinopt == QRADIUS) {	/* DEFAULT */
    /* SHOULD BE HERE! */
    if (!settings.zset) settings.Zoption = 0.95; /* defaults */
    if (!settings.wset) settings.Woption = 20; /* defaults */
    if (!settings.suppress) {
      printCNTMethod(settings.pinopt);
      printf(" (Quality > %1.4f SPACED %d) !\n",
	  settings.Zoption, settings.Woption); 
    }
    qualitySpaced(ptable, opair->alignment, settings.Zoption, 
	settings.Woption, &pins);
  }

  if (pins != NULL) {
    if (settings.debugg) printCoordList(stdout, pins, FALSE);
    buildConstraints(rnas->sequence[SEQX]->len,
	rnas->sequence[SEQY]->len, pins, settings.pinopt, &cnst);
    ncord = countCoordList(pins);
    setCNTMethod(cnst, ncord, settings.Woption, settings.Zoption);
    if (settings.debugg) printConstraints(stdout,
	rnas->sequence[SEQX]->len, cnst, FALSE);
    rnas->c_info = cnst;
  } else {
    rnas->c_info = NULL;
  }

  if (settings.mset) cando = forceMemSize(settings, rnas, opair, ptable);

  /* Clean up */
  freeCoordList(pins);
  freeSeqPair(opair);
  freePosteriors(ptable, rnas->sequence[SEQY]->len);

  if (settings.debugg) printSeqPair(stdout, rnas);

  return cando;
}

int
forceMemSize(OPTS settings, SEQPR *rnas, SEQPR  *opair, float **ptable)
{
  CNSRNT *cnst;
  COORDS *pins;
  int ncord;
  int cando = TRUE;
  /* Local versions if we're not given this info */
  SEQPR *Lopair;
  float **Lptable;
  unsigned bytes;

  /* We've been asked to make certain we're under a set memory
   * limit.  In that case we've got to confirm that what we just
   * selected for pins actually fits.  */
  if (rnas->c_info != NULL) {
    bytes = fakeRedAllocMx(STA, rnas->c_info->sL, rnas->c_info->sR, 
	rnas->sequence[SEQX]->len, rnas->sequence[SEQY]->len);
  } else {
    /* Not using pins, so we must check that we can fit the full
     * allocation in this memory. */
    bytes = fakeAllocMx(STA, rnas->sequence[SEQX]->len, 
	rnas->sequence[SEQY]->len);
  }
  /* If we're over our memory limit, we default to more poor quality pins */
  if (bytes > (100 * settings.Moption)) {
    if (rnas->c_info != NULL) {	/* Pitch what we've already got */
      freeConstraints(rnas->c_info); 
      rnas->c_info = NULL;
    }
    settings.pinopt = SPACED;
    if (!settings.pset) settings.Poption = ncord/2; /* default */
    if (!settings.wset) settings.Woption = 25; /* default */
    if (!settings.suppress) {
      printf("SWITCH: ");
      printCNTMethod(SPACED);
      printf(" (fit under %d MB) !\n", settings.Moption);
    }
    if ((opair == NULL) || (ptable == NULL)) {
      /* Calc if we've not already got them */
      runHolmes(rnas, settings.verbose, !(settings.debugg), &Lptable, &Lopair);
      cando = fit2mem(settings, rnas->sequence[SEQX]->len, rnas->sequence[SEQY]->len,
	  Lptable, Lopair, &pins, 2000);
      freeSeqPair(Lopair);
      freePosteriors(Lptable, rnas->sequence[SEQY]->len);
    } else {
      cando = fit2mem(settings, rnas->sequence[SEQX]->len, rnas->sequence[SEQY]->len,
	  ptable, opair, &pins, 2000);
    }
    if (pins != NULL) {
      buildConstraints(rnas->sequence[SEQX]->len,
	  rnas->sequence[SEQY]->len, pins, settings.pinopt, &cnst);
      ncord = countCoordList(pins);
      setCNTMethod(cnst, ncord, settings.Woption, settings.Zoption);
      rnas->c_info = cnst;
    } else {
      cando = FALSE;
      rnas->c_info = NULL;
    }
    if (cando) printf("Using %d Pins!\n", countCoordList(pins));
  }
  return cando;
}

int
fit2mem(OPTS settings, int lenX, int lenY, float **ptable, SEQPR *opair, COORDS **ret_pins, int MBytes)
{
  COORDS *pins = NULL;
  CNSRNT *cnst;
  unsigned bytes;
  int pinnum = 1;
  int winsize = 25;

  printf("Max Pins: %d\n", opair->alignment->alen); fflush(stdout);

  /* Check that fully constrained alignment will fit under level */
  do {
    if (pins != NULL) freeCoordList(pins);
    alignSpaced(opair->alignment, ptable, pinnum, winsize, &pins);
    buildConstraints(lenX, lenY, pins, SPACED, &cnst);
    bytes = fakeRedAllocMx(STA, cnst->sL, cnst->sR, lenX, lenY);
    pinnum++;
    /* If max out pins at this spacing, reduce spacing? */
    if ((pinnum * winsize * 2) > opair->alignment->alen) {
      winsize = winsize - 5;
      pinnum = pinnum / 2;
    }
    freeConstraints(cnst);
  } while ((bytes > (100 * MBytes)) || (pinnum > opair->alignment->alen));

  *ret_pins = pins;
  /* A fully constrained alignment is still not small enough */
  if (pinnum > opair->alignment->alen) { return 0; }
  else return 1;
}

/**************** Select a Fixed Number of Pins ***************/

/* Function: alignPostBest 
 * Date:     RDD, Sat Jul 10 13:31:51 CDT 2004
 *
 * Purpose:  find best pins in posteriors
 * 	considering only the path represented by 
 * 	a given alignment
 *
 * Notes: If we give the optimal accuracy alignment 
 * (a la I. Holmes) then we can "easily" get a consistent 
 * set of pins who together should be relatively high
 * scoring.
 *
 * Args:
 *   ptable	posterior table
 *   optacc	"optimal" pairwise alignment 
 *   npins	how many pins do we want?
 *   ret_pins	set of pins to utilize
 *
 * Returns: number of pins 
 */
int 
alignPostBest(float **ptable, ALIGN *optacc, int npins, COORDS **ret_pins)
{
  COORDS *head;		/* List to return (pins) */
  COORDS *optlist;	/* Possible pins from alignment */
  COORDS *olist;	/* Ordered list */
  COORDS *cur;		/* Traversal placeholder */
  int i;

  if (align2pins(optacc, &optlist) < 0) return -1;
  scoreList(optlist, ptable);

  /* Order the list based on score */
  olist = (COORDS *)initCoordList();
  cur = optlist;
  while (cur->next != NULL) {
    cur = cur->next; 
    iCoordListS(olist, cur->posX, cur->posY, cur->score);
  }

  /* Build return list consisting of npins */
  head = (COORDS *)initCoordList();
  cur = olist; i = 0;
  while ((cur->next != NULL) && (i < npins)) {
    cur = cur->next;
    iCoordListX(head, cur->posX, cur->posY, cur->score);
    i++;
  }

  freeCoordList(optlist);
  freeCoordList(olist);
  *ret_pins = head;

  return i;
}

/* Function: alignSpaced 
 * Date: RDD, Sun Sep  5 18:36:04 CDT 2004 [St Louis]
 *
 * Purpose: Given an alignment, select npins 
 * 	where each pin "protects" a window of radius W
 *
 * Notes:
 *   Recall that alignment and sequence coordinates are
 *   not the same.  Well space therefore is defined as
 *   number of possible pins between selected pins.
 *
 * Args:
 *   galign	Given alignment (must choose pins from it)
 *   ptable	posterior table for scoring pins
 *   npins	Number of pins to select
 *   W		protection window size (radius)
 *   ret_pins	Pins selected
 *
 * Returns: number of pins 
 */
int
alignSpaced(ALIGN *galign, float **ptable, int npins, int W, COORDS **ret_pins)
{
  COORDS *glist;	/* Possible pins from alignment */
  COORDS *head;		/* Pins from alignment */
  COORDS *cur;		/* Pins from alignment */
  int cnt, n, window;
  int *Xlist, *Ylist;
  int i, xedge, yedge;

  window = 2 * W + 1;
  Xlist = (int *)malloc(sizeof(int) * window);
  Ylist = (int *)malloc(sizeof(int) * window);

  for (i = 0; i < window; i++) {
    Xlist[i] = Ylist[i] = 0;
  }

  n = align2pins(galign, &glist);
  scoreList(glist, ptable);

  head = (COORDS *)initCoordList();
  cnt = 0; 

  while ((glist->next != NULL) && (cnt < npins)) {
    /* Find best in list */
    cur = findBestList(glist);

    /* Count this as a pin */
    iCoordListX(head, cur->posX, cur->posY, cur->score);
    cnt++;

    xedge = cur->posX - W;
    yedge = cur->posY - W;
    for (i = 0; i < window; i++) {
      Xlist[i] = xedge++;
      Ylist[i] = yedge++;
    }

    /* Remove the protection set from the global list */
    for (i = 0; i < window; i++) {
      rmXList(glist, Xlist[i]);
    }
  }
  free(Xlist); free(Ylist);
  freeCoordList(glist);
  *ret_pins = head;
  return cnt;
}

/*************** Enforce a Quality Cutoff ********************/

/* Function: qualityPins 
 * Date:     RDD, Mon Oct 18 22:21:06 CDT 2004 [St Louis]
 *
 * Purpose:  find pins > edge in posteriors
 * 	considering only the path represented by 
 * 	a given alignment
 *
 * Args:
 *   ptable	posterior table
 *   optacc	"optimal" pairwise alignment 
 *   edge	Minimium posterior acceptable
 *   ret_pins	set of pins to utilize
 *
 * Returns: number of pins 
 */
int 
qualityPins(float **ptable, ALIGN *optacc, float edge, COORDS **ret_pins)
{
  COORDS *head;		/* List to return (pins) */
  COORDS *optlist;	/* Possible pins from alignment */
  COORDS *cur;		/* Traversal placeholder */
  int i;

  if (align2pins(optacc, &optlist) < 0) return -1;
  scoreList(optlist, ptable);

  /* Build return list consisting of pins 
   * with posterior >= edge */
  head = (COORDS *)initCoordList();
  cur = optlist; i = 0;
  while (cur->next != NULL) {
    cur = cur->next;
    if (cur->score >= edge) {
      iCoordListX(head, cur->posX, cur->posY, cur->score);
      i++;
    }
  }

  freeCoordList(optlist);
  *ret_pins = head;

  return i;
}
/* Function: qualitySpaced 
 * Date: Tue Apr 19 13:55:46 EDT 2005 [Somerville, MA]
 *
 * Purpose:  find pins > edge in posteriors
 * 	considering only the path represented by 
 * 	a given alignment but each pin "protects"
 * 	a region of radius W.
 *
 * Args:
 *   ptable	posterior table
 *   optacc	"optimal" pairwise alignment 
 *   edge	Minimium posterior acceptable
 *   W		protection window size (radius)
 *   ret_pins	set of pins to utilize
 *
 * Returns: number of pins 
 */
int 
qualitySpaced(float **ptable, ALIGN *optacc, float edge, int W, 
    COORDS **ret_pins)
{
  COORDS *glist;	/* Possible pins from alignment */
  COORDS *head;		/* Pins from alignment */
  COORDS *cur;		/* Pins from alignment */
  int cnt, n, window;
  int *Xlist, *Ylist;
  int i, xedge, yedge;

  window = 2 * W + 1;
  Xlist = (int *)malloc(sizeof(int) * window);
  Ylist = (int *)malloc(sizeof(int) * window);

  for (i = 0; i < window; i++) {
    Xlist[i] = Ylist[i] = 0;
  }

  n = qualityPins(ptable, optacc, edge, &glist);
  scoreList(glist, ptable);

  head = (COORDS *)initCoordList();
  cnt = 0; 

  while ((glist->next != NULL)) {
    /* Find best in list */
    cur = findBestList(glist);

    /* Count this as a pin */
    iCoordListX(head, cur->posX, cur->posY, cur->score);
    cnt++;

    xedge = cur->posX - W;
    yedge = cur->posY - W;
    for (i = 0; i < window; i++) {
      Xlist[i] = xedge++;
      Ylist[i] = yedge++;
    }

    /* Remove the protection set from the global list */
    for (i = 0; i < window; i++) {
      rmXList(glist, Xlist[i]);
    }
  }
  free(Xlist); free(Ylist);
  freeCoordList(glist);
  *ret_pins = head;
  return cnt;
}

/*************** Ignoring Opt Acc Alignment ********************/

/* Function: justBest 
 * Date:     Sun Oct  3 19:48:11 CDT 2004 [St Louis]
 *
 * Purpose:  find best pins in posteriors table
 *   (ignores optimal accuracy alignment)
 *
 * Args:
 *   ptable	posterior table
 *   columns	number of columns
 *   rows	number of rows 
 *   npins	how many pins do we want?
 *   ret_pins	set of pins to utilize
 *
 * Returns: number of pins built 
 */
int 
justBest(float **ptable, int columns, int rows, int npins, COORDS **ret_pins)
{
  COORDS *best, *head;
  COORDS *cur;
  int i;

  best = (COORDS *)initCoordList();
  buildBestSet(best, ptable, 0, columns-1, 0, rows-1);

  /* Build return list consisting of npins */
  head = (COORDS *)initCoordList();
  cur = best; i = 0;
  while ((cur->next != NULL) && (i < npins)) {
    cur = cur->next;
    iCoordListX(head, cur->posX, cur->posY, cur->score);
    i++;
  }

  freeCoordList(best);
  *ret_pins = head;

  return i;
}

/* Function: singleBest
 * Date:     RDD, Sat Jul 10 13:30:36 CDT 2004
 *
 * Purpose:  find single best pin within 
 * 	segment of the posterior table
 *
 * Note:
 * 	bias our selection towards a middle pin 
 * 	by taking the best pin with the smallest value
 * 	of |midX-idX|+|midY-idY|
 *
 *  COLMAX and COLMIN are precise edges (not typical C
 *  edge of len ... instead len-1).
 *
 * Args:
 *   ptable	posterior table
 *   colmin, colmax	Range of possible indicies in X
 *   rowmin, rowmax	Range of possible indicies in Y
 *   ret_pin	best pin found (allocated here, free elsewhere)
 *
 * Returns:  
 *    TRUE if no errors; FALSE if error enountered 
 */
int 
singleBest(float **ptable, int colmin, int colmax, 
    		int rowmin, int rowmax, COORDS **ret_pin)
{
  int i, j;
  float max, bscore;
  int jmax, imax;
  COORDS *best;
  int maxdist;
  int midX, midY;

  best = (COORDS *)initCoordList();

  /* Find single best pin */
  midX = (int)((rowmax-rowmin+1)/2);
  midY = (int)((colmax-colmin+1)/2);
  max = 0.0;
  for (i = rowmin; i <= rowmax; i++) {
    for (j = colmin; j <= colmax; j++) {
      if (ptable[i][j] > max) {
	max = ptable[i][j];
	bscore = max; jmax = j; imax = i; 
	maxdist = ABSDIST(midX, i) + ABSDIST(midY, j);
	/****************************************************** 
	 * In event of a tie, take the more middle biased pin 
	 ******************************************************/
      } else if (ptable[i][j] == max) {
	if ((ABSDIST(midX, i) + ABSDIST(midY, j)) < maxdist) {
	  max = ptable[i][j];
	  bscore = max; jmax = j; imax = i; 
	  maxdist = ABSDIST(midX, i) + ABSDIST(midY, j);
	}
      } /* ptable > max */
    } /* j */
  } /* i */
  iCoordListX(best, jmax, imax, bscore);

  *ret_pin = best;
  return 1;
}

/* Function: buildBestSet
 * Date: Sun Oct  3 19:55:06 CDT 2004 [St Louis]
 *
 * Purpose:  Recursively find best pins in 
 * 	current subsection of posterior table.
 *
 * Note:
 * 	OFTEN this returns the same answer as the
 * 	optimal accuracy alignment would.  But not
 * 	always.
 *
 * Args:
 *   head		list to build
 *   ptable		posterior table
 *   colmin, colmax	Range of possible indicies in X
 *   rowmin, rowmax	Range of possible indicies in Y
 *
 * Returns: --void--
 */
int
buildBestSet(COORDS *head, float **ptable, int colmin, int colmax, int rowmin, int rowmax)
{
  COORDS *best;

  if ((colmax < colmin) || (rowmax < rowmin)) return 0;

  singleBest(ptable, colmin, colmax, rowmin, rowmax, &best);
  iCoordListS(head, best->posX, best->posY, best->score);

  buildBestSet(head, ptable, colmin, (best->posX)-1, rowmin, (best->posY)-1);
  buildBestSet(head, ptable, (best->posX)+1, colmax, (best->posY)+1, rowmax);
  free(best);
  return 1;
}
