/* mltrain_main.c 
 * RDD, Thu Feb 27 16:27:27 CST 2003 [St Louis]
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"consan.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-g <string>   : Use grammar <string>, defaults to STA\n\
-s <file>     : save model file to <file>\n\
-x            : print out parameters of model \n\
-q            : print out counts used for model \n\
-t            : print traceback\n\
-d            : debugging output \n\
-v            : verbose output \n\
-n	      : Turn off weighting scheme\n\
-c	      : Force recalculate weights (defaults to given when available)\n\
-V	      : Use Voronoi weights instead of GSC \n\
-T <int>      : Setup Tying Type \n\
  	        [No tying = 0; NT counts = 1; Gap Open/Extend counts = 2; \n\
  		 Gap Open/Extend probs = 3; LR Symmetry 4 (default)]  \n\
";
static char usage[]  = "Usage: mltrain [-options] <training set files> \n";

void gatherCounts(PROBMOD *counts, char *filename, int grammar, OPTS settings);
int khs2count(PROBMOD *counts, MSA *msa, int i, int j, char *conss, 
      OPTS settings);

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;
  MODEL *scfg;
  FILE *ofp, *cfp;
  char cname[128];

  /**** parse arguments *****/
  if (!(processOpts(&settings, &optid, argc, argv, usage, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  /* Must have specified at least one training file */
  if (argc - optid < 1) 
	  Die("Incorrect number of command line arguments.\n%s\n%s\n",
			  usage, optsline);

  allocModel(&scfg); /* Check that grammar is set correctly */

  /* If training it must be probabilistic */
  if (settings.verbose)  {
      fprintf(settings.ofp, "Training, Grammar is %s\n", grNAME[scfg->grammar]);
      printOptions(stdout, &settings);
  }

  ZeroModel(scfg);
  /* Run through sequences in training files and gather counts */
  while (!(argc - optid < 1)) {
    printf("Training set %s\n", argv[optid]); fflush(stdout);
    gatherCounts(&(scfg->fmod), argv[optid], settings.grammar, settings);
    optid++;
  }

  if (settings.stockout) {
     printf("\n\nCOUNTS:\n");
     printModel(settings.ofp, PRINT_FLT, scfg); 
  }
  /* Convert counts into probabilities */
  ProbifySCFG(settings.grammar, &(scfg->fmod), NULL, settings.tie, &(scfg->fmod));
  LogifySCFG(settings.grammar, &(scfg->fmod), &(scfg->imod));

  if (settings.parameterout) { 
     printf("\n\nPARAMS:\n");
     printModel(settings.ofp, PRINT_BTH, scfg); 
     fflush(stdout);
  }

  /* If asked to save the model, do so now. */
  if (settings.savefile != NULL) {
    ofp = fopen(settings.savefile, "w");
    SaveSCFG(ofp, scfg);
    fclose(ofp);
  }

  /* Including this causes training on STA to segmentation fault */
  freeModel(scfg);
  return 1;
}

/* Function: gatherCounts
 * Date:     Fri Feb 28 13:37:21 CST 2003 [I-44 mile 302, OK]
 *
 * Purpose: Convert training sequences into counts
 *
 * Args:    
 *	 counts		integer form of model to keep counts
 *	 filename	training file name
 *	 grammar	which grammar to utilize
 *	 settings	command line options
 *
 * Returns:  nothing
 */
void
gatherCounts(PROBMOD *counts, char *filename, int grammar, OPTS settings)
{
  MSAFILE *sfp; MSA *msa;
  int ignored, total;
  int i,j;
  char *conss;

  ignored = 0; total = 0;
  if ((sfp = MSAFileOpen(filename, SQFILE_UNKNOWN, NULL)) == NULL)
    Die("Failed to open sequence file %s\n", filename);

  while ((msa = MSAFileRead(sfp)) != NULL) {
     standardizeMSA(msa);
     setupWeights(msa, settings);

     /* Ideally we'd like to use indivdual sequence structure
      * annotations, as these can be examined to determine the
      * best pairwise information.
      */
     if (msa->ss != NULL) {
	printf("Using individual sequence structures\n"); fflush(stdout);
	for (i = 0; i < (msa->nseq -1); i++) {
	   for (j = i+1; j < msa->nseq; j++) {
	      total ++;
	      calcConsStruct(msa->ss[i], msa->aseq[i], msa->ss[j], 
		    	msa->aseq[j], msa->alen, &conss);
	      if (!(khs2count(counts, msa, i, j, conss, settings))) 
		ignored ++;
	      free(conss);
	   }
	}
     /* Unforunately, individual data isn't always available and
      * in these cases sometimes we get a consensus structure.
      * Not as good, but will work.
      */
     } else if (msa->ss_cons != NULL) {
     	printf("Using consensus sequence structures\n"); fflush(stdout);
	/* For all possible pairs within each MSA */
	for (i = 0; i < (msa->nseq -1); i++) {
	   for (j = i+1; j < msa->nseq; j++) {
	      total ++;
	      if (!(khs2count(counts, msa, i, j, msa->ss_cons, settings))) 
		 ignored ++;
	   }
	}
     } else {
	Die("File %s contains no useable structure information!\n", filename);
     }

     MSAFree(msa);
  }
  if (settings.verbose) {
     printf("Training set contained %d sequences, %d ignored.\n", total, ignored);
     fflush(stdout);
  }
  MSAFileClose(sfp);
}

/* Function: khs2count
 *
 * Purpose: 
 *    Count a particular khs entry from a MSA.
 */
int
khs2count(PROBMOD *counts, MSA *msa, int i, int j, char *conss, OPTS settings)
{
   SEQPR *rnas;
   struct trace_s *trc;

   if (msa2seqpair(msa, i, j, conss, &rnas)) {
      if (settings.debugg) { printSeqPair(stdout, rnas); fflush(stdout);  }

      if (khs2trace(rnas->alignment->ss, rnas->alignment->alen, 
	       rnas->alignment->aseqs[SEQX], rnas->alignment->aseqs[SEQY], 
	       settings.grammar, &trc)) {
	 if (settings.traceback) printTrace(settings.ofp, trc, rnas);
	 if (settings.debugg) 
	   printf("Alignment Weight: %f\n", rnas->alignment->prwgt);
	 traceCount(rnas->alignment->prwgt, rnas->sequence[SEQX]->dseq,
	       rnas->sequence[SEQY]->dseq, trc, settings.grammar, counts);
         FreeTrace(trc);
      } else {
         printf("Failed khs2count's if within msa2seqpair \n"); fflush(stdout);
         freeSeqPair(rnas);
	 return 0;
      }
      freeSeqPair(rnas);
   } else {
      printf("Failed khs2count's msa2seqpair if\n");
      fflush(stdout);    
      return 0;
   }
   return 1;
}


