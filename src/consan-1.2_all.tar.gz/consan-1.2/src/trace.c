/* trace.c  -  support for traceback tree structure 
 *     (RNA structure representation)
 *
 * cove 1.0: SRE, Mon May 17 09:38:14 1993
 * modified for yarn, SRE, Sun Aug 28 10:01:42 1994
 * modified for conus, RDD, Tue Aug 21 14:35:19 CDT 2001
 * modified for sankoff, RDD, Sat Jan 25 19:35:02 CST 2003
 * 
 * The traceback of an SCFG-sequence alignment is an RNA structure,
 * which is kept as a tree of trace_s structures. Here
 * we provide support for the traceback data structures: the
 * tree itself, and a pushdown stack used for traversing the
 * tree.
 * 
 * The trace tree structure has a dummy node at its beginning
 * and dpcE END states at the leaves. Unlike COVE, these ends are
 * created by the functions that create traces, not maintained
 * automatically. Non-BIFURC states have a NULL right branch. 
 * 
 * The pushdown stack structure has a dummy begin node, and the
 * end is signified by a final NULL ptr.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "cfg.h"		
#include "consan.h"		
#include "alphabet.h"
#include "trace.h"

/* Function: traceCount 
 * Date:     Fri Mar  7 12:33:46 CST 2003 [St Louis]
 *
 * Purpose: Parse a traceback tree for counts (training).
 *
 * Args:     
 *
 * Returns:  
 */
void
traceCount(float wgt, char *dseqX, char *dseqY, struct trace_s *tr, 
      int grammar, PROBMOD *cfg)
{
  struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
  struct trace_s      *cur;     /* current node in the tree              */
  int leftX, leftY, rightX, rightY;
  int debug = FALSE;

  dolist = InitTracestack();
  PushTracestack(dolist, tr->nxtl);

  if (debug) {
     printf("We're here %f -- let's get this shit counted\n", wgt); 
     fflush(stdout); 
  }

  while ((cur = PopTracestack(dolist)) != NULL) {
     if (debug) {
	if (cur->emitLx != -1) 
	   leftX = dseqX[cur->emitLx]; else leftX = -1;
	if (cur->emitLy != -1) 
	   leftY = dseqY[cur->emitLy]; else leftY = -1;
	if (cur->emitRx != -1) 
	   rightX = dseqX[cur->emitRx]; else rightX = -1;
	if (cur->emitRy != -1) 
	   rightY = dseqY[cur->emitRy]; else rightY = -1;
	fprintf(stdout, "(%#12x) %2d  %5d  %5d  %5d  %5d  %3d  %#10x  %#10x  %2d \
	      %2d %2d %2d\n", (int) cur, cur->nonterminal,
	      cur->emitLx, cur->emitRx, cur->emitLy, cur->emitRy, cur->transition, 
	      (int) cur->nxtl, (int) cur->nxtr, leftX, rightX, leftY, rightY);
     }

     if (cur->transition < NTRANS) {

	cfg->transitions[cur->transition] += wgt;

	/* do nothing on ENDS */
	if (cur->nxtl == NULL) {
	   continue;
	}
	/* Non emitting states */
	else if ((cur->emitLx == -1) && (cur->emitRx == -1) &&
	      (cur->emitLy == -1) && (cur->emitRy == -1)) {
	   if (cur->nxtr != NULL) {	/* nxtr != NULL only on BIF */
	      PushTracestack(dolist, cur->nxtr);
	      PushTracestack(dolist, cur->nxtl);
	   } else {
	      PushTracestack(dolist, cur->nxtl);
	   }
	}
	else {
	      /* Emit to right */
	   if ((cur->emitLx == -1) && (cur->emitLy == -1)) {
	      if (cur->emitRx == -1) {	/* Ry */
		 if (dseqY[cur->emitRy] > ALPHA) {
	            /* Do nothing, contains an ambiguous base! */
	            cfg->transitions[cur->transition] -= wgt;
		 } else {
		    cfg->emissions[eSS((int)dseqY[cur->emitRy])] += wgt;
		 }
	      } else if (cur->emitRy == -1) { /* Rx */
		 if (dseqX[cur->emitRx] > ALPHA) {
	            /* Do nothing, contains an ambiguous base! */
		    cfg->transitions[cur->transition] -= wgt;
		 } else {
		    cfg->emissions[eSS((int)dseqX[cur->emitRx])] += wgt;
		 }
	      } else {
		 if ((dseqX[cur->emitRx] > ALPHA) ||
		       (dseqY[cur->emitRy] > ALPHA)) {
		    /* Do nothing, contains an ambiguous base! */
		    cfg->transitions[cur->transition] -= wgt;
		 } else {
		    cfg->emissions[eAL(dseqX[cur->emitRx],
			  dseqY[cur->emitRy])] += wgt;
		 }
	      }
	      /* Emit to left */
	   } else if ((cur->emitRx == -1) && (cur->emitRy == -1)) {
	      if (cur->emitLx == -1) { /* Ly */
		 if (dseqY[cur->emitLy] > ALPHA) {
		    /* Do nothing, contains an ambiguous base! */
		    cfg->transitions[cur->transition] -= wgt;
		 } else {
		    cfg->emissions[eSS((int)dseqY[cur->emitLy])] += wgt;
		 }
	      } else if (cur->emitLy == -1) { /* Lx */
		 if (dseqX[cur->emitLx] > ALPHA) {
		    /* Do nothing, contains an ambiguous base! */
		    cfg->transitions[cur->transition] -= wgt;
		 } else {
		    cfg->emissions[eSS((int)dseqX[cur->emitLx])] += wgt;
		 }
	      } else {
		 if ((dseqX[cur->emitLx] > ALPHA) ||
		       (dseqY[cur->emitLy] > ALPHA)) {
		    /* Do nothing, contains an ambiguous base! */
		    cfg->transitions[cur->transition] -= wgt;
		 } else {
		    cfg->emissions[eAL(dseqX[cur->emitLx],
			  dseqY[cur->emitLy])] += wgt;
		 }
	      }

	      /* Emit aligned pair */
	   } else {
	      if ((dseqX[cur->emitRx] > ALPHA) || (dseqX[cur->emitRx] < 0) || 
		    (dseqY[cur->emitRy] > ALPHA) || (dseqY[cur->emitRy] < 0) ||
		    (dseqX[cur->emitLx] > ALPHA) || (dseqX[cur->emitLx] < 0) || 
		    (dseqY[cur->emitLy] > ALPHA) || (dseqY[cur->emitLy] < 0)) {
		 /* Do nothing, contains an ambiguous or problematic base! */
		 cfg->transitions[cur->transition] -= wgt;
	      } else {
		 cfg->emissions[ePR(idx(dseqX[cur->emitLx], dseqX[cur->emitRx]),\
		       idx(dseqY[cur->emitLy], dseqY[cur->emitRy]))] += wgt;
	      }
	   }
	   if (cur->nxtr != NULL) {	/* nxtr != NULL only on BIF */
	      PushTracestack(dolist, cur->nxtr);
	      PushTracestack(dolist, cur->nxtl);
	   } else {
	      PushTracestack(dolist, cur->nxtl);
	   }
	}
     } else {
	if (cur->nxtr != NULL) {	/* nxtr != NULL only on BIF */
	   PushTracestack(dolist, cur->nxtr);
	   PushTracestack(dolist, cur->nxtl);
	} else {
	   PushTracestack(dolist, cur->nxtl);
	}
     }
  }
  FreeTracestack(dolist);
}

/* Function: traceScore 
 * Date:     Fri Feb 28 15:34:38 CST 2003 [Tulsa, OK]
 *
 * Purpose: Parse a traceback tree for 
 *	determining tracebcak score.
 *
 * Args:     
 *      seq   - sequence corresponding to the trace
 *      tr    - traceback to count
 *      cfg   - model, counts form, to add counts to
 *
 * Returns:  score of current traceback (in TraceScore mode)
 * 	Should return zero in TraceCount mode
 */
int
traceScore(SEQPR *seqs, struct trace_s *tr, INTMOD *cfg, int grammar)
{
  struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
  struct trace_s      *cur;     /* current node in the tree              */
  int score;
  int debug = FALSE;

  dolist = InitTracestack();
  PushTracestack(dolist, tr->nxtl);

  score = 0;  

  while ((cur = PopTracestack(dolist)) != NULL) {
     if (debug) fprintf(stdout, "(%#12x) %2d  %5d  %5d  %5d  %5d  %3d  %#10x  %#10x  \n", 
	   (int) cur, cur->nonterminal, cur->emitLx, cur->emitRx, 
	   cur->emitLy, cur->emitRy, cur->transition, 
	   (int) cur->nxtl, (int) cur->nxtr); fflush(stdout);
	   if (cur->transition < NTRANS) {

	      score += cfg->transitions[cur->transition];

	      /* do nothing on ENDS */
	      if (cur->nxtl == NULL) {
		 continue;
	      }
	      /* Non emitting states */
	      else if ((cur->emitLx == -1) && (cur->emitRx == -1) &&
		    (cur->emitLy == -1) && (cur->emitRy == -1)) {
		 if (cur->nxtr != NULL) {	/* nxtr != NULL only on BIF */
		    PushTracestack(dolist, cur->nxtr);
		    PushTracestack(dolist, cur->nxtl);
		 } else {
		    PushTracestack(dolist, cur->nxtl);
		 }
	      }
	      else {
		 if ((seqs->sequence[SEQX]->dseq[cur->emitLx] > ALPHA) || (seqs->sequence[SEQX]->dseq[cur->emitRx] > ALPHA) ||
		       (seqs->sequence[SEQY]->dseq[cur->emitLy] > ALPHA) || (seqs->sequence[SEQY]->dseq[cur->emitRy] > ALPHA)) {
		    /* Do nothing, contains an ambiguous base! */

		    /* Emit to right */
		 } else if ((cur->emitLx == -1) && (cur->emitLy == -1)) {
		    if (cur->emitRx == -1) {	/* Ry */
		       score += cfg->emissions[eSS((int)seqs->sequence[SEQY]->dseq[cur->emitRy])];
		    } else if (cur->emitRy == -1) { /* Rx */
		       score += cfg->emissions[eSS((int)seqs->sequence[SEQX]->dseq[cur->emitRx])];
		    } else {
		       score +=  cfg->emissions[eAL(seqs->sequence[SEQX]->dseq[cur->emitRx],seqs->sequence[SEQY]->dseq[cur->emitRy])];
		    }
		    /* Emit to left */
		 } else if ((cur->emitRx == -1) && (cur->emitRy == -1)) {
		    if (cur->emitLx == -1) { /* Ly */
		       score += cfg->emissions[eSS((int)seqs->sequence[SEQY]->dseq[cur->emitLy])];
		    } else if (cur->emitLx == -1) { /* Lx */
		       score += cfg->emissions[eSS((int)seqs->sequence[SEQX]->dseq[cur->emitLx])];
		    } else {
		       score +=  cfg->emissions[eAL(seqs->sequence[SEQX]->dseq[cur->emitLx],seqs->sequence[SEQY]->dseq[cur->emitLy])];
		    }

		    /* Emit aligned pair */
		 } else {
		    score += 
		       cfg->emissions[ePR(idx(seqs->sequence[SEQX]->dseq[cur->emitLx],seqs->sequence[SEQX]->dseq[cur->emitRx]),\
			     idx(seqs->sequence[SEQY]->dseq[cur->emitLy],seqs->sequence[SEQY]->dseq[cur->emitRy]))];
		 }
		 if (cur->nxtr != NULL) {	/* nxtr != NULL only on BIF */
		    PushTracestack(dolist, cur->nxtr);
		    PushTracestack(dolist, cur->nxtl);
		 } else {
		   PushTracestack(dolist, cur->nxtl);
		 }

	      }
	   } else {
	     if (cur->nxtr != NULL) {	/* nxtr != NULL only on BIF */
	       PushTracestack(dolist, cur->nxtr);
	       PushTracestack(dolist, cur->nxtl);
	     } else {
	       PushTracestack(dolist, cur->nxtl);
	     }

	   }
  }
  FreeTracestack(dolist);
  return score;
}

/* Function: trace2alignment()
 *  
 * Purpose:  From a traceback tree of seq, produce a
 * 	secondary structure string. ">" and "<" are
 * 	used for pairwise emissions; "." for single-stranded stuff.
 * 	Note that structure is defined by pairwise emissions,
 * 	not by Watson-Crick-isms and stacking rules.
 *        
 * Args:     tr          - traceback structure
 * 	     seqs	 - sequence pair 
 *           
 * Return:   seqs->ss contains a string 0..rlen-1 containing the
 *           secondary structure. seqs->aseqs contain the alignment
 *           strings.  Must be free'd by caller.
 */
  void
trace2alignment(struct trace_s *tr, SEQPR *seqs, ALIGN **align)
{
  struct tracestack_s *dolist;
  struct trace_s      *curr;
  int	rlen;
  int  curX, gi, goingdown;
  ALIGN *alignment;

  /* Laborious way to figure out the alignment length, but it works */
  rlen = 0;
  dolist = (struct tracestack_s *)InitTracestack();
  PushTracestack(dolist, tr->nxtl);
  while ((curr = PopTracestack(dolist)) != NULL) { 
    if ((curr->emitLx >= 0) && (curr->emitRx >= 0) &&
	(curr->emitLy >= 0) && (curr->emitRy >= 0)) {
      /* Emit pair */
      rlen += 2;
    } else if ((curr->emitLx < 0) && (curr->emitRx < 0) &&
	(curr->emitLy < 0) && (curr->emitRy < 0)) {
      /* Non emitting state*/
    } else {
      rlen += 1;
    }

    if (curr->nxtr) PushTracestack(dolist, curr->nxtr);
    if (curr->nxtl) PushTracestack(dolist, curr->nxtl);
  }
  FreeTracestack(dolist);
  allocAlignment(rlen, 1.0, &alignment);
  /*******************************************************************/

  /* Build the alignment strings */
  gi = 0; curX = 0;
  dolist = (struct tracestack_s *)InitTracestack();
  PushTracestack(dolist, tr->nxtl);
  goingdown = TRUE; 
  /* Ok, we've got a full traceback tree and need to do a 
   * depth first style traversal, emitting on the left as we
   * head down and on the right as we come back up.  This is
   * reading the sequence from a parse tree. */
  while ((curr = PopTracestack(dolist)) != NULL) { 
    if (goingdown) {
      /* Note that if it's a bif state (nxtr != NULL) then we don't emit
       * while going down -- since emissions are attached to the left P */
      if ((curr->nxtr == NULL) && ((curr->emitLx >= 0) || (curr->emitLy >= 0))) {
	/* Emit Left */
	if (curr->emitLx >= 0) {
	  alignment->aseqs[SEQX][gi] = seqs->sequence[SEQX]->seq[curr->emitLx];
	  if (seqs->c_info != NULL) 
	    if (seqs->c_info->isXconstraint[curX]) alignment->pins[gi] = '*';
	  curX++;
	}
	if (curr->emitLy >= 0) 
	  alignment->aseqs[SEQY][gi] = seqs->sequence[SEQY]->seq[curr->emitLy];
	if ((curr->emitLx >= 0) && (curr->emitLy >= 0) && 
	    (curr->emitRx >= 0) && (curr->emitRy >= 0)) 
	  alignment->ss[gi] = '>';
	gi++;
      }
      if (curr->nxtl == NULL) {	/* This is an end state */
	goingdown = FALSE;
	PushTracestack(dolist, curr->prv);
      } else {
	/* if (curr->nxtr) PushTracestack(dolist, curr->nxtr); */
	if (curr->nxtl) PushTracestack(dolist, curr->nxtl);
      }
    } else {
      /* When coming back up, we deal with bifs (nxtr != NULL) separately */
      if ((curr->nxtr == NULL) && ((curr->emitRx >= 0) || (curr->emitRy >= 0))) {
	/* Emit Right */
	if (curr->emitRx >= 0) {
	  alignment->aseqs[SEQX][gi] = seqs->sequence[SEQX]->seq[curr->emitRx];
	  if (seqs->c_info != NULL) 
	    if (seqs->c_info->isXconstraint[curX]) alignment->pins[gi] = '*';
	  curX++;
	}
	if (curr->emitRy >= 0) 
	  alignment->aseqs[SEQY][gi] = seqs->sequence[SEQY]->seq[curr->emitRy];
	if ((curr->emitLx >= 0) && (curr->emitLy >= 0) && 
	    (curr->emitRx >= 0) && (curr->emitRy >= 0)) 
	  alignment->ss[gi] = '<';
	gi++;
      }
      /* Ok -- time to handle the messy bifurcation states! */
      if (curr->nxtr != NULL) {
	/* When we hit the bifurcation going up the left, we're handling 
	 * the pair emission's LEFT state */
	if (curr->emitRx > curX) {
	  goingdown = TRUE;
	  alignment->aseqs[SEQX][gi] = seqs->sequence[SEQX]->seq[curr->emitLx];
	  alignment->aseqs[SEQY][gi] = seqs->sequence[SEQY]->seq[curr->emitLy];
	  alignment->ss[gi] = '>';
	  PushTracestack(dolist, curr->nxtr); 
	  /* When we hit the bifurcation going up the right, we're handling 
	   * the pair emission's RIGHT state */
	} else {
	  /* goingdown remains FALSE */
	  alignment->aseqs[SEQX][gi] = seqs->sequence[SEQX]->seq[curr->emitRx];
	  alignment->aseqs[SEQY][gi] = seqs->sequence[SEQY]->seq[curr->emitRy];
	  alignment->ss[gi] = '<';
	  PushTracestack(dolist, curr->prv);
	}
	if (seqs->c_info != NULL) 
	  if (seqs->c_info->isXconstraint[curX]) alignment->pins[gi] = '*';
	curX++; gi++;
       } else {
	 PushTracestack(dolist, curr->prv);
       }
    }
  }
  FreeTracestack(dolist);
  alignID(alignment);
  *align = alignment;
}


/* Function: InitTrace()
 * 
 * Purpose:  Initialize a traceback tree structure.
 *
 * Return:   ptr to the new tree.
 */          
struct trace_s *
InitTrace(void)
{
  struct trace_s *new;

  if ((new = (struct trace_s *) malloc (sizeof(struct trace_s))) == NULL)
    Die("Memory allocation failure at %s line %d", __FILE__, __LINE__);

  new->emitl = -1;
  new->emitr = -1;

  new->emitLx = -1;
  new->emitLy = -1;
  new->emitRx = -1;
  new->emitRy = -1;

  new->nonterminal = -1;
  new->transition = -1;

  new->nxtl  = NULL;
  new->nxtr  = NULL;
  new->prv   = NULL;
  return new;
}

/* Function: AttachTrace()
 * 
 * Purpose:  attach a new node to a tracetree node.
 *           
 *           Because of the mechanics of tracebacks through a Viterbi matrix,
 *           we have to make sure that BIFURC children are attached
 *           right first, left second.
 *           
 *           This version assumes a single set of 
 *           coordinates -- a per sequence set.
 *
 * Returns:  ptr to the new node, or NULL on failure.
 */          
struct trace_s *
AttachTrace(struct trace_s *parent,
	    int             nonterminal,
	    int             emitLx,
	    int             emitRx,
	    int             emitLy,
	    int             emitRy,
	    int             transition)
{
  struct trace_s *new;

  if (parent->nxtr != NULL)
    Die("That trace node is already full, fool.");

  /* If left branch is already connected to something, swap it over to the
   * right (thus enforcing the necessary rule that BIFURCS attach to the right
   * branch first), and attach a new dummy end to the left branch. 
   */
  if (parent->nxtl != NULL)
    {
      parent->nxtr = parent->nxtl;
      parent->nxtl = NULL;
    }

  if ((new = (struct trace_s *) malloc (sizeof(struct trace_s))) == NULL)
    Die("Memory allocation failure at %s line %d", __FILE__, __LINE__);
  new->nxtr    = NULL;
  new->nxtl    = NULL;
  new->prv     = parent;
  new->emitl	= -1;
  new->emitr	= -1;
  new->emitLx   = emitLx;
  new->emitLy   = emitLy;
  new->emitRx   = emitRx;
  new->emitRy   = emitRy;
  new->nonterminal = nonterminal;
  new->transition = transition;
  parent->nxtl = new;

  return new;
}

/* Function: AttachATrace()
 * 
 * Purpose:  attach a new node to a tracetree node.
 *           
 *           Because of the mechanics of tracebacks through a Viterbi matrix,
 *           we have to make sure that BIFURC children are attached
 *           right first, left second.
 *
 *           This version assumes that you have two sets of 
 *           coordinates -- an alignment set AND a per sequence set.
 *           
 * Returns:  ptr to the new node, or NULL on failure.
 */    
struct trace_s *
AttachATrace(struct trace_s *parent,
	    int             nonterminal,
	    int		    emitl,
            int		    emitr,
	    int             emitLx,
	    int             emitRx,
	    int             emitLy,
	    int             emitRy,
	    int             transition)
{
  struct trace_s *new;

  if (parent->nxtr != NULL)
    Die("That trace node is already full, fool.");

  /* If left branch is already connected to something, swap it over to the
   * right (thus enforcing the necessary rule that BIFURCS attach to the right
   * branch first), and attach a new dummy end to the left branch. 
   */
  if (parent->nxtl != NULL)
    {
      parent->nxtr = parent->nxtl;
      parent->nxtl = NULL;
    }

  if ((new = (struct trace_s *) malloc (sizeof(struct trace_s))) == NULL)
    Die("Memory allocation failure at %s line %d", __FILE__, __LINE__);
  new->nxtr    = NULL;
  new->nxtl    = NULL;
  new->prv     = parent;
  new->emitl	= emitl;
  new->emitr	= emitr;
  new->emitLx   = emitLx;
  new->emitLy   = emitLy;
  new->emitRx   = emitRx;
  new->emitRy   = emitRy;
  new->nonterminal = nonterminal;
  new->transition = transition;
  parent->nxtl = new;

  return new;
}

void
FreeTrace(struct trace_s *tr)
{
  struct tracestack_s *stack;
  struct trace_s      *currtr;

  stack = InitTracestack();
  PushTracestack(stack, tr);

  while ((currtr = PopTracestack(stack)) != NULL)
    {
      if (currtr->nxtr != NULL)
	PushTracestack(stack, currtr->nxtr);
      if (currtr->nxtl != NULL)
	PushTracestack(stack, currtr->nxtl);
      free(currtr);
    }
  FreeTracestack(stack);
}


/* Functions: InitTracestack()
 *            PushTracestack()
 *            PopTracestack()
 *            FreeTracestack()
 *            
 * Purpose:   Implementation of the pushdown stack for
 *            traversing traceback trees.
 */            
struct tracestack_s *
InitTracestack(void)
{
  struct tracestack_s *stack;

  if ((stack = (struct tracestack_s *) malloc (sizeof(struct tracestack_s))) == NULL)
    Die("Memory allocation failure at %s line %d", __FILE__, __LINE__);
  stack->nxt = NULL;
  return stack;
}

void 
PushTracestack(struct tracestack_s *stack,
	       struct trace_s      *tracenode)
{
  struct tracestack_s *new;

  if ((new = (struct tracestack_s *) malloc (sizeof(struct tracestack_s))) == NULL)
    Die("Memory allocation failure at %s line %d", __FILE__, __LINE__);
  new->node = tracenode;

  new->nxt = stack->nxt;
  stack->nxt = new;
}

struct trace_s *
PopTracestack(struct tracestack_s *stack)
{
  struct trace_s *node;
  struct tracestack_s *old;

  if (stack->nxt == NULL)
    return NULL;

  old = stack->nxt;
  stack->nxt = old->nxt;

  node = old->node;
  free(old);
  return node;
}
void
FreeTracestack(struct tracestack_s *stack)
{
  while (PopTracestack(stack) != NULL)
    ;
  free(stack);
}


/* Function: printTrace()
 * 
 * Purpose:  Debugging tool. Print a traceback tree.
 */
void
printTrace(FILE *fp, struct trace_s *tr, SEQPR *seqs)
{
  struct tracestack_s *stack;
  struct trace_s      *currtr;
  char leftX, leftY, rightX, rightY;

  if (tr == NULL) {
    printf("No traceback available!\n");
    return;
  }
  stack = InitTracestack();
  PushTracestack(stack, tr->nxtl);
  
  fprintf(fp, "(  address   ) dp  emitLx emitRx emitLy emitRy type    nxtl        nxtr      i  j  k  l \n");

  while ((currtr = PopTracestack(stack)) != NULL)
    {
      if (currtr->emitLx != -1) 
	 leftX = seqs->sequence[SEQX]->seq[currtr->emitLx]; else leftX = 'z';
      if (currtr->emitLy != -1) 
	 leftY = seqs->sequence[SEQY]->seq[currtr->emitLy]; else leftY = 'z';
      if (currtr->emitRx != -1) 
	 rightX = seqs->sequence[SEQX]->seq[currtr->emitRx]; else rightX = 'z';
      if (currtr->emitRy != -1) 
	 rightY = seqs->sequence[SEQY]->seq[currtr->emitRy]; else rightY = 'z';
   
      fprintf(fp, "(%#12x) %2d  %5d  %5d  %5d  %5d  %3d  %#10x  %#10x  %2c %2c %2c %2c\n", 
	     (int) currtr, currtr->nonterminal,
	     currtr->emitLx, currtr->emitRx, currtr->emitLy, currtr->emitRy, 
	     currtr->transition, 
	     (int) currtr->nxtl, (int) currtr->nxtr, leftX, rightX, leftY, rightY);
      if (currtr->nxtr != NULL)
	PushTracestack(stack, currtr->nxtr);
      if (currtr->nxtl != NULL)
	PushTracestack(stack, currtr->nxtl);
    }
  FreeTracestack(stack);
}

void
printTraceGC(FILE *fp, struct trace_s *tr)
{
  struct tracestack_s *stack;
  struct trace_s      *currtr;

  if (tr == NULL) {
    printf("No traceback available!\n");
    return;
  }
  stack = InitTracestack();
  PushTracestack(stack, tr->nxtl);
  
  fprintf(fp, "(  address   ) dp  coordL coordR type    nxtl        nxtr      \n");

  while ((currtr = PopTracestack(stack)) != NULL)
    {
      fprintf(fp, "(%#12x) %2d  %5d  %5d  %3d  %#10x  %#10x  \n", 
	     (int) currtr, currtr->nonterminal, currtr->emitl, currtr->emitr, 
	     currtr->transition, (int) currtr->nxtl, (int) currtr->nxtr);
      if (currtr->nxtr != NULL)
	PushTracestack(stack, currtr->nxtr);
      if (currtr->nxtl != NULL)
	PushTracestack(stack, currtr->nxtl);
    }
  FreeTracestack(stack);
}

/* Function: compareTrace()
 * 
 * Purpose:  Debugging tool. 
 *   Determine if two traceback trees are identical.
 */
int
compareTrace(struct trace_s *tr1, struct trace_s *tr2)
{
  struct tracestack_s *stack1;
  struct tracestack_s *stack2;
  struct trace_s      *curtr1;
  struct trace_s      *curtr2;

  if ((tr1 == NULL) || (tr2 == NULL)) {
    printf("Traceback must be available!!\n");
    return 0;
  }

  /* Setup stacks for traversing both traceback trees */
  stack1 = InitTracestack();
  PushTracestack(stack1, tr1->nxtl);
  stack2 = InitTracestack();
  PushTracestack(stack2, tr2->nxtl);
  
  while ((curtr1 = PopTracestack(stack1)) != NULL)
    {
      if ((curtr2 = PopTracestack(stack2)) == NULL)
         return 0;	/* Not same sized tree */
      
      if (curtr1->nonterminal != curtr2->nonterminal) {
         return 0;
      }
      if (curtr1->transition != curtr2->transition) {
         return 0;
      }
      if (curtr1->emitLx != curtr2->emitLx) {
         return 0;
      }
      if (curtr1->emitLy != curtr2->emitLy) {
         return 0;
      }
      if (curtr1->emitRx != curtr2->emitRx) {
         return 0;
      }
      if (curtr1->emitRy != curtr2->emitRy) {
         return 0;
      }
   
      if (curtr1->nxtr != NULL)
	PushTracestack(stack1, curtr1->nxtr);
      if (curtr1->nxtl != NULL)
	PushTracestack(stack1, curtr1->nxtl);
      if (curtr2->nxtr != NULL)
	PushTracestack(stack2, curtr2->nxtr);
      if (curtr2->nxtl != NULL)
	PushTracestack(stack2, curtr2->nxtl);


    }
  FreeTracestack(stack1);
  FreeTracestack(stack2);

  return 1;
}


