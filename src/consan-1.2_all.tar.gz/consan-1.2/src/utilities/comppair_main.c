/* comppair_main.c 
 * RDD, Wed Jun 23 15:04:27 CDT 2004 [St Louis]
 *
 * This is modeled after compalign and compstruct in squid.
 * The difference is that here we want to do BOTH.
 * Given a structural alignment we can calculate up to 4 sets:
 * 	- compalign of alignments
 * 	- compstruct of sequence X structures
 * 	- compstruct of sequence Y structures
 * 	- compstruct of consensus structures
 *
 * Note that for an X or Y structure comparisons we need a given
 * structure for the sequence and the structure implied by the
 * consensus predicted structure.  We could either expect the 
 * individual structure to be given (best case) or imposed from a
 * consensus.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../consan.h"
#include"../version.h"
#include"../trace.h"
#include"../alphabet.h"
#include"../options.h"
#include"../stats.h"
#include"../cyk.h"

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-S	      : suppress comparison totals \n\
-q	      : suppress every pair alignment prediction output \n\
-M 1	      : turn on Mathews definition of paired \n\
";
static char usage[]  = "Usage: comppair [-options] <seqfile in>\n";

#define TWOGIVEN	1
#define KGIVEN		2
#define TGIVEN		3
#define CONSENSUS 	4
#define STRTYPES	5

char *strTYPE[STRTYPES] = { "ERROR", "Given", "Given(ref) vs Cons", 
  		"Cons(ref) vs Given", "Consensus" }; 

int compStrWIalign(MSA *kmsa, MSA *tmsa, int idx, STATS *stats, int domathews);
extern float CompPairAlignments(char *known1, char *known2, char *calc1, char *calc2, int *ret_id, int *ret_tot);

  int 
main (int argc, char **argv) 
{
  char  *kfile;                 /* name of file of trusted (known) alignment */
  char  *tfile;                 /* name of file of test alignment            */
  MSAFILE *kfp;                 /* open ptr into trusted (known) alignfile   */
  MSAFILE *tfp;                 /* open ptr into test alignment file         */
  int    format;                /* expected format of alignment files        */
  MSA   *kmsa;                  /* a trusted (known) alignment               */
  MSA   *tmsa;                  /* a test alignment                          */
  float  score, cval;           /* RESULT: score for seq & struct compare    */ 
  float gscore;			/* Cummulative score for seq comparisons     */
  int npairs;			/* Number of pairs considered */

  int   optid;
  OPTS settings;
  int comptype;
  STATS xstat, ystat, pstats, gstats;
  int id, tot, Tid, Ttot;
  ALIGN *known;

  if (!(processOpts(&settings, &optid, argc, argv, usage, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  if (argc - optid != 2)
    Die("Incorrect number of command line arguments.\n%s\n", usage);

  /* Digitize Sequences */
  SetAlphabet(hmmNUCLEIC);

  format   = MSAFILE_UNKNOWN;
  kfile = argv[optid++];
  tfile = argv[optid];

  /* READ IN ALIGNMENTS */
  if ((kfp = MSAFileOpen(kfile, format, NULL)) == NULL)
    Die("Trusted alignment file %s could not be opened for reading", kfile);
  if ((tfp = MSAFileOpen(tfile, format, NULL)) == NULL)
    Die("Test alignment file %s could not be opened for reading", tfile);

  if (!settings.stockout) {
    printf("\nTrusted :   %s \t", kfile);
    printf("Test :      %s\n", tfile);
  }

  gscore = 0.0; npairs = 0; Tid = 0; Ttot = 0;
  ZeroStats(&gstats);  

  while ((kmsa = MSAFileRead(kfp)) != NULL)
  {
    if ((tmsa = MSAFileRead(tfp)) == NULL)
      Die("Failed test alignment match with the trusted alignment");

    msa2pairwise(kmsa->alen, NULL, kmsa->aseq[0], kmsa->aseq[1], 1.0, &known);

    if (testAlignPairs (kmsa, tmsa)) {
      id = tot = 0;
      /* Note that we're assuming pairwise alignments */
      score = CompPairAlignments(kmsa->aseq[0], kmsa->aseq[1], tmsa->aseq[0], 
	  tmsa->aseq[1], &id, &tot); 

      if (!settings.stockout) {
	printf("Alignment %s vs %s (Given per. id: %2.4f)\n", 
	    kmsa->sqname[SEQX], kmsa->sqname[SEQY], known->aliid);
	printf("Correctly predicted Symbols: %d/%d %4.2f percent\n\n", id, tot, score);
      }
      gscore += score; Tid += id;  Ttot += tot;
      npairs++;
    } 

    /***********************************************
     * Compare the structures, print results
     ***********************************************/
    ZeroStats(&xstat);  ZeroStats(&ystat);
    ZeroStats(&pstats);  

    comptype = compStrWIalign(kmsa, tmsa, SEQX, &xstat, settings.mset);
    printf("SEQX: %s (%s)\n", kmsa->sqname[SEQX], strTYPE[comptype]);
    PrintTotals(&xstat, FALSE, TRUE);
    accumulateStats(&xstat, &gstats);
    accumulateStats(&xstat, &pstats);

    comptype = compStrWIalign(kmsa, tmsa, SEQY, &ystat, settings.mset); 
    printf("SEQY: %s (%s)\n", kmsa->sqname[SEQY], strTYPE[comptype]);
    PrintTotals(&ystat, FALSE, TRUE); 
    accumulateStats(&ystat, &gstats);
    accumulateStats(&ystat, &pstats);

    if (!settings.suppress) {
      printf("PAIR TOTALS:\n");
      cval = PrintTotals(&pstats, FALSE, TRUE); 
    }
    freeAlignment(known);

    MSAFree(kmsa);
    MSAFree(tmsa);
  }
  MSAFileClose(kfp);
  MSAFileClose(tfp);

  if (!settings.suppress) {
    printf("=============== TOTALS ==============\n");
    printf("Trusted :   %s \t", kfile);
    printf("Test :      %s\n", tfile);
    printf("Average Alignment Identity: %f\n", gscore/npairs);
    printf("Cummulative Alignment Identity: %f\n", (((float)Tid/(float)Ttot)));
    cval = PrintTotals(&gstats, TRUE, TRUE);
  }
  return 0;
}

/* Function: compStrWIalign
 * Date: Fri Jun 25 13:27:58 CDT 2004 [St Louis]
 *
 * Purpose: Compare the structures between two 
 * 	identical sequences in two alignments.
 *
 * Assumption: Checks to verify sequences are under same
 *   idx are done elsewhere.
 *
 * NOTE: To be fully general, we've got to accept the possibility
 * that both sequences will specify the structure of each sequence.
 * For our purposes, we expect one (known) to be specified
 * and the other to just give a consensus.
 *
 * Arguments: kmsa	MSA of known alignment
 * 	      tmsa	MSA of test alignment
 * 	      idx	subsequences to compare
 * 	      stats	statistics to generate
 *
 * Returns: 
 * 	FALSE if comparison fails (structure info unavailable)
 * 	Otherwise return a comparison type code:
 * 	  (TWOGIVEN, KGIVEN, TGIVEN, CONSENSUS)
 */
int
compStrWIalign(MSA *kmsa, MSA *tmsa, int idx, STATS *stats,
    int domathews) 
{
  char *kss, *tss;		/* secondary structure info */

  if ((kss = MSAGetSeqSS(kmsa, idx)) != NULL) {
    if ((tss = MSAGetSeqSS(tmsa, idx)) != NULL) {
      /* We have sequence specific structure for both */
      MakeDealignedString(kmsa->aseq[idx], kmsa->alen, kmsa->ss[idx], &kss);
      MakeDealignedString(tmsa->aseq[idx], tmsa->alen, tmsa->ss[idx], &tss);
      CompStruct(kmsa->alen, kss, tss, stats, FALSE, domathews, FALSE);
      return TWOGIVEN;
    } else {
      /* We have sequence specific structure for known 
       * but must use consensus info for test */
      if (tmsa->ss_cons == NULL) return 0;
      /* We've got to dealign k as well because otherwise their coordinates
       * don't match up (kss would be alignment coordinates and tss would be
       * dealigned.  We can reference kmsa->ss[idx] directly because to have 
       * gotten here the MSAGetSeqSS for kmsa had to have passed already */
      MakeDealignedString(kmsa->aseq[idx], kmsa->alen, kmsa->ss[idx], &kss);
      MakeDealignedString(tmsa->aseq[idx], tmsa->alen, tmsa->ss_cons, &tss);
      CompStruct(strlen(kss), kss, tss, stats, FALSE, domathews, FALSE);
      free(tss); free(kss); 
      return KGIVEN;
    }
  } else {	/* Need to use consensus for SEQX */
    if ((tss = MSAGetSeqSS(tmsa, idx)) != NULL) {
      /* We have sequence specific structure for test  
       * but must use consensus info for known */
      if (kmsa->ss_cons == NULL) return 0;
      MakeDealignedString(kmsa->aseq[idx], kmsa->alen, kmsa->ss_cons, &kss);
      /* As with kss above, we've got to dealign tss here to put it on same
       * coordinate system as kss.  We can ref tmsa->ss[idx] directly because
       * to get here it would have already had to have passed MSAGetSeqSS */
      MakeDealignedString(tmsa->aseq[idx], tmsa->alen, tmsa->ss[idx], &tss);
      CompStruct(strlen(kss), kss, tss, stats, FALSE, domathews, FALSE);
      free(kss); free(tss);
      return TGIVEN;
    } else {
      /* We have to use consensus structure for both */
      if (kmsa->ss_cons == NULL) return 0;
      if (tmsa->ss_cons == NULL) return 0;
      MakeDealignedString(kmsa->aseq[idx], kmsa->alen, kmsa->ss_cons, &kss);
      MakeDealignedString(tmsa->aseq[idx], tmsa->alen, tmsa->ss_cons, &tss);
      CompStruct(strlen(kss), kss, tss, stats, FALSE, domathews, FALSE);
      free(kss);  free(tss);
      return CONSENSUS;
    }
  }
}
 
