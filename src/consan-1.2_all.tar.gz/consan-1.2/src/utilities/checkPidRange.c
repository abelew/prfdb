/* checkPidRange.c 
 * Sat Oct 15 12:35:18 EDT 2005 [Boston]
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<time.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../consan.h"
#include"../options.h"

static char optsline[]  = "\
Confirm that a percid pair exists for all sequences\n\
-h      	: print short help and usage info\n\
-v      	: verbose information \n\
-M <int>	: set lower bound\n\ 
-W <int>	: set upper bound\n\ 
";
static char usage[]  = "Usage: checkPid [-options] <msa> \n";

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;
  MSAFILE *sfp;  MSA *msa;	/* Handles for current MSA */
  float **imx;
  int found, bad;
  int i,j;
  float upper, lower;

  /**** parse arguments *****/
  if (!(processOpts(&settings, &optid, argc, argv, usage, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  /* Must have specified at least one test file */
  if (argc - optid < 1) 
	  Die("Incorrect number of command line arguments.\n%s\n%s\n",
			  usage, optsline);

  /* Default edges of range */
  if (!settings.mset) { lower = .40; } 
  else { lower = ((float)settings.Moption/100); }
  if (!settings.wset) { upper = .90; } 
  else { upper = ((float)settings.Woption/100); }

  if (settings.debugg) 
    printf("Range to check %1.2f - %1.2f \n", lower, upper);

  /* For each test file */
  while (!(argc - optid < 1)) {
     if (settings.debugg) printf("Test set %s\n", argv[optid]); fflush(stdout);

     if ((sfp = MSAFileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL)
	Die("Failed to open sequence file %s\n", argv[optid]);

     /* For each MSA in the current file */
     while ((msa = MSAFileRead(sfp)) != NULL) {
       standardizeMSA(msa);
       MakeIdentityMx(msa->aseq, msa->nseq, &imx); 
       bad = 0;

       if (msa->nseq > 1) {
	 for (i = 0; i < msa->nseq; i++) {
	   found = 0;
	   for (j = 0; j < msa->nseq; j++) {
	     if (i != j) {
	       if ((imx[i][j] <= upper) && (imx[i][j] >= lower)) {
		 j = msa->nseq; /* short circuit */
		 found = 1;
	       }
	     }
	   }
	   if (!found) { 
	     bad++; 
	     if ((settings.verbose) || (settings.debugg)) {
	       printf("%d %s has no pairs in range.\n", i, msa->sqname[i]);
	     }
	     if (settings.verbose) {
	       for (j = 0; j < msa->nseq; j++) {
		 printf("%1.4f\n", imx[i][j]);
	       }
	     }
	   }
	 }
       }

       if (bad > 0) {
	 printf("Of %d Sequences in %s MSA, %d were out of range.\n",
	     msa->nseq, argv[optid], bad);
       } 
       MSAFree(msa);
     } /* for all MSA in this file */
     MSAFileClose(sfp);
     optid++;
  } /* for all files */
  return 0;
}
