/* test.c */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<math.h>

#include"squid.h"
#include"sqfuncs.h"

#include"../cfg.h"
#include"../consan.h"
#include"../dps.h"
#include"../version.h"
#include"../alphabet.h"
#include"../options.h"

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-f	      : Use length as inputs rather than sequences \n\
  			memtest -f XX XX\n\
-q            : Use single sequence inputs (like sfold)\n\
		memtest -q <seq in> <seq in> [constraints] \n\
-C <int>      : do CYK and use <int> pins from trusted alignment \n\
-P <int>      : do CYK and use <int> predicted pins  \n\
	Note that we do not include in memory estimate the cost \n\
	of generating the posteriors, as they are external \n\
-d	      : Output debugging information \n\
";

static char usage[] = 
	"Usage: memtest [-options] <seqfile in> <seqfile in> [constraints] \n";

extern int msa2seqpair(MSA *msa, int i, int j, char *conss, SEQPR **rnas);

int 
main (int argc, char **argv) 
{
   /**** arguments variables *****/
   int   optid; 
   OPTS  settings;
   SEQPR *rnas;
   int grammar = STA;
   int Xlen, Ylen;
   int tmp;

   MSAFILE *sfp;  MSA *msa;      /* Handles for current MSA */
   int i,j; 	/* generic loop indicies */
   int numargs, pnum;

   char *pinstring;
   COORDS *pinlist;
   CNSRNT *constraints;

   if (!(processOpts(&settings, &optid, argc, argv, usage, optsline))) {
      printf("%s\n\n", usage);
      exit(0);
   }
   SetAlphabet(hmmNUCLEIC);
   numargs = argc - optid;

   if (settings.verbose) printOptions(settings.ofp, &settings);

   /* if -f option then we're given two numbers, generate
    * fake SEQPR at these lengths and then we can do correct
    * constraints (or a random predicted model too) */
   if (settings.fopt) {
       /* -f says use numbers as lengths rather than seqs */
      if (!(numargs < 1)) {
	 Xlen = atoi(argv[optid]); optid++; 
	 Ylen = atoi(argv[optid]); optid++; 
	 tmp = fakeAllocMx(grammar, Xlen, Ylen);
	 printf("Len: %d,%d \t Mbytes: %.2f \n", Xlen, Ylen, (float)tmp/1000);
      }
   } else {
     /* We're given an MSA and want to know a memory report for the
      * whole damn file -- all unque pairs */
     while (!(argc - optid < 1)) {
       if ((sfp = MSAFileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL)
	 Die("Failed to open sequence file %s\n", argv[optid]);

       /* For each MSA in the current file */
       while ((msa = MSAFileRead(sfp)) != NULL) {
	 standardizeMSA(msa);

	 /* For each possible pair in the current MSA */
	 for (i = 0; i < msa->nseq; i++) {
	   for (j = i+1; j < msa->nseq; j++) {
	     tmp = 0;

	     if (msa->ss_cons != NULL) {
	       if (msa2seqpair(msa, i, j, msa->ss_cons, &rnas)) {
		 /* If has PN line then want to use these as constraints */
		 if (msa->gc != NULL) {
		   pinstring = MSAGetGC(msa, "PN");
		   pnum = annot2pins(rnas->alignment, pinstring, &pinlist);
		   buildConstraints(rnas->sequence[SEQX]->len, 
		       	rnas->sequence[SEQY]->len, pinlist, GIVEN, &constraints);
		   rnas->c_info = constraints;
		 }
		 if (!(containsAmbiguous(rnas->sequence[SEQX]->seq,
			 rnas->sequence[SEQX]->len) &&
		       containsAmbiguous(rnas->sequence[SEQY]->seq,
			 rnas->sequence[SEQY]->len))) {
		   alignID(rnas->alignment);

		     printf("Pair: %s vs %s ", msa->sqname[SEQX], msa->sqname[SEQY]);
		     printf(" (Xlen %d Ylen %d)", rnas->sequence[SEQX]->len, rnas->sequence[SEQY]->len);

		   if (rnas->c_info == NULL) {
		     /* Fake straightforward allocation */
		     tmp = fakeAllocMx(STA, rnas->sequence[SEQX]->len, 
			 rnas->sequence[SEQY]->len);
		     printf("\nFull allocates %u kilobytes (%.2f MBytes) \n",
			 tmp, (float)tmp/1000);
		   } else {
		     /* Fake reduced memory allocation */
		     tmp = fakeRedAllocMx(STA, rnas->c_info->sL, rnas->c_info->sR,
			 rnas->sequence[SEQX]->len, rnas->sequence[SEQY]->len);
		     printf("\nConsan uses %d pins; allocates %u kilobytes (%.2f MBytes) \n",
			 pnum, tmp, (float)tmp/1000);
		   }
		   /* 
		   if (tmp < 2000000) {
		     printStockholm(stdout, rnas, NULL, TRUE);
		   }
		   */
		   /* containsAmbiguous */
		 }
		 /* if msa2seqpair */
		 freeSeqPair(rnas);
	       }
	     }
	   } /* for j */
	 } /* for i */
	 MSAFree(msa);
       } /* for all MSA in this file */
       MSAFileClose(sfp);
       optid++;
     }
   } /* end if fopt */
   return 1;
}
