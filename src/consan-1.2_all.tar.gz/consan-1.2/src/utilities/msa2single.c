/* msa2single.c 
 * Sun Oct 30 09:14:02 EST 2005 [Boston]
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<time.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../consan.h"
#include"../options.h"

static char optsline[]  = "\
Extract pairwise info from a MSA \n\
-h            : print short help and usage info\n\
-v            : verbose output \n\
";
static char usage[]  = "Usage: pickpairs [-options] <msa> \n";

extern int msa2seqpair(MSA *msa, int i, int j, char *conss, SEQPR **rnas);
void printSStock(FILE *fp, char *seq, char *Xname, char *Xss, int len);

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;
  MSAFILE *sfp;  MSA *msa;	/* Handles for current MSA */
  int i;
  struct trace_s *trc;		/* Traceback for current pair */
  char *Xss;
  int idn;


  idn = 0;
  /**** parse arguments *****/
  if (!(processOpts(&settings, &optid, argc, argv, usage, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  /* Must have specified at least one test file */
  if (argc - optid < 1) 
	  Die("Incorrect number of command line arguments.\n%s\n%s\n",
			  usage, optsline);

  if (!settings.cset) { settings.Coption = 100; }

  /* For each test file */
  while (!(argc - optid < 1)) {
    if (settings.debugg) printf("Test set %s\n", argv[optid]); fflush(stdout);

    if ((sfp = MSAFileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL)
      Die("Failed to open sequence file %s\n", argv[optid]);

    /* For each MSA in the current file */
    while ((msa = MSAFileRead(sfp)) != NULL) {
      standardizeMSA(msa);

      /* For each possible pair in the current MSA */
      for (i = 0; i < msa->nseq; i++) {
	trc = NULL;

	/* At least one has individual structure */
	if (msa->ss != NULL) {
	  if (msa->ss[i] != NULL) {
	    Xss = msa->ss[i];
	  }
	} else {	/* Use consensus info */
	  Xss = msa->ss_cons;
	}
	printSStock(stdout, msa->aseq[i], msa->sqname[i], Xss, msa->alen);
      } /* for i */
      MSAFree(msa);
    } /* for all MSA in this file */
    MSAFileClose(sfp);
    optid++;
  } /* for all files */
  return 0;
}

/* Function: printGStock()
 * 
 * Purpose:  Print a sequence/structure representation.
 *
 * Args:     fp     - open file pointer to write to
 *           seqs   - pairwise sequence info
 *                    
 * Return:  void.                   
 */
void   
printSStock(FILE *fp, char *seq, char *Xname, char *Xss, int seqlen)
{
  char seqXbuf[51];
  char strXbuf[51];
  int  nchar;
  int  pos, i, inc;

  fprintf(fp, "# STOCKHOLM 1.0\n\n");

  for (pos = 0; pos < seqlen; pos += 50) {
    inc = 0;
    for (i = 0; i < 50; i++) { 
      if (seq[pos+i] != '.') {
	seqXbuf[inc] = seq[pos+i];
	if (Xss != NULL)
	  strXbuf[inc] = Xss[pos+i];
	inc++;
      }
    }
    seqXbuf[inc] = '\0';
    strXbuf[inc] = '\0';
    nchar = strlen(seqXbuf);

    fprintf(fp, "%-20s\t%s\n", Xname, seqXbuf);
    if (Xss != NULL)
      fprintf(fp, "#=GR %-15s SS %s\n", Xname, strXbuf);
    fputs("\n", fp);
  }
  fputs("//\n\n", fp);

}
