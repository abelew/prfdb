/* printModel_main.c 
 *
 * print out a model file in readable ascii
 * Can optionally linearize a model for plotting.
 *
 * */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<time.h>

#include"squid.h"
#include"../cfg.h"
#include"../consan.h"
#include"../options.h"
#include"../cyk.h"

static char optsline[]  = "\
  [Defaults to printing all parameters as probs] \n\
\n\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-t            : Print transition parameters \n\
-x            : Print 16x16 pairwise emission parameters \n\
-f            : Print 4x4 alignment emission parameters \n\
-d            : Print 4 background (to gap) parameters \n\
-q            : Print parameters as scores (defaults to as probs) \n\
-S            : Print parameters as both probs and scores \n\
-l	      : Linearize output for gnuplot (not valid with -q or -S) \n\
-v	      : Include labels in linear output \n\
";
static char usage[]  = "Usage: pModel [-options] <modfile>\n";

  int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;

  /* Models info */
  MODEL *model;

  /* Possible options */
  int ptrans, ppair, palign, pgap;
  int pscores, pboth, linearize;

  if (!(processOpts(&settings, &optid, argc, argv, usage, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }
  /* Uses either -m or just putting model file at end */
  if (settings.modelfile == NULL) {
    if (argc - optid < 1)
       Die("Incorrect command line arguments.\n%s\n%s\n",
			                          usage, optsline);
    settings.modelfile = argv[optid];
  }

  /* Setup model */
  setupModelQuiet(&settings, &model);

  /* Hijacking parameters to output different parts of the model */
  ptrans = settings.traceback; ppair = settings.parameterout; 
  palign = settings.fopt; pgap = settings.debugg;
  pscores = settings.stockout;  pboth = settings.suppress;
  linearize = settings.linear;

  if (linearize && (pscores || pboth)) {
       Die("Can not request linear output with scores! \n");
  }

  if (ptrans || ppair || palign || pgap) {
    /* Transitions */
    if (ptrans) {
      if (pscores) printTransitions(stdout, model, FALSE);
      else {
	if (linearize) {
	  printTransL(stdout, model, settings.verbose);
	} else {
	  printTransitions(stdout, model, TRUE);
	}
      }
      if (pboth) printTransitions(stdout, model, FALSE);
    }
    /* 16x16 pairwise */
    if (settings.parameterout) {
      if (pscores) printEPairwise(stdout, model, FALSE);
      else {
	if (linearize) {
	  printEPairL(stdout, model, settings.verbose);
	} else {
	  printEPairwise(stdout, model, TRUE);
	}
      }
      if (pboth) printEPairwise(stdout, model, FALSE);
    }
    /* 4x4 alignment */
    if (settings.fopt) {
      if (pscores) printEAlign(stdout, model, FALSE);
      else {
	if (linearize) {
	  printEAlignL(stdout, model, settings.verbose);
	} else {
	  printEAlign(stdout, model, TRUE);
	}
      }
      if (pboth) printEAlign(stdout, model, FALSE);
    }
    /* 4 gap/background */
    if (settings.debugg) {
      if (pscores) printESingles(stdout, model, FALSE);
      else {
	if (linearize) {
	  printESingL(stdout, model, settings.verbose);
	} else {
	  printESingles(stdout, model, TRUE);
	}
      }
      if (pboth) printESingles(stdout, model, FALSE);
    }
  } else {
    if (pscores) printModel(stdout, PRINT_INT, model);
    else if (pboth) printModel(stdout, PRINT_BTH, model);
    else {
      if (linearize) {
	  printTransL(stdout, model, settings.verbose);
	  printEmisL(stdout, model, settings.verbose);
      } else {
	printModel(stdout, PRINT_FLT, model);
      }
    }
  } 
  /* Cleanup  */
  freeModel(model);
  return 0;
}
