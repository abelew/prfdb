/* post2heat.c 
 * RDD, Thu Feb 27 16:27:27 CST 2003 [St Louis]
 *
 * Convert output from dpswalign to input for 
 * matrix2png
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"../squid/squid.h"
#include"../squid/sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../consan.h"
#include"../version.h"
#include"../trace.h"
#include"../alphabet.h"
#include"../options.h"

static char optsline[]  = "\
where options are:\n\
  -h 	    : print usage and help \n\
  -v 	    : verbose \n\
  -m <pt>   : posterior table file \n\
  -C <num>  : number of columns (len first seq to dpswalign) \n\
  -P <num>  : number of rows (len second seq to dpswalign) \n\
";
static char usage[]  = "Usage: post2heat -m <posteriortable> -C columns -P rows \n";

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;

  float **ptable;

  /**** parse arguments *****/
  if (!(processOpts(&settings, &optid, argc, argv, usage, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  readPosteriors(settings.modelfile, settings.Coption, 
      settings.Poption, &ptable);
  printPosteriors(ptable, settings.Coption, settings.Poption);

  return 1;
}
