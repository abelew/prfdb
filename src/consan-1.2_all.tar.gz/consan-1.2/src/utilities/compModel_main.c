/* compModel_main.c 
 *
 * print parameters of models for gnuplot.
 *
 * Uses: 
 *   two models -- comparison plot
 *   two models -- mean & standard deviation
 *   four models -- comparison plot of means with stddev
 * */ 
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<time.h>

#include"squid.h"
#include"../cfg.h"
#include"../consan.h"
#include"../options.h"
#include"../cyk.h"

static char optsline[]  = "\
  [Defaults to printing all parameters as probs] \n\
\n\
where options are:\n\
-h            : print short help, usage info\n\
-t	      : transition parameters only (not compatible with -q or -f)\n\
-q	      : emission parameters only (not compatible with -t or -f)\n\
-f	      : Base pair (16x16) parameters only (not compatible with -t or -q)\n\
-S	      : Output labels \n\
\n\
May also include standard deviations: (must use both together) \n\
-p <file1>    : standard deviation to mod1 \n\
-s <file2>    : standard deviation to mod2 \n\
";
static char usage[]  = "Usage: cModel <mod1> <mod2>\n";

int checkModComparable(MODEL *mod1, MODEL *mod2);

  int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;

  /* Models info */
  MODEL *mod1, *mod2;
  MODEL *mod3, *mod4;

  int gstdev;
  int ptrans, pemiss, pbp;

  if (!(processOpts(&settings, &optid, argc, argv, usage, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }
  /* Uses either -m or just putting model file at end */
  if (settings.modelfile != NULL) {
       Die("Do not use -m.\n%s\n%s\n", usage, optsline);
  }
  if (argc - optid < 2)
       Die("Incorrect command line arguments.\n%s\n%s\n",
			                          usage, optsline);

  /* Hijack parameters for our purposes */
  ptrans = settings.traceback; pemiss = settings.stockout;
  pbp = settings.fopt; 

  if (settings.savefile && settings.pinfile) {
    gstdev = TRUE;
  } else {
    gstdev = FALSE;
  }

  if (settings.linear) settings.suppress = TRUE; 

  if ((ptrans && pbp) || (pemiss && pbp) || (ptrans && pemiss)) {
       Die("ONLY USE ONE SUBSET (-q, -f, or -t) AT A TIME!\n%s\n%s\n",
			                          usage, optsline);
  }

  /* Setup models */
  settings.modelfile = argv[optid++];
  setupModel(&settings, &mod1);
  settings.modelfile = argv[optid++];
  setupModel(&settings, &mod2);
  if (gstdev) {
    settings.modelfile = settings.pinfile;
    setupModel(&settings, &mod3);
    settings.modelfile = settings.savefile;
    setupModel(&settings, &mod4);
  }

  if (!(checkModComparable(mod1, mod2))) {
     Die("Models not comparable -- different grammars.\n");
  } 
  if (gstdev) {
    if (!(checkModComparable(mod1, mod3))) 
      Die("Stdev 1 not comparable -- different grammars.\n");
    if (!(checkModComparable(mod2, mod4))) 
      Die("Stdev 2 not comparable -- different grammars.\n");
  }

  /* Transitions */
  if (!pemiss && !pbp) {
    if (gstdev) {
    printTransQuad(stdout, mod1, mod2, mod3, mod4, settings.suppress);
    } else {
    printTransPair(stdout, mod1, mod2, settings.suppress);
    }
  }

  /* 16x16 pairwise */
  if (!ptrans) {
    if (gstdev) {
      printEPairQuad(stdout, mod1, mod2, mod3, mod4, settings.suppress);
    } else {
      printEPairPair(stdout, mod1, mod2, settings.suppress);
    }

    /* 4x4 alignment */
    if (!pbp) {
      if (gstdev) {
	printEAlignQuad(stdout, mod1, mod2, mod3, mod4, settings.suppress);
      } else {
	printEAlignPair(stdout, mod1, mod2, settings.suppress);
      }

      /* 4 gap/background */
      if (gstdev) {
	printESingQuad(stdout, mod1, mod2, mod3, mod4, settings.suppress);
      } else {
	printESingPair(stdout, mod1, mod2, settings.suppress);
      }
    }
  }

  /* Cleanup  */
  freeModel(mod1); freeModel(mod2);
  if (gstdev) {
    freeModel(mod3); freeModel(mod4);
  }
  return 0;
}

int
checkModComparable(MODEL *mod1, MODEL *mod2)
{
  if (mod1->grammar != mod2->grammar) return 0;
  return 1;
}

