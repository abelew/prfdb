#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  MSA *msa;
  MSAFILE *sfp; 

  if ((sfp = MSAFileOpen(argv[1], SQFILE_UNKNOWN, NULL)) == NULL)
    Die("Failed to open sequence file %s\n", argv[1]);

  while ((msa = MSAFileRead(sfp)) != NULL) {
     MSAMingap(msa);
     WriteStockholm(stdout, msa); fflush(stdout); 
  }

  MSAFileClose(sfp);
  return 0;
}
