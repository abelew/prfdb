/* pincheck.c 
 * RDD, Thu Feb 27 16:27:27 CST 2003 [St Louis]
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../consan.h"
#include"../version.h"
#include"../trace.h"
#include"../alphabet.h"
#include"../options.h"

static char optsline[]  = "\
where options are:\n\
  -h 	print usage and help \n\
  -v    verbose \n\
  -d 	debugging output \n\
  -S	suppress extra output \n\
  -t    print summary info (z = 3 or z = 4 only) \n\
  -z <int>	pin output method:\n\
      1	: Best Posterior Outputs (-P <num>) vs Single Best \n\
      2 : All pins better than X posterior (default .95; -Z <num> )\n\
      3 : How accurate is posterior table? \n\
      4 : How accurate is opt acc alignmnt posteriors? (default) \n\
      5 : Percent ID vs different cutoffs \n\
      6 : Percent ID vs different cutoffs (with window -W <int>) \n\
      7 : Best Posterior Outputs (-P <num>) well space (W <int>)\n\
";
static char usage[]  = "Usage: pincheck [-options] <MSA> \n";

void PrintHeadLabels(int otype);
extern int msa2seqpair(MSA *msa, int i, int j, char *conss, SEQPR **rnas); 

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;
  MSAFILE *sfp; MSA *msa;
  int i,j;
  int zeroes, sum, pairs;
  ALIGN *given;
  SEQPR *spair;
  SEQPR  *opair;                /* Optimal Accuracy Alignment if pred pins */
  float **ptable;               /* Posterior Table if we predict pins */
  int ncord, navail;
  COORDS *pins;                 /* Pins to use in constrained Sankoff */
  PSTATS pinstats;

  /**** parse arguments *****/
  if (!(processOpts(&settings, &optid, argc, argv, usage, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }
  if (argc - optid < 1) 
    Die("Must specify datafile!\n\n%s\n", optsline);

  if ((sfp = MSAFileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL)
    Die("Failed to open sequence file %s\n", argv[optid]);

  if (settings.pinopt == GIVEN) 
    Die("Can not use pin file in this test!");


  ZeroPinStats(&pinstats);
  PrintHeadLabels(settings.pinopt);

  while ((msa = MSAFileRead(sfp)) != NULL) {
    standardizeMSA(msa);

    pairs = 0; sum = 0; zeroes = 0; 
    /* For all pairs of sequences */
    for (i = 0; i < msa->nseq; i++) { 
      for (j = i+1; j < msa->nseq; j++) {
	if (msa2seqpair(msa, i, j, NULL, &spair)) {
	  given = spair->alignment; pairs++;

	  runHolmes(spair, FALSE, TRUE, &ptable, &opair); 

	  if (settings.pinopt == 1) {
	    if (!settings.pset) settings.Poption = 1;
	    ncord = alignPostBest(ptable, opair->alignment, 
		settings.Poption, &pins);
	    /* Opt Acc ID \t Best Opt Acc Score */
	    printf("%1.6f\t%1.6f\t", opair->alignment->aliid, 
		pins->next->score);
	    fflush(stdout);
	    freeCoordList(pins);
	    singleBest(ptable, 0, (spair->sequence[SEQX]->len -1),  0,
		(spair->sequence[SEQY]->len -1), &pins);
	    /* Given ID \t Best Posterior */
	    printf("%1.6f\t%1.6f\n", spair->alignment->aliid, 
		pins->next->score);
	    freeCoordList(pins);
	  } else if (settings.pinopt == 2) {
	    if (!settings.zset) settings.Zoption = 0.95; /* default */
	    ncord = qualityPins(ptable, opair->alignment, settings.Zoption, &pins);
	    printf("%1.6f\t%d\n", opair->alignment->aliid, ncord);
	    freeCoordList(pins);
	  } else if (settings.pinopt == 3) {
	    testPosteriors(ptable, spair->sequence[SEQX]->len,
		spair->sequence[SEQY]->len, spair->alignment,
		&pinstats);
	  } else if (settings.pinopt == 4) {
	    align2pins(opair->alignment, &pins);
	    scoreList(pins, ptable);
	    evalPins(pins, spair->alignment, &pinstats, TRUE);
	    freeCoordList(pins);
	  } else if (settings.pinopt == 5) {
	    if (!settings.zset) settings.Zoption = 0.95; /* default */
	    navail = qualityPins(ptable, opair->alignment, 
		settings.Zoption, &pins);
	    scoreList(pins, ptable);
	    ncord = evalPins(pins, spair->alignment, &pinstats, TRUE);
	    printf("%1.6f\t%1.6f\t%d\t%d\t%d\n", spair->alignment->aliid,
		opair->alignment->aliid, opair->alignment->alen, navail, ncord);
	    freeCoordList(pins);
	  } else if (settings.pinopt == 6) {
	    if (!settings.wset) settings.Woption = 3; /* default */
	    if (!settings.zset) settings.Zoption = 0.95; /* default */
	    navail = qualitySpaced(ptable, opair->alignment, settings.Zoption, 
		settings.Woption, &pins);
	    scoreList(pins, ptable);
	    ncord = evalPins(pins, spair->alignment, &pinstats, TRUE);
	    printf("%1.6f\t%1.6f\t%d\t%d\t%d\n", spair->alignment->aliid,
		opair->alignment->aliid, opair->alignment->alen, navail, ncord);
	    freeCoordList(pins);
	  } else if (settings.pinopt == 7) {
	    if (!settings.wset) settings.Woption = 3; /* default */
	    if (!settings.pset) settings.Poption = 2; /* default */
	    alignSpaced(opair->alignment, ptable, settings.Poption, 
		settings.Woption, &pins);
	    printCoordList(stdout, pins, TRUE);
	    freeCoordList(pins);
	  }
	  freeSeqPair(opair);
          freePosteriors(ptable, spair->sequence[SEQY]->len);
	}
	freeSeqPair(spair);
      } /* end for j */
    }	/* end for i */
    MSAFree(msa);
  }
  if ((settings.pinopt == 3) || (settings.pinopt == 4)) {
    printPinStats(pinstats, settings.traceback);
  }

  MSAFileClose(sfp);

  return 1;
}

void PrintHeadLabels(int otype)
{

  switch (otype) {
    case 1:
      printf("#h OptAcc ID\tBest OptAcc\tGiven ID\tBest Post\n");
      printf("# ==========\t===========\t========\t=========\n");
      break;
    case 2:
      printf("#h OptAcc ID\tNum Qpins\n");
      printf("# ==========\t=========\n");
      break;
    case 3:
      printf("#h All Possible Pins\n");
      printf("# Posterior\tPin Sens\tNum Corr\tTot Num\n");
      printf("# =========\t========\t========\t=======\n");
      break;
    case 4:
      printf("#h Optimal Accuracy Pins Only\n");
      printf("# Posterior\tPin Sens\tNum Corr\tTot Num\n");
      printf("# =========\t========\t========\t=======\n");
      break;
    case 5:
      printf("#h Given ID\tOptAcc ID\tOLen\tNQ\tNqC\n");
      printf("#  ========\t=========\t====\t==\t===\n");
      break;
    case 6:
      printf("#h Given ID\tOptAcc ID\tOLen\tNQ\tNqC\n");
      printf("#  ========\t=========\t====\t==\t===\n");
      break;
    case 7:
      printf("#h Best X Posteriors at Fixed Window Spacing\n");
      break;
  }
}

