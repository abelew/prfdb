/* lstat_main.c 
 * Determine how many sequences are below some cutoff
 * in length.
 * */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../options.h"

static char usage[]  = "Usage: stest <msa>\n"; 

int 
main (int argc, char **argv) 
{
  int   optid; 
  OPTS settings;
  MSAFILE *mfp;                 /* open ptr into trusted (known) alignfile   */
  int    format;                /* expected format of alignment files        */
  MSA   *msa;                  /* a trusted (known) alignment               */
  int i, cnt, cutoff, tmp;
  int min, max, sum, total;

  if (!(processOpts(&settings, &optid, argc, argv, usage, ""))) {
    printf("%s\n\n", usage);
    exit(0);
  } 

  if (settings.cset) {
    cutoff = settings.Coption;
  } else {
    cutoff = 120;
  }

  /* READ IN ALIGNMENTS */
  if ((mfp = MSAFileOpen(argv[optid], MSAFILE_STOCKHOLM, NULL)) == NULL)
    Die("Trusted alignment file %s could not be opened for reading", argv[optid]);

  cnt = total = sum = 0; 
  min = 100000; max = -1;
  while ((msa = MSAFileRead(mfp)) != NULL)
  {
    for (i = 0; i < msa->nseq; i++) {
      tmp = DealignedLength(msa->aseq[i]);
      if (tmp > max) max = tmp;
      if (tmp < min) min = tmp;
      if (tmp <= cutoff) cnt++;
      sum += tmp;
      total++;
    }
  }
  printf("%d Sequences: \n", total);
  printf("%d/%d Sequences are shorter than or equal to %d\n", cnt, total, cutoff);
  printf("Min %d\tMax %d\tAvg %d Tot Nt: %d \n", min, max, sum/total, sum);

  return 1;
}

