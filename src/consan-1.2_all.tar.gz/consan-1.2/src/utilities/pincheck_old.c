/* pincheck.c 
 * RDD, Thu Feb 27 16:27:27 CST 2003 [St Louis]
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../consan.h"
#include"../version.h"
#include"../trace.h"
#include"../alphabet.h"
#include"../options.h"

static char optsline[]  = "\
where options are:\n\
  -h 	print usage and help \n\
  -v    verbose \n\
  -d 	debugging output \n\
  -S	suppress extra output \n\
  -z <int>	pin selection method \n\
";
static char usage[]  = "Usage: pincheck [-options] <MSA> \n";

extern int msa2seqpair(MSA *msa, int i, int j, char *conss, SEQPR **rnas); 

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;
  MSAFILE *sfp; MSA *msa;
  int i,j;
  int zeroes, sum, pairs;
  int Zeroes, gsum;
  ALIGN *given;
  SEQPR *spair;
  SEQPR  *opair;                /* Optimal Accuracy Alignment if pred pins */
  float **ptable;               /* Posterior Table if we predict pins */
  int ncord;
  COORDS *pins;                 /* Pins to use in constrained Sankoff */
  PSTATS pinstats;

  /**** parse arguments *****/
  if (!(processOpts(&settings, &optid, argc, argv, usage, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }
  if ((sfp = MSAFileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL)
    Die("Failed to open sequence file %s\n", argv[optid]);

  if (settings.pinopt == GIVEN) 
    Die("Can not use pin file in this test!");

  ZeroPinStats(&pinstats);
  pinstats.method = settings.pinopt;

  gsum = 0; Zeroes = 0;
  while ((msa = MSAFileRead(sfp)) != NULL) {
    standardizeMSA(msa);

    pairs = 0; sum = 0; zeroes = 0; 
    /* For all pairs of sequences */
    for (i = 0; i < msa->nseq; i++) { 
      for (j = i+1; j < msa->nseq; j++) {
	if (msa2seqpair(msa, i, j, NULL, &spair)) {
	  given = spair->alignment; pairs++;

	  runHolmes(spair, FALSE, TRUE, &ptable, &opair); 

	  if (settings.pinopt == XBEST) {	/* 1 */
            if (!settings.pset) settings.Poption = 1;
	    ncord = alignPostBest(ptable, opair->alignment, settings.Poption, &pins);
	    printf("%1.5f\t%1.6f\n", spair->alignment->aliid, pins->next->score);
	  } else if (settings.pinopt == QUALITY) { /* 2 */
	    if (!settings.zset) settings.Zoption = 0.95;
	    ncord = qualityPins(ptable, opair->alignment, settings.Zoption, &pins);
	    if (settings.verbose)
	      printf("%2.4f %d\n", opair->alignment->aliid, ncord);
	  } else if (settings.pinopt == SPACED) { /* 3 */
	    Die("SPACED method not yet available.");
	    /*
            if (!settings.pset) settings.Poption = 3;
	    ncord = alignSpaced(opair->alignment, settings.Poption, &pins);
	    */
	  } else if (settings.pinopt == QRADIUS) { /* 4 */
	    Die("QRADIUS method not yet available.");
	    /*
            if (!settings.zset) settings.Zoption = 0.95;
	    */
	  } else {
	    Die("Suggested -z 1 or -z 2 only.");
	  }
	  evalPins(pins, given, &pinstats, settings.copt);
	  sum += ncord; gsum += sum;

	  if (ncord == 0) {
	    zeroes++; Zeroes++;
	    if (settings.debugg)
	      printf("%s %s\n", spair->sequence[SEQX]->name, spair->sequence[SEQY]->name);
	  }
	}
	freeSeqPair(spair);
      } /* end for j */
    }	/* end for i */
    MSAFree(msa);
    if (settings.Zoption < 1.0) {
      if ((!settings.suppress) && (settings.verbose)) 
	printf("Num pins: %d Zeroes: %d \n", sum, zeroes);
    }
  }
  if (settings.Zoption < 1.0) {
    printf("Num pins: %d Zeroes: %d \n", gsum, Zeroes);
  }

  if (!settings.suppress) {
    printf("Test Set: %s\n", argv[optid]);
    printPinStats(pinstats);
    if (settings.pinopt == QUALITY) {
      printf("Num pins > %f: %d \n", settings.Zoption, gsum);
    }
    if (settings.pinopt == XBEST) {
      printf("Selecting %d pins per pair\n", settings.Poption);
    }
  }

  MSAFileClose(sfp);

  return 1;
}
