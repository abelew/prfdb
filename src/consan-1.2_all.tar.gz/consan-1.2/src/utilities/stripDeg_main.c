/* stripDeg_main.c 
 * Sun Feb 12 12:37:49 EST 2006 [Boston]
 *
 * Take in MSA (or set) and stip degeneracy and then
 * spit back out the "degenerate corrected" version.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<time.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../consan.h"
#include"../version.h"
#include"../trace.h"
#include"../alphabet.h"
#include"../options.h"
#include"../stats.h"
#include"../cyk.h"

int outputGivenPair(FILE *ofp, MSA *msa, int i, int j, OPTS settings);

static char optsline[]  = "\
  Strip degenerate bases randomly and return new version of MSA.\
";
static char usage[]  = "Usage: stripdeg <msa> \n";

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;
  MSAFILE *sfp;  MSA *msa;	/* Handles for current MSA */

  /**** parse arguments *****/
  if (!(processOpts(&settings, &optid, argc, argv, usage, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  /* Must have specified at least one test file */
  if (argc - optid < 1) 
	  Die("Incorrect number of command line arguments.\n%s\n%s\n",
			  usage, optsline);

  /* For each test file */
  while (!(argc - optid < 1)) {
     if (settings.debugg) printf("Test set %s\n", argv[optid]); fflush(stdout);

     if ((sfp = MSAFileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL)
	Die("Failed to open sequence file %s\n", argv[optid]);

     /* For each MSA in the current file */
     while ((msa = MSAFileRead(sfp)) != NULL) {
       standardizeMSA(msa);

       WriteStockholm(stdout, msa);

       MSAFree(msa);
     } /* for all MSA in this file */
     MSAFileClose(sfp);
     optid++;
  } /* for all files */
  
  return 0;
}
