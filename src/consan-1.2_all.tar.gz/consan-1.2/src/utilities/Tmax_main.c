/* Tmax_main.c 
 * RDD, Wed Sep 29 12:42:40 CDT 2004 [St Louis]
 *
 * Given a reference file, a time slice file (a set of 
 * t values for which we've done comparisons), 
 * a file name (convention for predictions),
 * calculate Tmax for each sequence in the datasets.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../consan.h"
#include"../version.h"
#include"../trace.h"
#include"../alphabet.h"
#include"../options.h"
#include"../stats.h"
#include"../cyk.h"

/* Should do Spair by default but be able to do any of
 * the other metrics with switches */

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-S	      : suppress comparison totals \n\
-q	      : suppress alignment prediction output \n\
-Z <int>      : Number of rates compared \n\
-C <int>      : Number of sequences compared \n\
-M 1 	      : Use Mathews definition of correct pairs \n\
";


static char usage[]  = "Usage: comppair -Z # -C # [-opts] <refseq> <seqprefix>\n";

#define TWOGIVEN	1
#define KGIVEN		2
#define TGIVEN		3
#define CONSENSUS 	4
#define STRTYPES	5

char *strTYPE[STRTYPES] = { "ERROR", "Given", "Given(ref) vs Cons", 
  		"Cons(ref) vs Given", "Consensus" }; 

int compStrWIalign(MSA *kmsa, MSA *tmsa, int idx, STATS *stats, int domathews);
void ComparePairStructs(MSA *kmsa, MSA *tmsa, STATS *gstats, 
    int domathews, int printout);
float ComparePairAlign(MSA *kmsa, MSA *tmsa, int printout);

  int 
main (int argc, char **argv) 
{
  char  *kfile;                 /* name of file of trusted (known) alignment */
  char  *tfile;                 /* name of file prefix for test alignments   */
  char  testfile[128];          /* name of files for test alignments   */
  char suffix[20];

  MSAFILE *kfp;                 /* open ptr into trusted (known) alignfile   */
  MSAFILE *tfp;                 /* open ptr into test alignment file         */
  int    format;                /* expected format of alignment files        */
  MSA   *kmsa;                  /* a trusted (known) alignment               */
  MSA   *tmsa;                  /* a test alignment                          */
  float  score;                 /* RESULT: score for seq comparison	     */ 
  float gscore;			/* Cummulative score for seq comparisons     */
  int npairs;			/* Number of pairs considered */

  int   optid;
  OPTS settings;
  STATS pairstats;

  float sensitivity, ppv;
  float cval, Spair, sum;
  int nrates, nseqs, i, j, k, l;

  float  **imx;                 /* identity matrix               */
  float **Smax;
  int  **Sidx;

  if (!(processOpts(&settings, &optid, argc, argv, usage, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  nrates = settings.zoption;
  if (nrates == 100) 
    Die("Must specify -Z <int> for number of rates tested\n");

  /* Setup gather stats section */
  nseqs = settings.Coption;
  if (nseqs == 0) 
    Die("Must specify -C <int> for number of sequences \n");
  else {
    /* Allocate best Spair matrix */
    Smax = (float **) malloc(sizeof(float*)*nseqs);
    for (i = 0; i < nseqs; i++) {
      Smax[i] = (float *) malloc(sizeof(float)*nseqs);
    }
    for (i = 0; i < nseqs; i++) {
      for (j = 0; j < nseqs; j++) {
	Smax[i][j] = 0.0;
      }
    }
    /* Allocate best Spair index matrix */
    Sidx = (int **) malloc(sizeof(int*)*nseqs);
    for (i = 0; i < nseqs; i++) {
      Sidx[i] = (int *) malloc(sizeof(int)*nseqs);
    }
    for (i = 0; i < nseqs; i++) {
      for (j = 0; j < nseqs; j++) {
	Sidx[i][j] = -1;
      }
    }
   
  }

  /* Shutdown if we're not all setup properly */
  if (argc - optid < 2)
    Die("Incorrect number of command line arguments.\n%s\n", usage);

  /* Digitize Sequences */
  SetAlphabet(hmmNUCLEIC);
  format   = MSAFILE_UNKNOWN;
  kfile = argv[optid++];	/* Reference / Known file */

  if ((kfp = MSAFileOpen(kfile, format, NULL)) == NULL)
    Die("Trusted alignment file %s could not be opened for reading", kfile);

  /*****************************
   * Find given sequences % id *
   *****************************/
  j = 0; k = j+1;
  while ((kmsa = MSAFileRead(kfp)) != NULL) {
    MakeIdentityMx(kmsa->aseq, kmsa->nseq, &imx);
    sum = 0.0;
    for (i = 0; i < kmsa->nseq; i++) {
      for (l = 0; l < i; l++)
	sum += imx[i][l];
    }
    FMX2Free(imx);
    Smax[k][j] = sum / (float) (kmsa->nseq * (kmsa->nseq-1)/2.0);
    k++;
    if (k%nseqs == 0) {
      j++; k = j+1;
    }
  }
  MSAFileRewind(kfp);

  /* Results File Consensus Name */
  tfile = argv[optid];

  /* READ IN ALIGNMENTS */
  for (i = 0; i < nrates; i++) {
    j = 0; k = j+1;

    /* Append 'i.pred.stk' to tfile */
    strcpy(testfile, tfile);
    sprintf(suffix, ".%d.pred.stk", i);
    strcat(testfile, suffix);

    /* Open file */
    if ((tfp = MSAFileOpen(testfile, format, NULL)) == NULL)
      Die("Test alignment file %s could not be opened for reading", tfile);

    npairs = 0; 

    while ((kmsa = MSAFileRead(kfp)) != NULL) {
      if ((tmsa = MSAFileRead(tfp)) == NULL)
	Die("Failed: test alignment does not match trusted alignment");

      /**************************
       * Compare the alignments *
       **************************/
      score = ComparePairAlign(kmsa, tmsa, !settings.stockout);
      gscore = gscore + score;
      npairs++;
      /**************************
       * Compare the structures *
       **************************/
      ZeroStats(&pairstats);  
      ComparePairStructs(kmsa, tmsa, &pairstats, settings.mset);
      /**************************
       * Generate Stat Numbers  *
       **************************/
      sensitivity = ppv = cval = 0.0;
      if (pairstats.trust_pairs > 0) {
	sensitivity = 100. * (float) pairstats.trust_correct /
	  (float) pairstats.trust_pairs;
      }
      if (pairstats.test_pairs > 0) {
	ppv = 100. * (float) pairstats.test_correct /
	  (float) pairstats.test_pairs;
      }
      cval = sqrt(sensitivity*ppv);
      Spair = ((100*score) + cval)/2;
      /********************************
       * Determine if we have new max *
       ********************************/
      if (Spair > Smax[j][k]) {
	Smax[j][k] = Spair;
	Sidx[j][k] = i;
	/* Would be nicer if we keep all ties as well */
      }

      /********************************
       * Determine Index of next pair *
       ********************************/
      k++;
      if (k%nseqs == 0) {
	j++; k = j+1;
      }

      MSAFree(kmsa);
      MSAFree(tmsa);
    }
    MSAFileClose(tfp);

    /* Rewind kfp to get ready for next tfp*/
    MSAFileRewind(kfp);
  }
  MSAFileClose(kfp);

  /* Output -- upper half is Spair(max) and lower is % id */
  if (settings.debugg) {
    for (i = 0; i < nseqs; i++) {
      for (j = 0; j < i; j++) {
	printf("%3.2f\t", Smax[i][j]);
      }
      if (i == j) printf("------\t");
      for (j = i+1; j < nseqs; j++) {
	printf("%3.2f\t", Smax[i][j]);
      }
      printf("\n");
    }
  }
  for (i = 0; i < nseqs; i++) {
    for (j = i+1; j < nseqs; j++) {
      printf("%2.2f %d %3.2f\n", (100*Smax[j][i]), Sidx[i][j], Smax[i][j]);
    }
  }
  return 0;
}

void
ComparePairStructs(MSA *kmsa, MSA *tmsa, STATS *gstats, int domathews)
{
  STATS xstat, ystat;
  int comptype;

  ZeroStats(&xstat);  ZeroStats(&ystat);

  comptype = compStrWIalign(kmsa, tmsa, SEQX, &xstat, domathews);
  printf("SEQX: %s (%s)\n", kmsa->sqname[SEQX], strTYPE[comptype]);
  PrintTotals(&xstat, FALSE, TRUE);
  accumulateStats(&xstat, gstats);

  comptype = compStrWIalign(kmsa, tmsa, SEQY, &ystat, domathews); 
  printf("SEQY: %s (%s)\n", kmsa->sqname[SEQY], strTYPE[comptype]);
  PrintTotals(&ystat, FALSE, TRUE); 
  accumulateStats(&xstat, gstats);
}


float
ComparePairAlign(MSA *kmsa, MSA *tmsa, int printout)
{
  float score;

  /* Then we test them for alignment statistics -- compalign */
  /* Compare the alignments, print results
   * Uses a squid library function (CompareMultiAlignments) */
  if (testAlignPairs (kmsa, tmsa)) {
    score = CompareMultAlignments(kmsa->aseq, tmsa->aseq, kmsa->nseq);

    if (printout) {
      printf("Alignment %s vs %s \n", kmsa->sqname[SEQX], kmsa->sqname[SEQY]);
      printf("Alignment identity:  %.4f\n\n", score);
    }

    return score;
  }
  return -1;
}

/* Function: compStrWIalign
 * Date: Fri Jun 25 13:27:58 CDT 2004 [St Louis]
 *
 * Purpose: Compare the structures between two 
 * 	identical sequences in two alignments.
 *
 * Assumption: Checks to verify sequences are under same
 *   idx are done elsewhere.
 *
 * NOTE: To be fully general, we've got to accept the possibility
 * that both sequences will specify the structure of each sequence.
 * For our purposes, we expect one (known) to be will specified
 * and the other to just give a consensus.
 *
 * Arguments: kmsa	MSA of known alignment
 * 	      tmsa	MSA of test alignment
 * 	      idx	subsequences to compare
 * 	      stats	statistics to generate
 *
 * Returns: 
 * 	FALSE if comparison fails (structure info unavailable)
 * 	Otherwise return a comparison type code:
 * 	  (TWOGIVEN, KGIVEN, TGIVEN, CONSENSUS)
 */
int
compStrWIalign(MSA *kmsa, MSA *tmsa, int idx, STATS *stats,
    int domathews) 
{
  char *kss, *tss;		/* secondary structure info */

  if ((kss = MSAGetSeqSS(kmsa, idx)) != NULL) {
    if ((tss = MSAGetSeqSS(tmsa, idx)) != NULL) {
      /* We have sequence specific structure for both */
      CompStruct(kmsa->alen, kss, tss, stats, FALSE, domathews, FALSE);
      return TWOGIVEN;
    } else {
      /* We have sequence specific structure for known 
       * but must use consensus info for test */
      if (tmsa->ss_cons == NULL) return 0;
      /* We've got to dealign k as well because otherwise their coordinates
       * don't match up (kss would be alignment coordinates and tss would be
       * dealigned.  We can reference kmsa->ss[idx] directly because to have 
       * gotten here the MSAGetSeqSS for kmsa had to have passed already */
      MakeDealignedString(kmsa->aseq[idx], kmsa->alen, kmsa->ss[idx], &kss);
      MakeDealignedString(tmsa->aseq[idx], tmsa->alen, tmsa->ss_cons, &tss);
      CompStruct(strlen(kss), kss, tss, stats, FALSE, domathews, FALSE);
      free(tss); free(kss); 
      return KGIVEN;
    }
  } else {	/* Need to use consensus for SEQX */
    if ((tss = MSAGetSeqSS(tmsa, idx)) != NULL) {
      /* We have sequence specific structure for test  
       * but must use consensus info for known */
      if (kmsa->ss_cons == NULL) return 0;
      MakeDealignedString(kmsa->aseq[idx], kmsa->alen, kmsa->ss_cons, &kss);
      /* As with kss above, we've got to dealign tss here to put it on same
       * coordinate system as kss.  We can ref tmsa->ss[idx] directly because
       * to get here it would have already had to have passed MSAGetSeqSS */
      MakeDealignedString(tmsa->aseq[idx], tmsa->alen, tmsa->ss[idx], &tss);
      CompStruct(strlen(kss), kss, tss, stats, FALSE, domathews, FALSE);
      free(kss); free(tss);
      return TGIVEN;
    } else {
      /* We have to use consensus structure for both */
      if (kmsa->ss_cons == NULL) return 0;
      if (tmsa->ss_cons == NULL) return 0;
      MakeDealignedString(kmsa->aseq[idx], kmsa->alen, kmsa->ss_cons, &kss);
      MakeDealignedString(tmsa->aseq[idx], tmsa->alen, tmsa->ss_cons, &tss);
      CompStruct(strlen(kss), kss, tss, stats, FALSE, domathews, FALSE);
      free(kss);  free(tss);
      return CONSENSUS;
    }
  }
}
 
