/* picktRNA_main.c 
 * Sat Apr  2 14:14:13 EST 2005 [Boston]
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<time.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../consan.h"
#include"../options.h"

static char optsline[]  = "\
Extract pairwise info from a MSA \n\
-h            : print short help and usage info\n\
-v            : verbose output \n\
-C <int>      : number to pick per bin (5% bins)\n\
-Z <float>    : Cutoff for having at least one pin better than  \n\  
";
static char usage[]  = "Usage: pickpairs [-options] <msa> \n";

int outputGivenPair(FILE *ofp, MSA *msa, int i, int j, OPTS settings);
extern int msa2seqpair(MSA *msa, int i, int j, char *conss, SEQPR **rnas);
void   printGStock(FILE *fp, ALIGN *alignment, char *Xname, char *Yname,
         char *Xss, char *Yss);

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;
  MSAFILE *sfp;  MSA *msa;	/* Handles for current MSA */
  int i,j;			/* generic loop indicies */
  SEQPR *rnas;			/* Current pair to analyze */
  struct trace_s *trc;		/* Traceback for current pair */
  int nseqs, category;
  int interval[20], ncord;
  char *conss;
  char *Xss, *Yss;
  SEQPR  *opair;                /* Optimal Accuracy Alignment if pred pins */
  float **ptable;               /* Posterior Table if we predict pins */
  COORDS *pins;                 /* Pins to use in constrained Sankoff */
  int idn;


  idn = 0;
  for (i = 0; i < 20; i++) {
    interval[i] = 0;
  }

  /**** parse arguments *****/
  if (!(processOpts(&settings, &optid, argc, argv, usage, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  /* Must have specified at least one test file */
  if (argc - optid < 1) 
	  Die("Incorrect number of command line arguments.\n%s\n%s\n",
			  usage, optsline);

  if (!settings.cset) { settings.Coption = 100; }

  nseqs = 0;
  /* For each test file */
  while (!(argc - optid < 1)) {
     if (settings.debugg) printf("Test set %s\n", argv[optid]); fflush(stdout);

     if ((sfp = MSAFileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL)
	Die("Failed to open sequence file %s\n", argv[optid]);

     /* For each MSA in the current file */
     while ((msa = MSAFileRead(sfp)) != NULL) {
       standardizeMSA(msa);
       nseqs += msa->nseq;
  /*     MakeIdentityMx(msa->aseq, msa->nseq, &imx); */

     /* For each possible pair in the current MSA */
       for (i = 0; i < msa->nseq; i++) {
	 for (j = i+1; j < msa->nseq; j++) {
	   trc = NULL;

	   /* At least one has individual structure */
	   if (msa->ss != NULL) {
	     /* Both have individual structure */
	     if ((msa->ss[i] != NULL) && (msa->ss[j] != NULL)) {
	       calcConsStruct(msa->ss[i], msa->aseq[i], msa->ss[j], 
		   msa->aseq[j], msa->alen, &conss);
	       /*  Xss = msa->ss[i]; Yss = msa->ss[j]; */
	       Xss = NULL; Yss = NULL;
	     } else {
	       /* Only one or other has individual structure, 
		* so we should use the consensus info instead */
	       if (msa->ss[i] != NULL) {
		 if (msa->ss_cons != NULL) conss = msa->ss_cons;
		 else conss = NULL;
		 Xss = msa->ss[i]; Yss = NULL;
	       } else {
		 if (msa->ss_cons != NULL) conss = msa->ss_cons;
		 else conss = NULL;
		 Yss = msa->ss[j]; Xss = NULL;
	       }
	     }

	     /* Neither has individual structure */
	   } else if (msa->ss_cons != NULL) { 
	     /* A consensus structure exists */
	     conss = msa->ss_cons; 
	     Xss = NULL; Yss = NULL;
	   } else { 
	     /* We have no structure information at all */
	     conss = NULL; 
	     Xss = NULL; Yss = NULL;
	   }

	   if (msa2seqpair(msa, i, j, conss, &rnas)) {
	     if (!(containsAmbiguous(rnas->sequence[SEQX]->seq, 
		     rnas->sequence[SEQX]->len) &&
		   containsAmbiguous(rnas->sequence[SEQY]->seq, 
		     rnas->sequence[SEQY]->len))) {

	       alignID(rnas->alignment);
	       category = (int)(((int)(rnas->alignment->aliid * 100))/5);
	       idn++;
	       /* printf("%f %d\n", rnas->alignment->aliid, category); */
	       if ((interval[category] < settings.Coption) /* && ((int)(idn%3) == 2) */ ) { 
		 if (settings.zset) {
		   runHolmes(rnas, FALSE, TRUE, &ptable, &opair);
		   ncord = qualityPins(ptable, opair->alignment, 
		       settings.Zoption, &pins);
		   if (ncord > 2) {
		     printGStock(stdout, rnas->alignment, 
			 rnas->sequence[SEQX]->name, 
			 rnas->sequence[SEQY]->name, Xss, Yss);
		     interval[category] = interval[category] +1;
		   }
		   freeCoordList(pins);
		   freeSeqPair(opair);
		   freePosteriors(ptable, rnas->sequence[SEQY]->len);
		 } else {
		   printGStock(stdout, rnas->alignment, 
		       rnas->sequence[SEQX]->name, 
		       rnas->sequence[SEQY]->name, Xss, Yss);
		   interval[category] = interval[category] +1;
		 }
	       }
	     } /* containsAmbiguous */
	     freeSeqPair(rnas);
	   } /* if msa2seqpair */
	 } /* for j */
       } /* for i */
       MSAFree(msa);
     } /* for all MSA in this file */
     MSAFileClose(sfp);
     optid++;
  } /* for all files */
  return 0;
}

/* Function: printGStock()
 * 
 * Purpose:  Print a sequence/structure representation.
 *
 * Args:     fp     - open file pointer to write to
 *           seqs   - pairwise sequence info
 *                    
 * Return:  void.                   
 */
void   
printGStock(FILE *fp, ALIGN *alignment, char *Xname, char *Yname,
         char *Xss, char *Yss)
{
  char seqXbuf[51];
  char seqYbuf[51];
  char strXbuf[51];
  char strYbuf[51];
  char strucbuf[51];
  int  nchar;
  int  pos;

  fprintf(fp, "# STOCKHOLM 1.0\n\n");
  fprintf(fp, "#=GF PI\t %f\n\n", alignment->aliid);

  for (pos = 0; pos < alignment->alen; pos += 50) {
    strncpy(seqXbuf,   alignment->aseqs[SEQX] + pos, 50); seqXbuf[50] = '\0';
    strncpy(seqYbuf,   alignment->aseqs[SEQY] + pos, 50); seqYbuf[50] = '\0';
    if (alignment->ss != NULL)
      strncpy(strucbuf, alignment->ss + pos,   50); strucbuf[50] = '\0';
    if (Xss != NULL)
      strncpy(strXbuf, Xss + pos,   50); strXbuf[50] = '\0';
    if (Yss != NULL)
      strncpy(strYbuf, Yss + pos,   50); strYbuf[50] = '\0';
    nchar = strlen(seqXbuf);

    fprintf(fp, "%-20s\t%s\n", Xname, seqXbuf);
    if (Xss != NULL)
      fprintf(fp, "#=GR %-15s SS %s\n", Xname, strXbuf);
    fprintf(fp, "%-20s\t%s\n", Yname, seqYbuf);
    if (Yss != NULL)
      fprintf(fp, "#=GR %-15s SS %s\n", Yname, strYbuf);
    if (alignment->ss != NULL)
      fprintf(fp, "#=GC SS_cons\t\t%s\n", strucbuf);
    fputs("\n", fp);
  }
  fputs("//\n\n", fp);

}
