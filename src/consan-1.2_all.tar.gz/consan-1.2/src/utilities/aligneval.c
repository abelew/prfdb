/* aligneval.c
 * 
 * Comparison of multiple alignments. The functions are
 * provided to calculate:
 *    CompareMultAlignments()    - basic scoring scheme
 *                                 
 * The similarity measure is a fractional alignment identity averaged
 * over all sequence pairs. The score for all pairs is:
 *      (identically aligned symbols) / (total aligned columns in 
 *      known alignment)
 *      
 * A column c is identically aligned for sequences i, j if:
 *    1) both i,j have a symbol aligned in column c, and the
 *       same pair of symbols is aligned somewhere in the test
 *       alignment
 *    
 * The algorithm is as follows:
 *    1) For each known/test aligned pair of sequences (k1,k2 and t1,t2)
 *        construct a list for each sequence, in which for every
 *        counted symbol we record the raw index of the symbol in
 *        the other sequence that it aligns to, or -1 if it aligns
 *        to a gap or uncounted symbol.
 *        
 *    2)  Compare the list for k1 to the list for t1 and count an identity 
 *        for each correct alignment.
 *        
 *    3) Repeat 2) for comparing k2 to t2. Note that this means correct sym/sym
 *       alignments count for 2; correct sym/gap alignments count for 1.
 *    
 *    4) The score is (identities from 2 + identities from 3) / 
 *       (totals from 2 + totals from 3).
 *
 * Written originally for koala's ss2 pairwise alignment package.
 * Sean Eddy, Sun Nov  1 12:45:11 1992
 * SRE, Thu Jul 29 16:47:18 1993: major revision: all functions replaced by new algorithm
 * RDD, Wed Mar 23 13:55:24 EST 2005: Modified for consan usage.
 * CVS $Id: aligneval.c,v 1.1 2005/03/23 22:21:03 robin Exp $
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "../squid/squid.h"
#include "../squid/sre_random.h"

static int m_alilist(char *s1, char *s2, int **ret_s1_list, int *ret_listlen);
static int comp_lists(int *k1, int *k2, int *t1, int *t2, int len1, int len2, int *ret_id, int *ret_tot);

/* Function: CompPairAlignments
 * 
 * Purpose:  Calculate and return a number representing how well two different alignments
 *           of a pair of sequences compare. The number is, roughly speaking,
 *           the fraction of columns which are identically aligned.
 * 
 *           For all columns c in which either known1[c] or known2[c] 
 *           is a non-gap, count an identity if those same symbols are
 *           aligned somewhere in calc1/calc2. The score is identities/total
 *           columns examined. (i.e. fully gapped columns don't count)
 * 
 *           more explicitly, identities come from:
 *             both known and test aligned pairs have the same symbol in the first sequence aligned to
 *               a gap in the second sequence;
 *             both known and test aligned pairs have the same symbol in the second sequence
 *               aligned to a gap in the first sequence;
 *             the known alignment has symbols aligned at this column, and the test
 *               alignment aligns the same two symbols.
 * 
 * Args:     known1, known2: trusted alignment of two sequences
 *           calc1, calc2:   test alignment of two sequences
 *      RDD, modified to return integer counts of correct columns & total columns
 *           ret_id:  total correct columns
 *           ret_tot: total checked columns
 *  
 * Return:   Returns -1.0 on internal failure.
 */
float
CompPairAlignments(char *known1, char *known2, char *calc1, char *calc2, int *ret_id, int *ret_tot)
{
  int *klist1;
  int *klist2;
  int *tlist1;
  int *tlist2;
  int len1, len2;
  int id, tot;
  float sc;

  if (! m_alilist(calc1,  calc2,  &tlist1, &len1)) return -1.0;
  if (! m_alilist(calc2,  calc1,  &tlist2, &len2)) return -1.0;
  if (! m_alilist(known1, known2, &klist1, &len1)) return -1.0;
  if (! m_alilist(known2, known1, &klist2, &len2)) return -1.0;
  if (! comp_lists(klist1, klist2, tlist1, tlist2, len1, len2, &id, &tot)) return -1.0;

  *ret_id = id;
  *ret_tot = tot;
  
  free(klist1);
  free(klist2);
  free(tlist1);
  free(tlist2);

  sc = (((float)id/(float)tot));
  return (sc);
}


/* Function: m_alilist()
 * 
 * Purpose:  Construct a list (array) mapping the raw symbols of s1
 *           onto the indexes of the aligned symbols in s2 (or -1
 *           for gaps in s2). The list (s1_list) will be of the
 *           length of s1's raw sequence.
 *           
 * Args:     s1          - sequence to construct the list for
 *           s2          - sequence s1 is aligned to
 *           ret_s1_list - RETURN: the constructed list (caller must free)
 *           ret_listlen - RETURN: length of the list
 *           
 * Returns:  1 on success, 0 on failure
 */
static int
m_alilist(char *s1, char *s2, int **ret_s1_list, int *ret_listlen)
{
  int *s1_list;
  int  col;			/* column position in alignment */
  int  r1, r2;			/* raw symbol index at current col in s1, s2 */
  
  /* Malloc for s1_list. It can't be longer than s1 itself; we just malloc
   * for that (and waste a wee bit of space)
   */
  s1_list = (int *) MallocOrDie (sizeof(int) * strlen(s1));
  r1 = r2 = 0;
  for (col = 0; s1[col] != '\0'; col++)
    {
      /* symbol in s1? Record what it's aligned to, and bump
       * the r1 counter.
       */
      if (! isgap(s1[col]))
	{
	  s1_list[r1] = isgap(s2[col]) ? -1 : r2;
	  r1++;
	}

      /* symbol in s2? bump the r2 counter
       */
      if (! isgap(s2[col]))
	r2++;
    }

  *ret_listlen = r1;
  *ret_s1_list = s1_list;
  return 1;
}

/* Function: comp_lists()
 * 
 * Purpose:  Given four alignment lists (k1,k2, t1,t2), calculate the
 *           alignment score.
 *           
 * Args:     k1   - list of k1's alignment to k2
 *           k2   - list of k2's alignment to k1
 *           t1   - list of t1's alignment to t2
 *           t2   - list of t2's alignment to t2
 *           len1 - length of k1, t1 lists (same by definition)
 *           len2 - length of k2, t2 lists (same by definition)
 *     RDD: Changed to return integer count totals rather than score:
 *           ret_id - total correct columns
 *           ret_tot - total counted columns
 *
 * Return:   1 on success, 0 on failure.
 */           
static int
comp_lists(int *k1, int *k2, int *t1, int *t2, int len1, int len2, int *ret_id, int *ret_tot)
{
  int id;
  int tot;
  int   i;

  id = tot = 0;
  for (i = 0; i < len1; i++)
    {
      tot += 1;
      if (t1[i] == k1[i]) id += 1;
    }

  for ( i = 0; i < len2; i++)
    {
      tot += 1;
      if (k2[i] == t2[i]) id += 1;
    }

  /* RDD: removed -- *ret_sc = id / tot; */
  *ret_id = id;
  *ret_tot = tot;
  return 1;
}

