/* Use bootstrapping to get variance and std. dev for sample */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"../squid/squid.h"
#include"../squid/sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../alphabet.h"

struct opts {
   int help;
   int verbose;

   int iter;
};
typedef struct opts OPTM;

struct perfdata {
  int numcorrect;
  int numtrust;
  int numpred;
  float aliid;

  struct perfdata *next;
};
typedef struct perfdata PDATA;

struct opt_s OPTION[] = {
  { "-h",        TRUE,  sqdARG_NONE  },
  { "-v",        TRUE,  sqdARG_NONE  },
  { "-d",        TRUE,  sqdARG_STRING},
  { "-i",        TRUE,  sqdARG_INT},
};


static char optsline[]  = "\
where options are:\n\
  -h            : get help \n\
  -v 	        : verbose \n\
  -d <file>	: Output diff data to <file>\n\
  ";
static char usage[]  = "Usage: bstrap <file>\n";

#define NOPTION (sizeof(OPTION) / sizeof(struct opt_s))

void setupReplicate(PDATA ***rep, int size);
PDATA *allocPdata();
int loadOriginal(char *filename, PDATA ***dset);
int processOpt(OPTM *options, int *optid, int argc, 
    char **argv, char *usage, char *optsline); 
void printPdata(PDATA *node);
void calcStats(PDATA **list, int size, PDATA *ret_sum);
void genRepl(PDATA**original, int size, PDATA **rep);

int 
main (int argc, char **argv) 
{
  OPTM settings;
  int optid, size;
  PDATA **dataset;
  PDATA **rep;
  PDATA *summary;
  PDATA *rsum, *ans;
  int i;
  float *sensitivity, *ppv;
  float diff;
  double sensum;
  double ppvsum;
  double meansen, varsen, sdsen;
  double meanppv, varppv, sdppv;
  FILE *hfp;

  sre_srandom(time(0));
  summary = allocPdata();
  rsum = allocPdata();
  ans = allocPdata();

  if (!(processOpt(&settings, &optid, argc, argv, usage, optsline))) {
    printf("Bad Options\n\n");
    exit(0);
  }
  if (settings.help) Die("%s %s\n", usage, optsline);

  if ((sensitivity = (float *)malloc(sizeof(float)*settings.iter)) == NULL)
    Die("sensitivity matrix allocation error!\n");
  if ((ppv = (float *)malloc(sizeof(float)*settings.iter)) == NULL)
    Die("ppv matrix allocation error!\n");

  if (settings.histfile != NULL) {
    hfp = fopen(settings.histfile, "w");
  }

  /* Load the original dataset */
  size = loadOriginal(argv[optid], &dataset);
  /* Calc stats on original dataset */
  calcStats(dataset, size, summary);

  setupReplicate(&rep, size);
  sensum = 0.; ppvsum = 0.;
  /* For set number of iterations */
  for (i = 0; i < settings.iter; i++) {
    /* generate a replicate */
    genRepl(dataset, size, rep);
    /* Calc stats on replicate */
    calcStats(rep, size, rsum);
    sensitivity[i] = (double)rsum->numcorrect / (double)rsum->numtrust;
    ppv[i] = (double)rsum->numcorrect / (double)rsum->numpred;
    sensum += sensitivity[i];
    ppvsum += ppv[i];
    /* Calculate diff */
    if (settings.histfile != NULL) {
      diff = 
	((double)summary->numcorrect/(double)summary->numtrust) -
	((double)rsum->numcorrect/(double)rsum->numtrust) ;
      fprintf(hfp, "%f\n", diff);
    }
  }

  /* Run statistics */
  meansen = sensum / settings.iter;
  meanppv = ppvsum / settings.iter;
  sensum = 0.; ppvsum = 0.;
  for (i = 0; i < settings.iter; i++) {
    sensum += (sensitivity[i] - meansen) * (sensitivity[i] - meansen);
    ppvsum += (ppv[i] - meanppv) * (ppv[i] - meanppv);
  }
  varsen = sensum / (settings.iter - 1);
  varppv = ppvsum / (settings.iter - 1);
  sdsen = sqrt(varsen);
  sdppv = sqrt(varppv);

  printf("Original Dataset Statistics:\n");
  printPdata(summary);
  printf("Bootstrapping Results: (Sample %d)\n", settings.iter);
  printf("Sensitivity Mean: %f\tVariance %f\tStd.Dev. %f\n", 
      meansen, varsen, sdsen);
  printf("PPV Mean: %f\tVariance %f\tStd.Dev. %f\n", 
      meanppv, varppv, sdppv);

  return 0;
}

void
setupReplicate(PDATA ***rep, int size)
{
  PDATA **cur;
  int i;

  if ((cur = (PDATA**)malloc(sizeof(PDATA*)*size)) == NULL) 
    Die("malloc darray of pdata failed\n");
  for (i = 0; i < size; i++) {
    cur[i] = allocPdata();
  }

  *rep = cur;
}

PDATA *
allocPdata()
{
  PDATA *node;

  if ((node = (PDATA *)malloc(sizeof(PDATA))) == NULL)
    Die("malloc current element of pdata failed\n");
  node->numcorrect = 0;
  node->numtrust = 0;
  node->numpred = 0;
  node->aliid = 0.;
  node->next = NULL;

  return node;
}


void
genRepl(PDATA**original, int size, PDATA **rep)
{
  int i, dice;

  for (i = 0; i < size; i++) {
    dice = (int)(size * sre_random());
    rep[i]->numcorrect = original[dice]->numcorrect;
    rep[i]->numtrust = original[dice]->numtrust;
    rep[i]->numpred = original[dice]->numpred;
    rep[i]->aliid = original[dice]->aliid;
  }
}

int
loadOriginal(char *filename, PDATA ***dset)
{
  FILE *ifp;
  int cor, trust, pred;
  float align;
  int tokens, outputs;
  char line[128];
  char *stok;
  PDATA *prev, *cur;
  PDATA **darray;

  prev = cur = NULL;
  outputs = 0;
  ifp = fopen(filename, "r");

  /* Read in outputs info line by line */
  while (fgets(line, 128, ifp) != NULL) {
    if ((stok = strtok(line, " \t\n")) == NULL) {
      printf("NO TOLKENS\n");
    }
    cor = atoi(stok); tokens = 1;
    while ((stok = strtok(NULL, " \t\n")) != NULL) {
      if (tokens == 1) {
	trust = atoi(stok);
	tokens++;
      } else if (tokens == 2) {
	pred = atoi(stok);
	tokens++;
      } else if (tokens == 3) {
	align = atof(stok);
	tokens++;
      } else {
	printf("MORE TOLKENS THAN EXPECTED!\n");
      }
    }
    cur = allocPdata();
    cur->numcorrect = cor;
    cur->numtrust = trust;
    cur->numpred = pred;
    cur->aliid = align;
    cur->next = prev;
    prev = cur;
    outputs++;
  }
  fclose(ifp);
  /* At this point we have a linked list with outputs 
   * elements and head at prev */
  
  /* Setup an array of these guys because that's faster
   * for accessing */
  cur = prev;
  if ((darray = (PDATA**)malloc(sizeof(PDATA*)*outputs)) == NULL) 
    Die("malloc darray of pdata failed\n");
  for (cor = 0; cor < outputs; cor++) {
    darray[cor] = cur;
    if (darray[cor] == NULL) Die("PROBLEM!!\n");
    cur = cur->next;
  }
  *dset = darray;

  return outputs;
}

void 
calcStats(PDATA **list, int size, PDATA *ret_sum)
{
  int i;

  ret_sum->numcorrect = 0;
  ret_sum->numtrust = 0;
  ret_sum->numpred = 0;
  ret_sum->aliid = 0.;

  for (i = 0; i < size; i++) {
    ret_sum->numcorrect += list[i]->numcorrect;
    ret_sum->numtrust += list[i]->numtrust;
    ret_sum->numpred += list[i]->numpred;
    ret_sum->aliid += list[i]->aliid;
  }

}

void
printPdata(PDATA *node)
{
  printf("%d\t%d\t%d\t%f\n", node->numcorrect, node->numtrust,
      	node->numpred, node->aliid);
  printf("Sensitivity %f\nPPV %f\n",
      (double)node->numcorrect/(double)node->numtrust,
      (double)node->numcorrect/(double)node->numpred);
}

int
processOpt(OPTM *options, int *optid, int argc, 
    char **argv, char *usage, char *optsline)
{
  char *optarg; char *optname;

  /* Set defaults in options */
  options->help = FALSE;
  options->verbose = FALSE;
  options->iter = 10;

  options->histfile = NULL;

  /* Intepret command line arguments */
  while (Getopt(argc, argv, OPTION, NOPTION, optsline, optid,
	&optname, &optarg)) {
    if (strcmp(optname, "-h") == 0) options->help = TRUE;
    else if (strcmp(optname, "-d") == 0) options->histfile    = optarg;
    else if (strcmp(optname, "-v") == 0) options->verbose      = TRUE;
    else if (strcmp(optname, "-i") == 0) options->iter = atoi(optarg);
  }

  return TRUE;
}


