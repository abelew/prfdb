/* cfgmodel.c
 * RDD, Fri Aug 24 12:51:19 2001
 * 
 * Usage and setup of model parameters.
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include "squid/squid.h"
#include "cfg.h"
#include "options.h"


/* Function: plusOnePrior
 * Date: Fri Feb 28 12:11:48 CST 2003 [I-44 mile 44, MO]
 *
 * Purpose: Add +1 prior (does not zero!)
 *
 * Returns: Nothing
 */
void
plusOnePrior(INTMOD *scores)
{
   int i;

   for (i = 0; i < NTRANS; i++) {
      scores->transitions[i] ++;
   }
   for (i = 0; i < ECOUNT; i++) {
      scores->emissions[i] ++;
   }
}

/* Function: plusOnePriorD
 * Date: Thu Sep 30 16:24:39 CDT 2004
 *
 * Purpose: Add +1 prior (does not zero!)
 *
 * Returns: Nothing
 */
void
plusOnePriorD(PROBMOD *scores)
{
   int i;

   for (i = 0; i < NTRANS; i++) {
      scores->transitions[i] += 1.0;
   }
   for (i = 0; i < ECOUNT; i++) {
      scores->emissions[i] += 1.0;
   }
}

/* Function: DLogifySCFG
 * Date: Fri Feb 28 12:14:13 CST 2003 [I-44 mile 40, MO]
 *
 * Purpose:  Take an SCFG and convert it to log form
 *           for an alignment.
 *
 * Notes: Both cfg and icfg must already be allocated.
 *
 * Args:     cfg  - the grammar, floating point form
 * 	    icfg  - the grammar, log form
 *
 * Return:   log form of the grammar
 */
void
DLogifySCFG(int grammar, PROBMOD *cfg, PROBMOD *ret_icfg)
{
   int   i, j;

  for (i = 0; i < ECOUNT; i++) {
     ret_icfg->emissions[i] = asLog(cfg->emissions[i]);
  }
  for (i = 0; i < NDPS; i++) {
     for (j = 0; j < NTRANS; j++) {
	if (Rules[grammar][i][j]) {
	   ret_icfg->transitions[j] = asLog(cfg->transitions[j]);
	}
     }
  }
}

/* Function: LogifySCFG()
 * Date: Fri Feb 28 12:16:44 CST 2003 [I-44 mile 39, MO]
 *
 * Purpose:  Take an SCFG and convert it to integer log form
 *           for an alignment.
 *
 * Notes: Both cfg and icfg must already be allocated.
 *
 * Args:     cfg  - the grammar, floating point form
 * 	    icfg  - the grammar, integer log form
 *
 * Return:   integer log form of the grammar
 */
void
LogifySCFG(int grammar, PROBMOD *cfg, INTMOD *ret_icfg)
{
  int   i, j;

  for (i = 0; i < ECOUNT; i++) {
     ret_icfg->emissions[i] = asIntLog(cfg->emissions[i]);
  }
  for (i = 0; i < NDPS; i++) {
     for (j = 0; j < NTRANS; j++) {
	if (Rules[grammar][i][j]) {
	   ret_icfg->transitions[j] = asIntLog(cfg->transitions[j]);
	}
     }
  }
}

/* Function: InvLogifySCFG()
 * Fri Feb 28 12:19:37 CST 2003 [I-44 mile 36, MO]
 *
 * Purpose:  Take an SCFG and convert it from integer log form 
 * 	to probability form.  This is the direct inverse of
 * 	LogifySCFG.
 *
 * Notes: Both cfg and icfg must already be allocated.
 *
 * Args:     cfg  - the grammar, floating point form
 * 	    icfg  - the grammar, integer log form
 *
 * Return:   integer log form of the grammar
 */
void
InvLogifySCFG(int grammar, INTMOD *cfg, PROBMOD *ret_icfg)
{
  int   i, j;

  for (i = 0; i < ECOUNT; i++) {
     ret_icfg->emissions[i] = asFloatProb(cfg->emissions[i]);
  }
  for (i = 0; i < NDPS; i++) {
     for (j = 0; j < NTRANS; j++) {
	if (Rules[grammar][i][j]) {
	   ret_icfg->transitions[j] = asFloatProb(cfg->transitions[j]);
	}
     }
  }
}

void
InvDLogifySCFG(int grammar, PROBMOD *cfg, PROBMOD *ret_icfg)
{
  int   i, j;

  for (i = 0; i < ECOUNT; i++) {
     ret_icfg->emissions[i] = asProb(cfg->emissions[i]);
  }
  for (i = 0; i < NDPS; i++) {
     for (j = 0; j < NTRANS; j++) {
	if (Rules[grammar][i][j]) {
	   ret_icfg->transitions[j] = asProb(cfg->transitions[j]);
	}
     }
  }

}

/* Function: ProbifySCFG()
 * Date: Fri Feb 28 12:23:43 CST 2003 [I-44 mile 30, MO]
 * 
 * Purpose:  Convert a model from counts to probabilities
 * 
 * Note: We do all our conversions into a local PROBMOD and then
 * 	copy this back to the return variable so that we can use
 * 	the same PROBMOD to contain counts and return value without
 * 	risking data integrity problems.
 * 
 * Args:     
 *      grammar	 grammar of choice
 *      icfg     counts form of parameters
 *      prior    prior to add to counts (NULL uses +1)
 *      tie	 do we want to tie (symmetry)?
 *      ret_cfg  probabilistic form of parameters
 *                
 * Returns:  nothing.
 */
void
ProbifySCFG(int grammar, PROBMOD *icfg, INTMOD *prior, int tie, PROBMOD *ret_cfg) 
{
   PROBMOD cfg;

   allocFmod(&cfg);

   if (prior == NULL) plusOnePriorD(icfg); 
   else addPrior(grammar, icfg, prior, &cfg); 

   if (tie) {	/* Anything but NOTIE */
     if ((tie == CTTIE) || (tie == OETIE)) {	/* Specifically use Gap Version */
       tieGTransitions(grammar, icfg);
     } else if (tie == LRTIE) {
       tieLRTransitions(grammar, icfg);
     } else {	/* DPTIE */
       tieXYTransitions(grammar, icfg);
     }
     tieXYEmissions(icfg);
   }

   probifyEmissions(icfg, &cfg);
   probifyTransitions(grammar, icfg, &cfg);
   /* printFmodel(stdout, &cfg); */

   if (tie == OETIE) {
     printf("Hard Tie\n");
     tieOETransitions(grammar, &cfg);
   }

   /* printFmodel(stdout, &cfg); */

   copyFmod(&cfg, ret_cfg);
   freeFmod(&cfg);
}

/* Function: addPrior()
 * Date: Thu Sep 30 15:45:11 CDT 2004 [St Louis]
 * 
 * Purpose:  
 *   Add a prior (here as ints) to counts (here as floats)
 * 
 * Args:     
 *      icfg     counts form of parameters
 *      prior    + constant (usually 1) for prior
 *      ret_cfg  counts + priors (allocated elsewhere)
 *                 
 * Returns:  nothing.
 */
void
addPrior(int grammar, PROBMOD *icfg, INTMOD *prior, PROBMOD *ret_cfg)
{
  int   i, j;

  /* Pairs and Alignment converted to probs */
  for (i = 0; i < PAIR; i++) {
     for (j = 0; j < PAIR; j++) {
	ret_cfg->emissions[ePR(i,j)] = (double)(icfg->emissions[ePR(i,j)] 
	      + prior->emissions[ePR(i,j)]);
     }
     ret_cfg->emissions[eALP(i)] = (double)(icfg->emissions[eALP(i)] 
	   		+ prior->emissions[eALP(i)]);
  }
  /* Singles as a Probability */
  for (i = 0; i < ALPHA; i++) {
     ret_cfg->emissions[eSS(i)] = (double)(icfg->emissions[eSS(i)] 
	   + prior->emissions[eSS(i)]);
  }
  /* Transitions */
  for (i = 0; i < NDPS; i++) {		/* For each rule */
    /* Convert to probabilities */
    for (j=0; j < NTRANS; j++) {
      if (Rules[grammar][i][j]) 
	 ret_cfg->transitions[j] = (double)(icfg->transitions[j] 
	       + prior->transitions[j]);
    }
  }
}

/* Function: tieXYEmissions()
 * Date: Thu Sep 30 16:59:48 CDT 2004 [St Louis]
 * 
 * Purpose:  Force pairs and alignment matricies
 * 	to by symmetric.   
 *
 * Note: This way of making the matix
 * symmetric doubles the effective counts 
 * implied in the matrix.
 * 
 * Args:     
 *      icfg     counts form of parameters
 *                 
 * Returns:  -void-
 * changes counts in icfg to enforce symmetry
 */
void
tieXYEmissions(PROBMOD *icfg)
{
  int   i, j;
  PROBMOD cfg;

  allocFmod(&cfg);

  /* Counts for AC-CA are combined with CA-AC */
  for (i = 0; i < PAIR; i++) {
    for (j = 0; j < PAIR; j++) {
      cfg.emissions[ePR(i,j)] = icfg->emissions[ePR(i,j)] 
			+ icfg->emissions[ePR(j,i)]; 
    }
  }

  /* Counts for A-C are combined with C-A */
  for (i = 0; i < ALPHA; i++) {
    for (j = 0; j < ALPHA; j++) {
      cfg.emissions[eAL(i,j)] = icfg->emissions[eAL(i,j)] 
			+ icfg->emissions[eAL(j,i)];
    }
    /* Must copy this over so we don't loose it */
    cfg.emissions[eSS(i)] = icfg->emissions[eSS(i)];
  }
  /* Must copy this over too */
  for (i = 0; i < NTRANS; i++) {
    cfg.transitions[i] = icfg->transitions[i];
  }

  copyFmod(&cfg, icfg);
  freeFmod(&cfg);
}

/* Function: tieXYTransitions 
 * Date:     Thu Sep 30 17:00:52 CDT 2004 [St Louis]
 *
 * Purpose:  Force X and Y gap open transitions 
 * 	from same non-terminal to be tied.
 * 	
 * Args:     
 *      icfg     counts form of parameters
 *
 * Returns:  nothing.
 * changes counts in icfg to enforce symmetry
 */
void
tieXYTransitions(int grammar, PROBMOD *icfg)
{
  float sum;
  int count, i, j;

  for (i = 0; i < NDPS; i++) {	/* For each nonterminal */
    sum = 0.0;	count = 0;
    for (j = 0; j < NTRANS; j++) {	/* For each transition */
      if (Rules[grammar][i][j]) {
	/* Tie together all GapOpen transitions */
	if (GapOpen[Gtype[grammar]][j]) {
	  sum += icfg->transitions[j];
	  count++;
	} /* GapOpen */
      } /* Rules */
    } /* j */
    for (j = 0; j < NTRANS; j++) {	/* For each transition */
      if (Rules[grammar][i][j]) {
	/* Tie together all GapOpen transitions */
	if (GapOpen[Gtype[grammar]][j]) {
	  icfg->transitions[j] = sum / count;
	} /* GapOpen */
      } /* Rules */
    } /* j */
  } /* i */
}

/* Function: tieGTransitions 
 * Date:     Thu Sep 30 17:00:52 CDT 2004 [St Louis]
 *
 * Purpose:  Tie gap open and gap extend 
 * 	by counts
 * 	
 * Args:     
 *      icfg     counts form of parameters
 *
 * Returns:  nothing.
 * changes counts in icfg to enforce symmetry
 */
void
tieGTransitions(int grammar, PROBMOD *icfg)
{
  float sumGO, sumGE;
  int countGO, countGE, j;

  sumGO = sumGE = 0.0;	countGO = countGE = 0;
  for (j = 0; j < NTRANS; j++) {	/* For each transition */
    /* Tie together all GapOpen transitions */
    if (GapOpen[Gtype[grammar]][j]) {
      sumGO += icfg->transitions[j];
      countGO++;
    } /* GapOpen */
    if (GapExtend[Gtype[grammar]][j]) {
      sumGE += icfg->transitions[j];
      countGE++;
    } /* GapExtend */
  } /* j */
  for (j = 0; j < NTRANS; j++) {	/* For each transition */
    /* Tie together all GapOpen transitions */
    if (GapOpen[Gtype[grammar]][j]) {
      icfg->transitions[j] = sumGO / countGO;
    } /* GapOpen */
    if (GapExtend[Gtype[grammar]][j]) {
      icfg->transitions[j] = sumGE / countGE;
    } /* GapExtend*/
  } /* j */
}
/* Function: tieOETransitions 
 * Date:     Thu Sep 30 17:00:52 CDT 2004 [St Louis]
 *
 * Purpose:  Force PROBABILITIES of gap open 
 * 	and gap extend rules to be equal.
 * 	
 * Args:     
 *      icfg     parameters (as PROBS)
 *
 * Returns:  nothing.
 * changes icfg to enforce gap symmetry
 */
void
tieOETransitions(int grammar, PROBMOD *icfg)
{
  int i, j;
  float sumGO, sumGE;
  float unchanged;
  int countGO, countGE;
  float GOprob, GEprob;
  PROBMOD cfg;

  allocFmod(&cfg);

  /* Determine sum of probabilities for Gap Open & Gap Extend */
  sumGO = sumGE = 0.0;	countGO = countGE = 0;
  for (j = 0; j < NTRANS; j++) {	/* For each transition */
    if (GapOpen[Gtype[grammar]][j]) {
      sumGO += icfg->transitions[j];
      countGO++;
    } /* GapOpen */
    if (GapExtend[Gtype[grammar]][j]) {
      sumGE += icfg->transitions[j];
      countGE++;
    } /* GapExtend */
  } /* j */

  /* Determine Universal Gap Open/Extend probs */
  GOprob = sumGO/countGO;
  GEprob = sumGE/countGE;
 
  /* For each rule, renormalize, enforcing new
   * GO/GE probabilities */
  for (i = 0; i < NDPS; i++) {		/* For each rule */
    sumGO = sumGE = 0.0;	countGO = countGE = 0;
    /* Need to know how much of old prob is consumed */
    for (j = 0; j < NTRANS; j ++) {
      if (Rules[grammar][i][j]) {
	if (GapOpen[Gtype[grammar]][j]) {
	  sumGO += icfg->transitions[j];
	  countGO++;
	}
	if (GapExtend[Gtype[grammar]][j]) {
	  sumGE += icfg->transitions[j];
	  countGE++;
	}
      }
    }
    unchanged = (1. - sumGO - sumGE);

    /* Convert to probabilities */
    for (j=0; j < NTRANS; j++) {
      if (Rules[grammar][i][j]) {
	if (GapOpen[Gtype[grammar]][j]) {
	  cfg.transitions[j] = GOprob;
	} else if (GapExtend[Gtype[grammar]][j]) {
	  cfg.transitions[j] = GEprob;
	} else {
	  cfg.transitions[j] =  (1. - (countGO*GOprob) - (countGE*GEprob)) 
	    * (icfg->transitions[j] / unchanged) ;
	} /* Renormalize each rule */
      } /* if this trans is in this nonterminal */
    } /* for all transitions */
  } /* for all NP */

  /* Must copy this over too */
  for (i = 0; i < ECOUNT; i++) {
    cfg.emissions[i] = icfg->emissions[i];
  }
  printFmodel(stdout, &cfg);

  copyFmod(&cfg, icfg);
  freeFmod(&cfg);
}

/* Function: tieLRTransitions 
 * Date:     Thu Sep 30 17:00:52 CDT 2004 [St Louis]
 *
 * Purpose:  Force PROBABILITIES of 
 * 	Lx and Ly rules to be equal and
 * 	Rx and Ry rules to be equal.
 * 	
 * Args:     
 *      icfg     parameters (as PROBS)
 *
 * Returns:  nothing.
 * changes icfg to enforce gap symmetry
 */
void
tieLRTransitions(int grammar, PROBMOD *icfg)
{
  float sumGO;
  int countGO, i, j;
  PROBMOD cfg;

  allocFmod(&cfg);

  sumGO = 0.0;	countGO = 0;
  for (j = 0; j < NTRANS; j++) {	/* For each transition */
    /* Tie together all GapOpen transitions */
    if (GapOpen[Gtype[grammar]][j]) {
      sumGO += icfg->transitions[j];
      countGO++;
    } /* GapOpen */
  } /* j */
  for (j = 0; j < NTRANS; j++) {	/* For each transition */
    /* Tie together all GapOpen transitions */
    if (GapOpen[Gtype[grammar]][j]) {
      cfg.transitions[j] = sumGO / countGO;
    } else {
      cfg.transitions[j] = icfg->transitions[j];
    }
  } /* j */

  /* THIS IS REALLY BAD.  THIS SHOULDN'T USE HARD NUMBERS 
   * We need a better way to say "tie these together"
   * THIS IS EXPLICITLY FOR STA!
   * */
  for (j = 10; j < 14; j++) {
    cfg.transitions[j] = (icfg->transitions[j] + icfg->transitions[j+4])/2;
    cfg.transitions[j+4] = (icfg->transitions[j] + icfg->transitions[j+4])/2;
  }
  for (j = 18; j < 22; j++) {
    cfg.transitions[j] = (icfg->transitions[j] + icfg->transitions[j+4])/2;
    cfg.transitions[j+4] = (icfg->transitions[j] + icfg->transitions[j+4])/2;
  }
  /* Must copy this over to avoid lose it.*/
  for (i = 0; i < ECOUNT; i++) {
    cfg.emissions[i] = icfg->emissions[i];
  }
 
  copyFmod(&cfg, icfg);
  freeFmod(&cfg);
}

/* Function: probifyEmissions()
 * Date: Fri Feb 28 12:25:46 CST 2003 [I-44 mile 29, MO]
 * 
 * Purpose:  Properly convert counts to probabilities
 *           for singles and pair emissions
 * 
 * Args:     
 *      icfg     counts form of parameters
 *      ret_cfg  probabilistic form of parameters
 *                 
 * Returns:  nothing.
 */
void
probifyEmissions(PROBMOD *icfg, PROBMOD *ret_cfg)
{
  int   i, j;
  float dpair, dalign;	/* denominators */

  dpair = dalign = 0.0; 
  /* Denominators */
  for (i = 0; i < PAIR; i++) {
     for (j = 0; j < PAIR; j++) {
	dpair += icfg->emissions[ePR(i,j)];
     }
     dalign += icfg->emissions[eALP(i)];
  }
  /* Pairs and Alignment converted to probs */
  for (i = 0; i < PAIR; i++) {
     for (j = 0; j < PAIR; j++) {
	ret_cfg->emissions[ePR(i,j)] = ((double)icfg->emissions[ePR(i,j)])
	  		/ ((double)dpair);
     }
     ret_cfg->emissions[eALP(i)] = ((double)icfg->emissions[eALP(i)])
       			/ ((double)dalign);
  }
  dpair = 0;
  /* Singles Denominator */
  for (i = 0; i < ALPHA; i++) {
     dpair += icfg->emissions[eSS(i)];
  }
  /* Singles as a Probability */
  for (i = 0; i < ALPHA; i++) {
     ret_cfg->emissions[eSS(i)] = (double)icfg->emissions[eSS(i)] 
	   		/ (double)dpair;
  }
}

/* Function: probifyTransitions
 * Date:     Fri Feb 28 12:33:10 CST 2003 [I-44 mile 21, MO]
 *
 * Purpose:  Properly convert counts to probabilities
 *           for transitions of Unambiguous Nussinov grammar
 *
 * Args:     
 *      icfg     counts form of parameters
 *      ret_cfg  probabilistic form of parameters
 *
 * Returns:  nothing.
 */
void
probifyTransitions(int grammar, PROBMOD *icfg, PROBMOD *ret_cfg)
{
   float denom;
   int i, j;

  for (i = 0; i < NDPS; i++) {		/* For each rule */
    denom = 0.0;
    /* Calculate the denominator */
    for (j = 0; j < NTRANS; j ++) {
      if (Rules[grammar][i][j]) denom += icfg->transitions[j];
    }
    /* Convert to probabilities */
    for (j=0; j < NTRANS; j++) {
      if (Rules[grammar][i][j]) 
	 ret_cfg->transitions[j] = (double)icfg->transitions[j] 
	   			/ (double) denom;
    }
  }
}
