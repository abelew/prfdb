/* nus_pt_main.c */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"
#include"stats.h"

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-m <file>     : Use parameters, grammar and scoring specified in model <file> \n\
-g <string>   : Use grammar <string>, defaults to NUS; ignored if model file specified \n\
-s <file>     : save model file to <file> \n\
-o <file>     : redirect output to <file>\n\
-x            : print out parameters of model \n\
-d            : debugging output \n\
-v            : verbose output \n\
";
static char usage[]  = "Usage: pertest [-options] <seqfile in>\n"; 

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/ 
  int   optid; 
  OPTS settings;
  int rule, transition, sign, perper, numfiles;
   
  /* Models info */
  MODEL nusmodel;
  MODEL permmodel;
  STATS stats;
  char label[20];

  if (!(ProcessOpts(&settings, &optid, argc, argv, usage, gramdesc, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  } 
	      
  if (argc - optid < 1)
    Die("Incorrect number of command line arguments.\n%s\n%s\n", 
		    	usage, optsline);
	          
  SetupModel(&settings, &nusmodel);
  if (!(settings.useprob)) 
    Die("Must be using a training set or saved probabilistic model!\n%s\n%s\n",
		    usage, optsline);
		      
  /* Digitize Setup */
  SetAlphabet(hmmNUCLEIC);
  settings.permutatetype = PER;

  if (settings.verbose) PrintProbModel(settings.ofp, &(nusmodel.probs), nusmodel.grammar);

  for (perper = 1; perper <= 30; perper ++) {
    fprintf(settings.ofp, "Permutation specified: ");
    settings.percentage = perper;
    printf("percent %d%%\n", settings.percentage);
    numfiles = optid;

    while (!(argc - numfiles < 1)) {
      fprintf(settings.ofp, "\nPerforming permutation test on %s\n", argv[numfiles]);
      PrintTableHeader();
      gatherStats(argv[numfiles], &settings, &nusmodel, &stats, usage);
      PrintTableLine("Normal  (none)", stats, FALSE);
      for (rule = 0; rule < NDPS; rule ++) {
	for (transition = 0; transition < NTRANS; transition++) {
	  /* sign = 0 is FALSE; sign = 1 is true */
	  for (sign = 0; sign < 2; sign ++) {
	    /* For each rule -- permutate and run all tests */
	    if (Rules[settings.grammar][rule][transition]) {
	      PermutateParameter(&nusmodel, rule, transition, sign, settings, &(permmodel.probs));
	      gatherStats(argv[numfiles], &settings, &permmodel, &stats, usage);
	      if (sign == FALSE) {
		sprintf(label, "%s (%s) +", dpNAME[rule], dptNAME[settings.grammar][transition]);
	      } else {
		sprintf(label, "%s (%s) -", dpNAME[rule], dptNAME[settings.grammar][transition]);
	      }
	      PrintTableLine(label, stats, FALSE);
	    } /* If this transition is legal in this rule */
	  } /* For each possible sign of delta */
	} /* For each transition */
      } /* For each rule */
      fprintf(settings.ofp, "End permutation test on %s\n\n", argv[numfiles]);
      numfiles++;
    } /* end while more test files */
  } /* End permute different percentages (perper) */
}
