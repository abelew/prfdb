/* gr_dist.c
 * RDD, Tue Aug 21 15:33:15 2001
 *
 * For each DP algorithm (CYK, Inside, Outside) we have to
 * select a grammar specific version of initalization,
 * fill, and traceback.  In addition for posterior calculations
 * and training functions.
 *
 * Distribution functions (switches to grammar specific
 * versions of these functions):
 *
 * 	InitMx [CYK, conditional CYK, Inside, conditional Inside, Outside]
 * 	FillMx [CYK, conditional CYK, Inside, conditional Inside, Outside]
 * 	TraceMx [CYK, Inside]
 *
 * Each grammar has grammar specific versions of these functions 
 * in the grammar's code file.  See grammar.h for listings.
 *
 * These implementations assume a digitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include "squid.h"
#include "cfg.h"
#include "trace.h"
#include "grammars.h"

void outsideInitMxDef(int ***mxo, int len);

/*********************** CYK **********************************/

/* Function: cykInitMx
 * Date:     RDD, Fri Oct 12 13:56:34 2001 [St. Louis]
 *   
 * Purpose:  Initialize CYK fill matrix (distribution function)
 * 	This function calls the appropriate grammar specific
 * 	version.
 * 
 * Args:     
 * 	mx	fill matrix (integer log odds form)
 * 	model	parameters of model as integers
 * 	rna	sequence, digitized
 *      len	sequence length
 *      grammar which grammar to utilize
 *      
 * Returns:  
 * 	TRUE if successful
 * 	FALSE if detected an error
 */
int
cykInitMx(int ***mx, INTMOD *model, char *rna, int len, int grammar) 
{
   switch (grammar) {
      case NUS: cykInitNUS(mx, model, rna, len); break;
      case IVO: cykInitIVO(mx, model, rna, len); break;
      case BJK:
      case BK2: cykInitBJK(mx, model, rna, len); break;
      case YRN: cykInitYRN(mx, model, rna, len); break;
      case UNA: cykInitUNA(mx, model, rna, len); break;
      case UYN: cykInitUYN(mx, model, rna, len); break;
      case RUN: cykInitRUN(mx, model, rna, len); break;
      case RYN: 
      case RY2:
      case RY3: cykInitR(mx, model, rna, len, grammar); break;
      case BRY: cykInitB(mx, model, rna, len); break;
      case AYN:
      case AY2: cykInitA(mx, model, rna, len); break;
      case RZK: cykInitRZK(mx, model, rna, len); break;
      default:
         return FALSE;
	 break;
   }
  return TRUE;
}

/* Function: cykFillMx
 * Date:     Fri Oct 12 09:10:06 CDT 2001 [St Louis]
 * 
 * Purpose:  Fills CYK matrix for any specified grammar
 * 	This function calls the appropriate grammar specific
 * 	version.
 * 
 * Assumption: Fill matrix already allocated and initialized
 * 
 * Args:    
 * 	mx	matrix to calculate cyk (as integer log Probs)
 *      sc	parameters 
 *      	(integer log form or as scores)
 *      rna	sequence (digitized)
 *      len	sequence length
 *      grammar which grammar to utilize
 *
 * Returns:  
 * 	TRUE if successful
 * 	FALSE if detected an error
 */
int
cykFillMx (int ***mx, INTMOD *pr, char *rna, int len, int grammar) 
{
  switch (grammar) {
     case NUS: cykFillNUS(mx, pr, rna, len); break;
     case IVO: cykFillIVO(mx, pr, rna, len); break;
     case BJK: cykFillBJK(mx, pr, rna, len, BJK); break;
     case BK2: cykFillBJK(mx, pr, rna, len, BK2); break;
     case UNA: cykFillUNA(mx, pr, rna, len); break;
     case RUN: cykFillRUN(mx, pr, rna, len); break;
     case RYN:
     case RY2:
     case RY3: cykFillR(mx, pr, rna, len, grammar); break;
     case YRN: cykFillYRN(mx, pr, rna, len); break;
     case UYN: cykFillUYN(mx, pr, rna, len); break;
     case BRY: cykFillB(mx, pr, rna, len, grammar); break;
     case AYN:
     case AY2: cykFillA(mx, pr, rna, len, grammar); break;
     case RZK: cykFillRZK(mx, pr, rna, len); break;
     default: return FALSE;
	break;
  }
  return TRUE;
}

/* Function: cykTraceMx 
 * Date:     RDD, Mon Aug 27 13:44:16 2001 [St. Louis]
 * 
 * Purpose:  Build traceback tree for grammars
 * 	This function calls the appropriate grammar specific
 * 	version.
 * 
 * Args:
 * 	mx	matrix in which to calculate cyk
 *      pr	parameters in integer form
 *      rna	sequence 
 *      len	sequence length
 *      
 * Returns: 
 * 	pointer to head of resulting traceback tree
 * 	is NULL if an error occured.
 */
struct trace_s *
cykTraceMx (int ***mx, INTMOD *pr, char *rna, int len, int grammar)
{
  struct trace_s *tr;

  tr = NULL;
  switch (grammar) {
     case NUS: tr = cykTraceNUS(mx, pr, rna, len); break;
     case IVO: tr = cykTraceIVO(mx, pr, rna, len); break;
     case BJK: tr = cykTraceBJK(mx, pr, rna, len, BJK); break;
     case BK2: tr = cykTraceBJK(mx, pr, rna, len, BK2); break;
     case UNA: tr = cykTraceUNA(mx, pr, rna, len); break;
     case RUN: tr = cykTraceRUN(mx, pr, rna, len); break;
     case RYN:
     case RY2:
     case RY3: tr = cykTraceR(mx, pr, rna, len, grammar); break;
     case YRN: tr = cykTraceYRN(mx, pr, rna, len); break;
     case UYN: tr = cykTraceUYN(mx, pr, rna, len); break;
     case BRY: tr = cykTraceB(mx, pr, rna, len, grammar); break;
     case AYN:
     case AY2: tr = cykTraceA(mx, pr, rna, len, grammar); break;
     case RZK: tr = cykTraceRZK(mx, pr, rna, len); break;
     default: return NULL;
	break;
  }
  return (tr);
}

/********************** TRACE ***********************/
/* Function: traceCount
 * Date:     RDD, Wed Oct  3 20:48:17 2001 [St. Louis]
 * 
 * Purpose: add the state transitions of a traceback 
 *          to a current counts form SCFG
 * 		(modeled after TraceCount in yarn)
 *
 * This function calls the appropriate grammar specific version.
 *
 * Args:     
 *       seq   - sequence corresponding to the trace
 *       len   - length of the sequence
 *       wgt   - weight on the sequence (typically 1.0)
 *       tr    - traceback to count
 *       cfg   - model, counts form, to add counts to
 *	grammar - which grammar to use
 * 
 * Returns: 
 *    	TRUE on success; FALSE on failure
 */
int 
traceCount(char *seq, int len, int wgt, struct trace_s *tr, INTMOD *cfg, int grammar)
{
  switch (grammar) {
     case NUS:
     case UNA: 
     case YRN:
     case UYN: analyzeTraceN(seq, len, tr, cfg, TRUE); break;
     case IVO: analyzeTraceIVO(seq, len, tr, cfg, TRUE); break;
     case BJK: analyzeTraceBJK(seq, len, tr, cfg, BJK, TRUE); break;
     case BK2: analyzeTraceBJK(seq, len, tr, cfg, BK2, TRUE); break;
     case RUN:
     case RYN: analyzeTraceR(seq, len, tr, cfg, TRUE); break;
     case RY2:
     case RY3: analyzeTraceR2(seq, len, tr, cfg, grammar, TRUE); break;
     case BRY: analyzeTraceB(seq, len, tr, cfg, TRUE);  break;
     case AYN:
     case AY2: analyzeTraceA(seq, len, tr, cfg, TRUE); break;
     case RZK: analyzeTraceRZK(seq, len, tr, cfg, TRUE); break;
     default: return FALSE;
	break;
  }
  return TRUE;
}

/* Function: traceScore
 * Date:     RDD, Tue May 14 16:15:37 CDT 2002 [St Louis]
 * 
 * Purpose:  Calculate the score of a traceback,
 *           given an integer log-odds form SCFG
 *          (modeled after TraceScore in yarn)
 *
 * This function calls the appropriate grammar specific version.
 *
 * Args:     
 *       seq   - sequence corresponding to the trace
 *       len   - length of the sequence
 *       tr    - traceback to count
 *       cfg   - model, counts form, to add counts to
 *	grammar - which grammar to use
 *  	ret_score - score to return 
 * 
 * Returns:  
 *    	TRUE on success; FALSE on failure
 */
int
traceScore(char *seq, int len, struct trace_s *tr, INTMOD *cfg, 
      int grammar, int *ret_score)
{
  switch (grammar) {
     case NUS:
     case UNA:
     case YRN:
     case UYN: *ret_score = (analyzeTraceN(seq, len, tr, cfg, FALSE)); break;
     case IVO: *ret_score = (analyzeTraceIVO(seq, len, tr, cfg, FALSE)); break;
     case BJK: *ret_score = (analyzeTraceBJK(seq, len, tr, cfg, BJK, FALSE)); break;
     case BK2: *ret_score = (analyzeTraceBJK(seq, len, tr, cfg, BK2, FALSE)); break;
     case RUN:
     case RYN: *ret_score = (analyzeTraceR(seq, len, tr, cfg, FALSE)); break;
     case RY2:
     case RY3: *ret_score = (analyzeTraceR2(seq, len, tr, cfg, grammar, FALSE)); break;
     case BRY: *ret_score =  analyzeTraceB(seq, len, tr, cfg, FALSE); break;
     case AYN:
     case AY2: *ret_score = analyzeTraceA(seq, len, tr, cfg, FALSE); break;
     case RZK: *ret_score = analyzeTraceRZK(seq, len, tr, cfg, FALSE); break;
     default: return FALSE;
	break;
  }
  return TRUE;
}

/* Function: dTraceScore
 * Date:     Mon Oct 27 17:05:08 CST 2003 [St Louis]
 * 
 * Purpose:  Calculate the score of a traceback,
 *           given an float log-odds form SCFG
 *
 * This function calls the appropriate grammar specific version.
 *
 * Args:     
 *       seq   - sequence corresponding to the trace
 *       len   - length of the sequence
 *       tr    - traceback to count
 *       cfg   - model in float log form
 *	grammar - which grammar to use
 *  	ret_score - score to return 
 * 
 * Returns:  
 *    	TRUE on success; FALSE on failure
 */
int
dTraceScore(char *seq, int len, struct trace_s *tr, PROBMOD *cfg, 
      int grammar, double *ret_score)
{
   double score;

  switch (grammar) {
     case NUS:
     case UNA:
     case YRN:
     case UYN: dTraceScoreN(seq, len, tr, cfg, &score); break;
     case IVO: dTraceScoreIVO(seq, len, tr, cfg, &score); break;
     case BJK: 
     case BK2: dTraceScoreBJK(seq, len, tr, cfg, grammar, &score); break;
     case RUN:
     case RYN: dTraceScoreR(seq, len, tr, cfg, &score); break;
     case RY2:
     case RY3: dTraceScoreR2(seq, len, tr, cfg, grammar, &score); break;
     case BRY: dTraceScoreB(seq, len, tr, cfg, &score); break;
     case AYN:
     case AY2: dTraceScoreA(seq, len, tr, cfg, &score); break;
     default: return FALSE;
	break;
  }
  *ret_score = score;
  return TRUE;
}


/* Function: khs2trace()
 *
 *  Purpose:  Create a trace structure from a KH structure
 *             string. This is very similar to tracebacks
 *             of a dynamic programming matrix.
 * 
 *  This function calls the appropriate grammar specific version.
 *  
 *  Args:     
 *  	dolist  - stack in progress of traceback
 *  	ct 	- structure
 *      grammar - describes which grammar to assume
 *   
 *  Return:   1 on success, 0 on failure.
 *            Caller frees ret_tr with FreeTrace().
 */ 
int
khs2trace(struct tracestack_s *dolist, int *ct, int len, int grammar, int tolerate)
{
   int valid;

   valid = TRUE;

   switch (grammar) {
      case NUS: 
	 valid = khs2traceNUS(dolist, ct);
	 break;
      case IVO: 
	 valid = khs2traceIVO(dolist, ct);
	 break;
      case BJK: 
      case BK2: 
	 valid = khs2traceBJK(dolist, ct);
	 break;
      case YRN: 
	 valid = khs2traceYRN(dolist, ct);
	 break;
      case UNA: 
	 valid = khs2traceUNA(dolist, ct);
	 break;
      case UYN: 
	 valid = khs2traceUYN(dolist, ct, tolerate);
	 break;
      case RUN: 
	 valid = khs2traceRUN(dolist, ct);
	 break;
      case RYN: 
	 valid = khs2traceRYN(dolist, ct);
	 break;
      case RY2: 
	 valid = khs2traceRY2(dolist, ct);
	 break;
      case RY3: 
	 valid = khs2traceRY3(dolist, ct, tolerate);
	 break;
      case BRY: 
	 mismatch_label(ct, len);	/* convert 1 pair IL to mismatches */
	 valid = khs2traceBRY(dolist, ct, grammar);
	 break; 
      case AYN: 
      case AY2: 
	 valid = khs2traceAYN(dolist, ct, grammar);
	 break;
      case RZK: 
	 valid = khs2traceRZK(dolist, ct);
	 break;
      default: break;
   }

   return (valid);
}
/*********************** INSIDE **********************************/

/* Function: insideInitMx
 * Date:     RDD, Fri Oct 12 13:56:34 2001 [St. Louis]
 *   
 * Purpose:  Initialize CYK fill matrix (distribution function)
 * 	This function calls the appropriate grammar specific
 * 	version.
 * 
 * Args:     
 * 	mx	fill matrix (integer log odds form)
 * 	model	parameters of model as integers
 * 	rna	sequence, digitized
 *      len	sequence length
 *      grammar which grammar to utilize
 *      
 * Returns:  
 * 	TRUE if successful
 * 	FALSE if detected an error
 */
int
insideInitMx(double ***mx, PROBMOD *model, char *rna, int len, int grammar) 
{
  switch (grammar) {
     case NUS: insideInitNUS(mx, model, rna, len); break;
     case UNA: insideInitUNA(mx, model, rna, len); break;
     case YRN: insideInitYRN(mx, model, rna, len); break;
     default: return FALSE;
	break;
  }
  return TRUE;
}


/* Function: insideFillMx
 * Date:     Fri Oct 12 09:10:06 CDT 2001 [St Louis]
 * 
 * Purpose:  Fills CYK matrix for any specified grammar
 * 	This function calls the appropriate grammar specific
 * 	version.
 *
 * Assumption: Fill matrix already allocated and initialized
 * 
 * Args:    
 * 	mx	matrix to calculate inside (as integer log Probs)
 *      pr	parameters (integer log form or as scores)
 *      rna	sequence (digitized)
 *      len	sequence length
 *      grammar which grammar to utilize
 *
 * Returns:  
 * 	TRUE if successful
 * 	FALSE if detected an error
 */
int
insideFillMx(double ***mx, PROBMOD *pr, char *rna, int len, int grammar) 
{
  switch (grammar) {
     case NUS: insideFillNUS(mx, pr, rna, len); break;
     case UNA: insideFillUNA(mx, pr, rna, len); break;
     case YRN: insideFillYRN(mx, pr, rna, len); break;
     default: return FALSE;
	break;
  }
  return TRUE;
}

/* Function: condInsInitMx
 * Date:     RDD, Tue Oct  1 13:39:04 CDT 2002 [St Louis]
 *   
 * Purpose:  Initialize cond Inside fill matrix (distribution function)
 * 	This function calls the appropriate grammar specific
 * 	version.
 * 
 * Args:     
 * 	mx	fill matrix (integer log odds form)
 * 	model	parameters of model as integers
 * 	rna	sequence, digitized
 *      len	sequence length
 *      ss       secondary structure in ctformat 
 *      grammar which grammar to utilize
 *      
 * Returns:  
 * 	TRUE if successful
 * 	FALSE if detected an error
 */
int
condInsInitMx(double ***mx, PROBMOD *model, char *rna, int len, int *ss, int grammar) 
{
  switch (grammar) {
     case NUS: cinsInitNUS(mx, model, rna, len, ss); break;
     case UNA: cinsInitUNA(mx, model, rna, len, ss); break;
     case YRN: cinsInitYRN(mx, model, rna, len, ss); break;
     case IVO: cinsInitIVO(mx, model, rna, len); break;
     case BJK: 
     case BK2: cinsInitBJK(mx, model, rna, len); break;
     case RUN: cinsInitRUN(mx, model, rna, len); break;
     case RYN: 
     case RY2: 
     case RY3: cinsInitR(mx, model, rna, len, grammar); break;
     case UYN: cinsInitUYN(mx, model, rna, len); break;
     case BRY: cinsInitBRY(mx, model, rna, len); break;
     case AYN: 
     case AY2: cinsInitA(mx, model, rna, len, grammar); break;
     default: return FALSE;
	break;
  }
  return TRUE;
}
/* Function: condInsFillMx
 * Date:     Tue Oct  1 13:40:44 CDT 2002 [St Louis]
 * 
 * Purpose:  Fills CYK matrix for any specified grammar
 * 	This function calls the appropriate grammar specific
 * 	version.
 *
 * Assumption: Fill matrix already allocated and initialized
 * 
 * Args:    
 * 	mx	matrix to calculate inside (as integer log Probs)
 *      pr	parameters (integer log form or as scores)
 *      rna	sequence (digitized)
 *      len	sequence length
 *      ss	Secondary structure to condition upon
 *      grammar which grammar to utilize
 *
 * Returns:  
 * 	TRUE if successful
 * 	FALSE if detected an error
 */
int
condInsFillMx(double ***mx, PROBMOD *pr, char *rna, int len, int *ss, int grammar) 
{
  switch (grammar) {
     case NUS: cinsFillNUS(mx, pr, rna, len, ss); break;
     case UNA: cinsFillUNA(mx, pr, rna, len, ss); break;
     case YRN: cinsFillYRN(mx, pr, rna, len, ss); break;
     case IVO: cinsFillIVO(mx, pr, rna, len, ss); break;
     case BJK: cinsFillBJK(mx, pr, rna, len, BJK, ss); break;
     case BK2: cinsFillBJK(mx, pr, rna, len, BK2, ss); break;
     case RUN: cinsFillRUN(mx, pr, rna, len, ss); break;
     case RYN: 
     case RY2: 
     case RY3: cinsFillR(mx, pr, rna, len, grammar, ss); break;
     case UYN: cinsFillUYN(mx, pr, rna, len, ss); break;
     case BRY: cinsFillBRY(mx, pr, rna, len, ss); break;
     case AYN: 
     case AY2: cinsFillA(mx, pr, rna, len, grammar, ss); break;
     default: return FALSE;
	break;
  }
  return TRUE;
}

int 
generate_RNA(PROBMOD *pr, char **rna, char **ss, int grammar)
{
   int length;

   switch (grammar) {
     case BJK: length = generateBJK(pr, rna, ss); break;
     default: return -1;
	break;
  }
  return (length);
}

/********************* Suboptimals *************************/
/* Function: insideTraceMx 
 * Date:     Thu Oct  3 15:42:11 CDT 2002 [St Louis]
 * 
 * Purpose:  Build traceback tree for grammars' 
 * 	suboptimal routine.
 * 
 * Args:
 * 	mx	matrix (previously filled by Inside) 
 *      pr	parameters in integer form
 *      rna	sequence 
 *      len	sequence length
 *      
 * Returns: 
 * 	pointer to head of resulting traceback tree
 * 	is NULL if an error occured.
 */
struct trace_s *
insideTraceMx(double ***mx, PROBMOD *pr, char *rna, int len, int grammar)
{
  struct trace_s *tr;

  tr = NULL;
  switch (grammar) {
     case NUS: tr = insideTraceNUS(mx, pr, rna, len); break;
     case UNA: tr = insideTraceUNA(mx, pr, rna, len); break;
     case YRN: tr = insideTraceYRN(mx, pr, rna, len); break;
     default: return NULL;
	break;
  }
  return (tr);
}

/*********************** OUTSIDE **********************************/
/* Function: outsideInitMx
 * Date:     RDD, Tue Oct  1 13:39:04 CDT 2002 [St Louis]
 *   
 * Purpose:  Initialize cond Inside fill matrix (distribution function)
 * 	This function calls the appropriate grammar specific
 * 	version.
 * 
 * Args:     
 * 	mx	fill matrix (integer log odds form)
 * 	model	parameters of model as integers
 * 	rna	sequence, digitized
 *      len	sequence length
 *      ss       secondary structure in ctformat 
 *      grammar which grammar to utilize
 *      
 * Returns:  
 * 	TRUE if successful
 * 	FALSE if detected an error
 */
int
outsideInitMx(double ***mxo, int len, int grammar)
{
  switch (grammar) {
     case NUS: outsideInitNUS(mxo, len); break;
     case UNA: outsideInitUNA(mxo, len); break;
     case YRN: outsideInitYRN(mxo, len); break;
     default: return FALSE;
	break;
  }
  return TRUE;
}

void
outsideInitMxDef(int ***mxo, int len)
{
   int i,j,k;

   for (j=0; j < len ; j++) {
      for (i= 0; i < len; i++) {
	 for (k=0; k < NDPS; k++) {
	    mxo[i][j][k] = -BIGINT; 
	 }
      } /* end for j */
   } /* end for i */
   mxo[0][len-1][dpS] = 0;
}

/* Function: outsideFillMx
 * Date:     RDD, Wed Aug 21 13:42:13 CDT 2002 [St Louis]
 * 
 * Purpose:  Fills CYK matrix for any specified grammar
 * 	This function calls the appropriate grammar specific
 * 	version.
 * 
 * Assumption: Fill matrix already allocated and initialized
 * 
 * Args:    
 * 	mx	matrix to calculate outside (as integer log Probs)
 *      sc	parameters 
 *      	(integer log form or as scores)
 *      rna	sequence (digitized)
 *      len	sequence length
 *      grammar which grammar to utilize
 *
 * Returns:  
 * 	TRUE if successful
 * 	FALSE if detected an error
 */
int
outsideFillMx(double ***mxo, double ***mx, PROBMOD *pr, char *rna, int len, int grammar)
{
  switch (grammar) {
     case NUS: outsideFillNUS(mxo, mx, pr, rna, len); break;
     case UNA: outsideFillUNA(mxo, mx, pr, rna, len); break;
     case YRN: outsideFillYRN(mxo, mx, pr, rna, len); break;
     default: return FALSE;
	break;
  }
  return TRUE;
}

/* Function: coutFillMx
 * Date:     Fri Oct  4 19:55:22 CDT 2002 [St Louis]
 * 
 * Purpose:  Fills CYK matrix for any specified grammar
 * 	This function calls the appropriate grammar specific
 * 	version.
 * 
 * Assumption: Fill matrix already allocated and initialized
 * 
 * Args:    
 * 	mx	matrix to calculate outside (as integer log Probs)
 *      sc	parameters 
 *      	(integer log form or as scores)
 *      rna	sequence (digitized)
 *      len	sequence length
 *      grammar which grammar to utilize
 *
 * Returns:  
 * 	TRUE if successful
 * 	FALSE if detected an error
 */
int
coutFillMx(double ***mxo, double ***mx, PROBMOD *pr, char *rna, int len, 
      int *ss,  int grammar)
{
  switch (grammar) {
     case NUS: coutFillNUS(mxo, mx, pr, rna, len, ss); break;
     case UNA: coutFillUNA(mxo, mx, pr, rna, len, ss); break;
     case YRN: coutFillYRN(mxo, mx, pr, rna, len, ss); break;
     default: return FALSE;
	break;
  }
  return TRUE;
}


/********************* POSTERIORS ************************/

/* Function probXunpaired
 * Date: RDD, Tue Sep  3 21:03:27 CDT 2002 [St Louis]
 *
 * Purpose: Calculate the probability that Xi is unpaired
 * 	This function calls the appropriate grammar specific
 * 	version.
 *
 * Args:
 * 	i		First index - position under scrutiny
 * 	mx		Inside matrix -- filled
 * 	mxo		Outside Matrix -- filled
 *	rna		Sequence under study
 *	len		Length of said sequence
 *	model 		Parameters for this model
 *	grammar		Under which grammar
 *	ret_sc		Prob(x pairs y) as Int log sum
 *
 * Returns:
 * 	TRUE on success; FALSE on failure
 */
int
probXunpaired(int i, double ***mx, double ***mxo, char *rna, int len, 
      PROBMOD *model, int grammar, double *ret_sc)
{
  double score;

  switch (grammar) {
     case NUS: probXunpairedNUS(i,mx,mxo,rna,len,model,&score); break;
     case UNA: probXunpairedUNA(i, mx, mxo, rna, len, model, &score); break;
     case YRN: probXunpairedYRN(i,mx,mxo,rna,len,model,&score); break;
     default: return FALSE;
	break;
  }

  *ret_sc = score;
  return TRUE;
}


/* Function: probXYpair
 * Date: RDD, Tue Sep  3 21:00:58 CDT 2002 [St Louis]
 *
 * Purpose: Calculate the Probability that Xi pairs with Xj
 * 	This function calls the appropriate grammar specific
 * 	version.
 *
 * Args:
 * 	x		First index
 * 	y		second index
 * 	mx		Inside matrix -- filled
 * 	mxo		Outside Matrix -- filled
 *	rna		Sequence under study
 *	len		Length of said sequence
 *	model 		Parameters for this model
 *	grammar		Under which grammar
 *	ret_sc		Prob(x pairs y) as Int log sum
 *
 * Returns:
 * 	TRUE on success; FALSE on failure
 */
int
probXYpair(int x, int y, double ***mx, double ***mxo, char *rna, int len, 
      		PROBMOD *model, int grammar, double *ret_sc)
{
  double score;

  switch (grammar) {
     case NUS: probXYpairNUS(x,y,mx,mxo,rna,len,model,&score); break;
     case UNA: probXYpairUNA(x,y,mx,mxo,rna,len,model,&score); break;
     case YRN: probXYpairYRN(x,y,mx,mxo,rna,len,model,&score); break;
     default: return FALSE;
	break;
  }
  *ret_sc = score;
  return TRUE;
}

/********************** CML ***********************/
/* Function: calcNvals 
 * Date: Mon Oct 21 14:50:56 CDT 2002 [St Louis]
 *
 * Purpose: calculate the sum of posteriors (n_{ij}) 
 * 	for the transition parameters
 *
 * Note: Also calculates m_ij if the mx and mxo matricies
 * 	were conditionally calculated.
 *
 * Args:
 * 	mx	Inside matrix (precalculated)
 * 	mxo	Outside matrix (precalculated)
 * 	rna	sequence
 * 	len	length of said sequence
 * 	model	parameters of current model
 * 	grammar current grammar of choice
 * 	probseq P(x|model)
 *
 * Returns:
 * 	ret_nij	(Allocated elsewhere!)
 *   	1 on success; 0 on failure
 */
int
calcNvals(double ***mx, double ***mxo, char *rna, int len, PROBMOD *model, int grammar, 
      double probseq, PROBMOD *ret_nij)
{
   switch (grammar) {
     case NUS: calcNvalsNUS(mx, mxo, rna, len, model, probseq, ret_nij); break;
     case UNA: calcNvalsUNA(mx, mxo, rna, len, model, probseq, ret_nij); break;
     case YRN: calcNvalsYRN(mx, mxo, rna, len, model, probseq, ret_nij); break;
     default: return FALSE;
	break;
  }
  return TRUE;
}

