/* sample_main.c 
 *
 * Suboptimal experiment -- how many do I have
 * to generate to get a structure probability greater
 * than the CYK implied structural probability?
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"
#include"grammars.h"
#include"stats.h"

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-m <file>     : Use model <file> \n\
-b <int>      : Max num suboptimals to look at \n\
-x            : print out parameters of model \n\
-t            : print all parse trees (lots!) \n\
-d            : debugging output \n\
-v            : verbose output \n\
-f            : debugging, print fill matrix from cyk \n\
-p            : print real with predicted structure\n\
-q            : print predicted structures in stockholm format \n\
";

static char usage[]  = "Usage: findopt -b # [-options] <seqfile in>\n";

int 
main (int argc, char **argv) 
{
   /**** arguments variables *****/
   int   optid; 
   OPTS settings;

   /* ReadSeq variables */
   SQFILE *sqfp; SQINFO sqinfo;
   int sformat;
   char *rna, *drna; 

   /* Structures and Parse Tree variables */
   char *cykkhs, *subkhs;	/* KHS formatted structures */
   int *cykct, *subct;		/* CT formatted structures */
   /* Parse Trees and their scores: */
   struct trace_s *cyktrc;	/* Optimal parse tree */
   struct trace_s *subtrc;	/* A suboptimal parse tree */
   int cykparsescore;		/* Score of optimal parse */
   int subparsescore;		/* Score of suboptimal parse */
   /* These two are calculated by conditional Inside: */
   double cykstructscore;		/* Score of CYK structure prediction */
   double substructscore;		/* Score of suboptimal structure */

   double insidescore;			/* P(x|G, Theta) from Inside */

   /* Models info */
   MODEL nusmodel;
   PROBMOD dlogs;
   double ***matxCI;		/* Conditional Inside Matrix */
   double ***insmatx;		/* Full Inside Matrix */
   STATS checkvsCYK;

   /* Control & Checks variables */
   int noerror;		/* Boolean -- does subroutine finish correctly? */
   int found;		/* Boolean */
   int numsubopt, maxiter;
   int i, j, temp;

   if (!(ProcessOpts(&settings, &optid, argc, argv, usage, "\tfor NUS and YRN only!", optsline))) {
      printf("%s\n\n", usage);
      exit(0);
   }
   if (argc - optid != 1)
      Die("Incorrect number of command line arguments.\n%s\n%s\n", 
	    usage, optsline);

   SetupModel(&settings, &nusmodel);  
   DLogifySCFG(&(nusmodel.probs), &dlogs);
   LogifySCFG(&(nusmodel.probs), &(nusmodel.scores)); 

   if (settings.modelfile == NULL) {
      nusmodel.grammar = settings.grammar;
      SetUpFlatMx(&(nusmodel.probs), settings.grammar);
      LogifySCFG(&(nusmodel.probs), &(nusmodel.scores)); 
   }

   if (settings.debugg) PrintFullModel(settings.ofp, &nusmodel);

      /* Read input file into RNA array and filter for non-RNA residues */
   if ((sqfp = SeqfileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL) 
      Die("Failed to open sequence file %s\n%s\n", argv[optid], usage);

   maxiter = settings.percentage;	/* Maximum number of iterations */

   SetAlphabet(hmmNUCLEIC);
   srand(time(NULL)); 

   while (ReadSeq(sqfp, sformat, &rna, &sqinfo)) {
      ToRNA(rna);
      drna = DigitizeSequence(rna, sqinfo.len);

      if (settings.debugg) fprintf(settings.ofp, "Sequence %s:\n", sqinfo.name);

	/* Best prediction */
      cyktrc = (struct trace_s *)CYK(rna, sqinfo.len, settings.grammar, 
	      	      &(nusmodel.scores), &settings, &cykparsescore);

      if (cyktrc != NULL) {
	 trace2khs(cyktrc, rna, sqinfo.len, 1, &cykkhs);

	 if (! KHS2ct(cykkhs, sqinfo.len, FALSE, &cykct)) { 
	    printf("[bad predicted CYK structure]\n"); 
	    free(cykct);
	    return (FALSE);
	 }

	 /* Calculate P(structure, x | G, \Theta) : Conditional Inside */
	 noerror = Inside(rna, sqinfo.len, nusmodel.grammar, &dlogs,
	       &settings, cykct, &cykstructscore, &matxCI);
	 freeFillMxD(matxCI, nusmodel.grammar);

	 /* Need to check that we had no error there! */
      } else {
	 /* Hope we don't get here */
	 printf("CYK failed\n"); return (FALSE);
      }

      found = FALSE; numsubopt = 0;

      /* Calculate Inside Matrix */
      if (Inside(rna, sqinfo.len, settings.grammar, &dlogs, &settings, NULL, &insidescore, &insmatx)) {
	 while (!found && (numsubopt < maxiter)) {
	    /* Sample a suboptimal from Inside matrix */
	    subtrc = insideTraceMx(insmatx, &dlogs, drna, sqinfo.len, settings.grammar);
	    traceScore(rna, sqinfo.len, subtrc, &(nusmodel.scores), settings.grammar, &subparsescore);

	    /* Check suboptimal integrity */
	    trace2khs(subtrc, rna, sqinfo.len, 1, &subkhs);
	    if (! KHS2ct(subkhs, sqinfo.len, FALSE, &subct)) { 
	       /* If a bad structure is detected, treat it as impossible */
	       substructscore = -BIGINT;
	    } else {
	       /* Check suboptimal's structure probability */
	       noerror = Inside(rna, sqinfo.len, nusmodel.grammar, &dlogs,
		     &settings, subct, &substructscore, &matxCI);
	       freeFillMxD(matxCI, nusmodel.grammar);
	    }
	    if (substructscore > cykstructscore) {
	       /* Need to make sure this isn't just another parse from
		* the CYK optimal structure, which *might* happen because
		* of precision issues with floats ... */
	       ZeroStats(&checkvsCYK);
	       if (CompStruct(sqinfo.len, cykkhs, subkhs, &checkvsCYK, 
		     FALSE, FALSE, FALSE)) {
		  /* If these parses refer to the same structure then 
		   * the number correct will be equivalent to the
		   * trusted pairs. */
		  if (checkvsCYK.test_correct != checkvsCYK.trust_correct) {
		     found = TRUE;
		  } else {
		     if (settings.verbose) 
			printf("Found CYK structure again!\n");
		  }
	       }
	    } else {
	       numsubopt++;
	       /* Cleanup from this subopt */
               FreeTrace(subtrc);
               free(subkhs); free(subct);
	    }
	 }

	 if (found) {
	    /* Generate a report on the ones that are better */
	    printf("Suboptimal greater than CYK found for %s \n", sqinfo.name);
	    printf("%d \t %d \t CYK results \n", cykparsescore, (int)cykstructscore);
	    if (settings.istats) PrintTrace(stdout, cyktrc, rna);
	    PrintKHS(stdout, rna, &sqinfo, cykkhs);
	    printf("%d \t %d \t Better than CYK! (%d subopt) \n", subparsescore, (int)substructscore, numsubopt+1);
	    if (settings.istats) PrintTrace(stdout, subtrc, rna);
	    PrintKHS(stdout, rna, &sqinfo, subkhs);

	    /* If found then we still need to cleanup from last suboptimal */
	    free(subkhs); free(subct);
	 } else {
	    /* Generated limit and did't find one */
	    printf("No suboptimal parse found with structure probability > CYK in %d suboptimals\n", maxiter);
	 }
      } else {
	 /* Inside failed -- we don't want to be here either */
         freeFillMxD(insmatx, settings.grammar);
	 printf("Inside failed\n"); 
	 return (FALSE);
      }
      /* Lots to clean up */
      free(cykkhs); free(cykct); 
      freeFillMxD(insmatx, settings.grammar);
      FreeSequence(rna, &sqinfo);
      FreeTrace(cyktrc);
      free(drna);
   }
   SeqfileClose(sqfp);
   return TRUE;
}
