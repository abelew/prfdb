/* gr_azk.c
 * RDD, Wed May  8 11:19:20 CDT 2002
 *
 * Implementations of grammar specific routines for AYN 
 *
 * Affine Unambiguous Zuker:			(AYN)
 * 	S -> aS | T | end
 *      T -> Ta | aPa' | TaPa'
 *      P -> aPa' | x aPa' | aPa' x |
 *	     aNa' | x aNa' | aNa' x 
 *      N -> aaH | aaQ | Raa | aI | MT
 *      H -> aH | end
 *      Q -> aQ | aPa'
 *      R -> Ra | aPa'
 *      I -> aI | Ra
 *	M -> aM | R
 *
 * Variants:
 *      P -> aPa' | x aPa' | aPa' x | N		(AY2)
 *
 * These grammars separate hairpins from internal loops and bulges.  
 * They can uniquely identify these elements and therefore can utilize 
 * their unique emission probabilities.  
 *
 * These implementations assume a digitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"

/* Function: cykInitA
 * Date:     RDD, Wed Jan 23 08:28:44 CST 2002 [St Louis]
 *
 * Purpose:  Initialize CYK fill matrix for AYN and AY2 grammars 
 *
 * Args:     
 *	mx	fill matrix (integer log odds form)
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cykInitA(int ***mx, INTMOD *model, char *rna, int len)
{
   int j, d;

   for (d = 0; d <= len; d++) {
      for (j = d; j < len; j++) {
	 mx[dpS][j][d] = model->transitions[TSE];
	 mx[dpT][j][d] = -BIGINT;
	 mx[dpP][j][d] = -BIGINT;
	 mx[dpN][j][d] = -BIGINT;
	 mx[dpH][j][d] = model->transitions[THE];
	 mx[dpQ][j][d] = -BIGINT;
	 mx[dpR][j][d] = -BIGINT;
	 mx[dpI][j][d] = -BIGINT;
	 mx[dpM][j][d] = -BIGINT;
      }
      if (d > 0) {
	 mx[dpS][d-1][d] = model->transitions[TSE];
	 mx[dpT][d-1][d] = -BIGINT;
	 mx[dpP][d-1][d] = -BIGINT;
	 mx[dpN][d-1][d] = -BIGINT;
	 mx[dpH][d-1][d] = model->transitions[THE];
	 mx[dpQ][d-1][d] = -BIGINT;
	 mx[dpR][d-1][d] = -BIGINT;
	 mx[dpI][d-1][d] = -BIGINT;
	 mx[dpM][d-1][d] = -BIGINT;
      }
   }
}

/* Function: cykFillA
 * Date:    Tue Jan 22 15:01:41 CST 2002 [St Louis]
 *
 * Purpose:  Fills CYK matrix for AYN, AY2
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	sc	parameters 
 *		(integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
cykFillA(int ***mx, INTMOD *pr, char *rna, int len, int grammar)
{
  int d, i, j, k, m;       /* Loop indicies */
  int max;              /* Maximum value seen so far */
  int cursc, cursc2;    /* Current score */
  int stackvalue, emtemp;
  int tmp;

  /* Recursion */
  for (d = 1; d <= len; d++) {
     for (j = d-1; j < len; j++) {
	i = j - d + 1; max = -BIGINT;

	/* H -> aH */
	mx[dpH][j][d] = mx[dpH][j][d-1] + pr->singles[rna[i]] + pr->transitions[THH];

	/* T -> Ta */
	if (j > 0) {
	   cursc = mx[dpT][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TTT];
	   if (cursc > max) max = cursc;
	   /* T -> aPa' */
	   if (d > 1) {
	      cursc = mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TTP];
	      if ((cursc > max) && (d-1 > HLEN)) max = cursc; 
	   }
	}
	/* T -> T aPa' */
	for (k = i+1; k < j-1; k++) {
	   tmp = dist(k+2,j-1);
	   cursc = mx[dpT][k][dist(i,k)] + mx[dpP][j-1][tmp] + pr->pairs[rna[k+1]][rna[j]] 
	      				+ pr->transitions[TTB];
	   if ((cursc > max) && (tmp-1 > HLEN)) max = cursc; 
	} /* End for loop T -> T aSa' */
	/* T -> Ta | aPa' | T aPa' */
	mx[dpT][j][d] = max;

	/* S -> aS | T | end */
	cursc = mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSS];
	cursc2 = mx[dpT][j][d] + pr->transitions[TST];
	if (cursc > cursc2) mx[dpS][j][d] = cursc;
	else mx[dpS][j][d] = cursc2;

	/* R -> Ra | aPa' */
	if (j > 0) {
	   cursc = mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TRR];
	   if ((d > 1) && (d-1 > HLEN)) {
	      cursc2 = mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]]+ pr->transitions[TRP]; 
	   } else { cursc2 = -BIGINT; }
	   if (cursc2 > cursc) { mx[dpR][j][d] = cursc2; }
	   else { mx[dpR][j][d] = cursc; }
	}

	/* Q -> aQ | aPa' */
	cursc = mx[dpQ][j][d-1] + pr->singles[rna[i]] + pr->transitions[TQQ];
	if ((j > 0) && (d > 1) && (d-1 > HLEN)) {
	   cursc2 = mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]]+ pr->transitions[TQP]; 
	} else { cursc2 = -BIGINT; }
	if (cursc2 > cursc) { mx[dpQ][j][d] = cursc2; }
	else { mx[dpQ][j][d] = cursc; }

	/* I -> aI | Ra */
	cursc = mx[dpI][j][d-1] + pr->singles[rna[i]] + pr->transitions[TII];
	if (j > 0) cursc2 = mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TIR]; 
	else cursc2 = -BIGINT;
	if (cursc > cursc2) { mx[dpI][j][d] = cursc; }
	else { mx[dpI][j][d] = cursc2; }

	/* M -> aM | R */
	cursc = mx[dpM][j][d-1] + pr->singles[rna[i]] + pr->transitions[TMM];
	cursc2 = mx[dpR][j][d] + pr->transitions[TMR];
	if (cursc > cursc2) { mx[dpM][j][d] = cursc; }
	else { mx[dpM][j][d] = cursc2; }

	/* N -> aaH | aaQ | Raa | aI | MT */
	max = -BIGINT;
	if (d > 1) {
	   /* N -> aaH */
	   cursc = mx[dpH][j][d-2] + pr->singles[rna[i]] + pr->singles[rna[i+1]] 
	      				+ pr->transitions[TNH];
	   if (cursc > max) max = cursc; 
	   /* N -> aaQ */
	   cursc = mx[dpQ][j][d-2] + pr->singles[rna[i]] + pr->singles[rna[i+1]] 
	      				+ pr->transitions[TNQ];
	   if (cursc > max) max = cursc; 
	   /* N -> Raa */
	   if (j > 1) {
	      cursc = mx[dpR][j-2][d-2] + pr->singles[rna[j]] + pr->singles[rna[j-1]] 
		 + pr->transitions[TNR];
	      if (cursc > max) max = cursc;
	   }
	}
	/* N -> aI */
	cursc = mx[dpI][j][d-1] + pr->singles[rna[i]] + pr->transitions[TNI];
	if (cursc > max) max = cursc; 
	/* N -> MT */ 
	for (k = i+1; k < j-1; k++) {
	   cursc = mx[dpM][k][dist(i,k)] + mx[dpT][j][dist(k+1,j)] + pr->transitions[TNB];
	   if (cursc > max) max = cursc; 
	}
	mx[dpN][j][d] = max;

	/* P -> aPa | N (AY2) or aNa' (AYN) | ... */
	max = -BIGINT;
	/* Stacking! Can't be in P state at edges!  */
	if ((i > 0) && (j < len-1)) { 
	   stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]];
	   if ((j > 0) && (d > 1)) {
	      /* P -> aPa' */
	      cursc = mx[dpP][j-1][d-2] + stackvalue + pr->transitions[TPP];
	      if ((cursc > max) && (d-1 > HLEN)) max = cursc;
	   }
	   if (grammar == AYN) {
	      /* P -> aNa' */
	      if ((j > 0) && (d > 1)) {
		 cursc = mx[dpN][j-1][d-2] + stackvalue + pr->transitions[TPN];
		 if ((cursc > max) && (d-1 > HLEN)) max = cursc;
	      }
	   } else {		/* AY2 */
	      /* P -> N */
	      cursc = mx[dpN][j][d] + pr->transitions[TPN];
	      if (cursc > max) max = cursc;
	   }
	   /* P -> x aPa' | aPa' x | (AYN only:)  aNa' | x aNa' */
	   if (d-2 > HLEN) {	/* (j-i) >= (HLEN + 1)) { */
	      stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i+1]][rna[j]];
	      /* P -> x aPa' */
	      if (j > 0) {
		 tmp = dist(i+2,j-1);
		 cursc = mx[dpP][j-1][tmp] + stackvalue + pr->singles[rna[i]] + pr->transitions[TPL];
		 if ((cursc > max) && (tmp-1 > HLEN+2)) max = cursc;
		 if (grammar == AYN) {
		    /* P -> x aNa' */
		    cursc = mx[dpN][j-1][tmp] + stackvalue + pr->singles[rna[i]] 
		       + pr->transitions[TPE];
		    if ((cursc > max) && (tmp-1 > HLEN)) max = cursc;
		 }
	      }
	      stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j-1]];
	      /* P -> aPa' x */
	      if (j > 1) {
		 tmp = dist(i+1,j-2);
		 cursc = mx[dpP][j-2][tmp] + stackvalue + pr->singles[rna[j]] 
		    + pr->transitions[TPR];
		 if ((cursc > max) && (tmp-1 > HLEN+2)) max = cursc;
		 if (grammar == AYN) {
		    /* P -> aNa' x */
		    cursc = mx[dpN][j-2][tmp] + stackvalue + pr->singles[rna[j]] 
		       + pr->transitions[TPW];
		    if ((cursc > max) && (tmp-1 > HLEN)) max = cursc;
		 }
	      }
	   }

	}
	/* AYN: P -> aPa | x aPa' | aPa' x | aNa' | x aNa' | aNa' x  
	 * AY2: P -> aPa | x aPa' | aPa' x | N */
	mx[dpP][j][d] = max;
     }
  }
}

/* Function: cykTraceA
 * Date:     RDD, Tue Jan 22 15:24:12 CST 2002 [St Louis]
 *
 * Purpose:  Build traceback tree for AYN, AY2 
 *
 * Args:
 *	mx	matrix in which to calculate cyk
 *	pr	parameters in integer form
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns: --void --
 */
struct trace_s *
cykTraceA(int ***mx, INTMOD *pr, char *rna, int len, int grammar)
{
  int d, i, j, k, mtx;   /* Indices */
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */
  int emtemp;

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (len -1), TRE));

  /* Repeat until stack is empty */
  while (curr = PopTracestack(stack)) {
    /* Set i and j from items in stack */
    i = curr->emitl; j = curr->emitr; mtx = curr->nonterminal;
    d = j - i + 1;

    if (i > j) { 		/* S(R) -> end */
      curr->emitl = -1; curr->emitr = -1; 
      if (mtx == dpH) { curr->transition = THE; }
      else { curr->transition = TSE; curr->nonterminal = dpS; }
      continue;

      /* H -> aH */
    } else if (mtx == dpH) {
      curr->emitr = -1; curr->transition = THH; 
      PushTracestack(stack, AttachTrace (curr, dpH, i+1, j, TRE));

      /* S -> aS | T | end */
    } else if (mtx == dpS) {
      /* S -> aS | T | end */
      if ((mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSS]) == mx[dpS][j][d]) {
        curr->emitr = -1; curr->transition = TSS; 
        PushTracestack(stack, AttachTrace (curr, dpS, i+1, j, TRE));
      } else {
	/* Assumes: ((mx[dpT][j][d] + pr->transitions[TST]) == mx[dpS][j][d]) */
        curr->emitr = -1; curr->emitl = -1; curr->transition = TST; 
        PushTracestack(stack, AttachTrace (curr, dpT, i, j, TRE));
      }

      /* T -> Ta | aPa' | T aPa' */
    } else if (mtx == dpT) {
      /* T -> Tb | aPa' | T aPa' */
      if ((mx[dpT][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TTT]) == mx[dpT][j][d]) {
        curr->emitl = -1; curr->transition = TTT; 
        PushTracestack(stack, AttachTrace (curr, dpT, i, j-1, TRE));
      } else if ((mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TTP]) == mx[dpT][j][d]) {
        curr->transition = TTP;
        PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TRE));
      } else {
        for (k = i+1; k < j-1; k++) {
          if ((mx[dpT][k][dist(i,k)] + mx[dpP][j-1][dist(k+2,j-1)] + pr->pairs[rna[k+1]][rna[j]] + 
			pr->transitions[TTB]) == mx[dpT][j][d]) {
            curr->emitl = k+1; curr->transition = TTB;
            PushTracestack(stack, AttachTrace (curr, dpP, k+2, j-1, TRE));
            PushTracestack(stack, AttachTrace (curr, dpT, i, k, TRE));
	    k = j;	/* Short circuit */
          } /* End if */
        } /* End for (bifurcation points) */
      } 

      /* AYN: P -> aPa | x aPa' | aPa' x | aNa' | x aNa' | aNa' x  
       * AY2: P -> aPa | x aPa' | aPa' x | N */
    } else if (mtx == dpP) {
      if ((mx[dpP][j-1][d-2] + pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]] 
		+ pr->transitions[TPP]) == mx[dpP][j][d]) {
	curr->transition = TPP;
	PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TRE));
      } else if ((mx[dpP][j-1][dist(i+2,j-1)] + pr->singles[rna[i]] + pr->transitions[TPL] +
	       pr->stack[idx(rna[i-1],rna[j+1])][rna[i+1]][rna[j]]) == mx[dpP][j][d]) {
	 curr->transition = TPL;  curr->emitl = i+1;
	 PushTracestack(stack, AttachTrace (curr, dpP, i+2, j-1, TRE));
      } else if ((mx[dpP][j-2][dist(i+1,j-2)] + pr->singles[rna[j]] + pr->transitions[TPR] +
	       pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j-1]]) == mx[dpP][j][d]) {
	 curr->transition = TPR;  curr->emitr = j-1;
	 PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-2, TRE));
      } else if (grammar == AYN) {
	 if ((mx[dpN][j-1][dist(i+2,j-1)] + pr->singles[rna[i]] + pr->transitions[TPE] +
		  pr->stack[idx(rna[i-1],rna[j+1])][rna[i+1]][rna[j]]) == mx[dpP][j][d]) {
	    curr->transition = TPE;  curr->emitl = i+1;
	    PushTracestack(stack, AttachTrace (curr, dpN, i+2, j-1, TRE));
	 } else if ((mx[dpN][j-2][dist(i+1,j-2)] + pr->singles[rna[j]] + pr->transitions[TPW] +
		  pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j-1]]) == mx[dpP][j][d]) { 
	    curr->transition = TPW;  curr->emitr = j-1;
	    PushTracestack(stack, AttachTrace (curr, dpN, i+1, j-2, TRE));
	 } else {
	    if ((mx[dpN][j-1][d-2] + pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]] 
		     + pr->transitions[TPN]) == mx[dpP][j][d]) {
	       curr->transition = TPN;
	       PushTracestack(stack, AttachTrace (curr, dpN, i+1, j-1, TRE));
	    }
	 }
      } else  {
	 /* if ((mx[dpN][j][d] + pr->transitions[TPN]) == mx[dpP][j][d])  */
	 curr->transition = TPN;  curr->emitr = -1;  curr->emitl = -1;
	 PushTracestack(stack, AttachTrace (curr, dpN, i, j, TRE));
      }

      /* N -> aaH | aaQ | Raa | aI | MT */
    } else if (mtx == dpN) {
       if ((mx[dpH][j][d-2] + pr->singles[rna[i]] + pr->singles[rna[i+1]] + 
		pr->transitions[TNH]) == mx[dpN][j][d]) {
	  curr->emitr = -1; curr->emitl = i+1; curr->transition = TNH; 
	  PushTracestack(stack, AttachTrace (curr, dpH, i+2, j, TRE));
       } else if ((mx[dpQ][j][d-2] + pr->singles[rna[i]] + pr->singles[rna[i+1]] + 
		pr->transitions[TNQ]) == mx[dpN][j][d]) {
	  curr->emitr = -1; curr->emitl = i+1; curr->transition = TNQ; 
	  PushTracestack(stack, AttachTrace (curr, dpQ, i+2, j, TRE));
       } else if ((mx[dpR][j-2][d-2] + pr->singles[rna[j]] + pr->singles[rna[j-1]] + 
		pr->transitions[TNR]) == mx[dpN][j][d]) {
	  curr->emitl = -1; curr->emitr = j-1; curr->transition = TNR; 
	  PushTracestack(stack, AttachTrace (curr, dpR, i, j-2, TRE));
       } else if ((mx[dpI][j][d-1] + pr->singles[rna[i]] + pr->transitions[TNI]) 
	     			== mx[dpN][j][d]) {
	  curr->emitr = -1; curr->transition = TNI;
	  PushTracestack(stack, AttachTrace (curr, dpI, i+1, j, TRE));
	} else {
	  for (k = i+1; k < j-1; k++) {
	    if ((mx[dpM][k][dist(i,k)] + mx[dpT][j][dist(k+1,j)] + pr->transitions[TNB]) 
		  			== mx[dpN][j][d]) {
	      curr->emitl = -1; curr->emitr = -1; curr->transition = TNB;
	      PushTracestack(stack, AttachTrace (curr, dpT, k+1, j, TRE));
	      PushTracestack(stack, AttachTrace (curr, dpM, i, k, TRE));
	      k = j;	/* Short circuit */
	    }
	  }
	}

      /* R -> Ra | aPa' */
    } else if (mtx == dpR) {
      if ((mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TRR]) == mx[dpR][j][d]) {
	curr->emitl = -1; curr->transition = TRR;
	PushTracestack(stack, AttachTrace (curr, dpR, i, j-1, TRE));
      } else {
        curr->transition = TRP;
	PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TRE));
      }

      /* Q -> aQ | aPa' */
    } else if (mtx == dpQ) {
      if ((mx[dpQ][j][d-1] + pr->singles[rna[i]] + pr->transitions[TQQ]) == mx[dpQ][j][d]) {
	curr->emitr = -1; curr->transition = TQQ;
	PushTracestack(stack, AttachTrace (curr, dpQ, i+1, j, TRE));
      } else {
	curr->transition = TQP;
	PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TRE));
      }

      /* I -> aI | Ra */
    } else if (mtx == dpI) {
      if ((mx[dpI][j][d-1] + pr->singles[rna[i]] + pr->transitions[TII]) == mx[dpI][j][d]) {
	curr->emitr = -1; curr->transition = TII;
	PushTracestack(stack, AttachTrace (curr, dpI, i+1, j, TRE));
      } else {
	curr->transition = TIR; curr->emitl = -1;
	PushTracestack(stack, AttachTrace (curr, dpR, i, j-1, TRE));
      }

      /* M -> aM | R */
    } else if (mtx == dpM) {
      if ((mx[dpM][j][d-1] + pr->singles[rna[i]] + pr->transitions[TMM]) == mx[dpM][j][d]) {
	curr->emitr = -1; curr->transition = TMM;
	PushTracestack(stack, AttachTrace (curr, dpM, i+1, j, TRE));
      } else {
	curr->transition = TMR;  curr->emitl = -1; curr->emitr = -1;
	PushTracestack(stack, AttachTrace (curr, dpR, i, j, TRE));
      }

    } else {
      printf("ERROR!! Nonterminal %d unkown in AYN traceback!\n", mtx);
    }
  }
  FreeTracestack(stack);
  return parsetree;
}

/* Function: khs2traceAYN
 * Date:     RDD, Tue Apr 23 09:39:55 2002 [St. Louis]
 *
 * Purpose:  Convert KHS format into properly 
 * 	labeled traceback tree for AYN grammar
 *
 * Args:     
 *	dolist  Traceback tree to build from KHS	
 *	ct	KHS info represented as ct format
 */
int
khs2traceAYN(struct tracestack_s *dolist, int *ct, int grammar)
{
  struct trace_s      *cur;
  struct trace_s      *tr;
  struct trace_s      *prv, *nxt;
  char left; char right;
  int  i,j, mid, mid2;
  int debug;
  int emtemp;

  debug = FALSE;

  while ((cur = PopTracestack(dolist)) != NULL) {
    i = cur->emitl; j = cur->emitr;

    if (i > j) {
      if (cur->nonterminal == dpH) {
        cur->transition = THE; cur->emitl = -1; cur->emitr = -1; 
      } else {
        cur->transition = TSE; cur->emitl = -1; cur->emitr = -1; 
      }
    } else if (ct[i] == -1) {	/* i unpaired, single strand left */
      switch (cur->nonterminal) {
      case dpS: 
	cur->transition = TSS; cur->emitr = -1;
	PushTracestack(dolist, AttachTrace(cur, dpS, i+1, j, TRE));
	break;
      case dpP: 	
	switch (grammar) {
	case AYN:
	  if (ct[i+1] == j) { 	/* Bulge */
	    /* Must take into account the fact that the next position could
	       be a pair, or a single nucleotide bulge */
	    if ((ct[i+2] == j-1) || (ct[i+2] == j-2) || (ct[i+3] == j-1)) {
	      cur->transition = TPL; cur->emitl = i+1;
	      PushTracestack(dolist, AttachTrace(cur, dpP, i+2, j-1, TRE));
	    } else {		/* End of a stem */
	      cur->transition = TPE; cur->emitl = i+1;
	      PushTracestack(dolist, AttachTrace(cur, dpN, i+2, j-1, TRE));
	    }
	  } else {		/* No bulge, reached in error */
            if (debug) printf("RE: i unpaired (AYN) %d %d \n", i, j);
	    /* Can either discard this one, which throws away a LOT of
	     * useful information:
             * 		return 0;
             * Or we can push through this problem to collect as much
             * data as we can:
	     */
	    cur->nonterminal = dpN;
	    PushTracestack(dolist, cur);
	  }
	  break;
	case AY2:
	  if ((ct[i+1] == j) && ((ct[i+2] == j-1) || (ct[i+2] == j-2) || (ct[i+3] == j-1))) {
	    cur->transition = TPL; cur->emitl = i+1;
	    PushTracestack(dolist, AttachTrace(cur, dpP, i+2, j-1, TRE));
	  } else {
	    cur->transition = TPN; cur->emitl = -1; cur->emitr = -1;
	    PushTracestack(dolist, AttachTrace(cur, dpN, i, j, TRE));
	  }
	  break;
	default:	/* Reached in error */
          if (debug) printf("RE: i unpaired (AYN) %d %d \n", i, j );
	    /* Can either discard this one, which throws away a LOT of
	     * useful information:
             * 		return 0;
             * Or we can push through this problem to collect as much
             * data as we can:
	     */
	  cur->nonterminal = dpN;
	  PushTracestack(dolist, cur);
	  break;
	}
	break;
      case dpH:
	cur->transition = THH; cur->emitr = -1;  
	PushTracestack(dolist, AttachTrace(cur, dpH, i+1, j, TRE));
	break;
      case dpQ:
	cur->transition = TQQ; cur->emitr = -1;
	PushTracestack(dolist, AttachTrace(cur, dpQ, i+1, j, TRE));
	break;
      case dpM:
	cur->transition = TMM; cur->emitr = -1;
	PushTracestack(dolist, AttachTrace(cur, dpM, i+1, j, TRE));
	break;
      case dpI:
	cur->transition = TII; cur->emitr = -1;
	PushTracestack(dolist, AttachTrace(cur, dpI, i+1, j, TRE));
	break;
      case dpN:
	mid = find_split(ct, i, j);
	if (mid < 0) {		/* no pairs, single stranded between i,j */
	  if (grammar == AYN) {
	    cur->transition = TNH; cur->emitl = i+1; cur->emitr = -1;
	    PushTracestack(dolist, AttachTrace(cur, dpH, i+2, j, TRE));
	  } else {
	    cur->transition = TNH; cur->emitr = -1;
	    PushTracestack(dolist, AttachTrace(cur, dpH, i+1, j, TRE));
	  }
	} else if (mid == j) {	/* left bulge */
	   cur->transition = TNQ; cur->emitl = i+1; cur->emitr = -1;
	   PushTracestack(dolist, AttachTrace(cur, dpQ, i+2, j, TRE));
	} else {
	  mid2 = find_split(ct, mid+1, j);
	  if (mid2 < 0) {		/* Internal Loop */
	    cur->transition = TNI; cur->emitr = -1;
	    PushTracestack(dolist, AttachTrace(cur, dpI, i+1, j, TRE));
	  } else { 		/* Multiple stems, must bifurcate */
	    cur->transition = TNB; cur->emitr = -1; cur->emitl = -1;
	    PushTracestack(dolist, AttachTrace(cur, dpT, ct[mid2], j, TRE));
	    /* Left Nonterminal (M) must take care of first stem and 
	     * flanking single stranded */
	    PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[mid2]-1, TRE));
	  }
	}
	break;
      default: 
        if (debug) printf("RE: i unpaired %d\n", cur->nonterminal);
	return 0;
        break;
      }
    } else if (ct[j] == -1) { /* j unpaired, single strand right */
      switch (cur->nonterminal) {
      case dpS: 
	cur->transition = TST; cur->emitl = -1; cur->emitr = -1; 
	PushTracestack(dolist, AttachTrace(cur, dpT, i, j, TRE));
	break;
      case dpT:
	cur->transition = TTT; cur->emitl = -1; 
	PushTracestack(dolist, AttachTrace(cur, dpT, i, j-1, TRE));
	break;
      case dpP:
	switch (grammar) {
	case AYN:
	  if (ct[i] == j-1) { 	/* Bulge */
	    /* Must take into account the fact that the next position could
	       be a pair, or a single nucleotide bulge */
	    if ((ct[i+1] == j-2) || (ct[i+1] == j-3) || (ct[i+2] == j-2)) {
	      cur->transition = TPR; cur->emitr = j-1;
	      PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-2, TRE));
	    } else {		/* End of a stem */
	      cur->transition = TPW; cur->emitr = j-1;
	      PushTracestack(dolist, AttachTrace(cur, dpN, i+1, j-2, TRE));
	    }
	  } else { 	/* Reached in error */
            if (debug) printf("RE: j unpaired (AYN) %d %d \n", i, j);
	    /* Can either discard this one, which throws away a LOT of
	     * useful information:
             * 		return 0;
             * Or we can push through this problem to collect as much
             * data as we can:
	     */
	    cur->nonterminal = dpN;
	    PushTracestack(dolist, cur);
	  }
	  break;
	case AY2:
	  if ((ct[i] == j-1) && ((ct[i+1] == j-2) || (ct[i+1] == j-3) || (ct[i+2] == j-2))) {
	    cur->transition = TPR; cur->emitr = j-1;
	    PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-2, TRE));
	  } else {
	    cur->transition = TPN; cur->emitl = -1; cur->emitr = -1;
	    PushTracestack(dolist, AttachTrace(cur, dpN, i, j, TRE));
	  }
	  break;
	default: 	/* Reached in error */
          if (debug) printf("RE: j unpaired (AYN) %d\n", cur->nonterminal);
	    /* Can either discard this one, which throws away a LOT of
	     * useful information:
             * 		return 0;
             * Or we can push through this problem to collect as much
             * data as we can:
	     */
	    cur->nonterminal = dpN;
	    PushTracestack(dolist, cur);
	  break;
	}
	break;
      case dpR:
	cur->transition = TRR; cur->emitl = -1; 
	PushTracestack(dolist, AttachTrace(cur, dpR, i, j-1, TRE));
	break;
      case dpM:
	cur->transition = TMR; cur->emitl = -1; cur->emitr = -1; 
	PushTracestack(dolist, AttachTrace(cur, dpR, i, j, TRE));
	break;
      case dpI:
	cur->transition = TIR; cur->emitl = -1; 
	PushTracestack(dolist, AttachTrace(cur, dpR, i, j-1, TRE));
	break;
      case dpN:
	mid = find_split(ct, i, j);
	if ((mid >= 0 ) && (mid != j)) {	
	  mid2 = find_split(ct, mid+1, j);
	  if (mid2 >= 0) {	/* Multiple stems, must bifurcate */
	    cur->transition = TNB; cur->emitr = -1; cur->emitl = -1;
	    PushTracestack(dolist, AttachTrace(cur, dpT, ct[mid2], j, TRE));
	    /* Left Nonterminal (M) must take care of first stem and flanking single stranded */
	    PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[mid2]-1, TRE));
	  } 
	} else {	/* Left bulge */
	   cur->transition = TNR; cur->emitl = -1; cur->emitr = j-1;
	   PushTracestack(dolist, AttachTrace(cur, dpR, i, j-2, TRE));
	}
	break;
      default: 
        if (debug) printf("RE: j unpaired %d\n", cur->nonterminal);
        return 0;
	break;
      }
    } else if (ct[i] == j) { /* i,j paired to each other */
      switch (cur->nonterminal) {
      case dpS: 
	cur->transition = TST; cur->emitl = -1; cur->emitr = -1; 
	PushTracestack(dolist, AttachTrace(cur, dpT, i, j, TRE));
	break;
      case dpT:
	cur->transition = TTP;
	PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
	break;
      case dpQ:
	cur->transition = TQP; 
	PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
	break;
      case dpM:
	cur->transition = TMR; cur->emitr = -1; cur->emitl = -1;
	PushTracestack(dolist, AttachTrace(cur, dpR, i, j, TRE));
	break;
      case dpR:
	cur->transition = TRP;
	PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
	break;
      case dpP:
        if (grammar == AYN) {
	  if ((ct[i+1] == j-1) || (ct[i+2] == j-1) || (ct[i+1] == j-2)) {
	    cur->transition = TPP;
	    PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
          } else {
	    cur->transition = TPN;
	    PushTracestack(dolist, AttachTrace(cur, dpN, i+1, j-1, TRE));
          }
        } else {	/* AY2 */
	  cur->transition = TPP;
	  PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
        }
	break;
      default: 
        if (debug) printf("RE: i %d, j %d paired %d\n", i, j, cur->nonterminal);
        return 0;
	break;
      }
    } else {	/* i,j paired, but not to each other */
      switch (cur->nonterminal) {
      case dpS:
	cur->transition = TST; cur->emitl = -1; cur->emitr = -1; 
	PushTracestack(dolist, AttachTrace(cur, dpT, i, j, TRE));
	break;
      case dpT: 
	cur->transition = TTB; cur->emitl = ct[j];
	PushTracestack(dolist, AttachTrace(cur, dpP, ct[j]+1, j-1, TRE));
	PushTracestack(dolist, AttachTrace(cur, dpT, i, ct[j]-1, TRE));
	break;
      case dpN:
	cur->transition = TNB; cur->emitr = -1; cur->emitl = -1;
	/* Because the M state must take care of interstem region to its left, 
	 * we must now find the edge of that interstem sequence. */
	mid = find_split(ct, ct[i]+1, ct[j]-1);	
	if (mid < 0) {	/* No stems in between */
	  PushTracestack(dolist, AttachTrace(cur, dpT, ct[j], j, TRE));
	  PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[j]-1, TRE));
	} else {		/* Contains stems in between */
	  PushTracestack(dolist, AttachTrace(cur, dpT, ct[mid], j, TRE));
	  PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[mid]-1, TRE));
	}
	break;
      case dpP:
        if (grammar == AY2) {
	  cur->transition = TPN; cur->emitl = -1; cur->emitr = -1; 
	  PushTracestack(dolist, AttachTrace(cur, dpN, i, j, TRE));
        }
        break;
      default: 
        if (debug) printf("RE: i,j paired not to each other %d (%d, %d)\n", 
	      	cur->nonterminal, i, j);
        return 0;
        break;
      }
    }
    if (debug) printf("(%#12x) %2d  %4d  %4d  %3d  %#10x  %#10x \n", 
	   (int) cur, cur->nonterminal, cur->emitl, cur->emitr, 
	   cur->transition, (int) cur->nxtl, (int) cur->nxtr);
  }
  if (debug) printf("Finished without error, returning 1\n");
  return 1;
}

/* Function: analyzeTraceA
 * Date:     RDD, Tue May 14 16:40:56 CDT 2002 [St Louis]
 *
 * Purpose: Parse a traceback tree for information.
 *	Either for counts (training).
 *	Or for determining tracebcak score.
 *
 * Args:     
 *      seq   - sequence corresponding to the trace
 *      len   - length of the sequence
 *      tr    - traceback to count
 *      cfg   - model, counts form, to add counts to
 *      count - if TRUE this is TraceCount; 
 *		if FALSE this is TraceScore
 *
 * Returns:  score of current traceback (in TraceScore mode)
 * 	Should return zero in TraceCount mode
 */
int
analyzeTraceA(char *seq, int len, struct trace_s *tr, INTMOD *cfg, int count)
{
  struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
  struct trace_s      *cur;     /* current node in the tree              */
  char *iseq;                   /* sequence with 0,1,2,3,4 in place of A,C,G,U,N */
  int   cst, nst, j;
  char left; char right;
  int score;
  int k, i;

 /* Digitize Sequence setup */
  SetAlphabet(hmmNUCLEIC);

  iseq = DigitizeSequence(seq, len);

  dolist = InitTracestack();
  PushTracestack(dolist, tr->nxtl);
  score = 0;

  while ((cur = PopTracestack(dolist)) != NULL) {
     /*
    printf("(%#12x) %2d  %4d  %4d  %3d  %#10x  %#10x \n", 
	   (int) cur, cur->nonterminal, cur->emitl, cur->emitr, 
	   cur->transition, (int) cur->nxtl, (int) cur->nxtr); 
	   */

    if (cur->transition < NTRANS) {
      if (count) cfg->transitions[cur->transition] += 1;
      else score += cfg->transitions[cur->transition];
      if ((cur->transition == TSE) || (cur->transition == THE)) {	/* do nothing on ENDS */
	continue;
      } else if (cur->transition == TTB) {
        cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
	PushTracestack(dolist, cur->nxtr);
	PushTracestack(dolist, cur->nxtl);
      } else if (cur->transition == TNB) {
	PushTracestack(dolist, cur->nxtr);
	PushTracestack(dolist, cur->nxtl);
      } else if ((cur->emitl == -1) && (cur->emitr == -1)) { /* No emission */
	PushTracestack(dolist, cur->nxtl);
      } else {
        if ((iseq[cur->emitl] > ALPHA) || (iseq[cur->emitr] > ALPHA)) {
		/* Do nothing, contains an ambiguous base! */
		/* Therfore must back out of counting transition?
 		 */
	  if (count) cfg->transitions[cur->transition] -= 1;

	/* Emit to right */
	} else if (cur->emitl == -1) {
	  if (count) cfg->singles[iseq[cur->emitr]] += 1;
	  else score += cfg->singles[iseq[cur->emitr]];
	  if (cur->transition == TNR) {
	    if (iseq[(cur->emitr+1)] <= 4) {
              if (count) cfg->singles[iseq[(cur->emitr +1)]] += 1;
              else score += cfg->singles[iseq[(cur->emitr +1)]];
            }
	  }

	/* Emit to left */
	} else if (cur->emitr == -1) {
	  if (count) cfg->singles[iseq[cur->emitl]] += 1;
	  else score += cfg->singles[iseq[cur->emitl]];
	  if ((cur->transition == TNQ) || (cur->transition == TNH)) {
	    if (iseq[cur->emitl-1] <= 4) {
              if (count) cfg->singles[iseq[cur->emitl -1]] += 1;
              else score += cfg->singles[iseq[cur->emitl -1]];
            }
	  }

	/* Emit aligned pair -- stacking model */
        } else if (cur->nonterminal == dpP) {
	  if ((cur->transition == TPL) || (cur->transition == TPE)) {
            if ((iseq[cur->emitl -2] > ALPHA) || (iseq[cur->emitr +1] > ALPHA)) {
	      if (count) cfg->transitions[cur->transition] -= 1;
	    } else {
              if (count) {
	        cfg->stack[idx(iseq[cur->emitl - 2],iseq[cur->emitr + 1])]
		      	[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
	        cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
              } else {
	        score += cfg->stack[idx(iseq[cur->emitl - 2],iseq[cur->emitr + 1])]
		      	[iseq[cur->emitl]][iseq[cur->emitr]];
              }
	      if (iseq[cur->emitl-1] <= 4) {
                if (count) cfg->singles[iseq[cur->emitl -1]] += 1;
                else score += cfg->singles[iseq[cur->emitl -1]];
	      }
	    }
	    
	  } else if ((cur->transition == TPR) || (cur->transition == TPW)) {
            if ((iseq[cur->emitl -1] > ALPHA) || (iseq[cur->emitr +2] > ALPHA)) {
	      if (count) cfg->transitions[cur->transition] -= 1;
	    } else {
              if (count) {
	        cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 2])]
		      	[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
	        cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
              }  else {
	        score += cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 2])]
		      	[iseq[cur->emitl]][iseq[cur->emitr]];
              }
	      if (iseq[cur->emitr +1] <= 4) {
                if (count) cfg->singles[iseq[cur->emitr +1]] += 1;
                else score += cfg->singles[iseq[cur->emitr +1]];
              }
	    }
	  } else {	/* TPP or TPN */
            if ((iseq[cur->emitl -1] > ALPHA) || (iseq[cur->emitr +1] > ALPHA)) {
		/* Do nothing, contains an ambiguous base! 
		 * Therfore must back out of counting transition!
 		 */
	      if (count) cfg->transitions[cur->transition] -= 1;
            } else {
		/* Technically TPN is only collecting pairs in AYN,
	 	 * but because the AY2 TPN will have never made it
		 * here (-1 -1), it isn't necessary to test for them.
		 */
              if (count) {
	        cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
		      	[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
	       /* By also adding to pairs, it is like you are averaging the 
		* pair emissions over all pairs (including stacks) */
	        cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
              } else {
	        score += cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
		      	[iseq[cur->emitl]][iseq[cur->emitr]];
              }
            }
	  }

	/* Emit aligned pair -- no stacking */
	} else {
	  if (count) cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
	  else score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	}
	PushTracestack(dolist, cur->nxtl);
      }
    } else {
      PushTracestack(dolist, cur->nxtl);
    }
  }
  free(iseq);
  FreeTracestack(dolist);
  return (score);
}

/* Function: dTraceScoreA 
 * Date:     RDD, Mon Oct 27 16:38:56 CST 2003 [St Louis]
 *
 * Purpose: Parse a traceback tree for 
 *	determining tracebcak score (in float logs).
 *
 * Args:     
 *      seq   - sequence corresponding to the trace
 *      len   - length of the sequence
 *      tr    - traceback to count
 *      cfg   - model (float log form)
 *      ret_val  - score of trace 
 *
 * Returns:  void
 */
void
dTraceScoreA(char *seq, int len, struct trace_s *tr, PROBMOD *cfg, double *ret_val)
{
  struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
  struct trace_s      *cur;     /* current node in the tree              */
  char *iseq;                   /* sequence with 0,1,2,3,4 in place of A,C,G,U,N */
  int   cst, nst, j;
  char left; char right;
  double score;
  int k, i;

 /* Digitize Sequence setup */
  SetAlphabet(hmmNUCLEIC);

  iseq = DigitizeSequence(seq, len);

  dolist = InitTracestack();
  PushTracestack(dolist, tr->nxtl);
  score = 0.;

  while ((cur = PopTracestack(dolist)) != NULL) {
     /*
    printf("(%#12x) %2d  %4d  %4d  %3d  %#10x  %#10x \n", 
	   (int) cur, cur->nonterminal, cur->emitl, cur->emitr, 
	   cur->transition, (int) cur->nxtl, (int) cur->nxtr); 
	   */

    if (cur->transition < NTRANS) {
      score += cfg->transitions[cur->transition];
      if ((cur->transition == TSE) || (cur->transition == THE)) {	/* do nothing on ENDS */
	continue;
      } else if (cur->transition == TTB) {
        cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
	PushTracestack(dolist, cur->nxtr);
	PushTracestack(dolist, cur->nxtl);
      } else if (cur->transition == TNB) {
	PushTracestack(dolist, cur->nxtr);
	PushTracestack(dolist, cur->nxtl);
      } else if ((cur->emitl == -1) && (cur->emitr == -1)) { /* No emission */
	PushTracestack(dolist, cur->nxtl);
      } else {
        if ((iseq[cur->emitl] > ALPHA) || (iseq[cur->emitr] > ALPHA)) {
		/* Do nothing, contains an ambiguous base! */
		/* Therfore must back out of counting transition?
 		 */
	/* Emit to right */
	} else if (cur->emitl == -1) {
	  score += cfg->singles[iseq[cur->emitr]];
	  if (cur->transition == TNR) {
	    if (iseq[(cur->emitr+1)] <= 4) {
              score += cfg->singles[iseq[(cur->emitr +1)]];
            }
	  }

	/* Emit to left */
	} else if (cur->emitr == -1) {
	  score += cfg->singles[iseq[cur->emitl]];
	  if ((cur->transition == TNQ) || (cur->transition == TNH)) {
	    if (iseq[cur->emitl-1] <= 4) {
              score += cfg->singles[iseq[cur->emitl -1]];
            }
	  }

	/* Emit aligned pair -- stacking model */
        } else if (cur->nonterminal == dpP) {
	   if ((cur->transition == TPL) || (cur->transition == TPE)) {
	      if ((iseq[cur->emitl -2] > ALPHA) || (iseq[cur->emitr +1] > ALPHA)) {
		 /* Do nothing */
	      } else {
		 score += cfg->stack[idx(iseq[cur->emitl - 2],iseq[cur->emitr + 1])]
		    [iseq[cur->emitl]][iseq[cur->emitr]];
		 if (iseq[cur->emitl-1] <= 4) {
		    score += cfg->singles[iseq[cur->emitl -1]];
		 }
	      }
	    
	  } else if ((cur->transition == TPR) || (cur->transition == TPW)) {
            if ((iseq[cur->emitl -1] > ALPHA) || (iseq[cur->emitr +2] > ALPHA)) {
	       /* Do nothing */
	    } else {
	       score += cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 2])]
		  [iseq[cur->emitl]][iseq[cur->emitr]];
	       if (iseq[cur->emitr +1] <= 4) {
		  score += cfg->singles[iseq[cur->emitr +1]];
	       }
	    }
	  } else {	/* TPP or TPN */
            if ((iseq[cur->emitl -1] > ALPHA) || (iseq[cur->emitr +1] > ALPHA)) {
		/* Do nothing, contains an ambiguous base! 
		 * Therfore must back out of counting transition!
 		 */
            } else {
		/* Technically TPN is only collecting pairs in AYN,
	 	 * but because the AY2 TPN will have never made it
		 * here (-1 -1), it isn't necessary to test for them.
		 */
	       score += cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
		  [iseq[cur->emitl]][iseq[cur->emitr]];
	    }
	  }

	/* Emit aligned pair -- no stacking */
	} else {
	  score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	}
	PushTracestack(dolist, cur->nxtl);
      }
    } else {
      PushTracestack(dolist, cur->nxtl);
    }
  }
  free(iseq);
  FreeTracestack(dolist);
  *ret_val = score;
}

/* Function: tieParams
 *
 * Purpose: Experiment with various parameter tying possibilities
 */
void 
tieParams (INTMOD *counts)
{
   int newcount;
   int Pcount, Ncount; 
   float ratio;
   int debug;

   debug = FALSE;
/*
   newcount = (counts->transitions[TMM] + counts->transitions[TSS]) / 2;
   counts->transitions[TMM] = newcount;
   counts->transitions[TSS] = newcount;
   newcount = (counts->transitions[TMR] + counts->transitions[TST]) / 2;
   counts->transitions[TMR] = newcount;
   counts->transitions[TST] = newcount;

   newcount = (counts->transitions[TQQ] + counts->transitions[TRR]) / 2;
   counts->transitions[TQQ] = newcount;
   counts->transitions[TRR] = newcount;
   newcount = (counts->transitions[TQP] + counts->transitions[TRP]) / 2;
   counts->transitions[TQP] = newcount;
   counts->transitions[TRP] = newcount;

   Pcount = (counts->transitions[TPP] + counts->transitions[TPL] + counts->transitions[TPR]);
   if (debug) printf("TPP %d TPL %d TPR %d sum %d\n", 
	   counts->transitions[TPP] , counts->transitions[TPL] , counts->transitions[TPR], Pcount);
   Ncount = (counts->transitions[TPN] + counts->transitions[TPE] + counts->transitions[TPW]);
   if (debug) printf("TPN %d TPE %d TPW %d sum %d\n", 
	   counts->transitions[TPN] , counts->transitions[TPE] , counts->transitions[TPW], Ncount);

   ratio = (float)Ncount/(float)(Ncount + Pcount);
   if (debug) printf("Ratio N/P is %8.7f\n", ratio);
   newcount = (counts->transitions[TPL] + counts->transitions[TPE]);
   counts->transitions[TPE] = (int)(newcount * ratio);
   counts->transitions[TPL] = newcount - counts->transitions[TPE];

   newcount = (counts->transitions[TPR] + counts->transitions[TPW]);
   counts->transitions[TPW] = (int)(newcount * ratio);
   counts->transitions[TPR] = newcount - counts->transitions[TPW];
   if (debug) printf("TPP %d TPL %d TPR %d sum %d\n", 
	   counts->transitions[TPP] , counts->transitions[TPL] , counts->transitions[TPR], Pcount);
   if (debug) printf("TPN %d TPE %d TPW %d sum %d\n", 
	   counts->transitions[TPN] , counts->transitions[TPE] , counts->transitions[TPW], Ncount);

*/
}

/******************************** Inside **********************************/

/* Function: cinsInitA
 * Date:     RDD, Sun Oct  5 17:35:57 CDT 2003 [St Louis]
 *
 * Purpose:  Initialize cInside fill matrix 
 *
 * Args:     
 *	mx	fill matrix (log odds form)
 *	model	parameters (log odds form)
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cinsInitA(double ***mx, PROBMOD *model, char *rna, int len)
{
   int j, d;

   for (d = 0; d <= len; d++) {
      for (j = d; j < len; j++) {
	 mx[dpS][j][d] = model->transitions[TSE];
	 mx[dpT][j][d] = -BIGFLOAT;
	 mx[dpP][j][d] = -BIGFLOAT;
	 mx[dpN][j][d] = -BIGFLOAT;
	 mx[dpH][j][d] = model->transitions[THE];
	 mx[dpQ][j][d] = -BIGFLOAT;
	 mx[dpR][j][d] = -BIGFLOAT;
	 mx[dpI][j][d] = -BIGFLOAT;
	 mx[dpM][j][d] = -BIGFLOAT;
      }
      if (d > 0) {
	 mx[dpS][d-1][d] = model->transitions[TSE];
	 mx[dpT][d-1][d] = -BIGFLOAT;
	 mx[dpP][d-1][d] = -BIGFLOAT;
	 mx[dpN][d-1][d] = -BIGFLOAT;
	 mx[dpH][d-1][d] = model->transitions[THE];
	 mx[dpQ][d-1][d] = -BIGFLOAT;
	 mx[dpR][d-1][d] = -BIGFLOAT;
	 mx[dpI][d-1][d] = -BIGFLOAT;
	 mx[dpM][d-1][d] = -BIGFLOAT;
      }
   }
}

/* Function: cinsFillA
 * Date:    Sun Oct  5 17:38:14 CDT 2003 [St Louis]
 *
 * Purpose:  Fills cInside matrix 
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (log Probs)
 *	sc	parameters (log form)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
cinsFillA(double ***mx, PROBMOD *pr, char *rna, int len, int grammar, int *ss)
{
  int d, i, j, k, m;       /* Loop indicies */
  double cursc;
  double stackvalue, emtemp;

  /* Recursion */
  for (d = 1; d <= len; d++) {
     for (j = d-1; j < len; j++) {
	i = j - d + 1; 

	if (ss[i] == -1) mx[dpH][j][d] = mx[dpH][j][d-1] + pr->singles[rna[i]] + pr->transitions[THH];
	else mx[dpH][j][d] = -BIGFLOAT;

	cursc = -BIGFLOAT;
	/* T -> Ta | aPa' | T aPa' */
	if (j > 0) {
	   if (ss[j] == -1) cursc = mx[dpT][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TTT];
	   /* T -> aPa' */
	   if (d > 1) {
	      if (ss[i] == j) 
		 cursc = DLogsum(mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TTP], cursc);
	   }
	}
	/* T -> T aPa' */
	for (k = i+1; k < j-1; k++) {
	   if (ss[k+1] == j) 
	      cursc = DLogsum(mx[dpT][k][dist(i,k)] + mx[dpP][j-1][dist(k+2,j-1)] 
		    + pr->pairs[rna[k+1]][rna[j]] + pr->transitions[TTB], cursc);
	}
	/* T -> Ta | aPa' | T aPa' */
	mx[dpT][j][d] = cursc;

	/* S -> aS | T | end */
	cursc = mx[dpT][j][d] + pr->transitions[TST];
	if (ss[i] == -1) cursc = DLogsum(mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSS], cursc);
	mx[dpS][j][d] = cursc;

	cursc = -BIGFLOAT;
	/* R -> Ra | aPa' */
	if (j > 0) {
	   if (ss[j] == -1) cursc = mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TRR];
	   if ((d > 1) && (d-1 > HLEN)) {
	      if (ss[i] == j) 
		 cursc = DLogsum(mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]]+ pr->transitions[TRP], cursc); 
	   } 
	}
	mx[dpR][j][d] = cursc; 

	cursc = -BIGFLOAT;
	/* Q -> aQ | aPa' */
	if (ss[i] == -1) cursc = mx[dpQ][j][d-1] + pr->singles[rna[i]] + pr->transitions[TQQ];
	if ((j > 0) && (d > 1) && (d-1 > HLEN)) {
	   if (ss[i] == j)
	      cursc = DLogsum(mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]]+ pr->transitions[TQP], cursc); 
	}
	mx[dpQ][j][d] = cursc; 

	cursc = -BIGFLOAT;
	/* I -> aI | Ra */
	if (ss[i] == -1) cursc = mx[dpI][j][d-1] + pr->singles[rna[i]] + pr->transitions[TII];
	if (j > 0) {
	   if (ss[j] == -1) 
	      cursc = DLogsum(mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TIR], cursc); 
	}
	mx[dpI][j][d] = cursc; 

	cursc = -BIGFLOAT;
	/* M -> aM | R */
	cursc = mx[dpR][j][d] + pr->transitions[TMR];
	if (ss[i] == -1) 
	   cursc = DLogsum(mx[dpM][j][d-1] + pr->singles[rna[i]] + pr->transitions[TMM], cursc);
	mx[dpM][j][d] = cursc; 

	cursc = -BIGFLOAT;
	/* N -> aaH | aaQ | Raa | aI | MT */
	if (d > 1) {
	   /* N -> aaH */
	   if ((ss[i] == -1) && (ss[i+1] == -1)) {
	      cursc = mx[dpH][j][d-2] + pr->singles[rna[i]] + pr->singles[rna[i+1]] 
		 + pr->transitions[TNH];
	      /* N -> aaQ */
	      cursc = DLogsum(mx[dpQ][j][d-2] + pr->singles[rna[i]] + pr->singles[rna[i+1]] 
		 + pr->transitions[TNQ], cursc);
	   }

	   /* N -> Raa */
	   if (j > 1) {
	      if ((ss[j] == -1) && (ss[j-1] == -1)) 
		 cursc = DLogsum(mx[dpR][j-2][d-2] + pr->singles[rna[j]] + pr->singles[rna[j-1]] 
		 + pr->transitions[TNR], cursc);
	   }
	}
	/* N -> aI */
	if (ss[i] == -1) cursc = DLogsum(mx[dpI][j][d-1] + pr->singles[rna[i]] + pr->transitions[TNI], cursc);
	/* N -> MT */ 
	for (k = i+1; k < j-1; k++) {
	   cursc = DLogsum(mx[dpM][k][dist(i,k)] + mx[dpT][j][dist(k+1,j)] + pr->transitions[TNB], cursc);
	}
	mx[dpN][j][d] = cursc;

	/* P -> aPa | N (AY2) or aNa' (AYN) | ... */
	cursc = -BIGFLOAT;
	/* Stacking! Can't be in P state at edges!  */
	if ((i > 0) && (j < len-1)) { 
	   stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]];
	   if ((j > 0) && (d > 1)) {
	      /* P -> aPa' */
	      if (ss[i] == j)
		 cursc = mx[dpP][j-1][d-2] + stackvalue + pr->transitions[TPP];
	   }
	   if (grammar == AYN) {
	      /* P -> aNa' */
	      if ((j > 0) && (d > 1)) {
		 if (ss[i] == j)
		    cursc = DLogsum(mx[dpN][j-1][d-2] + stackvalue + pr->transitions[TPN], cursc);
	      }
	   } else {		/* AY2 */
	      /* P -> N */
	      cursc = DLogsum(mx[dpN][j][d] + pr->transitions[TPN], cursc);
	   }
	   /* P -> x aPa' | aPa' x | (AYN only:)  aNa' | x aNa' */
	   if (d-2 > HLEN) {	
	      stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i+1]][rna[j]];
	      /* P -> x aPa' */
	      if (j > 0) {
		 if ((ss[i] == -1) && (ss[i+1] == j)) {
		    cursc = DLogsum(mx[dpP][j-1][dist(i+2,j-1)] + stackvalue + pr->singles[rna[i]] + pr->transitions[TPL], cursc);
		    if (grammar == AYN) {
		       /* P -> x aNa' */
		       cursc = DLogsum(mx[dpN][j-1][dist(i+2,j-1)] + stackvalue + pr->singles[rna[i]] 
			  + pr->transitions[TPE], cursc);
		    }
		 }
	      }
	      stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j-1]];
	      /* P -> aPa' x */
	      if (j > 1) {
		 if ((ss[i] == -1) && (ss[i+1] == j)) {
		    cursc = DLogsum(mx[dpP][j-2][dist(i+1,j-2)] + stackvalue + pr->singles[rna[j]] 
			  + pr->transitions[TPR], cursc);
		    if (grammar == AYN) {
		       /* P -> aNa' x */
		       cursc = DLogsum(mx[dpN][j-2][dist(i+1,j-2)] + stackvalue + pr->singles[rna[j]] 
			     + pr->transitions[TPW], cursc);
		    }
		 }
	      }
	   }

	}
	/* AYN: P -> aPa | x aPa' | aPa' x | aNa' | x aNa' | aNa' x  
	 * AY2: P -> aPa | x aPa' | aPa' x | N */
	mx[dpP][j][d] = cursc;
     }
  }
}

