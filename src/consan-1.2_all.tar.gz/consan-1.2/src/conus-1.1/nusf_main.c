/* nusf_main.c 
 * RDD, Tue Aug 21 15:02:15 CDT 2001
 *
 * nusf_main.c 
 *   given seq and model, give best fold (structure)
 *   CYK/Viterbi algorithm
 */

/* What do we gain from each include? */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-m <file>     : Use model <file> \n\
-g <string>   : Use grammar <string> and plus one scoring \n\
   -H	        (with -g) shift to hydrogen bonding scoring  \n\
   --flat       (with -g) flat scoring scheme \n\
-o <file>     : redirect structure output to <file>\n\
-v            : verbose output \n\
-x            : print out parameters of model \n\
-d            : debugging output \n\
-t            : debugging, print traceback\n\
-f            : debugging, print fill matrix from cyk \n\
-q            : print predicted structures in stockholm format \n\
-c            : print ct output format for predicted structure\n\n\
";
static char usage[]  = "Usage: conus_fold [-options] <seqfile in>\n";

static char expert[] = "\
-s <mod>      : Save model to file mod\n\
-1	      : Use plus one scoring system \n\
--flat	      : Use flat probability distribution scoring system \n\
";

/*  -p does what (if anything)?
 *  -r <file> ?
 *  -e <file> ?
 */

int 
main (int argc, char **argv) 
{
  /* What are all the variables? */

  /**** arguments variables *****/
  int   optid; 
  OPTS settings;

  /* ReadSeq variables */
  SQFILE *sqfp; SQINFO sqinfo;
  int sformat;

  char *rna; 
  char *ss; 
  int *ctstruct; 
  FILE *ofp, *ifp;

  /* Models info */
  MODEL nusmodel;
  int score;
  struct trace_s *trc;

  if (!(ProcessOpts(&settings, &optid, argc, argv, usage, gramdesc, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  if (argc - optid < 1)
    Die("Incorrect number of command line arguments.\n%s\n%s\n", usage, optsline);

  SetupModel(&settings, &nusmodel);

  /* Digitize Sequence Setup*/
  SetAlphabet(hmmNUCLEIC);

  if (settings.minloop >= 0) HLEN = settings.minloop;
  if (settings.debugg) PrintOptions(settings.ofp, &settings);
  if (settings.parameterout) PrintModel(settings.ofp, &nusmodel);

  while (!(argc - optid < 1)) {
    /* Read input file into RNA array and filter for non-RNA residues */
    if ((sqfp = SeqfileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL) 
      Die("Failed to open sequence file %s\n%s\n", argv[optid], usage);

    while (ReadSeq(sqfp, sformat, &rna, &sqinfo)) {
      ToRNA(rna);

      if (settings.verbose) fprintf(settings.ofp, "Sequence %s (file: %s) :\n", 
		      sqinfo.name, argv[optid]);

      /* Should we fold this thing if it contains ambiguous bases? */

      if (settings.useprob) {
	if (settings.nostacking) {
	  dropStacking(&nusmodel);
          if (settings.parameterout) {
	    fprintf(settings.ofp, "Parameters Adjusted -- No Stacking!\n");
	    PrintModel(settings.ofp, &nusmodel);
	  }
	}
	 trc = (struct trace_s *)probCYK(rna, sqinfo.len, settings.grammar, 
	       &(nusmodel.probs), &settings);
      } else {
	if (settings.nostacking) {
	  dropStacking(&nusmodel);
          if (settings.parameterout) {
	    fprintf(settings.ofp, "Parameters Adjusted -- No Stacking!\n");
	    PrintModel(settings.ofp, &nusmodel);
	  }
	}
	 trc = (struct trace_s *)CYK(rna, sqinfo.len, settings.grammar, 
	       &(nusmodel.scores), &settings, &score);
      }

      /* What would it mean if trc == NULL?  What would we do? */

      if (trc != NULL) {
	if (settings.traceback) PrintTrace(settings.ofp, trc, rna); 

	/* This won't work for UZK grammar or any Zuker like grammar */
	trace2khs(trc, rna, sqinfo.len, 1, &ss);

	if (settings.stockout) {
	  PrintStockholm(settings.ofp, rna, &sqinfo, ss);
	} else if (settings.ctoutput) {
	  KHS2ct(ss, sqinfo.len, FALSE, &ctstruct, settings.verbose);
	  Print_CT(settings.ofp, rna, sqinfo.len, ctstruct, sqinfo.name);
	  free(ctstruct);
	} else {
	  PrintKHS(settings.ofp, rna, &sqinfo, ss);
	}
      }

      /* Cleanup  */
      free(ss);
      FreeTrace(trc);
      FreeSequence(rna, &sqinfo);
    }
    SeqfileClose(sqfp);
    optid ++;
  }
}
