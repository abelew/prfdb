#include "squid.h"

/* alpha_config.h  7/5/01
 * Parameters pulled from HMMERs config.h file that are relevant to alphabet.c
 */
#define MAXABET     20          /* maximum size of alphabet (4 or 20)              */
#define MAXCODE     23          /* maximum degenerate alphabet size (17 or 23)     */
#define MAXDCHLET   200         /* maximum # Dirichlet components in mixture prior */
#define NINPUTS     4           /* number of inputs into structural prior          */
#define NXRAY       4           /* number of structural inputs                */
#define ALILENGTH   50          /* length of displayed alignment lines        */

/* alpha_structs.h 7/5/01
 *
 * Struct definitions relevant to alphabet.c pulled from HMMERs
 * structs.h. May contain some chaff.
 */

/* an idiom for determining a symbol's position in the array
 * by pointer arithmetic.
 * does no error checking, so caller must already be damned sure x is
 * valid in the alphabet!
 */
#define SYMIDX(x)   (strchr(Alphabet, (x)) - Alphabet)

/* The symbol alphabet.
 * Must deal with IUPAC degeneracies. Nondegenerate symbols
 * come first in Alphabet[], followed by degenerate symbols.
 * Nucleic alphabet also must deal with other common symbols
 * like U (in RNA) and X (often misused for N).
 * Example:
 *   Nucleic: "ACGTUNRYMKSWHBVDX"          size=4  iupac=17
 *Symbol	Meaning	Origin of designation
 * G		G	Guanine
 * A		A	Adenine
 * T		T	Thymine
 * C		C	Cytosine
 * R		G or A	puRine
 * Y		T or C	pYrimidine
 * M		A or C	aMino
 * K		G or T	Keto
 * S		G or C	Strong interaction (3 H bonds)
 * W		A or T	Weak interaction (2 H bonds)
 * H		A or C or T	not-G, H follows G in the alphabet
 * B		G or T or C	not-A, B follows A
 * V		G or C or A	not-T (not-U), V follows U
 * D		G or A or T	not-C, D follows C
 * N		G or A or T or C	aNy
 *   
 *   Amino:   "ACDEFGHIKLMNPQRSTVWYBZX"    size=20 iupac=23
 *
 * Parts of the code assume that the last symbol is a
 * symbol for an unknown residue, i.e. 'X'.
 *
 * MAXCODE and MAXABET constants are defined in config.h
 */
#define hmmNOTSETYET 0
#define hmmNUCLEIC   2          /* compatibility with squid's kRNA   */
#define hmmAMINO     3          /* compatibility with squid's kAmino */

/* globals.h
 * Mon Nov 18 13:05:03 1996
 * 
 * Global variable definitions. 
 * This file may only be included in a main() .c file.
 */
char  Alphabet[MAXCODE]; /* ACGT, for instance                    */ 
int   Alphabet_type;     /* hmmNUCLEIC or hmmAMINO                */
int   Alphabet_size;     /* uniq alphabet size: 4 or 20           */
int   Alphabet_iupac;    /* total size of alphabet + IUPAC degen. */
char  Degenerate[MAXCODE][MAXABET];
int   DegenCount[MAXCODE];

/* alpha_funcs.h 7/5/01
 *
 * Funciton defintions relevant to alphabet.c pulled from HMMERs
 * funcs.h. May contain some chaff.
 */
extern void  DetermineAlphabet(char **rseqs, int  nseq);
extern void  SetAlphabet(int type);
extern int   SymbolIndex(char sym);
extern char *DigitizeSequence(char *seq, int L);
extern char *DedigitizeSequence(char *dsq, int L);

extern void  P7CountSymbol(float *counters, char sym, float wt);
extern void  DefaultGeneticCode(int *aacode);
extern void  DefaultCodonBias(float *codebias);

