/* inout_main.c 
 *
 * Verify that Inside and Outside work properly by
 * using the fact that posteriors can be used to
 * characterize a base as paired or unpaired.
 *
 * The sum of all states of a particular nucleotide
 * must be 1 (these are probabilities).
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-m <file>     : Use parameters, grammar and scoring specified in model <file> \n\
-g <string>   : Use grammar <string>, defaults to NUS; ignored if model file specified \n\
-x            : print out parameters of model \n\
-t            : print traceback\n\
-d            : debugging output \n\
-v            : verbose output \n\
-f            : debugging, print fill matrix from cyk \n\
-p            : print real with predicted structure\n\
-q            : print predicted structures in stockholm format \n\
";

static char usage[]  = "Usage: postcheck [-options] <seqfile in>\n";

int 
main (int argc, char **argv) 
{
   /**** arguments variables *****/
   int   optid; 
   OPTS settings;

   /* ReadSeq variables */
   SQFILE *sqfp; SQINFO sqinfo;
   int sformat;
   char *rna, *drna; 
   char *ss; 
   int *ctstruct; 

   /* Models info */
   MODEL nusmodel;
   PROBMOD dlogs;
   int ***insideMX, ***outsideMX;
   double ***idMX, ***odMX;
   int noerror, score;
   double sc;

   noerror = TRUE;

   if (!(ProcessOpts(&settings, &optid, argc, argv, usage, 
	       "\tNUS, YRN, UNA only!", optsline))) {
      printf("%s\n\n", usage);
      exit(0);
   }
   if (argc - optid != 1)
      Die("Incorrect number of command line arguments.\n%s\n%s\n", 
	    usage, optsline);

   SetupModel(&settings, &nusmodel);  
   DLogifySCFG(&(nusmodel.probs), &dlogs);
   LogifySCFG(&(nusmodel.probs), &(nusmodel.scores)); 

   if (!((settings.grammar == NUS) || (settings.grammar == UNA)
      || (settings.grammar == YRN))) {
      Die("Currently only available for NUS, UNA, and YRN!.\n%s\n%s\n", 
	    usage, optsline);
   }

   if (settings.modelfile == NULL) {
     nusmodel.grammar = settings.grammar;
     SetUpFlatMx(&(nusmodel.probs), settings.grammar);
     LogifySCFG(&(nusmodel.probs), &(nusmodel.scores)); 
   }

   if (settings.debugg) {
      PrintFullModel(settings.ofp, &nusmodel);
      PrintProbModel(stdout, &dlogs, NUS);
   }

   /* Read input file into RNA array and filter for non-RNA residues */
   if ((sqfp = SeqfileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL) 
          Die("Failed to open sequence file %s\n%s\n", argv[optid], usage);

   while (ReadSeq(sqfp, sformat, &rna, &sqinfo)) {
      ToRNA(rna);
      if (settings.verbose) fprintf(settings.ofp, "Sequence %s:\n", sqinfo.name);

      if (! KHS2ct(sqinfo.ss, sqinfo.len, FALSE, &ctstruct))
      { printf("[bad trusted structure]\n"); return (FALSE);}

      if (!settings.structout) {		/* Ignore given structure */
        ctstruct = NULL;
      } 

      noerror = Inside(rna, sqinfo.len, nusmodel.grammar, &dlogs, &settings, 
	    NULL, &sc, &idMX);
      printf("Inside score %f\n", sc);
      if (noerror) {
	 noerror = Outside(rna, sqinfo.len, nusmodel.grammar, &dlogs, 
	       &settings, NULL, idMX, &odMX);
      }
      if (noerror) {
	 posteriorCheck(idMX, odMX, rna, sqinfo.len, &dlogs, nusmodel.grammar);
      }
      freeFillMxD(odMX, nusmodel.grammar); 
      freeFillMxD(idMX, nusmodel.grammar); 
      FreeSequence(rna, &sqinfo);
   }
   SeqfileClose(sqfp);
}
