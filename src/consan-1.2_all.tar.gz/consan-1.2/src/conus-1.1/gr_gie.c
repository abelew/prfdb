/* gr_gie.c
 * RDD, Sun Feb 17 08:20:07 CST 2002
 *
 * Grammar specific routines for implementing the GIE grammar.
 *
 * Thu Feb 14 14:24:18 CST 2002
 *   Geigerich's Unambiguous Vienna:
 *    	S -> Q a...a | Q | QS
 *     	Q -> aPa' | a...aPa'
 *      P -> aPa' | aNa'
 *      N -> a...a | a...aPa' | aPa'...a | a...aPa'...a | QS
 *
 * These implementations assume a digitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"

/* Function: cykInitG
 * Date:     RDD, Fri Oct 12 13:56:34 2001 [St. Louis]
 *
 * Purpose:  Initialize CYK fill matrix for GIE  
 *
 * Args:     
 *	mx	fill matrix (integer log odds form)
 * 	len	sequence length
 *      grammar which grammar to utilize
 *
 * Returns:  -- void -- 
 */
void
cykInitG(int ***mx, INTMOD *model, char *rna, int len, int grammar)
{
  int i,j,k;

  for (i=0; i < len; i++) {
    for (j=0; j < len; j++) {
      for (k=0; k < NDPS; k++) {
	/* Diagonals of matricies */
	if (i == j) {
	} else {
	}
      } /* end for k */
    } /* end for j */
  } /* end for i */
}

/* Function: cykFillG
 * Date:     RDD, Fri Feb 15 11:30:37 CST 2002 [St Louis]
 *
 * Purpose:  Fills CYK matrix for GIE grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	sc	parameters 
 *		(integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *      grammar which grammar to utilize
 *
 * Returns:  void 
 */
void
cykFillG (int ***mx, INTMOD *pr, char *rna, int len, int grammar)
{
  int n, i, j, k, l;       /* Loop indicies */
  int max;              /* Maximum value seen so far */
  int cursc, cursc2;    /* Current score */
  int stackvalue;	

  /* Recursion */
  for (n = 1; n < len; n++) {
    for (i = 0; i < (len - n); i++) {
      j = i + n;  max = -BIGINT;

      /* P -> aPb | aNb  (stacking!) */
      /* Can't be in P state at edges!  */
      if ((i == 0) || (j == len-1)) {
        stackvalue = -BIGINT;
      } else {
        stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]];
      }
      cursc = mx[i+1][j-1][dpP] + stackvalue + pr->transitions[TPP];
      cursc2 = mx[i+1][j-1][dpN] + stackvalue + pr->transitions[TPN];
      if (cursc > cursc2) {
        mx[i][j][dpP] = cursc;
      } else {
        mx[i][j][dpP] = cursc2;
      }

      /* Q -> aPa' | a...aPa' */
      max = -BIGINT;
      cursc = mx[i+1][j-1][dpP] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TQP];
      if ((cursc > max) && (abs(i-j) > 1))  max = cursc;

      for (k = i+1; k < j; k++) {
        cursc = mx[k+1][j-1][dpP] + pr->pairs[rna[k]][rna[j]] 
			+ pr->loop[k-i] + pr->transitions[TQL];
        if ((cursc > max) && (abs(k-j) > 1)) max = cursc; 
      }
      
      /* R -> Qa...a | Q | QR */
      max = -BIGINT;
      for (k = i+1; k < j; k++) {
        cursc = mx[i][k][dpQ] + pr->loop[j-k] + pr->transitions[TRR];
        if (cursc > max) max = cursc; 
	if (k != j-1) {		/* Adjust for difference in max indicies */
          cursc = mx[i][k][dpQ] + mx[k+1][j][dpR] + pr->transitions[TRB];
          if (cursc > max) max = cursc; 
	}
      }
      cursc = mx[i][j][dpQ] + pr->transitions[TRQ];
      if (cursc > max) max = cursc;

      /* S -> R | a...a */
      max = -BIGINT;
      cursc = mx[i][j][dpR] + pr->transitions[TSR];
      cursc2 = pr->loop[j-i+1] + pr->transitions[TSS];
      if (cursc > cursc2) {
        mx[i][j][dpS] = cursc;
      } else {
        mx[i][j][dpS] = cursc2;
      }

      /* N -> a..a | a..aPa' | aPa'..a | a..aPa'..a | QR */
      max = -BIGINT; 
      cursc = pr->loop[j-i+1] + pr->transitions[TNH];
      for (k = i+1; k < j; k++) {
        cursc = mx[k+1][j-1][dpP] + pr->pairs[rna[k]][rna[j]] 
			+ pr->loop[k-i] + pr->transitions[TNL];
        if ((cursc > max) && (abs(k-j) > 1)) max = cursc; 
        cursc = mx[i+1][k-1][dpP] + pr->pairs[rna[i]][rna[k]] 
			+ pr->loop[j-k] + pr->transitions[TNR];
        if ((cursc > max) && (abs(i-k) > 1)) max = cursc; 
	if (k != j-1) {
	  for (l = k+1; l < j; l) {
          cursc = mx[k+1][l-1][dpP] + pr->loop[(j-l+k-i)] 
		  + pr->pairs[rna[k]][rna[l]] + pr->transitions[TNI];
          if ((cursc > max) && (abs(k-l) > 1)) max = cursc; 
	  }
          cursc = mx[i][k][dpQ] + mx[k+1][j][dpR] + pr->transitions[TNB];
          if (cursc > max) max = cursc; 
	}
      }
    }
  }
}

/* Function: cykTraceG
 * Date:     RDD, Fri Feb 15 11:30:37 CST 2002 [St Louis]
 *
 * Purpose:  Build traceback tree for GIE grammar
 *
 * Args:
 *	mx	matrix in which to calculate cyk
 *	pr	parameters in integer form
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns: --void --
 */
struct trace_s *
cykTraceG (int ***mx, INTMOD *pr, char *rna, int len, int grammar)
{
  int i, j, k, l, mtx;   /* Indices */
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (len -1), TRE));

  /* Repeat until stack is empty */
  while (curr = PopTracestack(stack)) {
    /* Set i and j from items in stack */
    i = curr->emitl; j = curr->emitr; mtx = curr->nonterminal;

    if (i > j) { 		/* Can this happen? */
      curr->emitl = -1; curr->emitr = -1; 
      curr->transition = TSS; curr->nonterminal = dpS; 
      continue;
    } else if (mtx == dpS) {
      /* S -> R | a...a */
      if (mx[i][j][dpR] + pr->transitions[TSR] == mx[i][j][dpS]) {
        curr->emitl = -1; curr->emitr = -1; curr->transition = TSR; 
        PushTracestack(stack, AttachTrace (curr, dpR, i, k, TRE));
      } else {
	curr->transition = TSS; 
      }
    } else if (mtx == dpR) {
      /* R -> Qa...a | Q | QR */
      if (mx[i][j][dpQ] + pr->transitions[TRQ] == mx[i][j][dpR]) {
        curr->emitl = -1; curr->emitr = -1; curr->transition = TRQ; 
        PushTracestack(stack, AttachTrace (curr, dpQ, i, j, TRE));
      } else {
        for (k = i+1; k < j; k++) {
	  if (mx[i][k][dpQ] + pr->loop[j-k] + pr->transitions[TRR] == mx[i][j][dpR]){
            curr->emitl = -1; curr->transition = TRR; 
            PushTracestack(stack, AttachTrace (curr, dpQ, i, k-1, TRE));
	    k = j;	/* Short circuit */
	  } else if (mx[i][k][dpQ] + mx[k+1][j][dpR] + pr->transitions[TRB] == mx[i][j][dpR]) {
            curr->emitl = -1; curr->emitr = -1; curr->transition = TRB; 
            PushTracestack(stack, AttachTrace (curr, dpQ, i, k, TRE));
            PushTracestack(stack, AttachTrace (curr, dpR, k+1, j, TRE));
	    k = j;	/* Short circuit */
          }
        }
      }
    } else if (mtx == dpP) {
      /* P -> aPb | aNb */
      if (mx[i+1][j-1][dpP] + pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]] 
		      + pr->transitions[TPP] == mx[i][j][dpP]) {
	curr->transition = TPP; 
        PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TRE));
      } else {
	curr->transition = TPN; 
        PushTracestack(stack, AttachTrace (curr, dpN, i+1, j-1, TRE));
      }
    } else if (mtx == dpQ) {
      /* Q -> aPa' | a...aPa' */
      if (mx[i+1][j-1][dpP] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TQP] == mx[i][j][dpQ]) {
	curr->transition = TQP; 
        PushTracestack(stack, AttachTrace (curr, dpP, k+1, j-1, TRE));
      } else {
        for (k = i+1; k < j; k++) {
	  if (mx[k+1][j-1][dpP] + pr->pairs[rna[k]][rna[j]] 
			+ pr->loop[k-i] + pr->transitions[TQL] == mx[i][j][dpQ]) {
	    curr->emitl = k; curr->transition = TQL; 
            PushTracestack(stack, AttachTrace (curr, dpP, k+1, j-1, TRE));
	    k = j;	/* Short circuit */
	  }
	}
      }
    } else if (mtx == dpN) {
      /* N -> a..a | a..aPa' | aPa'..a | a..aPa'..a | QR */
      if (pr->loop[j-i+1] + pr->transitions[TNH] == mx[i][j][dpN]) {
	curr->transition = TNH; 
      } else {
        for (k = i+1; k < j; k++) {
	  if (mx[k+1][j-1][dpP] + pr->pairs[rna[k]][rna[j]] 
			+ pr->loop[k-i] + pr->transitions[TNL] == mx[i][j][dpN]) {
	    curr->emitr = k; curr->emitl = j; curr->transition = TNL; 
            PushTracestack(stack, AttachTrace (curr, dpP, k+1, j-1, TRE));
	    k = j;	/* Short circuit */
	  } else if (mx[i+1][k-1][dpP] + pr->pairs[rna[i]][rna[k]] 
			+ pr->loop[j-k] + pr->transitions[TNR] == mx[i][j][dpN]) {
	    curr->emitl = k; curr->transition = TNR; 
            PushTracestack(stack, AttachTrace (curr, dpP, i+1, k-1, TRE));
	    k = j;	/* Short circuit */
	  } else if (mx[i][k][dpQ] + mx[k+1][j][dpR] + pr->transitions[TNB] == mx[i][j][dpN]) {
	    curr->emitr = -1; curr->emitl = -1; curr->transition = TNB; 
            PushTracestack(stack, AttachTrace (curr, dpQ, i, k, TRE));
            PushTracestack(stack, AttachTrace (curr, dpR, k+1, j, TRE));
	    k = j;	/* Short circuit */
	  } else {
            for (l = k+1; l < j; l++) {
              if (mx[k+1][l-1][dpP] + pr->loop[(j-l+k-i)] 
		  + pr->pairs[rna[k]][rna[l]] + pr->transitions[TNI] == mx[i][j][dpN]) {
	        curr->transition = TNI; 
                PushTracestack(stack, AttachTrace (curr, dpP, k+1, j, TRE));
	        k = j; l = j;	/* Short circuit */
	      }
	    }
	  }
	}
      }
    } else {
      printf("ERROR!! Nonterminal %d unkown in RUN/RYN traceback!\n", mtx);
    }
  }
  return parsetree;
}

void
khs2traceGIE (struct tracestack_s *dolist, int *ct, int grammar)
{
}

int
analyzeTraceG(char *seq, int len, struct trace_s *tr, INTMOD *cfg, int count)
{
   return 0;
}

