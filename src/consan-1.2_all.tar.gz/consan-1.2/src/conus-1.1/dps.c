/* dps.c
 * Fri Aug 24 12:51:19 2001
 * 
 * Allocation, free'ing, printing of the 
 * fill matrix 
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include "squid.h"
#include "cfg.h"

void AllocFillMx(int len, int ****ret_mx);
void FreeFillMx(int ***mx, int len);
void AllocFill2Mx(int len, int ****ret_mx);
void FreeFill2Mx(int ***mx);
void allocFillMx(int len, int ****ret_mx, int grammar);
void freeFillMx(int ***mx, int grammar);
void PrintFillMx(FILE *fp, int ***mx, char *rna, int len, int grammar);
void PrintFillProb(FILE *fp, int ***mx, char *rna, int len, int grammar);

void PrintFillMxD(FILE *fp, double ***mx, char *rna, int len, int grammar);

/*************** Allocation of full matrix *****************/
/* Function: AllocFillMx, FreeFillMx
 * Date:     Thu Nov 15 17:55:12 2001 [St. Louis]
 *
 * Purpose: Allocate space for the DP matrix 
 * 	Used for CYK, Inside and Outside
 * 	Allocates entire matrix (regardless of filling only 1/2)
 *
 * Notes: This is a 3D matrix (Length X Length X Nonterminals)
 *
 * Args:     
 *	len	length of the sequence
 *	ret_mx	pointer to the allocated space (returned)
 *
 * Returns:  void
 */
void
AllocFillMx(int len, int ****ret_mx)
{
  int ***mx;
  int    i,j;

  if ((mx = (int ***) malloc (len * sizeof(int **))) == NULL) Die("malloc failed");
  for (j = 0; j < len; j++)
    {
      if ((mx[j] = (int **) malloc (len * sizeof(int *))) == NULL)
        Die("malloc failed");
      if ((mx[j][0] = (int *) malloc (len * NDPS * sizeof(int))) == NULL)
        Die("malloc failed");
      for (i = 1; i < len; i++)
        mx[j][i] = mx[j][0] + (i * NDPS);
    }
  *ret_mx = mx;
}

void
FreeFillMx(int ***mx, int len)
{
  int j;

  for (j = 0; j < len; j++)
    {
      free(mx[j][0]);
      free(mx[j]);
    }
  free(mx);
}

/*************** Reduced Space *****************/
/* Function: AllocFill2Mx, FreeFill2Mx
 * Date:     Wed Oct 16 15:51:00 CDT 2002 [St Louis]
 *
 * Purpose: Allocate space for the DP matrix 
 * 	Used for CYK, Inside and Outside
 *
 * Assumption:
 * 	Allocates only 1/2 of matrix
 * 	Assumes (j,d) notation
 *
 * Notes: This is a 3D matrix (Nonterminal X Length X 1/2 Length)
 *
 * Args:     
 *	len	length of the sequence
 *	ret_mx	pointer to the allocated space (returned)
 *
 * Returns:  void
 */

void
AllocFill2Mx(int len, int ****ret_mx)
{
  int ***mx;
  int i,j, tmp;

  if ((mx = (int ***) malloc (NDPS * sizeof(int **))) == NULL) Die("malloc failed");
  for (j = 0; j < NDPS; j++) {
     if ((mx[j] = (int **) malloc (len * sizeof(int *))) == NULL)
	Die("malloc failed");
     tmp = ((len * (len+1))/2) + len;
     if ((mx[j][0] = (int *) malloc (tmp * sizeof(int))) == NULL)
	Die("malloc failed");
     for (i = 1; i < len; i++) {
	tmp = (i*(i+1)/2) + i;
	mx[j][i] = mx[j][0] + tmp;
	/* printf("%d %d at %d \n", j, i, tmp);  */
     }
  }
  *ret_mx = mx;
}

void
FreeFill2Mx(int ***mx)
{
  int j;

  for (j = 0; j < NDPS; j++)
    {
      free(mx[j][0]);
      free(mx[j]);
    }
  free(mx);
}

/*************** Perfect Fit *****************/
/* Function: allocFillMx, freeFillMx
 * Date:     Wed Oct 16 15:51:00 CDT 2002 [St Louis]
 *
 * Purpose: Allocate space for the DP matrix 
 * 	Used for CYK, Inside and Outside
 *
 * Notes: This is a 3D matrix (Nonterminals X Length X 1/2 Length)
 * 	This is a "true fit" allocation -- so boundry checking
 * 	is going to become critical!
 *
 * Assumption:
 * 	This assumes the (j,d) notation.
 *
 * Args:     
 *	len	length of the sequence
 *	ret_mx	pointer to the allocated space (returned)
 *	grammar	Grammar for which this will be used.
 *
 * Returns:  void
 */
void
allocFillMx(int len, int ****ret_mx, int grammar)
{
  int ***mx;
  int    i,j, tmp;

  if ((mx = (int ***) malloc (NDPS * sizeof(int **))) == NULL) Die("malloc failed");
  for (j = 0; j < NDPS; j++) {
     if (Contains[grammar][j]) {
	if ((mx[j] = (int **) malloc (len * sizeof(int *))) == NULL)
	   Die("malloc failed");
	tmp = ((len * (len+1))/2) + len;
	if ((mx[j][0] = (int *) malloc (tmp * sizeof(int))) == NULL)
	   Die("malloc failed");
	for (i = 1; i < len; i++) {
	   tmp = (i*(i+1)/2) + i;
	   mx[j][i] = mx[j][0] + tmp;
	   /* printf("%s %d at %d \n", dpNAME[j], i, tmp); */
	}

     } else {
	mx[j] = NULL;	/* Unused nonterminal matrix */
     }
  }
  *ret_mx = mx;
}

void
freeFillMx(int ***mx, int grammar)
{
  int j;

  for (j = 0; j < NDPS; j++) {
     if (Contains[grammar][j]) {
	free(mx[j][0]);
	free(mx[j]);  
     }
  }
  free(mx); 
}

/*************** Doubles:: Perfect Fit *****************/
/* Function: allocFillMxD, freeFillMxD
 * Date:     Wed Oct 16 15:51:00 CDT 2002 [St Louis]
 *
 * Purpose: Allocate space for the DP matrix 
 * 	Used for CYK, Inside and Outside
 *
 * Notes: This is a 3D matrix (Nonterminals X Length X 1/2 Length)
 * 	This is a "true fit" allocation -- so boundry checking
 * 	is going to become critical!
 *
 * Assumption:
 * 	This assumes the (j,d) notation.
 *
 * Args:     
 *	len	length of the sequence
 *	ret_mx	pointer to the allocated space (returned)
 *	grammar	Grammar for which this will be used.
 *
 * Returns:  void
 */
void
allocFillMxD(int len, double ****ret_mx, int grammar)
{
  double ***mx;
  int    i,j, tmp;
  int count;

  if ((mx = (double ***) malloc (NDPS * sizeof(double **))) == NULL) Die("malloc failed");
  for (j = 0; j < NDPS; j++) {
     if (Contains[grammar][j]) {
	if ((mx[j] = (double **) malloc (len * sizeof(double *))) == NULL)
	   Die("malloc failed");
	tmp = ((len * (len+1))/2) + len;
	if ((mx[j][0] = (double *) malloc (tmp * sizeof(double))) == NULL)
	   Die("malloc failed");
	for (i = 1; i < len; i++) {
	   tmp = (i*(i+1)/2) + i;
	   mx[j][i] = mx[j][0] + tmp;
	   /* printf("%s %d at %d \n", dpNAME[j], i, tmp);   */
	}

     } else {
	mx[j] = NULL;	/* Unused nonterminal matrix */
     }
  }
  *ret_mx = mx;
}

void
freeFillMxD(double ***mx, int grammar)
{
  int j;

  for (j = 0; j < NDPS; j++) {
     if (Contains[grammar][j]) {
	free(mx[j][0]);
	free(mx[j]);  
     }
  }
  free(mx); 
}

/* Function: PrintFillMx()
 * Date:     Sat Dec  8 16:09:49 2001 [St. Louis]
 *
 * Purpose:  For debugging: print a matrix out.
 *
 * Args:     fp   - open FILE ptr to write to (stdout, perhaps)
 *           mx   - DP matrix
 *           rna  - sequence
 *           len  - width/height of mx
 *
 * Return:   (void)
 */
void
PrintFillMx(FILE *fp, int ***mx, char *rna, int len, int grammar)
{
  int i, j, k;

  fprintf(fp, "Using %d %s Grammar in ", grammar, grNAME[grammar]);
  fprintf(fp, "### Here's the DP matrix (length is %d):\n", len);
  for (k = 0; k < NDPS; k++) {
    if (contains_rule(grammar, k)) {
      fprintf(fp, "%s\n", dpNAME[k]); 

      /* NDPS x len x len */
      fprintf(fp, "%9s ", " "); 
      for (i = 0; i <= len; i++) {
	 fprintf(fp, "%9d ", i);
      }
      fputs("\n", fp);

      for (j = 0; j < len; j++) {
	 fprintf(fp, "%4d%5c ",j, toupper(rna[j])); 
	 for (i = 0; i <= len; i++) {   /* actually this is d */
	    if (i-1 <= j) fprintf(fp, "%9d ", mx[k][j][i]);
	    else fprintf(fp, "%9s ", "-");
	 }
	 fputs("\n", fp);
      }
      fputs("\n", fp);
    }
  }
}

/* Function: PrintFillMxD
 * Date:     Sat Dec  8 16:09:49 2001 [St. Louis]
 *
 * Purpose:  For debugging: print a matrix out.
 *
 * Args:     fp   - open FILE ptr to write to (stdout, perhaps)
 *           mx   - DP matrix, len x len x NDPS 
 *           rna  - sequence
 *           len  - width/height of mx
 *
 * Return:   (void)
 */
void
PrintFillMxD(FILE *fp, double ***mx, char *rna, int len, int grammar)
{
   int k, j, d;

   fprintf(fp, "Using %d %s Grammar in ", grammar, grNAME[grammar]);
   fprintf(fp, "### Here's the DP matrix (length is %d):\n", len);
   for (k = 0; k < NDPS; k++) {
      if (contains_rule(grammar, k)) {
	 fprintf(fp, "%s\n", dpNAME[k]); 

	 fprintf(fp, "%9s ", " "); 
	 for (d = 0; d <= len; d++) {
	    fprintf(fp, "%12d ", d);
	 }
	 fputs("\n", fp);

	 for (j = 0; j < len; j++) {
	    fprintf(fp, "%4d%5c ",j, toupper(rna[j])); 
	    for (d = 0; d <= len; d++) {   /* actually this is d */
	       if (d-1 <= j) fprintf(fp, "%f ", mx[k][j][d]);
	       else fprintf(fp, "%12s ", "-");
	    }
	    fputs("\n", fp);
	 }
	 fputs("\n", fp);
      }
   }
}

/* Function: PrintFillProb()
 * Date:     Tue Sep  3 12:25:41 CDT 2002 [St Louis]
 *
 * Purpose:  For debugging: print a matrix out as Probs
 *
 * Args:     fp   - open FILE ptr to write to (stdout, perhaps)
 *           mx   - DP matrix, len x len x NDPS 
 *           rna  - sequence
 *           len  - width/height of mx
 *
 * Return:   (void)
 */
void
PrintFillProb(FILE *fp, int ***mx, char *rna, int len, int grammar)
{
  int i, j, k;

  fprintf(fp, "Using %d %s Grammar in ", grammar, grNAME[grammar]);
  fprintf(fp, "### Here's the DP matrix (length is %d):\n", len);
  for (k = 0; k < NDPS; k++) {
     if (contains_rule(grammar, k)) {
	fprintf(fp, "%s\n", dpNAME[k]); 

	fprintf(fp, "%9s ", " "); 
	for (i = 0; i <= len; i++) {
	   fprintf(fp, "%12d ", i);
	}
	fputs("\n", fp);

	for (j = 0; j < len; j++) {
	   fprintf(fp, "%4d%5c ",j, toupper(rna[j])); 
	   for (i = 0; i <= len; i++) {   /* actually this is d */
	      if (i-1 <= j) fprintf(fp, "%11.10f ", asFloatProb(mx[k][j][i]));
	      else fprintf(fp, "%12s ", "-");
	   }
	   fputs("\n", fp);
	}
     }
  }
}

/* PrintFillProbD()
 * Date:     Tue Sep  3 12:25:41 CDT 2002 [St Louis]
 *
 * Purpose:  For debugging: print a matrix out as Probs
 *
 * Args:     fp   - open FILE ptr to write to (stdout, perhaps)
 *           mx   - DP matrix, len x len x NDPS 
 *           rna  - sequence
 *           len  - width/height of mx
 *
 * Return:   (void)
 */
void
PrintFillProbD(FILE *fp, double ***mx, char *rna, int len, int grammar)
{
  int i, j, k;

  fprintf(fp, "Using %d %s Grammar in ", grammar, grNAME[grammar]);
  fprintf(fp, "### Here's the DP matrix (length is %d):\n", len);
  for (k = 0; k < NDPS; k++) {
     if (contains_rule(grammar, k)) {
	fprintf(fp, "%s\n", dpNAME[k]); 

	fprintf(fp, "%9s ", " "); 
	for (i = 0; i <= len; i++) {
	   fprintf(fp, "%12d ", i);
	}
	fputs("\n", fp);

	for (j = 0; j < len; j++) {
	   fprintf(fp, "%4d%5c ",j, toupper(rna[j])); 
	   for (i = 0; i <= len; i++) {   /* actually this is d */
	      if (i-1 <= j) fprintf(fp, "%11.10f ", asProb(mx[k][j][i]));
	      else fprintf(fp, "%12s ", "-");
	   }
	   fputs("\n", fp);
	}
	fputs("\n", fp);
     }
  }
}

/* Function: PrintBigFilljdMx
 * Date:     Sat Feb 15 13:26:02 CST 2003 [St Louis]
 *
 * Purpose:  For debugging: print a matrix out.
 *
 * Args:     fp   - open FILE ptr to write to (stdout, perhaps)
 *           mx   - DP matrix, len x len x NDPS 
 *           rna  - sequence
 *           len  - width/height of mx
 *
 * Return:   (void)
 */
void
PrintBigFilljdMx(FILE *fp, int ***mx, char *rna, int len, int grammar)
{
   int k, j, d;
   int block, edge;

   fprintf(fp, "Using %d %s Grammar in ", grammar, grNAME[grammar]);
   fprintf(fp, "### Here's the DP matrix (length is %d):\n", len);
   for (k = 0; k < NDPS; k++) {
      if (contains_rule(grammar, k)) {
	 fprintf(fp, "%s\n", dpNAME[k]); 

	 for (block = 0; block <= len; block = block + 10) {
	    edge = block + 9;
	    if (edge > len) edge = len;

	    fprintf(fp, "%9s ", " "); 
	    for (d = block; d <= edge; d++) {
	       fprintf(fp, "%12d ", d);
	    }
	    fputs("\n", fp);

	    for (j = 0; j < len; j++) {
	       fprintf(fp, "%4d%5c ",j, toupper(rna[j])); 
	       for (d = block; d <= edge; d++) {   /* actually this is d */
		  if (d-1 <= j) fprintf(fp, "%12d ", mx[k][j][d]);
		  else fprintf(fp, "%12s ", "-");
	       }
	       fputs("\n", fp);
	    }
	 }
	 fputs("\n", fp);
      }
   }
}

/* Function: PrintIndFillMx
 * Date:     Wed Mar 26 13:50:46 CST 2003 [St Louis]
 *
 * Purpose:  For debugging: print a matrix out.
 *
 * Args:     fp   - open FILE ptr to write to (stdout, perhaps)
 *           mx   - DP matrix, len x len x NDPS 
 *           rna  - sequence
 *           len  - width/height of mx
 *
 * Return:   (void)
 */
void
PrintIndFillMx(FILE *fp, int ***mx, char *rna, int len, int grammar, int nonterminal)
{
   int k, j, d;
   int block, edge;

   if (!Contains[grammar][nonterminal]) {
      printf("Requested %s printed, not available in %s grammar!\n", 
	    	dpNAME[nonterminal], grNAME[grammar]);
      return;
   }
   fprintf(fp, "Using %d %s Grammar in ", grammar, grNAME[grammar]);

   fprintf(fp, "### Here's the %s matrix (length is %d):\n", dpNAME[nonterminal], len);

   k = nonterminal;
   if (contains_rule(grammar, k)) {
      fprintf(fp, "%s\n", dpNAME[k]); 

      for (block = 0; block <= len; block = block + 9) {
	 edge = block + 8;
	 if (edge > len) edge = len;

	 fprintf(fp, "%9s ", " "); 
	 for (d = block; d <= edge; d++) {
	    fprintf(fp, "%12d ", d);
	 }
	 fputs("\n", fp);

	 for (j = 0; j < len; j++) {
	    fprintf(fp, "%4d%5c ",j, toupper(rna[j])); 
	    for (d = block; d <= edge; d++) {   /* actually this is d */
	       if (d-1 <= j) fprintf(fp, "%12d ", mx[k][j][d]);
	       else fprintf(fp, "%12s ", "-");
	    }
	    fputs("\n", fp);
	 }
      }
      fputs("\n", fp);
   }
}

/* Function: PrintBigFillijMx
 * Date:     Sat Feb 15 13:26:02 CST 2003 [St Louis]
 *
 * Purpose:  For debugging: print a matrix out.
 *
 * Args:     fp   - open FILE ptr to write to (stdout, perhaps)
 *           mx   - DP matrix, len x len x NDPS 
 *           rna  - sequence
 *           len  - width/height of mx
 *
 * Return:   (void)
 */
void
PrintBigFillijMx(FILE *fp, int ***mx, char *rna, int len, int grammar)
{
   int k, i, j;
   int block, edge;

   fprintf(fp, "Using %d %s Grammar in ", grammar, grNAME[grammar]);
   fprintf(fp, "### Here's the DP matrix (length is %d):\n", len);
   for (k = 0; k < NDPS; k++) {
      if (contains_rule(grammar, k)) {
	 fprintf(fp, "%s\n", dpNAME[k]); 

	 for (block = 0; block <= len; block = block + 10) {
	    edge = block + 10;
	    if (edge > len) edge = len;

	    fprintf(fp, "%9s ", " "); 
	    for (j = block; j < edge; j++) {
	       fprintf(fp, "%12d ", j);
	    }
	    fputs("\n", fp);

	    for (i = 0; i < len; i++) {
	       fprintf(fp, "%4d%5c ",i, toupper(rna[i])); 
	       for (j = block; j < edge; j++) {   /* actually this is d */
		  if (j+1 >= i) fprintf(fp, "%12d ", mx[i][j][k]);
		  else fprintf(fp, "%12s ", "-");
	       }
	       fputs("\n", fp);
	    }
	 }
	 fputs("\n", fp);
      }
   }
}
/*************** Used in development *****************/
/* Function: Alloc2DMx, Free2DMx
 * Date:     Thu Nov 15 17:55:12 2001 [St. Louis]
 *
 * Purpose: Allocate space for the DP matrix 
 * 	Used for CYK, Inside and Outside
 *
 * Notes: This is a 2D matrix (Length X Length)
 *
 * Args:     
 *	len	length of the sequence
 *	ret_mx	pointer to the allocated space (returned)
 *
 * Returns:  void
 */
void
Alloc2DMx (int len, int ***ret_mx) 
{
  int **mtx;
  int i,j;

  if (((mtx = (int **) malloc (sizeof(int *) * len)) == NULL) ||
     ((mtx[0] = (int *) malloc (sizeof (int) * len * len)) == NULL)) Die("malloc failed");
  for (i = 1; i < len; i++) {
    mtx[i] = mtx[0] + i*len;
  }

  for (i = 0; i < len; i++) {
    for (j = 0; j < len; j++) {
      mtx[i][j] = 0;
    }
  }
  *ret_mx = mtx;
}

Free2DMx(int ***mx, int len)
{
  int j;

  for (j = 0; j < len; j++)
    {
      free(mx[j]);
    }
  free(mx);
}

