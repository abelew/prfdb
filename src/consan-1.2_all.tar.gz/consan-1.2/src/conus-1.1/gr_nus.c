/* gr_nus.c
 * Fri Oct 12 13:56:34 2001
 *
 * Implementations of the grammar specific functions for NUS
 *
 * Thu Aug 23 17:19:01 2001 
 * Nussinov:  S -> aSa' | aS | Sa | SS | end	(NUS)
 *
 * Implementation Notes:
 *
 * These implementations assume a digitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"

/*************************  CYK ********************************/
/* Function: cykInitNUS
 * Date:     Fri Oct 12 13:56:34 2001 [St. Louis]
 *
 * Purpose:  Initialize CYK fill matrix for NUS grammar
 * Assumption: Fill matrix already allocated 
 *
 * Args:     
 *	mx	fill matrix (integer log odds form)
 *	model 	parameters (integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cykInitNUS(int ***mx, INTMOD *model, char *rna, int len)
{
  int j, d;

  for (d = 0; d <= len; d++) {
     for (j = (d > 0? d-1:  d); j < len; j++) {
	mx[dpS][j][d] = model->transitions[TSE];	/* S -> end */
     } /* end for j */
  } /* end for i */
}

/* Function: cykFillNUS
 * Date:     Fri Oct 12 09:10:06 CDT 2001 [St Louis]
 *
 * Purpose:  Fills CYK matrix for NUS grammar
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	pr	parameters (integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
cykFillNUS (int ***mx, INTMOD *pr, char *rna, int len)
{
  int d, i, j, k;       /* Loop indicies */
  int max;              /* Maximum value seen so far */
  int cursc;

  /* Recursion */
  for (d = 1; d <= len; d++) {
    for (j = d-1; j < len; j++) {
       i = j - d + 1; max = -BIGINT;

      /* S -> aS */
      cursc = mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL];
      if (cursc > max) max = cursc; 

      /* S -> Sb */
      if (j > 0) 
        cursc = mx[dpS][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR];
      if (cursc > max) max = cursc;

      /* S -> SS */
      for (k = i; k < j; k++) {
        cursc = mx[dpS][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] + pr->transitions[TSB];
        if (cursc > max) max = cursc;
      }

      /* S -> aSb */
      if ((j > 0) && (d > 1)) 
        cursc = mx[dpS][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
	   + pr->transitions[TSS];
      if ((cursc > max) && (lplen(i,j) >= HLEN)) max = cursc;

      /* S -> aSb | aS | Sb | SS | end */
      mx[dpS][j][d] = max;
    } /* End for loop */
  } /* End foreach n */
}

/* Function: cykTraceNUS
 * Date:     Mon Aug 27 13:44:16 2001 [St. Louis]
 *
 * Purpose:  Build traceback tree for scoring NUSsinov 
 * Assumption: Fill matrix already allocated, initialized, and filled
 *
 * Args:
 *	mx	matrix in which to calculate cyk
 *	pr	parameters in integer form
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns: traceback tree
 */
struct trace_s *
cykTraceNUS (int ***mx, INTMOD *pr, char *rna, int len)
{
  int d, i, j, k, mtx;   /* Indices */
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (len -1), TSE));

  /* Repeat until stack is empty */
  while (curr = PopTracestack(stack)) {
    /* Set i and j from items in stack */
    i = curr->emitl; j = curr->emitr; mtx = curr->nonterminal; d = j - i + 1;

    /* S -> aSb | aS | Sb | SS | end */
    if (i > j) { 		/* S -> end */
      curr->emitl = -1; curr->emitr = -1;
      curr->transition = TSE; curr->nonterminal = dpE; 
      continue;
    } else {  /* (mtx == dpS) */
       /* Single nt seq's:: select "better" */
       if (i == j) {
	  if (pr->transitions[TSR] >= pr->transitions[TSL]) {
	     curr->emitl = -1; curr->transition = TSR; 
	     PushTracestack(stack, AttachTrace (curr, dpS, i, j-1, TSE));
	  } else {
	     curr->emitr = -1; curr->transition = TSL; 
	     PushTracestack(stack, AttachTrace (curr, dpS, i+1, j, TSE));
	  }
       } else if ((mx[dpS][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR]) == mx[dpS][j][d]) {
	  curr->emitl = -1; curr->transition = TSR; 
	  PushTracestack(stack, AttachTrace (curr, dpS, i, j-1, TSE));
       } else if ((mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL]) == mx[dpS][j][d]) {
	  curr->emitr = -1; curr->transition = TSL; 
	  PushTracestack(stack, AttachTrace (curr, dpS, i+1, j, TSE));
       /* Must check lplen here because with simple scoring schemes (+1)
	* a number of choices could be equivalent even when this one should
	* be illegal.  */
       } else if ((lplen(i,j) >=HLEN) && ((mx[dpS][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TSS]) == mx[dpS][j][d])) {
	  curr->transition = TSS;
	  PushTracestack(stack, AttachTrace (curr, dpS, i+1, j-1, TSE));
       } else {
	  for (k = i; k < j; k++) {
	     if ((mx[dpS][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] + pr->transitions[TSB]) == mx[dpS][j][d]) {
		curr->emitl = -1; curr->emitr = -1; curr->transition = TSB;
		PushTracestack(stack, AttachTrace (curr, dpS, k+1, j, TSE));
		PushTracestack(stack, AttachTrace (curr, dpS, i, k, TSE));
		k = j;	/* Short circuit */
	     } /* End if */
	  } /* End for (bifurcation points) */
       } /* End if i <= j */
    } /* End if dpS, dpL or dpR */
  } /* end while stack not empty*/
  FreeTracestack(stack);
  return parsetree;
}

/*************************  TRAIN ******************************/
/* Function: khs2traceNUS
 * Date:     Tue Apr 23 09:39:24 2002 [St. Louis]
 *
 * Purpose: Convert KHS to traceback tree properly 
 * 	labeled for NUS grammar.
 *
 * Args:     
 *	dolist  Traceback tree to build from KHS	
 *	ct	KHS info represented as ct format
 */
int
khs2traceNUS(struct tracestack_s *dolist, int *ct)
{
  struct trace_s      *cur;
  int  i,j, mid;

  while ((cur = PopTracestack(dolist)) != NULL) {
    i = cur->emitl; j = cur->emitr; 

    if (i > j) {
      cur->emitl = -1; cur->emitr = -1; 
      cur->transition = TSE; cur->nonterminal = dpE;
    } else if (ct[j] == -1) {   /* j unpaired: single strand right */
      cur->transition = TSR; cur->emitl = -1;
      PushTracestack(dolist, AttachTrace(cur, dpS, i, j-1, TSE));
    } else if (ct[i] == -1) {   /* i unpaired; single strand left */
      cur->transition = TSL; cur->emitr = -1;
      PushTracestack(dolist, AttachTrace(cur, dpS, i+1, j, TSE));
    } else if (ct[i] == j) {    /* i,j paired to each other */
      cur->transition = TSS;
      PushTracestack(dolist, AttachTrace(cur, dpS, i+1, j-1, TSE));
    } else {			/* i,j pair; not to each other */
      cur->transition = TSB; 
      cur->emitl = -1; cur->emitr = -1;
      mid = (random() % 2) ? ct[i] : ct[j]-1;
      PushTracestack(dolist, AttachTrace(cur, dpS, mid+1, j, TSE));
      PushTracestack(dolist, AttachTrace(cur, dpS, i, mid, TSE));
    }
  }
  return 1;
}

/************************** disambiguation ************************/
/* Function: probifyNUS
 * Date:     Sat Dec  8 16:08:01 2001 [St. Louis]
 * 
 * Purpose:  Properly convert counts to probabilities
 *           for transitions of NUSsinov grammar
 *
 * Args:     
 *      icfg     counts form of parameters
 *      ret_cfg  probabilistic form of parameters
 *      prior    + constant (usually 1) for prior
 *
 * Returns:  nothing.
 */ 
void
probifyNUS (INTMOD *icfg, PROBMOD *ret_cfg, INTMOD *prior)
{
  int   denom;                /* sum used for normalization in denominator */
  int   ssregion;
  int i;

  denom = (icfg->transitions[TSS] + prior->transitions[TSS]) +
          (icfg->transitions[TSL] + prior->transitions[TSL]) +
          (icfg->transitions[TSR] + prior->transitions[TSR]) + 
	  (icfg->transitions[TSB] + prior->transitions[TSB]) + 
          (icfg->transitions[TSE] + prior->transitions[TSE]);
  ret_cfg->transitions[TSS] = (double)(icfg->transitions[TSS] 
	+ prior->transitions[TSS]) / (double) denom;
  ret_cfg->transitions[TSB] = (double) (icfg->transitions[TSB] 
	+ prior->transitions[TSB]) / (double) denom; 
  ret_cfg->transitions[TSE] = (double) (icfg->transitions[TSE] 
	+ prior->transitions[TSE]) / (double) denom;
  /* Assume single stranded regions are equally likely from TSR as TSL 
   * */
  ssregion = (((icfg->transitions[TSL] + prior->transitions[TSL]) +
          (icfg->transitions[TSR] + prior->transitions[TSR])) / 2 );
  ret_cfg->transitions[TSL] = (double) ssregion / (double) denom;
  ret_cfg->transitions[TSR] = (double) ssregion / (double) denom;

  /* An alternative is to not assume equally likely -- so we're forcing
   * a sort of disambiguation
  ret_cfg->transitions[TSL] = (double) (icfg->transitions[TSL] + prior->transitions[TSL]) / 
     					(double) denom;
  ret_cfg->transitions[TSR] = (double) (icfg->transitions[TSR] + prior->transitions[TSR]) / 
     					(double) denom;
   * */
}

/* Function: analyzeTraceN
 * Date:     Tue May 14 15:10:54 CDT 2002 [St Louis]
 *
 * Purpose: Parse a traceback tree for information.
 *	Either for counts (training).
 *	Or for determining tracebcak score.
 *
 * Grammars: NUS, UNA, UYN, YRN(?)
 *
 * Args:     
 *      seq   - sequence corresponding to the trace
 *      len   - length of the sequence
 *      tr    - traceback to count
 *      cfg   - model, counts form, to add counts to
 *      count - if TRUE this is TraceCount; 
 *		if FALSE this is TraceScore
 *
 * Returns:  score of current traceback (in TraceScore mode)
 * 	Should return zero in TraceCount mode
 */
int
analyzeTraceN(char *seq, int len, struct trace_s *tr, INTMOD *cfg, int count) 
{
  struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
  struct trace_s      *cur;     /* current node in the tree              */
  char *iseq;                   
  int   cst, nst, j;
  char left; char right;
  int score;

 /* Digitize Sequence setup */
  SetAlphabet(hmmNUCLEIC);

  iseq = DigitizeSequence(seq, len);

  dolist = InitTracestack();
  PushTracestack(dolist, tr->nxtl);

  score = 0; 

  while ((cur = PopTracestack(dolist)) != NULL) {
    if (cur->transition < NTRANS) {

      if (count) cfg->transitions[cur->transition] += 1;
      else score += cfg->transitions[cur->transition];

      if (cur->transition == TRE) {	/* do nothing on ENDS */
	continue;
      }
      /* bifurcations */
      else if ((cur->transition == TSB) || (cur->transition == TNB)) {
	PushTracestack(dolist, cur->nxtr);
	PushTracestack(dolist, cur->nxtl);
      }
	/* Non emitting states */
      else if ((cur->emitl == -1) && (cur->emitr == -1)) {
	PushTracestack(dolist, cur->nxtl);
      }
      else {
	 if (cur->emitl == -1) {
	    if (iseq[cur->emitr] > ALPHA) {
	       /* Do nothing, contains an ambiguous base! 
		* Therfore must back out of counting transition!  */
	       if (count) cfg->transitions[cur->transition] -= 1;
	    } else {
	       if (count) cfg->singles[iseq[cur->emitr]] += 1;
	       else score +=  cfg->singles[iseq[cur->emitr]];
	   }

	/* Emit to left */
	} else if (cur->emitr == -1) {
	   if (iseq[cur->emitl] > ALPHA) {
	      /* Do nothing, contains an ambiguous base! 
	       * Therfore must back out of counting transition!  */
	      if (count) cfg->transitions[cur->transition] -= 1;
	   } else {
	      if (count) cfg->singles[iseq[cur->emitl]] += 1;
	      else score += cfg->singles[iseq[cur->emitl]];
	   }

	/* Emit aligned pair -- stacking model */
        } else if (cur->nonterminal == dpP) {
          if ((iseq[cur->emitl -1] > ALPHA) || (iseq[cur->emitr +1] > ALPHA)) {
		/* Do nothing, contains an ambiguous base! 
		 * Therfore must back out of counting transition!
 		 */
	    if (count) cfg->transitions[cur->transition] -= 1;
          } else {
            if (count) {
	      cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
			[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
	      /* By also adding to pairs, it is like you are 
	       * averaging the pair emissions over all pairs 
	       * (including stacks) */
	      cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
            } else {
              score += cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
			[iseq[cur->emitl]][iseq[cur->emitr]];
            }
          }

	/* Emit aligned pair -- no stacking */
	} else {
          if (count) cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
          else score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	}
	PushTracestack(dolist, cur->nxtl);
      }
    } else {
      PushTracestack(dolist, cur->nxtl);
    }
  }
  free(iseq);
  FreeTracestack(dolist);
  return score;
}

/* Function: dTraceScoreN
 * Date:     Mon Oct 27 16:04:26 CST 2003 [St Louis]
 *
 * Purpose: Parse a traceback tree for 
 *	for determining tracebcak score (using floats).
 *	(Used in ambiguity testing)
 *
 * Grammars: NUS, UNA, UYN 
 *
 * Args:     
 *      seq   - sequence corresponding to the trace
 *      len   - length of the sequence
 *      tr    - traceback to count
 *      cfg   - model (float log form)
 *      ret_val - score of trace as float log
 *
 * Returns:  void
 */
void
dTraceScoreN(char *seq, int len, struct trace_s *tr, PROBMOD *cfg, double *ret_val)
{
  struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
  struct trace_s      *cur;     /* current node in the tree              */
  char *iseq;                   
  int   cst, nst, j;
  char left; char right;
  double score;

 /* Digitize Sequence setup */
  SetAlphabet(hmmNUCLEIC);

  iseq = DigitizeSequence(seq, len);

  dolist = InitTracestack();
  PushTracestack(dolist, tr->nxtl);

  score = 0.; 

  while ((cur = PopTracestack(dolist)) != NULL) {
    if (cur->transition < NTRANS) {

      score += cfg->transitions[cur->transition];

      if (cur->transition == TRE) {	/* do nothing on ENDS */
	continue;
      }
      /* bifurcations */
      else if ((cur->transition == TSB) || (cur->transition == TNB)) {
	PushTracestack(dolist, cur->nxtr);
	PushTracestack(dolist, cur->nxtl);
      }
	/* Non emitting states */
      else if ((cur->emitl == -1) && (cur->emitr == -1)) {
	PushTracestack(dolist, cur->nxtl);
      }
      else {
	 /* Emit to right */
	 if (cur->emitl == -1) {
	    if (iseq[cur->emitr] > ALPHA) {
	       /* Do nothing */
	    } else {
	       score += cfg->singles[iseq[cur->emitr]];
	    }

	    /* Emit to left */
	 } else if (cur->emitr == -1) {
	    if (iseq[cur->emitl] > ALPHA) {
	       /* Do nothing */
	    } else {
	       score += cfg->singles[iseq[cur->emitl]];
	    }

	/* Emit aligned pair -- stacking model */
        } else if (cur->nonterminal == dpP) {
          if ((iseq[cur->emitl -1] > ALPHA) || (iseq[cur->emitr +1] > ALPHA)) {
		/* Do nothing, contains an ambiguous base! 
		 * Therfore must back out of counting transition!
 		 */
          } else {
              score += cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
			[iseq[cur->emitl]][iseq[cur->emitr]];
          }

	/* Emit aligned pair -- no stacking */
	} else {
          score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	}
	PushTracestack(dolist, cur->nxtl);
      }
    } else {
      PushTracestack(dolist, cur->nxtl);
    }
  }
  free(iseq);
  FreeTracestack(dolist);
  *ret_val = score;
}

/************************* Inside ********************************/
/* Function: insideInitNUS
 * Date:     Dec 13 08:13:55 CDT 2002 [St Louis]
 *
 * Purpose:  Initialize Inside fill matrix for NUS grammar
 * Assumption: Fill matrix already allocated 
 *
 * Args:     
 *	mx	where to store inside (matrix to fill)
 *	model	integer log form of parameters
 *	rna	Sequence to be analyzed
 * 	len	sequence length
 *
 * Notes:  To initialize the "lower" half of the matrix:
 *   \alpha_{nonterminal}(i+1, i) = 1 for nontermianls with \epsilon
 *   				  = 0 otherwise
 * To initalize the diagonal (i == j) we calculate the inside
 *  	variable (\alpha) for each nontermianl type assuming
 *  	the values above for all \alpha_{nontemrainl}(i,j) where
 *  	i > j.
 *
 * Returns:  -- void -- 
 */
void
insideInitNUS(double ***mx, PROBMOD *model, char *rna, int len)
{
   int d,j;

  for (d = 0; d <= len; d++) {
     for (j = d; j < len; j++) {
        mx[dpS][j][d] = model->transitions[TSE];
     } /* end for j */
     if (d > 0) mx[dpS][d-1][d] = model->transitions[TSE];	
  } /* end for d */
}

/* Function: insideFillNUS
 * Date:     Dec 13 08:53:15 CDT 2002 [St Louis]
 *
 * Purpose:  Fills inside matrix for NUS grammar
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	pr	parameters (integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
insideFillNUS(double ***mx, PROBMOD *pr, char *rna, int len)
{
  int d, i, j, k;       /* Loop indicies */
  double cursc;		/* Current score */
  int debug;	

  debug = FALSE;

  /* Recursion */
  for (d = 1; d <= len; d++) {
    for (j = d-1; j < len; j++) {
       i = j - d + 1; 

      /* S -> aS | Sa */
      if ((j == 0) && (d == 1)) {
        cursc = DLogsum(mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL],
	      mx[dpS][j][d-1] + pr->singles[rna[j]] + pr->transitions[TSR]);
	if (debug) printf("j = 0 %f\n", cursc);
      } else {
        cursc = DLogsum(mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL],
      			mx[dpS][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR]);
	if (debug) printf("j > 0 %f\n", cursc);
      }

      /* S -> SS in NUS */
      for (k = i; k < j; k++) {
	if (debug) printf("Adding a bifurcation with k = %d (%d, %d)\n", k, i, j);
        cursc = DLogsum(mx[dpS][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] 
	      + pr->transitions[TSB], cursc);
      }

      if ((lplen(i,j) >= HLEN) && (j > 0)) {	/* S -> aSa' */
	if (debug) printf("Adding a pair at (%d, %d)\n", i,j );
        cursc = DLogsum(mx[dpS][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
	      + pr->transitions[TSS], cursc);
      }

      /* S -> aSb | aS | Sb | SS | end */
      mx[dpS][j][d] = cursc;

    } /* End for loop */
  } /* End foreach n */
}

/********************* Suboptimals **************************/
/* Function: insideTraceNUS
 * Date:     Thu Oct  3 14:03:21 CDT 2002 [St Louis]
 *
 * Purpose:  Build a traceback tree for Inside  (sampled)
 * Assumption: Fill matrix already allocated, initialized, and filled
 *
 * Args:
 *	mx	matrix containing inside values 
 *	pr	parameters in integer form
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns: traceback tree
 */
struct trace_s *
insideTraceNUS(double ***mx, PROBMOD *pr, char *rna, int len)
{
  int d, i, j, k, mtx;   /* Indices */
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */
  double *ruleprob;
  double cursc, denom, randnum;
  int indx;

  ruleprob = (double *) malloc (sizeof(double) * (len + 4));

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (len -1), TSE));

  /* Repeat until stack is empty */
  while (curr = PopTracestack(stack)) {
     /* Generate a random number */
     randnum = asLog((float) rand() / RAND_MAX);

     /* Set i and j from items in stack */
     i = curr->emitl; j = curr->emitr; mtx = curr->nonterminal; d = j-i+1;

     /* S -> end */
     if (i > j) { 		/* S -> end */
	curr->emitl = -1; curr->emitr = -1;
	curr->transition = TSE; curr->nonterminal = dpE; 
	continue;
     } else { 
	/* Calculate the score for each possible move from this mtx[i][j] */
	/* S -> aSa' */
	if ((lplen(i,j) >= HLEN) && (j > 0) && (d > 1)) {
	   cursc = mx[dpS][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TSS];	
	} else {
	   cursc = -BIGFLOAT;
	}
	ruleprob[0] = cursc; denom = cursc;

	/* S -> aS */
	if (d > 0) {
	   cursc = mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL];	
	} else {
	   cursc = -BIGFLOAT;
	}
	ruleprob[1] = cursc; denom = DLogsum(denom, cursc);

	/* S -> aS */
	if ((j > 0) && (d > 0)) {
	   cursc = mx[dpS][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR];	
	} else {
	   cursc = -BIGFLOAT;
	}
	ruleprob[2] = cursc; denom = DLogsum(denom, cursc);

	/* S -> SS */
	indx = 3; cursc = -BIGFLOAT; 		
	for (k = i; k < j; k++) {
	   cursc = mx[dpS][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] + pr->transitions[TSB];
	   ruleprob[indx++] = cursc;
	   denom = DLogsum(denom, cursc);
	}

	/* Normalize the scores to probs */
	for (k = 0; k < indx; k++) {		
	   ruleprob[k] = ruleprob[k] - denom;
	   if (k > 0) {		/* Convert to intervals */
	      ruleprob[k] = DLogsum(ruleprob[k], ruleprob[k-1]);
	   }
	}

	/* Pick a rule based the interval of each rule */
	if (randnum < ruleprob[0]) {
	   curr->transition = TSS;
	   PushTracestack(stack, AttachTrace (curr, dpS, i+1, j-1, TSE));
	} else if (randnum < ruleprob[1]) {
	   curr->emitr = -1; curr->transition = TSL; 
	   PushTracestack(stack, AttachTrace (curr, dpS, i+1, j, TSE));
	} else  if (randnum < ruleprob[2]) {
	   curr->emitl = -1; curr->transition = TSR; 
	   PushTracestack(stack, AttachTrace (curr, dpS, i, j-1, TSE));
	} else {	
	   for (mtx = 3; mtx < indx; mtx++) {
	      k = i + (mtx - 3);			/* Coordinate of this bif */
	      if (randnum < ruleprob[mtx]) {
		 curr->emitl = -1; curr->emitr = -1; curr->transition = TSB;
		 PushTracestack(stack, AttachTrace (curr, dpS, k+1, j, TSE));
		 PushTracestack(stack, AttachTrace (curr, dpS, i, k, TSE));
		 mtx = indx;	/* Break loop */
	      }
	   } /* Find which k of bif state */
	} /* End else is bif state */
     } /* End i <= j */
  }
  FreeTracestack(stack);
  free(ruleprob);
  return parsetree;
}

/******************* conditional Inside ********************************/
/* Function: cinsInitNUS
 * Date:   Wed Jan 22 11:34:10 CST 2003 [St Louis]
 *
 * Purpose:  Initialize conditional Inside fill matrix for NUS 
 * Assumption: Fill matrix already allocated 
 *
 * Args:     
 *	mx	where to store inside (matrix to fill)
 *	model	integer log form of parameters
 *	rna	Sequence to be analyzed
 * 	len	sequence length
 * 	ss	ct structure on which to condition
 *
 * Notes:  To initialize the "lower" half of the matrix:
 *   \alpha_{nonterminal}(i+1, i) = 1 for nontermianls with \epsilon
 *   				  = 0 otherwise
 * To initalize the diagonal (i == j) we calculate the inside
 *  	variable (\alpha) for each nontermianl type assuming
 *  	the values above for all \alpha_{nontemrainl}(i,j) where
 *  	i > j.
 *
 * Returns:  -- void -- 
 */
void
cinsInitNUS(double ***mx, PROBMOD *model, char *rna, int len, int *ss)
{
   int d,j;

  for (d = 0; d <= len; d++) {
     for (j = d; j < len; j++) {
        mx[dpS][j][d] = model->transitions[TSE];
     } /* end for j */
     if (d > 0) mx[dpS][d-1][d] = model->transitions[TSE];	
  } 
}

/* Function: cinsFillNUS
 * Date:     Wed Jan 22 11:34:38 CST 2003 [St Louis]
 *
 * Purpose:  Fills inside matrix for NUS 
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	sc	parameters 
 *		(integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 * 	ss	ct structure on which to condition
 *
 * Returns:  void 
 */
void
cinsFillNUS(double ***mx, PROBMOD *pr, char *rna, int len, int *ss)
{
  int d, i, j, k;       /* Loop indicies */
  double cursc;		/* Current score */
  int debug;	

  debug = FALSE;

  /* Recursion */
  for (d = 1; d <= len; d++) {
    for (j = d-1; j < len; j++) {
       i = j - d + 1; 

	cursc = -BIGFLOAT;
	/* S -> aS */
	if (ss[i] == -1) {
	   cursc = mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL];
	}
	/* S -> Sa */
	if (ss[j] == -1) {
	   if (j > 0) {
	     cursc = DLogsum(cursc, mx[dpS][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR]);
	   } else {
	     cursc = DLogsum(cursc, mx[dpS][j][d-1] + pr->singles[rna[j]] + pr->transitions[TSR]);
	   }
	}

	/* S -> SS */
	for (k = i; k < j; k++) {
	   if (debug) 
	      printf("Adding a bifurcation with k = %d (%d, %d)\n", k, i, j);
	   cursc = DLogsum(mx[dpS][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] 
		 + pr->transitions[TSB], cursc);
	}

	/* S -> aSa' */
	if (lplen(i,j) >= HLEN) {	
	   if (ss[i] == j) {
	      if (debug) printf("Adding a pair at (%d, %d)\n", i,j );
	      cursc = DLogsum(mx[dpS][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
		    + pr->transitions[TSS], cursc);
	   }
	}

	/* S -> aSb | aS | Sb | SS | end */
	mx[dpS][j][d] = cursc;

     } /* End for loop */
  } /* End foreach n */
}

/************************* Outside ********************************/
/* Function: outsideInitNUS
 *
 * Purpose:  Initialize conditional Inside fill matrix for NUS 
 * Assumption: Fill matrix already allocated 
 *
 * Args:     
 *	mxo	where to store outside (matrix to fill)
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
outsideInitNUS(double ***mxo, int len)
{
   int d, j;

   for (d = 0; d <= len; d++) {
      for (j = d; j < len; j++) {
	 mxo[dpS][j][d] = -BIGFLOAT;
      } /* end for j */
      if (d > 0) mxo[dpS][d-1][d] = -BIGFLOAT;
   }
   mxo[dpS][len-1][len] = 0;
}
/* Function: outsideFillNUS
 * 
 * Purpose:  Fills outside matrix for NUS
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 * 	mxo	where to store outside (matrix to fill)
 *	mx	results from inside
 *	pr	integer log form of parameters
 *	rna	Sequence to be analyzed
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
outsideFillNUS(double ***mxo, double ***mx, PROBMOD *pr, char *rna, int len)
{
   int d, i, j, k;
   double cursc;
   int debug;

   debug = FALSE;

   for (d = (len-1); d > 0; d--) {
      for (j = (len-1); j > d-2; j--) {
	 i = j - d + 1; 

	 if (debug) printf("(j %d, d %d) \n", j, d);

	 if ((i == 0) && (j == len-1)) {
	    mxo[dpS][len-1][len] = 0.; 	/* Initialization */
	 } else {
	    cursc = -BIGFLOAT;

	    /* \beta^S(i,j) */
	    cursc = DLogsum(cursc, mxo[dpS][j][d+1] + pr->transitions[TSL] 
		  + pr->singles[rna[i-1]]);
	    if (debug) printf("TSL %f\n", cursc);
	    if (j < len-1) {
	      cursc = DLogsum(cursc, mxo[dpS][j+1][d+1] + pr->transitions[TSR] 
		  + pr->singles[rna[j+1]]);
	      if (debug) printf("TSR %f\n", cursc);
	    }
	    if ((i > 0) && (j < len-1)) {
	       if (lplen(i,j) >= HLEN) {
		  cursc = DLogsum(cursc, mxo[dpS][j+1][d+2] + pr->transitions[TSS] 
			+ pr->pairs[rna[i-1]][rna[j+1]]);
	          if (debug) printf("TSS %f\n", cursc);
	       }
	    }
	    for (k = 0; k < i; k++) {
	       cursc = DLogsum(cursc, mxo[dpS][j][dist(k,j)] + pr->transitions[TSB] 
		     + mx[dpS][i-1][dist(k,i-1)]);
	       if (debug) {
		  printf("TSB (left) %f\n", cursc);
		  printf("O[j %d][d %d] %f ; TSB %f; I[j %d][d %d] %f\n", j, dist(k,j),
		  	mxo[dpS][j][dist(k,j)] , pr->transitions[TSB] , i-1, 
			dist(k,i-1), mx[dpS][i-1][dist(k,i-1)]);
	       }
	    }
	    for (k = j+1; k < len; k++) {
	       cursc = DLogsum(cursc, mxo[dpS][k][dist(i,k)] + pr->transitions[TSB] 
		     + mx[dpS][k][dist(j+1,k)]);
	       if (debug) printf("TSB (right) %f\n", cursc);
	    }
	    mxo[dpS][j][d] = cursc;
	 }
      }
   }
}

/******************* conditional Outside ********************************/
/* Function: coutFillNUS
 * 
 * Purpose:  Fills outside matrix for NUS
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 * 	mxo	where to store outside (matrix to fill)
 *	mx	results from inside
 *	pr	integer log form of parameters
 *	rna	Sequence to be analyzed
 * 	len	sequence length
 * 	ss	ct structure on which to condition
 *
 * Returns:  void 
 */
void
coutFillNUS(double ***mxo, double ***mx, PROBMOD *pr, char *rna, int len, int *ss)
{
   int d, i, j, k;
   int cursc;

   for (d = (len-1); d > 0; d--) {
      for (j = (len-1); j > d-2; j--) {
	 i = j - d + 1; 

	 if ((i == 0) && (j == len-1)) {
	    mxo[dpS][len-1][len] = 0; 	/* Initialization */
	 } else {
	    cursc = -BIGFLOAT;
	    /* \beta^S(i,j) */
	    if (i > 0) {
	       if (ss[i-1] == -1) {
		  cursc = DLogsum(cursc, mxo[dpS][j][d+1] + pr->transitions[TSL] 
			+ pr->singles[rna[i-1]]);
	       }
	    }
	    if (j < len-1) {
	       if (ss[j+1] == -1) {
		  cursc = DLogsum(cursc, mxo[dpS][j+1][d+1] + pr->transitions[TSR] 
			+ pr->singles[rna[j+1]]);
	       }
	    }
	    if ((i > 0) && (j < len-1)) {
	       if ((ss[i-1] == j+1) && (lplen(i,j) >= HLEN)) {
		  cursc = DLogsum(cursc, mxo[dpS][j+1][d+2] + pr->transitions[TSS] 
			+ pr->pairs[rna[i-1]][rna[j+1]]);
	       }
	    }
	    for (k = 0; k < i; k++) {
	       cursc = DLogsum(cursc, mxo[dpS][j][dist(k,j)] + pr->transitions[TSB] 
		     + mx[dpS][i-1][dist(k,i-1)]);
	    }
	    for (k = j+1; k < len; k++) {
	       cursc = DLogsum(cursc, mxo[dpS][k][dist(i,k)] + pr->transitions[TSB] 
		     + mx[dpS][k][dist(j+1,k)]);
	    }
	    mxo[dpS][j][d] = cursc;
	 }
      }
   }
}

/************************* Posteriors ********************************/
/* Function: probXYpairNUS
 *
 * Purpose: Calculate the Probability that Xi pairs with Xj
 *  	using the NUS grammar
 * 
 * Args:
 *   	x		Smaller index	
 *   	y	 	Larger Index	
 *   	mx		Inside matrix -- filled
 *   	mxo		Outside Matrix -- filled
 *  	rna		Sequence under study
 *  	len		Length of said sequence
 *  	model 		Parameters for this model
 * 
 * Returns:
 *  	ret_sc		Prob(x pairs y) as Int log sum
 * 	1 on success; 0 on failure
 */
int
probXYpairNUS(int x, int y, double ***mx, double ***mxo, char *rna, int len, 
      PROBMOD *model, double *ret_sc)
{
   double temp, fval;
   double probseq;
   int debug;

   debug = FALSE; 
   probseq = mx[dpS][len-1][len];

   if (debug) printf("NUS Prob(x%d pairs x%d): ", x, y);

   if (lplen(x,y) >= HLEN) {
      temp = mxo[dpS][y][dist(x,y)] + mx[dpS][y-1][dist(x+1,y-1)] + model->pairs[rna[x]][rna[y]] 
	 + model->transitions[TSS];
   } else {
      temp = -BIGFLOAT;
   }

   /* Normalize by multiply by (1 / P(x| model))
    * Recall p1 / p2 in log space is log(p1) - log(p2)
    */
   fval = temp - probseq;

   if (debug) {
      /*
      printf(" %d %10.9f  ", temp, asFloatProb(temp));
      printf("Normalized: %d %10.9f\n",  fval, asFloatProb(fval));
      */
   }
   *ret_sc = fval;
   return 1;
}

/* Function probXunpairedNUS
 * Date: Wed Sep 25 12:06:02 CDT 2002 [Bethesda]
 *
 * Purpose: Calculate the probability that Xi is unpaired
 *   	using the UNA grammar
 * 
 * Args:
 *   	i		First index - position under scrutiny
 *   	mx		Inside matrix -- filled
 *   	mxo		Outside Matrix -- filled
 *  	rna		Sequence under study
 *  	len		Length of said sequence
 *  	model 		Parameters for this model
 * 
 * Returns:
 *  	ret_sc		Prob(x pairs y) as Int log sum
 *   	1 on success; 0 on failure
 */
int
probXunpairedNUS(int i, double ***mx, double ***mxo, char *rna, int len, PROBMOD *model, double *ret_sc)
{
   int j, debug;
   double right, left;
   double sum, fval, probseq;

   debug = FALSE;
   probseq = mx[dpS][len-1][len]; 

   right = -BIGFLOAT;
   for (j = 0; j < i; j++) {
      right = DLogsum(right, mxo[dpS][i][dist(j,i)] + mx[dpS][i-1][dist(j,i-1)] 
	    + model->singles[rna[i]] + model->transitions[TSR]);
   }
   /* Special case: S -> Sa -> a */
   right = DLogsum(right, mxo[dpS][i][1] + model->transitions[TSE]
	 + model->singles[rna[i]] + model->transitions[TSR]);

   left = -BIGFLOAT;
   for (j = i+1; j < len; j++) {
      left = DLogsum(left, mxo[dpS][j][dist(i,j)] + mx[dpS][j][dist(i+1,j)] 
	    + model->singles[rna[i]] + model->transitions[TSL]);
   }
   /* Special case: S -> aS -> a */
   left = DLogsum(left, mxo[dpS][i][1] + model->transitions[TSE]
	 + model->singles[rna[i]] + model->transitions[TSL]);

   sum = DLogsum(right, left);

   /* Normalize by multiply by (1 / P(x| model))
    * Recall p1 / p2 in log space is log(p1) - log(p2)
    */
   fval = sum - probseq;

   *ret_sc = fval;
   return 1;
}

/****************************** CML *******************************/
/* Function: calcNvalsNUS
 *
 * Purpose: calculate the sum of posteriors (n_{ij}) 
 * 	for the transition parameters
 *
 * Math: (See Krogh and Riis (1999), Neural Computation 11, 541-563))
 * For an HMM (easier notation):
 *   n_{ij}(t) = P(\pi_{t-1} = i, \pi_t = j | x, \theta)
 *   n_{ij} = \sum_t n_{ij}(t)
 * where i, j are states and t is a time point.
 *
 * For SCFGs: we'd say n_{vw}(i,j) 
 * where v and w are states and (i,j) is a positional time point.
 * 
 * Note: Also calculates m_ij if the mx and mxo matricies
 * 	were conditionally calculated.
 *
 * Args:
 * 	mx	Inside matrix (precalculated)
 * 	mxo	Outside matrix (precalculated)
 * 	rna	sequence
 * 	len	length of said sequence
 * 	model	parameters of current model
 * 	probseq P(x|model)
 *
 * Returns:
 * 	ret_nij	(Allocated elsewhere!)
 *   	1 on success; 0 on failure
 */
int
calcNvalsNUS(double ***mx, double ***mxo, char *rna, int len, PROBMOD *model, 
      double probseq, PROBMOD *ret_nij)
{
   int i, j, k, l, d;
   double *trans, *semis, *emis;	/* Temp arrays for calc N_ij */
   double temp, left, right;	/* Temp values */
   int debug = FALSE;

   trans = (double *) malloc (sizeof(double) *NTRANS);
   semis = (double *) malloc (sizeof(double) * ALPHA);
   emis = (double *) malloc (sizeof(double) * PAIRS);

   for (i = 0; i < NTRANS; i++) {
      trans[i] = -BIGFLOAT;
   }
   for (i = 0; i < PAIRS; i++) {
      if (i < ALPHA) semis[i] = -BIGFLOAT;
      emis[i] = -BIGFLOAT;
   }

   for (j = 0; j < len; j++) {
      for (d = 1; d <= j+1; d++) {
	 i = j - d + 1; 

	 /* Transitions: 
	 *   n_{vw}(i,j) = \frac{mxo[v][i][j] * mx[w][i][j] * emit[i-\delta][j-\delta] 
	 *   * \theta_{vw}}{P(x|\theta)}
	 */
	 left = mxo[dpS][j][dist(i,j)] + mx[dpS][j][dist(i+1,j)] + model->singles[rna[i]]
	    + model->transitions[TSL] - probseq;
	 trans[TSL] = DLogsum(trans[TSL], left);
	 if (d == 1) trans[TSE] = DLogsum(trans[TSE], left);

	 if (j > 0) {
	    right = mxo[dpS][j][dist(i,j)] + mx[dpS][j-1][dist(i,j-1)] + model->singles[rna[j]]
	       + model->transitions[TSR] - probseq;
	    trans[TSR] = DLogsum(trans[TSR], right);
	    if (d == 1) trans[TSE] = DLogsum(trans[TSE], right);

	    left = mxo[dpS][j][dist(i,j)] + mx[dpS][j-1][dist(i+1,j-1)] 
	       + model->pairs[rna[i]][rna[j]] + model->transitions[TSS] - probseq;
	    trans[TSS] = DLogsum(trans[TSS], left);
	    if (d == 1) trans[TSE] = DLogsum(trans[TSE], left);
	 } else {
	    right = mxo[dpS][j][dist(i,j)] + model->transitions[TSE] + model->singles[rna[j]]
	       + model->transitions[TSR] - probseq;
	    trans[TSR] = DLogsum(trans[TSR], right);
	    trans[TSE] = DLogsum(trans[TSE], left);
	 }

	 for (k = i; k < j; k++) {
	    left = mxo[dpS][j][dist(i,j)] + mx[dpS][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)]
	       + model->transitions[TSB] - probseq;
	    trans[TSB] = DLogsum(trans[TSB], left);
	 }
	 /* Handling TSE */

	 /* Emissions:
	  * n_i(l) = P(\pi_l = i | x, \theta) = 
	  * 	\frac{\alpha_i(l) \beta_j(l)}{P(x|theta)}
	  */
	 temp = mx[dpS][j][d] + mxo[dpS][j][d] - probseq;

	 /* Singles Emissions */
	 semis[rna[i]] = DLogsum(semis[rna[i]], temp); 
	 semis[rna[j]] = DLogsum(semis[rna[j]], temp);  

	 /* Pairs Emissions */
	 if (i != j) {
	    emis[idx(rna[i], rna[j])] = DLogsum(emis[idx(rna[i], rna[j])], temp);
	 }
      }
   }

   for (i = 0; i < NTRANS; i++) {
      ret_nij->transitions[i] = trans[i];
   }
   for (i = 0; i < ALPHA; i++) {
      ret_nij->singles[i] = semis[i];
      for (j = 0; j < ALPHA; j++) {
	 ret_nij->pairs[i][j] = emis[idx(i,j)];
      }
   }

   free(trans); free(semis); free(emis);
   return (TRUE);
}
