/* trace.c  -  support for traceback tree structure 
 *     (RNA structure representation)
 *
 * cove 1.0: Mon May 17 09:38:14 1993
 * moved to cove 2.0, Mon Sep  6 13:34:55 1993
 * modified for yarn, Sun Aug 28 10:01:42 1994
 * modified for conus, RDD, Tue Aug 21 14:35:19 CDT 2001
 * 
 * The traceback of an SCFG-sequence alignment is an RNA structure,
 * which is kept as a tree of trace_s structures. Here
 * we provide support for the traceback data structures: the
 * tree itself, and a pushdown stack used for traversing the
 * tree.
 * 
 * The trace tree structure has a dummy node at its beginning
 * and dpcE END states at the leaves. Unlike COVE, these ends are
 * created by the functions that create traces, not maintained
 * automatically. Non-BIFURC states have a NULL right branch. 
 * 
 * The pushdown stack structure has a dummy begin node, and the
 * end is signified by a final NULL ptr.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "cfg.h"		/* struct trace_s and struct tracestack_s */
#include "alphabet.h"
#include "trace.h"

/* Function: KHS2Trace()
 * 
 * Purpose:  Create a trace structure from a KH structure
 *            string. This is very similar to tracebacks
 *            of a dynamic programming matrix.
 *
 * This function calls the appropriate grammar specific version.
 * 
 * Args:     seq    - sequence, 0..len-1
 *            ss     - structure string. May contain pseudoknots,
 *                     but these will be ignored and treated as
 *                     single strands.
 *            len    - length of both seq and ss
 *            ret_tr - RETURN: traceback
 *            tolerate - do we call a grammatically illegal structure
 *            	an error (FALSE) or do we work around it (TRUE)
 *            grammar - describes which grammar to assume
 * 
 * Return:   1 on success, 0 on failure.
 *           Caller frees ret_tr with FreeTrace().
 */
int
KHS2Trace(char *seq, char *ss, int len, struct trace_s **ret_tr, int tolerate, int grammar)
{
  struct tracestack_s *dolist;
  struct trace_s      *cur;
  struct trace_s      *tr;
  int *ct;
  int validstruct;

  if (! KHS2ct(ss, len, FALSE, &ct))
    {Warn("Structure string is inconsistent"); return 0; }

  validstruct = TRUE;
  tr     = InitTrace();
  dolist = InitTracestack();
  cur = AttachTrace(tr, dpS, 0, len-1, TRE); /* attach the guy we'll work on first */
  PushTracestack(dolist, cur);

  if (!khs2trace(dolist, ct, len, grammar, tolerate)) validstruct = FALSE;

  FreeTracestack(dolist);
  free(ct);

  *ret_tr = tr;
  if (!validstruct) {
    return 0;
  } else {
    return 1;
  }
}

/* Function: InitTrace()
 * 
 * Purpose:  Initialize a traceback tree structure.
 *
 * Return:   ptr to the new tree.
 */          
struct trace_s *
InitTrace(void)
{
  struct trace_s *new;

  if ((new = (struct trace_s *) malloc (sizeof(struct trace_s))) == NULL)
    Die("Memory allocation failure at %s line %d", __FILE__, __LINE__);
  
  new->emitl = -1;
  new->emitr = -1;

  new->nonterminal = -1;
  new->transition = -1;

  new->nxtl  = NULL;
  new->nxtr  = NULL;
  new->prv   = NULL;
  return new;
}

/* Function: AttachTrace()
 * 
 * Purpose:  attach a new node to a tracetree node.
 *           There are no dummy END nodes, in contrast to COVE.
 *           
 *           Because of the mechanics of tracebacks through a Viterbi matrix,
 *           we have to make sure that BIFURC children are attached
 *           right first, left second.
 *           
 * Returns:  ptr to the new node, or NULL on failure.
 */          
struct trace_s *
AttachTrace(struct trace_s *parent,
	    int             nonterminal,
	    int             emitl,
	    int             emitr,
	    int             transition)
{
  struct trace_s *new;

  if (parent != NULL) {
     if (parent->nxtr != NULL)
	Die("That trace node is already full, fool.");

     /* If left branch is already connected to something, swap it over to the
      * right (thus enforcing the necessary rule that BIFURCS attach to the right
      * branch first), and attach a new dummy end to the left branch. 
      */
     if (parent->nxtl != NULL)
     {
	parent->nxtr = parent->nxtl;
	parent->nxtl = NULL;
     }
  }

  if ((new = (struct trace_s *) malloc (sizeof(struct trace_s))) == NULL)
    Die("Memory allocation failure at %s line %d", __FILE__, __LINE__);
  new->nxtr    = NULL;
  new->nxtl    = NULL;
  new->prv     = parent;
  new->emitl   = emitl;
  new->emitr   = emitr;
  new->nonterminal = nonterminal;
  new->transition = transition;
  if (parent != NULL) parent->nxtl = new;

  return new;
}

void
FreeTrace(struct trace_s *tr)
{
  struct tracestack_s *stack;
  struct trace_s      *currtr;

  stack = InitTracestack();
  PushTracestack(stack, tr);

  while ((currtr = PopTracestack(stack)) != NULL)
    {
      if (currtr->nxtr != NULL)
	PushTracestack(stack, currtr->nxtr);
      if (currtr->nxtl != NULL)
	PushTracestack(stack, currtr->nxtl);
      free(currtr);
    }
  FreeTracestack(stack);
}

/* Functions: InitTracestack()
 *            PushTracestack()
 *            PopTracestack()
 *            FreeTracestack()
 *            
 * Purpose:   Implementation of the pushdown stack for
 *            traversing traceback trees.
 */            
struct tracestack_s *
InitTracestack(void)
{
  struct tracestack_s *stack;

  if ((stack = (struct tracestack_s *) malloc (sizeof(struct tracestack_s))) == NULL)
    Die("Memory allocation failure at %s line %d", __FILE__, __LINE__);
  stack->nxt = NULL;
  return stack;
}

void 
PushTracestack(struct tracestack_s *stack,
	       struct trace_s      *tracenode)
{
  struct tracestack_s *new;

  if ((new = (struct tracestack_s *) malloc (sizeof(struct tracestack_s))) == NULL)
    Die("Memory allocation failure at %s line %d", __FILE__, __LINE__);
  new->node = tracenode;

  new->nxt = stack->nxt;
  stack->nxt = new;
}

struct trace_s *
PopTracestack(struct tracestack_s *stack)
{
  struct trace_s *node;
  struct tracestack_s *old;

  if (stack->nxt == NULL)
    return NULL;

  old = stack->nxt;
  stack->nxt = old->nxt;

  node = old->node;
  free(old);
  return node;
}
void
FreeTracestack(struct tracestack_s *stack)
{
  while (PopTracestack(stack) != NULL)
    ;
  free(stack);
}


/* Function: PrintTrace()
 * 
 * Purpose:  Debugging tool. Print a traceback tree.
 */
void
PrintTrace(FILE *fp, struct trace_s *tr, char *seq)
{
  struct tracestack_s *stack;
  struct trace_s      *currtr;
  char left; char right;

  if (tr == NULL) {
    printf("No traceback available!\n");
    return;
  }
  stack = InitTracestack();
  PushTracestack(stack, tr->nxtl);
  
  fprintf(fp, "(  address   ) dp  emitl emitr type    nxtl        nxtr      i  j\n");

  while ((currtr = PopTracestack(stack)) != NULL)
    {
      if (currtr->emitl != -1) left = seq[currtr->emitl]; else left = 'z';
      if (currtr->emitr != -1) right = seq[currtr->emitr]; else right = 'z';
   
      fprintf(fp, "(%#12x) %2d  %4d  %4d  %3d  %#10x  %#10x  %2c %2c \n", 
	     (int) currtr, currtr->nonterminal, currtr->emitl, currtr->emitr, 
             currtr->transition, (int) currtr->nxtl, (int) currtr->nxtr, left, right);
      if (currtr->nxtr != NULL)
	PushTracestack(stack, currtr->nxtr);
      if (currtr->nxtl != NULL)
	PushTracestack(stack, currtr->nxtl);
    }
  FreeTracestack(stack);
}


