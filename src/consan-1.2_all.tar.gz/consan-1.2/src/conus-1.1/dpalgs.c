/* dpalgs.c
 * RDD, Tue Aug 21 15:33:15 2001
 *
 * The main routines for doing the
 * major manipulations of DP for CYK, Inside, and 
 * Outside.
 *
 * Distribution functions (switches to grammar specific
 * versions of these functions in gr_dist.c:
 *
 * 	InitializeMx (CYK, Inside, Outside)
 * 	FillMx (CYK, Inside, Outside)
 * 	TraceMx (CYK only)
 *
 * Each grammar has grammar specific versions of these functions 
 * in the grammar's code file.  See grammar.h for listings.
 *
 * These implementations assume a digitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include "squid.h"
#include "cfg.h"
#include "trace.h"	/* struct trace_s */
#include "options.h"	/* OPTS */
#include "alphabet.h"	/* Digitize */
#include "grammars.h"

/* dpalgs.c */
struct trace_s * probCYK(char *rna, int len, int grammar, PROBMOD *prmodel, 
      OPTS *output);
struct trace_s * CYK(char *rna, int len, int grammar, INTMOD *scmodel, 
      OPTS *output, int *ret_score);
int Inside(char *rna, int len, int grammar, PROBMOD *scmodel, OPTS *output, 
      int *ss, double *ret_score, double ****mtx);
int Suboptimals(char *rna, int len, int grammar, MODEL *model, OPTS *output, 
      int nstructs, int saveinfo, int **scores, struct trace_s ***structures,
      SQINFO *sqinfo);
int Outside(char *rna, int len, int grammar, PROBMOD *scmodel, OPTS *output, 
      int *ss, double ***Imatx, double ****matx);


/*********************** CYK **********************************/

/* Function: probCYK
 * Date:     RDD, Wed Oct 17 09:35:57 2001 [St. Louis]
 *
 * Purpose:  Run CYK on probabilities by conversion to
 * 	integer values (scores) and using scoring routine.
 *
 * Args:    
 *     drna	rna sequence 
 *     len	length of sequence
 *     grammar	which grammar to utilize (see cfg.h)
 *     scmodel  scoring paramters 
 *     output   command line options (varies output)	
 *
 * Returns:  
 * 	pointer to head of resulting traceback tree
 */
struct trace_s *
probCYK (char *rna, int len, int grammar, PROBMOD *prmodel, OPTS *output)
{
  INTMOD icfg;
  int score;

  /* This should return score just as CYK does.  And we should
   * shift score back into prob space?
   */

  LogifySCFG(prmodel, &icfg); 
  return (CYK(rna, len, grammar, &icfg, output, &score));
}

/* Function: CYK 
 * Date:     RDD, Wed Oct 17 09:35:57 2001 [St. Louis]
 *
 * Purpose:  CYK algorithm outline for scoring grammars
 *
 * Args:    
 *     drna	rna sequence 
 *     len	length of sequence
 *     grammar	which grammar to utilize (see cfg.h)
 *     scmodel  scoring paramters 
 *     output   command line options (varies output)	
 *     ss	secondary structure in ctformat 
 *     		if given, calculates conditional CYK 
 *     		if NULL, calculates full CYK 
 *
 * Returns:  
 * 	*ret_score	Score of best parse
 * 	pointer to head best parse traceback tree 
 * 	NULL on failure
 */
struct trace_s *
CYK(char *rna, int len, int grammar, INTMOD *scmodel, OPTS *output, 
    int *ret_score )
{
  int ***matx;
  struct trace_s *tr;
  char *drna;
  int i;

  SetAlphabet(hmmNUCLEIC);
  tr = NULL;
  drna = DigitizeSequence(rna, len);

  preCalcSegs(scmodel, drna, len);

  allocFillMx(len, &matx, grammar);

  cykInitMx(matx, scmodel, drna, len, grammar);
  if (output->outmx) PrintFillMx(output->ofp, matx, rna, len, grammar);

  cykFillMx(matx, scmodel, drna, len, grammar); 
  if (output->outmx) PrintBigFilljdMx(output->ofp, matx, rna, len, grammar);

  *ret_score = matx[dpS][len-1][len];
  if (output->debugg) {
     fprintf(output->ofp, "Best Score is %d (Length %d)\n", matx[dpS][len-1][len], len);
  }

  tr = cykTraceMx(matx, scmodel, drna, len, grammar);

  freeFillMx(matx, grammar); 

  freePreCalcSegs(scmodel);
  free(drna);
  return (tr);
}

/*********************** INSIDE **********************************/

/* Function: Inside 
 * Date:     RDD, Wed Jul 17 14:57:09 CDT 2002 [St Louis]
 *
 * Purpose:  Inside algorithm outline for scoring grammars
 * 	(and can calculate conditional Inside)
 *
 * Args:    
 *     rna	rna sequence 
 *     len	length of sequence
 *     grammar	which grammar to utilize (see cfg.h)
 *     scmodel  scoring paramters 
 *     output   options from command line
 *     ss	secondary structure in ctformat 
 *     		if given, calculates conditional Inside
 *     		if NULL, calculates full Inside
 *
 * Returns:  
 *	*ret_score	P(data | model), undefined if error
 *	****Imatx	Inside matrix -- allocated here, must free elsewhere
 *	TRUE 	successful calculation of inside
 *	FALSE	detected an error
 */
int
Inside(char *rna, int len, int grammar, PROBMOD *scmodel, OPTS *output, int *ss,
      double *ret_score, double ****Imtx)
{
  double ***matx; 
  char *drna;
  int i, noerror;

  SetAlphabet(hmmNUCLEIC);
  drna = DigitizeSequence(rna, len);

  allocFillMxD(len, &matx, grammar);

  noerror = TRUE;

  if (ss == NULL) {	/* Calc full Inside */
    insideInitMx(matx, scmodel, drna, len, grammar);
    if (output->outmx) PrintFillMxD(output->ofp, matx, rna, len, grammar);
  } else {		/* Calc conditional Inside */
     condInsInitMx(matx, scmodel, drna, len, ss, grammar);
  }

  if (noerror) {
     if (ss == NULL) {	
	insideFillMx(matx, scmodel, drna, len, grammar);
     } else {		
	condInsFillMx(matx, scmodel, drna, len, ss, grammar);
     }
     if (output->outmx) PrintFillMxD(output->ofp, matx, rna, len, grammar);

     *ret_score = matx[dpS][len-1][len];
  } else {
     noerror = FALSE;
     printf("Oh Shit -- Inside\n");
  }
  *Imtx = matx;

  free(drna);

  if (noerror) return (TRUE);
  else return (FALSE);
}

/* Function: Suboptimals 
 * Date:     Thu Oct  3 15:47:32 CDT 2002 [St Louis]
 *
 * Purpose:  Calculate a set of suboptimals for a sequence
 *
 * Args:    
 *     rna	rna sequence 
 *     len	length of sequence
 *     grammar	which grammar to utilize (see cfg.h)
 *     scmodel  scoring paramters 
 *     output   options from command line
 *     nstructs	number of suboptimals to sample
 *     saveinfo	if TRUE then will return scores and tracebacks
 *     		for each suboptimal (in *scores and **structures,
 *     		respectively).
 *     		if FALSE will output suboptimals
 *     	sqinfo  Sequence information for output (if saveinfo is FALSE)
 *
 * Returns:  
 * 	*scores		Array of scores for each of suboptimals
 * 	**structures	Traceback tree for each suboptimal
 * 		(The scores and structures arrays are in sync such that
 * 		scores[i] is the score of structures[i]).
 *	TRUE 	successful calculation of suboptimals 
 *	FALSE	detected an error
 */
int
Suboptimals(char *rna, int len, int grammar, MODEL *model, OPTS *output, 
      int nstructs, int saveinfo, int **scores, struct trace_s ***structures, 
      SQINFO *sqinfo)
{
   int i;
   double insidescore;
   int insc;
   double ***insmatx;
   struct trace_s *trc;
   char *drna;
   char *ss;
   int *sc;
   struct trace_s **trcset;
   PROBMOD dlogs;

   SetAlphabet(hmmNUCLEIC);
   drna = DigitizeSequence(rna, len);
   trc = NULL;

   DLogifySCFG(&(model->probs), &dlogs);

   srand(time(NULL)); 

   if (saveinfo) {
      /* Allocate scores and structures matrices */
      sc = (int *) malloc (sizeof(int) * nstructs);
      trcset = (struct trace_s **) malloc (sizeof(struct trace_s *) * nstructs);
   }

   if (Inside(rna, len, grammar, &dlogs, output, NULL, &insidescore, &insmatx)) {
      for (i = 0; i < nstructs; i++) {
	 trc = insideTraceMx(insmatx, &dlogs, drna, len, grammar);
	 if (output->traceback) PrintTrace(output->ofp, trc, rna);

	 if (saveinfo) {
	    trcset[i] = trc;
	    traceScore(rna, len, trc, &(model->scores), grammar, &(sc[i]));
	 } else {
	    traceScore(rna, len, trc, &(model->scores), grammar, &insc);
	 }
	 trace2khs(trc, rna, len, 1, &ss);
	 if (output->structout) {
	    if (saveinfo) {
	       printf("SCORE: %d\n", sc[i]);
	    } else {
	       printf("SCORE: %d\n", insc);
	    }
	    PrintKHS(output->ofp, rna, sqinfo, ss);
	 }
	 if (output->stockout) {
	    if (saveinfo) {
	       printf("SCORE: %d\n", sc[i]);
	    } else {
	       printf("SCORE: %d\n", insc);
	    }
	    PrintStockholm(output->ofp, rna, sqinfo, ss);
	 }
      }
      if (saveinfo) {
	 *scores = sc;
	 *structures = trcset;
      }
   } else {
      return FALSE;
   }
   /* To do suboptimals we've got to be in reduced space */
   freeFillMxD(insmatx, grammar);
   free(drna);
   return TRUE;
}

/*********************** OUTSIDE **********************************/

/* Function: Outside 
 * Date:     RDD, Wed Aug 21 13:42:13 CDT 2002 [St Louis]
 *
 * Purpose:  Outside algorithm outline for scoring grammars
 *
 * Args:    
 *     rna	rna sequence 
 *     len	length of sequence
 *     grammar	which grammar to utilize (see cfg.h)
 *     scmodel  scoring paramters 
 *     output   options from command line	
 *     Imatx	Inside matrix (if available, if is NULL will calc Inside)
 *
 * Returns:  
 *      ****Omatx	Filled outside matrix
 *	TRUE 	successful calculation of outside 
 *	FALSE	detected an error
 */
int
Outside(char *rna, int len, int grammar, PROBMOD *scmodel, OPTS *output, 
      int *ss, double ***Imatx, double ****Omatx)
{
  double ***matx;
  double ***matins;
  char *drna;
  int i, noerror, allochere;

  SetAlphabet(hmmNUCLEIC);
  drna = DigitizeSequence(rna, len);

  noerror = TRUE;
  if (Imatx == NULL) {
     printf("Calculating Inside\n");
     allochere = TRUE;

     allocFillMxD(len, &matins, grammar);

     insideInitMx(matins, scmodel, drna, len, grammar);
     insideFillMx(matins, scmodel, drna, len, grammar);
     if (output->outmx) {
	printf("INSIDE: \n");
	PrintFillMxD(output->ofp, matins, rna, len, grammar); 
     }
  } else {
     matins = Imatx;
     allochere = FALSE;
  }

  allocFillMxD(len, &matx, grammar);

  outsideInitMx(matx, len, grammar);
  if (ss == NULL) {
     outsideFillMx(matx, matins, scmodel, drna, len, grammar);
  } else {
     coutFillMx(matx, matins, scmodel, drna, len, ss, grammar);
  }
  if ((output->outmx) && (noerror)) {
     printf("OUTSIDE: \n");
     PrintFillMxD(output->ofp, matx, rna, len, grammar);
     fflush(stdout);
  }

  *Omatx = matx;

  if (allochere) {
     freeFillMxD(matins, grammar);
  }

  free(drna);

  if (noerror) return (TRUE);
  else return (FALSE);
}
