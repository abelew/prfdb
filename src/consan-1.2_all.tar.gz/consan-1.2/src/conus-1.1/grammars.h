#ifndef GRAM_H_INCLUDED
#define GRAM_H_INCLUDED

/* Grammar specific functions and the distributors to them.
 * gr_dist.c contains distributor fuctions which call the
 * grammar specific versions of routines. 
 *
 * Grammar specific routines are contained in grammar files
 * designated by their three letter codes (see cfg.h).  
 * [Example: Nussinov grammar is in gr_nus.c]
 *
 * For the DP algorithms
 * Name of each grammar specific function follows a standard
 * nomeclature:
 *     - lead with lowercase shorthand for dpalgorithm
 *       (cyk, ins, out, cins, cout )
 *     - upper case intention of the routine
 *     	 (Init, Fill, Trace)
 *     - finish with three letter (all uppercase) grammar code
 *       (see cfg.h for grammar codes; Ex: NUS)
 *
 * For the other grammar specific functions, append grammar three 
 * letter code to function name:
 *     - probXYpair and probXunpaired for posterior check
 *     - khs2trace, analyzeTrace, and probify for training
 */
 
/************************* Grammar Distribution Functions *****************************/
/* gr_dist.c :: Distribution functions for picking grammar specific routines */
	/* CYK algorithm: best parse */
extern int cykInitMx(int ***mx, INTMOD *model, char *rna, int len, int grammar);
extern int cykFillMx (int ***mx, INTMOD *pr, char *rna, int len, int grammar);
extern struct trace_s *cykTraceMx(int ***mx, INTMOD *pr, char *rna, int len, int grammar);
	/* Training */
extern int traceCount(char *seq, int len, int wgt, struct trace_s *tr, INTMOD *cfg, 
      int grammar);
extern int traceScore(char *seq, int len, struct trace_s *tr, INTMOD *cfg,
             int grammar, int *ret_score);
extern int khs2trace (struct tracestack_s *dolist, int *ct, int len, 
      int grammar, int tolerate);
extern int generate_RNA(PROBMOD *pr, char **rna, char **ss, int grammar);

	/* Inside algorithm: P(seq | model) or P(structure, seq | model) */
extern int insideInitMx(double ***mx, PROBMOD *model, char *rna, int len, int grammar);
extern int insideFillMx(double ***mx, PROBMOD *pr, char *rna, int len, int grammar);
extern int condInsInitMx(double ***mx, PROBMOD *model, char *rna, int len, int *ss, int grammar);
extern int condInsFillMx(double ***mx, PROBMOD *pr, char *rna, int len, int *ss, int grammar); 
extern struct trace_s * insideTraceMx(double ***mx, PROBMOD *pr, char *rna, int len, int grammar);

	/* Outside algorithm: Necessary for posteriors */
extern int outsideInitMx(double ***mxo, int len, int grammar);
extern void outsideInitMxDef(int ***mxo, int len);
extern int outsideFillMx(double ***mxo, double ***mx, PROBMOD *pr, char *rna, int len, int grammar);
extern int coutFillMx(double ***mxo, double ***mx, PROBMOD *pr, char *rna, int len, 
            int *ss,  int grammar);

	/* Posteriors -- status of position X */
extern int probXunpaired(int i, double ***mx, double ***mxo, char *rna, int len, 
            PROBMOD *model, int grammar, double *ret_sc);
extern int probXYpair(int x, int y, double ***mx, double ***mxo, char *rna, int len, 
            		PROBMOD *model, int grammar, double *ret_sc);
extern int calcNvals(double ***mx, double ***mxo, char *rna, int len, PROBMOD *model, int grammar, 
            double probseq, PROBMOD *ret_nij);

/************************* Grammar Specific Routines *******************************/
/* gr_nus.c */
extern void cykInitNUS(int ***mx, INTMOD *model, char *rna, int len);
extern void cykFillNUS (int ***mx, INTMOD *pr, char *rna, int len);
extern struct trace_s * cykTraceNUS (int ***mx, INTMOD *pr, char *rna, int len);
extern int khs2traceNUS(struct tracestack_s *dolist, int *ct);
extern void probifyNUS (INTMOD *icfg, PROBMOD *ret_cfg, INTMOD *prior);

extern int analyzeTraceN(char *seq, int len, struct trace_s *tr, INTMOD *cfg, int count);
extern void dTraceScoreN(char *seq, int len, struct trace_s *tr, PROBMOD *cfg, double *ret_val);

extern void insideInitNUS(double ***mx, PROBMOD *model, char *rna, int len);
extern void insideFillNUS(double ***mx, PROBMOD *pr, char *rna, int len);
extern void cinsInitNUS(double ***mx, PROBMOD *model, char *rna, int len, int *ss);
extern void cinsFillNUS(double ***mx, PROBMOD *pr, char *rna, int len, int *ss);

extern struct trace_s * insideTraceNUS(double ***mx, PROBMOD *pr, char *rna, int len);

extern void outsideInitNUS(double ***mxo, int len);
extern void outsideFillNUS(double ***mxo, double ***mx, PROBMOD *pr, char *rna, int len);
extern void coutFillNUS(double ***mxo, double ***mx, PROBMOD *pr, char *rna, int len, int *ss);

extern int probXYpairNUS(int x, int y, double ***mx, double ***mxo, char *rna, int len, 
            PROBMOD *model, double *ret_sc);
extern int probXunpairedNUS(int i, double ***mx, double ***mxo, char *rna, int len, 
      	PROBMOD *model, double *ret_sc);

extern int calcNvalsNUS(double ***mx, double ***mxo, char *rna, int len, PROBMOD *model, 
            double probseq, PROBMOD *ret_nij);
extern int calcGradientNUS(PROBMOD *model, PROBMOD *nij, PROBMOD *mij, PROBMOD *ret_gradient);
extern int updateParamsNUS(double eta, PROBMOD *model, PROBMOD *gradient, PROBMOD *newp);

/* gr_una.c */
extern void cykInitUNA(int ***mx, INTMOD *model, char *rna, int len);
extern void cykFillUNA(int ***mx, INTMOD *pr, char *rna, int len);
extern struct trace_s * cykTraceUNA(int ***mx, INTMOD *pr, char *rna, int len);
extern int khs2traceUNA(struct tracestack_s *dolist, int *ct);

extern void insideInitUNA(double ***mx, PROBMOD *model, char *rna, int len);
extern void insideFillUNA(double ***mx, PROBMOD *pr, char *rna, int len);
extern void cinsInitUNA(double ***mx, PROBMOD *model, char *rna, int len, 
      int *ss);
extern void cinsFillUNA(double ***mx, PROBMOD *pr, char *rna, int len, 
      int *ss);
extern struct trace_s * insideTraceUNA(double ***mx, PROBMOD *pr, char *rna, int len);

extern void outsideInitUNA(double ***mxo, int len);
extern void outsideFillUNA(double ***mxo, double ***mx, PROBMOD *pr, 
      char *rna, int len);
extern void coutFillUNA(double ***mxo, double ***mx, PROBMOD *pr, char *rna, 
      int len, int *ss); 

extern int probXYpairUNA(int x, int y, double ***mx, double ***mxo, char *rna, 
      int len, PROBMOD *model, double *ret_sc);
extern int probXunpairedUNA(int x, double ***mx, double ***mxo, char *rna, 
      int len, PROBMOD *model, double *ret_sc);
extern int calcNvalsUNA(double ***mx, double ***mxo, char *rna, int len, 
      PROBMOD *model, double probseq, PROBMOD *ret_nij);

/* gr_yrn.c */
extern void cykInitYRN(int ***mx, INTMOD *model, char *rna, int len);
extern void cykFillYRN (int ***mx, INTMOD *pr, char *rna, int len);
extern struct trace_s * cykTraceYRN (int ***mx, INTMOD *pr, char *rna, int len);
extern int khs2traceYRN(struct tracestack_s *dolist, int *ct);
extern void probifyYRN (INTMOD *icfg, PROBMOD *ret_cfg, INTMOD *prior);

extern void insideInitYRN(double ***mx, PROBMOD *model, char *rna, int len);
extern void insideFillYRN(double ***mx, PROBMOD *pr, char *rna, int len);
extern void cinsInitYRN(double ***mx, PROBMOD *model, char *rna, int len, int *ss);
extern void cinsFillYRN(double ***mx, PROBMOD *pr, char *rna, int len, int *ss);
extern struct trace_s * insideTraceYRN(double ***mx, PROBMOD *pr, char *rna, int len);

extern void outsideInitYRN(double ***mxo, int len);
extern void outsideFillYRN(double ***mxo, double ***mx, PROBMOD *pr, char *rna, int len);
extern void coutFillYRN(double ***mxo, double ***mx, PROBMOD *pr, char *rna, int len, int *ss);

extern int probXYpairYRN(int x, int y, double ***mx, double ***mxo, char *rna, int len,
            PROBMOD *model, double *ret_sc);
extern int probXunpairedYRN(int i, double ***mx, double ***mxo, char *rna, int len,
            PROBMOD *model, double *ret_sc);

/************************* CYK and cond Inside only ****************************/
/* gr_ivo.c */
extern void cykInitIVO(int ***mx, INTMOD *model, char *rna, int len);
extern void cykFillIVO (int ***mx, INTMOD *pr, char *rna, int len);
extern struct trace_s * cykTraceIVO (int ***mx, INTMOD *pr, char *rna, int len);
extern int khs2traceIVO(struct tracestack_s *dolist, int *ct);
extern void cinsInitIVO(double ***mx, PROBMOD *model, char *rna, int len);
extern void cinsFillIVO(double ***mx, PROBMOD *pr, char *rna, int len, int *ss);
extern int analyzeTraceIVO(char *seq, int len, struct trace_s *tr, INTMOD *cfg, 
      int count);
extern void dTraceScoreIVO(char *seq, int len, struct trace_s *tr, PROBMOD *cfg, 
      double *ret_val);

/* gr_bjk.c */
extern void cykInitBJK(int ***mx, INTMOD *model, char *rna, int len);
extern void cykFillBJK(int ***mx, INTMOD *pr, char *rna, int len, int grammar);
extern struct trace_s * cykTraceBJK(int ***mx, INTMOD *pr, char *rna, int len, 
      int grammar);

extern int analyzeTraceBJK(char *seq, int len, struct trace_s *tr, INTMOD *cfg, 
      	int grammar, int count);
extern void dTraceScoreBJK(char *seq, int len, struct trace_s *tr, PROBMOD *cfg, 
      int grammar, double *ret_val); 

extern int khs2traceBJK(struct tracestack_s *dolist, int *ct);
extern void cinsInitBJK(double ***mx, PROBMOD *model, char *rna, int len);
extern void cinsFillBJK (double ***mx, PROBMOD *pr, char *rna, int len, int grammar, int *ss);
extern int generateBJK(PROBMOD *pr, char **ret_rna, char **ret_ss);

/* gr_run.c */
extern void cykInitRUN(int ***mx, INTMOD *model, char *rna, int len);
extern void cykFillRUN(int ***mx, INTMOD *pr, char *rna, int len);
extern struct trace_s * cykTraceRUN(int ***mx, INTMOD *pr, char *rna, int len);
extern int khs2traceRUN(struct tracestack_s *dolist, int *ct);
extern int analyzeTraceR(char *seq, int len, struct trace_s *tr, INTMOD *cfg, int count);
extern void dTraceScoreR (char *seq, int len, struct trace_s *tr, PROBMOD *cfg, 
      double *ret_val);
extern void cinsInitRUN(double ***mx, PROBMOD *model, char *rna, int len);
extern void cinsFillRUN (double ***mx, PROBMOD *pr, char *rna, int len, int *ss);

/* gr_ryn.c */
extern void cykInitR(int ***mx, INTMOD *model, char *rna, int len, int grammar);
extern void cykFillR(int ***mx, INTMOD *pr, char *rna, int len, int grammar);
extern struct trace_s * cykTraceR(int ***mx, INTMOD *pr, char *rna, int len, int grammar);
extern int khs2traceRYN(struct tracestack_s *dolist, int *ct);
extern int khs2traceRY2(struct tracestack_s *dolist, int *ct);
extern int khs2traceRY3(struct tracestack_s *dolist, int *ct, int tolerate);
extern int analyzeTraceR2(char *seq, int len, struct trace_s *tr, INTMOD *cfg, int grammar, int count);
extern void dTraceScoreR2(char *seq, int len, struct trace_s *tr, PROBMOD *cfg, 
      int grammar, double *ret_val);
extern void cinsInitR(double ***mx, PROBMOD *model, char *rna, int len, int grammar);
extern void cinsFillR(double ***mx, PROBMOD *pr, char *rna, int len, int grammar, int *ss);

/* gr_uyn.c */
extern void cykInitUYN(int ***mx, INTMOD *model, char *rna, int len);
extern void cykFillUYN (int ***mx, INTMOD *pr, char *rna, int len);
extern struct trace_s * cykTraceUYN (int ***mx, INTMOD *pr, char *rna, int len);
extern int khs2traceUYN(struct tracestack_s *dolist, int *ct, int tolerate);
extern void cinsInitUYN(double ***mx, PROBMOD *model, char *rna, int len);
extern void cinsFillUYN(double ***mx, PROBMOD *pr, char *rna, int len, int *ss);

/* gr_bry.c :: AMBIGUOUS */
extern void cykInitB(int ***mx, INTMOD *model, char *rna, int len);
extern void cykFillB(int ***mx, INTMOD *pr, char *rna, int len, int grammar);
extern struct trace_s * cykTraceB(int ***mx, INTMOD *pr, char *rna, int len, int grammar);
extern int khs2traceBRY(struct tracestack_s *dolist, int *ct, int grammar);
extern int analyzeTraceB(char *seq, int len, struct trace_s *tr, INTMOD *cfg, int count);
extern void dTraceScoreB(char *seq, int len, struct trace_s *tr, PROBMOD *cfg, 
      double *ret_val);
extern void cinsInitBRY(double ***mx, PROBMOD *model, char *rna, int len);
extern void cinsFillBRY(double ***mx, PROBMOD *pr, char *rna, int len, int *ss);

/* gr_ayn.c */
extern void cykInitA(int ***mx, INTMOD *model, char *rna, int len);
extern void cykFillA (int ***mx, INTMOD *pr, char *rna, int len, int grammar);
extern struct trace_s * cykTraceA(int ***mx, INTMOD *pr, char *rna, int len, int grammar);
extern int khs2traceAYN(struct tracestack_s *dolist, int *ct, int grammar);
extern int analyzeTraceA(char *seq, int len, struct trace_s *tr, INTMOD *cfg, int count);
extern void dTraceScoreA(char *seq, int len, struct trace_s *tr, PROBMOD *cfg, 
      double *ret_val);
extern void tieParams (INTMOD *counts);
extern void cinsInitA(double ***mx, PROBMOD *model, char *rna, int len, int grammar);
extern void cinsFillA(double ***mx, PROBMOD *pr, char *rna, int len, int grammar, int *ss);

/************************* CYK implementations only ****************************/
/* gr_rzk.c */
extern void cykInitRZK(int ***mx, INTMOD *model, char *rna, int len);
extern void cykFillRZK(int ***mx, INTMOD *pr, char *rna, int len);
extern struct trace_s * cykTraceRZK(int ***mx, INTMOD *pr, char *rna, int len);

extern int khs2traceRZK(struct tracestack_s *dolist, int *ct);
extern int analyzeTraceRZK(char *seq, int len, struct trace_s *tr, INTMOD *cfg, int count);
extern void trace2khsRZK(struct trace_s *tr, char *seq, int rlen, char **ret_ss);

/* gr_uzk.c */
extern void cykInitUZK(int ***mx, INTMOD *model, char *rna, int len);
extern void cykFillUZK(int ***mx, INTMOD *pr, char *rna, int len);
extern struct trace_s * cykTraceUZK(int ***mx, INTMOD *pr, char *rna, int len);

extern int khs2traceUZK(struct tracestack_s *dolist, int *ct);
extern int analyzeTraceUZK(char *seq, int len, struct trace_s *tr, INTMOD *cfg, int count);
extern void trace2khsUZK(struct trace_s *tr, char *seq, int rlen, char **ret_ss);

/****************** Hanging Around ************************/

/* gr_uzkD.c :: note that this is actually the stuff that goes with 
 * what I'm now calling the RZK grammar and hasn't yet been set to 
 * work in reduced space.
 */
extern void insideInitUZK(int ***mx, INTMOD *model, char *rna, int len);
extern void insideFillUZK(int ***mx, INTMOD *pr, char *rna, int len);
extern struct trace_s * insideTraceUZK(int ***mx, INTMOD *pr, char *rna, int len);

extern void outsideInitUZK(int ***mxo, char *rna, int len);
extern void outsideFillUZK(int ***mxo, int ***mx, INTMOD *pr, char *rna, int len);
extern int probXYpairUZK (int i, int j, int ***mx, int ***mxo, char *rna, int len, 
            INTMOD *model, int *ret_sc);
extern int probXunpairedUZK(int i, int ***mx, int ***mxo, char *rna, int len,
            INTMOD *model, int *ret_sc);

#endif /* GRAM_H_INCLUDED */
