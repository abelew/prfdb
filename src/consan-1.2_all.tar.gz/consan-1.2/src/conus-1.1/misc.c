/* misc.c 
 *
 * Assorted utility functions 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "squid.h"
#include "alphabet.h"	/* Digitize */
#include "cfg.h"

int isRNAComplement(char sym1, char sym2, int allow_gu);
int find_split(int *ct, int i, int j);
void mismatch_label(int *ct, int len);
void Print_CT(FILE *ofp, char *seq, int len, int *ss, char *name);
void PrintStockholm(FILE *fp, char *rseq, SQINFO *sqinfo, char *ss);
int ContainsAmbiguous (char *rna, int len);
int CheckforLonePairs(int *ct, int len);

/* Function: IsRNAComplement()
 * 
 * Purpose:  Returns TRUE if sym1, sym2 are Watson-Crick complementary.
 *           If allow_gu is TRUE, GU pairs also return TRUE.
 */
int
isRNAComplement(char sym1, char sym2, int allow_gu)
{
  sym1 = toupper(sym1);
  sym2 = toupper(sym2);

  if ((sym1 == 'A' && sym2 == 'U') ||
      (sym1 == 'C' && sym2 == 'G') ||
      (sym1 == 'G' && sym2 == 'C') ||
      (sym1 == 'U' && sym2 == 'A') ||
      (allow_gu && sym1 == 'G' && sym2 == 'U') ||
      (allow_gu && sym1 == 'U' && sym2 == 'G'))
    return 1;
  else
    return 0;
}

/* Function: find_split
 *
 * Purpose: determine if any pairing between a
 * 		given set of coordinates.
 *
 * Args:
 *     ct 	sequence in ct format
 *     i	starting location
 *     j 	ending location
 *
 * Returns:
 * 	-1	no pairs exist between i and j
 * 	num	endpoint of left most stem
 */
int
find_split (int *ct, int i, int j)
{
  int k;
 
  for (k = i; k <= j; k++) {
    if (ct[k] >= 0) {
      /* printf("FOUND at %d, %d\n", k, ct[k]); */
      return ct[k];
    }
  }
  return -1;
}

/* Function: mismatch_label
 *
 * Purpose: convert single pair internal loops 
 *		to mismatches 
 *
 * Args:
 *	ct	structure represented in ct format
 *	len	sequence length
 * 
 * Returns: nothing
 */
void
mismatch_label(int *ct, int len)
{
  int i, j;

  for (i = 0; i < (len-2); i++) {
    j = ct[i]; 
	/* i participates in a downstream pairing interaction */
    if ((j >= 0) && (j > i)) {	
	/* between adjacent basepairs is a single paired internal loop */
      if ((ct[i+2] == j-2) && (ct[i+1] == -1) && (ct[j-1] == -1)) {
	/* Relabel internal loop as paired (effectively, a mismatch) */
	ct[i+1] = j-1;
	ct[j-1] = i+1;
      }
    }
  }
}

/* Function: PrintStockholm()
 * 
 * Purpose:  Print a sequence/structure representation.
 * 
 * Args:     fp     - open file pointer to write to
 *           rseq   - sequence, 0..len-1
 *           sqinfo - info about rseq, including name and length
 *           ss     - secondary structure of rseq to show.
 *                    May or may not be the same as the ss in sqinfo.
 *                    
 * Return:  void.                   
 */
void   
PrintStockholm(FILE *fp, char *rseq, SQINFO *sqinfo, char *ss)
{
  char seqbuf[51];
  char strucbuf[51];
  int  nchar;
  int  pos;

  fprintf(fp, "# STOCKHOLM 1.0\n#=GS %s DE %s\n\n",
	  sqinfo->name,
	  (sqinfo->flags & SQINFO_DESC) ? sqinfo->desc : "TEST");

  for (pos = 0; pos < sqinfo->len; pos += 50) {
    strncpy(seqbuf,   rseq + pos, 50); seqbuf[50] = '\0';
    strncpy(strucbuf, ss + pos,   50); strucbuf[50] = '\0';
    nchar = strlen(seqbuf);
      
    fprintf(fp, "%-20s\t%s\n", sqinfo->name, seqbuf);
    fprintf(fp, "#=GR %-12s SS\t%s\n", sqinfo->name, strucbuf);
    fputs("\n", fp);
  }
  fputs("//\n\n", fp);
}

/* Function: Print_CT()
 * 
 * Purpose:  Converts the output of program to the "connect" format.
 *           It allows to convert any fragment of the sequence.
 *           
 * Args:     ofp	      - where to send the output
 *           seq      - sequence to fold. 
 *           len      - seq length
 *           ss       - secondary structure in CT form.
 *                      ss[i] = j  if position i paired to position j
 *                      ss[i] = -1 if position i is unpaired
 *         
 * Return:   (void)
 */
void
Print_CT(FILE *ofp, char *seq, int len, int *ss, char *name)
{
  int i;          /* initial position of fragment. 0,..,d-1 */

  /*
  fprintf(ofp,"\n ct_output \n");
  fprintf(ofp,"----------------------------------------------------------------------\n");
  */

  fprintf(ofp, "%5d \t %s\n", len, name);
  for (i = 0; i < len; i++) {
    fprintf(ofp, "%5d %c   %5d %4d %4d %4d\n",
            i+1, seq[i], i, i+2, (ss[i] != -1)? ss[i]+1: -1, i);
  }
  /* fprintf(ofp, "\n"); */
}

/* Function: AddLoopCounts
 *  RDD, Wed Feb 20 14:48:19 CST 2002 [St Louis]
 * 
 * Purpose: Count background frequency within loops
 * 
 * Args:     
 *        rna     digitized sequence being analyzed
 *        counts  array in which to put counts (does not zero!)
 *        i       beginning position of loop 
 *        j       ending position of loop
 * 
 * Returns: nothing
 */
void
AddLoopCounts(char *rna, int *counts, int i, int j) 
{
   int nt;

   for (nt = i; nt <= j; nt++) {
      if (rna[nt] == ntA) counts[ntA] += 1;
      else if (rna[nt] == ntC) counts[ntC] += 1;
      else if (rna[nt] == ntG) counts[ntG] += 1;
      else if (rna[nt] == ntU) counts[ntU] += 1;
   }
}

/* Function: ContainsAmbiguous
 * Date:     RDD, Thu Nov 15 17:51:27 2001 [St. Louis]
 *
 * Purpose:  Test for non {ACGTU} bases
 *
 * Args:     
 * 	rna	Sequence to test
 * 	len	Length of sequence
 *
 * Returns:  
 * 	TRUE 	if contains an unknown base
 * 	FALSE 	otherwise
 */
int
ContainsAmbiguous (char *rna, int len)
{
  int i;
  char *drna;

  drna = DigitizeSequence(rna, len);

  for (i = 0; i < len; i++) {
    if (drna[i] > ALPHA) {
      free(drna);
      return TRUE;
    }
  }
  free(drna);
  return FALSE;
}

/* Function: CheckforLonePairs 
 * RDD, Tue Mar 23 19:23:03 CST 2004 [St Louis]
 * 
 * Purpose: Check for lone pairs.  We define a 
 * lone pair as the condition when:
 *  x-1		unpaired
 *  x		pairs y
 *  x+1		unpaired
 *
 *  y-1		unpaired
 *  y		pairs x
 *  y+1		unpaired
 * 
 * Args:     
 * 	ct	- structure in CT format
 * 	len	- length of sequence/structure
 * 
 * Returns: true if seq contains lone pairs
 * 	false otherwise
 */
int
CheckforLonePairs(int *ct, int len)
{
   int i;

   for (i = 0; i < len; i++) {
      if (ct[i] != -1) {	/* This X pairs */
	 /* Boundary conditions -- pairs at boundaries can't be lone 
	  * by definition?
	  */
	 if ((i > 0) && (i < len-1) && (ct[i] > 0) && (ct[i] < len-1)) {
	    /* The test for lone pairs */
	    if ((ct[i-1] == -1) && (ct[i+1] == -1) &&			
		  (ct[ct[i]-1] == -1) && (ct[ct[i]+1] == -1)) {
	       return 1;
	    }
	 }
      }
   }
   return 0;
}
