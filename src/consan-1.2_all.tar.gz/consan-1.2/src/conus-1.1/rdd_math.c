/* rdd_math.c
 * RDD, Fri Aug 24 12:51:19 2001
 * 
 * Math support routines for manipulating 
 * probabilities and their integer log counterpart.
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include "squid.h"
#include "cfg.h"

/* Function: asIntLog
 * Date: RDD, Fri Aug 30 10:03:52 CDT 2002 [St Louis]
 *
 * Purpose: Debugging, convert prob. to int log form
 *
 * Args:
 *     prob	Prob to convert (in float form)
 *
 * Returns:
 * 	Prob in Int log form
 */
int
asIntLog (float prob)
{
   /* If we feed something nearly zero, we need to be
    * assured that we're getting back the int value of prob(zero).
    */
   if (LOG2(prob) < -BIGFLOAT) return -BIGINT;
   /* Adding the 0.5 make the cast effectively round */
   else return ((int) (LOG2(prob) * INTSCALE - 0.5));
}

/* Function: asLog
 * Date: Fri Dec 13 10:28:45 CST 2002 [St Louis]
 *
 * Purpose: Debugging, convert prob. to log form
 *
 * Args:
 *     prob	Prob to convert (in float form)
 *
 * Returns:
 * 	Prob in Float log form
 */
float 
asLog(float prob)
{
   /* If we feed something nearly zero, we need to be
    * assured that we're getting back the int value of prob(zero).
    */
   if (LOG2(prob) < -BIGFLOAT)  return -BIGFLOAT;
      /* Adding the 0.5 make the cast effectively round */
   else  return (LOG2(prob) * INTSCALE); 
}

/* Function: asFloatProb
 * Date: RDD, Fri Aug 30 10:08:50 CDT 2002 [St Louis]
 *
 * Purpose: Debugging, convert int log form to prob 
 *
 * Args:
 *     prob	Prob to convert (in int log form)
 *
 * Returns:
 * 	Prob as a float
 */
float
asFloatProb(int prob)
{
   if (prob <= -BIGINT) return 0.0;
   else return (exp(LN2 * (float)(prob/INTSCALE))); 
}

/* Function: asProb
 * Date: Fri Dec 13 10:28:30 CST 2002 [St Louis]
 *
 * Purpose: Debugging, convert log form to prob 
 *
 * Args:
 *     prob	Prob to convert (in log form)
 *
 * Returns:
 * 	Prob as a float
 */
float
asProb (double prob)
{
   if (prob <= -BIGFLOAT) return 0.0; 
   else return ((float)(exp(LN2 * (prob/INTSCALE)))); 
}

/* Function: ILogsum()
 * From HMMer's mathsupport.c -- SRE, Mon Nov 11 15:07:33 1996
 * RDD, Thu Jun 20 14:54:03 CDT 2002 [St Louis]
 * 
 * Purpose:  Return the scaled integer log probability of
 *           the sum of two probabilities p1 and p2, where
 *           p1 and p2 are also given as scaled log probabilities.
 *         
 *           log(exp(p1)+exp(p2)) = p1 + log(1 + exp(p2-p1)) for p1 > p2
 *           
 *           For speed, builds a lookup table the first time it's called.
 *
 * Note: LOGSUM_TBL currently set to 20,000 (in cfg.h)
 *           
 * Args:     p1,p2 -- scaled integer log_2 probabilities to be summed
 *                    in probability space.
 *                    
 * Return:   scaled integer log_2 probability of the sum.
 */
inline int 
ILogsum(int p1, int p2)
{
  static int firsttime = 1;
  static int lookup[LOGSUM_TBL];
  int    diff;
  int    i;

  if (firsttime) {
    for (i = 0; i < LOGSUM_TBL; i++) 
      lookup[i] = (int) (INTSCALE * LN2INV *
			 (log(1.+exp(LN2 * (float) -i/INTSCALE))));
    firsttime = 0;
  }

  if (p2 < -BIGINT) return p1;
  else if (p1 < -BIGINT) return p2;

  diff = p1-p2;
  if      (diff >=  LOGSUM_TBL) return p1;
  else if (diff <= -LOGSUM_TBL) return p2;
  else if (diff > 0)            return p1 + lookup[diff];
  else                          return p2 + lookup[-diff];
} 

/* Function: DLogsum()
 * RDD, Fri Dec 20 08:56:01 CST 2002 [Cuba, MO]
 * 
 * Purpose:  Return the scaled log probability of
 *           the sum of two probabilities p1 and p2, where
 *           p1 and p2 are also given as scaled probabilities.
 *         
 *           log(exp(p1)+exp(p2)) = p1 + log(1 + exp(p2-p1)) for p1 > p2
 *           
 * Args:     p1,p2 -- scaled log_2 probabilities to be summed
 *                    in probability space.
 *                    
 * Return:   scaled log_2 probability of the sum.
 */
inline double  
DLogsum(double p1, double p2)
{
  double diff;
  double lookup;

  if (p2 < -BIGFLOAT) return p1;
  else if (p1 < -BIGFLOAT) return p2;

  diff = p1-p2;
  if (diff > 0) {
    lookup = (double) (INTSCALE * LN2INV *
			 (log(1.+exp(LN2 *  -diff/INTSCALE))));
  } else {
    lookup = (double) (INTSCALE * LN2INV *
			 (log(1.+exp(LN2 *  diff/INTSCALE))));
  }

  if      (diff >=  LOGSUM_TBL) return p1;
  else if (diff <= -LOGSUM_TBL) return p2;
  else if (diff > 0)            return p1 + lookup;
  else                          return p2 + lookup;
}

/* Function: ILogsumSet()
 * RDD, Wed Aug 21 16:08:37 CDT 2002 [St Louis]
 *
 * Purpose: Given an array of scaled integer log probabilities,
 * 		calculate the sum across the array.
 *
 * Args:
 *   intprob	scaled integer (log_2) probs
 *   n		size of intprob array
 *
 * Return:  scaled integer prob of sum
 */
int 
ILogsumSet(int *intprob, int n)
{
  static int firsttime = 1;
  static int lookup[LOGSUM_TBL];
  int    diff;
  int    i, temp;

  if (firsttime) {
    for (i = 0; i < LOGSUM_TBL; i++) 
      lookup[i] = (int) (INTSCALE * LN2INV *
			 (log(1.+exp(LN2 * (float) -i/INTSCALE))));
    firsttime = 0;
  }

  if (n == 0) return (-BIGINT);
  if (n == 1) return (intprob[0]);

  /* rddSort(intprob, n);
  for (i = 0; i < n; i++) {
     printf("i %d : %d\n", i, intprob[i]);
  } */

  diff = intprob[0] - intprob[1];
  if (diff >= LOGSUM_TBL) temp = intprob[0];
  else if (diff <= -LOGSUM_TBL) temp = intprob[1];
  else if (diff > 0) temp = intprob[0] + lookup[diff];
  else temp = intprob[1] + lookup[-diff];

  if (n == 2) return temp;

  for (i = 2; i < n; i++) {
     diff = temp - intprob[i];

     if (diff >= LOGSUM_TBL) temp = temp;
     else if (diff <= -LOGSUM_TBL) temp = intprob[i];
     else if (diff > 0) temp = temp + lookup[diff];
     else temp = intprob[i] + lookup[-diff];
  }
  return temp;
} 

/**************** Debugging Fuctions **************/
int 
sanityCheck(int *intprob, int n)
{
   double *asfloats;
   double sum;
   int i;

   asfloats = (double *) malloc(sizeof(double)*n+1);

   sum = 0.0;
   for (i = 0; i < n ; i++) {
      asfloats[i] = asFloatProb(intprob[i]);
      printf("%e %d\n", asfloats[i], intprob[i]);
      sum += asfloats[i];
   }
   return (asIntLog(sum));
}

void
rddSort(int *intprob, int n)
{
   int i, j, temp;

   for (i = 0; i < n; i++) {
      for (j = i+1; j < n; j++) {
	 if (intprob[i] > intprob[j]) {
	    temp = intprob[j];
	    intprob[j] = intprob[i];
	    intprob[i] = temp;
	 }
      }
   }
}

/* Function: DLog2Choose
 * modified from QRNA's er_math.c
 * Date: Wed Oct  8 12:34:30 CDT 2003 [St Louis]
 *
 * Purpose: Pick an element based on it's probability.
 * 
 * Args: 
 *    p		vector of probs (what units?)
 *    N		size of vector
 * Returns:
 *    index to selected element of p
 */
int
DLog2Choose(double *p, int N)
{
  double roll;                  /* random fraction */
  double sum;                   /* integrated prob */
  int    i;                     /* counter over the probs */

  roll    = sre_random(); /* (float)rand()/RAND_MAX; */
  sum     = 0.0;
  for (i = 0; i < N; i++) {
     sum += p[i];
     if (sum > 1.00001) Die ("DLog2Choose() sum larger than one");
     if (roll < sum) { return i; }
  }
  return (int) (sre_random() * N);   /* bulletproof */
}


