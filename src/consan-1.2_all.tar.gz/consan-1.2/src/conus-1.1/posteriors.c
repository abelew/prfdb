/* posteriors.c
 * RDD, Tue Sep  3 20:58:26 CDT 2002 
 *
 * Calculate various posterior probs and utilize
 * these probs to check algorithms and within 
 * other analysis.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "squid.h"
#include "cfg.h"
#include "trace.h"
#include "alphabet.h" /* DigitizeSequence */

int posteriorCheck(double ***mx, double ***mxo, char *rna, int len, 
      PROBMOD *model, int grammar);
void probXpairs(int x, double ***mx, double ***mxo, char *rna, int len, 
      PROBMOD *model, int grammar, double *ret_sc);

/* Function: posteriorCheck
 * Date: RDD, Tue Sep  3 20:59:43 CDT 2002 [St Louis]
 *
 * Purpose: Use the posteriors to verify that Inside and
 * 	Outside work properly.  At this level this function
 * 	is independent of grammar.
 * 	
 * Args:
 *  	mx		Inside matrix -- filled
 *  	mxo		Outside Matrix -- filled
 * 	rna		Sequence under study
 *      len		Length of said sequence
 *      model 		Parameters for this model
 *      grammar 	Under what grammar
 *      
 * Returns:
 *   1 on success; 0 on failure
 */
int
posteriorCheck(double ***mx, double ***mxo, char *rna, int len, 
      PROBMOD *model, int grammar)
{
   int i;
   double unpaired = 0.;
   double paired = 0.;
   char *drna;
   int debug, count;
   double temp, boundary;

   debug = TRUE; count = 0; 
   drna = DigitizeSequence(rna, len);

   if (debug) printf("Pos %12s %18s %18s\n", "Unpaired", "Paired", "Sum"); fflush(stdout);
   for (i = 0; i < len; i++) {
      probXunpaired(i, mx, mxo, drna, len, model, grammar, &unpaired);    
      probXpairs(i, mx, mxo, drna, len, model, grammar, &paired); 

      if (debug) printf("%d %s %12f %18f %18f %10f \n", i, 
	    baseNAME[drna[i]], unpaired, paired, 
	    DLogsum(unpaired, paired), asProb(DLogsum(unpaired, paired)));
      fflush(stdout);

      /* Crude Check: Want our tolerance to be within 0.01 */
      temp = DLogsum(unpaired, paired);

   }
   printf("Length: %d; Num Off: %d\n", len, count);

   return 1;
}

/* Function: probXpairs
 * Date: RDD, Tue Sep  3 21:02:24 CDT 2002 [St Louis]
 *
 * Purpose: Calculate the Probability that X pairs 
 * 	At this level this function is independent of
 * 	the grammar.
 *
 * Note: probXYpairs requires x < y
 *
 * Args:
 * 	x		First index
 * 	mx		Inside matrix -- filled
 * 	mxo		Outside Matrix -- filled
 *	rna		Sequence under study
 *	len		Length of said sequence
 *	model 		Parameters for this model
 *	grammar 	Under which grammar
 *	ret_sc		Prob(x pairs y) as Int log sum
 *
 */
void
probXpairs(int x, double ***mx, double ***mxo, char *rna, int len, 
      PROBMOD *model, int grammar, double *ret_sc)
{
   int k;
   double sum, debug;
   double cur_sc;

   debug = FALSE;
   sum = -BIGFLOAT;	/* Prob = zero */

   for (k = 0; k < len; k++) {
     if (k < x-HLEN) {
       probXYpair(k, x, mx, mxo, rna, len, model, grammar, &cur_sc);
       sum = DLogsum(sum, cur_sc);
     } else if (k > x+HLEN) {
       probXYpair(x, k, mx, mxo, rna, len, model, grammar, &cur_sc);
       sum = DLogsum(sum, cur_sc);
     }
   } 
   *ret_sc = sum;
}
