#ifndef TRACE_H_INCLUDED
#define TRACE_H_INCLUDED

/* Structure: trace_s
 * 
 * Binary tree structure for storing an RNA structure,
 * derived as a traceback of an alignment of SCFG to sequence.
 *
 */
struct trace_s {
  int emitl;			/* i position (0..N-1) or -1 if nothing   */
  int emitr;			/* j position (0..N-1) or -1 if nothing   */

  int transition;               /* Transition to this node */
  int nonterminal;		/* Nonterminal type for this node */
    
  struct trace_s *nxtl;		/* ptr to left (or only) branch, or NULL for end    */
  struct trace_s *nxtr;		/* ptr to right branch, for o(mx)^2 only, else NULL */
  struct trace_s *prv;          /* ptr to parent                                    */
};

/* Structure: tracestack_s
 *
 * A pushdown stack used for traversing a binary tree of trace_s structures.
 */
struct tracestack_s {
  struct trace_s      *node;
  struct tracestack_s *nxt;
};

extern struct trace_s * InitTrace(void);
extern struct trace_s * AttachTrace(struct trace_s *parent, int nonterminal, int emitl, int emitr, int transition);
extern void FreeTrace(struct trace_s *tr);
extern struct tracestack_s * InitTracestack(void);
extern void PushTracestack(struct tracestack_s *stack, struct trace_s *tracenode);
extern struct trace_s * PopTracestack(struct tracestack_s *stack);
extern void FreeTracestack(struct tracestack_s *stack);
extern void PrintTrace(FILE *fp, struct trace_s *tr, char *seq);
extern int KHS2Trace(char *seq, char *ss, int len, struct trace_s **ret_tr, 
      int tolerate, int grammar);

/* deprecated */
extern int TraceScore_old(char *seq, int len, struct trace_s *tr, INTMOD *icfg);
#endif /* TRACE_H_INCLUDED */

