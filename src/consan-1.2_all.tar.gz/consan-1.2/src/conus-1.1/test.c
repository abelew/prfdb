/* inout_main.c 
 *
 * Verify that Inside and Outside work properly by
 * using the fact that posteriors can be used to
 * characterize a base as paired or unpaired.
 *
 * The sum of all states of a particular nucleotide
 * must be 1 (these are probabilities).
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-m <file>     : Use parameters, grammar and scoring specified in model <file> \n\
-e <file>     : Use parameters specified in <file>; which is in ascii format \n\
-r <file>     : Use training set in <file>; ignored if model file specified\n\
-g <string>   : Use grammar <string>, defaults to NUS; ignored if model file specified \n\
-s <file>     : save model file to <file> \n\
-o <file>     : redirect output to <file>\n\
-l <file>     : Load counts specified in <file> \n\
-k <file>     : Save counts specified to <file> \n\
-x            : print out parameters of model \n\
-t            : print traceback\n\
-d            : debugging output \n\
-v            : verbose output \n\
-f            : debugging, print fill matrix from cyk \n\
-p            : print real with predicted structure\n\
-q            : print predicted structures in stockholm format \n\
";

static char usage[]  = "Usage: test2 [-options] <seqfile in>\n";

int 
main (int argc, char **argv) 
{
   /**** arguments variables *****/
   int   optid; 
   OPTS settings;

   /* ReadSeq variables */
   SQFILE *sqfp; SQINFO sqinfo;
   int sformat;
   char *rna, *drna; 
   char *ss; 
   int *ctstruct; 

   /* Models info */
   MODEL nusmodel;
   PROBMOD dlogs;
   int ***insideMX, ***outsideMX;
   double ***idMX, ***odMX;
   int noerror, score;
   double sc;

   noerror = TRUE;

   if (!(ProcessOpts(&settings, &optid, argc, argv, usage, optsline))) {
      printf("%s\n\n", usage);
      exit(0);
   }
   if (argc - optid != 1)
      Die("Incorrect number of command line arguments.\n%s\n%s\n", 
	    usage, optsline);

   SetupModel(&settings, &nusmodel);  
   DLogifySCFG(&(nusmodel.probs), &dlogs);
   LogifySCFG(&(nusmodel.probs), &(nusmodel.scores)); 

   if (settings.modelfile == NULL) {
     nusmodel.grammar = settings.grammar;
     SetUpFlatMx(&(nusmodel.probs), settings.grammar);
     LogifySCFG(&(nusmodel.probs), &(nusmodel.scores)); 
   }

   if (settings.debugg) {
      PrintFullModel(settings.ofp, &nusmodel);
      PrintProbModel(stdout, &dlogs, NUS);
   }

   /* Read input file into RNA array and filter for non-RNA residues */
   if ((sqfp = SeqfileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL) 
          Die("Failed to open sequence file %s\n%s\n", argv[optid], usage);

   while (ReadSeq(sqfp, sformat, &rna, &sqinfo)) {
      ToRNA(rna);
      if (settings.verbose) fprintf(settings.ofp, "Sequence %s:\n", sqinfo.name);

      if (! KHS2ct(sqinfo.ss, sqinfo.len, FALSE, &ctstruct))
      { printf("[bad trusted structure]\n"); return (FALSE);}

      if (!settings.structout) {		/* Ignore given structure */
        ctstruct = NULL;
      } 

      noerror = Inside(rna, sqinfo.len, nusmodel.grammar, &dlogs, &settings, 
	    NULL, &sc, &idMX);
      printf("Inside score %f\n", sc);
      if (noerror) {
	 noerror = Outside(rna, sqinfo.len, nusmodel.grammar, &dlogs, 
	       &settings, NULL, idMX, &odMX);
      }
      /*
      if (noerror) {
	 posteriorCheck(idMX, odMX, rna, sqinfo.len, &dlogs, nusmodel.grammar);
      }
      */
      freeFillMxD(odMX, nusmodel.grammar);  
      freeFillMxD(idMX, nusmodel.grammar); 
      FreeSequence(rna, &sqinfo);
   }
   SeqfileClose(sqfp);
}

void TestCYKdiffs(char *rna, int len, PROBMOD *prmodel, OPTS *output, SQINFO *sqinfo);
void findDifferences(int ***matxZ, int ***matxU, int len);

void
TestCYKdiffs(char *rna, int len, PROBMOD *prmodel, OPTS *output, SQINFO *sqinfo)
{
  int ***matxZ;
  int ***matxU;
  struct trace_s *trU;
  struct trace_s *trZ;
  char *drna;
  INTMOD scmodel;

  char *ssU; 

  SetAlphabet(hmmNUCLEIC);
  trZ = NULL; trU = NULL;
  drna = DigitizeSequence(rna, len);

  LogifySCFG(prmodel, &scmodel);

  AllocFillMx(len, &matxU);

  cykInitMx(matxU, &scmodel, drna, len, RZK);

  cykFillMx(matxU, &scmodel, drna, len, RZK);

  findDifferences(matxZ, matxU, len);

  trU = (struct trace_s *)cykTraceMx(matxU, &scmodel, drna, len, RZK);

  if ((trZ != NULL) && (trU != NULL)) {
    if (output->traceback) {
      PrintTrace(output->ofp, trU, rna); 
    }
    Trace2KHS(trU, rna, len, 1, &ssU);

    fprintf(output->ofp, "RZK structure:\n");
    PrintKHS(output->ofp, rna, sqinfo, ssU);
  }

  FreeFillMx(matxU, len);
  free(drna);
}

void
findDifferences(int ***matxZ, int ***matxU, int len)
{
  int i, j, d;

  for (i = 0; i < len; i++) {
    for (j = i; j < len; j++) {
      d = j-i;
      if (matxZ[i][j][dpS] != matxU[j][d][dpS]) {
        printf("dpS (%d, %d) d = %d Zij %d RZK %d\n", i, j, d, matxZ[i][j][dpS], matxU[j][d][dpS]);
      }
      if (matxZ[i][j][dpT] != matxU[j][d][dpT]) {
        printf("dpT (%d, %d) d = %d Zij %d RZK %d\n", i, j, d, matxZ[i][j][dpT], matxU[j][d][dpT]);
      }
      if (matxZ[i][j][dpP] != matxU[j][d][dpP]) {
        printf("dpP (%d, %d) d = %d Zij %d RZK %d\n", i, j, d, matxZ[i][j][dpP], matxU[j][d][dpP]);
      }
      if (matxZ[i][j][dpN] != matxU[j][d][dpN]) {
        printf("dpN (%d, %d) d = %d Zij %d uZK %d\n", i, j, d, matxZ[i][j][dpN], matxU[j][d][dpN]);
      }
      if (matxZ[i][j][dpM] != matxU[j][d][dpM]) {
        printf("dpM (%d, %d) d = %d Zij %d RZK %d\n", i, j, d, matxZ[i][j][dpM], matxU[j][d][dpM]);
      }
      if (matxZ[i][j][dpJ] != matxU[j][d][dpJ]) {
        printf("dpJ (%d, %d) d = %d Zij %d RZK %d\n", i, j, d, matxZ[i][j][dpJ], matxU[j][d][dpJ]);
      }
    }
  }  
}
