#define PACKAGE     "CONUS"
#define RELEASE     "1.0"
#define RELEASEDATE "in progress"
#define COPYRIGHT   "Copyright (C) 2002 HHMI/Washington University School of Medicine"
#define LICENSE     "Freely distributed under the GNU General Public License (GPL)"
#define BANNER	    "CONUS: Single Sequence SCFG algorithms"

