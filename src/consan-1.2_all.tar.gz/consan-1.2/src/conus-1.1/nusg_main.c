/* nusg_main.c 
 * RDD, Thu Oct  9 10:50:45 CDT 2003 
 *
 * nusg_main.c -- generate sequence from a model
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"


static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-m <file>     : Use parameters, grammar and scoring specified in model <file> \n\
-x            : print out parameters of model \n\
-b <num>      : generate num sequences (default is 5) \n\
-d            : debugging output \n\
-v            : verbose output \n\
-q            : print generated structures in stockholm format \n\
";
static char usage[]  = "Usage: conus_generate [-options] -m model.mod \n";

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;

  FILE *ofp, *ifp;

  /* ReadSeq variables */
  SQINFO sqinfo;
  char *rna; 
  char *ss; 
  int nums;

  /* Models info */
  MODEL nusmodel;

  if (!(ProcessOpts(&settings, &optid, argc, argv, usage, "\tfor BJK only!", optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  SetupModel(&settings, &nusmodel);
  nums = 0;

  if (settings.grammar != BJK) {
    Die("At this time, you can only generate from BJK (G6)!\n%s\n%s\n", usage, optsline);
  }

  /* Digitize Sequence Setup*/
  SetAlphabet(hmmNUCLEIC);
  if (settings.debugg) PrintOptions(settings.ofp, &settings);
  if (settings.parameterout) PrintModel(settings.ofp, &nusmodel);

   sre_srandom(time(NULL));

  while (nums < settings.percentage) {
     sprintf(sqinfo.name, "Example %d", nums);
     sqinfo.len = generate_RNA(&(nusmodel.probs), &rna, &ss, BJK);
     if (settings.stockout) {
	PrintStockholm(settings.ofp, rna, &sqinfo, ss);
     } else {
	PrintKHS(settings.ofp, rna, &sqinfo, ss);
     }

     /* Cleanup  */
     free(ss);
     free(rna);
     nums++;
  }
}
