/* nust_main.c 
 * RDD, Tue Aug 21 15:02:15 CDT 2001
 *
 * nust_main.c -- Nussinov training algorithms
 * 	-- given set of seq + structure and model; train parameters
 *
 * Want to compare unambiguous Nussinov with regular
 * Nussinov and determine what you gain (compare 8 production
 * Nussinov to unambiguous Nussinov) at what cost (compare
 * unambiguous Nussinov to plain Nussinov) for
 * making a grammar unambiguous.  
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-g <string>   : Use grammar <string>, defaults to NUS\n\
-l <file>     : Load prior specified in <file> \n\
-1            : Turn off the standard plus one prior \n\
-s <file>     : save model file to <file>; defaults to conus.mod \n\
-x            : print out parameters of model \n\
-t            : print traceback\n\
-d            : debugging output \n\
-v            : verbose output \n\
";
static char usage[]  = "Usage: conus_train [-options] <training set files> \n";

void gatherCounts (INTMOD *counts, char *filename, int grammar, OPTS *settings);

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;
  MODEL scfg;
  FILE *ofp, *ifp;
  INTMOD prior;

  /**** parse arguments *****/
  if (!(ProcessOpts(&settings, &optid, argc, argv, usage, gramdesc, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  /* Must have specified at least one training file */
  if (argc - optid < 1) 
	  Die("Incorrect number of command line arguments.\n%s\n%s\n",
			  usage, optsline);
  
  scfg.grammar = settings.grammar;

  /* If training it must be probabilistic */
  scfg.probabilistic = TRUE; settings.useprob = TRUE;
  if (settings.verbose) 
      fprintf(settings.ofp, "Training, Grammar is %s\n", grNAME[scfg.grammar]);

  ZeroModel(&scfg);

  /* Run through sequences in training files and gather counts*/
  while (!(argc - optid < 1)) {
    printf("Training set %s\n", argv[optid]); fflush(stdout);
    /* settings.trainfile = argv[optid]; */
    gatherCounts(&(scfg.scores), argv[optid], settings.grammar, &settings);
    optid++;
  }

  /* Setup Plus one prior */
  zeroIntMod(&prior);
  plusOnePrior(&prior);

  /* Convert counts into probabilities */
  ProbifySCFG(&(scfg.scores), &(scfg.probs), scfg.grammar, &prior);

  if (settings.verbose) {
    if (CheckModel(&(scfg.probs), scfg.grammar) == FALSE) {
      printf("WARNING: Model probabilities are off!\n");
    } else {
      printf("Model probabilities are fine!\n");
    }
  }

  /* If asked to save the model, do so now. */
  if (settings.savefile != NULL) {
    ofp = fopen(settings.savefile, "w");
    SaveSCFG(ofp, &scfg);
  }
}

/* Function: gatherCounts
 * Date:     RDD, Thu Nov 15 17:53:56 2001 [St. Louis]
 *
 * Purpose: Convert training sequences into counts
 *
 * Args:    
 *	 counts		integer form of model to keep counts
 *	 filename	training file name
 *	 grammar	which grammar to utilize
 *	 settings	command line options
 *
 * Returns:  nothing
 */
void
gatherCounts (INTMOD *counts, char *filename, int grammar, OPTS *settings)
{
  SQFILE *sfp; SQINFO sinfo;
  int sformat; char *rna;
  struct trace_s *nustrc;
  int ignored, counted, total;

  ignored = 0; total = 0; counted = 0;
  /* TRAINING SET SEQUENCE FILE */
  if ((sfp = SeqfileOpen(filename, SQFILE_UNKNOWN, NULL)) == NULL)
    Die("Failed to open sequence file %s\n", filename);

  while (ReadSeq(sfp, sformat, &rna, &sinfo)) {
    ToRNA(rna);
    total ++;

    if (settings->istats) { printf("%s  ", sinfo.name); fflush(stdout); }

    if (VerifyKHS(sinfo.name, sinfo.ss, TRUE) == TRUE) {

      /* KHS2Trace */
      if (KHS2Trace(rna, sinfo.ss, sinfo.len, &nustrc, TRUE, grammar)) { 

        /* if verbose */
	if (settings->traceback) {
	  printf("%s", sinfo.name);
          PrintTrace(settings->ofp, nustrc, rna);
	  printf("\n");
	}

        /* Trace Counts */
        traceCount(rna, sinfo.len, 1, nustrc, counts, grammar);
        if (settings->istats) { printf("counted\n"); fflush(stdout); }
        counted ++;
      } else {
        if (settings->istats) { printf("ignored\n"); fflush(stdout); }
        ignored ++;
      }

      FreeTrace(nustrc);
    }

    /* Cleanup  */
    FreeSequence(rna, &sinfo);
  }
  printf("Training: %d Ignored %d Counted %d Total \n", ignored, counted, total);
  fflush(stdout);

  SeqfileClose(sfp);
}


