/* cfgmodel.c
 * RDD, Fri Aug 24 12:51:19 2001
 * 
 * Usage and setup of model parameters.
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include "squid.h"
#include "cfg.h"

/* Function: dropStacking 
 * Date: RDD, Wed Sep 15 13:36:36 CDT 2004
 *
 * Purpose:  
 *    Given a model which contains stacking parameters,
 *    push the pairing parameters down on stacking so that
 *    it behaves as if there were NOT stacking values.
 *
 * Args:     
 *
 * Return:   
 */
void
dropStacking(MODEL *mod) 
{
  int pair,i,j;

  for (pair = 0; pair < (ALPHA*ALPHA); pair++) {
    for (i = 0; i < ALPHA; i++) {
      for (j = 0; j < ALPHA; j++) {
	mod->probs.stack[pair][i][j] = mod->probs.pairs[i][j];
	mod->scores.stack[pair][i][j] = mod->scores.pairs[i][j];
      }
    }
  }
}
/* Function: contains_rule 
 *
 * Purpose:  
 * 	Determine if a particular rule is used in 
 * 	a given grammar.
 *
 * Notes: Depends on globally defined variable
 * 	Rules[grammar][dp][transition]
 * 	which is defined in globals.c
 *
 * Args:     
 * 	grammar		grammar in use
 * 	dp		rule 
 *
 * Return:   
 * 	TRUE if this rule uses any transitions
 * 		(and is therefore permitted in this grammar)
 * 	FALSE if this rule is not used in this grammar
 */
int
contains_rule (int grammar, int dp) 
{
  int i;

  for (i = 0; i < NTRANS; i++) {
    if (Rules[grammar][dp][i] > 0) return TRUE;
  }
  return FALSE;
}

/* Function: plusOnePrior
 * Date: RDD, Sun Mar 10 13:09:24 CST 2002 [St Louis]
 *
 * Purpose: Add +1 prior (does not zero!)
 *
 * Returns: Nothing
 */
void
plusOnePrior(INTMOD *probs)
{
 int i,j,k, l;

  for (i = 0; i < NTRANS; i++) {
    probs->transitions[i] ++;
  }
  for (i = 0; i < ALPHA; i++) {
    for (j = 0; j < ALPHA; j++) {
      for (k = 0; k < ALPHA; k++) {
        for (l = 0; l < ALPHA; l++) {
          probs->stack[(4*k+l)][i][j] ++;
        }
      }
      probs->pairs[i][j] ++;
    }
    probs->singles[i] ++;
    probs->loopcomp[i] ++;
    probs->hpcomp[i] ++;
    probs->bulgecomp[i] ++;
  }
  for (i = 0; i < MAXLOOP; i++) {
    probs->loop[i] ++;
    probs->hairpin[i] ++;
    probs->bulge[i] ++;
  }
}

/* Function: DLogifySCFG()
 * Date: Fri Dec 20 09:10:33 CST 2002 [St. Roberts, MO]
 *
 * Purpose:  Take an SCFG and convert it to log form
 *           for an alignment.
 *
 * Notes: Both cfg and icfg must already be allocated.
 *
 * Args:     cfg  - the grammar, floating point form
 * 	    icfg  - the grammar, log form
 *
 * Return:   log form of the grammar
 */
void
DLogifySCFG(PROBMOD *cfg, PROBMOD *ret_icfg)
{
  int   i,j, k, bd;

  bd = ALPHA * ALPHA;

  for (k = 0; k < bd; k++) {
    for (i = 0; i < ALPHA; i++) {
      for (j = 0; j < ALPHA; j++) {
	 ret_icfg->stack[k][i][j] = asLog(cfg->stack[k][i][j]);
	 if (k == 0) 
	   ret_icfg->pairs[i][j] = asLog(cfg->pairs[i][j]);
      }
      if (k == 0) {
        ret_icfg->singles[i] = asLog(cfg->singles[i]);
        ret_icfg->loopcomp[i] = asLog(cfg->loopcomp[i]);
        ret_icfg->hpcomp[i] = asLog(cfg->hpcomp[i]);
        ret_icfg->bulgecomp[i] = asLog(cfg->bulgecomp[i]);
      }
    }
  }
  for (i = 0; i < MAXLOOP; i++) {
    ret_icfg->loop[i] = asLog(cfg->loop[i]);
    ret_icfg->hairpin[i] = asLog(cfg->hairpin[i]);
    ret_icfg->bulge[i] = asLog(cfg->bulge[i]);
  }
  ret_icfg->loop[0] = -BIGFLOAT;	
  ret_icfg->hairpin[0] = -BIGFLOAT;	
  for (i = 0; i < NTRANS; i++) {
    ret_icfg->transitions[i] = asLog(cfg->transitions[i]);
  }
}

/* Function: LogifySCFG()
 * from yarn's model.c -- SRE, Fri May 27 11:25:06 1994
 * modified for conus; RDD, Wed Oct 17 08:36:36 CDT 2001 [St Louis]
 *
 * Purpose:  Take an SCFG and convert it to integer log form
 *           for an alignment.
 *
 * Notes: Both cfg and icfg must already be allocated.
 *
 * Args:     cfg  - the grammar, floating point form
 * 	    icfg  - the grammar, integer log form
 *
 * Return:   integer log form of the grammar
 */
void
LogifySCFG(PROBMOD *cfg, INTMOD *ret_icfg)
{
  int   i,j, k, bd;

  bd = ALPHA * ALPHA;

  for (k = 0; k < bd; k++) {
    for (i = 0; i < ALPHA; i++) {
      for (j = 0; j < ALPHA; j++) {
	 ret_icfg->stack[k][i][j] = asIntLog(cfg->stack[k][i][j]);
	 if (k == 0) 
	   ret_icfg->pairs[i][j] = asIntLog(cfg->pairs[i][j]);
      }
      if (k == 0) {
        ret_icfg->singles[i] = asIntLog(cfg->singles[i]);
        ret_icfg->loopcomp[i] = asIntLog(cfg->loopcomp[i]);
        ret_icfg->hpcomp[i] = asIntLog(cfg->hpcomp[i]);
        ret_icfg->bulgecomp[i] = asIntLog(cfg->bulgecomp[i]);
      }
    }
  }
  for (i = 0; i < MAXLOOP; i++) {
    ret_icfg->loop[i] = asIntLog(cfg->loop[i]);
    ret_icfg->hairpin[i] = asIntLog(cfg->hairpin[i]);
    ret_icfg->bulge[i] = asIntLog(cfg->bulge[i]);
  }
  ret_icfg->loop[0] = -BIGINT;	
  ret_icfg->hairpin[0] = -BIGINT;	
  for (i = 0; i < NTRANS; i++) {
    ret_icfg->transitions[i] = asIntLog(cfg->transitions[i]);
  }
}

/* Function: InvLogifySCFG()
 * from yarn's model.c -- SRE, Fri May 27 11:25:06 1994
 * modified for conus; RDD, Wed Oct 17 08:36:36 CDT 2001 [St Louis]
 *
 * Purpose:  Take an SCFG and convert it from integer log form 
 * 	to probability form.  This is the direct inverse of
 * 	LogifySCFG.
 *
 * Notes: Both cfg and icfg must already be allocated.
 *
 * Args:     cfg  - the grammar, floating point form
 * 	    icfg  - the grammar, integer log form
 *
 * Return:   integer log form of the grammar
 */
void
InvLogifySCFG(INTMOD *cfg, PROBMOD *ret_icfg)
{
  int   i,j, k, bd;

  bd = ALPHA * ALPHA;

  for (k = 0; k < bd; k++) {
    for (i = 0; i < ALPHA; i++) {
      for (j = 0; j < ALPHA; j++) {
	 ret_icfg->stack[k][i][j] = asFloatProb(cfg->stack[k][i][j]);
	 if (k == 0) 
	   ret_icfg->pairs[i][j] = asFloatProb(cfg->pairs[i][j]);
      }
      if (k == 0) {
        ret_icfg->singles[i] = asFloatProb(cfg->singles[i]);
        ret_icfg->loopcomp[i] = asFloatProb(cfg->loopcomp[i]);
        ret_icfg->hpcomp[i] = asFloatProb(cfg->hpcomp[i]);
        ret_icfg->bulgecomp[i] = asFloatProb(cfg->bulgecomp[i]);
      }
    }
  }
  for (i = 0; i < MAXLOOP; i++) {
    ret_icfg->loop[i] = asFloatProb(cfg->loop[i]);
    ret_icfg->hairpin[i] = asFloatProb(cfg->hairpin[i]);
    ret_icfg->bulge[i] = asFloatProb(cfg->bulge[i]);
  }
  ret_icfg->loop[0] = -BIGINT;	
  ret_icfg->hairpin[0] = -BIGINT;	
  for (i = 0; i < NTRANS; i++) {
    ret_icfg->transitions[i] = asFloatProb(cfg->transitions[i]);
  }
}
void
InvDLogifySCFG(PROBMOD *cfg, PROBMOD *ret_icfg)
{
  int   i,j, k, bd;

  bd = ALPHA * ALPHA;

  for (k = 0; k < bd; k++) {
    for (i = 0; i < ALPHA; i++) {
      for (j = 0; j < ALPHA; j++) {
	 ret_icfg->stack[k][i][j] = asProb(cfg->stack[k][i][j]);
	 if (k == 0) 
	   ret_icfg->pairs[i][j] = asProb(cfg->pairs[i][j]);
      }
      if (k == 0) {
        ret_icfg->singles[i] = asProb(cfg->singles[i]);
        ret_icfg->loopcomp[i] = asProb(cfg->loopcomp[i]);
        ret_icfg->hpcomp[i] = asProb(cfg->hpcomp[i]);
        ret_icfg->bulgecomp[i] = asProb(cfg->bulgecomp[i]);
      }
    }
  }
  for (i = 0; i < MAXLOOP; i++) {
    ret_icfg->loop[i] = asProb(cfg->loop[i]);
    ret_icfg->hairpin[i] = asProb(cfg->hairpin[i]);
    ret_icfg->bulge[i] = asProb(cfg->bulge[i]);
  }
  ret_icfg->loop[0] = -BIGINT;	
  ret_icfg->hairpin[0] = -BIGINT;	
  for (i = 0; i < NTRANS; i++) {
    ret_icfg->transitions[i] = asProb(cfg->transitions[i]);
  }
}

/* Function: ProbifySCFG()
 * Date: RDD, Wed Oct 17 08:36:36 CDT 2001 [St Louis]
 * 
 * Purpose:  Convert a model from counts to probabilities
 * 
 * Args:     
 *      icfg     counts form of parameters
 *      ret_cfg  probabilistic form of parameters
 *      prior    + constant (usually 1) for prior
 *                 
 * Returns:  nothing.
 */
void
ProbifySCFG(INTMOD *icfg, PROBMOD *ret_cfg, int grammar, INTMOD *prior)
{
  probifyEmissions(icfg, ret_cfg, prior);

  /* Convert stack parameters for all grammars except 
   * Nussinov (NUS) and it's Unambiguous Versions (UNA, RUN)
   */
  if (grFAMILY[grammar] != NUN) {
    probifyStackParams(icfg, ret_cfg, prior);
  }

  /* Zuker and it's Unambiguous Counterparts require loop parameters */
  if (grFAMILY[grammar] == ZKG) {
    probifyLoops(icfg, ret_cfg, prior, TRUE);
  }

  /* Convert Transitions:
   *   Nussinov requires a special function as it has disambiguation
   *   constraints.
   *
   *   (probifyNus in nus.c because it's specific to NUS)
   */
  if (grammar == NUS) probifyNUS(icfg, ret_cfg, prior);
  else if (grammar == YRN) probifyYRN(icfg, ret_cfg, prior);
  else {
    if (grFAMILY[grammar] == AYR) { tieParams(icfg); }
    probifyTransitions(icfg, ret_cfg, prior, grammar);
  }
}

/* Function: probifyEmissions()
 * Date: RDD, Mon Feb 18 12:22:44 CST 2002 [St Louis]
 * 
 * Purpose:  Properly convert counts to probabilities
 *           for singles and pair emissions
 * 
 * Args:     
 *      icfg     counts form of parameters
 *      ret_cfg  probabilistic form of parameters
 *      prior    + constant (usually 1) for prior
 *                 
 * Returns:  nothing.
 */
void
probifyEmissions(INTMOD *icfg, PROBMOD *ret_cfg, INTMOD *prior) {
  int   i, j;                 /* from state, to state                      */
  int   denom;                /* sum used for normalization in denominator */
  int   denom2;                /* sum used for normalization in denominator */

  denom = 0; denom2 = 0;
  for (i = 0; i < ALPHA; i++) {
    for (j = 0; j < ALPHA; j++) {
      if ((i != ntT) && (j != ntT)) {
        denom += (icfg->pairs[i][j] + prior->pairs[i][j]);
      } 
    }
    if (i != ntT) {
      denom2 += (icfg->singles[i] + prior->singles[i]);
    }
  }
  for (i = 0; i < ALPHA; i++) {
    for (j = 0; j < ALPHA; j++) {
      if ((i != ntT) && (j != ntT)) {
        ret_cfg->pairs[i][j] = (double)(icfg->pairs[i][j] 
	      + prior->pairs[i][j]) / (double)denom;
      }
    }
    if (i != ntT) {
      ret_cfg->singles[i] = (double)(icfg->singles[i] 
	    + prior->singles[i]) / (double)denom2;
    }
  }
}

/* Function: probifyStackParams
 * Date:     RDD, Sat Dec  8 16:08:01 2001 [St. Louis]
 *
 * Purpose:  Properly convert counts to probabilities
 *           for stacking emissions
 *
 * Args:     
 *      icfg     counts form of parameters
 *      ret_cfg  probabilistic form of parameters
 *      prior    + constant (usually 1) for prior
 *
 * Returns:  nothing.
 */
void
probifyStackParams (INTMOD *icfg, PROBMOD *ret_cfg, INTMOD *prior)
{
  int i, j, k, boundary;
  int denom;

  boundary = ALPHA*ALPHA;
  for (i=0; i < boundary; i++) {
    denom = 0;
    for (j = 0; j < ALPHA; j++) {
      for (k = 0; k < ALPHA; k++) {
        if ((j != ntT) && (k != ntT)) {
          denom += (icfg->stack[i][j][k] + prior->stack[i][j][k]);
        }
      }
    }
    for (j = 0; j < ALPHA; j++) {
      for (k = 0; k < ALPHA; k++) {
        if ((j != ntT) && (k != ntT)) {
          ret_cfg->stack[i][j][k] = (double)(icfg->stack[i][j][k] + 
				prior->stack[i][j][k]) / (double)denom;
        }
      }
    }
  }
}

/* Function: probifyLoops
 * Date:     RDD, Mon Feb 18 12:22:44 CST 2002 [St Louis]
 *
 * Purpose:  Properly convert counts to probabilities
 *           for stacking emissions
 *
 * Args:     
 *      icfg     counts form of parameters
 *      ret_cfg  probabilistic form of parameters
 *      prior    + constant (usually 1) for prior
 *      tie	 whether to lump loops and hairpin counts together
 *
 * Returns:  nothing.
 */
void
probifyLoops (INTMOD *icfg, PROBMOD *ret_cfg, INTMOD *prior, int tie)
{
  int i, total;
  int denom, denom2, denom3;

  /* Smooth the counts out based on functional form 
  quadraticCounts(icfg->hairpin);
  quadraticCounts(icfg->loop);
  quadraticCounts(icfg->bulge);
   * */

  denom = 0; denom2 = 0; denom3 = 0;
  for (i = 1; i < MAXLOOP; i++) {
    denom += (icfg->loop[i] + prior->loop[i]);
    if (tie) {
      denom += icfg->hairpin[i];
      denom += icfg->bulge[i];
    } else {
      denom2 += (icfg->hairpin[i] + prior->hairpin[i]);
      denom3 += (icfg->bulge[i] + prior->bulge[i]);
    }
  }
  for (i = 1; i < MAXLOOP; i++) {
    if (tie) {
      total = icfg->loop[i] + prior->loop[i] + icfg->hairpin[i] + icfg->bulge[i];
      ret_cfg->loop[i] = (double)total / (double) denom;
      ret_cfg->hairpin[i] = (double)total / (double) denom;
      ret_cfg->bulge[i] = (double)total / (double) denom;
    } else {
      ret_cfg->loop[i] = (double)(icfg->loop[i] + prior->loop[i]) / (double)denom;
      ret_cfg->hairpin[i] = (double)(icfg->hairpin[i] + prior->hairpin[i]) / (double)denom2;
      ret_cfg->bulge[i] = (double)(icfg->bulge[i] + prior->bulge[i]) / (double)denom3;
    }
  }

  /* Used for forbidden loops (too big) */
  ret_cfg->loop[0] = 0.0; 	
  ret_cfg->hairpin[0] = 0.0; 	
  ret_cfg->bulge[0] = 0.0; 	

  denom = 0; denom2 = 0; denom3 = 0;
  for (i = 0; i < ALPHA; i++) {
    if (i != ntT) {
      denom += (icfg->loopcomp[i] + prior->loopcomp[i]);
      if (tie) {
        denom += icfg->hpcomp[i];
        denom += icfg->bulgecomp[i];
      } else {
        denom2 += (icfg->hpcomp[i] + prior->hpcomp[i]);
        denom3 += (icfg->bulgecomp[i] + prior->bulgecomp[i]);
      }
    }
  }
  for (i = 0; i < ALPHA; i++) {
    if (i != ntT) {
      if (tie) {
        total = icfg->loopcomp[i] + prior->loopcomp[i] + icfg->hpcomp[i] + icfg->bulgecomp[i];
        ret_cfg->loopcomp[i] = (double)total / (double) denom;
        ret_cfg->hpcomp[i] = (double)total / (double) denom;
        ret_cfg->bulgecomp[i] = (double)total / (double) denom;
      } else {
        ret_cfg->loopcomp[i] = (double)(icfg->loopcomp[i] + prior->loopcomp[i]) / (double)denom;
        ret_cfg->hpcomp[i] = (double)(icfg->hpcomp[i] + prior->hpcomp[i])/ (double)denom2;
        ret_cfg->bulgecomp[i] = (double)(icfg->bulgecomp[i] + prior->bulgecomp[i])/ (double)denom3;
      }
    }
  }
}

/* Function: probifyTransitions
 * Date:     RDD, Sat Dec  8 16:08:01 2001 [St. Louis]
 *
 * Purpose:  Properly convert counts to probabilities
 *           for transitions of Unambiguous Nussinov grammar
 *
 * Args:     
 *      icfg     counts form of parameters
 *      ret_cfg  probabilistic form of parameters
 *      prior    + constant (usually 1) for prior
 *      grammar  which grammar is being normalized
 *
 * Returns:  nothing.
 */
void
probifyTransitions(INTMOD *icfg, PROBMOD *ret_cfg, INTMOD *prior, int grammar) 
{
   int denom;
   int i, j;

  for (i = 0; i < NDPS; i++) {		/* For each rule */
    denom = 0;
    /* Calculate the denominator */
    for (j = 0; j < NTRANS; j ++) {
      if (Rules[grammar][i][j]) {
        denom += (icfg->transitions[j] + prior->transitions[j]);
      }
    }
    /* Convert to probabilities */
    for (j=0; j < NTRANS; j++) {
      if (Rules[grammar][i][j]) {
	ret_cfg->transitions[j] = (double)(icfg->transitions[j] + prior->transitions[j])/ (double) denom;
      }
    }
  }
}

/* Function: preCalcSegs
 * Date: RDD, Wed Sep  4 13:20:16 CDT 2002 [St Louis]
 *
 * Purpose: precalculate a long string of emissions for grammars
 *  	which can emit long single stranded regions
 *
 *  Args:
 *  	model	parameters of model in integer log form
 *  	drna	digitized version of sequence 
 *  	len	length of sequence
 *
 */
void
preCalcSegs (INTMOD *model, char *drna, int len)
{
  model->emitloop = preCalcSegEmit (drna, len, model->loopcomp);
  model->emithp = preCalcSegEmit (drna, len, model->hpcomp);
  model->emitbulge = preCalcSegEmit (drna, len, model->bulgecomp);
}

void
freePreCalcSegs(INTMOD *model)
{
   free(model->emitloop);
   free(model->emithp);
   free(model->emitbulge);
}

/* Function: preCalcSegEmit
 * RDD, Wed Feb 20 21:59:26 CST 2002 [St Louis]
 *
 * Purpose: Precalculate P(segment emission)
 *      Each array element (i) contains the sum of
 *      probabilities from i to the end of the sequence.
 *      Hence to calculate a segment is:
 *      emitseg(i,j) = emit(i) - emit(j+1);
 *
 * Args:
 *      rna     sequence, digitized
 *      len     sequence length
 *      comp	parameters of loop in integer form
 *
 * Returns:
 *      values for loops
 */
int *
preCalcSegEmit (char *rna, int len, int *comp)
{
  int i;
  int *lprna;

  lprna = MallocOrDie (sizeof(int) * (len+1));

  lprna[len] = 0;
  lprna[len-1] = comp[rna[len-1]];

  for (i = len-2; i >= 0; i--) {
    lprna[i] = lprna[i+1] + comp[rna[i]];
  }
  return (lprna);
}

/*********************** Hard coded special cases **********************/

/* Function: SetUpNusScoring
 * Date: RDD, Tue Feb 19 14:27:22 CST 2002 [St Louis]
 *
 * Purpose: Use standard Nussinov +1 scoring scheme
 * 
 * Returns: void
 */
void
SetUpNusScoring(INTMOD *sc)
{
  int i, j, k, l;

  for (i=0; i < NTRANS; i++) {
    sc->transitions[i] = 0;
  }
  for (i =0; i < ALPHA; i++) {
    for (j =0; j < ALPHA; j++) {
      for (k = 0; k < (ALPHA*ALPHA); k++) {
	if (((i == ntA) && (j == ntU)) || ((j == ntA) && (i == ntU)) 
	    || ((i == ntC) && (j == ntG)) || ((j == ntC) && (i == ntG)) /* C <-> G */
	    || ((i == ntG) && (j == ntU)) || ((j == ntG) && (i == ntU))) { /* G <-> U */
          sc->stack[k][i][j] = 1;
          sc->pairs[i][j] = 1;
	} else { 
          sc->stack[k][i][j] = 0;
          sc->pairs[i][j] = 0;
	}
      }
    }
    sc->singles[i] = 0;
    sc->loopcomp[i] = 0;
    sc->hpcomp[i] = 0;
    sc->bulgecomp[i] = 0;
  }

  for (i = 0; i < MAXLOOP; i++) {
    sc->loop[i] = 0;
    sc->hairpin[i] = 0;
    sc->bulge[i] = 0;
  }
}
/* Function: SetUpM99s1
 * Date: RDD, Thu Mar 18 14:32:06 CST 2004 [St Louis]
 *
 * Purpose: 
 *   Recreate the Mathews99 experiment shown in 
 *   their Table S1.  There GC pairs are +3, 
 *   AU and GU pairs are +2, and all loops are 0.
 * 
 * Returns: void
 */
void
SetUpM99s1(INTMOD *sc)
{
  int i, j, k, l;

  for (i=0; i < NTRANS; i++) {
    sc->transitions[i] = 0;
  }
  for (i =0; i < ALPHA; i++) {
    for (j =0; j < ALPHA; j++) {
      for (k = 0; k < (ALPHA*ALPHA); k++) {
	    /* C <-> G */
	 if (((i == ntC) && (j == ntG)) || ((j == ntC) && (i == ntG))) {
          sc->stack[k][i][j] = 3;
          sc->pairs[i][j] = 3;
	    /* A <-> U or G <-> U */
	 } else if (((i == ntA) && (j == ntU)) || ((j == ntA) && (i == ntU)) 
	    || ((i == ntG) && (j == ntU)) || ((j == ntG) && (i == ntU))) { 
          sc->stack[k][i][j] = 2;
          sc->pairs[i][j] = 2;
	} else { 
          sc->stack[k][i][j] = 0;
          sc->pairs[i][j] = 0;
	}
      }
    }
    sc->singles[i] = 0;
    sc->loopcomp[i] = 0;
    sc->hpcomp[i] = 0;
    sc->bulgecomp[i] = 0;
  }

  for (i = 0; i < MAXLOOP; i++) {
    sc->loop[i] = 0;
    sc->hairpin[i] = 0;
    sc->bulge[i] = 0;
  }
}
/* fUNCTIon: SetUpFlatMx
 * Date:     RDD, Thu Nov 15 17:55:39 2001 [St. Louis]
 *
 * Purpose:  Set known scores/probs for
 *		testing the FillMx and traceback
 *
 * Returns:  void
 */
void
SetUpFlatMx(PROBMOD *sc, int grammar)
{
  int i, j, k;
  float temp;

  for (j = 0; j < NDPS; j++) {
     k = 0;
     for (i=0; i < NTRANS; i++) {
	if (Rules[grammar][j][i]) k++; 
     }
     if (k != 0) temp = 1.0 / (float)k; 
     else temp = 0;
     for (i=0; i < NTRANS; i++) {
	if (Rules[grammar][j][i]) sc->transitions[i] = temp;
     }
  }

  for (i = 0; i < ALPHA; i++) {
    for (j = 0; j < ALPHA; j++) {
      for (k = 0; k < (ALPHA*ALPHA); k++) {
        sc->stack[k][i][j] = .0625;
  	sc->pairs[i][j] = .0625;
      }
    }
    sc->singles[i] = 0.25;
    sc->loopcomp[i] = 0.25;
    sc->hpcomp[i] = 0.25;
    sc->bulgecomp[i] = 0.25;
  }

  temp = .033333333; /* 1/31 */
  for (i = 0; i < MAXLOOP; i++) {
    sc->loop[i] = temp;
    sc->hairpin[i] = temp;
    sc->bulge[i] = temp;
  }
}

/****************** Stack for generating from grammars ******************/

struct gstack_s *
InitGstack(void)
{
   struct gstack_s *stack;

   if ((stack = (struct gstack_s *) malloc (sizeof(struct gstack_s))) == NULL)
      Die("Memory allocation failure at %s line %d", __FILE__, __LINE__);
   stack->nxt = NULL;
   stack->node = NULL;

   return stack;
}

void
FreeGstack(struct gstack_s *stack)
{
   while (PopGstack(stack) != NULL);
   free(stack);
}

struct gnode_s *
NewNode(int csymbol, char ssymbol, int nonterm)
{
   struct gnode_s *new;

   if ((new = (struct gnode_s *)malloc(sizeof(struct gnode_s))) == NULL)
      Die("Memory Allocation Error on Node at %s line %d", __FILE__, __LINE__);

   new->nonterminal = nonterm;
   new->esymbol = csymbol;
   new->ess = ssymbol;

   return new;
}

void
PushGstack(struct gstack_s *stack, GNODE *newnode)
{
   struct gstack_s *new;

   if ((new = (struct gstack_s *) malloc (sizeof(struct gstack_s))) == NULL)
      Die("Memory allocation failure at %s line %d", __FILE__, __LINE__);
   new->nxt = stack->nxt;
   new->node = newnode;

   stack->nxt = new;
}

struct gnode_s *
PopGstack(struct gstack_s *stack)
{
   struct gnode_s *node;
   struct gstack_s *old;

   if (stack->nxt == NULL)
      return NULL;

   old = stack->nxt;
   stack->nxt = old->nxt;

   node = old->node;
   free(old);

   return node;
}

