/* cfgio.c
 * I/O of models to/from disk files
 * RDD, Wed Oct 17 17:03:10 CDT 2001
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "squid.h"
#include "cfg.h"

/* The magic number is "nus1" + 0x80808080 */
static int v10magic     = 0xeef5f3b1;
static int v10swap 	= 0xb1f3f5ee;
/* The magic number is "nus3" + 0x80808080 */
static int v11magic     = 0xeef5f3b3;
static int v11swap 	= 0xb3f3f5ee;

/* Function: byteswap()
 * from HMMer's hmmio.c -- SRE, Sun Feb 12 10:26:22 1995              
 * 
 * Purpose:  (from hmmio.c)
 * 	Swap between big-endian and little-endian.
 *           For example:
 *               int foo = 0x12345678;
 *               byteswap((char *) &foo, sizeof(int));
 *               printf("%x\n", foo)
 *           gives 78563412.
 *           
 *       I don't fully understand byte-swapping issues.
 *       However, I have tested this on chars through floats,
 *       on various machines:
 *               SGI IRIX 4.0.5, SunOS 4.1.3, DEC Alpha OSF/1, Alliant
 *               
 *       Note: this is only a partial solution to the problem of
 *           binary file portability. 32 bit integers are assumed by HMMER,
 *           for instance. This should be true for all UNIX, VAX, and WinNT
 *           platforms, I believe.     
 *
 */
static void
byteswap(char *swap, int nbytes)
{
  int  x;
  char byte;
  
  for (x = 0; x < nbytes / 2; x++)
    {
      byte = swap[nbytes - x - 1];
      swap[nbytes - x - 1] = swap[x];
      swap[x] = byte;
    }
}

/* Function: SaveSCFG()
 * Date:     RDD, Wed Oct 31 10:41:20 2001 [St. Louis]
 * 
 * Purpose:  Write an SCFG to disk in binary format.
 *           Return 1 on success, 0 on failure
 *
 * Args:
 * 	ofp	-- to where to write the file
 * 	ret_cfg -- the model which should be written
 *
 * Return:   
 *      1 on success, 0 on failure
 */
int
SaveSCFG(FILE *ofp, MODEL *cfg)
{
  int i,j, k, bd;

  if (fwrite(&v10magic, sizeof(int), 1, ofp) < 1) return 0;
  if (fwrite(&(cfg->grammar), sizeof(int), 1, ofp) < 1) return 0;
  if (fwrite(&(cfg->probabilistic), sizeof(int), 1, ofp) < 1) return 0;

  bd = PAIRS;
  for (i = 0; i < bd; i++) {
    for (j = 0; j < ALPHA; j++) {
      if (fwrite(&(cfg->probs.stack[i][j]), sizeof(double), ALPHA, ofp) < ALPHA) return 0;
    }
  }
  for (i = 0; i < ALPHA; i++) {
    if (fwrite(&(cfg->probs.pairs[i]), sizeof(double), ALPHA, ofp) < ALPHA) return 0;
  }
  if (fwrite(&(cfg->probs.singles[0]), sizeof(double), ALPHA, ofp) < ALPHA) return 0;
  if (fwrite(&(cfg->probs.loopcomp[0]), sizeof(double), ALPHA, ofp) < ALPHA) return 0;
  if (fwrite(&(cfg->probs.loop[0]), sizeof(double), (MAXLOOP), ofp) < (MAXLOOP)) return 0;
  if (fwrite(&(cfg->probs.hpcomp[0]), sizeof(double), ALPHA, ofp) < ALPHA) return 0;
  if (fwrite(&(cfg->probs.hairpin[0]), sizeof(double), (MAXLOOP), ofp) < (MAXLOOP)) return 0;
  if (fwrite(&(cfg->probs.bulgecomp[0]), sizeof(double), ALPHA, ofp) < ALPHA) return 0;
  if (fwrite(&(cfg->probs.bulge[0]), sizeof(double), (MAXLOOP), ofp) < (MAXLOOP)) return 0;
  if (fwrite(&(cfg->probs.transitions[0]), sizeof(double), NTRANS , ofp) < NTRANS) return 0;

  for (i = 0; i < bd; i++) {
    for (j = 0; j < ALPHA; j++) {
      if (fwrite(&(cfg->scores.stack[i][j]), sizeof(int), ALPHA, ofp) < ALPHA) return 0;
    }
  }
  for (i = 0; i < ALPHA; i++) {
    if (fwrite(&(cfg->scores.pairs[i]), sizeof(int), ALPHA, ofp) < ALPHA) return 0;
  }
  if (fwrite(&(cfg->scores.singles[0]), sizeof(int), ALPHA, ofp) < ALPHA) return 0;
  if (fwrite(&(cfg->scores.loopcomp[0]), sizeof(int), ALPHA, ofp) < ALPHA) return 0;
  if (fwrite(&(cfg->scores.loop[0]), sizeof(int), (MAXLOOP), ofp) < (MAXLOOP)) return 0;
  if (fwrite(&(cfg->scores.hpcomp[0]), sizeof(int), ALPHA, ofp) < ALPHA) return 0;
  if (fwrite(&(cfg->scores.hairpin[0]), sizeof(int), (MAXLOOP), ofp) < (MAXLOOP)) return 0;
  if (fwrite(&(cfg->scores.bulgecomp[0]), sizeof(int), ALPHA, ofp) < ALPHA) return 0;
  if (fwrite(&(cfg->scores.bulge[0]), sizeof(int), (MAXLOOP), ofp) < (MAXLOOP)) return 0;
  if (fwrite(&(cfg->scores.transitions[0]), sizeof(int), NTRANS , ofp) < NTRANS) return 0;
  return 1;
}

/* Function: ReadSCFG()
 * Date:     RDD, Wed Oct 31 10:41:20 2001 [St. Louis]
 * 
 * Purpose:  Read an SCFG from disk in binary format.
 *           
 * Args:
 * 	ofp	-- from where to read the file
 * 	ret_cfg -- space in which to store read model (allocated elsewhere)
 *
 * Return:   
 *      1 on success, 0 on failure
 */
int 
ReadSCFG(FILE *ofp, MODEL *ret_cfg)
{
  int i,j,k,l, bd;
  int magic, grammarcheck;
  int do_byteswap = 0;

  bd = PAIRS;
  if (fread(&magic, sizeof(int), 1, ofp) < 1)
    { Warn("Failed to read magic number from SCFG save file"); return 0; }
  if (magic == v10swap) {
    do_byteswap = 1;
    byteswap((char *)&magic, sizeof(int));
  } 
  if (magic == v10magic)
    {
      if (fread(&(ret_cfg->grammar), sizeof(int), 1, ofp) < 1)
	  { Warn("fread failed on SCFG save file: grammar"); return 0; }
      if (fread(&(ret_cfg->probabilistic), sizeof(int), 1, ofp) < 1)
	  { Warn("fread failed on SCFG save file: probabilistic"); return 0; }
      for (i = 0; i < bd; i++) {
        for (j = 0; j < ALPHA; j++) {
          if (fread(&(ret_cfg->probs.stack[i][j]), sizeof(double), ALPHA, ofp) < ALPHA) {
	    Warn("fread failed on SCFG save file: stack %d", j); return 0; 
	  }
	}
      }
      for (i = 0; i < ALPHA; i++) {
	if (fread(&(ret_cfg->probs.pairs[i]), sizeof(double), ALPHA, ofp) < ALPHA)
	  { Warn("fread failed on SCFG save file: pairs"); return 0; }
      }
      if (fread(&(ret_cfg->probs.singles[0]), sizeof(double), ALPHA, ofp) < ALPHA)
	  { Warn("fread failed on SCFG save file: singles"); return 0; }
      if (fread(&(ret_cfg->probs.loopcomp[0]), sizeof(double), ALPHA, ofp) < ALPHA)
	  { Warn("fread failed on SCFG save file: loop composition "); return 0; }
      if (fread(&(ret_cfg->probs.loop[0]), sizeof(double), (MAXLOOP), ofp) < (MAXLOOP))
	  { Warn("fread failed on SCFG save file: loop len"); return 0; }
      if (fread(&(ret_cfg->probs.hpcomp[0]), sizeof(double), ALPHA, ofp) < ALPHA)
	  { Warn("fread failed on SCFG save file: hairpin composition "); return 0; }
      if (fread(&(ret_cfg->probs.hairpin[0]), sizeof(double), (MAXLOOP), ofp) < (MAXLOOP))
	  { Warn("fread failed on SCFG save file: hairpin len"); return 0; }
      if (fread(&(ret_cfg->probs.bulgecomp[0]), sizeof(double), ALPHA, ofp) < ALPHA)
	  { Warn("fread failed on SCFG save file: bulge composition "); return 0; }
      if (fread(&(ret_cfg->probs.bulge[0]), sizeof(double), (MAXLOOP), ofp) < (MAXLOOP))
	  { Warn("fread failed on SCFG save file: bulge len"); return 0; }
      if (fread(&(ret_cfg->probs.transitions[0]), sizeof(double), NTRANS, ofp) < NTRANS)
	  { Warn("fread failed on SCFG save file: transitions"); return 0; }
      for (i = 0; i < bd; i++) {
        for (j = 0; j < ALPHA; j++) {
          if (fread(&(ret_cfg->scores.stack[i][j]), sizeof(int), ALPHA, ofp) < ALPHA) {
	  Warn("fread failed on SCFG save file: stack scores"); return 0; 
	  }
	}
      }
      for (i = 0; i < ALPHA; i++) {
	if (fread(&(ret_cfg->scores.pairs[i]), sizeof(int), ALPHA, ofp) < ALPHA)
	  { Warn("fread failed on SCFG save file: pairs score"); return 0; }
      }
      if (fread(&(ret_cfg->scores.singles[0]), sizeof(int), ALPHA, ofp) < ALPHA)
	  { Warn("fread failed on SCFG save file: singles score"); return 0; }
      if (fread(&(ret_cfg->scores.loopcomp[0]), sizeof(int), ALPHA, ofp) < ALPHA)
	  { Warn("fread failed on SCFG save file: loop comp score"); return 0; }
      if (fread(&(ret_cfg->scores.loop[0]), sizeof(int), (MAXLOOP), ofp) < (MAXLOOP))
	  { Warn("fread failed on SCFG save file: loop leng"); return 0; }
      if (fread(&(ret_cfg->scores.hpcomp[0]), sizeof(int), ALPHA, ofp) < ALPHA)
	  { Warn("fread failed on SCFG save file: hairpin comp score"); return 0; }
      if (fread(&(ret_cfg->scores.hairpin[0]), sizeof(int), (MAXLOOP), ofp) < (MAXLOOP))
	  { Warn("fread failed on SCFG save file: hairpin leng"); return 0; }
      if (fread(&(ret_cfg->scores.bulgecomp[0]), sizeof(int), ALPHA, ofp) < ALPHA)
	  { Warn("fread failed on SCFG save file: bulge comp score"); return 0; }
      if (fread(&(ret_cfg->scores.bulge[0]), sizeof(int), (MAXLOOP), ofp) < (MAXLOOP))
	  { Warn("fread failed on SCFG save file: bulge leng"); return 0; }
      if (fread(&(ret_cfg->scores.transitions[0]), sizeof(int), NTRANS, ofp) < NTRANS)
	  { Warn("fread failed on SCFG save file: transitions score"); return 0; }

      if (do_byteswap) {
        byteswap((char*)&(ret_cfg->grammar), sizeof(int));
        byteswap((char*)&(ret_cfg->probabilistic), sizeof(int));
        for (i = 0; i < ALPHA; i++) {
          for (j = 0; j < ALPHA; j++) {
            byteswap((char*)&(ret_cfg->probs.pairs[i][j]), sizeof(double));
            byteswap((char*)&(ret_cfg->scores.pairs[i][j]), sizeof(int));
	    for (k = 0; k < ALPHA; k++) {
	      for (l = 0; l < ALPHA; l++) {
	        byteswap((char*)&(ret_cfg->probs.stack[(4*k+l)][i][j]), sizeof(double));
	        byteswap((char*)&(ret_cfg->scores.stack[(4*k+l)][i][j]), sizeof(int));
	      }
            }
            byteswap((char*)&(ret_cfg->probs.singles[i]), sizeof(double));
            byteswap((char*)&(ret_cfg->scores.singles[i]), sizeof(int));
            byteswap((char*)&(ret_cfg->probs.loopcomp[i]), sizeof(double));
            byteswap((char*)&(ret_cfg->scores.loopcomp[i]), sizeof(int));
            byteswap((char*)&(ret_cfg->probs.hpcomp[i]), sizeof(double));
            byteswap((char*)&(ret_cfg->scores.hpcomp[i]), sizeof(int));
            byteswap((char*)&(ret_cfg->probs.bulgecomp[i]), sizeof(double));
            byteswap((char*)&(ret_cfg->scores.bulgecomp[i]), sizeof(int));
	  }
        }
        for (i = 0; i < NTRANS; i++) {
          byteswap((char*)&(ret_cfg->probs.transitions[i]), sizeof(double));
          byteswap((char*)&(ret_cfg->scores.transitions[i]), sizeof(int));
        }
	for (i = 0; i < MAXLOOP; i++) {
          byteswap((char*)&(ret_cfg->probs.loop[i]), sizeof(double));
          byteswap((char*)&(ret_cfg->scores.loop[i]), sizeof(int));
          byteswap((char*)&(ret_cfg->probs.hairpin[i]), sizeof(double));
          byteswap((char*)&(ret_cfg->scores.hairpin[i]), sizeof(int));
          byteswap((char*)&(ret_cfg->probs.bulge[i]), sizeof(double));
          byteswap((char*)&(ret_cfg->scores.bulge[i]), sizeof(int));
	}
      }
    }
  else 
    { Warn("bad magic on that SCFG save file"); return 0; }
  return 1;
}

/* Function: CheckModel
 * Date:     RDD, Wed Oct 31 10:41:20 2001 [St. Louis]
 *
 * Purpose:  verify that the loaded model is sane
 *
 * Args:     
 * 	prmodel		The probability paramters
 * 	grammar		The grammar to verify
 *
 * Returns:  
 *      1 on success, 0 on failure
 */
int
CheckModel (PROBMOD *prmodel, int grammar) 
{
  int i, j, k, l;
  double singles, loopcomp, hpcomp, bulcomp;
  double pairs;
  double triloops;
  double tetraloops, stack;
  double looplen, hplen, bullen;
  double transitions;

  float precision = 0.0001;

  /* Emission check */
  singles = 0.; loopcomp = 0.; hpcomp = 0.; bulcomp = 0.;
  pairs = 0.; triloops = 0.; tetraloops = 0.; stack = 0.;
  looplen = 0.; hplen = 0.; bullen = 0.; 

  /* Sum parameters of each type */
  for (i=0; i< ALPHA; i++) {
    singles += prmodel->singles[i];
    loopcomp += prmodel->loopcomp[i];
    hpcomp += prmodel->hpcomp[i];
    bulcomp += prmodel->bulgecomp[i];
    for (j=0; j< ALPHA; j++) {
      pairs += prmodel->pairs[i][j];
      for (k=0; k< ALPHA; k++) {
        for (l=0; l< ALPHA; l++) {
          stack += prmodel->stack[(4*k+l)][i][j];
	} 
      }
    }
  }
  /* Check sums against one */
  if (fabs(singles-1) > precision) {
    printf("Singles sum to %6.4f\n", singles);
    return (FALSE);
  }
  if (fabs(pairs -1) > precision) {
    printf("Pairs sum to %6.4f\n", pairs);
    return (FALSE);
  } 

  /* Stacking sums to 16 because there are 16
   * possible stacking states because of lexicalization */
  if (grFAMILY[grammar] != NUN) {
    if (fabs(stack -16) > precision) {
      printf("Stacking sum to %6.4f (should be 16).\n", stack);
      return (FALSE);
    } 
  }

  if (grFAMILY[grammar] == ZKG) {
    if (fabs(loopcomp-1) > precision) {
      printf("Loop Comp sum to %6.4f\n", loopcomp);
      return (FALSE);
    }
    if (fabs(hpcomp-1) > precision) {
      printf("Hairpin Comp sum to %6.4f\n", hpcomp);
      return (FALSE);
    }
    if (fabs(bulcomp-1) > precision) {
      printf("Bulge Comp sum to %6.4f\n", bulcomp);
      return (FALSE);
    }
  }

  /* Transition check */
  for (j = 0; j < NDPS; j++) {
    transitions = 0.0;
    for (i = 0; i < NTRANS; i++) {
      if (Rules[grammar][j][i]) {
        transitions += prmodel->transitions[i];
      }
    }
    if (transitions > 0.0) {
      if (fabs(transitions - 1.0) > precision) {
        printf("Transitions from %s sum to %6.4f\n", dpNAME[j], transitions);
        return (FALSE);
      }
    }
  }

  /* Loop length check * */
  if (grFAMILY[grammar] == ZKG) {
    looplen = 0.0; hplen = 0.0; bullen = 0.0;
    for (i = 1; i < MAXLOOP; i++) {
      looplen += prmodel->loop[i];
      hplen += prmodel->hairpin[i];
      bullen += prmodel->bulge[i];
    }
    if (fabs(looplen-1) > precision) {
      printf("Loop Lengths sum to %6.4f\n", looplen);
      return (FALSE);
    }
    if (fabs(hplen-1) > precision) {
      printf("Hairpin Lengths sum to %6.4f\n", hplen);
      return (FALSE);
    }
    if (fabs(bullen-1) > precision) {
      printf("Bulge Lengths sum to %6.4f\n", bullen);
      return (FALSE);
    }
  }
  return (TRUE);
}

/* Function: SaveAscii 
 * Date:     RDD, Sun Mar 10 12:21:44 CST 2002
 *
 * Purpose:  Save an ascii parameters file (with comments)
 *
 * Args: 
 *      ofp		Location from where to read  
 * 	model		The paramters as ints
 *
 */
void
SaveAscii(FILE *ofp, INTMOD *cfg)
{
  int i, j, k;

  fprintf(ofp, "# Transitions #\n");
  for (i = 0; i < NTRANS; i++) {
    fprintf(ofp, "%d", cfg->transitions[i]);
    /* Don't want a lagging tab or newline*/
    if (i != (NTRANS-1)) {
      if ((i+1)%6 == 0) fprintf(ofp, "\n");
      else fprintf(ofp, " ");
    }
  }
  fprintf(ofp, "\n# Single nt Emissions #\n");
  fprintf(ofp, "%d %d %d %d\n", cfg->singles[ntA], cfg->singles[ntC],
		  	cfg->singles[ntG], cfg->singles[ntU]);
  fprintf(ofp, "# Paired nt Emissions #\n");
  for (i = 0; i < ALPHA; i++) {
    fprintf(ofp, "%d %d %d %d\n", cfg->pairs[i][ntA], cfg->pairs[i][ntC],
		  	cfg->pairs[i][ntG], cfg->pairs[i][ntU]);
  }
  fprintf(ofp, "# Stacked nt Emissions #\n");
  for (i=0; i < ALPHA; i++) {
    for (j=0; j < ALPHA; j++) {
      fprintf(ofp, "# stack[%s%s] #\n", baseNAME[i], baseNAME[j]);
      for (k = 0; k < ALPHA; k++) {
        fprintf(ofp, "%d %d %d %d\n", cfg->stack[idx(i,j)][k][ntA], 
		cfg->stack[idx(i,j)][k][ntC], cfg->stack[idx(i,j)][k][ntG], 
		cfg->stack[idx(i,j)][k][ntU]);
      } /* for inner pair */
    } /* half of outter pair */
  } /* for outter pairs */

  fprintf(ofp, "# Loop Length Emissions #\n");
  for (i = 0; i < MAXLOOP; i++) {
    fprintf(ofp, "%d", cfg->loop[i]);
    if ((i+1)%8 == 0) {
      fprintf(ofp, "\n");
    } else if (i != MAXLOOP-1) {
      fprintf(ofp, " ");
    }
  }
  fprintf(ofp, "\n# Loop nt Emissions #\n");
  fprintf(ofp, "%d %d %d %d\n", cfg->loopcomp[ntA], cfg->loopcomp[ntC],
		  	cfg->loopcomp[ntG], cfg->loopcomp[ntU]);

  fprintf(ofp, "# Hairpin Length Emissions #\n");
  for (i = 0; i < MAXLOOP; i++) {
    fprintf(ofp, "%d", cfg->hairpin[i]);
    if ((i+1)%8 == 0) {
      fprintf(ofp, "\n");
    } else if (i != MAXLOOP-1) {
      fprintf(ofp, " ");
    }
  }
  fprintf(ofp, "\n# Hairpin nt Emissions #\n");
  fprintf(ofp, "%d %d %d %d\n", cfg->hpcomp[ntA], cfg->hpcomp[ntC],
		  	cfg->hpcomp[ntG], cfg->hpcomp[ntU]);

  fprintf(ofp, "# Bulge Length Emissions #\n");
  for (i = 0; i < MAXLOOP; i++) {
    fprintf(ofp, "%d", cfg->bulge[i]);
    if ((i+1)%8 == 0) {
      fprintf(ofp, "\n");
    } else if (i != MAXLOOP-1) {
      fprintf(ofp, " ");
    }
  }
  fprintf(ofp, "\n# Bulge nt Emissions #\n");
  fprintf(ofp, "%d %d %d %d\n", cfg->bulgecomp[ntA], cfg->bulgecomp[ntC],
		  	cfg->bulgecomp[ntG], cfg->bulgecomp[ntU]);

}

/* Function: ReadAscii 
 * Date:     RDD, Sun Mar 10 12:21:44 CST 2002
 *
 * Purpose:  Save an ascii parameters file (with comments)
 *
 * Args: 
 *      ofp		Location to save info
 * 	model		The paramters as ints (allocated elsewhere)
 *
 */
void
ReadAscii(FILE *ofp, INTMOD *cfg)
{
  int i, j, k, l, tmp;
  char *buf;
  char *s;
  char *tok;
  int n, index;
  int singles, pairs, stacks;
  int loops, loopcomp, hairpin, hpcomp, bulge, bulgecomp;
  int tetras, tris;
  int debug, commentline;

  debug = FALSE;

  /* Set boundary conditions */
  singles = NTRANS + ALPHA;
  pairs = singles + PAIRS;
  stacks = pairs + QUADS;
  loops = stacks + MAXLOOP;
  loopcomp = loops + ALPHA;
  hairpin = loopcomp + MAXLOOP;
  hpcomp = hairpin + ALPHA;
  bulge = hpcomp + MAXLOOP;
  bulgecomp = bulge + ALPHA;
  tetras = bulgecomp + QUADS;
  tris = tetras + TRIPLETS;

  buf = NULL; n = 0;  index = 0;
  while (sre_fgets(&buf, &n, ofp) != NULL) {
    /* If buffer line begins with '#' this is a comment line */
    commentline = FALSE;
    s = buf;
    /* First NTRANS lines are transition probabilities */
    while ((tok = sre_strtok(&s, " ", NULL)) != NULL) {
      if (strcmp(tok, "#") == 0) {
        /* This line is a comment, ignore */
        commentline = TRUE;
      } else if (commentline == FALSE) {
	/* This line isn't a comment, parse in the tokens */
	if (index < NTRANS) {
	  cfg->transitions[index] = atoi(tok);
	  if (debug) printf("transition[%d] is %d\n", index, 
			  	cfg->transitions[index]);
	} else if (index < singles) {
	  i = index - NTRANS;
	  cfg->singles[i] = atoi(tok);
	  if (debug) printf("single[%s] is %d\n", baseNAME[i], 
			  cfg->singles[i]);
	} else if (index < pairs) {
	  tmp = index - singles;
	  if (tmp == 0) i = 0;
	  j = tmp - (i*ALPHA);
	  cfg->pairs[i][j] = atoi(tok);
	  if (debug) printf("pairs[%s][%s] is %d\n", baseNAME[i],
			  	baseNAME[j], cfg->pairs[i][j]);
	  /* Throws off indexing if we don't return to normal */
	  if ((tmp+1)%ALPHA == 0) i++;
	} else if (index < stacks) {
	  tmp = index - pairs;
	  if (tmp == 0) { i = 0; j = 0; k = 0; }  /* initialize */
	  k = tmp - ((i*16) + (j*ALPHA));	/* 0 < k < 4 */
	  cfg->stack[i][j][k] = atoi(tok);
	  if (debug) printf("stack[%d][%s][%s] is %d\n", i,
			  baseNAME[j], baseNAME[k], cfg->stack[i][j][k]);
	  if (((tmp+1) - (i*PAIRS))%ALPHA == 0) j++;	/* if k = 3, ++j */
	  if ((tmp+1)%16 == 0) { i++; j = 0; k = 0;}	/* if j = 3, ++k */
	} else if (index < loops) {
	  i = index - stacks;
	  cfg->loop[i] = atoi(tok);
	  if (debug) printf("loop[%d] is %d\n", i, cfg->loop[i]);
	} else if (index < loopcomp) {
	  i = index - loops;
	  cfg->loopcomp[i] = atoi(tok);
	  if (debug) printf("loopcomp[%s] is %d\n", baseNAME[i], 
			  cfg->loopcomp[i]);
	} else if (index < hairpin) {
	  i = index - loopcomp;
	  cfg->hairpin[i] = atoi(tok);
	  if (debug) printf("hairpin[%d] is %d\n", i, cfg->hairpin[i]);
	} else if (index < hpcomp) {
	  i = index - hairpin;
	  if (i < ALPHA) {
	    cfg->hpcomp[i] = atoi(tok);
	    if (debug) printf("hpcomp[%s] is %d\n", baseNAME[i], 
			    cfg->hpcomp[i]);
	  }
	} else if (index < bulge) {
	  i = index - hpcomp;
	  cfg->bulge[i] = atoi(tok);
	  if (debug) printf("bulge[%d] is %d\n", i, cfg->bulge[i]);
	} else if (index < bulgecomp) {
	  i = index - bulge;
	  if (i < ALPHA) {
	    cfg->bulgecomp[i] = atoi(tok);
	    if (debug) printf("bulgecomp[%s] is %d\n", baseNAME[i], 
			    cfg->bulgecomp[i]);
	  }
	}
	index++;
      }
    }
  }
}
