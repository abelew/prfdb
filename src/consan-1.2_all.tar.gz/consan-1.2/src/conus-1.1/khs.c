/* khs.c 
 * derived from Yarn's rnaoutput.c
 *   derived from COVE's konings.c
 *   SRE, Sun Aug 28 10:39:18 1994
 * modified for CONUS, RDD Tue Oct  2 14:56:30 CDT 2001
 * Representation of secondary structure and secondary structural 
 * alignments using a variant of Danielle Konings' string notation.
 * See: Konings and Hogeweg, J. Mol. Biol. 207:597-614 1989
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "squid.h"
#include "cfg.h"
#include "trace.h"

#ifdef MEMDEBUG
#include "dbmalloc.h"
#endif

/* khs.c */
void Trace2KHS (struct trace_s *tr, char *seq, int rlen, int watsoncrick, int grammar, char **ret_ss);
void trace2khs(struct trace_s *tr, char *seq, int rlen, int watsoncrick, char **ret_ss);
void PrintKHS(FILE *fp, char *rseq, SQINFO *sqinfo, char *ss);
int KHS2ct(char *ss, int len, int allow_pseudoknots, int **ret_ct);
int VerifyKHS(char *name, char *ss, int wordy);

/* Function: Trace2KHS()
 *  
 * Purpose:  From a traceback tree of seq, produce a
 * 		secondary structure string. ">" and "<" are
 *              used for pairwise emissions; "." for single-stranded stuff.
 *      	Note that structure is defined by pairwise emissions,
 *       	not by Watson-Crick-isms and stacking rules.
 *        
 * Note: This function switches between versions which differ based on
 * differing assumptions made by the grammars.
 * 
 * Args:     tr          - traceback structure
 * 	     seq         - sequence, 0..rlen-1
 *           rlen        - length of seq and returned ss string
 *           watsoncrick - TRUE to annotate canonical pairs only
 *           grammar     - current gramamr in usage
 *           ret_ss      - RETURN: alloc'ed secondary structure string
 *           
 * Return:   ret_ss contains a string 0..rlen-1 containing the
 *           secondary structure. Must be free'd by caller.
 */
void
Trace2KHS (struct trace_s *tr, char *seq, int rlen, int watsoncrick,
		          int grammar, char **ret_ss)
{
  if (grFAMILY[grammar] == ZKG) {
    trace2khsRZK(tr, seq, rlen, ret_ss);
  } else {
    trace2khs(tr, seq, rlen, watsoncrick, ret_ss);
  }
}

/* Function: trace2khs()
 * 
 * Purpose:  From a traceback tree of seq, produce a
 *           secondary structure string. ">" and "<" are
 *           used for pairwise emissions; "." for single-stranded stuff.
 *           Note that structure is defined by pairwise emissions,
 *           not by Watson-Crick-isms and stacking rules.
 *           
 * Args:     tr          - traceback structure
 *           seq         - sequence, 0..rlen-1
 *           rlen        - length of seq and returned ss string
 *           watsoncrick - TRUE to annotate canonical pairs only
 *           ret_ss      - RETURN: alloc'ed secondary structure string
 *
 * Return:   ret_ss contains a string 0..rlen-1 containing the
 *           secondary structure. Must be free'd by caller.
 */
void
trace2khs(struct trace_s *tr, char *seq, int rlen, int watsoncrick, 
          char **ret_ss)  
{
  struct tracestack_s *dolist;
  struct trace_s      *curr;
  char                *ss;

  if ((ss = (char *) malloc (sizeof(char) * rlen+1)) == NULL)
    Die("malloc failed");
  memset(ss, '.', rlen);
  ss[rlen] = '\0';

  dolist = (struct tracestack_s *)InitTracestack();
  PushTracestack(dolist, tr->nxtl);

  while ((curr = PopTracestack(dolist)) != NULL) { 
    if ((curr->emitl != -1) && (curr->emitr != -1)) {
/*      if (! watsoncrick  ||
	      isRNAComplement(seq[curr->emitl], seq[curr->emitr], 1)) {
	      */
        ss[curr->emitl] = '>';
        ss[curr->emitr] = '<';
    }

    if (curr->nxtr) PushTracestack(dolist, curr->nxtr);
    if (curr->nxtl) PushTracestack(dolist, curr->nxtl);
  }
  FreeTracestack(dolist);
  *ret_ss = ss;
}

/* Function: PrintKHS()
 * 
 * Purpose:  Print a sequence/structure representation.
 * 
 * Args:     fp     - open file pointer to write to
 *           rseq   - sequence, 0..len-1
 *           sqinfo - info about rseq, including name and length
 *           ss     - secondary structure of rseq to show.
 *                    May or may not be the same as the ss in sqinfo.
 *                    
 * Return:  void.                   
 */
void   
PrintKHS(FILE *fp, char *rseq, SQINFO *sqinfo, char *ss)
{
  char seqbuf[51];
  char strucbuf[51];
  int  nchar;
  int  pos;

  fprintf(fp, "> %s %s\n",
	  sqinfo->name,
	  (sqinfo->flags & SQINFO_DESC) ? sqinfo->desc : "");

  for (pos = 0; pos < sqinfo->len; pos += 50)
    {
      strncpy(seqbuf,   rseq + pos, 50); seqbuf[50] = '\0';
      strncpy(strucbuf, ss + pos,   50); strucbuf[50] = '\0';
      nchar = strlen(seqbuf);
      
      fprintf(fp, "%4d %s %4d\n", pos+1, seqbuf, pos + nchar);
      fprintf(fp, "     %s\n", strucbuf);
      fputs("\n", fp);
    }
}

/* Function: Infernal2ct()
 *
 * Note: Infernal uses a KHS like format but with the
 * >< symbols reversed to <>.
 * 
 * Purpose:  Convert a secondary structure string to an array of integers
 *           representing what position each position is base-paired 
 *           to (0..len-1), or -1 if none. This is off-by-one from a
 *           Zuker .ct file representation.
 *           
 *           The .ct representation can accomodate pseudoknots but the 
 *           secondary structure string cannot easily; the string contains
 *           "Aa", "Bb", etc. pairs as a limited representation of
 *           pseudoknots. The string contains "><" for base pairs.
 *           Other symbols are ignored. If allow_pseudoknots is FALSE,
 *           the pseudoknot symbols will be ignored and these positions
 *           will be treated as single stranded.
 *           
 * Return:   ret_ct is allocated here and must be free'd by caller.
 *           Returns 1 on success, 0 if ss is somehow inconsistent.
 */
int 
Infernal2ct(char *ss, int len, int allow_pseudoknots, int **ret_ct)
{
  struct intstack_s *dolist[27];
  int *ct;
  int  i;
  int  pos, pair;
  int  status = 1;		/* success or failure return status */

  for (i = 0; i < 27; i++)
    dolist[i] = InitIntStack();

  if ((ct = (int *) malloc (len * sizeof(int))) == NULL)
    Die("malloc failed");
  for (pos = 0; pos < len; pos++)
    ct[pos] = -1;

  for (pos = 0; ss[pos] != '\0'; pos++)
    {
      /* bulletproof against SGI non-ANSI compliant ctype.h */
      if (! sre_isascii(ss[pos])) status = 0;

      else if (ss[pos] == '<')	/* left side of a pair: push onto stack 0 */
	PushIntStack(dolist[0], pos);
      else if (ss[pos] == '>')	/* right side of a pair; resolve pair */
	{
	  if (! PopIntStack(dolist[0], &pair))
	    { status = 0; }
	  else
	    {
	      ct[pos]  = pair;
	      ct[pair] = pos;
	    }
	}
				/* same stuff for pseudoknots */
      else if (allow_pseudoknots && isupper((int) ss[pos]))
	PushIntStack(dolist[ss[pos] - 'A' + 1], pos);
      else if (allow_pseudoknots && islower((int) ss[pos]))
	{
	  if (! PopIntStack(dolist[ss[pos] - 'a' + 1], &pair))
	    { status = 0; }
	  else
	    {
	      ct[pos]  = pair;
	      ct[pair] = pos;
	    }
	}
      else if (allow_pseudoknots && !isgap(ss[pos])) status = 0; /* bad character */
    }

  for (i = 0; i < 27; i++)
    if ( FreeIntStack(dolist[i]) > 0)
      status = 0;

  *ret_ct = ct;
  return status;
}

/* Function: KHS2ct()
 * 
 * Purpose:  Convert a secondary structure string to an array of integers
 *           representing what position each position is base-paired 
 *           to (0..len-1), or -1 if none. This is off-by-one from a
 *           Zuker .ct file representation.
 *           
 *           The .ct representation can accomodate pseudoknots but the 
 *           secondary structure string cannot easily; the string contains
 *           "Aa", "Bb", etc. pairs as a limited representation of
 *           pseudoknots. The string contains "><" for base pairs.
 *           Other symbols are ignored. If allow_pseudoknots is FALSE,
 *           the pseudoknot symbols will be ignored and these positions
 *           will be treated as single stranded.
 *           
 * Return:   ret_ct is allocated here and must be free'd by caller.
 *           Returns 1 on success, 0 if ss is somehow inconsistent.
 */
int 
KHS2ct(char *ss, int len, int allow_pseudoknots, int **ret_ct)
{
  struct intstack_s *dolist[27];
  int *ct;
  int  i;
  int  pos, pair;
  int  status = 1;		/* success or failure return status */

  for (i = 0; i < 27; i++)
    dolist[i] = InitIntStack();

  if ((ct = (int *) malloc (len * sizeof(int))) == NULL)
    Die("malloc failed");
  for (pos = 0; pos < len; pos++)
    ct[pos] = -1;

  for (pos = 0; ss[pos] != '\0'; pos++)
    {
      /* bulletproof against SGI non-ANSI compliant ctype.h */
      if (! sre_isascii(ss[pos])) status = 0;

      else if (ss[pos] == '>')	/* left side of a pair: push onto stack 0 */
	PushIntStack(dolist[0], pos);
      else if (ss[pos] == '<')	/* right side of a pair; resolve pair */
	{
	  if (! PopIntStack(dolist[0], &pair))
	    { status = 0; }
	  else
	    {
	      ct[pos]  = pair;
	      ct[pair] = pos;
	    }
	}
				/* same stuff for pseudoknots */
      else if (allow_pseudoknots && isupper((int) ss[pos]))
	PushIntStack(dolist[ss[pos] - 'A' + 1], pos);
      else if (allow_pseudoknots && islower((int) ss[pos]))
	{
	  if (! PopIntStack(dolist[ss[pos] - 'a' + 1], &pair))
	    { status = 0; }
	  else
	    {
	      ct[pos]  = pair;
	      ct[pair] = pos;
	    }
	}
      else if (allow_pseudoknots && !isgap(ss[pos])) status = 0; /* bad character */
    }

  for (i = 0; i < 27; i++)
    if ( FreeIntStack(dolist[i]) > 0)
      status = 0;

  *ret_ct = ct;
  return status;
}

/* Function: VerifyKHS()
 * 
 * Purpose:  Examine a possibly bad structure string, and print out diagnostics 
 *           about it if wordy is TRUE.
 *
 * Return:   1 if string is OK, 0 if string is bad.
 */
int
VerifyKHS(char *name, char *ss, int wordy)
{
  int symcount[27];             /* 0 is normal pairs. 1-26 for pseudoknots */
  int i;
  int pos;
  int status = 1;

  for (i = 0; i < 27; i++)
    symcount[i] = 0;

  for (pos = 0; ss[pos] != '\0'; pos++)
    {
      if (!sre_isascii(ss[pos]))        /* SGI ctype.h non-ANSI compliant */
        {
          status = 0;
          if (wordy)
            Warn("VerifyKHS: Sequence %s no good; structure has garbage symbol (val %d) at position %d\n",
                 name, (int) ss[pos], pos);
        }
      else if (ss[pos] == '>')
        symcount[0] ++;
      else if (ss[pos] == '<')
        symcount[0] --;
      else if (isupper((int) ss[pos]))
        symcount[ss[pos] - 'A' + 1] ++; /* pseudoknot-left  */
      else if (islower((int) ss[pos]))
        symcount[ss[pos] - 'a' + 1] --; /* pseudoknot-right */
      else if (!isgap(ss[pos]))
        {
          status = 0;
          if (wordy)
            Warn("VerifyKHS: Sequence %s no good, structure has invalid symbol %c at position %d\n",
                 name, ss[pos], pos);
        }
    }

  if (symcount[0] != 0)
    {
      status = 0;
      if (wordy)
        Warn("VerifyKHS: Sequence %s no good, structure has extra paired bases: %d on %s\n",
             name, abs(symcount[0]),
             (symcount[0] > 0) ? "left" : "right");
    }

  for (i = 1; i <= 26; i++)
    if (symcount[i] != 0)
      {
        status = 0;
        if (wordy)
          Warn("VerifyKHS: Sequence %s no good, structure has extra paired bases for pseudoknot %c: %d on %s\n",
               name, (char) (i + 'A' - 1),
               abs(symcount[i]),
               (symcount[i] > 0) ? "left" : "right");
      }
  return status;
}
