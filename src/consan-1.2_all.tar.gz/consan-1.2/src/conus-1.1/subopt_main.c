/* subopt_main.c 
 *
 * Testing suboptimal algorithms
 *
 * The sum of all states of a particular nucleotide
 * must be 1 (these are probabilities).
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-m <file>     : Use parameters, grammar and scoring specified in model <file> \n\
-g <string>   : Use grammar <string>, defaults to NUS; ignored if model file specified \n\
-s <file>     : save model file to <file> \n\
-o <file>     : redirect output to <file>\n\
-x            : print out parameters of model \n\
-t            : print traceback\n\
-d            : debugging output \n\
-v            : verbose output \n\
-f            : debugging, print fill matrix from cyk \n\
-p            : print real with predicted structure\n\
-q            : print predicted structures in stockholm format \n\
";

static char usage[]  = "Usage: subopt [-options] <seqfile in>\n";

int 
main (int argc, char **argv) 
{
   /**** arguments variables *****/
   int   optid; 
   OPTS settings;

   /* ReadSeq variables */
   SQFILE *sqfp; SQINFO sqinfo;
   int sformat;
   char *rna, *drna; 
   char *ss; 
   int *ctstruct; 
   /* Models info */
   MODEL nusmodel;
   int ***insideMX, ***outsideMX;
   int noerror, score;

   noerror = TRUE;

   if (!(ProcessOpts(&settings, &optid, argc, argv, usage, "\tfor NUS and YRN only", optsline))) {
      printf("%s\n\n", usage);
      exit(0);
   }
   if (argc - optid != 1)
      Die("Incorrect number of command line arguments.\n%s\n%s\n", 
	    usage, optsline);

   SetupModel(&settings, &nusmodel);  
   LogifySCFG(&(nusmodel.probs), &(nusmodel.scores)); 

   if (settings.modelfile == NULL) {
     nusmodel.grammar = settings.grammar;
     SetUpFlatMx(&(nusmodel.probs), settings.grammar);
     LogifySCFG(&(nusmodel.probs), &(nusmodel.scores)); 
   }

   if (settings.debugg) PrintFullModel(settings.ofp, &nusmodel);

   /* Read input file into RNA array and filter for non-RNA residues */
   if ((sqfp = SeqfileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL) 
          Die("Failed to open sequence file %s\n%s\n", argv[optid], usage);

   while (ReadSeq(sqfp, sformat, &rna, &sqinfo)) {
      ToRNA(rna);
      if (settings.verbose) fprintf(settings.ofp, "Sequence %s:\n", sqinfo.name);

      /* noerror = SuboptimalsD(rna, sqinfo.len, nusmodel.grammar, &nusmodel,
	    &settings, 5, FALSE, NULL, NULL, &sqinfo); */
      noerror = Suboptimals(rna, sqinfo.len, nusmodel.grammar, &nusmodel,
	    &settings, 5, FALSE, NULL, NULL, &sqinfo);

      FreeSequence(rna, &sqinfo);
   }
   SeqfileClose(sqfp);
}
