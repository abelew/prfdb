/* nuss_main.c
 * RDD, Tue Aug 21 15:02:15 CDT 2001
 *
 * nuss_main.c
 *  -- given seq, structure, and model, get score
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"


static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-m <file>     : Use parameters, grammar and scoring specified in model <file> \n\
-g <string>   : Use grammar <string> and plus one scoring \n\
   -H	        (with -g) shift to hydrogen bonding scoring  \n\
   --flat       (with -g) flat scoring scheme \n\
-o <file>     : redirect output to <file>\n\
-p	      : score even if violates grammar (careful!)\n\
-v            : verbose output \n\
-x            : print out parameters of model \n\
-d            : debugging output \n\
-t            : debugging, print traceback\n\
-f            : debugging, print fill matrix from cyk \n\
";

static char usage[]  = "Usage: conus_score [-options] <seqfile in>\n";

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  struct opts settings;

  /* ReadSeq variables */
  SQFILE *sqfp; SQINFO sqinfo;
  int sformat;
  char *rna; char *drna;
  char *ss; int *ct;
  int *ctstruct;

  /* Models info */
  MODEL nusmodel;
  struct trace_s *trc;

  /* Unique to scoring program */
  int score;
  int noerror;
  
  if (!(ProcessOpts(&settings, &optid, argc, argv, usage, gramdesc, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  if (argc - optid <  1)
    Die("Incorrect number of command line arguments.\n%s\n%s\n", usage, optsline);
  
  SetupModel(&settings, &nusmodel);
  if (settings.minloop >= 0) HLEN = settings.minloop;
  if (settings.verbose) PrintModel(settings.ofp, &nusmodel);

  if (settings.useprob) {
    LogifySCFG(&(nusmodel.probs), &(nusmodel.scores));
    if (settings.verbose) {
      PrintProbModel(settings.ofp, &(nusmodel.probs), nusmodel.grammar);
      printf("After LOGIFY:\n");
      PrintIntModel(settings.ofp, &(nusmodel.scores), nusmodel.grammar);
    }
  }

  /* Digitize Setup */
  SetAlphabet(hmmNUCLEIC);
  score = 0;

  while (!(argc - optid < 1)) {
    /* Read input file into RNA array and filter for non-RNA residues */
    if ((sqfp = SeqfileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL) 
      Die("Failed to open sequence file %s\n%s\n", argv[optid], usage);

    while (ReadSeq(sqfp, sformat, &rna, &sqinfo)) {
      ToRNA(rna);
      if (settings.verbose) { fprintf(settings.ofp, "%s\n", rna); }

      if (! (sqinfo.flags & SQINFO_SS)) {
	 printf("[ERROR: %s has no structure to score!]\n\n", sqinfo.name);
      } else {

	 /* OK -- we'd like for this thing to check that the 
	  * structure is permissible under the specified grammar
	  * before we off and randomly score through problem areas.
	  * Unforunately, the stacking grammars seem to identify a
	  * ton of crap which is "illegal" so I need to check that.*/
	 if (settings.structout) {
	    noerror = KHS2Trace(rna, sqinfo.ss, sqinfo.len, &trc, 
		  FALSE, settings.grammar);
	 } else {
	    noerror = KHS2Trace(rna, sqinfo.ss, sqinfo.len, &trc, 
		  TRUE, settings.grammar);
	 }
	 if (noerror) {
	    if (settings.traceback) PrintTrace(settings.ofp, trc, rna);

	    /* TraceScore */
	    traceScore(rna, sqinfo.len, trc, &(nusmodel.scores), settings.grammar, &score);

	    fprintf(settings.ofp, "%s (file: %s) scores: %d\n", sqinfo.name, 
		  argv[optid], score);

	    /* Cleanup */
	 } else {
	   printf("[PROBLEM: %s is an illegal structure under %s grammar!]\n\n", 
		 sqinfo.name, grNAME[settings.grammar]);
	 }
	 FreeTrace(trc);
      }
      FreeSequence(rna, &sqinfo);
    }

    SeqfileClose(sqfp);
    optid ++;
    score = 0;
  }
}
