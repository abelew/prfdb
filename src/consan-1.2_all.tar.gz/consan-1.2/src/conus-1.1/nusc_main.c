/* nusc_main.c 
 * RDD, Tue Aug 21 15:02:15 CDT 2001
 *
 * nusc_main.c -- Nussinov comparison algorithm
 * 	-- given seq, structure, and model, get stats on
 *	   how well this prediction was relative to given. 
 *
 * This is currently the older version of compstruct.
 * For the paper Sean changed compstruct so I 
 * NEED to upgrade this to newest compstruct style
 * and options -- we ought to be able to do mathews
 * and avg analysis by switches.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"
#include"stats.h"

/* Note that for conus_compare we've taken over the ctoutput
 * switch (-c) to instead mean that we want tabular output.
 */

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-m <file>     : Use model <file> \n\
-g <string>   : Use grammar <string> and plus one scoring \n\
   -H	        (with -g) shift to hydrogen bonding scoring  \n\
   --flat       (with -g) flat scoring scheme \n\
-M	      : Use the Mathews99 method of evalutation \n\
-c            : output in table format \n\
-a            : give cummulative statistics (global) \n\
-i            : give statistics on each sequence (ignored in table mode)\n\
-p            : output real and predicted structures\n\
-q            : output predicted structures in stockholm format \n\
-v            : verbose output \n\
-x            : print out parameters of model \n\
-d            : debugging output \n\
-t            : debugging, print traceback\n\
-f            : debugging, print fill matrix from cyk \n\
";
static char usage[]  = "Usage: conus_compare [-options] <testfile1> <testfile2> ...\n";

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;
  STATS stattot; 
  STATS globalstats; 

  /* ReadSeq variables */
  SQFILE *sqfp; SQINFO sqinfo;
  int sformat;
  char *rna; char *ss; 

  /* Models info */
  MODEL nusmodel;
  struct trace_s *trc;

  /* Digitize Setup */
  SetAlphabet(hmmNUCLEIC);

  if (!(ProcessOpts(&settings, &optid, argc, argv, usage, 
	      gramdesc, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  if (argc - optid < 1) {
    Die("Incorrect number of command line arguments.\n%s\n%s\n", 
	  usage, optsline);
  }
  /* We don't have table code for each sequence so for now
   * we must disallow both table mode and individual sequence 
   * output. */
  if ((settings.istats) && (settings.ctoutput)) {
     settings.istats = FALSE;
  }
  
  SetupModel(&settings, &nusmodel);
  if (settings.minloop >= 0) HLEN = settings.minloop;
  if (settings.parameterout) PrintModel(settings.ofp, &nusmodel); 
  if (settings.verbose) 
     fprintf(settings.ofp, "Using %s \n", grNAME[settings.grammar]);

  ZeroStats(&globalstats);
  if (settings.ctoutput) PrintTableHeader();

  while (!(argc - optid < 1)) {
    gatherStats(argv[optid], &settings, &nusmodel, &stattot, usage);

    if (settings.ctoutput) {
       PrintTableLine(argv[optid], stattot, TRUE);
    } else {
       fprintf(settings.ofp, "\nFinal Analysis Stats for %s\n", argv[optid]);
       fprintf(settings.ofp, 
	     "%d Sequences in Input File: %d Analyzed, %d Ignored\n", 
	     (stattot.Nfree + stattot.containN), stattot.Nfree, 
	     stattot.containN);
       PrintTotals(stattot, TRUE);
    }
    optid ++; 
    accumulateStats(&stattot, &globalstats);
  }

  if (settings.globalstats) {
     if (settings.ctoutput) {
	PrintTableLine("TOTALS", globalstats, FALSE);
     } else {
	fprintf(settings.ofp, 
	      "\nFinal Analysis Stats (over all test files): \n");
	fprintf(settings.ofp, 
	      "%d Sequences in Input File: %d Analyzed, %d Ignored\n", 
	      (globalstats.Nfree + globalstats.containN), globalstats.Nfree, 
	      globalstats.containN);
	PrintTotals(globalstats, FALSE);
     }
  }
}

/* If want in tabular format: 
 *
 *   PrintTableHeader();
 *     while (!(argc - optid < 1)) {
 *       gatherStats(argv[optid], settings, model, &stattot, usage);
 *	 PrintTableLine(argv[optid], stattot);
 *	 optid ++;
 *     }
 *
 */
