/* loops.c
 * RDD, Wed Apr  2 09:02:45 CST 2003
 *
 * Functional forms for loops in UZK styled 
 * grammars
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "gsl/gsl_multifit.h"

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"
#include "grammars.h"


/* Function: parabolizeCounts
 * Date: Tue Apr  1 22:15:29 CST 2003 [St Louis]
 *
 * Purpose: Convert counts into a parabola.
 * 	Uses a crude three point approximation
 *
 * Parameters: 
 * 	loops	The set of loop paramters (as counts)
 *
 * Returns: -void-
 */
void
parabolizeCounts(int *loops)
{
   int i;
   float a, b, c;
   int x1, x2, x3;
   int y1, y2, y3;
   float delta2, delta3;
   float K;

   y1 = loops[1];
   x1 = 1;

   x2 = 2; y2 = loops[2];
   x3 = 29; y3 = loops[29];
   printf("x1 %d y1 %d\nx2 %d y2 %d\nx3 %d y3 %d\n", 
	 x1, y1, x2, y2, x3, y3);

   for (i = 2; i < MAXLOOP; i++) {
      if (loops[i] > y2) {
	 y2 = loops[i];
	 x2 = i;
      }
   }
   printf("x1 %d y1 %d\nx2 %d y2 %d\nx3 %d y3 %d\n", 
	 x1, y1, x2, y2, x3, y3);

   K = (float)(x3 -1) / (float)(x2-1);
   printf("K %f\n", K);

   delta2 = y3 - y1 + (K * y1) - (K * y2);
   delta3 = (x3 * x3) - 1 - (K * x2 * x2) - K;

   a = delta2 / delta3;
   b = (float)(y2 - y1 - (a * x2 * x2) -a)/(float)(x2-1);
   c = y1 - a - b;

   for (i = 1; i < MAXLOOP; i++) {
      x1 = (int)(a * i * i + i * b + c);
      if (x1 > 0) loops[i] = x1;
   }
}

/* Function: quadraticCounts 
 * Date: Wed Apr  2 09:04:34 CST 2003 [St Louis]
 *
 * Purpose: Convert counts into a parabola.
 * 	Uses a crude three point approximation
 *
 * Parameters: 
 * 	loops	The set of loop paramters (as counts)
 *
 * Returns: -void-
 */
void
quadraticCounts(int *loops)
{
   int i; int x1;
   double xi, yi; 
   double chisq;
   gsl_matrix *X, *cov;
   gsl_vector *y, *c;
   gsl_multifit_linear_workspace *work;

   /* Allocate space for polynomial of degree 2 */
   X = gsl_matrix_alloc(MAXLOOP-1, 3);
   y = gsl_vector_alloc(MAXLOOP-1);
   c = gsl_vector_alloc(3);
   cov = gsl_matrix_alloc(3,3);

   /* Setup the model matrix X for polynomial of degree 2 */
   for (i = 1; i < MAXLOOP; i++) {
     gsl_matrix_set(X, i-1, 0, 1.0);
     gsl_matrix_set(X, i-1, 1, i);
     gsl_matrix_set(X, i-1, 2, i*i);
     gsl_vector_set(y, i-1, loops[i]);
   }

   /* Allocate a workspace and then calc the best fit polynomial */
   work = gsl_multifit_linear_alloc(MAXLOOP-1, 3);
   gsl_multifit_linear(X, y, c, cov, &chisq, work);
   gsl_multifit_linear_free(work);

   printf("Y = %g + %g X + %g X^2 ",
	 gsl_vector_get(c, 0), gsl_vector_get(c, 1), gsl_vector_get(c, 2));

   for (i = 1; i < MAXLOOP; i++) {
      x1 = (int)(gsl_vector_get(c,2) * i * i + i * gsl_vector_get(c,1) + gsl_vector_get(c,0));
      if (x1 > 0) loops[i] = x1;
   }
/*
#define C(i) (gsl_vector_get(c, (i)))
#define COV(i,j)  (gsl_matrix_get(cov, (i), (j)))
*/
}

/* Function: cubicCounts 
 * Date: Wed Apr  2 14:06:36 CST 2003 [St Louis]
 *
 * Purpose: Convert counts into a parabola.
 * 	Uses a crude three point approximation
 *
 * Parameters: 
 * 	loops	The set of loop paramters (as counts)
 *
 * Returns: -void-
 */
void
cubicCounts(int *loops)
{
   int i; int x1;
   double xi, yi; 
   double chisq;
   gsl_matrix *X, *cov;
   gsl_vector *y, *c;
   gsl_multifit_linear_workspace *work;

   /* Allocate space for polynomial of degree 2 */
   X = gsl_matrix_alloc(MAXLOOP-1, 4);
   y = gsl_vector_alloc(MAXLOOP-1);
   c = gsl_vector_alloc(4);
   cov = gsl_matrix_alloc(4,4);

   /* Setup the model matrix X for polynomial of degree 2 */
   for (i = 1; i < MAXLOOP; i++) {
     gsl_matrix_set(X, i-1, 0, 1.0);
     gsl_matrix_set(X, i-1, 1, i);
     gsl_matrix_set(X, i-1, 2, i*i);
     gsl_matrix_set(X, i-1, 3, i*i*i);
     gsl_vector_set(y, i-1, loops[i]);
   }

   /* Allocate a workspace and then calc the best fit polynomial */
   work = gsl_multifit_linear_alloc(MAXLOOP-1, 4);
   gsl_multifit_linear(X, y, c, cov, &chisq, work);
   gsl_multifit_linear_free(work);

   printf("Y = %g + %g X + %g X^2 + %g X^3",
	 gsl_vector_get(c, 0), gsl_vector_get(c, 1), gsl_vector_get(c, 2),
	 gsl_vector_get(c,3));

   for (i = 1; i < MAXLOOP; i++) {
      x1 = (int)(gsl_vector_get(c,3) * i * i * i +
	    gsl_vector_get(c,2) * i * i + i * gsl_vector_get(c,1) + gsl_vector_get(c,0));
      if (x1 > 0) loops[i] = x1;
   }
}

/* Function: quarticCounts 
 * Date: Wed Apr  2 14:08:03 CST 2003 [St Louis]
 *
 * Purpose: Convert counts into a parabola.
 * 	Uses a crude three point approximation
 *
 * Parameters: 
 * 	loops	The set of loop paramters (as counts)
 *
 * Returns: -void-
 */
void
quarticCounts(int *loops)
{
   int i; int x1;
   double xi, yi; 
   double chisq;
   gsl_matrix *X, *cov;
   gsl_vector *y, *c;
   gsl_multifit_linear_workspace *work;

   /* Allocate space for polynomial of degree 2 */
   X = gsl_matrix_alloc(MAXLOOP-1, 5);
   y = gsl_vector_alloc(MAXLOOP-1);
   c = gsl_vector_alloc(5);
   cov = gsl_matrix_alloc(5,5);

   /* Setup the model matrix X for polynomial of degree 2 */
   for (i = 1; i < MAXLOOP; i++) {
     gsl_matrix_set(X, i-1, 0, 1.0);
     gsl_matrix_set(X, i-1, 1, i);
     gsl_matrix_set(X, i-1, 2, i*i);
     gsl_matrix_set(X, i-1, 3, i*i*i);
     gsl_matrix_set(X, i-1, 4, i*i*i*i);
     gsl_vector_set(y, i-1, loops[i]);
   }

   /* Allocate a workspace and then calc the best fit polynomial */
   work = gsl_multifit_linear_alloc(MAXLOOP-1, 5);
   gsl_multifit_linear(X, y, c, cov, &chisq, work);
   gsl_multifit_linear_free(work);

   printf("Y = %g + %g X + %g X^2 + %g X^3 + %g X^4",
	 gsl_vector_get(c, 0), gsl_vector_get(c, 1), gsl_vector_get(c, 2),
	 gsl_vector_get(c,3), gsl_vector_get(c,4));

   for (i = 1; i < MAXLOOP; i++) {
      x1 = (int)(gsl_vector_get(c,4) * i * i * i * i + gsl_vector_get(c,3) * i * i * i +
	    gsl_vector_get(c,2) * i * i + i * gsl_vector_get(c,1) + gsl_vector_get(c,0));
      if (x1 > 0) loops[i] = x1;
   }
}
