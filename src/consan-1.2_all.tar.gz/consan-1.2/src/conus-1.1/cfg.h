#ifndef CFG_H_INCLUDED
#define CFG_H_INCLUDED

/* See NOTES for grammar descriptions. */

/* Grammar classifications */
#define	NUN	0	/* Maximize base pairs: NUS, UNA, RUN, IVO */
#define YRG	1	/* Simple Stacking: YRN, UYN */
#define RYG	2	/* Simple Stacking: RYN, RY2, RY3 */
#define BYG	3	/* Simple Stacking: BRY, BR2 */
#define AYR	4	/* Bulge + Split Loops: AYN, AY2 */
#define ZKG	5	/* Loop lengths: RZK, ZUK, GIE */

/* Grammars */
#define NUS  	0	
#define UNA	1
#define UYN	2
#define RUN 	3
#define RYN	4
#define RY2	5
#define RY3	6
#define BRY	7
#define AYN	8
#define AY2	9
#define RZK	10
#define YRN	11	
#define ZUK	12
#define IVO	13
#define BJK	14
#define BK2	15
#define GIE	16
#define GMR	17

/* DP non-terminals: Productions */
#define dpS      0 
#define dpW	 0
#define dpL      1
#define dpT	 1
#define dpX	 1
#define dpV	 2
#define dpR      2
#define dpP	 3
#define dpN	 4
#define dpM	 5
#define dpJ	 6
#define dpI	 6
#define dpH	 7
#define dpQ	 8
#define dpF	 9	
#define dpE	 10	/* dummy identifier */
#define NDPS     10      

/***********************************************/
/* Indicies for model transitions: Rules 
 *   NOTE: This is probablly a strange way to do this.
 *      But because CONUS is built up piece meal, I want to
 *      reuse space previously allocated whenever possible (minimze
 *      the number of transitions (NTRANS) while still making sure
 * 	that the terminology for each grammar makes sense and assigns
 *	each transition uniquely).
 */
/************** NUS ****************/
#define TSS      0	/* S -> aSa' */
#define TSL      1	/* S -> aS */ 
#define TSR      2	/* S -> Sa */
#define TSB      3	/* S -> SS */
#define TSE      7	/* S -> end */

/*************** IVO **************/
/*
 - utilize TSL = 1
 - utilize TSB = 3
 - utilize TSE = 7
 */

/************** YRN  ****************/
/* 
 - utilize TSP = 0	S -> aPa' 
 - utilize TSL = 1
 - utilize TSR = 2
 - utilize TSB = 3
 - utilize TSE = 7
 - utilize TPP = 8	
*/
#define TPS	 9	/* P -> S */

/************** UNA **************/
/* 
  - utilize TSS = 0	 S -> aSa' 
  - utilize TSL = 1	 S -> aL
  - utilize TSR = 2 	 S -> Ra
  - utilize TSB = 3 	 S -> LS
*/
#define TLS      4	/* L -> aSa' */
#define TLL      5	/* L -> aL */
#define TRR      6	/* R -> Ra */
/* changing TSE -> TRE */
#define TRE      7	/* R -> end */

/************* UYN *************/
/* changing TSS -> TSP */
#define TSP	 0	/* S -> aPa */
/* 
  - utilize TSL = 1		S -> aL
  - utilize TSR = 2		S -> Ra 
  - utilize TSB = 3 		S -> LS
  - changing TLS -> TLP 	L -> aPa'
*/
#define TLP      4	/* L -> aPa */
/* 
  - utilize TLL = 5	L -> aL
  - utilize TRR = 6	R -> Ra 
  - utilize TRE = 7	R -> end
*/
#define TPP	 8	/* P -> aPa */
#define TPN	 9	/* P -> aNa */
#define TNL	10	/* N -> aL */
#define TNR	11	/* N -> Ra */
#define TNB	12	/* N -> LS */

/**************** RUN ***************/
/*  
  - utilize TSS = 0	S -> aS
  - utilize TSE = 7 	S -> end
*/
#define TST	 1	/* S -> T */
#define TTT	 2	/* T -> Ta */
#define TTS	 3	/* T -> aSa' */
#define TTB	 4	/* T -> TaSa' */

/**************** RYN ***************/
/* 
  - utilize TSS = 0	S -> aS
  - utilize TST = 1 	S -> T
  - utilize TSE = 7	S -> end
  - utilize TTT	 2	 T -> Ta 
  - changing TTS -> TTP */
#define TTP	 3	/* T -> aPa' */
/* - utilize TTB = 4	T -> TaSa' */
/* - utilize TPP = 8 	P -> aPa' */
#define TPS	 9	/* P -> aS */
#define TPT	10	/* P -> Ta */
#define TPB	11	/* P -> TaPa' */

/**************** RY2 & RY3 *****************/
/* 
  - utilize TSS = 0	S -> aS
  - utilize TST = 1 	S -> T
  - utilize TSE = 7	S -> end
  - utilize TTT	= 2	T -> Ta 
  - utilize TTP	= 3	T -> aPa' 
  - utilize TTB = 4	T -> TaSa' 
  - utilize TPP = 8 	P -> aPa' 
  - utilize TPN = 9	P -> N
  - utilize TNL	= 10	N -> aS 
  - utilize TNR	= 11	N -> Ta 
  - utilize TNB	= 12	N -> T aPa'
*/

/***************** BRY **************/ 
/*
  - utilize TSS = 0	S -> aS
  - utilize TST = 1 	S -> T
  - utilize TSE = 7	S -> end
  - utilize TTT	= 2	T -> Ta 
  - utilize TTP	= 3	T -> aPa' 
  - utilize TTB = 4	T -> TaSa' 
*/
  #define TPL 	17 	/* P -> x aPa' */
  #define TPR 	18	/* P -> aPa' x */
/*
  - utilize TPP = 8 	P -> aPa' 
  - utilize TPN = 9	P -> N 
  - utilize TNL	= 10	N -> aaS 
  - utilize TNR	= 11	N -> Taa 
  - utilize TNB	= 12	N -> MT 
*/
#define TMM	5	/* M -> aM */
#define TMJ	6	/* M -> J */
#define TJJ	15	/* J -> Ja */
#define TJP	16	/* J -> aPa' */

/************** AYN & AY2 ***************/
/* 
  - utilize TSS = 0	S -> aS
  - utilize TST = 1 	S -> T
  - utilize TSE = 7	S -> end
  - utilize TTT	 2	T -> Ta 
  - utilize TTP	 3	T -> aPa' 
  - utilize TTB = 4	T -> TaSa' 
  - utilize TRR	= 6	R -> Ra
*/
#define TRP 	26	/* R -> aPa' */
/*
  - utilize TMM	= 5	M -> aM 
*/
#define TMR	16	/* M -> R */
/*
  - utilize TPP = 8 	P -> aPa' 
  - utilize TPN = 9	P -> N (AY2, LY2);  P -> aNa' (AYN, LYN)
  - utilize TPL = 17 	P -> x aPa' (AYN, AY2)
  - utilize TPR = 18 	P -> aPa' x (AYN, AY2)
*/
#define TPE 	19	/* P -> x aNa' */
#define TPW	20	/* P -> aNa' x */
#define TNQ	10	/* N -> aaQ (AYN, AY2); N -> aQ (LYN, LY2) */
/* 
  - utilize TNR	= 11	N -> Raa (AYN, AY2); N -> Ra (LYN, LY2) 
  - utilize TNB	= 12	N -> IT
*/
#define TNH	13	/* N -> aaH (AYN, AY2); N -> aH (LYN, LY2) */
#define TNI	14	/* N -> aI */
/* double up on end defs */
#define THE	15	/* H -> end */
#define THH	21	/* H -> aH */
#define TII	22	/* I -> aI */
#define TIR	23	/* I -> Ra */
#define TQQ	24	/* Q -> aQ */
#define TQP	25	/* Q -> aPa' */

/*******************  RZK *****************/
 /* 
  - utilize TSS = 0	S -> aS
  - utilize TST = 1 	S -> T
  - utilize TSE = 7	S -> end
  - utilize TTT	 2	T -> Ta 
  - utilize TTP	= 3	T -> aPa' 
  - utilize TTB = 4	T -> TaSa' 
  - utilize TPP = 8 	P -> aPa' 
  - utilize TPN = 9	P -> aNa'
  - utilize TNH = 13	N -> a...a 
  - utilize TNL = 10	N -> a... aPa' 
  - utilize TNR = 11  	N -> aPa' ...a
  - utilize TNI	= 14	N -> a... aPa' ...a 
  - utilize TNB = 12	N -> MT 
  - utilize TMM	= 5	M -> aM 
  - utilize TMJ	= 6	M -> J
  - utilize TJJ	= 15	J -> Ja 
  - utilize TJP	= 16	J -> aPa' 
*/

/*********** BJK ************/
/* 
 - utilize TSL = 1
 - utilize TSB = 3
 */
#define TLF	0
#define TLA	2
#define TFF	4
#define TFB	5

/************** GIE **************/
/************** ZUK **************/

#define NTRANS	27 /* Max from above + 1 */
/***********************************************/

/* Indices for bases */
#define ntA	0
#define ntC	1
#define ntG	2
#define ntU	3
#define ntT	4	/* For compatability with HMMER alphabets */
#define ALPHA   4

#define PAIRS		(ALPHA*ALPHA)
#define TRIPLETS	(ALPHA*ALPHA*ALPHA)
#define QUADS		(ALPHA*ALPHA*ALPHA*ALPHA)

/* Convert a pair into a number between 0 and (ALPHA^2 -1) */
#define idx(symi, symj)		(symi+ALPHA*symj)

/* Names -- useful for debugging; see globals.c */
extern char *baseNAME[ALPHA];
extern char *grNAME[GMR];
extern int grFAMILY[GMR];
extern char *dpNAME[NDPS];
extern int Contains[GMR][NDPS];
extern char *dptNAME[GMR][NTRANS];
extern int Rules[GMR][NDPS][NTRANS];

/* Defining HLEN as global permits us to modify it with command line params 
 * Grammars should set (lplen(i,j) >= HLEN) for pairs[i][j] */
extern int HLEN;

/* Useful macros -- from qrna's globals.h */
#define LN2         0.69314718056
#define LN2INV      1.44269504089
#define LOG2(x)     ((x) == 0.0 ? -HUGE_VAL : log(x) * LN2INV)
#define LOGSUM_TBL  20000	/* controls precision on Logsum() */
#define BIGINT     9999999	/* prohibition without overflow */
/* Note: values of 999999 and smaller are too small for groupI's score */
#define BIGFLOAT   9999999.99	/* prohibition without overflow */

/* Parameters pulled from HMMERs config.h file that are relevant to alphabet.c */
#define INTSCALE    1000.0      /* scaling constant for floats to integer scores   */
#define INFTY       987654321   /* infinity for purposes of integer DP cells       */

#define MAXLOOPSIZE 30		/* loop size maximum */
#define MAXLOOP  MAXLOOPSIZE+1	/* using loop(0) to be "impossible", this for allocations */
#define dist(i,j)	((j)-(i)+1) 
#define lplen(i,j)	((j)-(i)-1) 
#define ilplen(i,k,l,j)  (((j)-(l)+1) + ((k)-(i)+1)) 

#define lpindex(x)	((((x) < 1) || ((x) > MAXLOOPSIZE)) ? 0 : (x))
#define dif(x,y)	((y) - (x))

/*********************** structures ***********************/
/* Parameters of the model in probability form */
struct nusmodel_s {
  double transitions[NTRANS];

  double singles[ALPHA];	/* A, C, G, or U */
  double pairs[ALPHA][ALPHA];	/* All possible pairings of nt */
  double stack[(ALPHA*ALPHA)][ALPHA][ALPHA];	/* ALPHA^2 possible stack matricies */

  double loop[MAXLOOP];	/* single stranded loops */
  double loopcomp[ALPHA];	/* A, C, G, or U */

  double hairpin[MAXLOOP];	/* single stranded loops */
  double hpcomp[ALPHA];	/* A, C, G, or U */

  double bulge[MAXLOOP];	/* single stranded loops */
  double bulgecomp[ALPHA];	/* A, C, G, or U */
};
typedef struct nusmodel_s PROBMOD;

struct nusscor_s {
  int transitions[NTRANS];	

  int singles[ALPHA];		/* A, C, G, T or U */
  int pairs[ALPHA][ALPHA];	/* All possible pairings of nt */
  int stack[(ALPHA*ALPHA)][ALPHA][ALPHA];	/* ALPHA^2 possible stck matricies */

  int loop[MAXLOOP];	/* single stranded loops */
  int loopcomp[ALPHA];		/* A, C, G, T or U */
  int *emitloop;

  int hairpin[MAXLOOP];	/* single stranded loops */
  int hpcomp[ALPHA];	/* A, C, G, or U */
  int *emithp;

  int bulge[MAXLOOP];	/* single stranded loops */
  int bulgecomp[ALPHA];	/* A, C, G, or U */
  int *emitbulge;
};
typedef struct nusscor_s INTMOD;

/* Convient way of associating a probabilistic model with its integer form
	and other useful information */
struct modelparam_s {
  int grammar;		/* What grammar is this set of parameters for? */
  int probabilistic;	/* Are these parameters probabilities or scores? */

  PROBMOD probs;	/* Probabilistic parameters */
  INTMOD  scores;	/* Integer parameters -- either scores, or integer log from of probs */
};
typedef struct modelparam_s MODEL;

struct gnode_s {
   int nonterminal;
   int esymbol;
   char ess;
};
typedef struct gnode_s GNODE;

struct gstack_s {
   struct gstack_s *nxt;
   GNODE *node;
};
typedef struct gstack_s GSTACK;

/* Indicies in a single matrix of parameters */
/*
#define peTSP(symi, symj)	(symi*4+symj)
#define peTSS(symi) 		(16+symi)
*/
#define pTSS		20
#define pTSL		21
#define pTSR		22
#define pTSB		23
#define pTSE		24
#define NUSvals		25

#define sre_isascii(c)   (!((c) & ~0177))

/*********************** headers *****************************/

/* cfg.c */
extern void CopyIntModel(INTMOD *from, INTMOD *to);
extern void CopyIntEmissions(INTMOD *from, INTMOD *to);
extern void CopyProbModel(PROBMOD *from, PROBMOD *to);
extern void CopyProbEmissions(PROBMOD *from, PROBMOD *to);

extern void PrintModel(FILE *fp, MODEL *cfg);
extern void PrintFullModel(FILE *fp, MODEL *cfg);
extern void PrintProbModel(FILE *fp, PROBMOD *icfg, int grammar);
extern void PrintIntModel(FILE *fp, INTMOD *icfg, int grammar);
extern void PrintAsProbModel(FILE *fp, INTMOD *icfg, int grammar);
extern void PrintAsIntModel(FILE *fp, PROBMOD *icfg, int grammar);

extern void printTransModel(FILE *fp, MODEL *model, int useprobs);
extern void printEmissionMatricies(FILE *fp, MODEL *model, int useprobs);
extern void printStackMatrices(FILE *fp, MODEL *model, int useprobs);
extern void printLoops (FILE *fp, MODEL *mod, int useprobs);
extern void printSpecLoops (FILE *fp, MODEL *mod, int useprobs);

extern void ZeroModel(MODEL *cfg);
extern void zeroProbMod(PROBMOD *probs);
extern void zeroIntMod(INTMOD *probs);

/* cfgmodel.c */
extern int contains_rule (int grammar, int dp);
extern void plusOnePrior(INTMOD *probs);

extern void LogifySCFG(PROBMOD *cfg, INTMOD *ret_icfg);
extern void InvLogifySCFG(INTMOD *cfg, PROBMOD *ret_icfg);
extern void ProbifySCFG(INTMOD *icfg, PROBMOD *ret_cfg, int grammar, INTMOD *prior);
extern void probifyEmissions(INTMOD *icfg, PROBMOD *ret_cfg, INTMOD *prior);
extern void probifyStackParams (INTMOD *icfg, PROBMOD *ret_cfg, INTMOD *prior);
extern void probifyLoops (INTMOD *icfg, PROBMOD *ret_cfg, INTMOD *prior, int tie);
extern void probSpecLoops (INTMOD *icfg, PROBMOD *ret_cfg, INTMOD *prior);
extern void probifyTransitions(INTMOD *icfg, PROBMOD *ret_cfg, INTMOD *prior, int grammar);

void preCalcSegs (INTMOD *model, char *drna, int len);
int * preCalcSegEmit (char *rna, int len, int *comp);

extern void SetUpNusScoring(INTMOD *sc);
extern void SetUpFlatMx(PROBMOD *sc, int grammar);

extern struct gnode_s * PopGstack(struct gstack_s *stack);
extern void PushGstack(struct gstack_s *stack, GNODE *newnode);
extern struct gnode_s * NewNode(int csymbol, char ssymbol, int nonterm);
extern void FreeGstack(struct gstack_s *stack);
extern struct gstack_s * InitGstack(void);

/* cfgio.c */
/* static void byteswap(char *swap, int nbytes);  */
extern int SaveSCFG(FILE *ofp, MODEL *cfg);
extern int ReadSCFG(FILE *ofp, MODEL *ret_cfg);
extern int CheckModel(PROBMOD *prmodel, int grammar);
extern void SaveAscii(FILE *ofp, INTMOD *cfg);
extern void ReadAscii(FILE *ofp, INTMOD *cfg);

/* rdd_math.c */
extern int asIntLog (float prob);
extern float asLog (float prob);
extern float asFloatProb (int prob);
extern float asProb (double prob);
extern float LogSum(float p1, float p2);
extern inline int ILogsum(int p1, int p2);
extern inline double DLogsum(double p1, double p2);
extern inline int ILogdiff(int p1, int p2);
extern inline double DLogdiff(double p1, double p2);
extern int ILogsumSet(int *intprobs, int num);

extern void parabolizeCounts(int *icfg);

#endif /* CFG_H_INCLUDED */

