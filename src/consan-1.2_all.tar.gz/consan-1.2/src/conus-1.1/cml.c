/* cml.c
 *
 * Routines for conducting conditional maximum likelihood training 
 * on my grammars.
 *
 */

#include<stdio.h>

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"

void offlineCML(PROBMOD *model, char *filename, int grammar, OPTS *settings, double tol,
      	double etaTol); 
void calcSetExpVal(int grammar, char *filename, OPTS *settings, PROBMOD *model,
      PROBMOD *Ntotals, PROBMOD *Mtotals, double *Tval);
void calcLikelihoodSet(int grammar, OPTS *settings, char *filename, 
      PROBMOD *model, double *fTval);
void accumulateExp(PROBMOD *toadd, PROBMOD *cummulative);

void onlineCML(PROBMOD *model, char *filename, int grammar, OPTS *settings, double tol,
      double etaTol); 
int calcExpVals(char *rna, int len, int grammar, PROBMOD *model, OPTS *settings, 
      char *sqss, double *PEval, PROBMOD *Nvals, PROBMOD *Mvals);
void calcGradient(int grammar, PROBMOD *model, PROBMOD *nij, PROBMOD *mij, 
      	PROBMOD *ret_gradient);
void updateParams(int grammar, double eta, PROBMOD *model, PROBMOD *gradient, 
      PROBMOD *newp);
void polyEtapprox(char *rna, char *sqss, int len, int grammar, OPTS *settings, double G1,
      PROBMOD *model, PROBMOD *gradient, char *filename, double epsilon, 
      double *ret_eta, double *newFval);
int calcLikelihood(char *rna, int len, int grammar, PROBMOD *model, OPTS *settings, 
      char *sqss, double *ret_Lval); 

/* Function: offlineCML 
 *
 * Purpose: Execute gradient descent CML training on 
 * 	a training set
 *
 * Reference: See Krogh and Riis 1999, Neural Computation 11, 541-563
 *
 * Args:
 * 	model	parameters of the model
 * 	filename	training set
 * 	grammar
 * 	settings	global settings/parameters
 * 	tol		Tolerance of training (cutoff for "convergence")
 *
 */
void
offlineCML(PROBMOD *model, char *filename, int grammar, OPTS *settings,
      double tol, double etaTol)
{
   /* Managing a sequence file (training set */
   SQFILE *sfp; SQINFO sinfo;
   int sformat;

   /* Gathering data from a sequence file */
   char *rna;

   /* Calculating qualities within the CML process */
   PROBMOD gradient, Nvals, Mvals;
   double PEval; /* P(y| x, Theta) for: single sequence, all seqs */
   double Fval;  /* P(y| x, Theta) after step */
   double stepsize;
   double tolerance;
   int i;
   int converged = FALSE;
   int debug = FALSE;

   i = 0; 

   do {

      /* Gather expected values */
      zeroProbMod(&Nvals); zeroProbMod(&Mvals);
      calcSetExpVal(grammar, filename, settings, model, &Nvals, &Mvals, &PEval);

      /* Using the n and m vectors, calculate the gradient */
      calcGradient(grammar, model, &Nvals, &Mvals, &gradient);
      if (settings->debugg) {
	 printf("gradient values: \n");
	 PrintProbModel(settings->ofp, &gradient, grammar); 
      }

      /* Set the stepsize */
      if (settings->seteta == TRUE) {
	 stepsize = settings->delta;
      } else {
	 polyEtapprox(rna, sinfo.ss, sinfo.len, grammar, settings, PEval,
	       model, &gradient, filename, etaTol, &stepsize, &Fval);
      }

      /* Adjust the parameters with respect to this gradient 
      *  P_{i+1} = P_{i} + stepsize * gradient_{i}
       * updateParams(grammar, current->stepsize, model, &gradient); 
       */
      updateParams(grammar, stepsize, model, &gradient, model);
      if (settings->debugg) PrintProbModel(settings->ofp, model, grammar); 

      /* Determine how much we've moved the likelihood */
      calcLikelihoodSet(grammar, settings, filename, model, &Fval);
      printf("PEval %f Fval %f\n", PEval, Fval);

      /* Test for convergence */
      i++; 
      printf("Iteration # %d stepsize %f \n", i, stepsize);
      tolerance = tol * abs(PEval);

      /* PrintAsProbModelD(stdout, model, grammar);  */
      fflush(stdout);

      /* Convergence Tests */
      if (settings->fixedstep) {	/* Go fixed number of iters */
	 if (i >= settings->percentage) {
	    converged = TRUE;  
	 }
      } else if (abs(abs(PEval) - Fval) < tolerance) {
	 converged = TRUE;
	 printf("Likelihood Change below Tolerance \n");
	 break;
      } else if (stepsize < etaTol) {
	 printf("Change in stepsize below epsilon \n");
	 converged = TRUE;
	 break;
      } else {				/* Prevent infinite walk */
	 if (i >= settings->percentage) {
	    converged = TRUE;  
	 }
      }

      /* Hijacked percentage option to count interations; prevents infinite */
   } while (!converged);
}

/* Function: calcSetExpVal 
 *
 * Purpose: Calculate Expected Value over a set of inputs
 * 
 * Args:
 * 	grammar  	currently utilized grammar
 * 	filename	set on which to calculate
 * 	settings	global settings for output and debugging
 *	
 * Returns:
 * 	Ntotals & Mtotals	calculated expected values
 * 	Tval			calculated likelihood over set
 */
void
calcSetExpVal(int grammar, char *filename, OPTS *settings, PROBMOD *model,
      PROBMOD *Ntotals, PROBMOD *Mtotals, double *Tval)
{
   /* Managing a sequence file (training set */
   SQFILE *sfp; SQINFO sinfo;
   int sformat;

   /* Gathering data from a sequence file */
   char *rna;

   /* Calculating qualities within the CML process */
   PROBMOD Nvals, Mvals;
   double PEval, fTval; /* P(y| x, Theta) for: single sequence, all seqs */
   int debug = FALSE;

   fTval = -BIGFLOAT; 

   /* open training set */
   if ((sfp = SeqfileOpen(filename, SQFILE_UNKNOWN, NULL)) == NULL)
      Die("Failed to open sequence file %s\n", filename);

   /* For each sequence in the training set, gather expected values */
   while (ReadSeq(sfp, sformat, &rna, &sinfo)) {
      ToRNA(rna);
      if (settings->verbose) 
	 fprintf(settings->ofp, "Sequence %s:\n", sinfo.name);

      if (!(ContainsAmbiguous(rna, sinfo.len))) {

	 /* Calculate the expected counts (N and M values) 
	  * as well as the function value (PEval) for this
	  * instance
	  */
	 calcExpVals(rna, sinfo.len, grammar, model, settings, 
	       sinfo.ss, &PEval, &Nvals, &Mvals);

	 /* Accumulate information over all data sets */
	 fTval = DLogsum(PEval, fTval);
	 accumulateExp(&Nvals, Ntotals); 
	 accumulateExp(&Mvals, Mtotals);

	 if (settings->debugg) {
	    printf("N values: \n");
	    PrintProbModel(settings->ofp, &Nvals, grammar); 
	    printf("M values: \n");
	    PrintProbModel(settings->ofp, &Mvals, grammar); 
	 }
      } else {
	 /* We'll ignore sequences containing ambiguous bases. */
	 printf("Sequence %s is ambiguous\n", sinfo.name);
      }
   }
   SeqfileClose(sfp);
   *Tval = fTval;
}

/* Function: calcLikelihoodSet
 * Date: Tue Feb 11 13:37:31 CST 2003 [St Louis]
 *
 * Purpose: Calculate likelihood for a set of samples
 *
 * Args:
 * 	grammar	
 * 	filename	Dataset
 *
 * Returns:
 * 	fTval	Likelihood for set
 */
void
calcLikelihoodSet(int grammar, OPTS *settings, char *filename, 
      PROBMOD *model, double *fTval)
{
   /* Managing a sequence file (training set */
   SQFILE *sfp; SQINFO sinfo;
   int sformat;

   /* Gathering data from a sequence file */
   char *rna;

   double Fval, Lval; 
   int debug = FALSE;

   Lval = -BIGFLOAT; 

   /* We need to calculate how much the likelihood has now changed */
   if ((sfp = SeqfileOpen(filename, SQFILE_UNKNOWN, NULL)) == NULL)
      Die("Failed to open sequence file %s\n", filename);

   /* For each sequence in the training set, gather expected values */
   while (ReadSeq(sfp, sformat, &rna, &sinfo)) {
      ToRNA(rna);
      if (settings->verbose) 
	 fprintf(settings->ofp, "Sequence %s:\n", sinfo.name);

      if (!(ContainsAmbiguous(rna, sinfo.len))) {
	 /* printf("%s %d %s \n", rna, sinfo.len, grNAME[grammar]); */
	 calcLikelihood(rna, sinfo.len, grammar, model, settings, sinfo.ss, &Fval);
	 Lval = DLogsum(Fval, Lval);
      } 
   }
   SeqfileClose(sfp);

   *fTval = Lval;
}

/* Function: accumulateExp
 * Date Tue Feb 11 13:08:00 CST 2003 [St Louis]
 *
 * Purpose: Accumulate expected values (N & M) over
 * 	a large data set
 *
 * Arg:
 * 	toadd	a set of N values to add to a total
 * 	cummulative	current total 
 * 			(must be zeroed before first use)
 *
 * Returns: - void -
 */
void
accumulateExp(PROBMOD *toadd, PROBMOD *cummulative)
{
   int i, j, k;

   for (i = 0; i < NTRANS; i++) {
      cummulative->transitions[i] = DLogsum(toadd->transitions[i],
	    	cummulative->transitions[i]);
   }
   for (k = 0; k < (ALPHA * ALPHA); k++) {
      for (i = 0; i < ALPHA; i++) {
	 for (j = 0; j < ALPHA; j++) {
	    if (k == 0) cummulative->pairs[i][j] = DLogsum(toadd->pairs[i][j],
	    				cummulative->pairs[i][j]);
	    cummulative->stack[k][i][j] = DLogsum(toadd->stack[k][i][j], 
		  cummulative->stack[k][i][j]); 
	 }
	 if (k == 0) cummulative->singles[i] = DLogsum(toadd->singles[i], 
	       cummulative->singles[i]);
      }
   }
}

/* Function: onlineCML 
 *
 * Purpose: Execute gradient descent CML training on 
 * 	a training set
 *
 * Reference: See Krogh and Riis 1999, Neural Computation 11, 541-563
 *
 * Args:
 * 	model	parameters of the model
 * 	filename	training set
 * 	grammar
 * 	settings	global settings/parameters
 * 	tol		Tolerance of training (cutoff for "convergence")
 *
 */
void
onlineCML(PROBMOD *model, char *filename, int grammar, OPTS *settings,
      double tol, double etaTol)
{
   /* Managing a sequence file (training set */
   SQFILE *sfp; SQINFO sinfo;
   int sformat;

   /* Gathering data from a sequence file */
   char *rna;
   
   /* Save intermediate steps */
   FILE *ofp;
   char temp[30];
   MODEL TEMP;

   /* Calculating qualities within the CML process */
   PROBMOD gradient, Nvals, Mvals;
   double PEval, Fval;
   double stepsize, tolerance;
   int i;
   int converged = FALSE;
   int debug = FALSE;

   TEMP.grammar = grammar;
   TEMP.probabilistic = TRUE;

   i = 0; 
   do {
      /* open training set */
      if ((sfp = SeqfileOpen(filename, SQFILE_UNKNOWN, NULL)) == NULL)
	 Die("Failed to open sequence file %s\n", filename);

      /* For each sequence in the training set, take 1 step */
      while (ReadSeq(sfp, sformat, &rna, &sinfo)) {
	 ToRNA(rna);
	 if (settings->verbose) 
	    fprintf(settings->ofp, "Sequence %s:\n", sinfo.name);

	 if (!(ContainsAmbiguous(rna, sinfo.len))) {
	    i++; 	/* In online training a "step" is per sequence */

	    /* Calculate the expected counts (N and M values) 
	     * as well as the function value (PEval) for this
	     * instance
	     */
	    calcExpVals(rna, sinfo.len, grammar, model, settings, 
		  sinfo.ss, &PEval, &Nvals, &Mvals);
	    if (settings->debugg) {
	       printf("Likelihood: %f\n", PEval);
	       printf("N values: \n");
	       PrintProbModel(settings->ofp, &Nvals, grammar); 
	       printf("M values: \n");
	       PrintProbModel(settings->ofp, &Mvals, grammar); 
	    }

	    /* Using the n and m vectors, calculate the gradient */
	    calcGradient(grammar, model, &Nvals, &Mvals, &gradient);
	    if (settings->debugg) {
	       printf("gradient values: \n");
	       PrintProbModel(settings->ofp, &gradient, grammar); 
	    }
	   
	    if (settings->seteta == TRUE) {
	       stepsize = settings->delta;
	    } else {
	       polyEtapprox(rna, sinfo.ss, sinfo.len, grammar, settings, PEval,
		     model, &gradient, NULL, etaTol, &stepsize, &Fval);
	    }
	    printf("%s stepsize %f \n", sinfo.name, stepsize);  

	    /* Adjust the parameters with respect to this gradient 
	    *  P_{i+1} = P_{i} + stepsize * gradient_{i}
	     * updateParams(grammar, current->stepsize, model, &gradient); 
	     */
	    updateParams(grammar, stepsize, model, &gradient, model);
	    if (settings->debugg) PrintProbModel(settings->ofp, model, grammar); 

	    /* Determine how much Likelihood changed */
	    calcLikelihood(rna, sinfo.len, grammar, model, settings, sinfo.ss, &Fval);
	    printf("PEval %f Fval %f\n", PEval, Fval);

   	    /* PrintAsProbModelD(stdout, model, grammar);  */
	    fflush(stdout);
      
	    tolerance = tol * abs(PEval);
	    /* Convergence Tests */
	    if (settings->fixedstep) {		/* Go fixed steps */
	       printf("Iteration # %d of %d\n", i, settings->percentage);
	       if (i >= settings->percentage) {
		  converged = TRUE;  
		  break;
	       }
	    } else if (abs(PEval - Fval) < tolerance) {
	       printf("Change in Likelihood below tolerance \n");
	       converged = TRUE;
	       break;
	    } else if (stepsize < etaTol) {
	       printf("Change in stepsize below epsilon \n");
	       converged = TRUE;
	       break;
	    } else {				/* Prevent infinite walk */
	       if (i >= settings->percentage) {
		  converged = TRUE;  
		  printf("Max iterations permitted\n");
		  break;
	       }
	    }

	    if (settings->scorefile != NULL) {
	       sprintf(temp, "%d", i);
	       strcat(temp, settings->scorefile);
	       ofp = fopen(temp, "w");
	       printf("Writing %s\n", temp);
	       InvDLogifySCFG(model, &(TEMP.probs));
	       SaveSCFG(ofp, &TEMP);
	    }

	 } else {
	    /* We'll ignore sequences containing ambiguous bases. */
	    printf("Sequence %s is ambiguous\n", sinfo.name);
	 }
      }
      SeqfileClose(sfp);

      /* Hijacked percentage option to count interations; prevents infinite */
   } while (!converged);
}

/* Function: calcExpVals
 *
 * Purpose: 
 *    - calculate the expected counts for
 * 	the various model parameters (n_{ij}, n_i)
 *    - Also returns the likelihood for
 * 	this set of parameters
 *
 * Ref: Krogh and Riis (1999), Neural Computation 11, 541-563
 *	the m values are calculated under the conditional 
 * 	the n values are calculated for all paths
 * 	The likelihood is the value of L = Lc - Lf
 * 	Both m and n are returned as log values
 * 
 * Args:
 * 	rna	sequence
 * 	len	length of sequence
 * 	model	parameters of the model
 * 	settings	global settings/parameters
 * 	sqss	given secondary structure on which to condition
 *
 * Returns:
 * 	PEval	neg log prob = Likelihood (Krogh's L)
 * 	Nvals	expected counts calculated for all paths (as logs)
 * 	Mvals	expected counts calculated for conditional (as logs)
 * 	FALSE   if problems; TRUE otherwise
 */
int
calcExpVals(char *rna, int len, int grammar, PROBMOD *model, OPTS *settings, char *sqss,
      double *PEval, PROBMOD *Nvals, PROBMOD *Mvals)
{
   double ***insideMX, ***outsideMX;
   /* Note: Inside returns log P(x | \Theta) which is 
    * the negative of Krogh's Lf value.
    */
   double nLc; 		/* clamped phase: log P (x, y | \Theta) */
   double nLf;		/* free running phase: log P (x | \Theta */
   double Lval;		/* log P (y | x, \Theta) */
   char *drna;
   int *ss;
   int debug = FALSE;
   
   drna = DigitizeSequence(rna, len);

   /* Convert given structure to ct format */
   if (! KHS2ct(sqss, len, FALSE, &ss))
   { printf("[bad trusted structure]\n"); return (FALSE);}
     
   /* if (settings->debugg) printf("Calc for conditional \n"); */
   if (Inside(rna, len, grammar, model, settings, ss, &nLc, &insideMX)) {
      if (Outside(rna, len, grammar, model, settings, ss, insideMX, &outsideMX)) {
	 calcNvals(insideMX, outsideMX, drna, len, model, grammar, nLc, Mvals);
	 if (debug) {
	    printf("M values\n");
	    PrintProbModel(settings->ofp, Mvals, grammar); 
	 }
      }
   }
   freeFillMxD(outsideMX, grammar); 
   freeFillMxD(insideMX, grammar); 

   /* if (settings->debugg) printf("Calc for sequence \n"); */
   ss = NULL;   /* Unconstrained "free running phase" */
   if (Inside(rna, len, grammar, model, settings, ss, &nLf, &insideMX)) {
      if (Outside(rna, len, grammar, model, settings, ss, insideMX, &outsideMX)) {
	 calcNvals(insideMX, outsideMX, drna, len, model, grammar, nLf, Nvals);
	 if (debug) {
	    printf("N values\n");
	    PrintProbModel(settings->ofp, Mvals, grammar); 
	 }
      }
   }
   freeFillMxD(outsideMX, grammar); 
   freeFillMxD(insideMX, grammar); 

   /* Calculate probability of the labeling:
    * log P(y| x, \Theta) = log P(x, y | \Theta) / log P(x | \Theta) 
    */
   if (nLc > nLf) printf("conditional log P %f is larger than full log P %f! \n", nLc, nLf);

   /* Calculate log P(y| x, \theta) 
    * L = Lc - Lf
    * nLf = -Lf and nLc = -Lc
    * Hence L = nLf - nLc
    */
   Lval = nLf - nLc;
   
   if (settings->debugg)
     printf("nLc %e nLf %e return Lval %e\n", nLc, nLf, Lval); fflush(stdout);
   *PEval = Lval;

   return(TRUE);
}

/* Function: calcLikelihood
 *
 * Purpose: 
 *    - returns the negative log likelihood for this 
 *    set of parameters
 *
 * Ref: Krogh and Riis (1999), Neural Computation 11, 541-563
 *
 * Notes:  
 * The likelihood is the value of L = Lc - Lf
 * 
 * Args:
 * 	rna	sequence
 * 	len	length of sequence
 * 	grammar	current grammar under consideration
 * 	model	parameters of the model
 * 	settings	global settings/parameters
 * 	sqss	given secondary structure on which to condition
 *
 * Returns:
 * 	ret_Lval	negative log prob = likelihood (L)
 */
int
calcLikelihood(char *rna, int len, int grammar, PROBMOD *model, 
      		OPTS *settings, char *sqss, double *ret_Lval)
{
   double ***insideMX;
   /* Note: Inside return the log P(x \ Theta) which is
    * the negative of Krogh's Lf value. 
    */
   double nLc, nLf, Lval;
   char *drna;
   int *ss;
   
   drna = DigitizeSequence(rna, len);
   nLc = nLf = -BIGFLOAT;

   /* Convert given structure to ct format */
   if (! KHS2ct(sqss, len, FALSE, &ss))
   { printf("[bad trusted structure]\n"); return (FALSE);}

   /* if (settings->debugg) printf("Calc for conditional \n"); */
   Inside(rna, len, grammar, model, settings, ss, &nLc, &insideMX); 
   freeFillMxD(insideMX, grammar); 

   /* if (settings->debugg) printf("Calc for sequence \n"); */
   ss = NULL;   /* Unconstrained "free running phase" */
   Inside(rna, len, grammar, model, settings, ss, &nLf, &insideMX);
   freeFillMx(insideMX, grammar); 

   /* Calculate log P(y| x, \theta) 
    * L = Lc - Lf
    * nLf = -Lf and nLc = -Lc
    * Hence L = nLf - nLc
    */
   Lval = nLf - nLc;
   if (settings->debugg) printf("Likelihood: nLc %f nLf %f Lval %f \n", nLc, nLf, Lval);
   fflush(stdout);
   *ret_Lval = Lval;

   return(TRUE);
}

/* Function: calcGradient
 * Date: Wed Oct  9 12:39:51 CDT 2002 [St Louis]
 *
 * Purpose: calculate the gradient values for
 * 	the various model parameters (z_{ij})
 *
 * Ref: Krogh and Riis (1999), Neural Computation 11, 541-563
 *
 * \frac{\partial{\mathcal{L}}}{\partial{z_{ij}}}
 *   = - [ m_{ij} - n_{ij} - \theta_{ij} \sum_{j'}(m_{ij'} - n_{ij'}) ]
 * 
 * Args:
 * 	model	parameters of current model
 * 	n_ij	n_ij parameters (using all paths)
 * 	m_ij	m_ij parameters (constrained)
 *
 * Returns:
 * 	ret_gradient  {\partial{\mathcal{L}}}{\partial{z_{ij}}}
 */
void
calcGradient(int grammar, PROBMOD *model, PROBMOD *nij, PROBMOD *mij, PROBMOD *ret_gradient)
{
   int i, j;
   double sumval, sumval2, temp;
   int debug = FALSE;

   if (debug) {
      printf("Theta: \n");
      PrintProbModel(stdout, model, grammar);
      PrintAsProbModelD(stdout, model, grammar); 
      printf("Nij: \n");
      PrintProbModel(stdout, nij, grammar);
      printf("Mij: \n");
      PrintProbModel(stdout, mij, grammar);
   } 

   /* Transition parameters */
   for (i = 0; i < NDPS; i++) {
      sumval = 0.0;   
      for (j = 0; j < NTRANS; j++) {
	 if (Rules[grammar][i][j] > 0) {
	    if (debug) printf("mij %f nij %f \n", asProb(mij->transitions[j]), 
		  asProb(nij->transitions[j]));
	    /* mij->transitions[j] - nij->transitions[j] */
	    ret_gradient->transitions[j] = asProb(mij->transitions[j]) - asProb(nij->transitions[j]);
	    if (debug) printf("mij - nij = %f \n", ret_gradient->transitions[j]);
            /* \sum_{j'} (m_{ij'} - n_{ij'}) */
	    sumval = sumval + ret_gradient->transitions[j];
	 }
      }
      /* - [ m_{ij} - n_{ij} - \theta_{ij} \sum_{j'}(m_{ij'} - n_{ij'}) ] */
      for (j = 0; j < NTRANS; j++) {
	 if (Rules[grammar][i][j] > 0) {
	    temp = asProb(model->transitions[j]) * sumval;
	    if (debug) printf("theta %f temp %f\n", asProb(model->transitions[j]), temp);
	    ret_gradient->transitions[j] = -1 * (ret_gradient->transitions[j] - temp);
	 }
      }
   }

   /* Emission parameters 
    *
    * Currently only does singles and pairs parameters. 
    * Will need to modify to handle stacking for Yarn like grammars
    * Will need to modify to handle loop lengths for Zuker like grammars
    */
   sumval = 0.0; sumval2 = 0.0;
   for (i = 0; i < ALPHA; i++) {
     for (j = 0; j < ALPHA; j++) {
   	/* m_{i}(a,b) - n_{i}(a,b) */
	ret_gradient->pairs[i][j] = asProb(mij->pairs[i][j]) - asProb(nij->pairs[i][j]);
	sumval = sumval + ret_gradient->pairs[i][j];
     }
     /* m_{i}(a) - n_{i}(a) */
     ret_gradient->singles[i] = asProb(mij->singles[i]) - asProb(nij->singles[i]);
     sumval2 = sumval2 + ret_gradient->singles[i];
   }
   for (i = 0; i < ALPHA; i++) {
      /* - [ m_{i}(a) - n_{i}(a) - \theta_{i}(a) 
       * 			\sum_{a'}(m_{i}(a') - n_{i}(a')) ] */
      temp = asProb(model->singles[i]) * sumval;
      ret_gradient->singles[i] = -1 * (ret_gradient->singles[i] - temp);
      /* - [ m_{i}(a,b) - n_{i}(a,b) - \theta_{i}(a,b) 
       * 			\sum_{a'b'}(m_{i}(a', b') - n_{i}(a',b')) ] */
      for (j = 0; j < ALPHA; j++) {
	 temp = asProb(model->pairs[i][j]) * sumval;
	 ret_gradient->pairs[i][j] = -1 * (ret_gradient->pairs[i][j] - temp);
      }
   }
   if (debug) {
      printf("Gradient: \n");
      PrintProbModel(stdout, ret_gradient, grammar);
   }

}

/* Function: updateParams
 *
 * Purpose: update the parameters based on this gradient
 *
 * Ref: Krogh and Riis (1999), Neural Computation 11, 541-563
 *
 * \theta_{ij} = \frac{\theta_{ij} \exp^{-\eta \frac{\partial{\mathcal{L}}}
 * 		{\partial{z_{ij}}}}} {\sum_{j'} \theta_{ij'} 
 * 		\exp^{-\eta \frac{\partial{\mathcal{L}}}{\partial{z_{ij'}}}}}
 * 
 * Args:
 * 	model	parameters of current model
 * 	gradient	parameters of gradient 
 * 	eta	gradient stepsize value
 *
 */
void
updateParams(int grammar, double eta, PROBMOD *model, PROBMOD *gradient, PROBMOD *newp)
{
   int i, j;
   double scalefactor;		/* eta * gradient */
   double dps[NDPS];		/* denominator for each nonterminal */
   double numerator[NTRANS];	/* numerator for each transition */

   double num[ALPHA][ALPHA];	/* numerator for pairs emissions */
   double dpairs; 		/* denominator for pairs */
   double snum[ALPHA];		/* numerator for singles */
   double dsingles; 		/* denominator for pairs */

   double scheck, dcheck, newval;	/* Temp values */
   int debug = FALSE;

   if (debug) printf("Eta: %f\n", eta);

   /* Transition parameters */
   for (i = 0; i < NDPS; i++) {
      dps[i] = 0.0;
      for (j = 0; j < NTRANS; j++) {
	 if (Rules[grammar][i][j] > 0) {
	    scalefactor = eta * gradient->transitions[j];
	    if (asProb(model->transitions[j]) != 0) {
	      numerator[j] = log(asProb(model->transitions[j])) - scalefactor;
	    } else {
	      printf("Current model transition %s is zero!\n", dptNAME[grammar][j]);
	    }
	    dps[i] += exp(numerator[j]);
	 }
      }
      if (debug) if (Contains[grammar][i]) {
	 printf("%s denom %f\n", dpNAME[i], dps[i]); fflush(stdout);
      }

      scheck = -BIGINT;
      for (j = 0; j < NTRANS; j++) {
	 if (Rules[grammar][i][j] > 0) {
	    newval = asLog(exp(numerator[j]) / dps[i]);
	    if (debug) printf("j %d = %f (%f)\n", j, newval, asProb(newval));
	    scheck = DLogsum(scheck, newval);
	    newp->transitions[j] = newval;
	 }
      }
      if (debug) if (Contains[grammar][i]) 
	 printf("Trans Sum check: %f (%f)\n", scheck, asProb(scheck));
   }

   /* Emission parameters 
    * 
    * Currently only does singles and pairs parameters. 
    */
   dsingles = 0.0; dpairs = 0.0;
   for (i = 0; i < ALPHA; i++) {
      /* Singles */
      scalefactor = eta * gradient->singles[i];
      if (asProb(model->singles[i]) != 0) {
        snum[i] = log(asProb(model->singles[i])) - scalefactor;
      } else {
	 printf("Current model singles transition is zero!\n");
      }
      dsingles += exp(snum[i]);
      /* Pairs */
      for (j = 0; j < ALPHA; j++) {
	 scalefactor = eta * gradient->pairs[i][j];
	 /* if (debug) printf("Pair %d %d scale %e ", i, j, scalefactor);  */
	 if (asProb(model->pairs[i][j]) != 0) {
	   num[i][j] = log(asProb(model->pairs[i][j])) - scalefactor;
	 } else {
	 printf("Current model pair transition is zero!\n");
	 }
	 /* if (debug) printf("numer %e\n", num[i][j]);  */
	 dpairs += exp(num[i][j]);
      }
   }
   if (debug) printf("Esingles denom %f\n", dpairs); fflush(stdout); 

   scheck = -BIGINT; dcheck = -BIGINT;
   for (i = 0; i < ALPHA; i++) {
      /* Singles */
      newval = asLog(exp(snum[i]) / dsingles);
      if (debug) printf("single %s %f (%f)\n", baseNAME[i], newval, asProb(newval));
      scheck = DLogsum(scheck, newval);
      newp->singles[i] = newval;
      /* Pairs */
      for (j = 0; j < ALPHA; j++) {
	 newval = asLog(exp(num[i][j]) / dpairs);
	 /* if (debug) printf("%d %12.11f \n", newval, asFloatProb(newval));   */
	 dcheck = DLogsum(dcheck, newval);
	 newp->pairs[i][j] = newval;
      }
   }
   if (debug) printf("Epairs Singles check: %f (%f) \n", scheck, asProb(scheck));
   if (debug) printf("Epairs Sum check: %f (%f) \n", dcheck, asProb(dcheck));
}


/* Function: polyEtapprox
 *
 * Purpose: Determine the stepsize for gradient descent
 * 	by a quadradic polynomial approximation
 *
 * Ref: N.S. Asaithambi _Numerical Analysis_ pg 298-299
 * 
 * Args:
 * 	rna	 sequence under analysis
 * 	sqss	 secondary structure given for said sequence
 * 	len	 length of the sequence
 * 	grammar  currently utilized grammar
 * 	settings	global settings for output and debugging
 * 	G1	 previously calcaulted log likelihood for model
 *	model	 current parameters
 *	gradient	first derivative at this location
 *	filename	Dataset if calculating for offline, otherwise NULL
 *	epsilon		tolerance on size of eta
 *
 * Returns:
 * 	ret_eta		Calculated value for eta (stepsize)
 * 	newFval		log likelihood for eta selected
 */
void
polyEtapprox(char *rna, char *sqss, int len, int grammar, OPTS *settings, double G1,
      PROBMOD *model, PROBMOD *gradient, char *filename,
      double epsilon, double *ret_eta, double *newFval)
{
   double eta0, eta1, eta2, eta3;
   double g0, g1, g2, g3;
   double delta2, delta3;
   double a, b, c;
   PROBMOD newmodel;
   int debug = FALSE;

   /* if (debug) printf("Tolerance of Eta: %f\n", epsilon);   */

   /* Because G1 is log Likelihood, we need to use
    * negative log likelihood
    */
   g1 = G1;
   
   eta0 = eta2 = eta3 = 0.1;
   eta1 = 0.0;
   if (debug) {
      printf("Gradient:\n");
      PrintProbModel(stdout, gradient, grammar);
      printf("Original Model: %f\n", g1);
      PrintProbModel(stdout, model, grammar);
   } 

   eta3 = 0.5;
   updateParams(grammar, eta3, model, gradient, &newmodel);
   if (filename == NULL) {
     calcLikelihood(rna, len, grammar, &newmodel, settings, sqss, &g3);
   } else {
     calcLikelihoodSet(grammar, settings, filename, &newmodel, &g3);
   }
   if (debug) {
      printf("Eta3 at %f: %f \n", eta3, g3);
      PrintProbModel(stdout, &newmodel, grammar); 
   }

   while ((g3 > g1) && (eta3 > epsilon)) {
      eta3 = eta3 / 2;
      updateParams(grammar, eta3, model, gradient, &newmodel);
      if (filename == NULL) {
	 calcLikelihood(rna, len, grammar, &newmodel, settings, sqss, &g3);
      } else {
	 calcLikelihoodSet(grammar, settings, filename, &newmodel, &g3);
      }
      if (debug) {
	 printf("Eta3 at %f: %f \n", eta3, g3);
	 PrintProbModel(stdout, &newmodel, grammar); 
      }
   }
   /* If we are below tolerance, we can stop */
   if (eta3 < epsilon) {
      *ret_eta = eta3;
      *newFval = g3;
      return;
   }

   eta2 = eta3 / 2;
   updateParams(grammar, eta2, model, gradient, &newmodel);
   if (filename == NULL) {
     calcLikelihood(rna, len, grammar, &newmodel, settings, sqss, &g2);
   } else {
     calcLikelihoodSet(grammar, settings, filename, &newmodel, &g2);
   }
   if (debug) {
      printf("Eta2 at %f: %f \n", eta2, g2);
      PrintProbModel(stdout, &newmodel, grammar); 
   }

   delta2 = ((g2 - g1)) / eta2;
   delta3 = ((g3 - g1)) / eta3;

   a = (delta3 - delta2) / (eta3 - eta2);
   b = delta2 - a * eta2;
   c = g1;

   eta0 = (-1 * b) / (2 * a);
   if (eta0 < 0) eta0 = eta0 * -1; /* crude absolute value */
   updateParams(grammar, eta0, model, gradient, &newmodel);
   if (filename == NULL) {
     calcLikelihood(rna, len, grammar, &newmodel, settings, sqss, &g0);
   } else {
     calcLikelihoodSet(grammar, settings, filename, &newmodel, &g0);
   }

   if (debug) { 
      printf("Eta0 at %f: %f \n", eta0, g0);
      PrintProbModel(stdout, &newmodel, grammar); 
   }
   if (debug)  
      printf("g0 %f (eta0 %f) g1 %f (eta1 %f) g2 %f (eta2 %f) g3 %f (eta3 %f) \n", 
	 g0, eta0, g1, eta1, g2, eta2, g3, eta3);

   if ((g0 > epsilon) && (g0 < g3)) {
      *ret_eta = eta0;
      *newFval = -1 * g0;	/* Return log likelihood */
   } else {
      *ret_eta = eta3;
      *newFval = -1 * g3;	/* Return log likelihood */
   }
}

