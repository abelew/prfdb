/* cmltrain_main.c */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

/*
#include"gsl/gsl_multimin.h"
#include"gsl/gsl_multimin.h"
*/

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"

static char optsline[]  = "\
where options are:\n\
-m <file>     : (required) Use parameters, grammar and scoring specified in model <file> \n\
-h            : print short help, usage info, and grammar description\n\
-g <string>   : Use (flat) grammar <string>, default NUS; ignored if model file specified \n\
-a 	      : Use offline training procedure (batch mode); Default to online \n\
-b <int>      : Iternate for <int> rounds (do not check for convergence \n\
-z	      : Use fixed stepsize \n\
-e <name>     : debugging; output intermediate steps models \n\
-x            : print out parameters of model \n\
-t            : print traceback\n\
-d            : debugging output \n\
-v            : verbose output \n\
-f            : debugging, print fill matrix from cyk \n\
-p            : Ignore given structure (do full Inside/Outside) \n\
-q            : print predicted structures in stockholm format \n\
";

static char usage[]  = "Usage: cmltrain -m model [-options] <seqfile in>\n";

int 
main (int argc, char **argv) 
{
   /**** arguments variables *****/
   int   optid; 
   OPTS settings;

   /* ReadSeq variables */
   SQFILE *sqfp; SQINFO sqinfo;
   int sformat;
   char *rna, *drna; 
   char *ss; 
   int *ctstruct; 

   /* Models info */
   MODEL nusmodel;
   PROBMOD dlogs;
   double ***insideMX, ***outsideMX;
   int score;
   PROBMOD Nvals, Mvals, gradient, Newval;
   FILE *ofp;

   if (!(ProcessOpts(&settings, &optid, argc, argv, usage, gramdesc, optsline))) {
      printf("%s\n\n", usage);
      exit(0);
   }
   if (argc - optid != 1)
      Die("Incorrect number of command line arguments.\n%s\n%s\n", 
	    usage, optsline);

   SetAlphabet(hmmNUCLEIC);

   SetupModel(&settings, &nusmodel);  
   LogifySCFG(&(nusmodel.probs), &(nusmodel.scores)); 
   DLogifySCFG(&(nusmodel.probs), &dlogs);

   if (settings.modelfile == NULL) {
     nusmodel.grammar = settings.grammar;
     nusmodel.probabilistic = TRUE;
     SetUpFlatMx(&(nusmodel.probs), settings.grammar);
     LogifySCFG(&(nusmodel.probs), &(nusmodel.scores)); 
     DLogifySCFG(&(nusmodel.probs), &dlogs);
   }

   if (settings.debugg) {
      PrintFullModel(settings.ofp, &nusmodel);
      PrintProbModel(stdout, &dlogs, NUS);
   }

   PrintAsProbModelD(stdout, &dlogs, settings.grammar);

   if (settings.globalstats) {
     offlineCML(&dlogs, argv[optid], settings.grammar, &settings, 0.0001, .00000001);
   } else {
     onlineCML(&dlogs, argv[optid], settings.grammar, &settings, 0.0001, .000001);
   }

   PrintAsProbModelD(stdout, &dlogs, settings.grammar); 

   InvDLogifySCFG(&dlogs, &(nusmodel.probs));
   LogifySCFG(&(nusmodel.probs), &(nusmodel.scores)); 

   /* If asked to save the model, do so now. */
   if (settings.savefile != NULL) {
      ofp = fopen(settings.savefile, "w");
      SaveSCFG(ofp, &nusmodel);
   }

}
