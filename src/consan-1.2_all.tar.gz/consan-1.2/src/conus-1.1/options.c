/* options.c
 * Routines for processing a universal set of options 
 */

#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"options.h"
#include"version.h"

struct opt_s OPTIONS[] = {
  { "-H",        TRUE,  sqdARG_NONE  },
  { "-N",        TRUE,  sqdARG_NONE  },
  { "-M",        TRUE,  sqdARG_NONE  },
  { "-a",        TRUE,  sqdARG_NONE  },
  { "-b",        TRUE,  sqdARG_INT   },
  { "-c",        TRUE,  sqdARG_NONE  },
  { "-d",        TRUE,  sqdARG_NONE  },
  { "-e",        TRUE,  sqdARG_STRING},
  { "-f",        TRUE,  sqdARG_NONE  },
  { "-g",        TRUE,  sqdARG_STRING},
  { "-h",        TRUE,  sqdARG_NONE  },
  { "-i",        TRUE,  sqdARG_NONE  },
  { "-j",        TRUE,  sqdARG_FLOAT },
  { "-m",        TRUE,  sqdARG_STRING},
  { "-o",        TRUE,  sqdARG_STRING},
  { "-p",        TRUE,  sqdARG_NONE  },
  { "-q",        TRUE,  sqdARG_NONE  },
  { "-r",        TRUE,  sqdARG_STRING},
  { "-s",        TRUE,  sqdARG_STRING},
  { "-t",        TRUE,  sqdARG_NONE  },
  { "-v",        TRUE,  sqdARG_NONE  },
  { "-w",        TRUE,  sqdARG_INT   },
  { "-x",        TRUE,  sqdARG_NONE  },
  { "-y",        TRUE,  sqdARG_NONE  },
  { "-z",        TRUE,  sqdARG_NONE  },
  { "--flat",    FALSE,  sqdARG_NONE  },
};

#define NOPTIONS (sizeof(OPTIONS) / sizeof(struct opt_s))

/* Function: ProcessOpts
 * Date:     RDD, Thu Nov 15 17:52:31 2001 [St. Louis]
 *
 * Purpose:  proccess a standard set of options for CONUS
 *
 * Args:     
 *     	options		datastructure containing settings
 *	optid		iterator to command line options
 *	argc		command line information
 *	argv		command line information
 *	usage		program usage statement, printed on failure.
 *
 * Returns:  TRUE if options parsed properly; FALSE otherwise
 */
int 
ProcessOpts(OPTS *options, int *optid, int argc, char **argv, char *usage, char *expert, char *optsline)
{
  char *optarg; char *optname;
  char *outfile;		/* Redirect output */
  char *savefile;		/* Where to save model */
  char *modelfile;		/* Model file to load */
  char *trainfile;		/* Training set to load */ 
  char *grmr;			/* Loaded grammar value */
  int specpercent, specexact;

  /* Set defaults in options */
  options->grammar 	= NUS;
  options->useprob	= FALSE; 

  options->verbose       = FALSE; options->debugg 	= FALSE; 
  options->traceback     = FALSE; options->outmx	= FALSE;
  options->parameterout	 = FALSE;

  options->structout 	= FALSE; options->ctoutput	= FALSE; 
  options->stockout 	= FALSE; options->mathews	= FALSE;
  options->istats	= FALSE; options->globalstats 	= FALSE;
  options->tie	= TRUE;

  options->modelfile	= NULL; options->trainfile 	= NULL;
  options->savefile	= NULL; options->scorefile	= NULL; 

  options->hbondsc 	= FALSE; options->flatscore	= FALSE;
  options->seteta = FALSE;	 options->nostacking	= FALSE;
  options->fixedstep = FALSE;

  options->minloop = 1;
  options->percentage   = 5;
  options->permutatetype	= NON;
  options->delta	= 0.0; 

  /* Initialize */
  specpercent = FALSE;  specexact = FALSE;
  outfile       = NULL; grmr = NULL;


  /* Intepret command line arguments */
 while (Getopt(argc, argv, OPTIONS, NOPTIONS, optsline, optid, &optname, &optarg)) {
    if (strcmp(optname, "-v") == 0) options->verbose = TRUE;
    else if (strcmp(optname, "-g") == 0) grmr			= optarg;
    else if (strcmp(optname, "-d") == 0) options->debugg	= TRUE;
    else if (strcmp(optname, "-t") == 0) options->traceback 	= TRUE;
    else if (strcmp(optname, "-f") == 0) options->outmx         = TRUE;
    else if (strcmp(optname, "-H") == 0) options->hbondsc	= TRUE;
    else if (strcmp(optname, "-N") == 0) options->nostacking    = TRUE;
    else if (strcmp(optname, "-M") == 0) options->mathews	= TRUE;
    else if (strcmp(optname, "-x") == 0) options->parameterout	= TRUE;
    else if (strcmp(optname, "-p") == 0) options->structout     = TRUE;
    else if (strcmp(optname, "-q") == 0) options->stockout	= TRUE;
    else if (strcmp(optname, "-c") == 0) options->ctoutput	= TRUE;
    else if (strcmp(optname, "-i") == 0) options->istats        = TRUE;
    else if (strcmp(optname, "-a") == 0) options->globalstats	= TRUE;
    else if (strcmp(optname, "--flat") == 0) options->flatscore = TRUE;
    else if (strcmp(optname, "-m") == 0) options->modelfile	= optarg;
    else if (strcmp(optname, "-r") == 0) options->trainfile	= optarg;
    else if (strcmp(optname, "-s") == 0) options->savefile	= optarg;
    else if (strcmp(optname, "-e") == 0) options->scorefile	= optarg;
    else if (strcmp(optname, "-z") == 0) options->seteta = TRUE;
    else if (strcmp(optname, "-y") == 0) options->fixedstep = TRUE;
    else if (strcmp(optname, "-b") == 0) {
       options->fixedstep = TRUE;
       options->percentage    = atoi(optarg);
       specpercent = TRUE;
    } else if (strcmp(optname, "-w") == 0) {
       options->minloop = atoi(optarg);
       if (options->minloop < 0) options->minloop = 0;
    } else if (strcmp(optname, "-j") == 0) {
       options->seteta = TRUE;
       options->delta = atof(optarg);
    }
    else if (strcmp(optname, "-o") == 0) outfile        	= optarg;
    else if (strcmp(optname, "-h") == 0)
      {
        puts(BANNER);
        printf("         CONUS %s (%s)\n", RELEASE, RELEASEDATE);
        /* printf(" using squid %s (%s)\n", squid_version, squid_date); */
        printf("%s\n", usage);
        puts(optsline);
	puts(expert);
        return FALSE;
      }
  }

  /* Redirect output if necessary */
  options->ofp = stdout;
  if (outfile != NULL && (options->ofp = fopen(outfile, "w")) == NULL)
    Die("Failed to open output file %s", outfile);

  /* Process selected grammar -- convert input string into a grammar choice */
  if (grmr != NULL) 
     options->grammar = processGrammarChoice(grmr, options->verbose);
  if (options->grammar >= GMR) 
     Die("Improperly specified grammar!\n%s\n", gramdesc ); 

  if (specpercent) {
    options->permutatetype = PER;
  } else if (specexact) {
    options->permutatetype = EXA;
  }

  return TRUE;
}

/* Function: processGrammarChoice
 * Date:     RDD, Thu Nov 15 17:52:41 2001 [St. Louis]
 *
 * Purpose:  convert grammar input string to grammar code
 *
 * Args:   
 *	grammar		Grammar choice as a string 
 *
 * Returns:  
 *	grammar choice as it's code (see cfg.h)
 *	Returns GMR if unknown grammar selected
 */
int
processGrammarChoice (char *grammar, int verbose)
{
  if (strcmp(grammar, "NUS") == 0) {
    if (verbose) printf("Using Nussinov grammar\n");
    return NUS;
  } else if (strcmp(grammar, "IVO") == 0) {
    if (verbose) printf("Using Ivo's grammar\n");
    return IVO;
  } else if (strcmp(grammar, "BJK") == 0) {
    if (verbose) printf("Using B.Knudsen's Pfold grammar\n");
    return BJK;
  } else if (strcmp(grammar, "BK2") == 0) {
    if (verbose) printf("Using B.Knudsen's Pfold grammar (w/stacking)\n");
    return BK2;
  } else if (strcmp(grammar, "YRN") == 0) {
    if (verbose) printf("Using Yarn grammar\n");
    return YRN;
  } else if (strcmp(grammar, "UNA") == 0) {
    if (verbose) printf("Using Unambiguous Nussinov grammar\n");
    return UNA;
  } else if (strcmp(grammar, "UYN") == 0) {
    if (verbose) printf("Using Unambiguous Yarn (aNa') grammar\n");
    return UYN;
  } else if (strcmp(grammar, "RUN") == 0) {
    if (verbose) printf("Using Little Unambiguous Yarn grammar\n");
    return RUN;
  } else if (strcmp(grammar, "RYN") == 0) {
    if (verbose) printf("Using Little Unambiguous Yarn grammar (no N) \n");
    return RYN;
  } else if (strcmp(grammar, "RY2") == 0) {
    if (verbose) printf("Using Little Unambiguous Yarn grammar (N) \n");
    return RY2;
  } else if (strcmp(grammar, "RY3") == 0) {
    if (verbose) printf("Using Little Unambiguous Yarn grammar (aNa') \n");
    return RY3;
  } else if (strcmp(grammar, "BRY") == 0) {
    if (verbose) printf("Using Bulge Unambiguous Yarn (ambiguous) \n");
    return BRY;
  } else if (strcmp(grammar, "AYN") == 0) {
    if (verbose) printf("Using Affine Unambiguous Yarn grammar\n");
    return AYN;
  } else if (strcmp(grammar, "AY2") == 0) {
    if (verbose) printf("Using Affine Unambiguous Yarn (N) \n");
    return AY2;
  } else if (strcmp(grammar, "ZUK") == 0) {
    if (verbose) printf("Using Zuker grammar\n");
    return ZUK;
  } else if (strcmp(grammar, "RZK") == 0) {
    if (verbose) printf("Using Revised Unambiguous Zuker grammar\n");
    return RZK;
  } else if (strcmp(grammar, "GIE") == 0) {
    if (verbose) printf("Using Giegerich's grammar\n");
    return GIE;
  } else {
    return GMR;
  }
}

/* Function: PrintOptions
 * Date:     RDD, Thu Nov 15 17:52:48 2001 [St. Louis]
 *
 * Purpose: debugging function.  Prints contents of
 *	opts struct (see options.h) 
 *
 * Args:    
 *	ofp	Where to print 
 *	options	Which settings/options to print 
 *
 * Returns:  -nothing-
 */
void
PrintOptions (FILE *ofp, OPTS *options)
{
  fprintf(ofp, "Current Settings:\n");
  if (options->grammar < GMR) {
    fprintf(ofp, "Options: Grammar is %s\n", grNAME[options->grammar]);
  } else {
    fprintf(ofp, "Improperly specified grammar!\n");
  }
  if (options->useprob) { fprintf(ofp, "Use Probs Set\n"); }

  fprintf(ofp, "Min Loop Size: %d\n", options->minloop);

  if (options->verbose) fprintf(ofp, "Verbose output mode\n");
  if (options->debugg) fprintf(ofp, "Debug Mode\n");
  if (options->traceback) fprintf(ofp, "Report tracebacks\n");
  if (options->outmx) fprintf(ofp, "Report Fill Matrix\n");
  if (options->parameterout) fprintf(ofp, "Output Parameters\n");

  if (options->structout) fprintf(ofp, "Compare Real to Predicted Structure Output\n");
  if (options->stockout) fprintf(ofp, "Produce Stockholm Output\n");
  if (options->ctoutput) fprintf(ofp, "Output in ct format\n");
  if (options->istats) fprintf(ofp, "Report Intermediate Statistics (per seq)\n");
  if (options->globalstats) fprintf(ofp, "Report Global Statistics (all test sets)\n");

  if (options->permutatetype == EXA) {
    fprintf(ofp, "Permutate type is exact amount (Delta)\n");
    fprintf(ofp, "Delta set to %6.4f\n", options->delta);
  } else if (options->permutatetype == PER) {
    fprintf(ofp, "Permutate type is as percentage \n");
    fprintf(ofp, "Permutate precentage at %d\n", options->percentage);
  }
  if (options->modelfile != NULL) fprintf(ofp, "Using modelfile: %s\n", options->modelfile);
  if (options->trainfile != NULL) fprintf(ofp, "Using training set: %s\n", options->trainfile);
  if (options->savefile != NULL) fprintf(ofp, "Saving model to file: %s\n", options->savefile);
  if (options->scorefile != NULL) fprintf(ofp, "Using scorefile: %s\n", options->scorefile);

}

