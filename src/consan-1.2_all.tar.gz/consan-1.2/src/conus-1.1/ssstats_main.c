/* ssstats_main.c */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"
#include"stats.h"

void khstotrace(char *seq, int *ct, int len, struct trace_s **ret_tr);
void gatherStructStat(char *seq, int len, char *name, struct trace_s *tr, 
      OPTS settings, SSINFO *stats);
void addLoopCounts(char *rna, int *counts, int i, int j);
void PrintSStotals (SSINFO *stats, OPTS settings);

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-v            : verbose output \n\
-d            : debugging output \n\
-t            : print traceback\n\
";

static char usage[]  = "Usage: gatherstats [-options] <seqfile in>\n";

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;

  FILE *ofp, *ifp;

  /* ReadSeq variables */
  SQFILE *sfp; SQINFO sinfo;
  int sformat; char *rna;

  /* Models info */
  struct trace_s *trc;
  SSINFO collector;
  int i, nbp;
  int *ct;

  if (!(ProcessOpts(&settings, &optid, argc, argv, usage, "", optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  if (argc - optid < 1)
    Die("Incorrect number of command line arguments.\n%s\n%s\n", usage, optsline);

  ZeroSS(&collector);

  printf("File: %s\n", argv[optid]);

  if ((sfp = SeqfileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL)
    Die("Failed to open sequence file %s\n", argv[optid]);

  while (ReadSeq(sfp, sformat, &rna, &sinfo)) {
    ToRNA(rna);
    collector.nseq++;
    collector.positions += sinfo.len;
    if (sinfo.len > collector.maxlen) collector.maxlen = sinfo.len;
    if (sinfo.len < collector.minlen) collector.minlen = sinfo.len;

    if (settings.istats) {printf("Sequence: %s\n", sinfo.name); }
    if (!(ContainsAmbiguous(rna, sinfo.len))) collector.Nfree++; 

    /* Need to count number of bps in this guy */
    nbp = 0;
    for (i = 0; i < sinfo.len; i++) {
       if (sinfo.ss[i] == '>') nbp++;	/* Does this always work? */
    }
    collector.trusted += nbp;
    if (nbp > collector.maxbp) collector.maxbp = nbp;
    if (nbp < collector.minbp) collector.minbp = nbp;

    /* Need to calculate if this sequence has any lone pairs */

    if (VerifyKHS(sinfo.name, sinfo.ss, TRUE) == TRUE) {

      if (! KHS2ct(sinfo.ss, sinfo.len, FALSE, &ct)) {
	 Warn("Structure string is inconsistent"); 
         collector.khsfailed++;
      } else {
	 if (CheckforLonePairs(ct, sinfo.len)) {
	   collector.lonepairs++; 
	   if (settings.verbose) 
	      printf("%s contains lone pair\n", sinfo.name);
	 }

	 khstotrace(rna, ct, sinfo.len, &trc);
	 if (settings.traceback) { PrintTrace(stdout, trc, rna); }

	 /* Trace Counts */
	 gatherStructStat(rna, sinfo.len, sinfo.name, trc, settings, &collector);

	 FreeTrace(trc);
      }

    } else {
       collector.khsfailed++;
    }

    /* Cleanup  */
    FreeSequence(rna, &sinfo);
  }
  SeqfileClose(sfp);

  if (settings.savefile != NULL) {
    ofp = fopen(settings.savefile, "w");
    gnuLoops(&collector, ofp);
    fclose(ofp);
  }
  printf("Num Seqs: %d \tnts: %d \tbps: %d\n", collector.nseq, collector.positions, collector.trusted);
  printf("Length: Min %d \tAvg %d \tMax %d\n", collector.minlen, 
	(int)(collector.positions/collector.nseq), collector.maxlen);
  printf("bps: Min %d \tAvg %d \tMax %d\n", collector.minbp, 
	(int)(collector.trusted/collector.nseq), collector.maxbp);
  PrintSStotals(&collector, settings); 
  printf("%d  of %d seqs contain an ambiguous base \n", (collector.nseq - collector.Nfree),
		collector.nseq);
  printf("Seqs containing lone pairs: %d\n", collector.lonepairs);
}

/* Function: khstotrace()
 * Date: RDD, Tue Mar 23 19:12:49 CST 2004 [St Louis]
 *
 * Purpose: Convert khs format into traceback.
 *
 * Uses RZK grammar:
 *   S -> aS | T | end
 *   T -> Ta | aPa' | TaPa'
 *   P -> aPa' | N
 *   N -> a...a | a... aPa' | aPa' ...a | a... aPa' ...a | MT
 *   M -> aM | J
 *   J -> Ja | aPa'
 *
 * Args:
 *   seq	- sequence
 *   ct		- structure in CT format 
 *   len	- length of seq and ct 
 *   ret_tr	- RETURNS traceback
 *
 */
void
khstotrace(char *seq, int *ct, int len, struct trace_s **ret_tr)
{
   struct tracestack_s *dolist;
   struct trace_s      *cur;
   struct trace_s      *tr;
   struct trace_s      *prv, *nxt;
   char left; char right;
   int  i,j, mid, mid2, validstruct;

   validstruct = TRUE;
   tr     = InitTrace();
   dolist = InitTracestack();
   cur = AttachTrace(tr, dpS, 0, len-1, TRE); /* attach the guy we'll work on first */
   PushTracestack(dolist, cur);

   while ((cur = PopTracestack(dolist)) != NULL) {
      i = cur->emitl; j = cur->emitr;

      if (i > j) {
	 cur->transition = TSE; cur->emitl = -1; cur->emitr = -1; 
      } else if (ct[i] == -1) {	/* left unpaired */
	 switch (cur->nonterminal) {
	    case dpS:
	       cur->transition = TSS; cur->emitr = -1;
	       PushTracestack(dolist, AttachTrace(cur, dpS, i+1, j, TRE));
	       break;
	    case dpM:
	       cur->transition = TMM; cur->emitr = -1;
	       PushTracestack(dolist, AttachTrace(cur, dpM, i+1, j, TRE));
	       break;
	    case dpN:
	       /* Can't be right bulge as (by def) the left position is unpaired */
	       mid = find_split(ct, i, j);
	       if (mid < 0 ) {	/* No stems, must be a hairpin */
		  cur->transition = TNH;
	       } else {		/* Region contains stems */
		  if (mid == j) {	/* Only stem at far right -- this is a Left bulge */
		     cur->transition = TNL; cur->emitl = ct[j]; 
		     PushTracestack(dolist, AttachTrace(cur, dpP, ct[j]+1, j-1, TRE));
		  } else {		/* Contains at least one stem, check if more */
		     mid2 = find_split(ct, mid+1, j);
		     if (mid2 < 0) {	/* Nope, only the one -> therefore is Internal loop */
			cur->transition = TNI; cur->emitl = ct[mid]; cur->emitr = mid;
			PushTracestack(dolist, AttachTrace(cur, dpP, ct[mid]+1, mid-1, TRE));
		     } else {		/* Multiple stems, must bifurcate */
			cur->transition = TNB; cur->emitr = -1; cur->emitl = -1;
			PushTracestack(dolist, AttachTrace(cur, dpT, ct[mid2], j, TRE));
			/* Left Nonterminal (M) must take care of first stem and 
			 * flanking single stranded */
			PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[mid2]-1, TRE));
		     }
		  }
	       }
	       break;
	    case dpP:
	       cur->transition = TPN; cur->emitl = -1; cur->emitr = -1;
	       PushTracestack(dolist, AttachTrace(cur, dpN, i, j, TRE));
	       break;
	    default:
	       printf ("ERROR: Can't have left unpaired in %s!\n", dpNAME[cur->nonterminal]);
	       break;
	 }
      } else if (ct[j] == -1) {	/* right unpaired */
	 switch (cur->nonterminal) {
	    case dpS:
	       cur->transition = TST; cur->emitl = -1; cur->emitr = -1; 
	       PushTracestack(dolist, AttachTrace(cur, dpT, i, j, TRE));
	       break;
	    case dpM:
	       cur->transition = TMJ; cur->emitl = -1; cur->emitr = -1;
	       PushTracestack(dolist, AttachTrace(cur, dpJ, i, j, TRE));
	       break;
	    case dpT:
	       cur->transition = TTT; cur->emitl = -1; 
	       PushTracestack(dolist, AttachTrace(cur, dpT, i, j-1, TRE));
	       break;
	    case dpJ:
	       cur->transition = TJJ; cur->emitl = -1; 
	       PushTracestack(dolist, AttachTrace(cur, dpJ, i, j-1, TRE));
	       break;
	    case dpN:
	       /* Can't be left bulge as (by def) the right position is unpaired */
	       mid = find_split(ct, i, j);
	       if (mid < 0 ) {	/* No stems, must be a hairpin */
		  cur->transition = TNH;
	       } else {		/* Region contains stems */
		  if (ct[mid] == i) {	/* Only stem at far left -- this is a right bulge */
		     cur->transition = TNR; cur->emitr = ct[i];
		     PushTracestack(dolist, AttachTrace(cur, dpP, i+1, mid-1, TRE));
		  } else {		/* Contains at least one stem, check if more */
		     mid2 = find_split(ct, mid+1, j);
		     if (mid2 < 0) {	/* Nope, only the one -> therefore is Internal loop */
			cur->transition = TNI; cur->emitl = ct[mid]; cur->emitr = mid;
			PushTracestack(dolist, AttachTrace(cur, dpP, ct[mid]+1, mid-1, TRE));
		     } else {		/* Multiple stems, must bifurcate */
			cur->transition = TNB;
			PushTracestack(dolist, AttachTrace(cur, dpT, ct[mid2], j, TRE));
			/* Left Nonterminal (M) must take care of first stem and 
			 * flanking single stranded */
			PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[mid2]-1, TRE));
		     }
		  }
	       }
	       break;
	    case dpP:
	       cur->transition = TPN; cur->emitl = -1; cur->emitr = -1;
	       PushTracestack(dolist, AttachTrace(cur, dpN, i, j, TRE));
	       break;
	    default:
	       printf ("ERROR: Can't have right unpaired in %s!\n", dpNAME[cur->nonterminal]);
	       break;
	 }
      } else if (ct[i] == j) {	/* left pairs to right */
	 switch (cur->nonterminal) {
	    case dpS:
	       cur->transition = TST; cur->emitl = -1; cur->emitr = -1; 
	       PushTracestack(dolist, AttachTrace(cur, dpT, i, j, TRE));
	       break;
	    case dpM:
	       cur->transition = TMJ; cur->emitl = -1; cur->emitr = -1; 
	       PushTracestack(dolist, AttachTrace(cur, dpJ, i, j, TRE));
	       break;
	    case dpT:
	       cur->transition = TTP;
	       PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
	       break;
	    case dpJ:
	       cur->transition = TJP;
	       PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
	       break;
	    case dpP:
	       cur->transition = TPP;
	       PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
	       break;
	    case dpN:	/* Swith back? */
	       printf("No bases in this hairpin!\n");
	       cur->transition = TNH;
	       break;
	    default:
	       /* When it throws this error what in the hell does that mean? */
	       printf ("ERROR: Can't have i paired with j in %s!\n", dpNAME[cur->nonterminal]);
	       break;
	 }
      } else {		/* left pairs, not to right */
	 switch (cur->nonterminal) {
	    case dpS:
	       cur->transition = TST; cur->emitl = -1; cur->emitr = -1; 
	       PushTracestack(dolist, AttachTrace(cur, dpT, i, j, TRE));
	       break;
	    case dpT:
	       cur->transition = TTB; cur->emitl = ct[j];
	       PushTracestack(dolist, AttachTrace(cur, dpP, ct[j]+1, j-1, TRE));
	       PushTracestack(dolist, AttachTrace(cur, dpT, i, ct[j]-1, TRE));
	       break;
	    case dpN:
	       /* Must be bifurcation state because if we got here then the left and right
		* are paired to something, just not each other.  Hence bifurcation. */
	       cur->transition = TNB; cur->emitr = -1; cur->emitl = -1;
	       /* Because the M state must take care of interstem region to its left, 
		* we must now find the edge of that interstem sequence. */
	       mid = find_split(ct, ct[i]+1, ct[j]-1);	
	       if (mid < 0) {	/* No stems in between */
		  PushTracestack(dolist, AttachTrace(cur, dpT, ct[j], j, TRE));
		  PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[j]-1, TRE));
	       } else {		/* Cotains stems in between */
		  PushTracestack(dolist, AttachTrace(cur, dpT, ct[mid], j, TRE));
		  PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[mid]-1, TRE));
	       }
	       break;
	    case dpP:
	       cur->transition = TPN; cur->emitl = -1; cur->emitr = -1; 
	       PushTracestack(dolist, AttachTrace(cur, dpN, i, j, TRE));
	       break;
	    default:
	       printf ("ERROR: Can't have i paired, not to j in %s !\n", 
		     dpNAME[cur->nonterminal]);
	       break;
	 }
      }
   }

   FreeTracestack(dolist);
   free(ct);

   *ret_tr = tr;
}

/* Function: gatherStructStat
 * 
 * Purpose: Use traceback tree from RZK to gather
 *    various stats on given RNAs
 *
 * Args:
 *       seq   - sequence corresponding to the trace
 *       len   - length of the sequence
 *       wgt   - weight on the sequence (typically 1.0)
 *       tr    - traceback to count
 *       stats - categories in which to count data
 * 
 * Returns:  void
 */
void
gatherStructStat(char *seq, int len, char *name, struct trace_s *tr, 
      OPTS settings, SSINFO *stats)
{
   struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
   struct trace_s      *cur;     /* current node in the tree              */
   char *iseq;                   /* sequence with 0,1,2,3,4 in place of A,C,G,U,N */
   int  i, j, prvl, prvr;
   char left; char right;
   int wgt;

   wgt = 1;

   /* Digitize Sequence setup */
   SetAlphabet(hmmNUCLEIC);

   iseq = DigitizeSequence(seq, len);

   dolist = InitTracestack();
   PushTracestack(dolist, tr->nxtl);

   while ((cur = PopTracestack(dolist)) != NULL) {
      /* printf("(%#12x) %2d  %4d  %4d  %3d  %#10x  %#10x  \n",
      *              (int) cur, cur->nonterminal, cur->emitl, cur->emitr,
      *                           cur->transition, (int) cur->nxtl, (int) cur->nxtr); 
      *                                   fflush(stdout); 
      *                                           */
      if (cur->transition < NTRANS) {
	 if (cur->transition == TSE) {     /* do nothing on ENDS */
	    continue;

	    /* bifurcations */
	 } else if (cur->transition == TNB) { /* MT */
	    PushTracestack(dolist, cur->nxtr);
	    PushTracestack(dolist, cur->nxtl);
	 } else if (cur->transition == TTB) { /* TaPa' */
	    PushTracestack(dolist, cur->nxtr);
	    PushTracestack(dolist, cur->nxtl);
	    if ((iseq[cur->emitl] > ALPHA) && (iseq[cur->emitr] > ALPHA)) {
	       stats->pairs[ntX][ntX] += wgt;
	    } else if (iseq[cur->emitl] > ALPHA) {
	       stats->pairs[ntX][iseq[cur->emitr]] += wgt;
	    } else if (iseq[cur->emitr] > ALPHA) {
	       stats->pairs[iseq[cur->emitl]][ntX] += wgt;
	    } else {
	       stats->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += wgt;
	    }

	    /* Non-emitting transitions */
	 } else if ((cur->emitr == -1) && (cur->emitl == -1)) {
	    PushTracestack(dolist, cur->nxtl);

	 } else {
	    /* Count into loop composition matrix */
	    if (cur->nonterminal == dpN) {
	       /* i, j are indicies of P; not edges of this state! */
	       i = cur->emitl; j = cur->emitr;       
	       if (cur->transition == TNH) {
		  stats->hairpin[lpi(dist(i,j))] += wgt;
		  if (dist(i,j) >= MAXLOOPSIZE) stats->bigloops++;
		  if (dist(i,j) >= SSMAX) {
		     if (settings.verbose) {
			printf("Large Hairpin in %s; sized: %d\n", name, dist(i,j));
		     }
		  }
		  addLoopCounts(iseq, stats->hpcomp, i, j);
		  addLoopCounts(iseq, stats->singles, i, j);

	       } else if (cur->transition == TNL) {
		  prvl = cur->prv->emitl + 1;         /* Finding left edge! */
		  prvr = cur->prv->emitr - 1;
		  if (dist(prvl, i-1) >= MAXLOOPSIZE) stats->bigloops++;
		  if ((dist(prvl,i-1) >= SSMAX) || (dist(prvl,i-1) == 0)) {
		     if (settings.verbose) {
			printf("Large Left Bulge in %s; sized: %d (%d, %d)\n",
			      name, dist(prvl,i-1), prvl, i-1);
		     }
		  }

		  stats->bulge[lpi(dist(prvl, i-1))] += wgt;
		  if ((iseq[cur->emitl] < ALPHA) && (iseq[cur->emitr] < ALPHA)) {
		     stats->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += wgt;
		     if (dist(prvl, i-1) == 1) {
			if ((iseq[prvl] < ALPHA) && (iseq[prvr] < ALPHA)) {
			   stats->stack[idx(iseq[cur->emitl - 2],iseq[cur->emitr + 1])]\
			      [(iseq[cur->emitl])][(iseq[cur->emitr])] += wgt;
			}
			stats->onentbulge[iseq[i]] += wgt;
		     }
		  } else {
		  }
		  addLoopCounts(iseq, stats->bulgecomp, prvl, i-1);
		  addLoopCounts(iseq, stats->bulgeLcomp, prvl, i-1);
		  addLoopCounts(iseq, stats->singles, prvl, i-1);
		  PushTracestack(dolist, cur->nxtl);

	       } else if (cur->transition == TNR) {
		  prvl = cur->prv->emitl + 1;         /* Finding left edge! */
		  prvr = cur->prv->emitr - 1;         /* Finding right edge! */
		  if (dist(j+1, prvr) >= MAXLOOPSIZE) stats->bigloops++;
		  if ((dist(j+1,prvr) >= SSMAX) || (dist(j+1, prvr) == 0)){
		     if (settings.verbose) {
			printf("Large Right Bulge in %s; sized: %d\n", name, dist(j+1,prvr));
		     }
		  }

		  stats->bulge[lpi(dist(j+1, prvr))] += wgt;
		  if ((iseq[cur->emitl] < ALPHA) && (iseq[cur->emitr] < ALPHA)) {
		     stats->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += wgt;
		     if (dist(j+1, prvr) == 1) {
			if ((iseq[prvl] < ALPHA) && (iseq[prvr] < ALPHA)) {
			   stats->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 2])]\
			      [(iseq[cur->emitl])][(iseq[cur->emitr])] += wgt;
			}
			stats->onentbulge[iseq[j]] += wgt;
		     }
		  } else {
		  }
		  addLoopCounts(iseq, stats->bulgecomp, j+1, prvr);
		  addLoopCounts(iseq, stats->bulgeRcomp, j+1, prvr);
		  addLoopCounts(iseq, stats->singles, j+1, prvr);
		  PushTracestack(dolist, cur->nxtl);

	       } else if (cur->transition == TNI) {
		  prvl = cur->prv->emitl + 1; /* Finding left edge */
		  prvr = cur->prv->emitr - 1; /* Finding right edge */
		  if (dist(prvl, i-1) + (dist(j+1,prvr)) >= SSMAX) {
		     if (settings.verbose) {
			printf("Large Internal Loop in %s; sized: %d\n", name,
			      (dist(prvl, i-1) + dist(j+1,prvr)));
		     }
		  }
		  if (dist(prvl, i-1) == dist(j+1, prvr)) { stats->symmetric += wgt; }
		  else { stats->nonsymmetric += wgt; }
		  stats->loop[lpi(ilplen(prvl, i-1, j+1, prvr))] += wgt;
		  if ((iseq[cur->emitl] <= 4) && (iseq[cur->emitr] <= 4))
		     stats->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += wgt;
		  addLoopCounts(iseq, stats->intlpcomp, prvl, i-1);
		  addLoopCounts(iseq, stats->intlpcomp, j+1, prvr);
		  addLoopCounts(iseq, stats->singles, prvl, i-1);
		  addLoopCounts(iseq, stats->singles, j+1, prvr);
		  PushTracestack(dolist, cur->nxtl);
	       }
	    } else {        /* single stranded and pairs */
	       /* Emit to right */
	       if (cur->emitl == -1) {
		  if (iseq[cur->emitr] > ALPHA) {
		     /* Do nothing, contains an ambiguous base! */
		     stats->singles[ntX] += wgt;
		  } else {
		     stats->singles[iseq[cur->emitr]] += wgt;
		  }

		  /* Emit to left */
	       } else if (cur->emitr == -1) {
		  if (iseq[cur->emitl] > ALPHA) {
		     /* Do nothing, contains an ambiguous base! */
		     stats->singles[ntX] += wgt;
		  } else {
		     stats->singles[iseq[cur->emitl]] += wgt;
		  }

		  /* Emit aligned pair -- stacking model */
	       } else if (cur->nonterminal == dpP) {
		  if ((iseq[cur->emitl -1] > ALPHA) || (iseq[cur->emitr +1] > ALPHA)) {
		     /* Do nothing, contains an ambiguous base! */
		  } else {
		     stats->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
			[iseq[cur->emitl]][iseq[cur->emitr]] += wgt;
		     /* By also adding to pairs, it is like you are
		     *                * averaging the pair emissions over all pairs
		     *                               * (including stacks) */
		     stats->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += wgt;
		  }
		  /* Emit aligned pair -- no stacking */

	       } else {
		  if ((iseq[cur->emitl] > ALPHA) && (iseq[cur->emitr] > ALPHA)) {
		     stats->pairs[ntX][ntX] += wgt;
		  } else if (iseq[cur->emitl] > ALPHA) {
		     stats->pairs[ntX][iseq[cur->emitr]] += wgt;
		  } else if (iseq[cur->emitr] > ALPHA) {
		     stats->pairs[iseq[cur->emitl]][ntX] += wgt;
		  } else {
		     stats->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += wgt;
		  }
	       }
	       PushTracestack(dolist, cur->nxtl);
	    }
	 }
      } else {
	 PushTracestack(dolist, cur->nxtl);
      }
   }
   free(iseq);
   FreeTracestack(dolist);
}

/* Function: addLoopCounts
 * RDD, Tue Mar 23 19:23:03 CST 2004 [St Louis]
 * 
 * Purpose: Count background frequency within loops
 * 
 * Args:     
 *        rna     digitized sequence being analyzed
 *        counts  array in which to put counts (does not zero!)
 *        i       beginning position of loop 
 *        j       ending position of loop
 * 
 * Returns: nothing
 */
void
addLoopCounts(char *rna, int *counts, int i, int j) 
{
   int nt;

   for (nt = i; nt <= j; nt++) {
      if (rna[nt] > ALPHA) counts[ntX] += 1; 
      else if (rna[nt] == ntA) counts[ntA] += 1;
      else if (rna[nt] == ntC) counts[ntC] += 1;
      else if (rna[nt] == ntG) counts[ntG] += 1;
      else counts[ntU] += 1;
   }
}


