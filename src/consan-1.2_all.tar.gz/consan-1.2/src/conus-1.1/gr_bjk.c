/* gr_bjk.c
 * RDD, Tue Aug 12 12:59:13 CDT 2003 [St Louis]
 *
 * Implementations of the grammar specific functions for BJK 
 *
 * Thu Aug 23 17:19:01 2001 
 * Unamb.  :  S -> LS | L		(BJK)
 *            L -> aFa' | a
 *            F -> aFa' | LS
 *
 * Variation: BK2 uses stacking parameters for F -> F
 *
 * These implementations assume a digitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"

/*************************  CYK ********************************/
/* Function: cykInitBJK
 * Date:     Tue Aug 12 13:01:29 CDT 2003 [St Louis]
 *
 * Purpose:  Initialize CYK fill matrix for BJK grammar
 * Assumption: Fill matrix already allocated
 *
 * Args:     
 *	mx	fill matrix (integer log odds form)
 *	model 	parameters (integer log form or as scores)
 *	rna	sequence (digitized)
 *	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cykInitBJK(int ***mx, INTMOD *model, char *rna, int len)
{
  int j, d;

  for (d = 0; d <= len; d++) {
     for (j = (d > 0? d-1: d); j < len; j++) {
	mx[dpS][j][d] = -BIGINT;	/* Prohibited */
	mx[dpL][j][d] = -BIGINT;
	mx[dpF][j][d] = -BIGINT;
     } /* end for j */
  } /* end for i */
}

/* Function: cykFillBJK
 * Date:     Tue Aug 12 13:02:14 CDT 2003 [St Louis]
 *
 * Purpose:  Fills CYK matrix for BJK grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	sc	parameters 
 *		(integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
cykFillBJK (int ***mx, INTMOD *pr, char *rna, int len, int grammar)
{
  int d, i, j, k;       /* Loop indicies */
  int max;              /* Maximum value seen so far */
  int cursc, cursc2;    /* Current score */
  int stackvalue;

  /* Recursion */
  for (d = 1; d <= len; d++) {
     for (j = d-1; j < len; j++) {
	i = j - d + 1; max = -BIGINT;

	/* L -> aFb | a */
	if (d == 1) {
	   cursc = pr->singles[rna[i]] + pr->transitions[TLA];
	   if (cursc > max) max = cursc;
	}
	cursc = -BIGINT;
	if ((j > 0) && (d > 1)) {
	   if (lplen(i,j) >= HLEN) 
	     cursc = mx[dpF][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TLF];
	}
	if (cursc > max) max = cursc;
	mx[dpL][j][d] = max;

	/* S -> L */
	max = -BIGINT;
	cursc = mx[dpL][j][d] + pr->transitions[TSL];
	if (cursc > max) max = cursc; 

	/* S -> LS */
	for (k = i; k < j; k++) {
	   cursc = mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] 
	      + pr->transitions[TSB];
	   if (cursc > max) max = cursc;
	}

	/* S -> LS | L */
	mx[dpS][j][d] = max;

	/* F -> aFa' | LS */
	max = -BIGINT;

	cursc = -BIGINT;
	if ((j > 0) && (d > 1)) {
	   if (lplen(i,j) >= HLEN) {
	      if (grammar == BK2) {
		 /* Can't stack at edges!  */
		 if ((i == 0) || (j == len-1)) {
		    stackvalue = -BIGINT;
		 } else {
		    stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]];
		 }
		 cursc = mx[dpF][j-1][d-2] + stackvalue + pr->transitions[TFF];
	      } else {
		 cursc = mx[dpF][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
		    + pr->transitions[TFF];
	      }
	   }
	} 
	if (cursc > max) max = cursc;

	/* F -> LS */
	for (k = i; k < j; k++) {
	   cursc = mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] + pr->transitions[TFB];
	   if (cursc > max) max = cursc;
	}
        mx[dpF][j][d] = max;

    } /* End for loop */
  } /* End foreach n */
}

/* Function: cykTraceBJK 
 * Date:     Tue Aug 12 13:20:04 CDT 2003 [St Louis]
 *
 * Purpose:  Build traceback tree for scoring B. Knudsen's Pfold grammar 
 *
 * Args:
 *	mx	matrix in which to calculate cyk
 *	pr	parameters in integer form
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns: traceback tree
 */
struct trace_s *
cykTraceBJK (int ***mx, INTMOD *pr, char *rna, int len, int grammar)
{
  int d, i, j, k, mtx;   /* Indices */
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (len -1), TRE));

  /* Repeat until stack is empty */
  while (curr = PopTracestack(stack)) {
    /* Set i and j from items in stack */
    i = curr->emitl; j = curr->emitr; mtx = curr->nonterminal;
    d = j - i + 1;

    if (mtx == dpS) {
      if ((mx[dpL][j][d] + pr->transitions[TSL]) == mx[dpS][j][d]) {
        curr->emitr = -1; curr->emitl = -1; curr->transition = TSL; 
        PushTracestack(stack, AttachTrace (curr, dpL, i, j, TRE));
      } else {
          for (k = i; k < j; k++) {
            if ((mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)]
		     + pr->transitions[TSB]) == mx[dpS][j][d]) {
	      curr->emitl = -1; curr->emitr = -1; curr->transition = TSB;
              PushTracestack(stack, AttachTrace (curr, dpS, k+1, j, TRE));
              PushTracestack(stack, AttachTrace (curr, dpL, i, k, TRE));
	      k = j;	/* Short circuit */
            } /* End if */
          } /* End for (bifurcation points) */
      } /* end if (S -> L | LS) */
    } else if (mtx == dpL) {
      if (d == 1) {
	 curr->emitr = -1; curr->transition = TLA;
      } else {
	 curr->transition = TLF;
	 PushTracestack(stack, AttachTrace (curr, dpF, i+1, j-1, TRE));
      }
    } else if (mtx == dpF) {
       if ((grammar == BJK) && (lplen(i,j) >= HLEN) &&
	     (mx[dpF][j-1][d-2] + pr->transitions[TFF] 
		+ pr->pairs[rna[i]][rna[j]]) == mx[dpF][j][d]) {
	  curr->transition = TFF;
	  PushTracestack(stack, AttachTrace (curr, dpF, i+1, j-1, TRE));
       } else if ((grammar == BK2) && ((mx[dpF][j-1][d-2] + pr->transitions[TFF] 
		   + pr->stack[idx(rna[i-1], rna[j+1])][rna[i]][rna[j]]) 
		== mx[dpF][j][d])) {
	  curr->transition = TFF;
	  PushTracestack(stack, AttachTrace (curr, dpF, i+1, j-1, TRE));
       } else {
	  for (k = i; k < j; k++) {
	     if ((mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)]
		      + pr->transitions[TSB]) == mx[dpS][j][d]) {
		curr->emitl = -1; curr->emitr = -1; curr->transition = TFB;
		PushTracestack(stack, AttachTrace (curr, dpS, k+1, j, TRE));
		PushTracestack(stack, AttachTrace (curr, dpL, i, k, TRE));
		k = j;	/* Short circuit */
	     } /* End if */
	  } /* End for (bifurcation points) */
       } /* end if (F -> aFa' | LS) */
    } else {		
       printf("ERROR!! Nonterminal %d unknown in traceback!\n", mtx);
    } /* End if dpS, dpL or dpR */
  } /* end while stack not empty*/
  FreeTracestack(stack);
  return parsetree;
}

/***************************** TRAIN ********************************/
/* Function: khs2traceBJK
 * Date:     Tue Aug 12 13:39:49 CDT 2003 [St Louis]
 *
 * Purpose: Convert KHS to traceback tree properly 
 * 	labeled for BJK grammar.
 *
 * Args:     
 *	dolist  Traceback tree to build from KHS	
 *	ct	KHS info represented as ct format
 */
int
khs2traceBJK(struct tracestack_s *dolist, int *ct)
{
  struct trace_s      *cur;
  struct trace_s      *tr;
  struct trace_s      *prv, *nxt;
  char left; char right;
  int  i,j, mid, error;

  error = FALSE;
  while ((cur = PopTracestack(dolist)) != NULL) {
    i = cur->emitl;           /* 0..len-1 */
    j = cur->emitr;           /* 0..len-1 */

    if (ct[i] == -1) {   /* i unpaired; single strand left */
       if (cur->nonterminal == dpF) {
	  cur->transition = TFB; cur->emitl = -1; cur->emitr = -1;
	  PushTracestack(dolist, AttachTrace(cur, dpS, i+1, j, TRE));
	  PushTracestack(dolist, AttachTrace(cur, dpL, i, i, TRE));
       } else if (cur->nonterminal == dpL) {
	  cur->transition = TLA; cur->emitr = -1;
       } else {	/* dpS */
	  if (i == j) {	/* single nt */
	     cur->transition = TSL; cur->emitr = -1; cur->emitl = -1;
	     PushTracestack(dolist, AttachTrace(cur, dpL, i, j, TRE));
	  } else {
	     cur->transition = TSB; cur->emitr = -1; cur->emitl = -1;
	     PushTracestack(dolist, AttachTrace(cur, dpS, i+1, j, TRE));
	     PushTracestack(dolist, AttachTrace(cur, dpL, i, i, TRE));
	  }
       }
    } else if (ct[i] == j) {    /* i,j paired to each other */
       if (i+2 >= j) { 
	  /* printf("TRACEBACK ILLEGAL\n");  */
	  return 0; 
       }
       if (cur->nonterminal == dpS) {
	  cur->transition = TSL; cur->emitr = -1; cur->emitl = -1;
	  PushTracestack(dolist, AttachTrace(cur, dpL, i, j, TRE));
       } else {
	  if (cur->nonterminal == dpL) {
	     cur->transition = TLF;
	  } else {
	     cur->transition = TFF;
	  }
	  PushTracestack(dolist, AttachTrace(cur, dpF, i+1, j-1, TRE));
       }
    } else {            /* i,j paired but not to each other */
       if (cur->nonterminal == dpS) {
	  cur->transition = TSB;
       } else {
	  cur->transition = TFB;
       }
       cur->emitl = -1; cur->emitr = -1;
       PushTracestack(dolist, AttachTrace(cur, dpS, ct[i]+1, j, TRE));
       PushTracestack(dolist, AttachTrace(cur, dpL, i, ct[i], TRE));
    }
  }   /* while something's on dolist stack */
  if (error) return 0; 
  return 1;
}

/* Function: analyzeTraceBJK
 * Date:     Tue Aug 12 14:31:44 CDT 2003 [St Louis]
 *
 * Purpose: Parse a traceback tree for information.
 *	Either for counts (training).
 *	Or for determining tracebcak score.
 *
 * Args:     
 *      seq   - sequence corresponding to the trace
 *      len   - length of the sequence
 *      tr    - traceback to count
 *      cfg   - model, counts form, to add counts to
 *      count - if TRUE this is TraceCount; 
 *		if FALSE this is TraceScore
 *
 * Returns:  score of current traceback (in TraceScore mode)
 * 	Should return zero in TraceCount mode
 */
int
analyzeTraceBJK(char *seq, int len, struct trace_s *tr, INTMOD *cfg, 
      	int grammar, int count) 
{
  struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
  struct trace_s      *cur;     /* current node in the tree              */
  char *iseq;                   
  int   cst, nst, j;
  char left; char right;
  int score;

 /* Digitize Sequence setup */
   SetAlphabet(hmmNUCLEIC);

  iseq = DigitizeSequence(seq, len);

  dolist = InitTracestack();
  PushTracestack(dolist, tr->nxtl);

  score = 0; 

  while ((cur = PopTracestack(dolist)) != NULL) {
     if (cur->transition < NTRANS) {

	if (count) cfg->transitions[cur->transition] += 1;
	else score += cfg->transitions[cur->transition];

	/* bifurcations */
	if ((cur->transition == TSB) || (cur->transition == TFB)) {
	   PushTracestack(dolist, cur->nxtr);
	   PushTracestack(dolist, cur->nxtl);
	}
	/* Non emitting states */
	else if ((cur->emitl == -1) && (cur->emitr == -1)) {
	   PushTracestack(dolist, cur->nxtl);
	}
	else {
	   if (cur->emitr == -1) {
	      if (iseq[cur->emitl] > ALPHA) {
		 /* Do nothing, contains an ambiguous base! 
		  * Therfore must back out of counting transition!
		  */
		 if (count) cfg->transitions[cur->transition] -= 1;
	      } else {
		 if (count) cfg->singles[iseq[cur->emitl]] += 1;
		 else score += cfg->singles[iseq[cur->emitl]];
	      }

	      /* Emit aligned pair -- no stacking; must go to F state  */
	   } else {
	      if ((iseq[cur->emitl] > ALPHA) || (iseq[cur->emitr] > ALPHA)) {
		 /* Do nothing, contains an ambiguous base! 
		  * Therfore must back out of counting transition!
		  */
		 if (count) cfg->transitions[cur->transition] -= 1;
	      } else {
		 if (grammar == BJK) {
		    if (count) cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
		    else score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
		 } else {
		    if (cur->nonterminal == dpL) {
		       if (count) cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
		       else score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
		    } else {	/* TFF is stacking in BK2 */
		       if ((iseq[cur->emitl - 1 ] > ALPHA) || (iseq[cur->emitr + 1] > ALPHA)) {
		       } else {
			  if (count) {
			     cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
				[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
			     /* cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1; */
			  } else {
			     score += cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
				[iseq[cur->emitl]][iseq[cur->emitr]];
			  }
		       }
		    }
		 }
	      }
	      PushTracestack(dolist, cur->nxtl);
	   }
	}
     } else {
	PushTracestack(dolist, cur->nxtl);
     }
  }
  free(iseq);
  FreeTracestack(dolist);
  return score;
}
/* Function: dTraceScoreBJK 
 * Date:     Mon Oct 27 16:43:12 CST 2003 [St Louis]
 *
 * Purpose: Parse a traceback tree for determining 
 * 	tracebcak score as float log. [Used in 
 * 	ambiguity check.]
 *
 * Args:     
 *      seq   - sequence corresponding to the trace
 *      len   - length of the sequence
 *      tr    - traceback to count
 *      grammar - BJK or BK2
 *      cfg   - model (float log form)
 *      ret_val - score of traceback in float log
 *
 * Returns:  void 
 */
void
dTraceScoreBJK(char *seq, int len, struct trace_s *tr, PROBMOD *cfg, int grammar, 
      double *ret_val) 
{
  struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
  struct trace_s      *cur;     /* current node in the tree              */
  char *iseq;                   
  int   cst, nst, j;
  char left; char right;
  double score;

 /* Digitize Sequence setup */
   SetAlphabet(hmmNUCLEIC);

  iseq = DigitizeSequence(seq, len);

  dolist = InitTracestack();
  PushTracestack(dolist, tr->nxtl);

  score = 0.; 

  while ((cur = PopTracestack(dolist)) != NULL) {
     if (cur->transition < NTRANS) {

	score += cfg->transitions[cur->transition];

	/* bifurcations */
	if ((cur->transition == TSB) || (cur->transition == TFB)) {
	   PushTracestack(dolist, cur->nxtr);
	   PushTracestack(dolist, cur->nxtl);
	}
	/* Non emitting states */
	else if ((cur->emitl == -1) && (cur->emitr == -1)) {
	   PushTracestack(dolist, cur->nxtl);
	}
	else {
	   /* Emit to left (single base, this ends this branch) */
	   if (cur->emitr == -1) {
	      if (iseq[cur->emitl] > ALPHA) {
		 /* Do nothing, contains an ambiguous base!  */
	      } else {
		 score += cfg->singles[iseq[cur->emitl]];
	      }

	      /* Emit aligned pair -- no stacking; must go to F state  */
	   } else {
	      if (grammar == BJK) {
		 score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	      } else {
		 if (cur->nonterminal == dpL) {
		    score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
		 } else {	/* TFF is stacking in BK2 */
		       score += cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
			  [iseq[cur->emitl]][iseq[cur->emitr]];
		 }
	      }
	      PushTracestack(dolist, cur->nxtl);
	   }
	}
     } else {
	PushTracestack(dolist, cur->nxtl);
     }
  }
  free(iseq);
  FreeTracestack(dolist);
  *ret_val = score;
}

/*************************** cond Inside **********************************/
/* Function: cinsInitBJK
 * Date:     Tue Aug 12 13:01:29 CDT 2003 [St Louis]
 *
 * Purpose:  Initialize CYK fill matrix for BJK grammar
 * Assumption: Fill matrix already allocated
 *
 * Args:     
 *	mx	fill matrix (integer log odds form)
 *	model 	parameters (integer log form or as scores)
 *	rna	sequence (digitized)
 *	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cinsInitBJK(double ***mx, PROBMOD *model, char *rna, int len)
{
  int j, d;

  for (d = 0; d <= len; d++) {
     for (j = (d > 0? d-1: d); j < len; j++) {
	mx[dpS][j][d] = -BIGFLOAT;	/* Prohibited */
	mx[dpL][j][d] = -BIGFLOAT;
	mx[dpF][j][d] = -BIGFLOAT;
     } /* end for j */
     if (d > 0) {
	mx[dpS][d-1][d] = -BIGFLOAT;	/* Prohibited */
	mx[dpL][d-1][d] = -BIGFLOAT;
	mx[dpF][d-1][d] = -BIGFLOAT;
     }
  } /* end for i */
}

/* Function: cinsFillBJK
 * Date:     Fri Oct  3 16:02:13 CDT 2003 [St Louis]
 *
 * Purpose:  Fills CYK matrix for BJK grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	sc	parameters 
 *		(integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
cinsFillBJK (double ***mx, PROBMOD *pr, char *rna, int len, int grammar, int *ss)
{
  int d, i, j, k;       /* Loop indicies */
  double cursc, cursc2;    /* Current score */
  double stackvalue;

  /* Recursion */
  for (d = 1; d <= len; d++) {
     for (j = d-1; j < len; j++) {
	i = j - d + 1; 

	/* L -> aFa' | a */
	cursc = -BIGFLOAT;
	if (d == 1) { 
	   if (ss[i] == -1) {
	      cursc = pr->singles[rna[i]] + pr->transitions[TLA];
	   }
	}
	if (ss[i] == j) {
	   if ((j > 0) && (d > 1)) {
	      cursc = DLogsum(mx[dpF][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
		 + pr->transitions[TLF], cursc);
	   }
	}
	mx[dpL][j][d] = cursc;

	/* S -> LS | L */
	cursc = mx[dpL][j][d] + pr->transitions[TSL];

	for (k = i; k < j; k++) {
	   cursc = DLogsum(mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] 
	      + pr->transitions[TSB], cursc);
	}
	if (cursc < -BIGFLOAT) cursc = -BIGFLOAT;
	mx[dpS][j][d] = cursc;

	/* F -> aFa' | LS */
	cursc = -BIGFLOAT;

	if (ss[i] == j) {
	   if ((j > 0) && (d > 1)) {
	      if (grammar == BK2) {
		 if ((i == 0) || (j == len-1)) {
		    stackvalue = -BIGINT;
		 } else {
		    stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]];
		 }
		 cursc = mx[dpF][j-1][d-2] + stackvalue + pr->transitions[TFF];
	      } else {
		 cursc = mx[dpF][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
		    + pr->transitions[TFF];
	      }
	   }
	}
	for (k = i; k < j; k++) {
	   cursc = DLogsum(mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] 
		 + pr->transitions[TFB], cursc);
	}
        mx[dpF][j][d] = cursc;

    } /* End for loop */
  } /* End foreach n */
}

/* Function: generateBJK 
 * Date:     Wed Oct  8 13:51:10 CDT 2003 [St Louis]
 *
 * Purpose: generate a sequence from the grammar
 *
 * Args:    
 * 	pr 	parameters to utilize (as probs)
 *	ret_rna	sequence generated 
 * 	ret_ss	sequence structure
 *
 * Returns:  length of generated sequence 
 */
int
generateBJK(PROBMOD *pr, char **ret_rna, char **ret_ss)
{
   int length, index, i, j;
   struct gstack_s *gstack;	/* Traversal of grammar */
   struct gstack_s *gstring;	/* String generated */
   struct gnode_s *curr;

   char *stg;		/* String generated */
   char *ssg;		/* Sec struct generated */
   double roll;		/* Random number generated */
   int eidx, ei, ej;		/* emission index */
   double pairs[PAIRS];	/* pair emissions vector */

   /* Generate pair emissions vector */
   for (i = 0; i < ALPHA; i++) {
      for (j = 0; j < ALPHA; j++) {
	 pairs[idx(i,j)] = pr->pairs[i][j];
      }
   }

   /* Initialization of Traceback stuff */
   gstack = InitGstack();
   gstring = InitGstack();

   PushGstack(gstack, NewNode(dpS, '\0', TRUE));
   length = 0;

   /* Repeat until stack is empty */
   while (curr = PopGstack(gstack)) {
      /* if Nonterminal, use parameters to pick a rule */
      if (curr->nonterminal) {
	 /* Figure out which rule to utilize */
	 roll = sre_random();

	 if (curr->esymbol == dpS) {
	    if (roll <= pr->transitions[TSB]) {
	       PushGstack(gstack, NewNode(dpS, '\0', TRUE));
	       PushGstack(gstack, NewNode(dpL, '\0', TRUE));
	    } else {	/* TSL */
	       PushGstack(gstack, NewNode(dpL, '\0', TRUE));
	    }
	 } else if (curr->esymbol == dpL) {
	    if (roll <= pr->transitions[TLF]) {
	       eidx = DLog2Choose(&pairs, PAIRS);
	       ei = eidx%ALPHA; ej = eidx/ALPHA;
	       PushGstack(gstack, NewNode(ej, '<', FALSE));
	       PushGstack(gstack, NewNode(dpF, '\0', TRUE));
	       PushGstack(gstack, NewNode(ei, '>', FALSE));
	    } else {	/* TFA */
	       eidx = DLog2Choose(pr->singles, ALPHA);
	       PushGstack(gstack, NewNode(eidx, '.', FALSE));
	    }
	 } else {	/* dpF */
	    if (roll <= pr->transitions[TFF]) {
	       eidx = DLog2Choose(&pairs, PAIRS);
	       ei = eidx/ALPHA; ej = eidx%ALPHA;
	       PushGstack(gstack, NewNode(ej, '<', FALSE));
	       PushGstack(gstack, NewNode(dpF, '\0', TRUE));
	       PushGstack(gstack, NewNode(ei, '>', FALSE));
	    } else {	/* TFB */
	       PushGstack(gstack, NewNode(dpS, '\0', TRUE));
	       PushGstack(gstack, NewNode(dpL, '\0', TRUE));
	    }
	 }
      /* if an emission, add it to the growing string */
      } else {
	 length++;
	 /* Add this symbol (a nonterminal) to the growing string */
	 PushGstack(gstring, curr);
      }
   }
   /* Done with stack */
   FreeGstack(gstack);

  /* Allocate a string of the appropriate length */
  if ((stg = (char *) malloc (sizeof(char) * (length+1))) == NULL)
       Die("No room for the generated string!");
  if ((ssg = (char *) malloc (sizeof(char) * (length+1))) == NULL)
       Die("No room for the generated structure !");
  /* Fill the allocated strings from the growing string stack */
  index = length;
  stg[index] = '\0'; ssg[index] = '\0';
   while (curr = PopGstack(gstring)) {
      index--;
      if (curr->esymbol == 0) stg[index] = 'A';
      else if (curr->esymbol == 1) stg[index] = 'C';
      else if (curr->esymbol == 2) stg[index] = 'G';
      else stg[index] = 'U';
      if (curr->ess == '.') ssg[index] = '.';
      else if (curr->ess == '>') ssg[index] = '>';
      else ssg[index] = '<';
   }
   if (index != 0) printf("Index did not decrement correctly!");
   /* Clear allocated memory for growing string */
   FreeGstack(gstring);

   *ret_rna = stg;
   *ret_ss = ssg;

   return (length);
}

