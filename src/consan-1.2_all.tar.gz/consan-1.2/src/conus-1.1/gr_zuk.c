/* gr_zuk.c
 * Wed Aug 20 13:57:06 CDT 2003 [St Louis]
 *
 * Grammar specific routines for implementing the ZUK grammar.
 *
 * Zuker's original 1981 grammar:
 * 	W -> aVa' | aW | Wa | WW 
 * 	X -> aVa' | aX | Xa | XX
 * 	V -> a...a | a...aVa'...a | XX
 * Note that X is W_b in Zuker and Elena's papers.
 * See Elena's RNAscan for implementational aids.
 *
 * These implementations assume a digitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"

/* Function: cykInitZ
 * Date:     
 *
 * Purpose:  Initialize CYK fill matrix for ZUK 
 *
 * Args:     
 *	mx	fill matrix (integer log odds form)
 * 	len	sequence length
 *      grammar which grammar to utilize
 *
 * Returns:  -- void -- 
 */
void
cykInitZ(int ***mx, INTMOD *model, char *rna, int len, int grammar)
{
  int i,j,k;

  for (i=0; i < len; i++) {
    for (j=0; j < len; j++) {
      for (k=0; k < NDPS; k++) {
	/* Diagonals of matricies */
	if (i == j) {
	} else {
	}
      } /* end for k */
    } /* end for j */
  } /* end for i */
}

/* Function: cykFillZ
 * Date:     
 *
 * Purpose:  Fills CYK matrix for ZUK grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	sc	parameters 
 *		(integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *      grammar which grammar to utilize
 *
 * Returns:  void 
 */
void
cykFillZ(int ***mx, INTMOD *pr, char *rna, int len, int grammar)
{
  int n, i, j, k, l;       /* Loop indicies */
  int max;              /* Maximum value seen so far */
  int cursc, cursc2;    /* Current score */
  int stackvalue;	

  /* Recursion */
  for (n = 1; n < len; n++) {
    for (i = 0; i < (len - n); i++) {
      j = i + n;  max = -BIGINT;

    }
  }
}

/* Function: cykTraceZ
 * Date:     
 *
 * Purpose:  Build traceback tree for ZUK grammar
 *
 * Args:
 *	mx	matrix in which to calculate cyk
 *	pr	parameters in integer form
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns: --void --
 */
struct trace_s *
cykTraceZ(int ***mx, INTMOD *pr, char *rna, int len, int grammar)
{
  int i, j, k, l, mtx;   /* Indices */
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (len -1), TRE));

  /* Repeat until stack is empty */
  while (curr = PopTracestack(stack)) {
    /* Set i and j from items in stack */
    i = curr->emitl; j = curr->emitr; mtx = curr->nonterminal;

    if (i > j) { 		/* Can this happen? */
    } else {
      printf("ERROR!! Nonterminal %d unkown in RUN/RYN traceback!\n", mtx);
    }
  }
  return parsetree;
}

void
khs2traceZUK(struct tracestack_s *dolist, int *ct, int grammar)
{
}

int
analyzeTraceZ(char *seq, int len, struct trace_s *tr, INTMOD *cfg, int count)
{
   return 0;
}

