/* stk2ct_main.c */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"

static char optsline[]  = "\
";

static char usage[]  = "Usage: givect [-options] <seqfile in>\n";

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;

  FILE *ofp, *ifp;

  /* ReadSeq variables */
  SQFILE *sqfp; SQINFO sqinfo;
  int sformat;
  char *rna; 
  char *ss; 
  int *ctstruct; 
  int score, returned;
  int *ctinfo;

  /* Models info */
  MODEL nusmodel;
  struct trace_s *trc;

  if (!(ProcessOpts(&settings, &optid, argc, argv, usage, "", optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  if (argc - optid != 1)
    Die("Incorrect number of command line arguments.\n%s\n%s\n", usage, optsline);

  SetupModel(&settings, &nusmodel);
  LogifySCFG(&(nusmodel.probs), &(nusmodel.scores));
  
  /* Digitize Sequence Setup*/
  SetAlphabet(hmmNUCLEIC);
  if (settings.parameterout) PrintFullModel(settings.ofp, &nusmodel);

  /* Read input file into RNA array and filter for non-RNA residues */
  if ((sqfp = SeqfileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL) 
    Die("Failed to open sequence file %s\n%s\n", argv[optid], usage);

  while (ReadSeq(sqfp, sformat, &rna, &sqinfo)) {
    ToRNA(rna);

    if (settings.verbose) fprintf(settings.ofp, "Sequence %s:\n", sqinfo.name);

    KHS2ct(sqinfo.ss, sqinfo.len, FALSE, &ctinfo);
    Print_CT(settings.ofp, rna, sqinfo.len, ctinfo, sqinfo.name);


    /* Cleanup  */
    free(ss);
    FreeTrace(trc);
    FreeSequence(rna, &sqinfo);
  }
  SeqfileClose(sqfp);
}
