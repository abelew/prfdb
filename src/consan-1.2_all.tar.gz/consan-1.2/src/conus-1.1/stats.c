/* stats.c
 * Routines for gathering structure comparative statistics
 */

#include<string.h>
#include<ctype.h>

#include"squid.h"

#include"cfg.h"
#include"options.h"
#include"stats.h"

/* Function: CompStruct
 * Date:  RDD, Thu Nov 15 17:51:38 2001 [St. Louis]
 *  Modified from SQUID's compstruct_main.c [SRE]
 *
 * Purpose:  Compare a predicted (test) structure to
 * 	a given (trusted) structure.  Collect statistics
 * 	about accuracy of prediction.
 *
 * Args:     
 * 	len		Length of alignment
 * 	trusted		given structure
 * 	test		predicted structure
 * 	totals		Where to store totals
 * 			(add to existing numbers)
 * 	iseq		Flag for verbose output.
 * 	do_mathews	Turn on Mathews +/- method of evaluation bp
 * 	ct_knots	Turn on knots as bases in structure
 *
 * Returns:  
 * 	TRUE		if comparison executed correctly
 * 	FALSE		if problem with either KHS formatted structure
 *
 * 	totals		is filled (adds to current values in totals)
 */
int
CompStruct (int len, char *trusted, char *test, STATS *totals, 
      int iseq, int do_mathews, int ct_knots) 
{   
   int *trusted_ct;  int *test_ct;
   int pos;

   int kpairs;         /* count of base pairs in a known (trusted) structure     */
   int tpairs;         /* count of base pairs in a test (predicted) structure    */
   int kcorrect;       /* # bp in a known structure that are correctly predicted */
   int tcorrect;       /* # bp in a test structure that are true                 */

   int tot_kpairs;     /* total base pairs in all known structures               */
   int tot_tpairs;     /* total base pairs in all predicted structures           */
   int tot_kcorrect;   /* total correctly predicted pairs in all known structures*/
   int tot_tcorrect;   /* total true pairs in all test structures                */
   int tot_positions;  /* total # of bases                                       */

   float sensitivity, specificity;

  if (! KHS2ct(trusted, len, ct_knots, &trusted_ct)) { 
     printf("[bad trusted structure]\n"); 
     free(trusted_ct); return (FALSE);
  }
  if (! KHS2ct(test, len, ct_knots, &test_ct)) { 
     printf("[bad predicted/test structure]\n"); 
     free(test_ct); free(trusted_ct); 
     return (FALSE); 
  }

  tpairs = tcorrect = 0;	/* Test Structure */
  kpairs = kcorrect = 0;	/* Trusted Structure */

  for (pos = 0; pos < len; pos++) {
     /* Sensitivity */
     if (trusted_ct[pos] > pos) {	/* Known bp in trusted seq */
	kpairs++;
	if (do_mathews) {
	   if (test_ct[pos] == trusted_ct[pos] ||		 	/* i,j */
		 (pos > 0  && test_ct[pos-1] == trusted_ct[pos]) ||	/* i-1, j */
		 (pos < len  && test_ct[pos+1] == trusted_ct[pos]) ||	/* i+1, j */
		 (test_ct[pos] > 0 && test_ct[pos] == trusted_ct[pos]-1) || /* i, j-1 */
		 (test_ct[pos] > 0 && test_ct[pos] == trusted_ct[pos]+1))  /* i, j+1 */
	      kcorrect++;
	} else {
	   if (test_ct[pos] == trusted_ct[pos] ) kcorrect++;
	}
     }
     /* PPV */
     if (test_ct[pos] > pos) {	/* Known bp in test seq */
	tpairs++;
	if (do_mathews) {
	   if (trusted_ct[pos] == test_ct[pos] ||		 	/* i,j */
		 (pos > 0  && trusted_ct[pos-1] == test_ct[pos]) ||	/* i-1, j */
		 (pos < len  && trusted_ct[pos+1] == test_ct[pos]) ||	/* i+1, j */
		 (trusted_ct[pos] > 0 && trusted_ct[pos] == test_ct[pos]-1) || /* i, j-1 */
		 (trusted_ct[pos] > 0 && trusted_ct[pos] == test_ct[pos]+1))  /* i, j+1 */
	      tcorrect++;
	} else {
	   if (trusted_ct[pos] == test_ct[pos] ) tcorrect++;
	}
     }
  }

     /* Note: Under default rule tcorrect = kcorrect; but not necessarily
      * the case under relaxed mathews criteria */

     totals->trust_pairs += kpairs;
     totals->test_pairs += tpairs;

     totals->trust_correct += kcorrect;
     totals->test_correct += tcorrect;

     totals->nseq++; 
     totals->positions += len;

  /* Gather Range data */
  sensitivity = 100. * (float) kcorrect/ (float) kpairs;
  if (sensitivity < totals->sens_min) totals->sens_min = sensitivity;
  if (sensitivity > totals->sens_max) totals->sens_max = sensitivity;

  specificity = 100. * (float) tcorrect/ (float) tpairs;
  if (specificity < totals->spec_min) totals->spec_min = specificity;
  if (specificity > totals->spec_max) totals->spec_max = specificity;

  /* print out per sequence info */
  if (iseq) {
     printf(" ==  %.2f  %.2f\n", sensitivity, specificity);
     printf("   %d/%d trusted pairs correctly predicted (%.2f%% sensitivity)\n",
	   kcorrect, kpairs, sensitivity);
     printf("   %d/%d predicted pairs are true (%.2f%% PPV/specificity)\n",
	   tcorrect, tpairs, specificity);
     puts("");
  }

  free(test_ct); free(trusted_ct); 

  return 1;
}

/* Function: PrintTableHeader
 * Date:     RDD, Sat Dec  8 16:28:29 2001 [St. Louis]
 *
 * Purpose:  Print header for permutation test table
 *
 * Note: This header assumes PrintTableLine is
 * 	used to produce each line of statistics.  This
 * 	allows computation to occur between lines.  However,
 * 	it does make the output table "break" if verbose 
 * 	outputs are requested as they will interrupt the table.
 */
void
PrintTableHeader()
{
  printf("\nDataset\t\t\tSeqs\tPositions\tSens\tMin\tMax\tSpec\tMin\tMax\tCval\tAcc\tMin\tMax\n");
  printf("========\t\t====\t=========\t====\t===\t===\t====\t===\t===\t====\t===\t===\t===\n");
}

/* Function: PrintTableLine
 * Date:     RDD, Sat Dec  8 16:28:36 2001 [St. Louis]
 *
 * Purpose:  Print a single line for each set of stats gathered.
 *
 * Args:     
 * 	label		A string label for this line.
 * 	statistics	Gathered pos/neg numbers for test 
 * 	
 * Note: This is assumed to be used with PrintTableHeader.
 * 	This allows computation to occur between lines.  However,
 * 	it does make the output table "break" if verbose 
 * 	outputs are requested as they will interrupt the table.
 */
void
PrintTableLine (char * label, STATS statistics, int outputrange)
{
   float sens, spec, cval;
   char outlabel[25];
   int i, len;
   char *tmp;

   sens = 100. * (float) statistics.trust_correct/ (float) statistics.trust_pairs;
   spec = 100. * (float) statistics.test_correct / (float) statistics.test_pairs;
   cval = sqrt(sens*spec);

   /* Could format output depending on size of test sets */
   if (outputrange) {
      /* Format Dataset name to fit in our output dimensions */
      len = strlen(label);
      if (len > 20) {
        tmp = &(label[(len-20)]);
      } else {
	 tmp = label;
      }
      strncpy(outlabel, tmp, 20);
      outlabel[21] = '\0';
      
      printf("%-20s\t%5d\t%8d\t%.2f%%\t%.2f%%\t%.2f%%\t%.2f%%\t%.2f%%\t%.2f%%\t%.2f%%\n",
	    outlabel, statistics.nseq, statistics.positions, 
	    sens, statistics.sens_min, statistics.sens_max,
	    spec, statistics.spec_min, statistics.spec_max, cval);
   } else {
      printf("%-20s\t%5d\t%8d\t%.2f%%\t   \t   \t%.2f%%\t   \t   \t%.2f%%\n",
	    label, statistics.nseq, statistics.positions, 
	    sens, spec, cval);
   }
}

/* Function: accumulateStats 
 * Date:     RDD, Sat Dec  8 16:28:49 2001 [St. Louis]
 *
 * Purpose:  set contents of STAT structre to zero.
 */
void
accumulateStats (STATS *newtotals, STATS *globals)
{
  globals->nseq = globals->nseq + newtotals->nseq;
  globals->Nfree = globals->Nfree + newtotals->Nfree;
  globals->containN = globals->containN + newtotals->containN;

  globals->positions = globals->positions + newtotals->positions;
  globals->trust_pairs = globals->trust_pairs + newtotals->trust_pairs;
  globals->test_pairs = globals->test_pairs + newtotals->test_pairs;
  globals->test_correct = globals->test_correct + newtotals->test_correct;
  globals->trust_correct = globals->trust_correct + newtotals->trust_correct;
}

/* Function: PrintTotals
 * Date:     RDD, Thu Nov 15 17:51:47 2001 [St. Louis]
 *
 * Purpose:  Print test set totals in paragraph format.
 */
   void
PrintTotals (STATS statistics, int withranges)
{
   float sensitivity, specificity;

   sensitivity = 100. * (float) statistics.trust_correct / (float) statistics.trust_pairs;
   specificity = 100. * (float) statistics.test_correct / (float) statistics.test_pairs;

   /* And the final summary: */
   if (withranges) {
      puts("");
      printf("Overall structure prediction accuracy");
      printf("(%d sequences, %d positions)  Cval: %.2f%%\n",
	    statistics.nseq, statistics.positions, sqrt(sensitivity*specificity));
	printf("   %d/%d trusted pairs correctly predicted (%.2f%% sensitivity [%.2f%% - %.2f%%]\n",
	      statistics.trust_correct, statistics.trust_pairs, sensitivity,
	      statistics.sens_min, statistics.sens_max);
	printf("   %d/%d predicted pairs are true (%.2f%% PPV/specificity) [%.2f%% - %.2f%%]\n",
	      statistics.test_correct, statistics.test_pairs, specificity,
	      statistics.spec_min, statistics.spec_max);
	puts("");
   } else {
      printf("Overall structure prediction accuracy");
      printf("(%d sequences, %d positions)  Cval: %.2f%%\n",
	    statistics.nseq, statistics.positions, sqrt(sensitivity*specificity));
      printf("   %d/%d trusted pairs correctly predicted (%.2f%% sensitivity)\n",
	    statistics.trust_correct, statistics.trust_pairs, sensitivity);
      printf("   %d/%d predicted pairs are true (%.2f%% PPV/specificity)\n",
	    statistics.test_correct, statistics.test_pairs, specificity);
      puts("");
   }
}

/* Function: ZeroStats
 * Date:     RDD, Sat Dec  8 16:28:49 2001 [St. Louis]
 *
 * Purpose:  set contents of STAT structre to zero.
 */
void
ZeroStats (STATS *statistics)
{
  statistics->nseq = 0;
  statistics->Nfree = 0; 
  statistics->containN = 0; 
  statistics->positions = 0;

  statistics->trust_pairs = 0;
  statistics->test_pairs = 0;
  statistics->test_correct = 0;
  statistics->trust_correct = 0;

  statistics->sens_max = 0.0;
  statistics->spec_max = 0.0;

  statistics->sens_min = BIGFLOAT;
  statistics->spec_min = BIGFLOAT;
}

/************************************************************************/

/* Function: ZeroSS
 *
 * Purpose: initialize structure contents
 */
void 
ZeroSS (SSINFO *stats)
{
  int i, j, k;

  stats->nseq = 0;  stats->khsfailed = 0;
  stats->Nfree = 0; 
  stats->minlen = 987654321; stats->maxlen = 0;
  stats->minbp = 987654321; stats->maxbp = 0;

  for (k = 0; k < (ALPHAN * ALPHAN); k++) {
    for (j = 0; j < ALPHAN; j++) {
      for (i = 0; i < ALPHAN; i++) {
	stats->stack[k][j][i] = 0;
	if (k == 0) {
	  stats->pairs[j][i] = 0;
	  if (j == 0) {
	    stats->singles[i] = 0;
	    stats->hpcomp[i] = 0;
	    stats->bulgecomp[i] = 0;
	    stats->onentbulge[i] = 0;
	    stats->bulgeLcomp[i] = 0;
	    stats->bulgeRcomp[i] = 0;
	    stats->intlpcomp[i] = 0;
	    stats->multiloop[i] = 0;
	  }
	}
      }
    }
  }

  for (i = 0; i < SSMAX; i++) {
    stats->hairpin[i] = 0;
    stats->loop[i] = 0;
    stats->bulge[i] = 0;
    stats->stem[i] = 0;
  }

  stats->bigloops = 0;
  stats->symmetric = 0;
  stats->nonsymmetric = 0;
  stats->positions = 0;
  stats->lonepairs = 0;
}

void
PrintSStotals (SSINFO *stats, OPTS settings)
{
   if (settings.outmx) printLoopNFO(stats);
   printPairNFO(stats);
   printCompNFO(stats);
} 

void
printLoopNFO(SSINFO *stats) 
{
  int i, j, k;
  float asprobs[SSMAX];

  printf ("Loop lengths: \n");
  calcLoopProbs((stats->loop), asprobs);
  for (i = 0; i < SSMAX; i++) {
    printf("loop[%d] = %6d (%4.2f) ", i, stats->loop[i], asprobs[i]);
    if ((i%3) == 0) printf("\n");
  }

  printf ("\n\nHairpin lengths: \n");
  calcLoopProbs((stats->hairpin), asprobs);
  for (i = 0; i < SSMAX; i++) {
    printf("hpin[%d] = %6d (%4.2f) ", i, stats->hairpin[i], asprobs[i]);
    if ((i%3) == 0) printf("\n");
  }

  printf ("\n\nBulge lengths: \n");
  calcLoopProbs((stats->bulge), asprobs);
  for (i = 0; i < SSMAX; i++) {
    printf("bulge[%d] = %6d (%4.2f) ", i, stats->bulge[i], asprobs[i]);
    if ((i%3) == 0) printf("\n");
  }
  puts("\n");
}

void
printCompNFO(SSINFO *stats) 
{
  float asprobs[ALPHAN];
  int sum;

  printf("\n%-15s\t  ntA\t\t  ntC\t\t  ntG\t\t  ntU\t\t ntX\n", "Name");
  printf("%-15s\t=========\t========\t========\t========\t========\n", "====");

  calcCompProbs((stats->singles),asprobs);
  printf("%-15s\t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \t %d (%4.2f) \t %d (%4.2f) \n", 
	"Singles:", stats->singles[ntA], asprobs[ntA],
		stats->singles[ntC], asprobs[ntC],
		stats->singles[ntG], asprobs[ntG],
		stats->singles[ntU], asprobs[ntU],
		stats->singles[ntX], asprobs[ntX]);

  calcCompProbs((stats->intlpcomp),asprobs);
  printf("%-15s\t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \n", 
	"Loops:", stats->intlpcomp[ntA], asprobs[ntA], stats->intlpcomp[ntC], asprobs[ntC],
		stats->intlpcomp[ntG], asprobs[ntG], stats->intlpcomp[ntU], asprobs[ntU],
		stats->intlpcomp[ntX], asprobs[ntX]);

  calcCompProbs((stats->hpcomp),asprobs);
  printf("%-15s\t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \n", 
	"Hairpins:", stats->hpcomp[ntA], asprobs[ntA], stats->hpcomp[ntC], asprobs[ntC],
		stats->hpcomp[ntG], asprobs[ntG], stats->hpcomp[ntU], asprobs[ntU],
		stats->hpcomp[ntX], asprobs[ntX]);

  calcCompProbs((stats->bulgecomp),asprobs);
  printf("%-15s\t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \n", 
	"Bulges:", stats->bulgecomp[ntA], asprobs[ntA], stats->bulgecomp[ntC], asprobs[ntC], 
		stats->bulgecomp[ntG], asprobs[ntG], stats->bulgecomp[ntU], asprobs[ntU],
		stats->bulgecomp[ntX], asprobs[ntX]);

  calcCompProbs((stats->bulgeRcomp),asprobs);
  printf("%-15s\t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \n", 
	"Rbulges:", stats->bulgeRcomp[ntA], asprobs[ntA], 
	stats->bulgeRcomp[ntC], asprobs[ntC], stats->bulgeRcomp[ntG], asprobs[ntG], 
	stats->bulgeRcomp[ntU], asprobs[ntU], stats->bulgeRcomp[ntX], asprobs[ntX]);

  calcCompProbs((stats->bulgeLcomp),asprobs);
  printf("%-15s\t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \n", 
	"Lbulges:", stats->bulgeLcomp[ntA], asprobs[ntA], 
	stats->bulgeLcomp[ntC], asprobs[ntC], stats->bulgeLcomp[ntG], asprobs[ntG], 
	stats->bulgeLcomp[ntU], asprobs[ntU], stats->bulgeLcomp[ntX], asprobs[ntX]);

/*
  calcCompProbs((stats->multiloop),asprobs);
  printf("%-15s\t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \n", "Multi:",
		stats->multiloop[ntA], asprobs[ntA], stats->multiloop[ntC], asprobs[ntC], 
		stats->multiloop[ntG], asprobs[ntG], stats->multiloop[ntU], asprobs[ntU]);
*/

  calcCompProbs((stats->onentbulge),asprobs);
  printf("%-15s\t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \t%d (%4.2f) \n", 
	"1 nt B:", stats->onentbulge[ntA], asprobs[ntA], 
	stats->onentbulge[ntC], asprobs[ntC], stats->onentbulge[ntG], asprobs[ntG], 
	stats->onentbulge[ntU], asprobs[ntU], stats->onentbulge[ntX], asprobs[ntX]);

  sum = (stats->symmetric + stats->nonsymmetric);
  printf("\nSymmetric IL: %d (%4.2f) Nonsymmetric: %d (%4.2f) Total: %d\n", 
		stats->symmetric, (float) stats->symmetric / (float)sum, 
		stats->nonsymmetric, (float)stats->nonsymmetric / (float)sum, sum);
}

void
printPairNFO(SSINFO *stats) 
{
  float asprobs[ALPHAN][ALPHAN];
  int sum[ALPHAN];
  float sumasprobs[ALPHAN];

  printf("%-15s%13s%23s%21s%21s%21s\n", "Name", "ntA", "ntC", "ntG", "ntU", "ntX");
  printf("%-15s%15s%23s%21s%21s%21s\n", "====", "=======", "=======", "=======", 
	"=======", "=======");
  
  calcPairsProbs((stats->pairs), asprobs);

  printf("%-15s\t%10d (%6.4f)  %10d (%6.4f)  %10d (%6.4f)  %10d (%6.4f) %10d (%6.4f) \n", 
	"Pairs A:",
		stats->pairs[ntA][ntA], asprobs[ntA][ntA],
		stats->pairs[ntA][ntC], asprobs[ntA][ntC],
		stats->pairs[ntA][ntG], asprobs[ntA][ntG],
		stats->pairs[ntA][ntU], asprobs[ntA][ntU],
		stats->pairs[ntA][ntX], asprobs[ntA][ntX]);
  printf("%-15s\t%10d (%6.4f)  %10d (%6.4f)  %10d (%6.4f)  %10d (%6.4f) %10d (%6.4f) \n", 
	"Pairs C:",
		stats->pairs[ntC][ntA], asprobs[ntC][ntA], 
		stats->pairs[ntC][ntC], asprobs[ntC][ntC],
		stats->pairs[ntC][ntG], asprobs[ntC][ntG],
		stats->pairs[ntC][ntU], asprobs[ntC][ntU],
		stats->pairs[ntC][ntX], asprobs[ntC][ntX]);
  printf("%-15s\t%10d (%6.4f)  %10d (%6.4f)  %10d (%6.4f)  %10d (%6.4f) %10d (%6.4f) \n", 
	"Pairs G:",
		stats->pairs[ntG][ntA], asprobs[ntG][ntA],
		stats->pairs[ntG][ntC], asprobs[ntG][ntC],
		stats->pairs[ntG][ntG], asprobs[ntG][ntG],
		stats->pairs[ntG][ntU], asprobs[ntG][ntU],
		stats->pairs[ntG][ntX], asprobs[ntG][ntX]);
  printf("%-15s\t%10d (%6.4f)  %10d (%6.4f)  %10d (%6.4f)  %10d (%6.4f) %10d (%6.4f) \n", 
	"Pairs U:",
		stats->pairs[ntU][ntA], asprobs[ntU][ntA],
		stats->pairs[ntU][ntC], asprobs[ntU][ntC],
		stats->pairs[ntU][ntG], asprobs[ntU][ntG],
		stats->pairs[ntU][ntU], asprobs[ntU][ntU],
		stats->pairs[ntU][ntX], asprobs[ntU][ntX]);

  calcPairSums ((stats->pairs), sum);
  calcCompProbs(sum, sumasprobs);
  printf("\n%-15s\t%10d (%6.4f)  %10d (%6.4f)  %10d (%6.4f)  %10d (%6.4f) %10d (%6.4f) \n", 
	"Sum Pairs:",
		sum[ntA], sumasprobs[ntA], sum[ntC], sumasprobs[ntC],
		sum[ntG], sumasprobs[ntG], sum[ntU], sumasprobs[ntU],
		sum[ntX], sumasprobs[ntX]);
}

void
gnuLoops(SSINFO *stats, FILE *ofp) 
{
  int i;
  float loop[SSMAX], hp[SSMAX], bul[SSMAX];

  calcLoopProbs((stats->loop), loop);
  calcLoopProbs((stats->hairpin), hp);
  calcLoopProbs((stats->bulge), bul);

  fprintf(ofp, "#len loop hp bulge\n");
  for (i = 0; i < SSMAX; i++) {
    fprintf(ofp, "%d %6.4f %6.4f %6.4f\n", i, loop[i], hp[i], bul[i]);
  }
}

void
calcLoopProbs(int counts[], float asprobs[])
{
  int i;
  int denom;

  denom = 0;
  for (i = 0; i < SSMAX; i++) {
    denom += counts[i];
  }
  for (i = 0; i < SSMAX; i++) {
    asprobs[i] = (float)counts[i] / (float)denom;
  }
}

void
calcCompProbs(int counts[], float asprobs[])
{
  int i;
  int denom;

  denom = 0;
  for (i = 0; i < ALPHAN; i++) {
    if (i != ntT) {
      denom += counts[i];
    }
  }
  for (i = 0; i < ALPHAN; i++) {
    if (i != ntT) {
      asprobs[i] = (double)counts[i] / (double)denom;
    }
  }
}

void
calcPairSums (int pairs[][ALPHAN], int sum[])
{
  sum[ntA] = ((2*pairs[ntA][ntA]) + pairs[ntA][ntC] + pairs[ntA][ntG] 
	+ pairs[ntA][ntU] + pairs[ntA][ntX] + pairs[ntC][ntA] + pairs[ntG][ntA] 
	+ pairs[ntU][ntA] + pairs[ntX][ntA]); 
  sum[ntC] = ((2*pairs[ntC][ntC]) + pairs[ntC][ntA] + pairs[ntC][ntG] 
	+ pairs[ntC][ntU] + pairs[ntC][ntX] + pairs[ntA][ntC] + pairs[ntG][ntC] 
	+ pairs[ntU][ntC] + pairs[ntX][ntC]); 
  sum[ntG] = ((2*pairs[ntG][ntG]) + pairs[ntG][ntA] + pairs[ntG][ntC] 
	+ pairs[ntG][ntU] + pairs[ntG][ntX] + pairs[ntA][ntG] + pairs[ntC][ntG] 
	+ pairs[ntU][ntG] + pairs[ntX][ntG]);
  sum[ntU] =  ((2*pairs[ntU][ntU]) + pairs[ntU][ntA] + pairs[ntU][ntC] 
	+ pairs[ntU][ntG] + pairs[ntU][ntX] + pairs[ntA][ntU] + pairs[ntC][ntU] 
	+ pairs[ntG][ntU] + pairs[ntX][ntU]);
  sum[ntX] =  ((2*pairs[ntX][ntX]) + pairs[ntX][ntA] + pairs[ntX][ntC] 
	+ pairs[ntX][ntG] + pairs[ntX][ntU] + pairs[ntA][ntX] + pairs[ntC][ntX] 
	+ pairs[ntG][ntX] + pairs[ntU][ntX]);
}

void
calcPairsProbs(int counts[][ALPHAN], float asprobs[][ALPHAN])
{
  int i, j;
  int denom;

  denom = 0;
  for (i = 0; i < ALPHAN; i++) {
    for (j = 0; j < ALPHAN; j++) {
      denom += counts[i][j];
    }
  }
  for (i = 0; i < ALPHAN; i++) {
    for (j = 0; j < ALPHAN; j++) {
      asprobs[i][j] = (float)counts[i][j] / (float)denom;
    }
  }
}


