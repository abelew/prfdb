/* gr_yrn.c
 * RDD, Mon Sep 30 10:48:58 CDT 2002
 *
 * Implementations of the grammar specific functions for YRN
 *
 * Thu Aug 23 17:19:01 2001 
 * Yarn:	S -> aPa' | aS | Sa | SS | end	(YRN)
 * 		P -> aPa' | S
 *
 * These implementations assume a digitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"

/*************************  CYK ********************************/
/* Function: cykInitYRN
 * Date:     RDD, Fri Oct 12 13:56:34 2001 [St. Louis]
 *
 * Purpose:  Initialize CYK fill matrix for YRN grammar
 *
 * Args:     
 *	mx	fill matrix (integer log odds form)
 *	model 	parameters (integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cykInitYRN(int ***mx, INTMOD *model, char *rna, int len)
{
   int j, d; 

   for (d = 0; d <= len; d++) {
      for (j = (d > 0? d-1: d); j < len; j++) {
	 /* S -> end in YRN */
	 mx[dpS][j][d] = model->transitions[TSE];	
	 /* P -> S -> end in YRN */
	 mx[dpP][j][d] = model->transitions[TPS] + model->transitions[TSE];	
      }
   }
}

/* Function: cykFillYRN
 * Date:     Fri Oct 12 09:10:06 CDT 2001 [St Louis]
 *
 * Purpose:  Fills CYK matrix for YRN grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	pr	parameters (integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
cykFillYRN(int ***mx, INTMOD *pr, char *rna, int len)
{
  int d, i, j, k;
  int max;              /* Maximum value seen so far */
  int cursc,curscP, cursc2;    /* Current score */
  int stackvalue;	

  /* Recursion */
  for (d = 1; d <= len; d++) {
     for (j = d-1; j < len; j++) {
	i = j - d + 1;  max = -BIGINT;
	/* S -> aS */
	cursc = mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL];
	if (cursc > max) max = cursc; 

	/* S -> Sb */
	if (j > 0) {
	   cursc = mx[dpS][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR];
	   if (cursc > max) max = cursc;

	   /* S -> aPa' */
	   if (d > 1) {
	      cursc = mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TSP];
	      if ((cursc > max) && (lplen(i,j) >= HLEN)) max = cursc;
	   }
	}

	/* S -> SS in Ambiguous grammars (YRN) */
	for (k = i; k < j; k++) {
	   cursc = mx[dpS][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] + pr->transitions[TSB];
	   if (cursc > max) max = cursc;
	}

	/* S -> aSb | SR | Sb | SS | end */
	mx[dpS][j][d] = max;

	/* Can't be in P state at edges!  */
	if ((i == 0) || (j == len-1)) {
	   stackvalue = -BIGINT;
	} else {
	   stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]];
	}

	/* P -> aPb | S  (stacking!) */
	if ((j > 0) && (d > 1) && (lplen(i,j) >= HLEN)) {
	   curscP = mx[dpP][j-1][d-2] + stackvalue + pr->transitions[TPP];
	} else {
	   curscP = -BIGINT;
	}
	cursc2 = mx[dpS][j][d] + pr->transitions[TPS];
	if (curscP > cursc2) {
	   mx[dpP][j][d] = curscP;
	} else {
	   mx[dpP][j][d] = cursc2;
	}

     } /* End for loop */
  } /* End foreach n */
}

/* Function: cykTraceYRN
 * Date:     RDD, Mon Aug 27 13:44:16 2001 [St. Louis]
 *
 * Purpose:  Build traceback tree for scoring YRNsinov 
 *
 * Args:
 *	mx	matrix in which to calculate cyk
 *	pr	parameters in integer form
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns: traceback tree
 */
struct trace_s *
cykTraceYRN (int ***mx, INTMOD *pr, char *rna, int len)
{
  int d, i, j, k, mtx;   /* Indices */
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (len -1), TSE));

  /* Repeat until stack is empty */
  while (curr = PopTracestack(stack)) {
    /* Set i and j from items in stack */
    i = curr->emitl; j = curr->emitr; mtx = curr->nonterminal;
    d = j - i + 1;

    if (i > j) { 		/* S -> end */
       if (mtx == dpP) {
          curr->transition = TPS; curr->emitl = -1; curr->emitr = -1; 
	  PushTracestack(stack, AttachTrace (curr, dpS, i, j, TSE));
       } else {
	  curr->emitl = -1; curr->emitr = -1;
	  curr->transition = TSE; curr->nonterminal = dpE; 
	  continue;
       }

    /* S -> aPb | aS | Sb | SS | end */
    } else if (mtx == dpS) {  
		/* Single nt length seq's i == j */
      if ((mx[dpS][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR]) 
	  			== mx[dpS][j][d]) {
        curr->emitl = -1; curr->transition = TSR; 
        PushTracestack(stack, AttachTrace (curr, dpS, i, j-1, TSE));
      } else if ((mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL]) 
	    		== mx[dpS][j][d]) {
        curr->emitr = -1; curr->transition = TSL; 
        PushTracestack(stack, AttachTrace (curr, dpS, i+1, j, TSE));
      } else if ((lplen(i,j) >= HLEN) && ((mx[dpP][j-1][d-2] 
		  + pr->pairs[rna[i]][rna[j]] + pr->transitions[TSP]) 
	       == mx[dpS][j][d])) {
        curr->transition = TSP;
        PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TSE));
      } else {
        for (k = i; k < j; k++) {
          if ((mx[dpS][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] + pr->transitions[TSB]) 
		== mx[dpS][j][d]) {
	    curr->emitl = -1; curr->emitr = -1; curr->transition = TSB;
            PushTracestack(stack, AttachTrace (curr, dpS, k+1, j, TSE));
            PushTracestack(stack, AttachTrace (curr, dpS, i, k, TSE));
	    k = j;	/* Short circuit */
          } /* End if */
        } /* End for (bifurcation points) */
      } /* End if i <= j */

    /* P -> aPa | S */
    } else {	/* dpP */
      if ((lplen(i,j) >= HLEN) && ((mx[dpP][j-1][d-2] + pr->stack[idx(rna[i-1], rna[j+1])][rna[i]][rna[j]] 
	       + pr->transitions[TPP]) == mx[dpP][j][d])) {
        curr->transition = TPP;
        PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TSE));
      } else {
        curr->transition = TPS; curr->emitl = -1; curr->emitr = -1; 
        PushTracestack(stack, AttachTrace (curr, dpS, i, j, TSE));
      }
    }
  } /* end while stack not empty*/
  FreeTracestack(stack);
  return parsetree;
}

/* analyzeTraceN and dTraceScoreN in NUS */

/*************************  TRAIN ******************************/
/* Function: khs2traceYRN
 * Date:     RDD, Tue Apr 23 09:39:24 2002 [St. Louis]
 *
 * Purpose: Convert KHS to traceback tree properly 
 * 	labeled for YRN grammar.
 *
 * Args:     
 *	dolist  Traceback tree to build from KHS	
 *	ct	KHS info represented as ct format
 */
int
khs2traceYRN(struct tracestack_s *dolist, int *ct)
{
  struct trace_s      *cur;
  int  i,j, mid;

  while ((cur = PopTracestack(dolist)) != NULL) {
    i = cur->emitl;           /* 0..len-1 */
    j = cur->emitr;           /* 0..len-1 */

    if (i > j) {
       cur->transition = TSE; cur->emitl = -1; cur->emitr = -1; cur->nonterminal = dpE;
    } else if (ct[j] == -1) {   /* j unpaired: single strand right */
       if (cur->nonterminal == dpS) {
	  cur->transition = TSR; cur->emitl = -1;
	  PushTracestack(dolist, AttachTrace(cur, dpS, i, j-1, TSE));
       } else {
	  cur->transition = TPS; cur->emitl = -1; cur->emitr = -1;
	  PushTracestack(dolist, AttachTrace(cur, dpS, i, j, TSE));
       }
    } else if (ct[i] == -1) {   /* i unpaired; single strand left */
       if (cur->nonterminal == dpS) {
	  cur->transition = TSL; cur->emitr = -1;
	  PushTracestack(dolist, AttachTrace(cur, dpS, i+1, j, TSE));
       } else {
	  cur->transition = TPS; cur->emitl = -1; cur->emitr = -1;
	  PushTracestack(dolist, AttachTrace(cur, dpS, i, j, TSE));
       }
    } else if (ct[i] == j) {    /* i,j paired to each other */
       if (cur->nonterminal == dpS) {
	  cur->transition = TSP;
	  PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TSE));
       } else {
	  cur->transition = TPP;
	  PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TSE));
       }
    } else {
       if (cur->nonterminal == dpS) {
	  cur->transition = TSB; 
	  cur->emitl = -1; cur->emitr = -1;
	  mid = (random() % 2) ? ct[i] : ct[j]-1;
	  PushTracestack(dolist, AttachTrace(cur, dpS, mid+1, j, TSE));
	  PushTracestack(dolist, AttachTrace(cur, dpS, i, mid, TSE));
       } else {
	  cur->transition = TPS; cur->emitl = -1; cur->emitr = -1;
	  PushTracestack(dolist, AttachTrace(cur, dpS, i, j, TSE));
       }
    }
  }
  return 1;
}

/************************** disambiguation ************************/
/* Function: probifyYRN
 * Date:     RDD, Sat Dec  8 16:08:01 2001 [St. Louis]
 * 
 * Purpose:  Properly convert counts to probabilities
 *           for transitions of YRNsinov grammar
 *
 * Args:     
 *      icfg     counts form of parameters
 *      ret_cfg  probabilistic form of parameters
 *      prior    + constant (usually 1) for prior
 *
 * Returns:  nothing.
 */ 
void
probifyYRN (INTMOD *icfg, PROBMOD *ret_cfg, INTMOD *prior)
{
  int   denom;                /* sum used for normalization in denominator */
  int   ssregion;
  int i;

  denom = (icfg->transitions[TSP] + prior->transitions[TSP]) +
          (icfg->transitions[TSL] + prior->transitions[TSL]) +
          (icfg->transitions[TSR] + prior->transitions[TSR]) + 
	  (icfg->transitions[TSB] + prior->transitions[TSB]) + 
          (icfg->transitions[TSE] + icfg->transitions[TSE]);
  ret_cfg->transitions[TSP] = (double)(icfg->transitions[TSP] + prior->transitions[TSP]) / (double) denom;
  ret_cfg->transitions[TSB] = (double) (icfg->transitions[TSB] + prior->transitions[TSB]) / (double) denom; 
  ret_cfg->transitions[TSE] = (double) (icfg->transitions[TSE] + icfg->transitions[TSE]) / (double) denom;
  /* Assume single stranded regions are equally likely from TSR as TSL */
  ssregion = (((icfg->transitions[TSL] + prior->transitions[TSL]) +
          (icfg->transitions[TSR] + prior->transitions[TSR])) / 2 );
  ret_cfg->transitions[TSL] = (double) ssregion / (double) denom;
  ret_cfg->transitions[TSR] = (double) ssregion / (double) denom;

  denom = (icfg->transitions[TPP] + prior->transitions[TPP]) +
  	  (icfg->transitions[TPS] + prior->transitions[TPS]);
  ret_cfg->transitions[TPP] = (double) (icfg->transitions[TPP] + prior->transitions[TPP]) /
     (double) denom;
  ret_cfg->transitions[TPS] = (double) (icfg->transitions[TPS] + prior->transitions[TPS]) /
     (double) denom;
}

/*************************  Inside ********************************/
/* Function: insideInitYRN
 * Date:     RDD, Jul 19 13:59:35 CDT 2002 [St Louis]
 *
 * Purpose:  Initialize Inside fill matrix for YRN grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:     
 *	mx	where to store inside (matrix to fill)
 *	model	integer log form of parameters
 *	rna	Sequence to be analyzed
 * 	len	sequence length
 *
 * Notes:  To initialize the "lower" half of the matrix:
 *   \alpha_{nonterminal}(i+1, i) = 1 for nontermianls with \epsilon
 *   				  = 0 otherwise
 * To initalize the diagonal (i == j) we calculate the inside
 *  	variable (\alpha) for each nontermianl type assuming
 *  	the values above for all \alpha_{nontemrainl}(i,j) where
 *  	i > j.
 *
 * Returns:  -- void -- 
 */
void
insideInitYRN(double ***mx, PROBMOD *model, char *rna, int len)
{
  int j, d;

  for (d = 0; d <= len; d++) {
    for (j = d; j < len; j++) {
       mx[dpS][j][d] = model->transitions[TSE];
       mx[dpP][j][d] = -BIGFLOAT;
    }
    if (d > 0) {
       mx[dpS][d-1][d] = model->transitions[TSE];
       mx[dpP][d-1][d] = model->transitions[TPS] + model->transitions[TSE];
    }
  }
}

/* Function: insideFillYRN
 * Date:     RDD, Jul 19 13:59:35 CDT 2002 [St Louis]
 *
 * Purpose:  Fills inside matrix for YRN grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	pr	parameters (integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
insideFillYRN(double ***mx, PROBMOD *pr, char *rna, int len)
{
  int i, j, d, k; 
  double cursc;		/* Current score */
  double stackvalue;	
  int debug;	

  debug = FALSE;

  /* Recursion */
  for (d = 1; d <= len; d++) {
     for (j = d-1; j < len; j++) {
	i = j - d + 1; cursc = -BIGFLOAT;

	/* S -> aS | Sa */
	if (j > 0) {
	   cursc = DLogsum(mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL],
		 mx[dpS][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR]);
	} else {
	   cursc = DLogsum(mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL],
		 pr->transitions[TRE] + pr->singles[rna[j]] + pr->transitions[TSR]);
	}

	/* S -> SS in YRN */
	for (k = i; k < j; k++) {
	   if (debug) printf("Adding a bifurcation with k = %d (%d, %d)\n", k, i, j);
	   cursc = DLogsum(mx[dpS][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] 
		 + pr->transitions[TSB], cursc);
	}

	/* S -> aPa' */
	if ((j > 0) && (abs(j-i) > HLEN)) {
	   if (debug) printf("Adding a pair at (%d, %d)\n", i,j );
	   cursc = DLogsum(mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
		 + pr->transitions[TSP], cursc);
	}

	/* S -> aPa' | aS | Sb | SS | end */
	mx[dpS][j][d] = cursc;

	/* P -> aPb | S  (stacking!) */
	if ((i == 0) || (j == len-1)) {
	   stackvalue = -BIGFLOAT;
	} else {
	   stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]];
	}
	if ((j > 0) && (d > 1)) {
	  mx[dpP][j][d] = DLogsum(mx[dpP][j-1][d-2] + stackvalue + pr->transitions[TPP],
	      mx[dpS][j][d] + pr->transitions[TPS]);
	} else {
	   mx[dpP][j][d] = mx[dpS][j][d] + pr->transitions[TPS];
	}
     } /* End for loop */
  } /* End foreach n */
}

/*********************** Suboptimals ******************************/
/* Function: insideTraceYRN
 * Date:     Fri Oct  4 21:07:03 CDT 2002 [St Louis]
 *
 * Purpose:  Build a traceback tree for Inside (sampled)
 *
 * Args:
 *	mx	matrix containing inside values 
 *	pr	parameters in integer form
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns: traceback tree
 */
struct trace_s *
insideTraceYRN(double ***mx, PROBMOD *pr, char *rna, int len)
{
  int i, j, k, mtx, d;
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */
  double *ruleprob;
  double cursc, denom, randnum; 
  int indx;
  double stackvalue;

  ruleprob = (double *) malloc (sizeof(double) * (len + 4));
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (len -1), TSE));

  /* Repeat until stack is empty */
  while (curr = PopTracestack(stack)) {
     /* Set i and j from items in stack */
     i = curr->emitl; j = curr->emitr; mtx = curr->nonterminal;
     d = j - i + 1;

     /* Generate a random number */
     randnum = asLog((float) rand() / RAND_MAX);

     /* S -> end */
     if (i > j) { 		/* S -> end */
	curr->emitl = -1; curr->emitr = -1;
	curr->transition = TSE; curr->nonterminal = dpE; 
	continue;
     } else if (mtx == dpS) {
	indx = 0;
	/* S -> aPa' */
	if ((j > 0) && (d > 1)) {
	  cursc = mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TSP];	
	} else { cursc = -BIGFLOAT; }
	ruleprob[indx++] = cursc;
	denom = cursc;

	/* S -> aS */
	if (d > 0) {
	   cursc = mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL];	
	} else {
	   cursc = -BIGFLOAT;
	}
	ruleprob[indx++] = cursc;
	denom = ILogsum(denom, cursc);

	/* S -> aS */
	if ((j > 0) && (d > 0)) {
	 cursc = mx[dpS][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR];	
	} else { cursc = -BIGFLOAT; }
	ruleprob[indx++] = cursc;
	denom = ILogsum(denom, cursc);

	/* S -> SS */
	cursc = -BIGFLOAT; 		
	for (k = i; k < j; k++) {
	   cursc = mx[dpS][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] + pr->transitions[TSB];
	   ruleprob[indx++] = cursc;
	   denom = ILogsum(denom, cursc);
	}

	/* Normalize to probs */
	for (k = 0; k < indx; k++) {		
	   ruleprob[k] = ruleprob[k] - denom;
	   if (k > 0) {		/* Convert to intervals */
	      ruleprob[k] = ILogsum(ruleprob[k], ruleprob[k-1]);
	   }
	}

	/* Pick a rule based on probs of those rules */
	if (randnum < ruleprob[0]) {
	   curr->transition = TSP;
	   PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TSE));
	} else if (randnum < ruleprob[1]) {
	   curr->emitr = -1; curr->transition = TSL; 
	   PushTracestack(stack, AttachTrace (curr, dpS, i+1, j, TSE));
	} else  if (randnum < ruleprob[2]) {
	   curr->emitl = -1; curr->transition = TSR; 
	   PushTracestack(stack, AttachTrace (curr, dpS, i, j-1, TSE));
	} else {	
	   for (mtx = 3; mtx < indx; mtx++) {
	      k = i + (mtx - 3);			/* Coordinate of this bif */
	      if (randnum < ruleprob[mtx]) {
		 curr->emitl = -1; curr->emitr = -1; curr->transition = TSB;
		 PushTracestack(stack, AttachTrace (curr, dpS, k+1, j, TSE));
		 PushTracestack(stack, AttachTrace (curr, dpS, i, k, TSE));
		 mtx = indx;	/* Break loop */
	      }
	   } /* Find which k of bif state */
	} /* End else is bif state */
     } else if (mtx == dpP) {
	indx = 0;
	/* P -> S */
	cursc = mx[dpS][j][d] + pr->transitions[TPS];  
	ruleprob[indx++] = cursc;
	denom = cursc;

	/* P -> aPa' */
	stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]];
	if ((j > 0) && (d > 1)) {
	cursc = mx[dpP][j-1][d-2] + stackvalue + pr->transitions[TPP]; 
	} else {
	   cursc = -BIGFLOAT;
	}
	ruleprob[indx++] = cursc;
	denom = ILogsum(cursc, denom);

	/* Normalize to probs */
	for (k = 0; k < indx; k++) {		
	   ruleprob[k] = ruleprob[k] - denom;
	   if (k > 0) {		/* Convert to intervals */
	      ruleprob[k] = ILogsum(ruleprob[k], ruleprob[k-1]);
	   }
	}

	if (randnum < ruleprob[0]) {
	   curr->transition = TPS; curr->emitl = -1; curr->emitr = -1;
	   PushTracestack(stack, AttachTrace (curr, dpS, i, j, TSE));
	} else {
	   curr->transition = TPP; 
	   PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TSE));
	}
     }
  }	/* End while */
  FreeTracestack(stack);
  free(ruleprob);
  return parsetree;
}

/******************* conditional Inside ********************************/
/* Function: cinsInitYRN
 * Date: Mon Sep 30 10:49:18 CDT 2002 [St Louis]
 *
 * Purpose:  Initialize conditional Inside fill matrix for YRN 
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:     
 *	mx	where to store inside (matrix to fill)
 *	model	integer log form of parameters
 *	rna	Sequence to be analyzed
 * 	len	sequence length
 * 	ss	specified structure
 *
 * Notes:  To initialize the "lower" half of the matrix:
 *   \alpha_{nonterminal}(i+1, i) = 1 for nontermianls with \epsilon
 *   				  = 0 otherwise
 * To initalize the diagonal (i == j) we calculate the inside
 *  	variable (\alpha) for each nontermianl type assuming
 *  	the values above for all \alpha_{nontemrainl}(i,j) where
 *  	i > j.
 *
 * Returns:  -- void -- 
 */
void
cinsInitYRN(double ***mx, PROBMOD *model, char *rna, int len, int *ss)
{
  int j, d;

  for (d = 0; d <= len; d++) {
    for (j = d; j < len; j++) {
       mx[dpS][j][d] = model->transitions[TSE];
       mx[dpP][j][d] = model->transitions[TPS] + model->transitions[TSE];
    }
    if (d > 0) {
       mx[dpS][d-1][d] = model->transitions[TSE];
       mx[dpP][d-1][d] = model->transitions[TPS] + model->transitions[TSE];
    }
  }
}

/* Function: cinsFillYRN
 * Date:     RDD, Mon Sep 30 10:50:05 CDT 2002 [St Louis]
 *
 * Purpose:  Fills inside matrix for YRN 
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	sc	parameters 
 *		(integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 * 	ss	specified structure
 *
 * Returns:  void 
 */
void
cinsFillYRN(double ***mx, PROBMOD *pr, char *rna, int len, int *ss)
{
  int d, i, j, k;       /* Loop indicies */
  double cursc;		/* Current score */
  double stackvalue;	
  int debug;	

  debug = FALSE;
  /* Recursion */
  for (d = 1; d <= len; d++) {
     for (j = d-1; j < len; j++) {
	i = j - d + 1; cursc = -BIGFLOAT;

      /* S -> aS | Sa */
      if (ss[i] == -1) {
        cursc = mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL];
      }
      if ((ss[j] == -1) && (j > 0)) {
        cursc = DLogsum(cursc, mx[dpS][j-1][d-1] + pr->singles[rna[j]] 
	      		+ pr->transitions[TSR]);
      }

      /* S -> SS in YRN */
      for (k = i; k < j; k++) {
	if (debug) printf("Adding a bifurcation with k = %d (%d, %d)\n", k, i, j);
        cursc = DLogsum(mx[dpS][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] 
	      		+ pr->transitions[TSB], cursc);
      }

      if (abs(j-i) > HLEN) {	/* S -> aPa' */
	 if (ss[i] == j) {
	    if ((j > 0) && (d > 1)) {
	       if (debug) printf("Adding a pair at (%d, %d)\n", i,j );
	       cursc = DLogsum(mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
		     + pr->transitions[TSP], cursc);
	    }
	 }
      }

      /* S -> aPa' | aS | Sb | SS | end */
      mx[dpS][j][d] = cursc;

      /* P -> aPb | S  (stacking!) */
      /* Can't be in P state at edges!  */
      mx[dpP][j][d] = mx[dpS][j][d] + pr->transitions[TPS];
      if (ss[i] == j) {
	 if ((i > 0) && (j < len-1)) {
	    stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]];
	    if ((j > 0) && (d > 1)) {
	       mx[dpP][j][d] = DLogsum(mx[dpP][j-1][d-2] + stackvalue + pr->transitions[TPP],
		     mx[dpS][j][d] + pr->transitions[TPS]);
	    }
	 }
      }
    } /* End for loop */
  } /* End foreach n */
}

/************************* Outside ********************************/
/* Function: outsideInitMxYRN
 * Date:     Mon Feb 10 13:43:39 CST 2003 [St Louis]
 *
 * Purpose:  Initialize Inside fill matrix for YRN grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:     
 *	mxo	where to store outside (matrix to fill)
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
outsideInitYRN(double ***mxo, int len)
{
   int d, j;

   for (d = 0; d <= len; d++) {
      for (j = d; j < len; j++) {
	 mxo[dpS][j][d] = -BIGFLOAT;
	 mxo[dpP][j][d] = -BIGFLOAT;
      } /* end for j */
      if (d > 0) {
	 mxo[dpS][d-1][d] = -BIGFLOAT;
	 mxo[dpP][d-1][d] = -BIGFLOAT;
      }
   }
   mxo[dpS][len-1][len] = 0;
}

/* Function: outsideFillYRN
 * Date:  Fri Aug 16 15:16:38 CDT 2002 [St Louis]
 * 
 * Purpose:  Fills outside matrix for YRN
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 * 	mxo	where to store outside (matrix to fill)
 *	mx	results from inside
 *	pr	integer log form of parameters
 *	rna	Sequence to be analyzed
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
outsideFillYRN(double ***mxo, double ***mx, PROBMOD *pr, char *rna, int len)
{
   int d, i, j, k, max, temp;
   double cursc;
   double stackvalue;

   /* Recursion */
   for (d = (len-1); d > 0; d--) {
      for (j = (len-1); j > d-2; j--) {
	 i = j - d + 1; cursc = -BIGFLOAT;

	 /* \beta^P(i,j) */
	 if ((i > 0) && (j < len-1)) {
	    cursc = mxo[dpS][j+1][d+2] + pr->transitions[TSP] + pr->pairs[rna[i-1]][rna[j+1]];
	    if ((i > 1) && (j < len-2)) {
	       stackvalue = pr->stack[idx(rna[i-2], rna[j+2])][rna[i-1]][rna[j+1]];
	       cursc = DLogsum(cursc, mxo[dpP][j+1][d+2] + pr->transitions[TPP] 
		     + stackvalue);
	    }
	 }
	 mxo[dpP][j][d] = cursc;

	 /* \beta^S(i,j) */
	 if ((i == 0) && (j == len-1)) {
	    mxo[dpS][len-1][len] = 0; /* Initialization */
	 } else {
	    cursc = -BIGFLOAT;
	    cursc = mxo[dpP][j][d] + pr->transitions[TPS];
	    if (i > 0) {
	       cursc = DLogsum(cursc, mxo[dpS][j][d+1] + pr->transitions[TSL] 
		     + pr->singles[rna[i-1]]);
	    }
	    if (j < len-1) {
	       cursc = DLogsum(cursc, mxo[dpS][j+1][d+1] + pr->transitions[TSR] 
		     + pr->singles[rna[j+1]]);
	    }
	    for (k = 0; k < i; k++) {
	       cursc = DLogsum(cursc, mxo[dpS][j][dist(k,j)] + pr->transitions[TSB] 
		     + mx[dpS][i-1][dist(k,i-1)]);
	    }
	    for (k = j+1; k < len; k++) {
	       cursc = DLogsum(cursc, mxo[dpS][k][dist(i,k)] + pr->transitions[TSB] 
		     + mx[dpS][k][dist(j+1,k)]);
	    }
	    mxo[dpS][j][d] = cursc;
	 }
      }
   }
}

/* Function: coutFillYRN
 * Date:  Fri Oct  4 21:12:59 CDT 2002 [St Louis]
 * 
 * Purpose:  Fills conditional outside matrix for YRN
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 * 	mxo	where to store outside (matrix to fill)
 *	mx	results from inside
 *	pr	integer log form of parameters
 *	rna	Sequence to be analyzed
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
coutFillYRN(double ***mxo, double ***mx, PROBMOD *pr, char *rna, int len, int *ss)
{
   int d, i, j, k, max, temp;
   double cursc;
   double stackvalue;

   /* Recursion */
   for (d = (len-1); d > 0; d--) {
      for (j = (len-1); j > d-2; j--) {
	 i = j - d + 1; 

	 /* \beta^P(i,j) */
	 if ((i > 0) && (j < len-1)) {
	    if (ss[i-1] == j+1) {
	       cursc = mxo[dpS][j+1][d+2] + pr->transitions[TSP] 
		  + pr->pairs[rna[i-1]][rna[j+1]];
	       if ((i > 1) && (j < len-2)) {
		  stackvalue = pr->stack[idx(rna[i-2], rna[j+2])][rna[i-1]][rna[j+1]];
		  cursc = DLogsum(cursc, mxo[dpP][j+1][d+1] + pr->transitions[TPP] 
			+ stackvalue);
	       }
	    }
	 }
	 mxo[dpP][j][d] = cursc;

	 /* \beta^S(i,j) */
	 if ((i == 0) && (j == len-1)) {
	    mxo[dpS][len-1][len] = 0; /* Initialization */
	 } else {
	    cursc = -BIGFLOAT;
	    cursc = mxo[dpP][j][d] + pr->transitions[TPS];
	    if (i > 0) {
	       if (ss[i-1] == -1) {
		  cursc = DLogsum(cursc, mxo[dpS][j][d-1] + pr->transitions[TSL] 
			+ pr->singles[rna[i-1]]);
	       }
	    }
	    if (j < len-1) {
	       if (ss[j+1] == -1) {
		  cursc = DLogsum(cursc, mxo[dpS][j+1][d+1] + pr->transitions[TSR] 
			+ pr->singles[rna[j+1]]);
	       }
	    }
	    for (k = 0; k < i; k++) {
	       cursc = DLogsum(cursc, mxo[dpS][j][dist(k,j)] + pr->transitions[TSB] 
		     + mx[dpS][i-1][dist(k,i-1)]);
	    }
	    for (k = j+1; k < len; k++) {
	       cursc = DLogsum(cursc, mxo[dpS][k][dist(i,k)] + pr->transitions[TSB] 
		     + mx[dpS][k][dist(j+1,k)]);
	    }
	    mxo[dpS][j][d] = cursc;
	 }
      }
   }
}

/************************* Posteriors ********************************/
/* Function: probXYpairYRN
 * Date: RDD, Wed Sep 25 12:04:35 CDT 2002 [Bethesda]
 *
 * Purpose: Calculate the Probability that Xi pairs with Xj
 *  	using the YRN grammar
 * 
 * Args:
 *   	x		Smaller index	
 *   	y	 	Larger Index	
 *   	mx		Inside matrix -- filled
 *   	mxo		Outside Matrix -- filled
 *  	rna		Sequence under study
 *  	len		Length of said sequence
 *  	model 		Parameters for this model
 *  	ret_sc		Prob(x pairs y) as Int log sum
 * 
 * Returns:
 * 	1 on success; 0 on failure
 */
int
probXYpairYRN(int x, int y, double ***mx, double ***mxo, char *rna, int len, 
      PROBMOD *model, double *ret_sc)
{
   double temp, fval;
   double probseq;
   double stackvalue;
   int debug;

   debug = FALSE; 
   probseq = mx[dpS][len-1][len];

   if (debug) printf("YRN Prob(x%d pairs x%d): ", x, y);

   temp = mxo[dpS][y][dist(x,y)] + mx[dpP][y-1][dist(x+1,y-1)] 
      + model->pairs[rna[x]][rna[y]] + model->transitions[TSP];

   if ((x > 0) && (y < len-1)) {
      stackvalue = model->stack[idx(rna[x-1],rna[y+1])][rna[x]][rna[y]]; 
      temp = DLogsum(temp, mxo[dpP][y][dist(x,y)] + mx[dpP][y-1][dist(x+1,y-1)] 
	    + stackvalue + model->transitions[TPP]);
   }

   /* Normalize by multiply by (1 / P(x| model))
    * Recall p1 / p2 in log space is log(p1) - log(p2)
    */
   fval = temp - probseq;

   if (debug) {
      printf(" %f (%f)  ", temp, asProb(temp));
      printf("Normalized: %f (%f)\n",  fval, asProb(fval));
   }
   *ret_sc = fval;
   return 1;
}

/* Function probXunpairedYRN
 * Date: RDD, Wed Sep 25 12:06:02 CDT 2002 [Bethesda]
 *
 * Purpose: Calculate the probability that Xi is unpaired
 *   	using the UNA grammar
 * 
 * Args:
 *   	i		First index - position under scrutiny
 *   	mx		Inside matrix -- filled
 *   	mxo		Outside Matrix -- filled
 *  	rna		Sequence under study
 *  	len		Length of said sequence
 *  	model 		Parameters for this model
 *  	ret_sc		Prob(x pairs y) as Int log sum
 * 
 * Returns:
 *   	1 on success; 0 on failure
 */
int
probXunpairedYRN(int i, double ***mx, double ***mxo, char *rna, int len, 
      PROBMOD *model, double *ret_sc)
{
   int j, debug;
   double right, left;
   double sum, fval, probseq;

   debug = FALSE;
   probseq = mx[dpS][len-1][len];

   if (debug) 
      printf("\nProb(x|model): %f (%f) Pos %d unpaired \n", 
	    probseq, asProb(probseq), i);

   sum = -BIGFLOAT; right = -BIGFLOAT;
   for (j = 0; j < i; j++) {
      right = DLogsum(right, mxo[dpS][i][dist(j,i)] + mx[dpS][i-1][dist(j,i-1)] 
	    + model->singles[rna[i]] + model->transitions[TSR]);
   }
   /* Special case: S -> Sa -> a */
   right = DLogsum(right, mxo[dpS][i][1] + model->transitions[TSE]
	 + model->singles[rna[i]] + model->transitions[TSR]);
   if (debug) printf("Right %f (%e)\n", right, asProb(right));

   left = -BIGFLOAT;
   for (j = i+1; j < len; j++) {
      left = DLogsum(left, mxo[dpS][j][dist(i,j)] + mx[dpS][j][dist(i+1,j)]
	    + model->singles[rna[i]] + model->transitions[TSL]);
   }
   /* Special case: S -> aS -> a */
   left = DLogsum(left, mxo[dpS][i][1] + model->transitions[TSE]
	 + model->singles[rna[i]] + model->transitions[TSL]);
   if (debug) printf("Left %f (%f)\n", left , asProb(left));

   sum = DLogsum(right, left);
   if (debug) printf("Sum %f (%f)\n", sum, asProb(sum));

   /* Normalize by multiply by (1 / P(x| model))
    * Recall p1 / p2 in log space is log(p1) - log(p2)
    */
   fval = sum - probseq;
   
   if (debug) printf("Fval %f (%f)\n", fval, asProb(fval));

   *ret_sc = fval;
   return 1;
}


/****************************** CML *******************************/
/* Function: calcNvalsYRN
 * Date: Mon Feb 10 15:46:02 CST 2003 [St Louis]
 *
 * Purpose: calculate the sum of posteriors (n_{ij}) 
 *      for the transition parameters
 *
 * Math: (See Krogh and Riis (1999), Neural Computation 11, 541-563))
 * For an HMM (easier notation):
 *   n_{ij}(t) = P(\pi_{t-1} = i, \pi_t = j | x, \theta) 
 *   n_{ij} = \sum_t n_{ij}(t)
 * where i, j are states and t is a time point.
 *
 * For SCFGs: we'd say n_{vw}(i,j) 
 * where v and w are states and (i,j) is a positional time point.
 * 
 * Note: Also calculates m_ij if the mx and mxo matricies
 *      were conditionally calculated.
 *
 * Args:
 *      mx      Inside matrix (precalculated)
 *      mxo     Outside matrix (precalculated)
 *      rna     sequence 
 *      len     length of said sequence
 *      model   parameters of current model
 *      probseq P(x|model)
 *
 * Returns:
 *      ret_nij (Allocated elsewhere!)
 *      1 on success; 0 on failure
 */
int
calcNvalsYRN(double ***mx, double ***mxo, char *rna, int len, PROBMOD *model,
      double probseq, PROBMOD *ret_nij)
{
   int i, j, k, l, d;
   double *trans, *semis, *emis, *stack;        /* Temp arrays for calc N_ij */
   double temp, left, right;    /* Temp values */
   double stackvalue;
   int debug = FALSE;

   trans = (double *) malloc (sizeof(double) *NTRANS);
   semis = (double *) malloc (sizeof(double) * ALPHA);
   emis = (double *) malloc (sizeof(double) * PAIRS);
   stack = (double *) malloc (sizeof(double) * QUADS);

   for (i = 0; i < NTRANS; i++) {
      trans[i] = -BIGFLOAT;
   }
   for (i = 0; i < QUADS; i++) {
      if (i < ALPHA) semis[i] = -BIGFLOAT;
      if (i < PAIRS) emis[i] = -BIGFLOAT;
      stack[i] = -BIGFLOAT;
   }

   for (j = 0; j < len; j++) {
      for (d = 1; d <= j+1; d++) {
	 i = j - d + 1;

	 /* Transitions: 
	  *   n_{vw}(i,j) = \frac{mxo[v][i][j] * mx[w][i][j] * emit[i-\delta][j-\delta] 
	  *   	* \theta_{vw}}{P(x|\theta)}
	  */
	 left = mxo[dpS][j][d] + mx[dpS][j][d-1] + model->singles[rna[i]] 
	    		+ model->transitions[TSL] - probseq;
	 trans[TSL] = DLogsum(trans[TSL], left);
	 if (d == 1) trans[TSE] = DLogsum(trans[TSE], left);

	 left = mxo[dpP][j][d] + mx[dpS][j][d] + model->transitions[TPS] - probseq;
	 trans[TPS] = DLogsum(trans[TPS], left);

	 if (j > 0) {
	    right = mxo[dpS][j][d] + mx[dpS][j-1][d-1] + model->singles[rna[j]]
	       + model->transitions[TSR] - probseq;
	    trans[TSR] = DLogsum(trans[TSR], right);
	    if (d == 1) trans[TSE] = DLogsum(trans[TSE], right);

	    left = mxo[dpS][j][d] + mx[dpP][j-1][d-2] + model->pairs[rna[i]][rna[j]] 
	       		+ model->transitions[TSP] - probseq;
	    trans[TSP] = DLogsum(trans[TSP], left);

	    stackvalue = model->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]];
	    left = mxo[dpP][j][d] + mx[dpP][j-1][d-2] + stackvalue 
	       		+ model->transitions[TPP] - probseq;
	    trans[TPP] = DLogsum(trans[TPP], left);

	 } else {
	    right = mxo[dpS][j][d] + model->transitions[TSE] + model->singles[rna[j]]
	       + model->transitions[TSR] - probseq;
	    trans[TSR] = DLogsum(trans[TSR], right);
	    trans[TSE] = DLogsum(trans[TSE], left);
	 }

	 for (k = i; k < j; k++) {
	    left = mxo[dpS][j][d] + mx[dpS][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)]
	       + model->transitions[TSB] - probseq;
	    trans[TSB] = DLogsum(trans[TSB], left);
	 }

	 /* Emissions:
	  * n_i(l) = P(\pi_l = i | x, \theta) = 
	  *     \frac{\alpha_i(l) \beta_j(l)}{P(x|theta)}
	  */
	 temp = mx[dpS][j][d] + mxo[dpS][j][d] - probseq;

	 /* Singles Emissions */
	 semis[rna[i]] = DLogsum(semis[rna[i]], temp);
	 semis[rna[j]] = DLogsum(semis[rna[j]], temp);

	 /* Pairs Emissions */
	 if (i != j) {
	    emis[idx(rna[i], rna[j])] = DLogsum(emis[idx(rna[i], rna[j])], temp);
	 }
	 /* Stacking Emissions */
      }
   }

   for (i = 0; i < NTRANS; i++) {
      ret_nij->transitions[i] = trans[i];
   }
   for (i = 0; i < ALPHA; i++) {
      ret_nij->singles[i] = semis[i];
      for (j = 0; j < ALPHA; j++) {
	 ret_nij->pairs[i][j] = emis[idx(i,j)];
	 for (k = 0; k < PAIRS; k++) {
	 }
      }
   }

   free(trans); free(semis); free(emis); free(stack);
   return (TRUE);
}

