#ifndef STATS_H_INCLUDED
#define STATS_H_INCLUDED

#define SSMAX 100       /* gather secondary structure stats max loop size */
/* These are linked to the defs of ALPHA in cfg.h 
 * ntX represents anything not in the standard alphabet (as defined in cfg.h)
 * */
#define ALPHAN (ALPHA+1)
#define ntX 	ALPHA		/* Bigger than largest nt value (ival > ALPHA) */
#define lpi(x)      (((x) < 1) || (x > (SSMAX-1))) ? 0 : x

/* General structure definition  terms */
struct totalstats {
  int nseq;		/* Total number of sequence */
  int Nfree;		/* Sequences which are N free */
  int containN;		/* Sequences which contain N's */

  int trust_pairs;	/* Total bp in all trusted structures */
  int test_pairs;	/* Total bp in all test structures */
  int trust_correct;	/* Total correct pred bp in trusted structures */
  int test_correct;	/* Total true bp in test structures */
  int positions;	/* Total number of bp */

  /* Keeping range variables */
  float sens_max;
  float sens_min;

  float spec_max;
  float spec_min;
};
typedef struct totalstats STATS;

struct secstruct_s {
  int nseq;	/* Number of sequences */
  int khsfailed; int Nfree; 
  int minlen; int maxlen;	/* Length characteristics */
  int minbp; int maxbp;	/* BP characteristics */

  /* Compositional Characterizations */
  int singles[ALPHAN];           /* A, C, G, T or U, or N */
  int pairs[ALPHAN][ALPHAN];      /* All possible pairings of nt */
  	/* ALPHA^2 possible stck matricies */
  int stack[((ALPHAN)*(ALPHAN))][ALPHAN][ALPHAN];       
  int lonepairs;	/* How many? */

  /* Loop compositional biases */
  int hpcomp[ALPHAN];
  int bulgecomp[ALPHAN]; int onentbulge[ALPHAN];
  int bulgeLcomp[ALPHAN];  int bulgeRcomp[ALPHAN];
  int intlpcomp[ALPHAN];
  int multiloop[ALPHAN];

  /* Loop Length distributions */
  int hairpin[SSMAX];   /* single stranded loops */
  int loop[SSMAX];      /* single stranded loops */
  int bulge[SSMAX];     /* single stranded loops */
  int stem[SSMAX];      /* uniterrupted stems */
  int bigloops;		/* Number of loops of size > 30 */

  int symmetric; int nonsymmetric;	/* Loops of different types */

  int positions;	/* Total collective length */
  int trusted;	/* Total collective bps */
};
typedef struct secstruct_s SSINFO;


extern int CompStruct (int len, char *trusted, char *test, STATS *totals, 
      int debug, int do_mathews, int ct_knots);
extern void PrintTableHeader();
extern void PrintTableLine (char *label, STATS statistics, int withranges);
extern void accumulateStats (STATS *total, STATS *global);
extern void PrintTotals (STATS statistics, int withranges);
extern void ZeroStats (STATS *statistics);

extern void ZeroSS(SSINFO *stats);
extern void gnuLoops(SSINFO *stats, FILE *ofp);

extern void calcLoopProbs(int counts[], float asprobs[]);
extern void calcCompProbs(int counts[], float asprobs[]);
extern void calcPairSums (int pairs[][ALPHAN], int sum[]);
extern void calcPairsProbs(int counts[][ALPHAN], float asprobs[][ALPHAN]);

extern void printLoopNFO(SSINFO *stats);
extern void printCompNFO(SSINFO *stats); 
extern void printPairNFO(SSINFO *stats);

#endif
