/* nusp_main.c 
 * RDD, Tue Aug 21 15:02:15 CDT 2001
 *
 * nusp_main.c -- permute parameters for CONUS
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"
#include"stats.h"


static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-m <file>     : Use parameters, grammar and scoring specified in model <file> \n\
-g <string>   : Use grammar <string>, defaults to NUS; ignored if model file specified \n\
-s <file>     : save model file to <file> \n\
-o <file>     : redirect output to <file>\n\
-x            : print out parameters of model \n\
-t            : print traceback\n\
-d            : debugging output \n\
-v            : verbose output \n\
-f            : debugging, print fill matrix from cyk \n\
-p            : print real with predicted structure\n\
-q            : print predicted structures in stockholm format \n\
-i            : print intermediate statistics \n\
-w            : print statistics over all test sequences (global) \n\
-c            : print ct output format for predicted structure\n\n\
-b <int>      : Permutate the probabilistic grammar by <int> percentage \n\
";
static char usage[]  = "Usage: conus_permutate [-options] <testfile1> <testfile2> ...\n";

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;
  int rule, transition, sign;

  /* Models info */
  MODEL nusmodel;
  MODEL permmodel;
  STATS stats;
  char label[20];

  if (!(ProcessOpts(&settings, &optid, argc, argv, usage, gramdesc, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  if (argc - optid < 1)
    Die("Incorrect number of command line arguments.\n%s\n%s\n", usage, optsline);
  
  SetupModel(&settings, &nusmodel);
  if (!(settings.useprob)) 
    Die("Must be using a training set or saved probabilistic model!\n%s\n%s\n", usage, optsline);

  /* Digitize Setup */
  SetAlphabet(hmmNUCLEIC);

  PrintProbModel(settings.ofp, &(nusmodel.probs), nusmodel.grammar);

  if (settings.permutatetype == NON) {
    fprintf(settings.ofp, "No permutation specified!\n");
  } else {
    fprintf(settings.ofp, "Permutation specified: ");
    if (settings.permutatetype == PER) printf("percent %d%%\n", settings.percentage);
    else fprintf(settings.ofp, "exact amount %6.5f.\n", settings.delta);

    while (!(argc - optid < 1)) {
      fprintf(settings.ofp, "\nPerforming permutation test on %s\n", argv[optid]);
      PrintTableHeader();
      gatherStats(argv[optid], &settings, &nusmodel, &stats, usage);
      PrintTableLine("Normal  (none)", stats, FALSE);
      /* Need a grammar production rule iterator! */
      for (rule = 0; rule < NDPS; rule ++) {
        for (transition = 0; transition < NTRANS; transition++) {
	/* sign = 0 is FALSE; sign = 1 is true */
	  for (sign = 0; sign < 2; sign ++) {
	  /* For each rule -- permutate and run all tests */
	    if (Rules[settings.grammar][rule][transition]) {
	      PermutateParameter(&nusmodel, rule, transition, sign, settings, &(permmodel.probs));
	      gatherStats(argv[optid], &settings, &permmodel, &stats, usage);
	      if (sign == FALSE) {
		sprintf(label, "%s (%s) +", dpNAME[rule], dptNAME[settings.grammar][transition]);
	      } else {
		sprintf(label, "%s (%s) -", dpNAME[rule], dptNAME[settings.grammar][transition]);
	      }
	      PrintTableLine(label, stats, FALSE);
	    } /* If this transition is legal in this rule */
	  } /* For each possible sign of delta */
        } /* For each transition */
      } /* For each rule */
      fprintf(settings.ofp, "End permutation test on %s\n\n", argv[optid]);
      optid ++;
    } /* end while more test files */
  } /* end else permutatetype != NON */
}
