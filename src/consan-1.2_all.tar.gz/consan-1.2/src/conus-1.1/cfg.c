/* cfg.c
 * RDD, Fri Aug 24 12:51:19 2001
 * 
 * Manipulation of an SCFG as a datastructure
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include "squid.h"
#include "cfg.h"

/* Function: normalizeTransInt, normalizeTransProb
 * Date: Tue Oct  8 14:55:40 CDT 2002 [St Louis]
 *
 * Purpose: Given transition matrix, normalize into probs
 *
 * Args:
 * 	transitions	Transition portion of parameter matrix
 * 	grammar		Grammar to assume for normalization
 *
 * Returns:	-- void -- 
 */
void
normalizeTransProb (float *transitions, int grammar)
{
   int i, j, contains;
   float denom;

   for (i = 0; i < NDPS; i++) {
      denom = 0; contains = FALSE;
      for (j = 0; j < NTRANS; j++) {
	 if (Rules[grammar][i][j] > 0) {
	    contains = TRUE;
	    denom += transitions[j];
	 }
      }
      if (contains) {
	 for (j = 0; j < NTRANS; j++) {
	    if (Rules[grammar][i][j] > 0) {
	       transitions[j] = transitions[j] / denom;  
	    }
	 }
      }
   }
}
void 
normalizeTransInt (int *transitions, int grammar)
{
   int i, j, contains;
   int denom;

   for (i = 0; i < NDPS; i++) {
      denom = -BIGINT; contains = FALSE;
      for (j = 0; j < NTRANS; j++) {
	 if (Rules[grammar][i][j] > 0) {
	    contains = TRUE;
	    denom = ILogsum(denom, transitions[j]);
	 }
      }
      if (contains) {
	 for (j = 0; j < NTRANS; j++) {
	    if (Rules[grammar][i][j] > 0) {
	       transitions[j] = transitions[j] - denom;  
	    }
	 }
      }
   }
}

/* Function: CopyIntModel, CopyIntEmissions, CopyProbModel
 * 		CopyProbEmissions
 * Date:     RDD, Wed Feb 20 13:15:32 CST 2002 [St Louis]
 *
 * Purpose: debugging function, copies models
 *
 * Note: Assumes allocation of models external to these
 * 	functions.
 *
 * Returns: nothing
 */
void
CopyIntModel (INTMOD *from, INTMOD *to)
{
  int i;

  CopyIntEmissions (from, to);
  for (i = 0; i < NTRANS; i ++) {
    to->transitions[i] = from->transitions[i];
  }
}

void
CopyIntEmissions (INTMOD *from, INTMOD *to)
{
  int i, j, k, l;

  for (i = 0; i < ALPHA; i++) {
    for (j = 0; j < ALPHA; j++) {
      for (k = 0; k < ALPHA; k++) {
        for (l = 0; l < ALPHA; l++) {
          to->stack[(4*k+l)][i][j] = from->stack[(4*k+l)][i][j];
        }
      }
      to->pairs[i][j] = from->pairs[i][j];
    }
    to->singles[i] = from->singles[i];
    to->loopcomp[i] = from->loopcomp[i];
    to->hpcomp[i] = from->hpcomp[i];
    to->bulgecomp[i] = from->bulgecomp[i];
  }
  for (i = 0; i < MAXLOOP; i++) {
    to->loop[i] = from->loop[i];
    to->hairpin[i] = from->hairpin[i];
    to->bulge[i] = from->bulge[i];
  }
}

void
CopyProbModel (PROBMOD *from, PROBMOD *to)
{
  int i;

  CopyProbEmissions (from, to);
  for (i = 0; i < NTRANS; i ++) {
    to->transitions[i] = from->transitions[i];
  }
}

void
CopyProbEmissions (PROBMOD *from, PROBMOD *to)
{
  int i, j, k, l;

  for (i = 0; i < ALPHA; i++) {
    for (j = 0; j < ALPHA; j++) {
      for (k = 0; k < ALPHA; k++) {
        for (l = 0; l < ALPHA; l++) {
          to->stack[(4*k+l)][i][j] = from->stack[(4*k+l)][i][j];
        }
      }
      to->pairs[i][j] = from->pairs[i][j];
    }
    to->singles[i] = from->singles[i];
    to->loopcomp[i] = from->loopcomp[i];
    to->hpcomp[i] = from->hpcomp[i];
    to->bulgecomp[i] = from->bulgecomp[i];
  }
  for (i = 0; i < MAXLOOP; i++) {
    to->loop[i] = from->loop[i];
    to->hairpin[i] = from->hairpin[i];
    to->bulge[i] = from->bulge[i];
  }
}

/* Function: PrintModel
 * Date:     RDD, Sat Dec  8 16:09:49 2001 [St. Louis]
 *
 * Purpose:  print the parameters set for a model, 
 * 	use model's probabilistic flag to determine 
 * 	if we print integer or float version.
 *
 * Args:     
 *      fp       location to print
 *      cfg      the model to print
 *
 * Returns:  nothing
 */
void
PrintModel(FILE *fp, MODEL *cfg)
{
  printTransModel(fp, cfg, cfg->probabilistic);
  printEmissionMatricies(fp, cfg, cfg->probabilistic);
  if (grFAMILY[cfg->grammar] != NUN) printStackMatrices (fp, cfg, cfg->probabilistic);
  if (grFAMILY[cfg->grammar] == ZKG) printLoops(fp, cfg, cfg->probabilistic);
}

/* Function: PrintFullModel, PrintProbModle, PrintIntModel
 * Date:     RDD, Sat Dec  8 16:09:49 2001 [St. Louis]
 *
 * Purpose:  Utilize the PrintModel to print different
 * 	subsets of parameters 
 *
 * Args:     
 *      fp       location to print
 *      cfg      the model to print
 *
 * Returns:  nothing
 */
void
PrintFullModel(FILE *fp, MODEL *cfg)
{
  int tempprob;

  tempprob = cfg->probabilistic;

  cfg->probabilistic = FALSE;
  printf("Integer Form:\n");
  PrintModel(fp, cfg);

  cfg->probabilistic = TRUE;
  printf("Float Form:\n");
  PrintModel(fp, cfg);

  cfg->probabilistic = tempprob;
}

void
PrintProbModel(FILE *fp, PROBMOD *icfg, int grammar)
{
  MODEL temp;

  CopyProbModel(icfg, &(temp.probs));
  temp.grammar = grammar;

  temp.probabilistic = TRUE;
  printf("Probs:\n");
  PrintModel(fp, &temp);
}

void
PrintIntModel(FILE *fp, INTMOD *icfg, int grammar)
{
  MODEL temp;

  CopyIntModel(icfg, &(temp.scores));
  temp.grammar = grammar;

  temp.probabilistic = FALSE;
  printf("Scores:\n");
  PrintModel(fp, &temp);
}

void
PrintAsProbModel(FILE *fp, INTMOD *icfg, int grammar)
{
  MODEL temp;

  CopyIntModel(icfg, &(temp.scores));
  temp.grammar = grammar;
  InvLogifySCFG(&(temp.scores), &(temp.probs));

  temp.probabilistic = TRUE;
  printf("Probs:\n");
  PrintModel(fp, &temp);
}
void
PrintAsProbModelD(FILE *fp, PROBMOD *icfg, int grammar)
{
  MODEL temp;

  temp.grammar = grammar;
  InvDLogifySCFG(icfg, &(temp.probs));

  temp.probabilistic = TRUE;
  printf("Probs:\n");
  PrintModel(fp, &temp);
}

void
PrintAsIntModel(FILE *fp, PROBMOD *icfg, int grammar)
{
  MODEL temp;

  CopyProbModel(icfg, &(temp.probs));
  temp.grammar = grammar;
  LogifySCFG(&(temp.probs), &(temp.scores));

  temp.probabilistic = FALSE;
  printf("Prob. Model as Scores:\n");
  PrintModel(fp, &temp);
}

/* Function: printTransModel
 * Date:     RDD, Wed Oct 10 08:03:22 2001 [St. Louis]
 *
 * Purpose:  Debugging -- prints transition parameters
 *
 * Args:     
 *       fp	  to where this should be printed
 *       mod	  model (prob and score0
 *       useprobs should use prob model
 *
 * Returns: void 
 */
void 
printTransModel(FILE *fp, MODEL *mod, int useprobs)
{
  int i,j;
  int contains;

  contains = FALSE;

  fprintf (fp, "Transitions Grammar is %s\n\n", grNAME[mod->grammar]);
  fprintf (fp, "Transition Matrix:\n");
  if (useprobs) {
     for (i = 0; i < NDPS; i++) {
	for (j = 0; j < NTRANS; j++) {
	   if (Rules[mod->grammar][i][j] > 0) {
	      contains = TRUE; 
	   }
	}
	if (contains) {
	   fprintf (fp, "Nonterminal %s:\t", dpNAME[i]);
	   for (j = 0; j < NTRANS; j++) {
	      if (Rules[mod->grammar][i][j]) {
		 fprintf (fp, "%s: %1.4f ", dptNAME[mod->grammar][j], 
		       mod->probs.transitions[j]);
	      }
	   }
	   fputs("\n", fp);
	}
	contains = FALSE;
    }
  } else {
     for (i = 0; i < NDPS; i++) {
	for (j = 0; j < NTRANS; j++) if (Rules[mod->grammar][i][j] > 0) contains = TRUE; 
	if (contains) {
	   fprintf (fp, "Nonterminal %s:\t", dpNAME[i]);
	   for (j = 0; j < NTRANS; j++) {
	      if (Rules[mod->grammar][i][j]) {
		 fprintf (fp, "%s: %4d ", dptNAME[mod->grammar][j], 
		       mod->scores.transitions[j]);
	      }
	   }
	   fputs("\n", fp);
	}
	contains = FALSE;
     }
  }
  fputs("\n", fp);
}

/* Function: printEmissionMatricies
 * Date:     RDD, Wed Oct 10 08:03:22 2001 [St. Louis]
 *
 * Purpose:  Debugging -- prints basic (singles
 * 		and pairs) emission parameters
 *
 * Args:     
 *       fp	  to where this should be printed
 *       mod	  model (prob and score0
 *       useprobs should use prob model
 *
 * Returns: void 
 */
void
printEmissionMatricies(FILE *fp, MODEL *mod, int useprobs)
{
  int i, j;

  fprintf (fp, "Pairs Matrix:\n");
  if (useprobs) {
    for (i = 0; i < ALPHA; i++) {
      fprintf (fp, "%6s ", baseNAME[i]);
    }
    fprintf (fp, "\n");
    for (i = 0; i < ALPHA; i++) {
      fprintf (fp, "%s ", baseNAME[i]);
      for (j=0; j< ALPHA; j++) {
	fprintf (fp, "%1.4f ", mod->probs.pairs[i][j]);
      }
      fputs("\n", fp);
    }
  } else {
    fprintf (fp, "  ");		/* Necessary spacing for ints */
    for (i = 0; i < ALPHA; i++) {
      fprintf (fp, "%4s ", baseNAME[i]);
    }
    fprintf (fp, "\n");
    for (i = 0; i < ALPHA; i++) {
      fprintf (fp, "%s ", baseNAME[i]);
      for (j=0; j< ALPHA; j++) {
	fprintf (fp, "%4d ", mod->scores.pairs[i][j]);
      }
      fputs("\n", fp);
    }
  }

  fprintf (fp, "Singles Matrix:\n");
  if (useprobs) {
    for (i = 0; i < ALPHA; i++) 
      fprintf (fp, "%s %1.4f  ", baseNAME[i], mod->probs.singles[i]);
  } else {
    for (i = 0; i < ALPHA; i++) 
      fprintf (fp, "%s %4d  ", baseNAME[i], mod->scores.singles[i]);
  }
  fputs("\n\n", fp);

}

/* Function: printStackMatrices
 * Date:     RDD, Wed Oct 10 08:03:22 2001 [St. Louis]
 *
 * Purpose:  Debugging -- prints stacking 
 * 		emission parameters
 *
 * Args:     
 *       fp	  to where this should be printed
 *       mod	  model (prob and score0
 *       useprobs should use prob model
 *
 * Returns: void 
 */
void
printStackMatrices (FILE *fp, MODEL *mod, int useprobs)
{
  int i, j, k;
  int bd;

  bd = ALPHA * ALPHA;

  fprintf (fp, "Stacking Matrices:\n");
  for (k = 0; k < bd; k++) {
    fprintf (fp, "Stacking for %d\n", k);
    fprintf (fp, "%6c %6c %6c %6c \n", 'A', 'C', 'G', 'U');
    for (i = 0; i < ALPHA; i++) {
      fprintf (fp, "%s ", baseNAME[i]);
      if (useprobs) {
	for (j=0; j< ALPHA; j++) {
	  fprintf (fp, "%1.4f ", mod->probs.stack[k][i][j]);
	}
      } else {
	for (j=0; j< ALPHA; j++) {
	  fprintf (fp, "%6d ", mod->scores.stack[k][i][j]);
	}
      }
      fputs("\n", fp);
    } 
    fputs("\n", fp);
  }
  fputs("\n", fp);
}

/* Function: printLoops
 * Date:     RDD, Wed Oct 10 08:03:22 2001 [St. Louis]
 *
 * Purpose:  Debugging -- prints loop emission parameters
 *
 * Args:     
 *       fp	  to where this should be printed
 *       mod	  model (prob and score0
 *       useprobs should use prob model
 *
 * Returns: void 
 */
void
printLoops (FILE *fp, MODEL *mod, int useprobs)
{
  int i;

  fprintf (fp, "Loop lengths: \n");
  for (i = 0; i < MAXLOOP; i++) {
    if (useprobs) {
      fprintf(fp, "loop[%d] = %1.4f ", i, mod->probs.loop[i]);
    } else {
      fprintf(fp, "loop[%d] = %6d ", i, mod->scores.loop[i]);
    }
    if ((i%5) == 0) fputs("\n", fp);
  }
  fputs("\nLoop Composition: \n", fp);
  if (useprobs) {
    for (i = 0; i < ALPHA; i++) 
      fprintf (fp, "%s %1.4f  ", baseNAME[i], mod->probs.loopcomp[i]);
  } else {
    for (i = 0; i < ALPHA; i++) 
      fprintf (fp, "%s %4d  ", baseNAME[i], mod->scores.loopcomp[i]);
  }

  fprintf (fp, "\n\nHairpin lengths: \n");
  for (i = 0; i < MAXLOOP; i++) {
    if (useprobs) {
      fprintf(fp, "hpin[%d] = %1.4f ", i, mod->probs.hairpin[i]);
    } else {
      fprintf(fp, "hpin[%d] = %6d ", i, mod->scores.hairpin[i]);
    }
    if ((i%5) == 0) fputs("\n", fp);
  }
  fputs("\nHairpin Composition: \n", fp);
  if (useprobs) {
    for (i = 0; i < ALPHA; i++) 
      fprintf (fp, "%s %1.4f  ", baseNAME[i], mod->probs.hpcomp[i]);
  } else {
    for (i = 0; i < ALPHA; i++) 
      fprintf (fp, "%s %4d  ", baseNAME[i], mod->scores.hpcomp[i]);
  }

  fprintf (fp, "\n\nBulge lengths: \n");
  for (i = 0; i < MAXLOOP; i++) {
    if (useprobs) {
      fprintf(fp, "bulge[%d] = %1.4f ", i, mod->probs.bulge[i]);
    } else {
      fprintf(fp, "bulge[%d] = %6d ", i, mod->scores.bulge[i]);
    }
    if ((i%5) == 0) fputs("\n", fp);
  }
  fputs("\nBulge Composition: \n", fp);
  if (useprobs) {
    for (i = 0; i < ALPHA; i++) 
      fprintf (fp, "%s %1.4f  ", baseNAME[i], mod->probs.bulgecomp[i]);
  } else {
    for (i = 0; i < ALPHA; i++) 
      fprintf (fp, "%s %4d  ", baseNAME[i], mod->scores.bulgecomp[i]);
  }
  fputs("\n\n", fp);
}

/* Function: ZeroModel, zeroProbMod, zeroIntMod
 * Date:     RDD, Thu Nov 15 17:55:28 2001 [St. Louis]
 *
 * Purpose:  Initialize the contents of the models
 * to zero
 *
 * Returns:  void
 */
void
ZeroModel (MODEL *cfg)
{
  zeroProbMod(&(cfg->probs));
  zeroIntMod(&(cfg->scores));
}

void
zeroProbMod(PROBMOD *probs)
{
  int i,j,k,l;

  for (i = 0; i < NTRANS; i++) {
    probs->transitions[i] = 0.0;
  }
  for (i = 0; i < ALPHA; i++) {
    for (j = 0; j < ALPHA; j++) {
      for (k = 0; k < ALPHA; k++) {
        for (l = 0; l < ALPHA; l++) {
          probs->stack[(4*k+l)][i][j] = 0.0;
        }
      }
      probs->pairs[i][j] = 0.0;
    }
    probs->singles[i] = 0.0;
    probs->loopcomp[i] = 0.0;
    probs->hpcomp[i] = 0.0;
    probs->bulgecomp[i] = 0.0;
  }
  for (i = 0; i < MAXLOOP; i++) {
    probs->loop[i] = 0.0;
    probs->hairpin[i] = 0.0;
    probs->bulge[i] = 0.0;
  }
}

void
zeroIntMod(INTMOD *probs)
{
 int i,j,k,l;

  for (i = 0; i < NTRANS; i++) {
    probs->transitions[i] = 0;
  }
  for (i = 0; i < ALPHA; i++) {
    for (j = 0; j < ALPHA; j++) {
      for (k = 0; k < ALPHA; k++) {
        for (l = 0; l < ALPHA; l++) {
          probs->stack[(4*k+l)][i][j] = 0;
        }
      }
      probs->pairs[i][j] = 0;
    }
    probs->singles[i] = 0;
    probs->loopcomp[i] = 0;
    probs->hpcomp[i] = 0;
    probs->bulgecomp[i] = 0;
  }
  for (i = 0; i < MAXLOOP; i++) {
    probs->loop[i] = 0;
    probs->hairpin[i] = 0;
    probs->bulge[i] = 0;
  }
}

