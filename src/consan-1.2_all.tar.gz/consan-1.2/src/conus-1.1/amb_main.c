/* amb_main.c */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-m <file>     : (req) Use model <file> \n\
-v            : verbose output \n\
-i            : ignore given structure -- use CYK calculated structure \n\
-d            : debugging output \n\
-x            : print out parameters of model \n\
-t            : debugging, print traceback\n\
-c            : debugging, print CT format of structure \n\
-f            : debugging, print fill matrix from cyk \n\
";

static char usage[]  = "Usage: ambtest -m model [-options] <seqfile in>\n";

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;

  FILE *ofp, *ifp;

  /* ReadSeq variables */
  SQFILE *sqfp; SQINFO sqinfo;
  int sformat;
  char *rna; 
  char *cykss; 
  int *ctstruct; 
  int *cykct; 
  MODEL nusmodel;
  PROBMOD dlogs;
  struct trace_s *trc;
  struct trace_s *cyktrc;

  /* from Inside */
  double ***matxGCI;
  char *drna;
  int i, j;
  double cInsVal; 
  double fTval = 0.; 
  int gVal, flag;
  int noerror, total;
  int ignored, ambbase, illegal, probs;	/* Why do we ignore some seqs? */
  int score, usecyk;
  char *khs;

  if (!(ProcessOpts(&settings, &optid, argc, argv, usage, 
	      "", optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  if ((argc - optid != 1) ||  (settings.modelfile == NULL)) {
    Die("Incorrect number of command line arguments.\n%s\n%s\n", 
	  usage, optsline);
  }

  SetupModel(&settings, &nusmodel); 
  DLogifySCFG(&(nusmodel.probs), &dlogs);
  LogifySCFG(&(nusmodel.probs), &(nusmodel.scores));
  
  /* Digitize Sequence Setup*/
  SetAlphabet(hmmNUCLEIC);
  if (settings.debugg) {
     PrintFullModel(settings.ofp, &nusmodel);
     PrintProbModel(stdout, &dlogs, settings.grammar);
  }

  /* Read input file into RNA array and filter for non-RNA residues */
  if ((sqfp = SeqfileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL) 
     Die("Failed to open sequence file %s\n%s\n", argv[optid], usage);

  SetAlphabet(hmmNUCLEIC);

  flag = FALSE; total = 0;
  ignored = ambbase = illegal = probs = 0;
  while ((ReadSeq(sqfp, sformat, &rna, &sqinfo)) && (flag == FALSE)) {
     ToRNA(rna);	total++;
     noerror = TRUE;

     /* Ignore strings containing ambiguous bases.
      * Alternative would be intelligent shift of those bases,
      * but this is easier. */
     if (!ContainsAmbiguous(rna, sqinfo.len)) {
	if (settings.verbose) 
	   fprintf(settings.ofp, "Sequence %s:\n", sqinfo.name); 
	cInsVal = 0.;

	/* If given structure use it */
	if ((sqinfo.flags & SQINFO_SS) && (!settings.istats)) {
	   if ((settings.verbose) || (settings.debugg)) 
	      printf("Using given structure\n");
	   if (!KHS2Trace(rna, sqinfo.ss, sqinfo.len, &trc, FALSE, 
		    settings.grammar)) {
	      /* A trusted structure may be "illegal" under a particular 
	       * grammar, in which case we want to ignore it
	       */
	      if (settings.verbose) 
		 printf("%s ignored; KHS2Trace failed \n", sqinfo.name);
	      ignored++; illegal++;
	      noerror = FALSE;
	   } else {
	      khs = sqinfo.ss;
	   }
	   usecyk = FALSE;
	   /* else generate a structure via CYK */
	} else {
	   if ((settings.verbose) || (settings.debugg))
	      printf("Using structure from CYK\n");
	   /* Best prediction */
	   trc = (struct trace_s *)CYK(rna, sqinfo.len, settings.grammar,
		 &(nusmodel.scores), &settings, &score);
	   if (trc == NULL) {
	      /* This kind of problem is a BUG! */
	      if ((settings.verbose) || (settings.debugg))
		 printf("PROBLEM: %s ignored; CYK failed \n", sqinfo.name);
	      ignored++; probs++;
	      noerror = FALSE;
	   } else {
	      trace2khs(trc, rna, sqinfo.len, 1, &khs);
	      usecyk = TRUE;
	   }
	}
	if (noerror) {
	   if (settings.traceback) PrintTrace(stdout, trc, rna);

	   /* Score the given structure */
	   traceScore(rna, sqinfo.len, trc, &(nusmodel.scores), 
		 settings.grammar, &gVal);
	   dTraceScore(rna, sqinfo.len, trc, &dlogs, 
		 settings.grammar, &fTval);

	   /* Convert structure to ct */
	   if (! KHS2ct(khs, sqinfo.len, FALSE, &ctstruct)) { 
	      printf("[bad trusted structure %s]\n", sqinfo.name); 
	   }
	   if (settings.ctoutput) 
	      Print_CT(stdout, rna, sqinfo.len, ctstruct, sqinfo.name);

	   /* Calculate the P(structure | model) for given structure */
	   noerror = Inside(rna, sqinfo.len, nusmodel.grammar, &dlogs, 
		 &settings, ctstruct, &cInsVal, &matxGCI);

	   if (noerror) {
	      if (fTval == cInsVal) {
		 if (settings.verbose || settings.debugg) {
		    fprintf(settings.ofp, "%s is Unambiguous:\n", sqinfo.name);
		    fprintf(settings.ofp, "Float TraceScore %f \n", fTval);
		    fprintf(settings.ofp, "Cond. Inside: %f  \n", cInsVal);
		 }
	      } else {
		 flag = TRUE;
		 if (settings.verbose || settings.debugg) {
		    fprintf(settings.ofp, "Ambiguity test failed!!! (%s) \n", 
			  sqinfo.name);
		    fprintf(settings.ofp, "Float TraceScore %f \n", fTval);
		    fprintf(settings.ofp, "Cond. Inside: %f  \n", cInsVal);
		 }
	      }
	   }
           freeFillMxD(matxGCI, nusmodel.grammar);
	   free(ctstruct);
	   if (usecyk) free(khs);
	}
     } else {
	ignored++;  ambbase++;
	if (settings.verbose) 
	   printf("%s ignored; contains ambiguous base(s)\n", sqinfo.name);
     }
     FreeSequence(rna, &sqinfo);
  }
  SeqfileClose(sqfp);

  printf("\nFor specified set %s (%d examined),\n", argv[optid], total);
  if (ignored > 0) {
     printf("Note: some sequences were ignored:\n");  
     if (ambbase > 0) printf("%d contained ambiguous bases\n", ambbase);
     if (illegal > 0) printf("%d were illegal under this grammar\n", illegal);
     if (probs > 0) printf("%d were problematic (ie some other problem) \n",
	   probs);
  }
  if (flag == FALSE) {
     printf("\tgrammar is unambiguous.\n");
  } else {
     printf("\tgrammar is AMBIGUOUS!\n");
  }
}
