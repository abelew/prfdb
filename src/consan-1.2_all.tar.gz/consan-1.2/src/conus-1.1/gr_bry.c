/* gr_bry.c
 * RDD, Tue Apr 30 10:13:44 CST 2002
 *
 * Implementations of grammar specific routines for BRY 
 *
 * Bulge Little Unambiguous Yarn: 		(BRY)
 *	S -> aS | T | end
 * 	T -> Ta | aPa' | TaPa'
 *	P -> aPa' | x aPa' | aPa' x | N
 *	N -> aaS | Taa | MT
 *	M -> aM | J
 *	J -> Ja | aPa'
 *
 * *************** AMBIGUOUS **********************
 *
 * These implementations assume a digitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"

/* Function: cykInitB
 * Date:     RDD, Jul 19 08:21:54 CST 2002 [St Louis] 
 *
 * Purpose:  Initialize CYK fill matrix for BRY grammars 
 *
 * Args:     
 *	mx	fill matrix (integer log odds form)
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cykInitB(int ***mx, INTMOD *model, char *rna, int len)
{
   int j, d;

   for (d = 0; d <= len; d++) { 
      for (j = d; j < len; j++) {
	 mx[dpS][j][d] = model->transitions[TSE];
	 mx[dpT][j][d] = -BIGINT;
	 mx[dpP][j][d] = -BIGINT;
	 mx[dpN][j][d] = -BIGINT;
	 mx[dpM][j][d] = -BIGINT;
	 mx[dpJ][j][d] = -BIGINT;
      }
      if (d > 0) {
	 mx[dpS][d-1][d] = model->transitions[TSE];
	 mx[dpT][d-1][d] = -BIGINT;
	 mx[dpP][d-1][d] = -BIGINT;
	 mx[dpN][d-1][d] = -BIGINT;
	 mx[dpM][d-1][d] = -BIGINT;
	 mx[dpJ][d-1][d] = -BIGINT;
      }
   }
}

/* Function: cykFillB
 * Date:     RDD, Jul 19 08:21:54 CST 2002 [St Louis] 
 *
 * Purpose:  Fills CYK matrix for BRY 
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	sc	parameters 
 *		(integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Notes: 
 *      Must fill T before S as one rule in S allows S -> T
 *      and therefore the current cell of T will need to
 *      already known.
 *
 * Returns:  void 
 */
void
cykFillB(int ***mx, INTMOD *pr, char *rna, int len, int grammar)
{
  int d, i, j, k;       /* Loop indicies */
  int max;              /* Maximum value seen so far */
  int cursc, cursc2;    /* Current score */
  int tmp;
  int stackvalue;	

  /* Recursion */
  for (d = 1; d <= len; d++) {
     for (j = d-1; j < len; j++) {
	i = j - d + 1; max = -BIGINT;

	/* T -> Ta */
	if (j > 0) {
	   cursc = mx[dpT][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TTT];
	   if (cursc > max) max = cursc;

	   /* T -> aPa' */
	   if (d > 1) {
	      cursc = mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TTP];
	      if ((cursc > max) && (d-1 > HLEN)) max = cursc; 
	   }
	}
	/* T -> T aPa' */
	for (k = i+1; k < j-1; k++) {
	   tmp = dist(k+2, j-1);
	   cursc = mx[dpT][k][dist(i,k)] + mx[dpP][j-1][tmp]
	      + pr->pairs[rna[k+1]][rna[j]] + pr->transitions[TTB];
	   if ((cursc > max) && (tmp-1 > HLEN)) max = cursc; 
	}
	/* T -> Ta | aPa' | T aPa' */
	mx[dpT][j][d] = max;

	/* S -> aS | T | end */
	max = -BIGINT;
	/* S -> aS */
	cursc = mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSS];
	if (cursc > max) max = cursc; 
	/* S -> T */
	cursc = mx[dpT][j][d] + pr->transitions[TST];
	if (cursc > max) max = cursc;
	/* S -> aS | T | end */
	mx[dpS][j][d] = max;

	/* J -> Ja | aPa' */
	if (j > 0) {
	   cursc = mx[dpJ][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TJJ];
	   if (d-1 > HLEN) {
	      cursc2 = mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]]
		 + pr->transitions[TJP]; 
	   } else { cursc2 = -BIGINT; }
	}
	if (cursc2 > cursc) { mx[dpJ][j][d] = cursc2; }
	else { mx[dpJ][j][d] = cursc; }

	/* M -> aM | J */
	cursc = mx[dpM][j][d-1] + pr->singles[rna[i]] + pr->transitions[TMM];
	cursc2 = mx[dpJ][j][d] + pr->transitions[TMJ];
	if (cursc > cursc2) { mx[dpM][j][d] = cursc; }
	else { mx[dpM][j][d] = cursc2; }

	/* N -> aaS | Taa | MT */
	max = -BIGINT;
	/* N -> aaS */
	if (d > 1) {
	   cursc = mx[dpS][j][d-2] + pr->singles[rna[i]] + pr->singles[rna[i+1]] 
	      + pr->transitions[TNL];
	   if (cursc > max) max = cursc; 
	   if (j > 1) {
	      /* N -> Taa */
	      cursc = mx[dpT][j-2][d-2] + pr->singles[rna[j]] + pr->singles[rna[j-1]] 
		 + pr->transitions[TNR];
	      if (cursc > max) max = cursc;
	   }

	}
	/* N -> MT */ 
	for (k = i+1; k < j-1; k++) {
	   cursc = mx[dpM][k][dist(i,k)] + mx[dpT][j][dist(k+1,j)] + pr->transitions[TNB];
	   if (cursc > max) max = cursc; 
	}
	/* N -> aaS | Taa | MT */
	mx[dpN][j][d] = max;

	/* P -> aPa | x aPa' | aPa' x | N */
	max = -BIGINT;
	/* Stacking! Can't be in P state at edges!  */
	if ((i > 0) && (j < len-1)) {
	   stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]];
	   if  ((j > 0) && (d > 1)) {
	      /* P -> aPa' */
	      cursc = mx[dpP][j-1][d-2] + stackvalue + pr->transitions[TPP];
	      if ((cursc > max) && (d-1 > HLEN)) max = cursc; 
	   }

	   /* P -> N */
	   cursc = mx[dpN][j][d] + pr->transitions[TPN];
	   if (cursc > max) max = cursc;
	   if (j > 0) {
	      if (d-2 > HLEN) { 
		 /* P -> x aPa' */
		 stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i+1]][rna[j]];
		 tmp = dist(i+2, j-1);
		 cursc = mx[dpP][j-1][tmp] + stackvalue + pr->singles[rna[i]] 
		    + pr->transitions[TPL];
		 if ((cursc > max) && (tmp-1 > HLEN+2)) max = cursc;

		 if (j > 1) {
		    /* P -> aPa' x */
		    stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j-1]];
		    tmp = dist(i+1, j-2);
		    cursc = mx[dpP][j-2][tmp] + stackvalue + pr->singles[rna[j]] 
		       + pr->transitions[TPR];
		    if ((cursc > max) && (tmp-1 > HLEN+2)) max = cursc; 
		 }
	      }
	   }
	}
	/* P -> aPa | x aPa' | aPa' x | N */
	mx[dpP][j][d] = max;
     }
  }
}

/* Function: cykTraceB
 * Date:     RDD, Tue Jan 22 15:24:12 CST 2002 [St Louis]
 *
 * Purpose:  Build traceback tree for BRY 
 *
 * Args:
 *	mx	matrix in which to calculate cyk
 *	pr	parameters in integer form
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns: --void --
 */
struct trace_s *
cykTraceB(int ***mx, INTMOD *pr, char *rna, int len, int grammar)
{
  int d, i, j, k, mtx;   /* Indices */
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (len -1), TRE));

  /* Repeat until stack is empty */
  while (curr = PopTracestack(stack)) {
    /* Set i and j from items in stack */
    i = curr->emitl; j = curr->emitr; mtx = curr->nonterminal;
    d = j - i + 1;

    if (i > j) { 		/* S(R) -> end */
      curr->emitl = -1; curr->emitr = -1; 
      curr->transition = TSE; curr->nonterminal = dpS; 
      continue;
    } else if (mtx == dpS) {
      /* S -> aS | T | end */
      if ((mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSS]) == mx[dpS][j][d]) {
        curr->emitr = -1; curr->transition = TSS; 
        PushTracestack(stack, AttachTrace (curr, dpS, i+1, j, TRE));
      } else {
	/* Assumes: ((mx[dpT][j][d] + pr->transitions[TST]) == mx[dpS][j][d]) */
        curr->emitr = -1; curr->emitl = -1; curr->transition = TST; 
        PushTracestack(stack, AttachTrace (curr, dpT, i, j, TRE));
      }

    } else if (mtx == dpT) {
      /* T -> Tb | aPa' | T aPa' */
      if ((mx[dpT][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TTT]) == mx[dpT][j][d]) {
        curr->emitl = -1; curr->transition = TTT; 
        PushTracestack(stack, AttachTrace (curr, dpT, i, j-1, TRE));
      } else if ((mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TTP]) 
	    					== mx[dpT][j][d]) {
        curr->transition = TTP;
        PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TRE));
      } else {
        for (k = i+1; k < j-1; k++) {
          if ((mx[dpT][k][dist(i,k)] + mx[dpP][j-1][dist(k+2,j-1)] + pr->pairs[rna[k+1]][rna[j]] 
		   		+ pr->transitions[TTB]) == mx[dpT][j][d]) {
            curr->emitl = k+1; curr->transition = TTB;
            PushTracestack(stack, AttachTrace (curr, dpP, k+2, j-1, TRE));
            PushTracestack(stack, AttachTrace (curr, dpT, i, k, TRE));
	    k = j;	/* Short circuit */
          } /* End if */
        } /* End for (bifurcation points) */
      } 

    } else if (mtx == dpP) {
      if ((mx[dpP][j-1][d-2] + pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]] 
			      + pr->transitions[TPP]) == mx[dpP][j][d]) {
	curr->transition = TPP;
	PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TRE));
      } else if ((mx[dpP][j-1][dist(i+2,j-1)] + pr->singles[rna[i]] + pr->transitions[TPL] +
		pr->stack[idx(rna[i-1],rna[j+1])][rna[i+1]][rna[j]]) == mx[dpP][j][d]) {
	curr->transition = TPL; curr->emitl = i+1;
	PushTracestack(stack, AttachTrace (curr, dpP, i+2, j-1, TRE));
      } else if ((mx[dpP][j-2][dist(i+1,j-2)] + pr->singles[rna[j]] + pr->transitions[TPR] +
		pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j-1]]) == mx[dpP][j][d]) {
	curr->transition = TPR; curr->emitr = j-1;
	PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-2, TRE));
      } else {
        curr->transition = TPN; curr->emitl = -1; curr->emitr = -1;
        PushTracestack(stack, AttachTrace (curr, dpN, i, j, TRE)); 
      }
    } else if (mtx == dpN) {
      if ((mx[dpS][j][d-2] + pr->singles[rna[i]] + pr->singles[rna[i+1]] + 
		pr->transitions[TNL]) == mx[dpN][j][d]) {
        curr->emitr = -1; curr->emitl = i+1; curr->transition = TNL; 
        PushTracestack(stack, AttachTrace (curr, dpS, i+2, j, TRE));
      } else if ((mx[dpT][j-2][d-2] + pr->singles[rna[j]] + pr->singles[rna[j-1]] + 
		pr->transitions[TNR]) == mx[dpN][j][d]) {
        curr->emitl = -1; curr->emitr = j-1; curr->transition = TNR; 
        PushTracestack(stack, AttachTrace (curr, dpT, i, j-2, TRE));
      } else {
        for (k = i+1; k < j-1; k++) {
          if ((mx[dpM][k][dist(i,k)] + mx[dpT][j][dist(k+1,j)] + pr->transitions[TNB]) 
				== mx[dpN][j][d]) {
            curr->emitl = -1; curr->emitr = -1; curr->transition = TNB;
            PushTracestack(stack, AttachTrace (curr, dpT, k+1, j, TRE));
            PushTracestack(stack, AttachTrace (curr, dpM, i, k, TRE));
	    k = j;	/* Short circuit */
          } /* End if */
        } /* End for (bifurcation points) */
      } 
    } else if (mtx == dpM) {
      if ((mx[dpM][j][d-1] + pr->singles[rna[i]] + pr->transitions[TMM]) == mx[dpM][j][d]) {
	curr->emitr = -1; curr->transition = TMM;
	PushTracestack(stack, AttachTrace (curr, dpM, i+1, j, TRE));
      } else {
	curr->emitr = -1; curr->emitl = -1; curr->transition = TMJ;
	PushTracestack(stack, AttachTrace (curr, dpJ, i, j, TRE));
      }
    } else if (mtx == dpJ) {
      if ((mx[dpJ][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TJJ]) == mx[dpJ][j][d]) {
	curr->emitl = -1; curr->transition = TJJ;
	PushTracestack(stack, AttachTrace (curr, dpJ, i, j-1, TRE));
      } else {
	curr->transition = TJP;
	PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TRE));
      }
    } else {
      printf("ERROR!! Nonterminal %d unkown in BRY traceback!\n", mtx);
    }
  }
  FreeTracestack(stack);
  return parsetree;
}

/***********************  Train **********************************/
/* Function: khs2traceBRY
 * Date:     RDD, Tue Apr 23 09:39:55 2002 [St. Louis]
 *
 * Purpose:  Convert KHS format into properly 
 * 	labeled traceback tree for BRY grammar
 *
 * Args:     
 *	dolist  Traceback tree to build from KHS	
 *	ct	KHS info represented as ct format
 */
int
khs2traceBRY(struct tracestack_s *dolist, int *ct, int grammar)
{
  struct trace_s      *cur;
  struct trace_s      *tr;
  struct trace_s      *prv, *nxt;
  char left; char right;
  int  i,j, mid, mid2;

  while ((cur = PopTracestack(dolist)) != NULL) {
    i = cur->emitl; j = cur->emitr;
    if (i > j) {
      cur->transition = TSE; cur->emitl = -1; cur->emitr = -1; 
    } else if (ct[i] == -1) {	/* i unpaired, single strand left */
      switch (cur->nonterminal) {
        case dpS: 
          cur->transition = TSS; cur->emitr = -1;
          PushTracestack(dolist, AttachTrace(cur, dpS, i+1, j, TRE));
          break;
        case dpP: 
	  if (ct[i+1] == j) {   /* This is a single nt bulge */
            if ((ct[i+2] == j-1) || (ct[i+2] == j-2) || (ct[i+3] == j-1)) {
              cur->transition = TPL; cur->emitl = i+1;
              PushTracestack(dolist, AttachTrace(cur, dpP, i+2, j-1, TRE));
	    }
	  } else {
            cur->transition = TPN; cur->emitl = -1; cur->emitr = -1;
            PushTracestack(dolist, AttachTrace(cur, dpN, i, j, TRE));
          }
          break;
        case dpM:
          cur->transition = TMM; cur->emitr = -1;
          PushTracestack(dolist, AttachTrace(cur, dpM, i+1, j, TRE));
          break;
        case dpN:
          mid = find_split(ct, i, j);
	  if ((mid >= 0 ) && (mid != j)) {	
	    mid2 = find_split(ct, mid+1, j);
	    if (mid2 >= 0) {	/* Multiple stems, must bifurcate */
	        cur->transition = TNB; cur->emitr = -1; cur->emitl = -1;
                PushTracestack(dolist, AttachTrace(cur, dpT, ct[mid2], j, TRE));
	        /* Left Nonterminal  must take care of first stem and 
		 * flanking single stranded */
                PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[mid2]-1, TRE));
	    } else {	/* Internal Loop */
              cur->transition = TNL; cur->emitl = i+1; cur->emitr = -1;
              PushTracestack(dolist, AttachTrace(cur, dpS, i+2, j, TRE));
            }
	  } else {	/* Left bulge or Hairpin */
            cur->transition = TNL; cur->emitl = i+1; cur->emitr = -1;
            PushTracestack(dolist, AttachTrace(cur, dpS, i+2, j, TRE));
          }
          break;
        default:
	  return 0;
          break;
      }
    } else if (ct[j] == -1) { /* j unpaired, single strand right */
      switch (cur->nonterminal) {
        case dpS: 
          cur->transition = TST; cur->emitl = -1; cur->emitr = -1; 
          PushTracestack(dolist, AttachTrace(cur, dpT, i, j, TRE));
          break;
        case dpT:
          cur->transition = TTT; cur->emitl = -1; 
          PushTracestack(dolist, AttachTrace(cur, dpT, i, j-1, TRE));
          break;
        case dpP:
	  if (ct[i] == j-1) {   /* This is a single nt bulge */
            if ((ct[i+1] == j-2) || (ct[i+1] == j-3) || (ct[i+2] == j-2)) {
              cur->transition = TPR; cur->emitr = j-1;
              PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-2, TRE));
            }
	  } else {
            cur->transition = TPN; cur->emitl = -1; cur->emitr = -1;
            PushTracestack(dolist, AttachTrace(cur, dpN, i, j, TRE));
          }
          break;
        case dpM:
	  cur->transition = TMJ; cur->emitl = -1; cur->emitr = -1;
          PushTracestack(dolist, AttachTrace(cur, dpJ, i, j, TRE));
          break;
        case dpJ:
          cur->transition = TJJ; cur->emitl = -1; 
          PushTracestack(dolist, AttachTrace(cur, dpJ, i, j-1, TRE));
          break;
        case dpN:
          mid = find_split(ct, i, j);
	  if ((mid >= 0 ) && (mid != j)) {	
	    mid2 = find_split(ct, mid+1, j);
	    if (mid2 >= 0) {	/* Multiple stems, must bifurcate */
	        cur->transition = TNB; cur->emitr = -1; cur->emitl = -1;
                PushTracestack(dolist, AttachTrace(cur, dpT, ct[mid2], j, TRE));
	        /* Left Nonterminal must take care of first stem and 
		 * flanking single stranded */
                PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[mid2]-1, TRE));
	    } else {	/* Internal Loop */
              cur->transition = TNR; cur->emitr = -1; cur->emitl = j-1;
              PushTracestack(dolist, AttachTrace(cur, dpS, i, j-2, TRE));
            }
	  } else {	/* Left bulge or Hairpin */
            cur->transition = TNR; cur->emitr = -1; cur->emitl = j-1;
            PushTracestack(dolist, AttachTrace(cur, dpS, i, j-2, TRE));
          }
          break;
        default:
	  return 0;
          break;
      }
    } else if (ct[i] == j) { /* i,j paired to each other */
      if (i+2 >= j) return 0;	/* Min hp is 1 nt */
      switch (cur->nonterminal) {
        case dpS: 
          cur->transition = TST; cur->emitl = -1; cur->emitr = -1; 
          PushTracestack(dolist, AttachTrace(cur, dpT, i, j, TRE));
          break;
	case dpM:
          cur->transition = TMJ; cur->emitl = -1; cur->emitr = -1; 
          PushTracestack(dolist, AttachTrace(cur, dpJ, i, j, TRE));
	  break;
        case dpT:
          cur->transition = TTP;
          PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
          break;
	case dpJ:
          cur->transition = TJP;
          PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
	  break;
        case dpP:
            cur->transition = TPP;
            PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
          break;
        default:
	  return 0;
          break;
      }
    } else {	/* i,j paired, but not to each other */
      switch (cur->nonterminal) {
        case dpS:
          cur->transition = TST; cur->emitl = -1; cur->emitr = -1; 
          PushTracestack(dolist, AttachTrace(cur, dpT, i, j, TRE));
          break;
        case dpT: 
         if (ct[j]+2 >= j) return 0;
          cur->transition = TTB; cur->emitl = ct[j];
          PushTracestack(dolist, AttachTrace(cur, dpP, ct[j]+1, j-1, TRE));
          PushTracestack(dolist, AttachTrace(cur, dpT, i, ct[j]-1, TRE));
          break;
        case dpN:
          cur->transition = TNB; cur->emitr = -1; cur->emitl = -1;
          /* Because the M state must take care of interstem region to its left, 
	   * we must now find the edge of that interstem sequence. */
	  mid = find_split(ct, ct[i]+1, ct[j]-1);	
	  if (mid < 0) {	/* No stems in between */
            PushTracestack(dolist, AttachTrace(cur, dpT, ct[j], j, TRE));
            PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[j]-1, TRE));
	  } else {		/* Cotains stems in between */
            PushTracestack(dolist, AttachTrace(cur, dpT, ct[mid], j, TRE));
            PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[mid]-1, TRE));
	  }
          break;
	case dpP:
	  cur->transition = TPN; cur->emitl = -1; cur->emitr = -1;
	  PushTracestack(dolist, AttachTrace(cur, dpN, i, j, TRE));
	  break;
        default:
	  return 0;
          break;
      }
    }
	/*
    printf("(%#12x) %2d  %4d  %4d  %3d  %#10x  %#10x \n", 
	     (int) cur, cur->nonterminal, cur->emitl, cur->emitr, 
             cur->transition, (int) cur->nxtl, (int) cur->nxtr);
	*/
  }
  return 1;
}

/* Function: analyzeTraceB
 * Date:     RDD, Tue May 14 17:08:15 CDT 2002 [St Louis]
 * 
 * Purpose: Parse a traceback tree for information.
 *	Either for counts (training).
 *	Or for determining tracebcak score.
 *
 * Args:     
 *      seq   - sequence corresponding to the trace
 *      len   - length of the sequence
 *      tr    - traceback to count
 *      cfg   - model, counts form, to add counts to
 *      count - if TRUE this is TraceCount; 
 *		if FALSE this is TraceScore
 *
 * Returns:  score of current traceback (in TraceScore mode)
 * 	Should return zero in TraceCount mode
 */
int
analyzeTraceB(char *seq, int len, struct trace_s *tr, INTMOD *cfg, int count)
{
  struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
  struct trace_s      *cur;     /* current node in the tree              */
  char *iseq;                   /* sequence with 0,1,2,3,4 in place of A,C,G,U,N */
  int score; 

 /* Digitize Sequence setup */
  SetAlphabet(hmmNUCLEIC);

  iseq = DigitizeSequence(seq, len);

  dolist = InitTracestack();
  PushTracestack(dolist, tr->nxtl);
  score = 0;

  while ((cur = PopTracestack(dolist)) != NULL) {
    if (cur->transition < NTRANS) {
      if (count) cfg->transitions[cur->transition] += 1;
      else score += cfg->transitions[cur->transition];
      if (cur->transition == TSE) {	/* do nothing on ENDS */
	continue;
      } else if (cur->transition == TTB) {
        if (count) cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
        else score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	PushTracestack(dolist, cur->nxtr);
	PushTracestack(dolist, cur->nxtl);
      } else if (cur->transition == TNB) {
	PushTracestack(dolist, cur->nxtr);
	PushTracestack(dolist, cur->nxtl);
      } else if ((cur->emitl == -1) && (cur->emitr == -1)) { /* No emission */
	PushTracestack(dolist, cur->nxtl);
      } else {
        if ((iseq[cur->emitl] > ALPHA) || (iseq[cur->emitr] > ALPHA)) {
		/* Do nothing, contains an ambiguous base! */
		/* Therfore must back out of counting transition?
 		 */
	  if (count) cfg->transitions[cur->transition] -= 1;

	/* Emit to right */
	} else if (cur->emitl == -1) {
	  if (count) cfg->singles[iseq[cur->emitr]] += 1;
	  else score += cfg->singles[iseq[cur->emitr]];
	  if (cur->transition == TNR) {
	    if (iseq[(cur->emitr+1)] <= 4) {
              if (count) cfg->singles[iseq[(cur->emitr +1)]] += 1;
              else score += cfg->singles[iseq[(cur->emitr +1)]];
	    }
	  }

	/* Emit to left */
	} else if (cur->emitr == -1) {
	  if (count) cfg->singles[iseq[cur->emitl]] += 1;
	  else score += cfg->singles[iseq[cur->emitl]];
	  if (cur->transition == TNL) {
	    if (iseq[cur->emitl-1] <= 4) {
              if (count) cfg->singles[iseq[cur->emitl -1]] += 1;
              else score += cfg->singles[iseq[cur->emitl -1]];
            }
	  }

	/* Emit aligned pair -- stacking model */
        } else if (cur->nonterminal == dpP) {
	  if (cur->transition == TPL) {
            if ((iseq[cur->emitl -2] > ALPHA) || (iseq[cur->emitr +1] > ALPHA)) {
	      if (count) cfg->transitions[cur->transition] -= 1;
	    } else {
              if (count) {
	        cfg->stack[idx(iseq[cur->emitl - 2],iseq[cur->emitr + 1])]
		      	[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
	        cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
              } else {
	        score += cfg->stack[idx(iseq[cur->emitl - 2],iseq[cur->emitr + 1])]
		      	[iseq[cur->emitl]][iseq[cur->emitr]];
              }
	      if (iseq[cur->emitl-1] <= 4) {
                if (count) cfg->singles[iseq[cur->emitl -1]] += 1;
                else score += cfg->singles[iseq[cur->emitl -1]];
	      }
	    }
	    
	  } else if (cur->transition == TPR) {
            if ((iseq[cur->emitl -1] > ALPHA) || (iseq[cur->emitr +2] > ALPHA)) {
	      if (count) cfg->transitions[cur->transition] -= 1;
	    } else {
              if (count) {
	        cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 2])]
		      	[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
	        cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
              } else {
	        score += cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 2])]
		      	[iseq[cur->emitl]][iseq[cur->emitr]];
              }
	      if (iseq[cur->emitr +1] <= 4) {
                if (count) cfg->singles[iseq[cur->emitr +1]] += 1;
                else score += cfg->singles[iseq[cur->emitr +1]];
	      }
	    }
	  } else {	/* TPP */
            if ((iseq[cur->emitl -1] > ALPHA) || (iseq[cur->emitr +1] > ALPHA)) {
		/* Do nothing, contains an ambiguous base! 
		 * Therfore must back out of counting transition!
 		 */
	      if (count) cfg->transitions[cur->transition] -= 1;
            } else {
              if (count) {
	        cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
		      	[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
	        /* By also adding to pairs, it is like you are averaging the 
                 * pair emissions over all pairs (including stacks) */
	        cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
              } else {
	        score += cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
		      	[iseq[cur->emitl]][iseq[cur->emitr]];
              }
            }
	  }

	/* Emit aligned pair -- no stacking */
	} else {
	  if (count) cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
	  else score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	}
	PushTracestack(dolist, cur->nxtl);
      }
    } else {
      PushTracestack(dolist, cur->nxtl);
    }
  }
  free(iseq);
  FreeTracestack(dolist);
  return score;
}
/* Function: dTraceScoreB 
 * Date:     Mon Oct 27 16:50:08 CST 2003 [St Louis]
 * 
 * Purpose: Parse a traceback tree for determining traceback score.
 * 	Needed for ambiguity testing
 *
 * Args:     
 *      seq   - sequence corresponding to the trace
 *      len   - length of the sequence
 *      tr    - traceback to count
 *      cfg   - model (float log form)
 *      ret_val - score of traceback as double
 *
 * Returns:  void
 */
void
dTraceScoreB(char *seq, int len, struct trace_s *tr, PROBMOD *cfg, double *ret_val)
{
  struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
  struct trace_s      *cur;     /* current node in the tree              */
  char *iseq;        /* sequence with 0,1,2,3,4 in place of A,C,G,U,N */
  double score; 

 /* Digitize Sequence setup */
  SetAlphabet(hmmNUCLEIC);

  iseq = DigitizeSequence(seq, len);

  dolist = InitTracestack();
  PushTracestack(dolist, tr->nxtl);
  score = 0.;

  while ((cur = PopTracestack(dolist)) != NULL) {
    if (cur->transition < NTRANS) {
      score += cfg->transitions[cur->transition];
      if (cur->transition == TSE) {	/* do nothing on ENDS */
	continue;
      } else if (cur->transition == TTB) {
        score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	PushTracestack(dolist, cur->nxtr);
	PushTracestack(dolist, cur->nxtl);
      } else if (cur->transition == TNB) {
	PushTracestack(dolist, cur->nxtr);
	PushTracestack(dolist, cur->nxtl);
      } else if ((cur->emitl == -1) && (cur->emitr == -1)) { /* No emission */
	PushTracestack(dolist, cur->nxtl);
      } else {
        if ((iseq[cur->emitl] > ALPHA) || (iseq[cur->emitr] > ALPHA)) {
		/* Do nothing, contains an ambiguous base! */
		/* Therfore must back out of counting transition?
 		 */
	/* Emit to right */
	} else if (cur->emitl == -1) {
	  score += cfg->singles[iseq[cur->emitr]];
	  if (cur->transition == TNR) {
	    if (iseq[(cur->emitr+1)] <= 4) {
              score += cfg->singles[iseq[(cur->emitr +1)]];
	    }
	  }

	/* Emit to left */
	} else if (cur->emitr == -1) {
	  score += cfg->singles[iseq[cur->emitl]];
	  if (cur->transition == TNL) {
	    if (iseq[cur->emitl-1] <= 4) {
              score += cfg->singles[iseq[cur->emitl -1]];
            }
	  }

	/* Emit aligned pair -- stacking model */
        } else if (cur->nonterminal == dpP) {
	  if (cur->transition == TPL) {
	     if ((iseq[cur->emitl -2] < ALPHA) && (iseq[cur->emitr +1] < ALPHA)) {
		score += cfg->stack[idx(iseq[cur->emitl - 2],iseq[cur->emitr + 1])]
		   [iseq[cur->emitl]][iseq[cur->emitr]];
		if (iseq[cur->emitl-1] <= 4) {
		   score += cfg->singles[iseq[cur->emitl -1]];
		}
	     }
	  } else if (cur->transition == TPR) {
	     if ((iseq[cur->emitl -1] < ALPHA) && (iseq[cur->emitr +2] < ALPHA)) {
		score += cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 2])]
		   [iseq[cur->emitl]][iseq[cur->emitr]];
		if (iseq[cur->emitr +1] <= 4) {
		   score += cfg->singles[iseq[cur->emitr +1]];
		}
	     }
	  } else {	/* TPP */
	     if ((iseq[cur->emitl -1] < ALPHA) && (iseq[cur->emitr +1] < ALPHA)) {
		score += cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
		   [iseq[cur->emitl]][iseq[cur->emitr]];
	     }
	  }

	/* Emit aligned pair -- no stacking */
	} else {
	  score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	}
	PushTracestack(dolist, cur->nxtl);
      }
    } else {
      PushTracestack(dolist, cur->nxtl);
    }
    /* printf("Score i %d j %d %f\n", cur->emitl, cur->emitr, score); */
  }
  free(iseq);
  FreeTracestack(dolist);
  /* printf("Score %f\n", score); */
  *ret_val = score;
}

/* Function: cinsInitBRY
 * Date:     RDD, Sun Oct  5 17:02:42 CDT 2003 [St Louis]
 *
 * Purpose:  Initialize cInside fill matrix for BRY grammars 
 *
 * Args:     
 *	mx	fill matrix (log odds form)
 *	model	parameters (log odds form)
 *	rna	sequence
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cinsInitBRY(double ***mx, PROBMOD *model, char *rna, int len)
{
   int j, d;

   for (d = 0; d <= len; d++) { 
      for (j = d; j < len; j++) {
	 mx[dpS][j][d] = model->transitions[TSE];
	 mx[dpT][j][d] = -BIGFLOAT;
	 mx[dpP][j][d] = -BIGFLOAT;
	 mx[dpN][j][d] = -BIGFLOAT;
	 mx[dpM][j][d] = -BIGFLOAT;
	 mx[dpJ][j][d] = -BIGFLOAT;
      }
      if (d > 0) {
	 mx[dpS][d-1][d] = model->transitions[TSE];
	 mx[dpT][d-1][d] = -BIGFLOAT;
	 mx[dpP][d-1][d] = -BIGFLOAT;
	 mx[dpN][d-1][d] = -BIGFLOAT;
	 mx[dpM][d-1][d] = -BIGFLOAT;
	 mx[dpJ][d-1][d] = -BIGFLOAT;
      }
   }
}

/* Function: cinsFillBRY
 * Date:     RDD, Sun Oct  5 17:03:43 CDT 2003 [St Louis]
 *
 * Purpose:  Fills cInside matrix for BRY 
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate (log Probs)
 *	sc	parameters (log form)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Notes: 
 *      Must fill T before S as one rule in S allows S -> T
 *      and therefore the current cell of T will need to
 *      already known.
 *
 * Returns:  void 
 */
void
cinsFillBRY(double ***mx, PROBMOD *pr, char *rna, int len, int *ss)
{
  int d, i, j, k;       /* Loop indicies */
  double cursc;
  double stackvalue;	

  /* Recursion */
  for (d = 1; d <= len; d++) {
     for (j = d-1; j < len; j++) {
	i = j - d + 1; 
	
	cursc = -BIGFLOAT;
	/* T -> Ta | aPa' | T aPa' */
	if (j > 0) {
	   if (ss[j] == -1) {
	      cursc = mx[dpT][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TTT];
	   }

	   /* T -> aPa' */
	   if (ss[i] == j)  {
	      if (d > 1) {
		 cursc = DLogsum(mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
		       + pr->transitions[TTP], cursc);
	      }
	   }
	}
	/* T -> T aPa' */
	for (k = i+1; k < j-1; k++) {
	   if (ss[k+1] == j) 
	      cursc = DLogsum(mx[dpT][k][dist(i,k)] + mx[dpP][j-1][dist(k+2, j-1)]
		 + pr->pairs[rna[k+1]][rna[j]] + pr->transitions[TTB], cursc);
	}
	/* T -> Ta | aPa' | T aPa' */
	mx[dpT][j][d] = cursc;

	/* S -> aS | T | end */
	cursc = mx[dpT][j][d] + pr->transitions[TST];
	if (ss[i] == -1) 
	   cursc = DLogsum(mx[dpS][j][d-1] + pr->singles[rna[i]] 
		 + pr->transitions[TSS], cursc);
	mx[dpS][j][d] = cursc;
	printf("dpS %d %d %f\n", i, j, cursc);

	/* J -> Ja | aPa' */
	cursc = -BIGFLOAT;
	if (j > 0) {
	   if (ss[j] == -1) {
	      cursc = mx[dpJ][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TJJ];
	   }
	   if (d-1 > HLEN) {
	      if (ss[i] == j) 
		 cursc = DLogsum(mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]]
		       + pr->transitions[TJP], cursc); 
	   }
	}
	mx[dpJ][j][d] = cursc; 

	/* M -> aM | J */
	cursc = mx[dpJ][j][d] + pr->transitions[TMJ];
	if (ss[i] == -1) {
	   cursc = DLogsum(mx[dpM][j][d-1] + pr->singles[rna[i]] 
		 + pr->transitions[TMM], cursc);
	}
	mx[dpM][j][d] = cursc; 

	/* N -> aaS | Taa | MT */
	cursc = -BIGFLOAT;
	if (d > 1) {
	   if ((ss[i] == -1) && (ss[i+1] == -1)) {
	      cursc = mx[dpS][j][d-2] + pr->singles[rna[i]] + pr->singles[rna[i+1]] 
		 + pr->transitions[TNL];
	   }
	   if (j > 1) {
	      /* N -> Taa */
	      if ((ss[j] == -1) && (ss[j-1] == -1)) {
		 cursc = DLogsum(mx[dpT][j-2][d-2] + pr->singles[rna[j]] 
		       + pr->singles[rna[j-1]] + pr->transitions[TNR], cursc);
	      }
	   }
	}
	/* N -> MT */ 
	for (k = i+1; k < j-1; k++) {
	   cursc = DLogsum(mx[dpM][k][dist(i,k)] + mx[dpT][j][dist(k+1,j)] 
		 + pr->transitions[TNB], cursc);
	}
	/* N -> aaS | Taa | MT */
	mx[dpN][j][d] = cursc;

	/* P -> aPa | x aPa' | aPa' x | N */
	cursc = mx[dpN][j][d] + pr->transitions[TPN];
	/* Stacking! Can't be in P state at edges!  */
	if ((i > 0) && (j < len-1)) {
	   stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]];
	   /* P -> aPa' */
	   if (ss[i] == j) {
	      if  ((j > 0) && (d > 1)) {
		 cursc = DLogsum(mx[dpP][j-1][d-2] + stackvalue 
		       + pr->transitions[TPP], cursc);
	      }
	   }

	   if (j > 0) {
	      if (d-2 > HLEN) { 
		 /* P -> x aPa' */
		 stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i+1]][rna[j]];
		 if ((ss[i] == -1) && (ss[i+1] == j)) {
		    cursc = DLogsum(mx[dpP][j-1][dist(i+2, j-1)] + stackvalue 
			  + pr->singles[rna[i]] + pr->transitions[TPL], cursc);
		 }
		 if (j > 1) {
		    /* P -> aPa' x */
		    stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j-1]];
		    if ((ss[j] == -1) && (ss[i] == j-1)) {
		       cursc = DLogsum(mx[dpP][j-2][dist(i+1, j-2)] + stackvalue 
			     + pr->singles[rna[j]] + pr->transitions[TPR], cursc);
		    }
		 }
	      }
	   }
	}
	/* P -> aPa | x aPa' | aPa' x | N */
	mx[dpP][j][d] = cursc;
     }
  }
}

