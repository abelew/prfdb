/* weedamb_main.c 
 *
 * This could be a perl script -- but with this machinery here
 * it's just as easy (if not easier) to do this in C code.
 *
 * Take in a dataset and split it into unambiguous and ambiguous
 * subsets, each ordered by length (shortest first).
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"
#include"stats.h"

static char optsline[]  = "\
where options are:\n\
-h            : print short help and usage info \n\
-s <filename> : save ambiguous sequences to this file \n\
";
static char usage[]  = "Usage: weedamb <seqfile in>\n"; 

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/ 
  int   optid; 
  OPTS settings;
  FILE *ambout;

  /* ReadSeq variables */
  SQFILE *sqfp; SQINFO sqinfo;
  int sformat;
  char *rna; 
  int *ct;

  /* Digitize Setup */
  SetAlphabet(hmmNUCLEIC);

  if (!(ProcessOpts(&settings, &optid, argc, argv, usage, "", optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  } 

   if (argc - optid != 1)
    Die("Incorrect number of command line arguments.\n%s\n%s\n", usage, optsline);

  if (settings.savefile != NULL) {
     if ((ambout = fopen(settings.savefile, "w")) == NULL) 
	Die("Failed to open output file %s!\n", settings.savefile);
  }

  /* Read input file into RNA array and filter for non-RNA residues */
  if ((sqfp = SeqfileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL) 
    Die("Failed to open sequence file %s\n%s\n", argv[optid], usage);

  while (ReadSeq(sqfp, sformat, &rna, &sqinfo)) {
    ToRNA(rna);
    if (settings.debugg) 
       fprintf(stdout, "Sequence: %s %d ", sqinfo.name, sqinfo.len);


    if (!(ContainsAmbiguous(rna, sqinfo.len))) {	
       PrintStockholm(stdout, rna, &sqinfo, sqinfo.ss);
    } else {	/* Contains ambiguous bases */
       if (settings.savefile != NULL) {
         PrintStockholm(ambout, rna, &sqinfo, sqinfo.ss);
       }
    }

    FreeSequence(rna, &sqinfo);
  }
  SeqfileClose(sqfp);
}


