/* gr_ivo.c
 * Sat Aug  9 13:18:20 CDT 2003
 *
 * Implementations of the grammar specific functions for IVO 
 *
 * Sat Aug  9 13:18:20 CDT 2003
 * Ivo Grammar:  S -> aS | aSa'S | end
 *
 * These implementations assume a digitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"

/*************************  CYK ********************************/
/* Function: cykInitIVO
 * Date:     Sat Aug  9 13:19:18 CDT 2003 [Delta Flt #153]
 *
 * Purpose:  Initialize CYK fill matrix for IVO grammar
 * Assumption: Fill matrix already allocated 
 *
 * Args:     
 *	mx	fill matrix (integer log odds form)
 *	model 	parameters (integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cykInitIVO(int ***mx, INTMOD *model, char *rna, int len)
{
  int j, d;

  for (d = 0; d <= len; d++) {
     for (j = (d > 0? d-1:  d); j < len; j++) {
	mx[dpS][j][d] = model->transitions[TSE];	/* S -> end */
     } /* end for j */
  } /* end for i */
}

/* Function: cykFillIVO
 * Date:     Sat Aug  9 13:20:09 CDT 2003 [Delta Flt #153]
 *
 * Purpose:  Fills CYK matrix for IVO grammar
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	pr	parameters (integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
cykFillIVO (int ***mx, INTMOD *pr, char *rna, int len)
{
  int d, i, j, k;       /* Loop indicies */
  int max;              /* Maximum value seen so far */
  int cursc;

  /* Recursion */
  for (d = 1; d <= len; d++) {
    for (j = d-1; j < len; j++) {
       i = j - d + 1; max = -BIGINT;

      /* S -> aS */
      cursc = mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL];
      if (cursc > max) max = cursc; 

      /* S -> aSa'S */
      for (k = i+HLEN+1; k <= j; k++) {
	 if (lplen(i,k) >= HLEN) {
	    cursc = mx[dpS][k-1][dist(i+1,k-1)] + mx[dpS][j][dist(k+1,j)] 
	       + pr->pairs[rna[i]][rna[k]] + pr->transitions[TSB];
	 }
        if (cursc > max) max = cursc;
      }

      /* S -> aS | aSa'S | end */
      mx[dpS][j][d] = max;
    } /* End for loop */
  } /* End foreach n */
}

/* Function: cykTraceIVO
 * Date:     Sat Aug  9 13:23:01 CDT 2003 [Delta Flt #153]
 *
 * Purpose:  Build traceback tree for scoring Ivo's Grammar
 * Assumption: Fill matrix already allocated, initialized, and filled
 *
 * Args:
 *	mx	matrix in which to calculate cyk
 *	pr	parameters in integer form
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns: traceback tree
 */
struct trace_s *
cykTraceIVO (int ***mx, INTMOD *pr, char *rna, int len)
{
  int d, i, j, k, mtx;   /* Indices */
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (len -1), TSE));

  /* Repeat until stack is empty */
  while (curr = PopTracestack(stack)) {
    /* Set i and j from items in stack */
    i = curr->emitl; j = curr->emitr; mtx = curr->nonterminal; d = j - i + 1;

    /* S -> aS | aSa'S | end */
    if (i > j) { 		/* S -> end */
      curr->emitl = -1; curr->emitr = -1;
      curr->transition = TSE; curr->nonterminal = dpE; 
      continue;
    } else {  /* (mtx == dpS) */
       if (i == j) {
	  curr->emitr = -1; curr->transition = TSL; 
	  PushTracestack(stack, AttachTrace (curr, dpS, i+1, j, TSE));
       } else if ((mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL]) == mx[dpS][j][d]) {
	  curr->emitr = -1; curr->transition = TSL; 
	  PushTracestack(stack, AttachTrace (curr, dpS, i+1, j, TSE));
       } else {
	  for (k = i+HLEN+1; k <= j; k++) {
	     if (lplen(i,k) >= HLEN) {
		if ((mx[dpS][k-1][dist(i+1,k-1)] + mx[dpS][j][dist(k+1,j)] 
			 + pr->pairs[rna[i]][rna[k]] 
			 + pr->transitions[TSB]) == mx[dpS][j][d]) {
		   curr->emitr = k; curr->transition = TSB;
		   PushTracestack(stack, AttachTrace (curr, dpS, k+1, j, TSE));
		   PushTracestack(stack, AttachTrace (curr, dpS, i+1, k-1, TSE));
		   k = j;	/* Short circuit */
		} /* End if */
	     }
	  } /* End for (bifurcation points) */
       } /* End if i <= j */
    } /* End if dpS, dpL or dpR */
  } /* end while stack not empty*/
  FreeTracestack(stack);
  return parsetree;
}

/*************************  TRAIN ******************************/
/* Function: khs2traceIVO
 * Date:     Sat Aug  9 13:25:55 CDT 2003 [Delta Flt #153]
 *
 * Purpose: Convert KHS to traceback tree properly 
 * 	labeled for IVO grammar.
 *
 * Args:     
 *	dolist  Traceback tree to build from KHS	
 *	ct	KHS info represented as ct format
 */
int
khs2traceIVO(struct tracestack_s *dolist, int *ct)
{
  struct trace_s      *cur;
  int  i,j, mid;

  while ((cur = PopTracestack(dolist)) != NULL) {
    i = cur->emitl; j = cur->emitr; 

    if (i > j) {
      cur->emitl = -1; cur->emitr = -1; 
      cur->transition = TSE; cur->nonterminal = dpE;
    } else if (ct[i] == -1) {   /* i unpaired; single strand left */
      cur->transition = TSL; cur->emitr = -1;
      PushTracestack(dolist, AttachTrace(cur, dpS, i+1, j, TSE));
    } else {			/* i,j pair; not to each other */
      cur->transition = TSB; 
      cur->emitr = ct[i];
      PushTracestack(dolist, AttachTrace(cur, dpS, ct[i]+1, j, TSE));
      PushTracestack(dolist, AttachTrace(cur, dpS, i+1, ct[i]-1, TSE));
    }
  }
  return 1;
}

/* Function: analyzeTraceIVO
 * Date:     Sat Aug  9 13:28:47 CDT 2003 [Delta Flt #153]
 *
 * Purpose: Parse a traceback tree for information.
 *	Either for counts (training).
 *	Or for determining traceback score.
 *
 * Args:     
 *      seq   - sequence corresponding to the trace
 *      len   - length of the sequence
 *      tr    - traceback to count
 *      cfg   - model, counts form, to add counts to
 *      count - if TRUE this is TraceCount; 
 *		if FALSE this is TraceScore
 *
 * Returns:  score of current traceback (in TraceScore mode)
 * 	Should return zero in TraceCount mode
 */
int
analyzeTraceIVO(char *seq, int len, struct trace_s *tr, INTMOD *cfg, int count) 
{
  struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
  struct trace_s      *cur;     /* current node in the tree              */
  char *iseq;                   
  int   cst, nst, j;
  char left; char right;
  int score;

 /* Digitize Sequence setup */
  SetAlphabet(hmmNUCLEIC);

  iseq = DigitizeSequence(seq, len);

  dolist = InitTracestack();
  PushTracestack(dolist, tr->nxtl);

  score = 0; 

  while ((cur = PopTracestack(dolist)) != NULL) {
    if (cur->transition < NTRANS) {

       if (count) cfg->transitions[cur->transition] += 1;
       else score += cfg->transitions[cur->transition];

       if (cur->transition == TSE) {	/* do nothing on ENDS */
	  continue;
	  /* Emit to left */
       } else if (cur->emitr == -1) {
	  if (iseq[cur->emitl] > ALPHA) {
	     /* Do nothing, contains an ambiguous base! 
	      * Therfore must back out of counting transition! */
	     if (count) cfg->transitions[cur->transition] -= 1;
	     PushTracestack(dolist, cur->nxtl);
	  } else {
	     if (count) cfg->singles[iseq[cur->emitl]] += 1;
	     else score += cfg->singles[iseq[cur->emitl]];
	     PushTracestack(dolist, cur->nxtl);
	  }

       } else if (cur->transition == TSB) {
	  if (count) cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
	  else score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	  PushTracestack(dolist, cur->nxtr);
	  PushTracestack(dolist, cur->nxtl);
       }
    } else {
       PushTracestack(dolist, cur->nxtl);
    }
  }
  free(iseq);
  FreeTracestack(dolist);
  return score;
}
/* Function: dTraceScoreIVO 
 * Date:     Mon Oct 27 16:53:20 CST 2003 [St Louis]
 *
 * Purpose: Parse a traceback tree for 
 *	determining traceback score -- needed for
 *	ambiguity testing
 *
 * Args:     
 *      seq   - sequence corresponding to the trace
 *      len   - length of the sequence
 *      tr    - traceback to count
 *      cfg   - model (float log form)
 *      ret_val - score of traceback
 *
 * Returns:  void
 */
void
dTraceScoreIVO(char *seq, int len, struct trace_s *tr, PROBMOD *cfg, double *ret_val)
{
  struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
  struct trace_s      *cur;     /* current node in the tree              */
  char *iseq;                   
  int   cst, nst, j;
  char left; char right;
  double score;

 /* Digitize Sequence setup */
  SetAlphabet(hmmNUCLEIC);

  iseq = DigitizeSequence(seq, len);

  dolist = InitTracestack();
  PushTracestack(dolist, tr->nxtl);

  score = 0.; 

  while ((cur = PopTracestack(dolist)) != NULL) {
    if (cur->transition < NTRANS) {

       score += cfg->transitions[cur->transition];

       if (cur->transition == TSE) {	/* do nothing on ENDS */
	  continue;
	  /* Emit to left */
       } else if (cur->emitr == -1) {
	  if (iseq[cur->emitl] > ALPHA) {
	     /* Do nothing, contains an ambiguous base! */
	     PushTracestack(dolist, cur->nxtl);
	  } else {
	     score += cfg->singles[iseq[cur->emitl]];
	     PushTracestack(dolist, cur->nxtl);
	  }

       } else if (cur->transition == TSB) {
	  score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	  PushTracestack(dolist, cur->nxtr);
	  PushTracestack(dolist, cur->nxtl);
       }
    } else {
       PushTracestack(dolist, cur->nxtl);
    }
  }
  free(iseq);
  FreeTracestack(dolist);
  *ret_val = score;
}

/******************* conditional Inside ******************************/
/* Function: cinsInitIVO
 * Date:     Fri Aug 22 13:11:39 CDT 2003 [St Louis]
 *
 * Purpose:  Initialize Inside fill matrix for IVO grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:     
 *	mx	where to store inside (matrix to fill)
 *	model	integer log form of parameters
 *	rna	Sequence to be analyzed
 * 	len	sequence length
 * 	ss	secondary structure to condition on.
 *
 * Notes:  To initialize the "lower" half of the matrix:
 *   \alpha_{nonterminal}(i+1, i) = 1 for nontermianls with \epsilon
 *   				  = 0 otherwise
 * To initalize the diagonal (i == j) we calculate the inside
 *  	variable (\alpha) for each nontermianl type assuming
 *  	the values above for all \alpha_{nontemrainl}(i,j) where
 *  	i > j.
 *
 * Returns:  -- void -- 
 */
void
cinsInitIVO(double ***mx, PROBMOD *model, char *rna, int len)
{
  int d,j;

  for (d = 0; d <= len; d++) {
     for (j = d; j < len; j++) {
	mx[dpS][j][d] = model->transitions[TSE];
     } /* end for j */
     if (d > 0) {
	mx[dpS][d-1][d] = model->transitions[TSE];
     }
  } 
}

/* Function: cinsFillIVO
 * Date:     Fri Aug 22 13:12:29 CDT 2003 [St Louis]
 *
 * Purpose:  Fills inside matrix for IVO grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (log Probs)
 *	pr	parameters (float form)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
cinsFillIVO(double ***mx, PROBMOD *pr, char *rna, int len, int *ss)
{
  int d, i, j, k;       /* Loop indicies */
  double cursc;

  /* Recursion */
  for (d = 1; d <= len; d++) {
     for (j = d-1; j < len; j++) {
	i = j - d + 1; 

	/* S -> aS | aSa'S | end */
	if (ss[i] == -1) {
	   mx[dpS][j][d] = mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL];
	} else {
	   /* S -> aSa'S */
	   cursc = -BIGFLOAT;
	   for (k = i+1; k <= j; k++) {
	      if (ss[i] == k) {
		 if (mx[dpS][k-1][dist(i+1,k-1)] > -BIGFLOAT) {
		    cursc = mx[dpS][k-1][dist(i+1,k-1)] + mx[dpS][j][dist(k+1,j)] 
		       + pr->pairs[rna[i]][rna[k]] + pr->transitions[TSB];
		 }
	      }
	   }
	   mx[dpS][j][d] = cursc;
	}

     } /* End for loop */
  } /* End foreach n */
}
