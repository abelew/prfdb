/* gr_uyn.c
 * RDD, Fri Oct 12 13:56:34 2001
 *
 * Implementations of the grammar specific functions for UYN
 *
 * Tue Nov 13 10:58:25 CST 2001 
 * Unambiguous Yarn :  
 *      	S -> aPa' | aL | Rb | LS	(UYN)
 *            	P -> aPa' | aNb		(stacking energies)
 *             	N -> aL | Rb | LS
 *              L -> aPa' | aL
 *              R -> Rb | end
 *
 * These implementations assume a digitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"

/*************************  CYK ********************************/
/* Function: cykInitUYN
 * Date:     RDD, Fri Oct 12 13:56:34 2001 [St. Louis]
 *
 * Purpose:  Initialize CYK fill matrix for UYN grammar
 *
 * Args:     
 *	mx	fill matrix (integer log odds form)
 *	model	parameters
 *	rna	sequence
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cykInitUYN(int ***mx, INTMOD *model, char *rna, int len)
{
   int j, d;

   for (d = 0; d <= len; d++) { 
      for (j = d; j < len; j++) {
	 mx[dpS][j][d] = -BIGINT;
	 mx[dpP][j][d] = -BIGINT;
	 mx[dpN][j][d] = -BIGINT;
	 mx[dpL][j][d] = -BIGINT;
	 mx[dpR][j][d] = model->transitions[TRE];
      }
      if (d > 0) {
	 mx[dpS][d-1][d] = -BIGINT;
	 mx[dpP][d-1][d] = -BIGINT;
	 mx[dpN][d-1][d] = -BIGINT;
	 mx[dpL][d-1][d] = -BIGINT;
	 mx[dpR][d-1][d] = model->transitions[TRE];
      }
   }
}

/* Function: cykFillUYN
 * Date:     Fri Oct 12 09:10:06 CDT 2001
 *
 * Purpose:  Fills CYK matrix for and UYN grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	pr	parameters 
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
cykFillUYN(int ***mx, INTMOD *pr, char *rna, int len)
{
   int d, i, j, k;       /* Loop indicies */
   int max;              /* Maximum value seen so far */
   int cursc, cursc2;    /* Current score */
   int stackvalue;	

   /* Recursion */
   for (d = 1; d <= len; d++) {
      for (j = d-1; j < len; j++) {
	 i = j - d + 1;  max = -BIGINT;

	 /* S -> aL */
	 cursc = mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL];
	 if (cursc > max) max = cursc; 

	 if (j > 0) {
	    /* S -> Rb */
	    cursc = mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR];
	    if (cursc > max) max = cursc;

	    /* S -> aPb */
	    if (d > 1) {
	       cursc = mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
		  + pr->transitions[TSP];
	       if ((cursc > max) && (lplen(i,j) >= HLEN)) max = cursc;
	    }
	 } else if (d == 1) {	/* Special case of 1 nt */
	    /* S -> Rb */
	    cursc = pr->transitions[TRE] + pr->singles[rna[j]] + pr->transitions[TSR];
	    if (cursc > max) max = cursc;
	 }

	 /* S -> LS */
	 for (k = i; k < j; k++) {
	    cursc = mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] + pr->transitions[TSB];
	    if (cursc > max) max = cursc;
	 }

	 /* S -> aPb | aR | Lb | LS */
	 mx[dpS][j][d] = max;

	 /* L -> aPb | aL */
	 if ((j > 0) && (d > 1) && (lplen(i,j) >= HLEN)) {
	    cursc = mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
	       + pr->transitions[TLP];
	 } else {
	    cursc = -BIGINT;
	 }
	 cursc2 = mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TLL];
	 if (cursc > cursc2) {
	    mx[dpL][j][d] = cursc;
	 } else {
	    mx[dpL][j][d] = cursc2;
	 }

	 /* R -> Rb | end */
	 if ((j > 0) && (d > 1)) {
	    mx[dpR][j][d] = mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TRR];
	 } else {	/* d = 1 */
	    mx[dpR][j][d] = pr->transitions[TRE] + pr->singles[rna[j]] + pr->transitions[TRR];
	 }

	 max = -BIGINT;
	 /* N -> aL */
	 cursc = mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TNL];
	 if (cursc > max) max = cursc; 

	 if (j > 0) {
	    /* N -> Rb */
	    cursc = mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TNR];
	    if (cursc > max) max = cursc;
	 }

	 /* N -> LS */
	 for (k = i; k < j; k++) {
	    cursc = mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] + pr->transitions[TNB];
	    if (cursc > max) { max = cursc; }
	 } /* End for loop N -> LS */

	 mx[dpN][j][d] = max;

	 /* Can't be in P state at edges!  */
	 if ((i == 0) || (j == len-1)) {
	    stackvalue = -BIGINT;
	 } else {
	    stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]];
	 }

	 /* P -> aPb | aNb  (stacking!) */
	 if ((j > 0) && (d > 1) && (lplen(i,j) >= HLEN)) {
	    /* P -> aPb | aNb  */
	    cursc = mx[dpP][j-1][d-2] + stackvalue + pr->transitions[TPP];
	    cursc2 = mx[dpN][j-1][d-2] + stackvalue + pr->transitions[TPN];

	    if (cursc > cursc2) { mx[dpP][j][d] = cursc; } 
	    else { mx[dpP][j][d] = cursc2; }

	 } else {
	    mx[dpP][j][d] = -BIGINT;
	 }
      } /* End for loop */
  } /* End foreach n */
}

/* Function: cykTraceUYN 
 * Date:     RDD, Mon Aug 27 13:44:16 2001 [St. Louis]
 *
 * Purpose:  Build traceback tree for scoring Nussinov 
 *
 * Args:
 *	mx	matrix in which to calculate cyk
 *	pr	parameters in integer form
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns: traceback tree
 */
struct trace_s *
cykTraceUYN (int ***mx, INTMOD *pr, char *rna, int len)
{
  int d, i, j, k, mtx;   /* Indices */
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (len -1), TRE));

  /* Repeat until stack is empty */
  while (curr = PopTracestack(stack)) {
    /* Set i and j from items in stack */
    i = curr->emitl; j = curr->emitr; mtx = curr->nonterminal;
    d = j - i + 1;

    /* S -> aPb | aL | Rb | LS | end */
    if (i > j) { 		/* S(R) -> end */
      curr->emitl = -1; curr->emitr = -1;
      curr->transition = TSE; curr->nonterminal = dpE; 
      continue;
    } else if (mtx == dpS) {
		/* Single nt length seq's i == j */
      if ((mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR]) == mx[dpS][j][d]) {
        curr->emitl = -1; curr->transition = TSR; 
        PushTracestack(stack, AttachTrace (curr, dpR, i, j-1, TRE));
      } else if ((mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL]) == mx[dpS][j][d]) {
        curr->emitr = -1; curr->transition = TSL; 
        PushTracestack(stack, AttachTrace (curr, dpL, i+1, j, TRE));
      } else if ((lplen(i,j) >= HLEN) && ((mx[dpP][j-1][d-2] 
		  + pr->pairs[rna[i]][rna[j]] + pr->transitions[TSS]) 
	       == mx[dpS][j][d])) {
        curr->transition = TSP;
        PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TRE));
      } else {
          for (k = i; k < j; k++) {
            if ((mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] + pr->transitions[TSB]) == mx[dpS][j][d]) {
	      curr->emitl = -1; curr->emitr = -1; curr->transition = TSB;
              PushTracestack(stack, AttachTrace (curr, dpS, k+1, j, TRE));
              PushTracestack(stack, AttachTrace (curr, dpL, i, k, TRE));
	      k = j;	/* Short circuit */
            } /* End if */
          } /* End for (bifurcation points) */
      } /* end if (S-> aSb | aL | Rb | LS) */
    } else if (mtx == dpL) {
      if ((mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TLL]) == mx[dpL][j][d]) {
        curr->emitr = -1; curr->transition = TLL;
        PushTracestack(stack, AttachTrace (curr, dpL, i+1, j, TRE));
      } else {
        curr->transition = TLP;
        PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TRE));
      }
    } else if (mtx == dpR) {
      if (d == 1) {
        curr->emitl = -1; curr->emitr = i; curr->transition = TRR; 	/* S(R) -> end */
        PushTracestack(stack, AttachTrace (curr, dpR, i, j-1, TRE));
      } else {
	 /*((mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TRR]) == mx[dpR][j][d])*/
        curr->emitl = -1; curr->transition = TRR;
        PushTracestack(stack, AttachTrace (curr, dpR, i, j-1, TRE));
      } 
    } else if (mtx == dpP) {
      if ((mx[dpP][j-1][d-2] + pr->stack[idx(rna[i-1], rna[j+1])][rna[i]][rna[j]] + pr->transitions[TPP]) == mx[dpP][j][d]) {
        curr->transition = TPP;
        PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TRE));
      } else {
	 curr->transition = TPN;
	 PushTracestack(stack, AttachTrace (curr, dpN, i+1, j-1, TRE)); 
      }
    } else if (mtx == dpN) {
      if ((mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TNR]) == mx[dpN][j][d]) {
        curr->emitl = -1; curr->transition = TNR;
        PushTracestack(stack, AttachTrace (curr, dpR, i, j-1, TRE));
      } else if ((mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TNL]) == mx[dpN][j][d]) {
        curr->emitr = -1; curr->transition = TNL;
        PushTracestack(stack, AttachTrace (curr, dpL, i+1, j, TRE));
      } else {
        for (k = i; k < j; k++) {
          if ((mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] + pr->transitions[TNB]) == mx[dpN][j][d]) {
	    curr->emitl = -1; curr->emitr = -1; curr->transition = TNB;
            PushTracestack(stack, AttachTrace (curr, dpS, k+1, j, TRE));
            PushTracestack(stack, AttachTrace (curr, dpL, i, k, TRE));
	    k = j;	/* Short circuit */
          } /* End if */
        } /* End for (bifurcation points) */
      } /* end if (S-> aSb | aL | Rb | LS) */
    } else {		
	printf("ERROR!! Nonterminal %d unknown in traceback!\n", mtx);
    } /* End if dpS, dpL or dpR */
  } /* end while stack not empty*/
  FreeTracestack(stack);
  return parsetree;
}

/*************************  TRAIN ******************************/
/* Function: khs2traceUYN
 * Date:     RDD, Tue Apr 23 09:39:07 2002 [St. Louis]
 *
 * Purpose: Convert KHS to traceback tree properly 
 * 	labeled for UYN grammars. 
 *
 * Args:     
 *	dolist  Traceback tree to build from KHS	
 *	ct	KHS info represented as ct format
 *	tolerate	Do we ignore illegal structure or do the 
 *			best we can?  (ignored -- needed for amb_test;
 *			do best we can for training)
 */
int
khs2traceUYN(struct tracestack_s *dolist, int *ct, int tolerate)
{
  struct trace_s      *cur;
  struct trace_s      *tr;
  struct trace_s      *prv, *nxt;
  char left; char right;
  int  i,j, mid;

  while ((cur = PopTracestack(dolist)) != NULL) {
    i = cur->emitl;           /* 0..len-1 */
    j = cur->emitr;           /* 0..len-1 */

    if (i > j) {
      cur->transition = TRE; cur->emitl = -1; cur->emitr = -1; cur->nonterminal = dpE;

    } else if (ct[j] == -1) {   /* j unpaired: single strand right */
      /* In region of right single stranded */
      if (cur->nonterminal == dpR) {
	cur->transition = TRR; cur->emitl = -1;
	PushTracestack(dolist, AttachTrace(cur, dpR, i, j-1, TRE));
      } else if (!tolerate && (cur->nonterminal == dpP)) {
	 return 0; 	/* No lone pairs */
      } else {
	mid = find_split(ct, i, j);
	if (mid  < 0) {   /* no pairs, open right string */
          if (cur->nonterminal == dpS) {
	    cur->transition = TSR; 
          } else {
	    cur->transition = TNR; 
          }
          cur->emitl = -1;
	  PushTracestack(dolist, AttachTrace(cur, dpR, i, j-1, TRE));
	} else {	/* pairs exist, must bifurcate */
          if (cur->nonterminal == dpS) {
            cur->transition = TSB; 
          } else {
            cur->transition = TNB;
          }
	  cur->emitl = -1; cur->emitr = -1;
	  PushTracestack(dolist, AttachTrace(cur, dpS, mid+1, j, TRE));
	  PushTracestack(dolist, AttachTrace(cur, dpL, i, mid, TRE));
	}
      } /* end what kind of right state is this? */

    } else if (ct[i] == -1) {   /* i unpaired; single strand left */
      if (cur->nonterminal == dpL) {
	cur->transition = TLL; cur->emitr = -1;
        PushTracestack(dolist, AttachTrace(cur, dpL, i+1, j, TRE));
      } else if (!tolerate && (cur->nonterminal == dpP)) {
	 return 0; 	 /* No lone pairs */
      } else {
	mid = find_split(ct, i, j);
        if (mid < j) {
          if (cur->nonterminal == dpS) {
	    cur->transition = TSB; 
          } else {
	    cur->transition = TNB; 
          }
	  cur->emitl = -1; cur->emitr = -1;
	  PushTracestack(dolist, AttachTrace(cur, dpS, mid+1, j, TRE));
	  PushTracestack(dolist, AttachTrace(cur, dpL, i, mid, TRE));
        } else {
          if (cur->nonterminal == dpS) {
	    cur->transition = TSL; 
          } else {
	    cur->transition = TNL; 
          }
          cur->emitr = -1;
          PushTracestack(dolist, AttachTrace(cur, dpL, i+1, j, TRE));
        }
      }

    } else if (ct[i] == j) {    /* i,j paired to each other */
      if (!tolerate && (i+1 == j)) { return 0; }	/* Hairpins min is 1 nt */
      switch (cur->nonterminal) {
        case dpS: 
          cur->transition = TSP;  
          PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
          break;
        case dpL: 
          cur->transition = TLP;  
          PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
          break;
        case dpP: 
          if (ct[i+1] != j-1) {
            cur->transition = TPN;  
            PushTracestack(dolist, AttachTrace(cur, dpN, i+1, j-1, TRE));
          } else {
            cur->transition = TPP;  
            PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
          }
          break;
        default: break;
      }
    } else {            /* i,j paired but not to each other */
       if (cur->nonterminal == dpS) {
	  cur->transition = TSB; 
       } else if (!tolerate && (cur->nonterminal == dpP)) {
	  return 0; 	 /* No lone pairs */
       } else {
	  cur->transition = TNB; 
       }
       cur->emitl = -1; cur->emitr = -1;
       mid = ct[i];	/* Always do left first */
       PushTracestack(dolist, AttachTrace(cur, dpS, mid+1, j, TRE));
       PushTracestack(dolist, AttachTrace(cur, dpL, i, mid, TRE));
    }
  }   /* while something's on dolist stack */
  return 1;
}

/********************* Conditional Inside ************************/

/* Function: cinsInitUYN
 * Date:     RDD, Sun Oct  5 15:50:20 CDT 2003 [St Louis]
 *
 * Purpose:  Initialize cInside fill matrix for UYN grammar
 *
 * Args:     
 *	mx	fill matrix (log odds form)
 *	model	parameters
 *	rna	sequence
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cinsInitUYN(double ***mx, PROBMOD *model, char *rna, int len)
{
   int j, d;

   for (d = 0; d <= len; d++) { 
      for (j = d; j < len; j++) {
	 mx[dpS][j][d] = -BIGFLOAT;
	 mx[dpP][j][d] = -BIGFLOAT;
	 mx[dpN][j][d] = -BIGFLOAT;
	 mx[dpL][j][d] = -BIGFLOAT;
	 mx[dpR][j][d] = model->transitions[TRE];
      }
      if (d > 0) {
	 mx[dpS][d-1][d] = -BIGFLOAT;
	 mx[dpP][d-1][d] = -BIGFLOAT;
	 mx[dpN][d-1][d] = -BIGFLOAT;
	 mx[dpL][d-1][d] = -BIGFLOAT;
	 mx[dpR][d-1][d] = model->transitions[TRE];
      }
   }
}

/* Function: cinsFillUYN
 * Date:     Sun Oct  5 15:51:23 CDT 2003 [St Louis]
 *
 * Purpose:  Fills cInside matrix for and UYN grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (log Probs)
 *	pr	parameters 
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
cinsFillUYN(double ***mx, PROBMOD *pr, char *rna, int len, int *ss)
{
   int d, i, j, k;       /* Loop indicies */
   double cursc, cursc2;    /* Current score */
   double stackvalue;	

   /* Recursion */
   for (d = 1; d <= len; d++) {
      for (j = d-1; j < len; j++) {
	 i = j - d + 1;  
	 
	 cursc= -BIGFLOAT;
	 /* S -> aPb | aR | Lb | LS */
	 if (ss[i] == -1) cursc = mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL];

	 if (j > 0) {
	    /* S -> Rb */
	    if (ss[j] == -1) 
	       cursc = DLogsum(mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR], cursc);

	    /* S -> aPb */
	    if (d > 1) {
	       if (ss[i] == j) {
		  cursc = DLogsum(mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
		     + pr->transitions[TSP], cursc);
	       }
	    }
	 } else if (d == 1) {	/* Special case of 1 nt */
	    /* S -> Ra */
	    cursc = DLogsum(pr->transitions[TRE] + pr->singles[rna[j]] + pr->transitions[TSR], cursc);
	 }

	 /* S -> LS */
	 for (k = i; k < j; k++) {
	    cursc = DLogsum(mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] + pr->transitions[TSB], cursc);
	 }

	 /* S -> aPb | aR | Lb | LS */
	 mx[dpS][j][d] = cursc;

	 cursc = -BIGFLOAT;
	 /* L -> aPb | aL */
	 if ((j > 0) && (d > 1)) {
	    if (ss[i] == j) {
	       cursc = mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TLP];
	    }
	 }
	 if (ss[i] == -1) 
	    cursc = DLogsum(mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TLL], cursc);
	 mx[dpL][j][d] = cursc;

	 /* R -> Ra | end */
	 if (ss[j] == -1) {
	    if ((j > 0) && (d > 1)) {
	       mx[dpR][j][d] = mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TRR];
	    } else {	/* d = 1 */
	       mx[dpR][j][d] = pr->transitions[TRE] + pr->singles[rna[j]] + pr->transitions[TRR];
	    }
	 } else {
	   mx[dpR][j][d] = -BIGFLOAT;
	 }

	 cursc = -BIGFLOAT;
	 /* N -> aL | Ra | LS */
	 if (ss[i] == -1) cursc = mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TNL];

	 if (j > 0) {
	    /* N -> Ra */
	    if (ss[j] == -1) 
	       cursc = DLogsum(mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TNR], cursc);
	 }

	 /* N -> LS */
	 for (k = i; k < j; k++) {
	    cursc = DLogsum(mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] + pr->transitions[TNB], cursc);
	 }

	 mx[dpN][j][d] = cursc;

	 cursc = -BIGFLOAT;
	 /* P -> aPa' | aNa'  (stacking!) */
	 /* Can't be in P state at edges!  */
	 if ((i == 0) || (j == len-1)) {
	    stackvalue = -BIGFLOAT;
	 } else {
	    stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]];
	 }
	 if (ss[i] == j) {
	    if ((j > 0) && (d > 1)) {
	       /* P -> aPb | aNb  */
	       cursc = mx[dpP][j-1][d-2] + stackvalue + pr->transitions[TPP];
	       cursc = DLogsum(mx[dpN][j-1][d-2] + stackvalue + pr->transitions[TPN], cursc);

	    }
	 }
	 mx[dpP][j][d] = cursc; 
      } /* End for loop */
  } /* End foreach n */
}

