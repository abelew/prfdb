/* gr_rzk.c
 * RDD, Thu Mar 27 13:23:30 CST 2003 [St Louis]
 *
 * Implementations of grammar specific routines for  
 * Unambiguous Zuker 
 *
 * Unambiguous Zuker  		(RZK)
 *   S -> aS | T | end
 *   T -> Ta | aPa' | TaPa'
 *   P -> aPa' | aNa'
 *   N -> a...a | a... aPa' | aPa' ...a | a... aPa' ...a | MT
 *   M -> aM | J
 *   J -> Ja | aPa'
 *
 * These implementations assume a digitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"
#include "grammars.h"

/*********************************** CYK ***********************************/
/* Function: cykInitRZK
 * Date:     RDD, Mon Mar  4 09:25:58 CST 2002 [St Louis]
 *
 * Purpose:  Initialize CYK fill matrix for
 * 		Unambiguous Zuker algorithm
 *
 * Args:     
 *	mx	fill matrix (integer log odds form)
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cykInitRZK(int ***mx, INTMOD *model, char *rna, int len)
{
  int j, d;

  for (d = 0; d <= len; d++) {
     for (j = d; j < len; j++) {
	mx[dpS][j][d] = model->transitions[TSE];
	mx[dpT][j][d] = -BIGINT;
	mx[dpP][j][d] = -BIGINT;
	if (d > HLEN) {
	   mx[dpN][j][d] = model->transitions[TNH] + model->emithp[j-d+1]
	      + model->hairpin[lpindex(d)] - model->emithp[j+1];
	} else {
	   mx[dpN][j][d] = -BIGINT;
	}
	mx[dpM][j][d] = -BIGINT;
	mx[dpJ][j][d] = -BIGINT;
     }
     if (d > 0) {
	mx[dpS][d-1][d] = model->transitions[TSE];
	mx[dpT][d-1][d] = -BIGINT;
	mx[dpP][d-1][d] = -BIGINT;
	if (d > HLEN) {
	   mx[dpN][d-1][d] = model->transitions[TNH] + model->emithp[0]
	      + model->hairpin[lpindex(d)] - model->emithp[d];
	} else {
	  mx[dpN][d-1][d] = -BIGINT;
	}
	mx[dpM][d-1][d] = -BIGINT;
	mx[dpJ][d-1][d] = -BIGINT;
     }
  }
  
}

/* Function: cykFillRZK
 * Date:     RDD, Fri Mar  1 14:42:16 CST 2002 [St Louis]
 *
 * Purpose:  Fills CYK matrix for RZK 
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	sc	parameters 
 *		(integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Notes: Fills matrix correctly for RZK 
 *      Must fill T before S as one rule in S allows S -> T
 *      Must fill J before M as one rule in J allows J -> M
 *
 * Returns:  void 
 */
void
cykFillRZK(int ***mx, INTMOD *pr, char *rna, int len)
{
  int i, j, k, l;    /* Loop indicies */
  int d, d1, d2, d3;     /* lengths/distances */
  int max, min; 	/* Maximum value seen so far; Min in loop index */
  int cursc, cursc2;    /* Current score */
  int stackvalue;

  int L, r, sc; /* N^3 internal loop variables */
  int *Ibest; 		/* N^3 internal loop variable */

   /* Allocate Ibest */
   if ((Ibest = (int *) malloc (len * sizeof(int))) == NULL) Die("malloc failed");

   /* Recursion 
    *   - We must keep j in the outter loop for the N^3 internal loops,
    *     as Ibest is relative to a particular j.
    *   - The alternative is to go:
    *   	for (d = 1; d <= len; d++)
    *   	   for (j = d-1; j < len; j++)
    *     these are equivalent.
    */
   for (j = 0; j < len; j++) {
      for (d = 1; d <= j+1; d++) {
	 i = j - d + 1; max = -BIGINT;

	 /* T -> Ta */
	 if (j > 0) {
	    cursc = mx[dpT][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TTT];
	    if (cursc > max) max = cursc;

	    /* T -> aPa' */
	    if (d-1 > HLEN) { 
	       cursc = mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TTP]; 
	    } else cursc = -BIGINT; 
	    if (cursc > max) max = cursc; 
	 }

	 /* T -> T aPa' */
	 for (k = i+1; k < j-HLEN; k++) {
	    d1 = k-i;  d2 = j-k-1;
	    cursc = mx[dpT][k-1][d1] + mx[dpP][j-1][d2]
	       + pr->pairs[rna[k]][rna[j]] + pr->transitions[TTB];
	    if (cursc > max) max = cursc; 
	 } /* End for loop T -> T aSa' */

	 /* T -> Ta | aPa' | T aPa' */
	 mx[dpT][j][d] = max;

	 /* S -> aS | T */
	 cursc = mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSS];
	 cursc2 = mx[dpT][j][d] + pr->transitions[TST];
	 if (cursc > cursc2) { mx[dpS][j][d] = cursc; }
	 else { mx[dpS][j][d] = cursc2; }

	 /* J -> Ja | aPa' */
	 if (j > 0) {
	 cursc = mx[dpJ][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TJJ];
	 } else cursc = -BIGINT;

	 if (d-1 > HLEN) cursc2 = mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]]+ pr->transitions[TJP]; 
	 else cursc2 = -BIGINT; 

	 if (cursc2 > cursc) { mx[dpJ][j][d] = cursc2; }
	 else { mx[dpJ][j][d] = cursc; }

	 /* M -> aM | J */
	 cursc = mx[dpM][j][d-1] + pr->singles[rna[i]] + pr->transitions[TMM];
	 cursc2 = mx[dpJ][j][d] + pr->transitions[TMJ];
	 if (cursc > cursc2) { mx[dpM][j][d] = cursc; }
	 else { mx[dpM][j][d] = cursc2; }

	 /* N -> a...a | a... aPa' | aPa' ...a | a... aPa' ...a | MT */
	 max = -BIGINT;

	 /* N -> a... a */
	 if (d >= HLEN) {	/* Min hp loop length */
	    cursc = pr->hairpin[lpindex(d)] + pr->emithp[i] 
	       + pr->transitions[TNH] - pr->emithp[j+1];
	 } else {
	    cursc = -BIGINT;
	 }
	 if (cursc > max) max = cursc; 

	 /* N -> a... aPa' */
	 for (k = i+1; k < j-HLEN; k++) {
	    d1 = k-i; d2 = j-k-1;	/* d = d1 + d2 + 2 */
	    cursc = mx[dpP][j-1][d2] + pr->transitions[TNL] 
	       + pr->pairs[rna[k]][rna[j]] + pr->emitbulge[i] 
	       - pr->emitbulge[k] + pr->bulge[lpindex(d1)];
	    if (cursc > max) { max = cursc; }
	 }

	 /* N -> aPa' ...a */
	 for (k = i+HLEN+1; k < j; k++) {
	    d1 = k-i-1;  d2 = j-k;	/* d = d1 + d2 + 2 */
	    cursc = mx[dpP][k-1][d1] + pr->transitions[TNR] 
	       + pr->pairs[rna[i]][rna[k]]
	       + pr->emitbulge[k+1] + pr->bulge[lpindex(d2)]
	       - pr->emitbulge[j+1]; 
	    if (cursc > max) { max = cursc; }
	 }
	
	 /* N -> MT */
	 for (k = i; k < j; k++) {
	    d1 = k-i+1; d2 = j-k;
	    cursc = mx[dpM][k][d1] + mx[dpT][j][d2] + pr->transitions[TNB]; 
	    if (cursc > max) { max = cursc; }
	 }  

	 /* N -> a... aPa' ...a  (N^4 version) 
	  *    This version works regardless the order of the
	  *    outer loops.
	 for (k = i+1; k < j-HLEN-1; k++) {
	    for (l = k+HLEN+1; l < j; l++) {
	       d1 = k-i; d2 = l-k-1; d3 = j-l;	
               cursc = mx[dpP][l-1][d2] + pr->transitions[TNI]
		 + pr->loop[lpindex(ilplen(i, k-1, l+1,j))] 
		 + pr->emitloop[i] - pr->emitloop[k] 
		 + pr->emitloop[l+1] - pr->emitloop[j+1]
	         + pr->pairs[rna[k]][rna[l]];
	       if (cursc > max) { 
		  max = cursc; 
		  if (dist(k,l) == 5)
		    printf("max %d i %d k %d l %d j %d \n", max, i, k, l, j);
	       }
            } 
          } 
	  * */

	 /* N^3 internal loops 
	  * */
	 for (r=HLEN+2; ((r+1) < d); r++) {
	    sc = mx[dpP][i+r-1][r-2] + pr->pairs[rna[i+1]][rna[i+r]] 
		- pr->emitloop[i+1] + pr->emitloop[i+r+1]; 
	    if (r == (d-2)) Ibest[r] = sc;  
	    else if (sc > Ibest[r]) Ibest[r] = sc; 
	 }

	 for (L = 2; ((L+HLEN+1 < d) && (L < MAXLOOP)); L++) {
	    r = d-L;
	    sc = pr->loop[lpindex(L)] + Ibest[r] + pr->transitions[TNI] + 
	       pr->emitloop[i] - pr->emitloop[j+1];
	    if (sc > max) max = sc; 
	 }

	 mx[dpN][j][d] = max;

	 /* P -> aPa' | aNa' */
	 /* Stacking! Can't be in P state at edges!  */
	 if ((i == 0) || (j == len-1)) { stackvalue = -BIGINT; } 
	 else { stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]]; }

	 if ((d-1 > HLEN) && (d-2 > 0)) { 
	    cursc = mx[dpP][j-1][d-2] + stackvalue + pr->transitions[TPP]; 
	    cursc2 = mx[dpN][j-1][d-2] + stackvalue + pr->transitions[TPN]; 
	    if (cursc > cursc2) mx[dpP][j][d] = cursc; 
	    else mx[dpP][j][d] = cursc2; 
	 } else { mx[dpP][j][d] = -BIGINT; }

      }
   }
}

/* Function: cykTraceRZK
 * Date:     RDD, Mon Mar  4 09:25:58 CST 2002 [St Louis]
 *
 * Purpose:  Build traceback tree for RZK 
 *
 * Args:
 *	mx	matrix in which to calculate cyk
 *	pr	parameters in integer form
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns: --void --
 */
struct trace_s *
cykTraceRZK(int ***mx, INTMOD *pr, char *rna, int len)
{
  int d, d1, d2, d3;
  int i, j, k, l, mtx;   /* Indices */
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */
  int hairpin, bulgeleft, bulgeright, intloop, found;

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (len -1), TRE));

  /* Repeat until stack is empty */
  while (curr = PopTracestack(stack)) {
    /* Set i and j from items in stack */
    i = curr->emitl; j = curr->emitr; mtx = curr->nonterminal;
    d = j-i+1;

    if (i > j) { 		/* S(R) -> end */
      curr->emitl = -1; curr->emitr = -1; 
      curr->transition = TSE; curr->nonterminal = dpS; 
      continue;
    } else if (mtx == dpS) {
      /* S -> aS | T | end */
      if ((i == j) ||
         ((mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSS]) == mx[dpS][j][d])) {
        curr->emitr = -1; curr->transition = TSS; 
        PushTracestack(stack, AttachTrace (curr, dpS, i+1, j, TRE));
      } else { 		/* S -> T */
        curr->emitr = -1; curr->emitl = -1; curr->transition = TST; 
        PushTracestack(stack, AttachTrace (curr, dpT, i, j, TRE));
      }

    } else if (mtx == dpT) {
      /* T -> Ta | aPa' | T aPa' */
      if ((mx[dpT][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TTT]) == mx[dpT][j][d]) {
        curr->emitl = -1; curr->transition = TTT; 
        PushTracestack(stack, AttachTrace (curr, dpT, i, j-1, TRE));
      } else if ((mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
		+ pr->transitions[TTP]) == mx[dpT][j][d]) {
        curr->transition = TTP;
        PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TRE));
      } else {	/* T -> TaPa' */
	for (k = i+1; k < j-HLEN; k++) {
	  d1 = k-i; d2 = j-k-1;
          if ((mx[dpT][k-1][d1] + mx[dpP][j-1][d2] + pr->pairs[rna[k]][rna[j]] + 
			pr->transitions[TTB]) == mx[dpT][j][d]) {
            curr->emitl = k; curr->transition = TTB;
            PushTracestack(stack, AttachTrace (curr, dpP, k+1, j-1, TRE));
            PushTracestack(stack, AttachTrace (curr, dpT, i, k-1, TRE));
	    k = j;	/* Short circuit */
          } /* End if */
        } /* End for (bifurcation points) */
      } 
    } else if (mtx == dpM) {
      /* M -> aM | J */
      if ((mx[dpM][j][d-1] + pr->singles[rna[i]] + pr->transitions[TMM]) == mx[dpM][j][d]) {
	curr->emitr = -1; curr->transition = TMM;
	PushTracestack(stack, AttachTrace (curr, dpM, i+1, j, TRE));
      } else { /* M -> J */
	curr->emitr = -1; curr->emitl = -1; curr->transition = TMJ;
	PushTracestack(stack, AttachTrace (curr, dpJ, i, j, TRE));
      }
		  
    } else if (mtx == dpJ) {
      /* J -> Ja | aPa' */
      if ((mx[dpJ][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TJJ]) == mx[dpJ][j][d]) {
	curr->emitl = -1; curr->transition = TJJ;
	PushTracestack(stack, AttachTrace (curr, dpJ, i, j-1, TRE));
      } else { /* J -> aPa' */
	curr->transition = TJP;
	PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TRE));
      }
    } else if (mtx == dpN) { 
      /* N -> a..a | a..aPa' | aPa'..a | a..aPa'..a | MT */ 
      hairpin = pr->hairpin[lpindex(d)] + pr->emithp[i] 
	 + pr->transitions[TNH] - pr->emithp[j+1];
      if (hairpin == mx[dpN][j][d]) {
	curr->transition = TNH; 
      } else { 
        found = FALSE;
        /* N -> a... aPa' */
	for (k = i+1; k < j-HLEN; k++) {
	  d1 = k-i; d2 = j-k-1;
          bulgeleft = mx[dpP][j-1][d2] + pr->transitions[TNL] 
	     + pr->pairs[rna[k]][rna[j]] + pr->bulge[lpindex(d1)]
	     + pr->emitbulge[i] - pr->emitbulge[k];
	  if (bulgeleft == mx[dpN][j][d]) { 
	    curr->emitl = k; curr->transition = TNL;
	    PushTracestack(stack, AttachTrace (curr, dpP, k+1, j-1, TRE));
            found = TRUE;
	    k = j;      /* Short circuit */
          }
        }
        if (!found) {
          /* N -> aPa' ...a */
	  for (k = i+HLEN+1; k < j; k++) {
	    d1 = k-i-1; d2 = j-k;
            bulgeright = mx[dpP][k-1][d1] + pr->transitions[TNR] 
	       + pr->pairs[rna[i]][rna[k]] + pr->bulge[lpindex(d2)]
	       + pr->emitbulge[k+1] - pr->emitbulge[j+1]; 
	    if (bulgeright == mx[dpN][j][d]) {
	      curr->emitr = k; curr->transition = TNR;
	      PushTracestack(stack, AttachTrace (curr, dpP, i+1, k-1, TRE));
              found = TRUE;
	      k = j;      /* Short circuit */
            }
          }
        } 
        if (!found) {
          /* N -> a... aPa' ...a  (N^4 version) */
          /* How do we do this in N^3??? */
	  for (k = i+1; k < j-HLEN-1; k++) {
	     for (l = k+HLEN+1; l < j; l++) {
	       d1 = k-i; d2 = l-k-1; d3 = j-l;	/* d = d1 + d2 + d3 + 2 */
               intloop = mx[dpP][l-1][d2] + pr->transitions[TNI]
		 + pr->loop[lpindex(ilplen(i, k-1, l+1,j))] 
		 + pr->emitloop[i] - pr->emitloop[k] 
		 + pr->emitloop[l+1] - pr->emitloop[j+1]
	         + pr->pairs[rna[k]][rna[l]];
	      if (intloop == mx[dpN][j][d]) {
		curr->transition = TNI; curr->emitl = k; curr->emitr = l;
		PushTracestack(stack, AttachTrace (curr, dpP, k+1, l-1, TRE));
                found = TRUE; l = k = j; /* Short circuit */
	      } /* if TNI */
            } /* l */
          } /* k */
        } 
        if (!found) {
          /* N -> MT */
	  for (k = i; k < j; k++) {
	    d1 = k-i+1; d2 = j-k;
	    if ((mx[dpM][k][d1] + mx[dpT][j][d2] + pr->transitions[TNB]) == mx[dpN][j][d]) {
	      curr->emitr = -1; curr->emitl = -1; curr->transition = TNB;
	      PushTracestack(stack, AttachTrace (curr, dpT, k+1, j, TRE));
	      PushTracestack(stack, AttachTrace (curr, dpM, i, k, TRE));
              found = TRUE;
	      k = j;      /* Short circuit */
            }
          }
        }
      } /* else -- not hairpin */
    } else if (mtx == dpP) {
      /* P -> aPa' | aS | Ta | T aPa' */
      if ((mx[dpP][j-1][d-2] + pr->stack[idx(rna[i-1], rna[j+1])][rna[i]][rna[j]] 
				+ pr->transitions[TPP]) == mx[dpP][j][d]) {
	curr->transition = TPP;
	PushTracestack(stack, AttachTrace (curr, dpP, i+1, j-1, TRE));
      } else {
	 curr->transition = TPN;
	 PushTracestack(stack, AttachTrace (curr, dpN, i+1, j-1, TRE));
      }
    } else {
      printf("ERROR!! Nonterminal %d unkown in RUN/RYN traceback!\n", mtx);
    }
  }
  FreeTracestack(stack);
  return parsetree;
}

/*********************** Train Functions ********************/
/* Function:  khs2traceRZK
 * Date:     RDD, Tue Apr 23 11:21:11 2002 [St. Louis]
 *
 * Purpose: Convert KHS to traceback tree properly 
 * 	labeled for RZK grammar. 
 *
 * Args:     
 *	dolist  Traceback tree to build from KHS	
 *	ct	KHS info represented as ct format
 */
int
khs2traceRZK(struct tracestack_s *dolist, int *ct)
{
  struct trace_s      *cur;
  struct trace_s      *tr;
  struct trace_s      *prv, *nxt;
  char left; char right;
  int  i,j, mid, mid2;

  while ((cur = PopTracestack(dolist)) != NULL) {
    i = cur->emitl; j = cur->emitr;

    if (i > j) {
      cur->transition = TSE; cur->emitl = -1; cur->emitr = -1; 
    } else if (ct[i] == -1) {	/* left unpaired */
      switch (cur->nonterminal) {
	case dpS:
          cur->transition = TSS; cur->emitr = -1;
          PushTracestack(dolist, AttachTrace(cur, dpS, i+1, j, TRE));
	  break;
	case dpM:
          cur->transition = TMM; cur->emitr = -1;
          PushTracestack(dolist, AttachTrace(cur, dpM, i+1, j, TRE));
	  break;
	case dpN:
	  /* Can't be right bulge as (by def) the left position is unpaired */
	  mid = find_split(ct, i, j);
	  if (mid < 0 ) {	/* No stems, must be a hairpin */
            cur->transition = TNH;
	  } else {		/* Region contains stems */
            if (mid == j) {	/* Only stem at far right -- this is a Left bulge */
              cur->transition = TNL; cur->emitl = ct[j]; 
              PushTracestack(dolist, AttachTrace(cur, dpP, ct[j]+1, j-1, TRE));
	    } else {		/* Contains at least one stem, check if more */
	      mid2 = find_split(ct, mid+1, j);
	      if (mid2 < 0) {	/* Nope, only the one -> therefore is Internal loop */
	        cur->transition = TNI; cur->emitl = ct[mid]; cur->emitr = mid;
                PushTracestack(dolist, AttachTrace(cur, dpP, ct[mid]+1, mid-1, TRE));
	      } else {		/* Multiple stems, must bifurcate */
	        cur->transition = TNB; cur->emitr = -1; cur->emitl = -1;
                PushTracestack(dolist, AttachTrace(cur, dpT, ct[mid2], j, TRE));
	        /* Left Nonterminal (M) must take care of first stem and 
		 * flanking single stranded */
                PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[mid2]-1, TRE));
	      }
	    }
	  }
	  break;
        case dpP:
	  /* This structure doesn't obey minimum stacking rules for RZK, push through*/
	  cur->transition = TPN; cur->emitl = -1; cur->emitr = -1;
          PushTracestack(dolist, AttachTrace(cur, dpN, i, j, TRE));
	  break;
	default:
	  printf ("ERROR: Can't have left unpaired in %s!\n", dpNAME[cur->nonterminal]);
	  break;
      }
    } else if (ct[j] == -1) {	/* right unpaired */
      switch (cur->nonterminal) {
	case dpS:
          cur->transition = TST; cur->emitl = -1; cur->emitr = -1; 
          PushTracestack(dolist, AttachTrace(cur, dpT, i, j, TRE));
	  break;
	case dpM:
	  cur->transition = TMJ; cur->emitl = -1; cur->emitr = -1;
          PushTracestack(dolist, AttachTrace(cur, dpJ, i, j, TRE));
	  break;
	 case dpT:
           cur->transition = TTT; cur->emitl = -1; 
           PushTracestack(dolist, AttachTrace(cur, dpT, i, j-1, TRE));
	   break;
	 case dpJ:
           cur->transition = TJJ; cur->emitl = -1; 
           PushTracestack(dolist, AttachTrace(cur, dpJ, i, j-1, TRE));
	   break;
	 case dpN:
	  /* Can't be left bulge as (by def) the right position is unpaired */
	  mid = find_split(ct, i, j);
	  if (mid < 0 ) {	/* No stems, must be a hairpin */
            cur->transition = TNH;
	  } else {		/* Region contains stems */
             if (ct[mid] == i) {	/* Only stem at far left -- this is a right bulge */
               cur->transition = TNR; cur->emitr = ct[i];
               PushTracestack(dolist, AttachTrace(cur, dpP, i+1, mid-1, TRE));
	     } else {		/* Contains at least one stem, check if more */
	       mid2 = find_split(ct, mid+1, j);
	       if (mid2 < 0) {	/* Nope, only the one -> therefore is Internal loop */
	         cur->transition = TNI; cur->emitl = ct[mid]; cur->emitr = mid;
                 PushTracestack(dolist, AttachTrace(cur, dpP, ct[mid]+1, mid-1, TRE));
	       } else {		/* Multiple stems, must bifurcate */
	         cur->transition = TNB;
                 PushTracestack(dolist, AttachTrace(cur, dpT, ct[mid2], j, TRE));
	         /* Left Nonterminal (M) must take care of first stem and 
		  * flanking single stranded */
                 PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[mid2]-1, TRE));
	       }
	     }
	   }
	   break;
         case dpP:
	   /* This structure doesn't obey minimum stacking rules for uZK, push through*/
	   cur->transition = TPN; cur->emitl = -1; cur->emitr = -1;
           PushTracestack(dolist, AttachTrace(cur, dpN, i, j, TRE));
           break;
	 default:
	  printf ("ERROR: Can't have right unpaired in %s!\n", dpNAME[cur->nonterminal]);
	  break;
        }
    } else if (ct[i] == j) {	/* left pairs to right */
      switch (cur->nonterminal) {
	case dpS:
          cur->transition = TST; cur->emitl = -1; cur->emitr = -1; 
          PushTracestack(dolist, AttachTrace(cur, dpT, i, j, TRE));
	  break;
	case dpM:
          cur->transition = TMJ; cur->emitl = -1; cur->emitr = -1; 
          PushTracestack(dolist, AttachTrace(cur, dpJ, i, j, TRE));
	  break;
	case dpT:
          cur->transition = TTP;
          PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
	  break;
	case dpJ:
          cur->transition = TJP;
          PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
	  break;
	case dpP:
	  if ((ct[i+1] != j-1)) { /* Does it stack? */
            cur->transition = TPN;
            PushTracestack(dolist, AttachTrace(cur, dpN, i+1, j-1, TRE));
	  } else {
            cur->transition = TPP;
            PushTracestack(dolist, AttachTrace(cur, dpP, i+1, j-1, TRE));
	  }
	  break;
	default:
	  /* When it throws this error what in the hell does that mean? */
	  printf ("ERROR: Can't have i paired with j in %s!\n", dpNAME[cur->nonterminal]);
	  break;
      }
    } else {		/* left pairs, not to right */
      switch (cur->nonterminal) {
	case dpS:
          cur->transition = TST; cur->emitl = -1; cur->emitr = -1; 
          PushTracestack(dolist, AttachTrace(cur, dpT, i, j, TRE));
	  break;
	case dpT:
          cur->transition = TTB; cur->emitl = ct[j];
          PushTracestack(dolist, AttachTrace(cur, dpP, ct[j]+1, j-1, TRE));
          PushTracestack(dolist, AttachTrace(cur, dpT, i, ct[j]-1, TRE));
	  break;
	case dpN:
	  /* Must be bifurcation state because if we got here then the left and right
	   * are paired to something, just not each other.  Hence bifurcation. */
	  cur->transition = TNB; cur->emitr = -1; cur->emitl = -1;
	  /* Because the M state must take care of interstem region to its left, 
	   * we must now find the edge of that interstem sequence. */
	  mid = find_split(ct, ct[i]+1, ct[j]-1);	
	  if (mid < 0) {	/* No stems in between */
            PushTracestack(dolist, AttachTrace(cur, dpT, ct[j], j, TRE));
            PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[j]-1, TRE));
	  } else {		/* Cotains stems in between */
            PushTracestack(dolist, AttachTrace(cur, dpT, ct[mid], j, TRE));
            PushTracestack(dolist, AttachTrace(cur, dpM, i, ct[mid]-1, TRE));
	  }
	  break;
        default:
	  printf ("ERROR: Can't have i paired, not to j in %s !\n", 
		dpNAME[cur->nonterminal]);
	  break;
      }
    }
  }
  return 1;
}

/* Function: analyzeTraceRZK
 * Date:     RDD, Tue May 14 17:25:29 CDT 2002 [St Louis]
 *
 * Purpose: Parse a traceback tree for information.
 *	Either for counts (training).
 *	Or for determining tracebcak score.
 *
 * Args:     
 *      seq   - sequence corresponding to the trace
 *      len   - length of the sequence
 *      tr    - traceback to count
 *      cfg   - model, counts form, to add counts to
 *      count - if TRUE this is TraceCount; 
 *		if FALSE this is TraceScore
 *
 * Returns:  score of current traceback (in TraceScore mode)
 * 	Should return zero in TraceCount mode
 */
int
analyzeTraceRZK(char *seq, int len, struct trace_s *tr, INTMOD *cfg, int count) 
{
  struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
  struct trace_s      *cur;     /* current node in the tree              */
  char *iseq;                   
  int  i, j, prvl, prvr;
  char left; char right;
  int score;

 /* Digitize Sequence setup */
  SetAlphabet(hmmNUCLEIC);

  iseq = DigitizeSequence(seq, len);

  dolist = InitTracestack();
  PushTracestack(dolist, tr->nxtl);
  score = 0;

  if (!count) {
     preCalcSegs(cfg, iseq, len);
  }

  while ((cur = PopTracestack(dolist)) != NULL) {
     /* printf("(%#12x) %2d  %4d  %4d  %3d  %#10x  %#10x  \n", 
	(int) cur, cur->nonterminal, cur->emitl, cur->emitr, 
	cur->transition, (int) cur->nxtl, (int) cur->nxtr);
	fflush(stdout);
	*/
     if (cur->transition < NTRANS) {
	if (count) cfg->transitions[cur->transition] += 1;
	else score += cfg->transitions[cur->transition];
	if (cur->transition == TSE) {	/* do nothing on ENDS */
	   continue;

	   /* bifurcations */
	} else if (cur->transition == TNB) { /* MT */
	   PushTracestack(dolist, cur->nxtr);
	   PushTracestack(dolist, cur->nxtl);
	} else if (cur->transition == TTB) { /* TaPa' */ 
	   if (count) cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
	   else score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	   PushTracestack(dolist, cur->nxtr);
	   PushTracestack(dolist, cur->nxtl);

	   /* Non-emitting transitions */
	} else if ((cur->emitr == -1) && (cur->emitl == -1)) {
	   PushTracestack(dolist, cur->nxtl);

	} else {
	   /* Count into loop composition matrix */
	   if (cur->nonterminal == dpN) {
	      /* i, j are indicies of P; not edges of this state! */
	      i = cur->emitl; j = cur->emitr;	
	      if (cur->transition == TNH) {
		 if (count) {
		    cfg->hairpin[lpindex(dist(i,j))] += 1;
		    AddLoopCounts(iseq, cfg->hpcomp, i, j);
		 } else {
		    score += cfg->hairpin[lpindex(dist(i,j))]
		    	+ cfg->emithp[i] - cfg->emithp[j+1];
		 }
	      } else if (cur->transition == TNL) {
		 prvl = cur->prv->emitl + 1;		/* Finding left edge! */
		 if (count) cfg->bulge[lpindex(dist(prvl, i-1))] += 1; 
		 else score += cfg->bulge[lpindex(dist(prvl, i-1))];
		 if ((iseq[cur->emitl] <= 4) && (iseq[cur->emitr] <= 4)) {
		    if (count) cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
		    else score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
		 }
		 if (count) { AddLoopCounts(iseq, cfg->bulgecomp, prvl, i-1); }
		 else { score += cfg->emitbulge[prvl] - cfg->emitbulge[i]; }
		 PushTracestack(dolist, cur->nxtl);

	      } else if (cur->transition == TNR) {
		 prvr = cur->prv->emitr - 1;		/* Finding right edge! */
		 if (count) cfg->bulge[lpindex(dist(j+1, prvr))] += 1; 
		 else score += cfg->bulge[lpindex(dist(j+1, prvr))];
		 if ((iseq[cur->emitl] <= 4) && (iseq[cur->emitr] <= 4)) {
		    if (count) cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
		    else score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
		 }
		 if (count) { AddLoopCounts(iseq, cfg->bulgecomp, j+1, prvr); }
		 else { score += cfg->emitbulge[j+1] - cfg->emitbulge[prvr+1]; }
		 PushTracestack(dolist, cur->nxtl);

	      } else if (cur->transition == TNI) {
		 prvl = cur->prv->emitl + 1;	/* Finding left edge */
		 prvr = cur->prv->emitr - 1;	/* Finding right edge */
		 if (count) cfg->loop[lpindex(ilplen(prvl, i-1, j+1, prvr))] += 1;
		 else score += cfg->loop[lpindex(ilplen(prvl, i-1, j+1, prvr))];
		 if ((iseq[cur->emitl] <= 4) && (iseq[cur->emitr] <= 4)) 
		    if (count) {
		       cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
		       AddLoopCounts(iseq, cfg->loopcomp, prvl, i-1);
		       AddLoopCounts(iseq, cfg->loopcomp, j+1, prvr);
		    } else {
		       score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
		       score += cfg->emitloop[prvl] - cfg->emitloop[i]; 
		       score += cfg->emitloop[j+1] - cfg->emitloop[prvr+1]; 
		    }
		 PushTracestack(dolist, cur->nxtl);
	      }
	   } else {	/* single stranded and pairs */
	      if ((iseq[cur->emitl] > ALPHA) || (iseq[cur->emitr] > ALPHA)) {
		 /* Do nothing, contains an ambiguous base! 
		  * Therfore must back out of counting transition!  */
		 if (count) cfg->transitions[cur->transition] -= 1;

		 /* Emit to right */
	      } else if (cur->emitl == -1) {
		 if (count) cfg->singles[iseq[cur->emitr]] += 1;
		 else score +=  cfg->singles[iseq[cur->emitr]];

		 /* Emit to left */
	      } else if (cur->emitr == -1) {
		 if (count) cfg->singles[iseq[cur->emitl]] += 1;
		 else score += cfg->singles[iseq[cur->emitl]];

		 /* Emit aligned pair -- stacking model */
	      } else if (cur->nonterminal == dpP) {
		 if ((iseq[cur->emitl -1] > ALPHA) || (iseq[cur->emitr +1] > ALPHA)) {
		    /* Do nothing, contains an ambiguous base! 
		     * Therfore must back out of counting transition!
		     */
		    if (count) cfg->transitions[cur->transition] -= 1;
		 } else {
		    if (count) {
		       cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
			  [iseq[cur->emitl]][iseq[cur->emitr]] += 1;
		       /* By also adding to pairs, it is like you are averaging the 
			* pair emissions over all pairs (including stacks) */
		       cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
		    } else {
		       score += cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
			  [iseq[cur->emitl]][iseq[cur->emitr]];
		    }
		 }

		 /* Emit aligned pair -- no stacking */
	      } else {
		 if (count) cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
		 else score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	      }
	      PushTracestack(dolist, cur->nxtl);
	   }
	}
     } else {
	PushTracestack(dolist, cur->nxtl);
     }
  }
  free(iseq);
  FreeTracestack(dolist);
  return score;
}

/* Function: trace2khsRZK()
 *
 * Purpose:  From a traceback tree of seq, produce a
 *           secondary structure string. ">" and "<" are
 *           used for pairwise emissions; "." for single-stranded stuff.
 *           Note that structure is defined by pairwise emissions,
 *           not by Watson-Crick-isms and stacking rules.
 *
 * Args:     tr          - traceback structure
 *           seq         - sequence, 0..rlen-1
 *           rlen        - length of seq and returned ss string
 *           watsoncrick - TRUE to annotate canonical pairs only
 *           ret_ss      - RETURN: alloc'ed secondary structure string
 *
 * Return:   ret_ss contains a string 0..rlen-1 containing the
 *           secondary structure. Must be free'd by caller.
 */
void
trace2khsRZK(struct trace_s *tr, char *seq, int rlen, char **ret_ss)
{
  struct tracestack_s *dolist;
  struct trace_s      *curr;
  char                *ss;

  if ((ss = (char *) malloc (sizeof(char) * rlen+1)) == NULL)
    Die("malloc failed");
  memset(ss, '.', rlen);
  ss[rlen] = '\0';

  dolist = (struct tracestack_s *)InitTracestack();
  PushTracestack(dolist, tr->nxtl);

  while ((curr = PopTracestack(dolist)) != NULL) {
    if (curr->transition == TNH) {
    } else
    if ((curr->emitl != -1) && (curr->emitr != -1)) {
      /* if (isRNAComplement(seq[curr->emitl], seq[curr->emitr], 1)) { */
        ss[curr->emitl] = '>';
        ss[curr->emitr] = '<';
      /* } */
    }

    if (curr->nxtr) PushTracestack(dolist, curr->nxtr);
    if (curr->nxtl) PushTracestack(dolist, curr->nxtl);
  }
  FreeTracestack(dolist);
  *ret_ss = ss;
}

#ifdef CINS_RZK

/************************** Inside **************************/
/* Function: cinsInitRZK
 * Date:     Sun Oct  5 18:25:04 CDT 2003 [St Louis]
 *
 * Purpose:  Initialize cInside fill matrix for
 * 		Unambiguous Zuker algorithm
 *
 * Args:     
 *	mx	fill matrix (log odds form)
 *	model	paramters (log odds form)
 *	rna	sequence
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cinsInitRZK(double ***mx, PROBMOD *model, char *rna, int len)
{
  int j, d;

  for (d = 0; d <= len; d++) {
     for (j = d; j < len; j++) {
	mx[dpS][j][d] = model->transitions[TSE];
	mx[dpT][j][d] = -BIGFLOAT;
	mx[dpP][j][d] = -BIGFLOAT;
	if (d > HLEN) {
	   mx[dpN][j][d] = model->transitions[TNH] + model->emithp[j-d+1]
	      + model->hairpin[lpindex(d)] - model->emithp[j+1];
	} else {
	   mx[dpN][j][d] = -BIGFLOAT;
	}
	mx[dpM][j][d] = -BIGFLOAT;
	mx[dpJ][j][d] = -BIGFLOAT;
     }
     if (d > 0) {
	mx[dpS][d-1][d] = model->transitions[TSE];
	mx[dpT][d-1][d] = -BIGFLOAT;
	mx[dpP][d-1][d] = -BIGFLOAT;
	if (d > HLEN) {
	   mx[dpN][d-1][d] = model->transitions[TNH] + model->emithp[0]
	      + model->hairpin[lpindex(d)] - model->emithp[d];
	} else {
	  mx[dpN][d-1][d] = -BIGFLOAT;
	}
	mx[dpM][d-1][d] = -BIGFLOAT;
	mx[dpJ][d-1][d] = -BIGFLOAT;
     }
  }
  
}

/* Function: cinsFillRZK
 * Date:     Sun Oct  5 18:26:44 CDT 2003 [St Louis]
 *
 * Purpose:  Fills cInside matrix for RZK 
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate (log Probs)
 *	sc	parameters (log form)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Notes: Fills matrix correctly for RZK 
 *      Must fill T before S as one rule in S allows S -> T
 *      Must fill J before M as one rule in J allows J -> M
 *
 * Returns:  void 
 */
void
cinsFillRZK(double ***mx, PROBMOD *pr, char *rna, int len, int *ss)
{
  int i, j, k, l;    /* Loop indicies */
  int d, d1, d2, d3;     /* lengths/distances */
  double cursc;
  double stackvalue;

  double L, r, sc; /* N^3 internal loop variables */
  double *Ibest; 		/* N^3 internal loop variable */

   /* Allocate Ibest */
   if ((Ibest = (double *) malloc (len * sizeof(double))) == NULL) Die("malloc failed");

   /* Recursion 
    *   - We must keep j in the outter loop for the N^3 internal loops,
    *     as Ibest is relative to a particular j.
    *   - The alternative is to go:
    *   	for (d = 1; d <= len; d++)
    *   	   for (j = d-1; j < len; j++)
    *     these are equivalent.
    */
   for (j = 0; j < len; j++) {
      for (d = 1; d <= j+1; d++) {
	 i = j - d + 1; 
	 
	 cursc = -BIGFLOAT;
	 /* T -> Ta | aPa' | T aPa' */
	 if (j > 0) {
	    if (ss[j] == -1) cursc = mx[dpT][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TTT];

	    /* T -> aPa' */
	    if (d-1 > HLEN) { 
	       if (ss[i] == j)
		  cursc = DLogsum(mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TTP], cursc); 
	    }
	 }

	 /* T -> T aPa' */
	 for (k = i+1; k < j-HLEN; k++) {
	    if (ss[k] == j) {
	       d1 = k-i;  d2 = j-k-1;
	       cursc = DLogsum(mx[dpT][k-1][d1] + mx[dpP][j-1][d2]
		  + pr->pairs[rna[k]][rna[j]] + pr->transitions[TTB], cursc);
	    }
	 } 

	 /* T -> Ta | aPa' | T aPa' */
	 mx[dpT][j][d] = cursc;

	 cursc = -BIGFLOAT;
	 /* S -> aS | T */
	 cursc = mx[dpT][j][d] + pr->transitions[TST];
	 if (ss[i] == -1) cursc = DLogsum(mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSS], cursc);
	 mx[dpS][j][d] = cursc; 

	 cursc = -BIGFLOAT;
	 /* J -> Ja | aPa' */
	 if (j > 0) {
	    if (ss[j] == -1) 
	       cursc = mx[dpJ][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TJJ];
	 }
	 if (d-1 > HLEN) {
	    if (ss[i] == j) 
	       cursc = DLogsum(mx[dpP][j-1][d-2] + pr->pairs[rna[i]][rna[j]]+ pr->transitions[TJP], cursc); 
	 }
	 mx[dpJ][j][d] = cursc; 

	 /* M -> aM | J */
	 cursc = -BIGFLOAT;
	 cursc = mx[dpJ][j][d] + pr->transitions[TMJ];
	 if (ss[i] == -1) cursc = DLogsum(mx[dpM][j][d-1] + pr->singles[rna[i]] + pr->transitions[TMM], cursc);
	 mx[dpM][j][d] = cursc;

	 cursc = -BIGFLOAT;
	 /* N -> a...a | a... aPa' | aPa' ...a | a... aPa' ...a | MT */
	 if (d >= HLEN) {	/* Min hp loop length */
	    cursc = pr->hairpin[lpindex(d)] + pr->emithp[i] 
	       + pr->transitions[TNH] - pr->emithp[j+1];
	 }

	 /* N -> a... aPa' */
	 for (k = i+1; k < j-HLEN; k++) {
	    d1 = k-i; d2 = j-k-1;	/* d = d1 + d2 + 2 */
	    cursc = mx[dpP][j-1][d2] + pr->transitions[TNL] 
	       + pr->pairs[rna[k]][rna[j]] + pr->emitbulge[i] 
	       - pr->emitbulge[k] + pr->bulge[lpindex(d1)];
	 }

	 /* N -> aPa' ...a */
	 for (k = i+HLEN+1; k < j; k++) {
	    d1 = k-i-1;  d2 = j-k;	/* d = d1 + d2 + 2 */
	    cursc = mx[dpP][k-1][d1] + pr->transitions[TNR] 
	       + pr->pairs[rna[i]][rna[k]]
	       + pr->emitbulge[k+1] + pr->bulge[lpindex(d2)]
	       - pr->emitbulge[j+1]; 
	 }
	
	 /* N -> MT */
	 for (k = i; k < j; k++) {
	    d1 = k-i+1; d2 = j-k;
	    cursc = DLogsum(mx[dpM][k][d1] + mx[dpT][j][d2] + pr->transitions[TNB], cursc); 
	 }  

	 /* N -> a... aPa' ...a  (N^4 version) 
	  *    This version works regardless the order of the
	  *    outer loops.
	 for (k = i+1; k < j-HLEN-1; k++) {
	    for (l = k+HLEN+1; l < j; l++) {
	       d1 = k-i; d2 = l-k-1; d3 = j-l;	
               cursc = mx[dpP][l-1][d2] + pr->transitions[TNI]
		 + pr->loop[lpindex(ilplen(i, k-1, l+1,j))] 
		 + pr->emitloop[i] - pr->emitloop[k] 
		 + pr->emitloop[l+1] - pr->emitloop[j+1]
	         + pr->pairs[rna[k]][rna[l]];
	       if (cursc > max) { 
		  max = cursc; 
		  if (dist(k,l) == 5)
		    printf("max %d i %d k %d l %d j %d \n", max, i, k, l, j);
	       }
            } 
          } 
	  * */

	 /* N^3 internal loops 
	  * */
	 for (r=HLEN+2; ((r+1) < d); r++) {
	    sc = mx[dpP][i+r-1][r-2] + pr->pairs[rna[i+1]][rna[i+r]] 
		- pr->emitloop[i+1] + pr->emitloop[i+r+1]; 
	    if (r == (d-2)) Ibest[r] = sc;  
	    else if (sc > Ibest[r]) Ibest[r] = sc; 
	 }

	 for (L = 2; ((L+HLEN+1 < d) && (L < MAXLOOP)); L++) {
	    r = d-L;
	    sc = pr->loop[lpindex(L)] + Ibest[r] + pr->transitions[TNI] + 
	       pr->emitloop[i] - pr->emitloop[j+1];
	    if (sc > max) max = sc; 
	 }
	 mx[dpN][j][d] = cursc;

	 /* P -> aPa' | aNa' */
	 cursc = -BIGFLOAT;
	 /* Stacking! Can't be in P state at edges!  */
	 if (ss[i] == j) {
	    if ((i == 0) || (j == len-1)) { stackvalue = -BIGFLOAT; } 
	    else { stackvalue = pr->stack[idx(rna[i-1],rna[j+1])][rna[i]][rna[j]]; }

	    if ((d-1 > HLEN) && (d-2 > 0)) { 
	       cursc = mx[dpP][j-1][d-2] + stackvalue + pr->transitions[TPP]; 
	       cursc = DLogsum(mx[dpN][j-1][d-2] + stackvalue + pr->transitions[TPN], cursc); 
	    } 
	 }
	 mx[dpP][j][d] = cursc; 

      }
   }
}

#endif 
