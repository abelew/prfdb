/* plusone_main.c 
 * RDD, Thu Dec  4 19:28:05 CST 2003
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"

int simple_grammars(char *rna, int len, char *name, 
      MODEL *nusmodel, OPTS *settings);
void dcG(int i);
extern struct trace_s * CYK(char *rna, int len, int grammar, INTMOD *scmodel, 
      OPTS *output, int *ret_score);

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-v            : verbose output \n\
-d            : debugging output \n\
";
static char usage[]  = "Usage: pocheck [-options] <seqfile in>\n";

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;

  /* ReadSeq variables */
  SQFILE *sqfp; SQINFO sqinfo;
  int sformat;
  char *rna; 

  /* Models info */
  MODEL nusmodel;
  int flag;

  if (!(ProcessOpts(&settings, &optid, argc, argv, usage, "", optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  if (argc - optid < 1)
    Die("Incorrect number of command line arguments.\n%s\n%s\n", usage, optsline);

  SetUpNusScoring(&(nusmodel.scores)); 
  nusmodel.grammar = settings.grammar;
  settings.useprob = FALSE; nusmodel.probabilistic = FALSE;

  /* Digitize Sequence Setup*/
  SetAlphabet(hmmNUCLEIC);
  if (settings.minloop >= 0) HLEN = settings.minloop;
  if (settings.debugg) PrintOptions(settings.ofp, &settings);
  if (settings.parameterout) PrintModel(settings.ofp, &nusmodel);

  flag = FALSE;
  while (!(argc - optid < 1)) {
    /* Read input file into RNA array and filter for non-RNA residues */
    if ((sqfp = SeqfileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL) 
      Die("Failed to open sequence file %s\n%s\n", argv[optid], usage);

    while (ReadSeq(sqfp, sformat, &rna, &sqinfo)) {
      ToRNA(rna);

      if (settings.verbose) fprintf(settings.ofp, "Sequence %s (file: %s) :\n", 
	    sqinfo.name, argv[optid]);

      flag = simple_grammars(rna, sqinfo.len, sqinfo.name, &nusmodel, &settings);

      FreeSequence(rna, &sqinfo);
    }
    SeqfileClose(sqfp);
    optid ++;
  }
  if (flag == FALSE) printf("All plus one tests passed!\n");
  return 1;
}

int
simple_grammars(char *rna, int len, char *name, MODEL *nusmodel, OPTS *settings)
{
  int score[7];
  int sc, i, flag;
  int uynscore, ry3score;	/* no lone pair grammars */
  struct trace_s *trc;

  flag = FALSE;
  for (HLEN = 0; HLEN < 3; HLEN++) {	/* Minimum loop lengths */ 
     if ((settings->verbose) || (settings->debugg)) 
	printf("HLEN is %d\n", HLEN);
     for (i = 0; i < 6; i++) { score[i] = -1; }
     uynscore = ry3score = 0;

     settings->grammar = NUS; sc = -1;
     trc = (struct trace_s *)CYK(rna, len, settings->grammar, 
	   &(nusmodel->scores), settings, &sc);
     if (trc != NULL) { score[0] = sc; } else { score[0] = -1; }
     FreeTrace(trc);

     settings->grammar = RUN; sc = -1;
     trc = (struct trace_s *)CYK(rna, len, settings->grammar, 
	   &(nusmodel->scores), settings, &sc);
     if (trc != NULL) { score[1] = sc; } else { score[1] = -1; }
     FreeTrace(trc);

     settings->grammar = IVO; sc = -1;
     trc = (struct trace_s *)CYK(rna, len, settings->grammar, 
	   &(nusmodel->scores), settings, &sc);
     if (trc != NULL) { score[2] = sc; } else { score[2] = -1; }
     FreeTrace(trc);

     settings->grammar = YRN; sc = -1;
     trc = (struct trace_s *)CYK(rna, len, settings->grammar, 
	   &(nusmodel->scores), settings, &sc);
     if (trc != NULL) { score[6] = sc; } else { score[6] = -1; }
     FreeTrace(trc);

     if (HLEN > 0) {		/* these three have a min loop len of 1 */
	settings->grammar = UNA; sc = -1;
	trc = (struct trace_s *)CYK(rna, len, settings->grammar, 
	      &(nusmodel->scores), settings, &sc);
	if (trc != NULL) { score[3] = sc; } else { score[3] = -1; }
	FreeTrace(trc);

        settings->grammar = UYN; sc = -1;
	trc = (struct trace_s *)CYK(rna, len, settings->grammar, 
	      &(nusmodel->scores), settings, &sc);
	if (trc != NULL) { uynscore = sc; } else { uynscore = -1; }
	FreeTrace(trc);

        settings->grammar = RY3; sc = -1;
	trc = (struct trace_s *)CYK(rna, len, settings->grammar, 
	      &(nusmodel->scores), settings, &sc);
	if (trc != NULL) { ry3score = sc; } else { ry3score = -1; }
	FreeTrace(trc);
    
     }
     if (HLEN > 1) { 		/* BJK has a min loop len of 2 */
	settings->grammar = BJK; sc = -1;
	trc = (struct trace_s *)CYK(rna, len, settings->grammar, 
	      &(nusmodel->scores), settings, &sc);
	if (trc != NULL) { score[4] = sc; } else { score[4] = -1; }
	FreeTrace(trc);

	settings->grammar = BK2; sc = -1;
	trc = (struct trace_s *)CYK(rna, len, settings->grammar, 
	      &(nusmodel->scores), settings, &sc);
	if (trc != NULL) { score[5] = sc; } else { score[5] = -1; }
	FreeTrace(trc);
 }

     /* Check that the lone pair grammars give the same score --
      * the additional constraint of no lone pairs means these may not
      * give the same score as those without this constraint.
      * */
     if (uynscore != ry3score) {
        flag = TRUE;
	fprintf(settings->ofp, 
		    "PLUS ONE CHECK FAILED for lone pair grammars on min HLEN %d for ", HLEN);
	fprintf(settings->ofp, 
		    "UYN: %d RY3: %d\n", uynscore, ry3score);
     }
     /* Check that the rest all give the same score */
     sc = score[0];
     for (i = 0; i < 7; i++) {
	if (score[i] != -1) {
	   if (score[i] != sc) {
	      flag = TRUE;
	      fprintf(settings->ofp, 
		    "PLUS ONE CHECK FAILED for %s on min HLEN %d for ",
		    name, HLEN);
	      dcG(i);
	   }
	   /* printf("%d %d \n", i , score[i]); */
	} else {
	   if (settings->verbose) {
	      printf("Trace failed for %s using ", name);
	      dcG(i);
	   }
	}
     }
  }
  return flag;
}

void
dcG(int i)
{
   if (i == 0) printf("NUS\n");
   if (i == 1) printf("RUN\n");
   if (i == 2) printf("IVO\n");
   if (i == 3) printf("UNA\n");
   if (i == 4) printf("BJK\n");
   if (i == 5) printf("BK2\n");
   if (i == 6) printf("YRN\n");
}
	
