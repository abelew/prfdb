/* gr_una.c
 * RDD, Fri Oct 12 13:56:34 2001
 *
 * Implementations of the grammar specific functions for UNA
 *
 * Thu Aug 23 17:19:01 2001 
 * Unamb.  :  S -> aSa' | aL | Rb | LS 		(UNA)
 *            L -> aSa' | aL
 *            R -> Rb | end
 *
 * These implementations assume a digitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"

/*************************  CYK ********************************/
/* Function: cykInitUNA
 * Date:     RDD, Fri Oct 12 13:56:34 2001 [St. Louis]
 *
 * Purpose:  Initialize CYK fill matrix for UNA grammar
 * Assumption: Fill matrix already allocated
 *
 * Args:     
 *	mx	fill matrix (integer log odds form)
 *	model 	parameters (integer log form or as scores)
 *	rna	sequence (digitized)
 *	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cykInitUNA(int ***mx, INTMOD *model, char *rna, int len)
{
  int j, d;

  for (d = 0; d <= len; d++) {
     for (j = (d > 0? d-1: d); j < len; j++) {
	mx[dpS][j][d] = -BIGINT;	/* Prohibited */
	mx[dpL][j][d] = -BIGINT;
	mx[dpR][j][d] = model->transitions[TRE];	/* R -> end */
     } /* end for j */
  } /* end for i */
}

/* Function: cykFillUNA
 * Date:     Fri Oct 12 09:10:06 CDT 2001
 *
 * Purpose:  Fills CYK matrix for UNA grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	sc	parameters 
 *		(integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
cykFillUNA (int ***mx, INTMOD *pr, char *rna, int len)
{
  int d, i, j, k;       /* Loop indicies */
  int max;              /* Maximum value seen so far */
  int cursc, cursc2;    /* Current score */

  /* Recursion */
  for (d = 1; d <= len; d++) {
     for (j = d-1; j < len; j++) {
	i = j - d + 1; max = -BIGINT;

      /* S -> aL */
      cursc = mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL];
      if (cursc > max) max = cursc; 

      /* S -> Rb */
      if (j == 0) {	/* Special case of one nucleotide */
        cursc = mx[dpR][0][d-1] + pr->singles[rna[j]] + pr->transitions[TSR];
      } else {
        cursc = mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR];
      }
      if (cursc > max) max = cursc;

      /* S -> LS */
        for (k = i; k < j; k++) {
          cursc = mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] 
	     + pr->transitions[TSB];
          if (cursc > max) max = cursc;
        }

      /* S -> aSb */
      if ((j > 0) && (d > 1)) {
        cursc = mx[dpS][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
	      + pr->transitions[TSS];
      } else {
	 cursc = -BIGINT;
      }
      if ((cursc > max) && (lplen(i,j) >= HLEN)) max = cursc;

      /* S -> aSb | aL | Ra | LS */
      mx[dpS][j][d] = max;

      /* L -> aSb | aL */
      cursc = -BIGINT;
      if ((j > 0) && (lplen(i,j) >= HLEN)) {
        cursc = mx[dpS][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
	 + pr->transitions[TLS];
      } 
      cursc2 = mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TLL];
      if (cursc > cursc2) {
	 mx[dpL][j][d] = cursc;
      } else {
	 mx[dpL][j][d] = cursc2;
      }

      /* R -> Rb | end */
      if (j == 0) {	/* Special case: first nucleotide */
        cursc = mx[dpR][0][d-1] + pr->singles[rna[j]] + pr->transitions[TRR];
      } else {
        cursc = mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TRR];
      }
      mx[dpR][j][d] = cursc;

    } /* End for loop */
  } /* End foreach n */
}

/* Function: cykTraceUNA 
 * Date:     RDD, Mon Aug 27 13:44:16 2001 [St. Louis]
 *
 * Purpose:  Build traceback tree for scoring Nussinov 
 *
 * Args:
 *	mx	matrix in which to calculate cyk
 *	pr	parameters in integer form
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns: traceback tree
 */
struct trace_s *
cykTraceUNA (int ***mx, INTMOD *pr, char *rna, int len)
{
  int d, i, j, k, mtx;   /* Indices */
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (len -1), TRE));

  /* Repeat until stack is empty */
  while (curr = PopTracestack(stack)) {
    /* Set i and j from items in stack */
    i = curr->emitl; j = curr->emitr; mtx = curr->nonterminal;
    d = j - i + 1;

    /* S -> aSb | aL | Rb | LS | end */
    if (i > j) { 		/* S(R) -> end */
      curr->emitl = -1; curr->emitr = -1;
      curr->transition = TSE; curr->nonterminal = dpE; 
      continue;
    } else if (mtx == dpS) {
		/* Single nt length seq's i == j */
      if ((i == j) || 	
         ((mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR]) 
	  			== mx[dpS][j][d])) {
        curr->emitl = -1; curr->transition = TSR; 
        PushTracestack(stack, AttachTrace (curr, dpR, i, j-1, TRE));
      } else if ((mx[dpL][j][d-1] + pr->singles[rna[i]] 
	       	+ pr->transitions[TSL]) == mx[dpS][j][d]) {
        curr->emitr = -1; curr->transition = TSL; 
        PushTracestack(stack, AttachTrace (curr, dpL, i+1, j, TRE));
      } else if ((lplen(i,j) >= HLEN) && ((mx[dpS][j-1][d-2] 
		  + pr->pairs[rna[i]][rna[j]] 
	       + pr->transitions[TSS]) == mx[dpS][j][d])) {
        curr->transition = TSS;
        PushTracestack(stack, AttachTrace (curr, dpS, i+1, j-1, TRE));
      } else {
          for (k = i+1; k < j; k++) {
            if ((mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)]
		     + pr->transitions[TSB]) == mx[dpS][j][d]) {
	      curr->emitl = -1; curr->emitr = -1; curr->transition = TSB;
              PushTracestack(stack, AttachTrace (curr, dpS, k+1, j, TRE));
              PushTracestack(stack, AttachTrace (curr, dpL, i, k, TRE));
	      k = j;	/* Short circuit */
            } /* End if */
          } /* End for (bifurcation points) */
      } /* end if (S-> aSb | aL | Rb | LS) */
    } else if (mtx == dpL) {
      if ((mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TLL]) 
	    		== mx[dpL][j][d]) {
        curr->emitr = -1; curr->transition = TLL;
        PushTracestack(stack, AttachTrace (curr, dpL, i+1, j, TRE));
      } else {
        curr->transition = TLS;
        PushTracestack(stack, AttachTrace (curr, dpS, i+1, j-1, TRE));
      }
    } else if (mtx == dpR) {
      if (i == j) { /* R -> end */
        curr->emitl = -1; curr->emitr = i; curr->transition = TRR; 	
        PushTracestack(stack, AttachTrace (curr, dpR, i, j-1, TRE));
      }
      else if ((mx[dpR][j-1][d-1] + pr->singles[rna[j]] 
	       + pr->transitions[TRR]) == mx[dpR][j][d]) {
        curr->emitl = -1; curr->transition = TRR;
        PushTracestack(stack, AttachTrace (curr, dpR, i, j-1, TRE));
      } 
    } else {		
	printf("ERROR!! Nonterminal %d unknown in traceback!\n", mtx);
    } /* End if dpS, dpL or dpR */
  } /* end while stack not empty*/
  FreeTracestack(stack);
  return parsetree;
}

/***************************** TRAIN ********************************/
/* Function: khs2traceUNA
 * Date:     RDD, Tue Apr 23 09:39:16 2002 [St. Louis]
 *
 * Purpose: Convert KHS to traceback tree properly 
 * 	labeled for UNA grammar.
 *
 * Args:     
 *	dolist  Traceback tree to build from KHS	
 *	ct	KHS info represented as ct format
 */
int
khs2traceUNA(struct tracestack_s *dolist, int *ct)
{
  struct trace_s      *cur;
  struct trace_s      *tr;
  struct trace_s      *prv, *nxt;
  char left; char right;
  int  i,j, mid, error;

  error = FALSE;

  while ((cur = PopTracestack(dolist)) != NULL) {
    i = cur->emitl;           /* 0..len-1 */
    j = cur->emitr;           /* 0..len-1 */

    if (i > j) {
      cur->transition = TRE; cur->emitl = -1; cur->emitr = -1; cur->nonterminal = dpE;
    } else if (ct[j] == -1) {   /* j unpaired: single strand right */
      /* In region of right single stranded */
      if (cur->nonterminal == dpR) {
        cur->transition = TRR; cur->emitl = -1;
        PushTracestack(dolist, AttachTrace(cur, dpR, i, j-1, TRE));
      } else {
        mid = find_split(ct, i, j);
        if (mid  < 0) {   /* no pairs, open right string */
          cur->transition = TSR; cur->emitl = -1;
          PushTracestack(dolist, AttachTrace(cur, dpR, i, j-1, TRE));
        } else {        /* pairs exist, must bifurcate */
          cur->transition = TSB;
          cur->emitl = -1; cur->emitr = -1;
          PushTracestack(dolist, AttachTrace(cur, dpS, mid+1, j, TRE));
          PushTracestack(dolist, AttachTrace(cur, dpL, i, mid, TRE));
        }
      } /* end what kind of right state is this? */
    } else if (ct[i] == -1) {   /* i unpaired; single strand left */
      if (cur->nonterminal == dpL) {
        cur->transition = TLL; cur->emitr = -1;
        PushTracestack(dolist, AttachTrace(cur, dpL, i+1, j, TRE));
      } else {		/* Move to L from S */
        mid = find_split(ct, i, j);
        if (mid < j) {		/* Must bifurcate */
          cur->transition = TSB;
          cur->emitl = -1; cur->emitr = -1;
          PushTracestack(dolist, AttachTrace(cur, dpS, mid+1, j, TRE));
          PushTracestack(dolist, AttachTrace(cur, dpL, i, mid, TRE));
        } else {		/* Straightforward S->L */
          cur->transition = TSL; cur->emitr = -1;
          PushTracestack(dolist, AttachTrace(cur, dpL, i+1, j, TRE));
        }
      }
    } else if (ct[i] == j) {    /* i,j paired to each other */
      if (i+1 == j) { error = TRUE; } /* This grammar can't handle zero length loops */ 
      if (cur->nonterminal == dpL) {
        cur->transition = TLS;
      } else {
        cur->transition = TSS;
      }
      PushTracestack(dolist, AttachTrace(cur, dpS, i+1, j-1, TRE));
    } else {            /* i,j paired but not to each other */
      cur->transition = TSB;
      cur->emitl = -1; cur->emitr = -1;
      mid = ct[i];      /* Always do left first */
      PushTracestack(dolist, AttachTrace(cur, dpS, mid+1, j, TRE));
      PushTracestack(dolist, AttachTrace(cur, dpL, i, mid, TRE));
    }
  }   /* while something's on dolist stack */
  if (error) return 0;	/* We do this via the error switch so we can ignore 
			   and still return an approximately correct traceback */
  return 1;
}

/*************************  Inside ********************************/
/* Function: insideInitUNA
 * Date:     RDD, Thu Jan 30 11:11:07 CST 2003
 *
 * Purpose:  Initialize Inside fill matrix for UNA grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:     
 *	mx	where to store inside (matrix to fill)
 *	model	integer log form of parameters
 *	rna	Sequence to be analyzed
 * 	len	sequence length
 *
 * Notes:  To initialize the "lower" half of the matrix:
 *   \alpha_{nonterminal}(i+1, i) = 1 for nontermianls with \epsilon
 *   				  = 0 otherwise
 * To initalize the diagonal (i == j) we calculate the inside
 *  	variable (\alpha) for each nontermianl type assuming
 *  	the values above for all \alpha_{nontemrainl}(i,j) where
 *  	i > j.
 *
 * Returns:  -- void -- 
 */
void
insideInitUNA(double ***mx, PROBMOD *model, char *rna, int len)
{
  int d,j;

  for (d = 0; d <= len; d++) {
     for (j = d; j < len; j++) {
	mx[dpS][j][d] = -BIGFLOAT;
	mx[dpL][j][d] = -BIGFLOAT;
	mx[dpR][j][d] = model->transitions[TRE];
     } /* end for j */
     if (d > 0) {
	mx[dpS][d-1][d] = -BIGFLOAT;
	mx[dpL][d-1][d] = -BIGFLOAT;
	mx[dpR][d-1][d] = model->transitions[TRE];	
     }
  } /* end for d */
}

/* Function: insideFillUNA
 * Date:     RDD, Thu Jan 30 11:19:53 CST 2003
 *
 * Purpose:  Fills inside matrix for UNA grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	sc	parameters 
 *		(integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
insideFillUNA(double ***mx, PROBMOD *pr, char *rna, int len)
{
  int d, i, j, k;       /* Loop indicies */
  double cursc;		/* Current score */
  int debug;	

  debug = FALSE;

  /* Recursion */
  for (d = 1; d <= len; d++) {
     for (j = d-1; j < len; j++) {
	i = j - d + 1; 

	/* S -> aL | Ra */
	if (j == 0) {
	  cursc = DLogsum(mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL],
	      mx[dpR][0][d-1] + pr->singles[rna[j]] + pr->transitions[TSR]);
	} else {
	  cursc = DLogsum(mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL],
	      mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR]);
	}

	/* S -> LS in Unambiguous grammars (UNA, UYN) */
	for (k = i; k < j; k++) {
	   cursc = DLogsum(mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] 
		 + pr->transitions[TSB], cursc);
	}

	if ((abs(i-j) > HLEN) && (j > 0)) {	/* S -> aSa' */
	   if (debug) printf("Adding a pair at (%d, %d)\n", i,j ); 
	   cursc = DLogsum(mx[dpS][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
		 + pr->transitions[TSS], cursc);
	}

	/* S -> aSb | aR | Lb | LS */
	mx[dpS][j][d] = cursc;
	if (debug) 
	   printf("S[%d][%d] %f (%f)\n", i, j, mx[dpS][j][d], asProb(mx[dpS][j][d]));

	/* L -> aSb | aL */
	if (d <= 2) {
	  mx[dpL][j][d] = -BIGFLOAT;
	} else {
	  mx[dpL][j][d] = DLogsum(mx[dpS][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
	      + pr->transitions[TLS], mx[dpL][j][d-1] + pr->singles[rna[i]] 
	      + pr->transitions[TLL]);
	}

	if (debug) 
	   printf("L[%d][%d] %f (%f)\n", i, j, mx[dpL][j][d], asProb(mx[dpL][j][d]));

	/* R -> Rb | end */
	if (j == 0) {
	  mx[dpR][j][d] = mx[dpR][0][d-1] + pr->singles[rna[j]] + pr->transitions[TRR];
	} else {
	  mx[dpR][j][d] = mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TRR];
	}

	if (debug) 
	   printf("R[%d][%d] %f (%f)\n", i, j, mx[dpR][j][d], asProb(mx[dpR][j][d]));

     } /* End for loop */
  } /* End foreach n */
}

/******************* Suboptimals ******************************/
/* Function: insideTraceUNA
 * Date:     Thu Oct 24 16:11:26 CDT 2002 [St Louis]
 *
 * Purpose:  Build a traceback tree for Inside  (sampled)
 * Assumption: Fill matrix already allocated, initialized, and filled
 *
 * Args:
 *	mx	matrix containing inside values 
 *	pr	parameters in integer form
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns: traceback tree
 */
struct trace_s *
insideTraceUNA(double ***mx, PROBMOD *pr, char *rna, int len)
{
  int d, i, j, k, mtx;   /* Indices */
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */
  double *ruleprob;
  double cursc, denom, randnum;
  int indx;

  ruleprob = (double *) malloc (sizeof(double) * (len + 4));

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (len -1), TSE));

  /* Repeat until stack is empty */
  while (curr = PopTracestack(stack)) {
     /* Generate a random number */
     randnum = asLog((float) rand() / RAND_MAX);

     /* Set i and j from items in stack */
     i = curr->emitl; j = curr->emitr; mtx = curr->nonterminal;
     d = j-i+1;

     /* S -> end */
     if (i > j) { 		/* S -> end */
	curr->emitl = -1; curr->emitr = -1;
	curr->transition = TSE; curr->nonterminal = dpR; 
	continue;
     } else { 
	/* Calculate the score for each possible move from this mtx[i][j] */
	if (mtx == dpS) { /* S -> aSa' | aL | Rb | LS */
	   /* S -> aSa' */
	   if ((abs(i-j) > HLEN) && (j > 0)) {
	      cursc = mx[dpS][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TSS];
	   } else {
	      cursc = -BIGFLOAT;
	   }
	   ruleprob[0] = cursc; denom = cursc;

	   /* S -> aL */
	   if (i < len-1) {
	     cursc = mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL];	
	   } else {
	     cursc = -BIGFLOAT;
	   }
	   ruleprob[1] = cursc; denom = ILogsum(denom, cursc);

	   /* S -> Ra */
	   if (j > 0) {
	     cursc = mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TSR];	
	   } else {
	      cursc = -BIGFLOAT;
	   }
	   ruleprob[2] = cursc; denom = ILogsum(denom, cursc);

	   /* S -> LS */
	   indx = 3; cursc = -BIGFLOAT; 		
	   for (k = i; k < j; k++) {
	      cursc = mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] + pr->transitions[TSB];
	      ruleprob[indx++] = cursc;
	      denom = ILogsum(denom, cursc);
	   }
	} else if (mtx == dpL) { /* L -> aSa' | aL */
	   /* L -> aSa' */
	   if (abs(i-j) > HLEN) {
	      cursc = mx[dpS][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
		 + pr->transitions[TLS];
	   } else {
	      cursc = -BIGFLOAT;
	   }
	   ruleprob[0] = cursc; denom = cursc;

	   /* L -> aL */
	   if (i < len-1) {
	      cursc = mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TLL];
	   } else {
	      cursc = -BIGFLOAT;
	   }
	   ruleprob[1] = cursc; denom = ILogsum(denom, cursc);
	   indx = 2;

	} else { /* R -> Rb | end */
	   /* S -> Ra */
	   if (j > 0) {
	      cursc = mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TRR];
	   } else {
	      cursc = -BIGFLOAT;
	   }
	   ruleprob[0] = cursc; denom = cursc;
           indx = 1;
	}

	/* Normalize the scores to probs */
	for (k = 0; k < indx; k++) {		
	   ruleprob[k] = ruleprob[k] - denom;
	   if (k > 0) {		/* Convert to intervals */
	      ruleprob[k] = ILogsum(ruleprob[k], ruleprob[k-1]);
	   }
	}

	/* Pick a rule based the interval of each rule */
	if (randnum < ruleprob[0]) {
	   if (mtx == dpS){
	      curr->transition = TSS;
	      PushTracestack(stack, AttachTrace (curr, dpS, i+1, j-1, TSE));
	   } else if (mtx == dpL) {
	      curr->transition = TLS;
	      PushTracestack(stack, AttachTrace (curr, dpS, i+1, j-1, TSE));
	   } else {
	      curr->emitl = -1; curr->transition = TRR; 
	      PushTracestack(stack, AttachTrace (curr, dpR, i, j-1, TSE));
	   }
	} else if (randnum < ruleprob[1]) {
	   if (mtx == dpS) {
	      curr->emitr = -1; curr->transition = TSL; 
	      PushTracestack(stack, AttachTrace (curr, dpL, i+1, j, TSE));
	   } else {
	      curr->emitr = -1; curr->transition = TLL; 
	      PushTracestack(stack, AttachTrace (curr, dpL, i+1, j, TSE));
	   }
	} else  if (randnum < ruleprob[2]) {
	   curr->emitl = -1; curr->transition = TSR; 
	   PushTracestack(stack, AttachTrace (curr, dpR, i, j-1, TSE));
	} else {	
	   for (mtx = 3; mtx < indx; mtx++) {
	      k = i + (mtx - 3);			/* Coordinate of this bif */
	      if (randnum < ruleprob[mtx]) {
		 curr->emitl = -1; curr->emitr = -1; curr->transition = TSB;
		 PushTracestack(stack, AttachTrace (curr, dpS, k+1, j, TSE));
		 PushTracestack(stack, AttachTrace (curr, dpL, i, k, TSE));
		 mtx = indx;	/* Break loop */
	      }
	   } /* Find which k of bif state */
	} /* End else is bif state */
     } /* End i <= j */
  }
  return parsetree;
}


/******************* conditional Inside ******************************/
/* Function: cinsInitUNA
 * Date:     Mon Thu Jan 30 11:26:09 CST 2003 [St Louis]
 *
 * Purpose:  Initialize Inside fill matrix for UNA grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:     
 *	mx	where to store inside (matrix to fill)
 *	model	integer log form of parameters
 *	rna	Sequence to be analyzed
 * 	len	sequence length
 *
 * Notes:  To initialize the "lower" half of the matrix:
 *   \alpha_{nonterminal}(i+1, i) = 1 for nontermianls with \epsilon
 *   				  = 0 otherwise
 * To initalize the diagonal (i == j) we calculate the inside
 *  	variable (\alpha) for each nontermianl type assuming
 *  	the values above for all \alpha_{nontemrainl}(i,j) where
 *  	i > j.
 *
 * Returns:  -- void -- 
 */
void
cinsInitUNA(double ***mx, PROBMOD *model, char *rna, int len, int *ss)
{
  int d,j;

  for (d = 0; d <= len; d++) {
     for (j = d; j < len; j++) {
	mx[dpS][j][d] = -BIGFLOAT;
	mx[dpL][j][d] = -BIGFLOAT;
	mx[dpR][j][d] = model->transitions[TRE];
     } /* end for j */
     if (d > 0) {
	mx[dpS][d-1][d] = -BIGFLOAT;
	mx[dpL][d-1][d] = -BIGFLOAT;
	mx[dpR][d-1][d] = model->transitions[TRE];	
     }
  } 
}

/* Function: cinsFillUNA
 * Date:     Thu Jan 30 11:27:12 CST 2003 [St Louis]
 *
 * Purpose:  Fills inside matrix for UNA grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	sc	parameters 
 *		(integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Returns:  void 
 */
void
cinsFillUNA(double ***mx, PROBMOD *pr, char *rna, int len, int *ss)
{
  int d, i, j, k;       /* Loop indicies */
  double cursc;		/* Current score */
  int debug;	

  debug = FALSE;

  /* Recursion */
  for (d = 1; d <= len; d++) {
     for (j = d-1; j < len; j++) {
	i = j - d + 1; 

	cursc = -BIGFLOAT;
	/* S -> aL | Ra */
	if (ss[i] == -1) {
	  cursc = mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSL];
	  if (debug) printf("aL %f: L %f i %f TSL %f \n", cursc,
	  	mx[dpL][j][d-1], pr->singles[rna[i]], pr->transitions[TSL]);
	}
	if (ss[j] == -1) {
	   if (j > 0) {
	      cursc = DLogsum(cursc, mx[dpR][j-1][d-1] + pr->singles[rna[j]] 
		    + pr->transitions[TSR]);
	   } else {
	      cursc = DLogsum(cursc, mx[dpR][0][d-1] + pr->singles[rna[j]] 
		    + pr->transitions[TSR]);
	   }
	   if (debug) printf("aR %f: R %f j %f TSR %f\n", cursc,
		 mx[dpR][j-1][d-1], pr->singles[rna[j]], pr->transitions[TSR]);
	}

	/* S -> LS */
	for (k = i+1; k < j; k++) {
	   cursc = DLogsum(mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)] 
		 + pr->transitions[TSB], cursc);
	  if (debug) printf("LS %f: L %f S %f TSS %f \n", cursc,
		 mx[dpL][k][dist(i,k)], mx[dpS][j][dist(k+1,j)],
		 pr->transitions[TSB] );
	}

	if ((abs(i-j) > HLEN) && (ss[i] == j)) {	/* S -> aSa' */
	   cursc = DLogsum(mx[dpS][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
		 + pr->transitions[TSS], cursc);
	  if (debug) printf("aSa %f\n", cursc);
	}

	/* S -> aSb | aR | Lb | LS */
	mx[dpS][j][d] = cursc;
	if (debug) 
	   printf("S[%d][%d] %f (%f)\n", i,j,mx[dpS][j][d], asProb(mx[dpS][j][d]));

	/* L -> aSb | aL */
	if (ss[i] == -1) {
	   mx[dpL][j][d] = mx[dpL][j][d-1] + pr->singles[rna[i]] + pr->transitions[TLL];
	} else if (ss[i] == j) {
	   mx[dpL][j][d] = mx[dpS][j-1][d-2] + pr->pairs[rna[i]][rna[j]] 
	      + pr->transitions[TLS];
	} else {
	   mx[dpL][j][d] = -BIGFLOAT;
	}
	if (debug) 
	   printf("L[%d][%d] %f (%f)\n", i,j,mx[dpL][j][d], asProb(mx[dpL][j][d]));

	/* R -> Rb | end */
	if (ss[j] == -1) {
	   if (j > 0) {
	     mx[dpR][j][d] = mx[dpR][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TRR];
	   } else {
	     mx[dpR][j][d] = mx[dpR][0][d-1] + pr->singles[rna[j]] + pr->transitions[TRR];
	   }
	} else {
	   mx[dpR][j][d] = -BIGFLOAT;
	}

	if (debug) 
	   printf("R[%d][%d] %f (%f)\n", i, j, mx[dpR][j][d], asProb(mx[dpR][j][d]));

     } /* End for loop */
  } /* End foreach n */
}

/*************************  Outside ********************************/
/* Function: outsideInitMxUNA
 * Date:     Thu Jan 30 11:32:26 CST 2003 [St Louis]
 *
 * Purpose:  Initialize Inside fill matrix for UNA grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:     
 *	mxo	where to store outside (matrix to fill)
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
outsideInitUNA(double ***mxo, int len)
{
   int d, j;

   for (d = 0; d <= len; d++) {
      for (j = d; j < len; j++) {
	 mxo[dpS][j][d] = -BIGFLOAT;
	 mxo[dpL][j][d] = -BIGFLOAT;
	 mxo[dpR][j][d] = -BIGFLOAT;
      } /* end for j */
      if (d > 0) {
	 mxo[dpS][d-1][d] = -BIGFLOAT;
	 mxo[dpL][d-1][d] = -BIGFLOAT;
	 mxo[dpR][d-1][d] = -BIGFLOAT;
      }
   }
   mxo[dpS][len-1][len] = 0;
}

/* Function: outsideFillUNA
 * Date:  Thu Jan 30 11:33:14 CST 2003 [St Louis]
 * 
 * Purpose:  Fills outside matrix for UNA grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 * 	mxo	where to store outside (matrix to fill)
 *	mx	results from inside
 *	model	integer log form of parameters
 *	rna	Sequence to be analyzed
 * 	len	sequence length
 *      grammar which grammar to utilize
 *
 * Returns:  void 
 */
void
outsideFillUNA(double ***mxo, double ***mx, PROBMOD *pr, char *rna, int len)
{
   int d, i, j, k;
   double cursc;

   for (d = (len-1); d > 0; d--) {
      for (j = (len-1); j > d-2; j--) {
	 i = j - d + 1; 

	 /* \beta^R(i,j) */
	 if (j < len-1) {
	   mxo[dpR][j][d] = DLogsum(mxo[dpS][j+1][d+1] + pr->transitions[TSR] 
		 + pr->singles[rna[j+1]], mxo[dpR][j+1][d+1] + pr->transitions[TRR] 
		 + pr->singles[rna[j+1]]);
	 } else {	/* \beta^R(i,len-1) */
	    mxo[dpR][j][d] = -BIGFLOAT;
	 }

	 /* \beta^L(i,j) */
	 if (i > 0) {
	    cursc = DLogsum(mxo[dpS][j][d+1] + pr->transitions[TSL] 
		  + pr->singles[rna[i-1]], mxo[dpL][j][d+1] + pr->transitions[TLL] 
		  + pr->singles[rna[i-1]]);
	 } else {
	   cursc = -BIGFLOAT;	/* At edge of matrix and can't be in L */
	 }
	 for (k = j+1; k < len; k++) {
	    cursc = DLogsum(cursc, 
	       mxo[dpS][k][dist(i,k)] + pr->transitions[TSB] + mx[dpS][k][dist(j+1,k)]);
	 }
	 mxo[dpL][j][d] = cursc;

	 /* \beta^S(i,j) */
	 if ((i > 0) && (j < len-1)) {
	    cursc = DLogsum(mxo[dpS][j+1][d+2] + pr->transitions[TSS] 
		  + pr->pairs[rna[i-1]][rna[j+1]], mxo[dpL][j+1][d+2] 
		  + pr->transitions[TLS] + pr->pairs[rna[i-1]][rna[j+1]]);
	 } else if ((i == 0) && (j == len-1)) {
	    cursc = 0;  /*By def: beta_S(1,LEN) = 1.0 */
	 } else {
	    cursc = -BIGFLOAT; 
	 }
	 for (k = 0; k < i; k++) {
	    cursc = DLogsum(cursc, mxo[dpS][j][dist(k,j)] + pr->transitions[TSB]
		  + mx[dpL][i-1][dist(k,i-1)]);
	 }
	 mxo[dpS][j][d] = cursc;
      }
   }
}

/******************* conditional Outside ********************************/

/* Function: coutFillUNA
 * Date:  Thu Jan 30 11:34:32 CST 2003 [St Louis]
 * 
 * Purpose:  Fills conditional outside matrix for UNA grammar
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 * 	mxo	where to store outside (matrix to fill)
 *	mx	results from inside
 *	model	integer log form of parameters
 *	rna	Sequence to be analyzed
 * 	len	sequence length
 * 	ss	secondary structure on which to condition
 *
 * Returns:  void 
 */
void
coutFillUNA(double ***mxo, double ***mx, PROBMOD *pr, char *rna, int len, int *ss)
{
   int d, i, j, k;
   double cursc;
   int debug = FALSE;

   if (debug) printf("Len %d\n", len);

   for (d = (len-1); d > 0; d--) {
      for (j = (len-1); j > d-2; j--) {
	 i = j - d + 1;

	 /* \beta^R(i,j) */
	 mxo[dpR][j][d] = -BIGFLOAT;
	 if (j < len-1) {
	    if (ss[j+1] == -1) {
	       mxo[dpR][j][d] = DLogsum(mxo[dpS][j+1][d+1] + pr->transitions[TSR] 
		     + pr->singles[rna[j+1]], mxo[dpR][j+1][d+1] + pr->transitions[TRR] 
		     + pr->singles[rna[j+1]]);
	    }
	 }
	 if (debug) printf("beta R %d %d: %f \n", i, j, mxo[dpR][j][d]);  fflush(stdout);

	 /* \beta^L(i,j) */
	 cursc = -BIGFLOAT;
	 if (i > 0) {
	    if (ss[i-1] == -1) {
	       cursc = DLogsum(mxo[dpS][j][d+1] + pr->transitions[TSL] 
		     + pr->singles[rna[i-1]], mxo[dpL][j][d+1] + pr->transitions[TLL] 
		     + pr->singles[rna[i-1]]);
	    }
	 }
	 for (k = j+1; k < len; k++) {
	    cursc = DLogsum(cursc, mxo[dpS][k][dist(i,k)] + pr->transitions[TSB] 
		  + mx[dpS][k][dist(j+1,k)]);
	    if (debug) printf("L %d %d %d: out %f in %f \n", i, j, k, 
		  mxo[dpS][k][dist(i,k)], mx[dpS][k][dist(j+1,k)]);  fflush(stdout);
	 }
	 mxo[dpL][j][d] = cursc;
	 if (debug) printf("beta L %d %d: %f \n", i, j, cursc);  fflush(stdout);

	 /* \beta^S(i,j) */
	 cursc = -BIGFLOAT;
	 if ((i == 0) && (j == len-1)) {
	    cursc = 0;  /*By def: beta_S(1,LEN) = 1.0 */
	 } else if ((i > 0) && (j < len-1)) {
	    if (ss[i-1] == j+1) {
	       cursc = DLogsum(mxo[dpS][j+1][d+2] + pr->transitions[TSS] 
		     + pr->pairs[rna[i-1]][rna[j+1]], mxo[dpL][j+1][d+2]  
		     + pr->transitions[TLS] + pr->pairs[rna[i-1]][rna[j+1]]);
	    }
	 } 
	 for (k = 0; k < i; k++) {
	    cursc = DLogsum(cursc, mxo[dpS][j][dist(k,j)] + pr->transitions[TSB]
		  + mx[dpL][i-1][dist(k,i-1)]);
	 }
	 mxo[dpS][j][d] = cursc;
	 if (debug) printf("beta S %d %d: %f\n", i, j, cursc);  fflush(stdout);

      }
   }
}

/***************** Posteriors *************************/

/* Function: probXYpairUNA
 * Date: RDD, Thu Jan 30 11:35:50 CST 2003 [St Louis]
 *
 * Purpose: Calculate the Probability that Xi pairs with Xj
 * 	using the UNA grammar
 *
 * Args:
 * 	x		Smaller index	
 * 	y	 	Larger Index	
 * 	mx		Inside matrix -- filled
 * 	mxo		Outside Matrix -- filled
 *	rna		Sequence under study
 *	len		Length of said sequence
 *	model 		Parameters for this model
 *	ret_sc		Prob(x pairs y) as Int log sum
 *
 * Returns:
 * 	1 on success; 0 on failure
 */
int
probXYpairUNA(int x, int y, double ***mx, double ***mxo, char *rna, int len, 
      		PROBMOD *model, double *ret_sc)
{
   double temp, fval;
   double probseq;
   int debug;
   int d;

   debug = FALSE;
   probseq = mx[dpS][len-1][len];
   d = y - x + 1;

   if (debug) printf("UNA Prob(x%d pairs x%d): ", x, y);

   temp = DLogsum(mxo[dpS][y][d] + mx[dpS][y-1][d-2]
	    + model->pairs[rna[x]][rna[y]] + model->transitions[TSS], 
	    mxo[dpL][y][d] + mx[dpS][y-1][d-2] + model->pairs[rna[x]][rna[y]] 
	    + model->transitions[TLS]);
   /* Normalize by multiply by (1 / P(x| model))
    * Recall p1 / p2 in log space is log(p1) - log(p2)
    */
   fval = temp - probseq;

   if (debug) {
      printf("Fval: %f (%f)  ", temp, asProb(temp));
      printf("Normalized: %f (%f)\n",  fval, asProb(fval));
   }

   *ret_sc = fval;
   return 1;
}

/* Function probXunpairedUNA
 * Date: RDD, Thu Jan 30 11:37:22 CST 2003 [St Louis]
 *
 * Purpose: Calculate the probability that Xi is unpaired
 * 	using the UNA grammar
 *
 * Args:
 * 	i		First index - position under scrutiny
 * 	mx		Inside matrix -- filled
 * 	mxo		Outside Matrix -- filled
 *	rna		Sequence under study
 *	len		Length of said sequence
 *	model 		Parameters for this model
 *	ret_sc		Prob(x pairs y) as Int log sum
 *
 * Returns:
 * 	1 on success; 0 on failure
 */
int
probXunpairedUNA(int i, double ***mx, double ***mxo, char *rna, int len, 
      PROBMOD *model, double *ret_sc)
{
  int d, j, debug;
  double cur_sc;
  double sum, fval, probseq;

  debug = FALSE;
  probseq = mx[dpS][len-1][len]; 

  if (debug) 
     printf("\nProb(x|model): %f (%f) Pos %d unpaired \n", 
	probseq, asProb(probseq), i);

  sum = -BIGFLOAT;
  for (j = i+1; j < len; j++) {
     d = j - i + 1;
     cur_sc = DLogsum(mxo[dpS][j][d] + mx[dpL][j][d-1] + model->singles[rna[i]] 
	   + model->transitions[TSL], mxo[dpL][j][d] + mx[dpL][j][d-1]
	   + model->singles[rna[i]] + model->transitions[TLL]);

     if (debug) printf("Left (%d, %d) : %f curr_sum %f ", i, j, cur_sc, sum); 
     sum = DLogsum(sum, cur_sc);
     if (debug) printf("sumsofar: %f\n", sum); 
  }
  for (j = 0; j < i; j++) {
     d = i - j + 1;
     cur_sc = DLogsum(mxo[dpS][i][d] + mx[dpR][i-1][d-1] + model->singles[rna[i]] 
	   + model->transitions[TSR], mxo[dpR][i][d] + mx[dpR][i-1][d-1]
	   + model->singles[rna[i]] + model->transitions[TRR]);
     if (debug) printf("Right (%d, %d) : %f curr_sum %f ", j, i, cur_sc, sum);  
     sum = DLogsum(sum, cur_sc);
     if (debug) printf("sumsofar: %f\n", sum);  
  }
  /* Special case of j = i; in which case effectively mx[i][i-1][dpR] = TRE */
  j = i; d = 1;
  cur_sc = DLogsum(mxo[dpS][j][d] + model->transitions[TRE] + model->singles[rna[i]] 
	+ model->transitions[TSR], mxo[dpR][j][d] + model->singles[rna[i]] 
	+ model->transitions[TRR] + model->transitions[TRE]);
  if (debug) printf("Right (%d, %d) E: %f curr_sum %f ", j, i, cur_sc, sum); 
  sum = DLogsum(sum, cur_sc); 
  if (debug) printf("sumsofar: %f\n", sum); 

  /* Normalize by multiply by (1 / P(x| model))
   * Recall p1 / p2 in log space is log(p1) - log(p2)
   */
  fval = sum - probseq;

  *ret_sc = fval;
  return 1;
}


/****************************** CML *******************************/
/* Function: calcNvalsUNA
 * Date: Thu Jan 30 11:38:24 CST 2003 [St Louis]
 * 
 * Purpose: calculate the sum of posteriors (n_{ij}) 
 *        for the transition parameters
 * 
 * Math: (See Krogh and Riis (1999), Neural Computation 11, 541-563))
 * For an HMM (easier notation):
 * 	n_{ij}(t) = P(\pi_{t-1} = i, \pi_t = j | x, \theta)
 * 	n_{ij} = \sum_t n_{ij}(t)
 * where i, j are states and t is a time point.
 * 
 * For SCFGs: we'd say n_{vw}(i,j) 
 * where v and w are states and (i,j) is a positional time point.
 * 
 * Note: Also calculates m_ij if the mx and mxo matricies
 * were conditionally calculated.
 * 
 * Args:
 * 	mx      Inside matrix (precalculated)
 *      mxo     Outside matrix (precalculated)
 *      rna     sequence
 *      len     length of said sequence
 *      model   parameters of current model
 *      probseq P(x|model)
 *      
 * Returns:
 * 	ret_nij (Allocated elsewhere!)
 *      1 on success; 0 on failure
 */
int
calcNvalsUNA(double ***mx, double ***mxo, char *rna, int len, PROBMOD *model,
            double probseq, PROBMOD *ret_nij)
{
   int d, i, j, k, l;
   double *trans, *semis, *emis;   /* Temp arrays for calc N_ij */
   double temp, left, right;       /* Temp values */
   int debug = FALSE;

   trans = (double *) malloc (sizeof(double) * NTRANS);
   semis = (double *) malloc (sizeof(double) * ALPHA);
   emis = (double *) malloc (sizeof(double) * PAIRS);

   for (i = 0; i < NTRANS; i++) {
      trans[i] = -BIGFLOAT;
   }
   for (i = 0; i < PAIRS; i++) {
      if (i < ALPHA) semis[i] = -BIGFLOAT;
      emis[i] = -BIGFLOAT;
   }

   for (j = 0; j < len; j++) {
      for (d = 1; d <= j+1; d++) {
	 i = j - d + 1; 

	 /* Transitions: 
	  * n_{vw}(i,j) = \frac{mxo[i][j][v] * mx[i][j][w] * emit[i-\delta][j-\delta] 
	  * \theta_{vw}}{P(x|\theta)}
	  */
	 left = mxo[dpS][j][d] + mx[dpL][j][d-1] + model->singles[rna[i]]
	    + model->transitions[TSL] - probseq;
	 trans[TSL] = DLogsum(trans[TSL], left);
	 left = mxo[dpL][j][d] + mx[dpL][j][d-1] + model->singles[rna[i]]
	    + model->transitions[TLL] - probseq;
	 trans[TLL] = DLogsum(trans[TLL], left);

	 if (j > 0) {
	    right = mxo[dpS][j][d] + mx[dpR][j-1][d-1] + model->singles[rna[j]]
	       + model->transitions[TSR] - probseq;
	    trans[TSR] = DLogsum(trans[TSR], right);
	    if (d == 1) trans[TRE] = DLogsum(trans[TRE], right);

	    right = mxo[dpR][j][d] + mx[dpR][j-1][d-1] + model->singles[rna[j]]
	       + model->transitions[TRR] - probseq;
	    trans[TRR] = DLogsum(trans[TRR], right);
	    if (d == 1) trans[TRE] = DLogsum(trans[TRE], right);

	    left = mxo[dpS][j][d] + mx[dpS][j-1][d-2] + model->pairs[rna[i]][rna[j]]
	       + model->transitions[TSS] - probseq;
	    trans[TSS] = DLogsum(trans[TSS], left);
	    left = mxo[dpL][j][d] + mx[dpS][j-1][d-2] + model->pairs[rna[i]][rna[j]]
	       + model->transitions[TLS] - probseq;
	    trans[TLS] = DLogsum(trans[TLS], left);
	 } else {
	    right = mxo[dpS][j][d] + model->transitions[TRE] + + model->singles[rna[j]]
	       + model->transitions[TSR] - probseq;
	    trans[TSR] = DLogsum(trans[TSR], right);
	    trans[TRE] = DLogsum(trans[TRE], right);
	 }

	 for (k = i; k < j; k++) {
	    left = mxo[dpS][j][d] + mx[dpL][k][dist(i,k)] + mx[dpS][j][dist(k+1,j)]
	       + model->transitions[TSB] - probseq;
	    trans[TSB] = DLogsum(trans[TSB], left);
	 }

	 /* Emissions:
	  * n_i(l) = P(\pi_l = i | x, \theta) = 
	  * 	\frac{\alpha_i(l) \beta_j(l)}{P(x|theta)}
	  */
	 temp = mx[dpS][j][d] + mxo[dpS][j][d] - probseq;
	 left = mx[dpL][j][d] + mxo[dpL][j][d] - probseq;
	 right = mx[dpR][j][d] + mxo[dpR][j][d] - probseq;
	 /* Singles Emissions */
	 semis[rna[i]] = DLogsum(semis[rna[i]], left);
	 semis[rna[j]] = DLogsum(semis[rna[j]], right);
	 /* Pairs Emissions */
	 if (i != j) {
	    emis[idx(rna[i], rna[j])] = DLogsum(emis[idx(rna[i], rna[j])], temp);
	 }
      }

   }
     for (i = 0; i < NTRANS; i++) {
      ret_nij->transitions[i] = trans[i];
   }
   for (i = 0; i < ALPHA; i++) {
      ret_nij->singles[i] = semis[i];
      for (j = 0; j < ALPHA; j++) {
	 ret_nij->pairs[i][j] = emis[idx(i,j)];
      }
   }

   if (debug) {
      PrintProbModel(stdout, ret_nij, UNA);
      PrintAsProbModelD(stdout, ret_nij, UNA);
   }

   return (TRUE);
}

/*
if (debug) {
      printf("Sum of Probs:\n");
      for (k = 0; k < ALPHA; k++) {
	 printf("%s: %f (%f)\n", baseNAME[k], semis[k], asProb(semis[k]));
	 for (l = 0; l < ALPHA; l++) {
	    printf("%s %s: %f (%f)\n", baseNAME[k], baseNAME[l], emis[idx(k,l)],
		  asProb(emis[idx(k,l)]));
	 }
      }
      printf("TSL: %f (%f)\n", trans[TSL], asProb(trans[TSL]));
      printf("TSR: %f (%f)\n", trans[TSR], asProb(trans[TSR]));
      printf("TSS: %f (%f)\n", trans[TSS], asProb(trans[TSS]));
      printf("TSB: %f (%f)\n", trans[TSB], asProb(trans[TSB]));
      printf("TLL: %f (%f)\n", trans[TLL], asProb(trans[TLL]));
      printf("TLS: %f (%f)\n", trans[TLS], asProb(trans[TLS]));
      printf("TRR: %f (%f)\n", trans[TRR], asProb(trans[TRR]));
      printf("TRE: %f (%f)\n", trans[TRE], asProb(trans[TRE]));
   }
   */
