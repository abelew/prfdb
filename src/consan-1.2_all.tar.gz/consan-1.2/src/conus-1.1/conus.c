/* conus.c 
 *
 * Meta-functions for training, gathering statistics, and
 * other actions necessary when comparing various grammars.
 */

#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"cfg.h"
#include"stats.h"
#include"options.h"

void SetupModel (OPTS *options, MODEL *loaded);
void gatherStats(char *filename, OPTS *settings, MODEL *model, STATS *ret_stats, char *usage);
void PermutateParameter (MODEL *model, int rule, int trans, int sign, 
      		OPTS settings, PROBMOD *ret_model);
void runComparison(int argc, char **argv, int optid, OPTS *settings, 
      			MODEL *model, char *usage);

/* Function: SetupModel
 * Date:     RDD, Thu Nov 15 17:53:41 2001 [St. Louis]
 *
 * Purpose: Using command line parameters, setup models. 
 *
 * Args:    
 *     options		command line selections
 *     model		The model parameters set
 *
 * Returns:  void.
 */
void
SetupModel (OPTS *options, MODEL *loaded)
{
  FILE *ifp;
  FILE *ofp;

  /* If a model is specified then should use the grammar and scoring scheme of the model */
  if (options->modelfile != NULL) {
    if (options->verbose) printf("Loading a saved model\n");
    ifp = fopen(options->modelfile, "r");
    ReadSCFG(ifp, loaded);
    fclose(ifp);
    if (loaded->probabilistic) {
      if (CheckModel(&(loaded->probs), loaded->grammar) == FALSE) {
        /* if (options->verbose) printProbModel(stdout, &(loaded->probs), options->grammar); */
        printf("WARNING: Model probabilities are off!\n");
      }
    }
    /* Set option parameters based on loaded model */
    options->useprob = loaded->probabilistic;
    options->grammar = loaded->grammar;
    if (options->verbose) printf("Load file using %s grammar \n", grNAME[loaded->grammar]);
    fflush(stdout);

  /* If an ascii parameter file is specified, load and setup the model 
  } else if (options->scorefile != NULL) {
    ZeroModel(loaded);
    if (options->verbose) printf("Loading an ascii parameter file\n");
    ifp = fopen(options->scorefile, "r");
    ReadAscii(ifp, &(loaded->scores));
    options->useprob = FALSE;
    loaded->probabilistic = FALSE;
    loaded->grammar = options->grammar;
    fclose(ifp);
   * */
 
  /* Else use a hydrogen bond counting scheme */
  } else {
    loaded->grammar = options->grammar;
    if (options->hbondsc) {
       SetUpM99s1(&(loaded->scores));  
    } else if (options->flatscore) {
       SetUpFlatMx(&(loaded->probs), options->grammar);
       LogifySCFG(&(loaded->probs), &(loaded->scores));
    } else {
       SetUpNusScoring(&(loaded->scores));
    }
    options->useprob = FALSE; loaded->probabilistic = FALSE;
    if (options->verbose) fprintf(options->ofp, 
	  "Hydrogen Bonding Parameters (+3 for GC/CG; +2 for AU/UA/GU/UG)\n");
  }
    
  if ((options->parameterout)) PrintModel(options->ofp, loaded);

  /* If asked to save the model, do so now. */
  if (options->savefile != NULL) {
    ofp = fopen(options->savefile, "w");
    SaveSCFG(ofp, loaded);
  } 
}
/* Function: gatherStats
 * Date:     RDD, Sat Dec  8 16:21:35 2001 [St. Louis]
 *
 * Purpose:  gathers stats on how well a model's
 *           predictions compare to the given structure
 *           for a test set.
 *         
 * Args:     
 * 	 filename    file containing sequences in test set
 *       settings    program settings (status of various flags)
 *       model       probabilistic model to use for predictions
 *       ret_stats   statistics returned by comparisons
 *       usage       program usage statement, to print on failure  
 *
 * Returns:  
 * 	ret_stats 	filled to reflect comparison of prediction to 
 * 			given structure for each sequence in filename.
 */
void
gatherStats(char *filename, OPTS *settings, MODEL *model, 
      STATS *ret_stats, char *usage)
{
  /* ReadSeq variables */
  SQFILE *sqfp; SQINFO sqinfo;
  int sformat;
  char *rna; char *ss; 
  struct trace_s *trc;
  int score;

  ZeroStats(ret_stats);

  /* Read input file into RNA array and filter for non-RNA residues */
  if ((sqfp = SeqfileOpen(filename, SQFILE_UNKNOWN, NULL)) == NULL) 
      Die("Failed to open sequence file %s\n%s\n", filename, usage);

  while (ReadSeq(sqfp, sformat, &rna, &sqinfo)) {
    ToRNA(rna);
    if (settings->istats || settings->debugg || 
	  settings->verbose || settings->structout) {
      fprintf(settings->ofp, "%s: ", sqinfo.name);
    }

    if (!(ContainsAmbiguous(rna, sqinfo.len))) {
      ret_stats->Nfree ++;

      if (settings->useprob) {
	if (settings->nostacking) {
	  dropStacking(model);
          if (settings->parameterout) {
	    fprintf(settings->ofp, "Parameters Adjusted -- No Stacking!\n");
	    PrintModel(settings->ofp, model);
	  }
	}
	trc = (struct trace_s *)probCYK(rna, sqinfo.len, 
			settings->grammar, &(model->probs), settings);
      } else {
	if (settings->nostacking) {
	  printf("NO STACKING\n");
	  dropStacking(model);
          if (settings->parameterout) {
	    fprintf(settings->ofp, "Parameters Adjusted -- No Stacking!\n");
	    PrintModel(settings->ofp, model);
	  }
	}
        trc = (struct trace_s *)CYK(rna, sqinfo.len,
		settings->grammar, &(model->scores), settings, &score);
      }	

      if (trc != NULL) {
        if (settings->traceback) PrintTrace(settings->ofp, trc, rna); 
        Trace2KHS(trc, rna, sqinfo.len, 1, settings->grammar, &ss);
        FreeTrace(trc);
      } else {
	 /* We shouldn't see this: */
	 printf("\nNOTICE!!!! Predicted Structure Trace is NULL!!!! NOTICE!!!\n\n");
      }

      if (!CompStruct(sqinfo.len, sqinfo.ss, ss, ret_stats, 
	       settings->istats, settings->mathews, FALSE)) {
	 fprintf(settings->ofp, "Bad Structure %s\n", sqinfo.name);
	 PrintKHS(stdout, rna, &sqinfo, ss);
      }

      if (settings->structout) {
	if (sqinfo.flags & SQINFO_SS) {
	  fprintf(settings->ofp, "The Given Structure\n");
	  PrintKHS(settings->ofp, rna, &sqinfo, sqinfo.ss);
	} else {
	 /* We shouldn't see this: */
	  printf("\nNOTICE!!!! No Structure Given in Test Sequence!  NOTICE!!!\n\n");
	} 
	fprintf(settings->ofp, "Predicted Structure:\n");
	PrintKHS(settings->ofp, rna, &sqinfo, ss);
	fprintf(settings->ofp, "Scores: %d\n", score);
      }
      if (settings->stockout) {
	PrintStockholm(settings->ofp, rna, &sqinfo, ss);
      }
      free(ss);
    } else {
      ret_stats->containN ++;
      printf("Ambiguous Sequence: %s\n", sqinfo.name);
    }
    /* Cleanup */
    FreeSequence(rna, &sqinfo);
  }
  SeqfileClose(sqfp);
}

/* Function: PermutateParameter
 * Date:     RDD, Fri Dec  7 10:27:09 2001 [St. Louis]
 *
 * Purpose:  Given a probabilistic model (model),
 *         run a permutation test on the transition parameters.
 *
 *     [Permutation Test:  
 *          Change a parameter by delta.
 *          Renormalize remaining parameters.
 *          Run new model on all test sets.]
 *
 * Args:     
 *     model  The unmodified model
 *     rule  	 The rule to modify
 *     trans     The transition to modify
 *     sign  	 FALSE means +; TRUE means - 
 *     settings  Information about how to modify
 *     ret_model The modified version of model
 *
 * Returns:  
 *     Puts modified version of model in ret_model
 */
void
PermutateParameter (MODEL *model, int rule, int trans, int sign, 
		OPTS settings, PROBMOD *ret_model)
{
  double changeamount;
  double renormfactor;
  int postrans;

  CopyProbEmissions (&(model->probs), ret_model);
  /* Should check that this TRANS is legal within this model */
  if (Rules[settings.grammar][rule][trans]) {
    /* Should calculate the absolute offset */
    if (settings.permutatetype == PER) {
      changeamount = (settings.percentage * 0.01) * model->probs.transitions[trans];
      if (sign) changeamount = changeamount * -1;
    } else if (settings.permutatetype == EXA) {
      if (sign) changeamount = settings.delta * -1;
      else changeamount = settings.delta;
    }
    if (settings.verbose) fprintf(settings.ofp, "Amount: %6.4f\n", changeamount); 
    /* Change the specified parameter */
    ret_model->transitions[trans] = model->probs.transitions[trans] + changeamount;
    /* Renormalize the remaining parameters */
    renormfactor = (1 - ret_model->transitions[trans]) / (1 - model->probs.transitions[trans]);
    for (postrans = 0; postrans < NTRANS; postrans++) {
      /* if this transition is involved in the same rule */
      if (Rules[settings.grammar][rule][postrans]){
	/* We don't renormalize the one we changed */
        if (postrans != trans) {
	  ret_model->transitions[postrans] = model->probs.transitions[postrans] * renormfactor;
        }
      }
    }
    if (settings.verbose) {
      fprintf(settings.ofp, "Permutated Probabilities\n");
      /* printProbModel(settings.ofp, ret_model, settings.grammar); */
    }
  } 
}

/* meldParams
 * RDD, Jul 25 14:29:19 CST 2002 [St Louis]
 * 
 * EXPERIMENT: Can we use the AYN parameters (or other)
 * to set the parameters for use in UZK?
 * Do we get better peformenace over UZK trained
 * parameters?
 *
 * Parameters:
 * 	params		model probs as trained by "lesser" grmamar
 *
 * Returns:
 * 	new values in params are adjusted for UZK grammar
 */
void
meldParams (MODEL *params)
{
  PROBMOD old;
  PROBMOD new;
  int i;
  float multiplier;
  float denom;

  /* Keep a copy of old parameters */
  CopyProbModel(&(params->probs), &old);

  /* Manipulate old (AYN) into new (UZK) */
  CopyProbEmissions(&old, &new);
  /* Set transitions */
  for (i = 0; i < NTRANS; i ++) {
    new.transitions[i] = old.transitions[i];
  }
  new.transitions[TPP] = old.transitions[TPP] + old.transitions[TPL] + old.transitions[TPR];
  new.transitions[TPN] = old.transitions[TPN] + old.transitions[TPE] + old.transitions[TPW];
  new.transitions[TJJ] = old.transitions[TRR];
  new.transitions[TJP] = old.transitions[TRP];
  new.transitions[TMM] = old.transitions[TMM];
  new.transitions[TMJ] = old.transitions[TMR];

  for (i = 0; i < ALPHA; i++) {
    new.loopcomp[i] = old.singles[i];
    new.hpcomp[i] = old.singles[i];
    new.bulgecomp[i] = old.singles[i];
  }

  /* Hairpins:
   * AYN: TNH * THH^(n-2) * THE 
   * UZK: TNH * Loop(n)
   * */
  new.hairpin[2] = old.transitions[THE];
  denom = new.hairpin[2];
  multiplier = old.transitions[THH];
  for (i = 3; i < MAXLOOP; i++) {
    new.hairpin[i] = old.transitions[THE] * multiplier;
    denom += new.hairpin[i];
    multiplier = multiplier * old.transitions[THH];
  }
  new.hairpin[0] = old.transitions[THE] * multiplier;
  denom += new.hairpin[0];
  new.hairpin[1] = old.transitions[THE] * multiplier;
  denom += new.hairpin[1];
  /* Renormalize */
  for (i = 0; i < MAXLOOP; i++) {
    new.hairpin[i] = new.hairpin[i] / denom;
    new.bulge[i] = new.hairpin[i];
    new.loop[i] = new.hairpin[i];
  }

  /* Set return values */
  CopyProbModel(&new, &(params->probs));
  params->grammar = RZK;
}
