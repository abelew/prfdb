/* order_main.c 
 *
 * Simple suboptimal reordering experiment 
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"
#include"stats.h"

static char optsline[]  = "\
where options are:\n\
-b	      : (req) number of suboptimals to reorder \n\
-h            : print short help, usage info, and grammar description\n\
-m <file>     : Use parameters, grammar and scoring specified in model <file> \n\
-g <string>   : Use grammar <string>, defaults to NUS; ignored if model file specified \n\
-x            : print out parameters of model \n\
-t            : print all parse trees (lots!) \n\
-a 	      : report all suboptimals table \n\
-c	      : report on things better than CYK \n\
-i	      : report tracebacks in CYK report (ignored if not with -c) \n\
-d            : debugging output \n\
-v            : verbose output \n\
-f            : debugging, print fill matrix from cyk \n\
-p            : print real with predicted structure\n\
-q            : print predicted structures in stockholm format \n\
";

static char usage[]  = "Usage: reorder -b # [-options] <seqfile in>\n";

void PrintOrdering(int bestscore, double beststr, int nstruct, 
      	int *pscores, int *strscores);

int 
main (int argc, char **argv) 
{
   /**** arguments variables *****/
   int   optid; 
   OPTS settings;

   /* ReadSeq variables */
   SQFILE *sqfp; SQINFO sqinfo;
   int sformat;
   char *rna, *drna; 
   char *ss; 
   char *bcyk; 
   int *ct;
   int *ctstruct; 

   /* Models info */
   MODEL nusmodel;
   PROBMOD dlogs;
   int ***insideMX, ***outsideMX;
   int noerror, bestscore;
   double score, beststr;
   int *scores, *neworder;
   int *indexmap;
   struct trace_s **structures;
   struct trace_s *trc;
   int i, j, temp;
   int nstruct;
   double ***matxINS;
   int numbetter, better, sbet, tsbet;
   int nseqs;
   int obsreorder, numreorder;
   STATS checkvsCYK;

   noerror = TRUE;
   numbetter = 0;
   nseqs = 0;
   numreorder = 0;
   tsbet = 0;

   /* srand(time(NULL)); */

   if (!(ProcessOpts(&settings, &optid, argc, argv, usage, "\tfor NUS and YRN only!", optsline))) {
      printf("%s\n\n", usage);
      exit(0);
   }
   if (argc - optid != 1)
      Die("Incorrect number of command line arguments.\n%s\n%s\n", 
	    usage, optsline);

   SetupModel(&settings, &nusmodel);  
   DLogifySCFG(&(nusmodel.probs), &dlogs);
   LogifySCFG(&(nusmodel.probs), &(nusmodel.scores)); 

   if (settings.modelfile == NULL) {
      nusmodel.grammar = settings.grammar;
      SetUpFlatMx(&(nusmodel.probs), settings.grammar);
      LogifySCFG(&(nusmodel.probs), &(nusmodel.scores)); 
   }

   if (settings.debugg) PrintFullModel(settings.ofp, &nusmodel);

   nstruct = settings.percentage;

   /* Read input file into RNA array and filter for non-RNA residues */
   if ((sqfp = SeqfileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL) 
      Die("Failed to open sequence file %s\n%s\n", argv[optid], usage);

   while (ReadSeq(sqfp, sformat, &rna, &sqinfo)) {
      ToRNA(rna);
      nseqs++; obsreorder = FALSE; better = FALSE; sbet = 0;
      if (settings.debugg) fprintf(settings.ofp, "Sequence %s:\n", sqinfo.name);

	/* Best prediction */
      trc = (struct trace_s *)CYK(rna, sqinfo.len, settings.grammar, 
	      	      &(nusmodel.scores), &settings, &bestscore);

      if (trc != NULL) {
	 trace2khs(trc, rna, sqinfo.len, 1, &ss);

	 if (! KHS2ct(ss, sqinfo.len, FALSE, &ct))
	 { printf("[bad predicted CYK structure]\n"); return (FALSE);}

	 noerror = Inside(rna, sqinfo.len, nusmodel.grammar, &dlogs,
	       &settings, ct, &beststr, &matxINS);
	 freeFillMxD(matxINS, nusmodel.grammar);
      }

	/* Suboptimals  */
      noerror = Suboptimals(rna, sqinfo.len, nusmodel.grammar, 
	    &nusmodel, &settings, nstruct, TRUE, &scores, &structures, &sqinfo);

      neworder = (int *) malloc (sizeof(int) * nstruct);
      indexmap = (int *) malloc (sizeof(int) * nstruct);
      for (i = 0; i < nstruct; i++) {
	 trace2khs(structures[i], rna, sqinfo.len, 1, &ss);

	 if (! KHS2ct(ss, sqinfo.len, FALSE, &ct)) { 
	    /* If a bad structure is detected, treat it as impossible 
	     * In theory this never happens.*/
	    neworder[i] = -BIGINT;
	 } else {
	    noerror = Inside(rna, sqinfo.len, nusmodel.grammar, &dlogs,
		  &settings, ct, &score, &matxINS);

	    freeFillMxD(matxINS, nusmodel.grammar);

	    neworder[i] = (int)score;
	 }
	 indexmap[i] = i;
      }

      /* Simple bubble sort of suboptimals */
      for (i = 0; i < nstruct; i++) {
        for (j = i; j < nstruct; j++) {
	   if (scores[j] > scores[i]) {
	      temp = scores[j];
	      scores[j] = scores[i];
	      scores[i] = temp;
	      temp = neworder[j];
	      neworder[j] = neworder[i];
	      neworder[i] = temp;
	      /* We need to sort structures too -- or keep a
	       * mapping of unsorted coordinates to sorted ones!
	       */
	      temp = indexmap[j];
	      indexmap[j] = indexmap[i];
	      indexmap[i] = temp;
	   }
	}
      }

      /* How do the suboptimals do? */
      for (i = 0; i < nstruct; i++) {
	 /* Check if ANY subopt struct is better */
	 if (neworder[i] > beststr) {
	    /* Need a sanity check -- is this just another 
	     * parse tree for the same CYK structure?  (ie.
	     * is it better just because of precision problems?)
	     */
	    trace2khs(trc, rna, sqinfo.len, 1, &ss);
	    /* Need to refer to the right structure -- which 
	     * requires using the mapping ... */
	    trace2khs(structures[indexmap[i]], rna, sqinfo.len, 1, &bcyk);
	    ZeroStats(&checkvsCYK);

	    if (CompStruct(sqinfo.len, ss, bcyk, &checkvsCYK, FALSE,
		  FALSE, FALSE)) {
	       /* If these parses refer to the same structure then
		* the number correct will be equivalent to the
		* trusted pairs. */
	       if (checkvsCYK.test_correct != checkvsCYK.trust_correct) {
		  better = TRUE;
		  sbet++;		/* How many per sequence? */
		  obsreorder = TRUE;
	       } else {
		  if (settings.verbose)
		     printf("Found CYK structure again!\n");
	       }
	    }
	 }
	 if (i > 0) {	/* Reordering */
	    if (neworder[i] > neworder[i-1]) {
	       obsreorder = TRUE;
	    }
	 }
      }

      if (obsreorder) { numreorder++; }
      if (better) { 
	 numbetter++; 
	 tsbet += sbet;
      }
      if (settings.globalstats) {
        PrintOrdering(bestscore, beststr, nstruct, scores, neworder);
      }
      if ((settings.ctoutput) && (better)) {
	 /* Generate a report on the ones that are better */
	 printf("Suboptimal(s) greater than CYK for %s (%d better) \n", sqinfo.name, sbet);
	 printf("%d \t %d \t CYK results \n", bestscore, (int)beststr);
	 if (settings.istats) PrintTrace(stdout, trc, rna);
	 trace2khs(trc, rna, sqinfo.len, 1, &ss);
	 PrintKHS(stdout, rna, &sqinfo, ss);
	 for (i = 0; i < nstruct; i++) {
	    if (neworder[i] > beststr) {
	       /* Order has CYK first, so a particular suboptimal is at i+1 position */
	       printf("%d \t %d \t Better than CYK! (%d in order; %d generated) \n", 
		     scores[i], neworder[i], (i+1), (indexmap[i]+1));
	       if (settings.istats) PrintTrace(stdout, structures[indexmap[i]], rna);
	       trace2khs(structures[indexmap[i]], rna, sqinfo.len, 1, &ss);
	       PrintKHS(stdout, rna, &sqinfo, ss);
	    }
	 }
      }
      /* Lots to clean up for this sequence */
      FreeSequence(rna, &sqinfo);
      FreeTrace(trc);
      for (i = 0; i < nstruct; i++) {
        FreeTrace(structures[i]);
      }
      free(neworder);
      free(scores);
      free(indexmap);
   }
   SeqfileClose(sqfp);
   printf("Totals %d seqs (%d subopts)\n", nseqs, nstruct);
   printf("Seqs with CYK not best: %d\n", numbetter);
   if (better != 0) {
     printf("\t(%f avg num/seq) \n", (float)tsbet/(float)nseqs);
   }
   printf("Seqs with Reordering observed: %d\n", numreorder);
}

void
PrintOrdering(int bestscore, double beststr, int nstruct,
      int *pscores, int *strscores)
{
   int i;

   printf("Best Parse \t Structure \t Notes \n");
   printf("---------- \t --------- \t ----- \n");
   printf("%d \t %d \t CYK results \n", bestscore, (int)beststr);

   if (beststr < strscores[0]) {
      printf("%d \t %d \t Better than CYK! \n", pscores[0], strscores[0]);
   } else if (beststr == strscores[0]) {
      printf("%d \t %d \t Equal Above \n", pscores[0], strscores[0]);
   } else {
      printf("%d \t %d \t \n", pscores[0], strscores[0]);
   }

   for (i = 1; i < nstruct; i++) {
      /* Check if ANY subopt struct is better */
      if (strscores[i] > beststr) {
	 printf("%d \t %d \t Better than CYK!\n", pscores[i], strscores[i]);
      } else if (strscores[i] > strscores[i-1]) {
	 printf("%d \t %d \t Better than previous \n", pscores[i], strscores[i]);
      } else if (strscores[i] != strscores[i-1]) {
	 printf("%d \t %d \t \n", pscores[i], strscores[i]);
      } else {
	 printf("%d \t %d \t Equal Above \n", pscores[i], strscores[i]);
      }
   }
}

