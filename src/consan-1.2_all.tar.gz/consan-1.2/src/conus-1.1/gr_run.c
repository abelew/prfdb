/* gr_ryn.c
 * RDD, Wed Jan 23 08:28:44 CST 2002
 *
 * Implementations of grammar specific 
 * routines for RUN
 *
 * Mon Jan 21 17:49:12 CST 2002
 * Revised Unambiguous Nussinov (II) :	
 *    (Based on the Graeme grammar of Tue Dec 11 14:45:50 CST 2001)
 *     	S -> aS | T | end			(RUN)
 *      T -> Ta | aSb | T aSa' 
 *
 * These implementations assume a digitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"

/* Function: cykInitRUN
 * Date:     RDD, Wed Jan 23 08:28:44 CST 2002 [St Louis]
 *
 * Purpose:  Initialize CYK fill matrix for RUN and RYN grammars 
 *
 * Args:     
 *	mx	fill matrix (integer log odds form)
 *	model	parameters
 *	rna	sequence
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cykInitRUN(int ***mx, INTMOD *model, char *rna, int len)
{
   int j, d;

   for (d = 0; d <= len; d++) {
      for (j = d; j < len; j++) {
	 mx[dpS][j][d] = model->transitions[TSE];        /* S -> end */
	 mx[dpT][j][d] = -BIGINT;
      } /* end for j */
      if (d > 0) {
	 mx[dpS][d-1][d] = model->transitions[TSE];
	 mx[dpT][d-1][d] = -BIGINT;
      }
   } /* end for i */
}

/* Function: cykFillRUN
 * Date:    Tue Jan 22 15:01:41 CST 2002 [St Louis]
 *
 * Purpose:  Fills CYK matrix for RUN 
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (as integer log Probs)
 *	sc	parameters 
 *		(integer log form or as scores)
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Notes: Fills matrix correctly for RUN and RYN.
 *      Must fill T before S as one rule in S allows S -> T
 *      and therefore the current cell of T will need to
 *      already known.
 *
 * Returns:  void 
 */
void
cykFillRUN(int ***mx, INTMOD *pr, char *rna, int len)
{
   int d, i, j, k;       /* Loop indicies */
   int max;              /* Maximum value seen so far */
   int cursc, cursc2;    /* Current score */
   int stackvalue;	

   /* Recursion */
   for (d = 1; d <= len; d++) {
      for (j = d-1; j < len; j++) {
	 i = j - d + 1; max = -BIGINT;

	 /* T -> Ta */
	 if (j > 0) {
	    cursc = mx[dpT][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TTT];
	    if (cursc > max) max = cursc;

	    /* T -> aPa' */
	    if (d > 1) {
	       cursc = mx[dpS][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TTP];
	       if ((cursc > max) && (lplen(i,j) >= HLEN)) max = cursc; 
	    }
	 }

	 /* T -> T aPa' */
	 for (k = i+1; k < j-1; k++) {
	    cursc = mx[dpT][k][dist(i,k)] + mx[dpS][j-1][dist(k+2,j-1)] 
	       + pr->pairs[rna[k+1]][rna[j]] + pr->transitions[TTB];
	    if ((cursc > max) && (lplen(k+1,j) >= HLEN)) max = cursc; 
	 } /* End for loop T -> T aSa' */

	 /* T -> Ta | aPa' | T aPa' */
	 mx[dpT][j][d] = max;

	 max = -BIGINT;
	 /* S -> aS */
	 cursc = mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSS];
	 if (cursc > max) max = cursc; 

	 /* S -> T */
	 cursc = mx[dpT][j][d] + pr->transitions[TST];
	 if (cursc > max) max = cursc;

	 /* S -> aS | T | end */
	 mx[dpS][j][d] = max;
      }
   }
}

/* Function: cykTraceRUN
 * Date:     RDD, Tue Jan 22 15:24:12 CST 2002 [St Louis]
 *
 * Purpose:  Build traceback tree for RUN and RYN 
 *
 * Args:
 *	mx	matrix in which to calculate cyk
 *	pr	parameters in integer form
 *	rna	sequence 
 * 	len	sequence length
 *
 * Returns: traceback tree
 */
struct trace_s *
cykTraceRUN(int ***mx, INTMOD *pr, char *rna, int len)
{
  int d, i, j, k, mtx;   /* Indices */
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, AttachTrace (parsetree, dpS, 0, (len -1), TRE));

  /* Repeat until stack is empty */
  while (curr = PopTracestack(stack)) {
    /* Set i and j from items in stack */
    i = curr->emitl; j = curr->emitr; mtx = curr->nonterminal;
    d = j - i + 1;

    if (i > j) { 		/* S(R) -> end */
      curr->emitl = -1; curr->emitr = -1; 
      curr->transition = TSE; curr->nonterminal = dpS; 
      continue;
    } else if (mtx == dpS) {
      /* S -> aS | T | end */
      if ((mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSS]) == mx[dpS][j][d]) {
        curr->emitr = -1; curr->transition = TSS; 
        PushTracestack(stack, AttachTrace (curr, dpS, i+1, j, TRE));
      } else {
	/* Assumes: ((mx[dpT][j][d] + pr->transitions[TST]) == mx[dpS][j][d]) */
        curr->emitr = -1; curr->emitl = -1; curr->transition = TST; 
        PushTracestack(stack, AttachTrace (curr, dpT, i, j, TRE));
      }
    } else if (mtx == dpT) {
      /* T -> Tb | aPa' | T aPa' */
      if ((mx[dpT][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TTT]) == mx[dpT][j][d]) {
        curr->emitl = -1; curr->transition = TTT; 
        PushTracestack(stack, AttachTrace (curr, dpT, i, j-1, TRE));
      } else if ((lplen(i,j) >= HLEN) && ((mx[dpS][j-1][d-2] 
		  + pr->pairs[rna[i]][rna[j]] + pr->transitions[TTP]) 
	       == mx[dpT][j][d])) {
        curr->transition = TTP;
        PushTracestack(stack, AttachTrace (curr, dpS, i+1, j-1, TRE));
      } else {
        for (k = i+1; k < j-1; k++) {
          if ((lplen(k+1, j) >= HLEN) && ((mx[dpT][k][dist(i,k)] 
		      + mx[dpS][j-1][dist(k+2,j-1)] 
		      + pr->pairs[rna[k+1]][rna[j]] 
		      + pr->transitions[TTB]) == mx[dpT][j][d])) {
            curr->emitl = k+1; curr->transition = TTB;
            PushTracestack(stack, AttachTrace (curr, dpS, k+2, j-1, TRE));
            PushTracestack(stack, AttachTrace (curr, dpT, i, k, TRE));
	    k = j;	/* Short circuit */
          } /* End if */
        } /* End for (bifurcation points) */
      } 

    } else {
      printf("ERROR!! Nonterminal %d unkown in RUN/RYN traceback!\n", mtx);
    }
  }
  FreeTracestack(stack);
  return parsetree;
}

/* Function:  khs2traceRUN
 * Date:     RDD, Tue Apr 23 09:40:05 2002 [St. Louis]
 *
 * Purpose:  Convert KHS format into properly 
 * 	labeled traceback tree for RUN grammar
 *
 * Args:     
 *	dolist  Traceback tree to build from KHS	
 *	ct	KHS info represented as ct format
 */
int
khs2traceRUN(struct tracestack_s *dolist, int *ct)
{
  struct trace_s      *cur;
  struct trace_s      *tr;
  struct trace_s      *prv, *nxt;
  char left; char right;
  int  i,j, mid;

  while ((cur = PopTracestack(dolist)) != NULL) {
    i = cur->emitl; j = cur->emitr;

    if (i > j) {
      cur->transition = TSE; cur->emitl = -1; cur->emitr = -1; 
    } else if (ct[i] == -1) {
      /* So to be here we HAVE to be in S? */
      cur->transition = TSS; cur->emitr = -1;
      PushTracestack(dolist, AttachTrace(cur, dpS, i+1, j, TRE));
    } else if (ct[j] == -1) {
      if (cur->nonterminal == dpS) {
        cur->transition = TST; cur->emitl = -1; cur->emitr = -1; 
        PushTracestack(dolist, AttachTrace(cur, dpT, i, j, TRE));
      } else {
        cur->transition = TTT; cur->emitl = -1; 
        PushTracestack(dolist, AttachTrace(cur, dpT, i, j-1, TRE));
      }
    } else if (ct[i] == j) {
      if (cur->nonterminal == dpS) {
        cur->transition = TST; cur->emitl = -1; cur->emitr = -1; 
        PushTracestack(dolist, AttachTrace(cur, dpT, i, j, TRE));
      } else {
        cur->transition = TTP;
        PushTracestack(dolist, AttachTrace(cur, dpS, i+1, j-1, TRE));
      }
    } else {
      if (cur->nonterminal == dpS) {
        cur->transition = TST; cur->emitl = -1; cur->emitr = -1; 
        PushTracestack(dolist, AttachTrace(cur, dpT, i, j, TRE));
      } else {
        cur->transition = TTB; cur->emitl = ct[j];
        PushTracestack(dolist, AttachTrace(cur, dpS, ct[j]+1, j-1, TRE));
        PushTracestack(dolist, AttachTrace(cur, dpT, i, ct[j]-1, TRE));
      }
    }
  }
  return 1;
}

/* Function: analyzeTraceR 
 * Date:     RDD, Tue May 14 15:56:25 CDT 2002 [St Louis]
 *
 * Purpose: Parse a traceback tree for information.
 *	Either for counts (training).
 *	Or for determining tracebcak score.
 *
 * Args:     
 *	seq	Current sequence under analysis
 *	len	length of said sequence
 *	tr	traceback tree (properly labeled)
 *	cfg	parameters, as ints, in which to count
 *      count - if TRUE this is TraceCount; 
 *		if FALSE this is TraceScore
 *
 * Returns:  score of current traceback (in TraceScore mode)
 * 	Should return zero in TraceCount mode
 */
int
analyzeTraceR(char *seq, int len, struct trace_s *tr, INTMOD *cfg, int count)
{
  struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
  struct trace_s      *cur;     /* current node in the tree              */
  char *iseq;                   /* sequence with 0,1,2,3,4 in place of A,C,G,U,N */
  int   cst, nst, j;
  char left; char right;
  int score;

 /* Digitize Sequence setup */
  SetAlphabet(hmmNUCLEIC);

  iseq = DigitizeSequence(seq, len);

  dolist = InitTracestack();
  PushTracestack(dolist, tr->nxtl);
  score = 0;

  while ((cur = PopTracestack(dolist)) != NULL) {
    if (cur->transition < NTRANS) {
      if (count) cfg->transitions[cur->transition] += 1;
      else score += cfg->transitions[cur->transition];
      if (cur->transition == TSE) {	/* do nothing on ENDS */
	continue;
      } else if ((cur->transition == TTB) || (cur->transition == TPB)) {
        if (count) cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
        else score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	PushTracestack(dolist, cur->nxtr);
	PushTracestack(dolist, cur->nxtl);
      } else if ((cur->emitl == -1) && (cur->emitr == -1)) { /* No emission */
	PushTracestack(dolist, cur->nxtl);
      } else {
	if (cur->emitl == -1) {
	   if (iseq[cur->emitr] > ALPHA) {
	      if (count) cfg->transitions[cur->transition] -= 1;
	   } else {
	      if (count) cfg->singles[iseq[cur->emitr]] += 1;
	      else score += cfg->singles[iseq[cur->emitr]];
	   }

	/* Emit to left */
	} else if (cur->emitr == -1) {
	   if (iseq[cur->emitl] > ALPHA) {
	      if (count) cfg->transitions[cur->transition] -= 1;
	   } else {
	      if (count)cfg->singles[iseq[cur->emitl]] += 1;
	      else score += cfg->singles[iseq[cur->emitl]];
	   }

	/* Emit aligned pair -- stacking model */
        } else if (cur->nonterminal == dpP) {
          if ((iseq[cur->emitl -1] > ALPHA) || (iseq[cur->emitr +1] > ALPHA)) {
		/* Do nothing, contains an ambiguous base! 
		 * Therfore must back out of counting transition!
 		 */
	    if (count)  cfg->transitions[cur->transition] -= 1;
          } else {
            if (count) {
	      cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
				[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
	      /* By also adding to pairs, it is like you are averaging the pair 
               * emissions over all pairs (including stacks) */
	      cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
            } else {
	      score += cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
				[iseq[cur->emitl]][iseq[cur->emitr]];
            }
          }

	/* Emit aligned pair -- no stacking */
	} else {
	  if (count) cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]] += 1;
	  else score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	}
	PushTracestack(dolist, cur->nxtl);
      }
    } else {
      PushTracestack(dolist, cur->nxtl);
    }
  }
  free(iseq);
  FreeTracestack(dolist);
  return score;
}
/* Function: dTraceScoreR 
 * Date:     Mon Oct 27 16:56:06 CST 2003 [St Louis]
 *
 * Purpose: Parse a traceback tree for determining traceback score.
 * 	[Needed for ambiguity testing]
 *
 * Args:     
 *	seq	Current sequence under analysis
 *	len	length of said sequence
 *	tr	traceback tree (properly labeled)
 *	cfg	parameters (as float log form)
 *	ret_val score of traceback
 *
 * Returns:  void
 */
void
dTraceScoreR (char *seq, int len, struct trace_s *tr, PROBMOD *cfg, double *ret_val)
{
  struct tracestack_s *dolist;  /* stack for traversal of traceback tree */
  struct trace_s      *cur;     /* current node in the tree              */
  char *iseq;                   /* sequence with 0,1,2,3,4 in place of A,C,G,U,N */
  int   cst, nst, j;
  char left; char right;
  double score;

 /* Digitize Sequence setup */
  SetAlphabet(hmmNUCLEIC);

  iseq = DigitizeSequence(seq, len);

  dolist = InitTracestack();
  PushTracestack(dolist, tr->nxtl);
  score = 0.;

  while ((cur = PopTracestack(dolist)) != NULL) {
    if (cur->transition < NTRANS) {
      score += cfg->transitions[cur->transition];
      if (cur->transition == TSE) {	/* do nothing on ENDS */
	continue;
      } else if ((cur->transition == TTB) || (cur->transition == TPB)) {
        score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	PushTracestack(dolist, cur->nxtr);
	PushTracestack(dolist, cur->nxtl);
      } else if ((cur->emitl == -1) && (cur->emitr == -1)) { /* No emission */
	PushTracestack(dolist, cur->nxtl);
      } else {
	if (cur->emitl == -1) {
	   if (iseq[cur->emitr] > ALPHA) {
	      /* Do nothing */
	   } else {
	      score += cfg->singles[iseq[cur->emitr]];
	   }

	/* Emit to left */
	} else if (cur->emitr == -1) {
	   if (iseq[cur->emitl] > ALPHA) {
	      /* Do nothing */
	   } else {
	      score += cfg->singles[iseq[cur->emitl]];
	   }

	/* Emit aligned pair -- stacking model */
        } else if (cur->nonterminal == dpP) {
          if ((iseq[cur->emitl -1] > ALPHA) || (iseq[cur->emitr +1] > ALPHA)) {
		/* Do nothing, contains an ambiguous base! 
		 * Therfore must back out of counting transition!
 		 */
          } else {
	      score += cfg->stack[idx(iseq[cur->emitl - 1],iseq[cur->emitr + 1])]
				[iseq[cur->emitl]][iseq[cur->emitr]];
          }

	/* Emit aligned pair -- no stacking */
	} else {
	  score += cfg->pairs[iseq[cur->emitl]][iseq[cur->emitr]];
	}
	PushTracestack(dolist, cur->nxtl);
      }
    } else {
      PushTracestack(dolist, cur->nxtl);
    }
  }
  free(iseq);
  FreeTracestack(dolist);
  *ret_val = score;
}

/******************************* Inside **********************************/

/* Function: cinsInitRUN
 * Date:     RDD, Sun Oct  5 14:07:44 CDT 2003 [St Louis]
 *
 * Purpose:  Initialize cInside fill matrix 
 *
 * Args:     
 *	mx	fill matrix (log odds form)
 *	model	parameters
 *	rna	sequence
 * 	len	sequence length
 *
 * Returns:  -- void -- 
 */
void
cinsInitRUN(double ***mx, PROBMOD *model, char *rna, int len)
{
   int j, d;

   for (d = 0; d <= len; d++) {
      for (j = d; j < len; j++) {
	 mx[dpS][j][d] = model->transitions[TSE];        /* S -> end */
	 mx[dpT][j][d] = -BIGFLOAT;
      } /* end for j */
      if (d > 0) {
	 mx[dpS][d-1][d] = model->transitions[TSE];
	 mx[dpT][d-1][d] = -BIGFLOAT;
      }
   } /* end for i */
}

/* Function: cinskFillRUN
 * Date:    Sun Oct  5 14:08:21 CDT 2003 [St Louis]
 *
 * Purpose:  Fills cInside matrix for RUN 
 *
 * Assumption: Fill matrix already allocated and initialized
 *
 * Args:    
 *	mx	matrix to calculate cyk (log Probs)
 *	sc	parameters  (log form )
 *	rna	sequence (digitized)
 * 	len	sequence length
 *
 * Notes: Fills matrix correctly for RUN and RYN.
 *      Must fill T before S as one rule in S allows S -> T
 *      and therefore the current cell of T will need to
 *      already known.
 *
 * Returns:  void 
 */
void
cinsFillRUN(double ***mx, PROBMOD *pr, char *rna, int len, int *ss)
{
   int d, i, j, k;       /* Loop indicies */
   double cursc, cursc2;    /* Current score */
   double stackvalue;	

   /* Recursion */
   for (d = 1; d <= len; d++) {
      for (j = d-1; j < len; j++) {
	 i = j - d + 1; 
	 
	 cursc= -BIGFLOAT;
	 /* T -> Ta | aPa' | T aPa' */

	 /* T -> Ta */
	 if (j > 0) {
	    if (ss[j] == -1) cursc = mx[dpT][j-1][d-1] + pr->singles[rna[j]] + pr->transitions[TTT];

	    /* T -> aPa' */
	    if (d > 1) {
	       if (ss[i] == j) {
		  cursc = DLogsum(mx[dpS][j-1][d-2] + pr->pairs[rna[i]][rna[j]] + pr->transitions[TTP], cursc);
	       }
	    }
	 }

	 /* T -> T aPa' */
	 for (k = i+1; k < j-1; k++) {
	    if (ss[k+1] == j) {
	       cursc = DLogsum(mx[dpT][k][dist(i,k)] + mx[dpS][j-1][dist(k+2,j-1)] 
		  + pr->pairs[rna[k+1]][rna[j]] + pr->transitions[TTB], cursc);
	    }
	 } 

	 /* T -> Ta | aPa' | T aPa' */
	 mx[dpT][j][d] = cursc;

	 cursc = -BIGFLOAT;
	 /* S -> aS | T | end */
	 if (ss[i] == -1) { cursc = mx[dpS][j][d-1] + pr->singles[rna[i]] + pr->transitions[TSS]; }
	 cursc = DLogsum(mx[dpT][j][d] + pr->transitions[TST], cursc);

	 /* S -> aS | T | end */
	 mx[dpS][j][d] = cursc;
      }
   }
}

