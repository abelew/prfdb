#ifndef OPTION_H_INCLUDED
#define OPTION_H_INCLUDED

#define NON	0
#define EXA	1
#define PER	2

/* Not all grammars available for all programs -- I need to 
 * swtich this message out depending on which grammars ARE 
 * available! 
 */
static char gramdesc[] = "\
Grammars available in CONUS: (use three letter codes) \n\
  code	Grammar:\n\
  ----  -------- \n\
  NUS   Ambiguous Simple Grammar (G1) \n\
  UNA   Another Unambiguous (G3) \n\
  RUN   Little Unambiguous (G4) \n\
  IVO	Simplest Unambiguous (G5) \n\
  BJK	Pfold grammar (G6) \n\
  YRN	Stacking grammar (G2) \n\
  UYN   Stacking analog of UNA (G7)\n\
  RY3   Stacking analog of RUN (G8)\n\
  BK2	Stacking parameterization of BJK (G6S)\n\
";

static char gdescexp[] = "\
Experimental grammars (various levels of implementations): \n\
	RYN     Stacking analog of RUN \n\
	RY2     Stacking analog of RUN \n\
	BRY     Bulge Little Unambiguous Yarn (ambiguous) \n\
	AYN	Affine Loop Length grammar \n\
	AY2	Affine Loop Length grammar \n\
	RZK 	Loop Length grammar \n\
	ZUK	Zuker's (1981) grammar \n\
	GIE 	Giegerich's  grammar \n\
";

struct opts {
  /* -g <string>   : Use grammar <string>, defaults to NUS; 
   * 			ignored if model file specified */
  int grammar;		/* Grammar requested on command line */
  /* -o <file>     : redirect output to <file> */
  FILE *ofp;

  /* -v            : verbose output */
  int verbose;		
  /* -d            : debugging output */
  int debugg;		
  /* -t            : print traceback stack */
  int traceback;	
  /* -f            : debugging, print fill matrix from cyk */
  int outmx;		
  /* -x		 : print out parameters of model */
  int parameterout;	

  /* -p            : print real and predicted structure (khs format) */
  int structout;	
  /* -q            : output predictions in stockholm format */
  int stockout;		
  /* -c            : print ct output format for predicted structure */
  int ctoutput;		

  /* -i            : print intermediate statistics (each input sequence) */
  int istats;		
  /* -a            : print globals statistics (over all files) */
  int globalstats;	
  /* -M		   : Turn on the Mathews method of evaluation */
  int mathews;	
  /* -N		   : Disallow stacking parameterization */
  int nostacking;	

  /* -m <file>     : Use parameters, grammar and scoring specified in model <file>  */
  char *modelfile;	
  /* -r <file>     : Use training set in <file>; ignored if model file specified */
  char *trainfile;	
  /* -s <file>     : save model file to <file> */
  char *savefile;	
  /* -e <file>     : save a scorefile */
  char *scorefile;	

  /* -H            : turn on Nussinov +1 scoring */
  int hbondsc;	
  /* --flat        : use a flat scoring scheme */
  int flatscore;	
  /* -w            : set minimum loop size (default = 1)  */
  int minloop;	/* Minimal Loop Size */

  /* conus_permutate and cml.c : */
  /* -b <int>      : Permutate the probabilistic grammar by <int> percentage */
  int percentage;	
  /* -j <float>    : Permutate the probabilistic grammar by <float> amount */
  double delta;		
  /* Switch between -b and -a permutation (will ignore -b if -a selected) */
  int permutatetype;	

  /* In cml.c only: */
  /* -y	           : Use delta for a percentage */
  int fixedstep;
  /* -z	           : Use a fixed step size instead */
  /* -j		 : Use a percentage */
  int seteta;

  /* Do we tie parameters? */
  int tie;	
  int useprob;		/* Use probabilistic version (vs scoring) */
};

typedef struct opts OPTS;

extern int ProcessOpts(OPTS *options, int *optid, int argc, char **argv, 
			char *usage, char *expert, char *optsline);
extern int processGrammarChoice (char *grammar, int verbose);
extern void PrintOptions (FILE *ofp, OPTS *options);
#endif /* OPTION_H_INCLUDED */


