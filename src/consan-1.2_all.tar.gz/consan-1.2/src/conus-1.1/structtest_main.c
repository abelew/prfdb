/* structtest_main.c 
 *
 * Determine if the structures contained in a stokholm file 
 * are valid.  Used in testing dataset conversions.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"
#include"stats.h"

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-i 	      : Assume KHS is reversed -- as in Infernal output \n\
-c            : print ct output format for predicted structure\n\n\
";
static char usage[]  = "Usage: stest [-options] <seqfile in>\n"; 

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/ 
  int   optid; 
  OPTS settings;

  /* Stats info */
  int total, bad;

  /* ReadSeq variables */
  SQFILE *sqfp; SQINFO sqinfo;
  int sformat;
  char *rna; 
  int *ct;
  int maxlen, minlen, totlen;
  int inbp, numbp, i, nknot, lonepairs;

  if (!(ProcessOpts(&settings, &optid, argc, argv, usage, "", optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  } 

   if (argc - optid != 1)
    Die("Incorrect number of command line arguments.\n%s\n%s\n", usage, optsline);

  /* Digitize Setup */
  SetAlphabet(hmmNUCLEIC);

  total = 0; bad = 0;
  /* Read input file into RNA array and filter for non-RNA residues */
  if ((sqfp = SeqfileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL) 
    Die("Failed to open sequence file %s\n%s\n", argv[optid], usage);

  maxlen = 0;
  minlen = 50000;
  totlen = 0;
  numbp = 0;
  nknot = 0;
  lonepairs = 0;

  while (ReadSeq(sqfp, sformat, &rna, &sqinfo)) {
    ToRNA(rna);
    inbp = 0;

    total ++;
    fprintf(settings.ofp, "Sequence: %s %d ", sqinfo.name, sqinfo.len);

    if (!settings.istats) {
       if (! KHS2ct(sqinfo.ss, sqinfo.len, FALSE, &ct)) { 
	  printf("[bad trusted structure]\n"); 
	  PrintKHS(stdout, rna, &sqinfo, sqinfo.ss);
	  bad++;
       } else {
	  if (sqinfo.len > maxlen) maxlen = sqinfo.len; 
	  if (sqinfo.len < maxlen) minlen = sqinfo.len; 
	  totlen += sqinfo.len;
	  for (i = 0; i < sqinfo.len; i++) {
	     if ((sqinfo.ss[i] == '<') || (sqinfo.ss[i] == '>')) {
		inbp++;
	     }
	     if (isalpha((int)sqinfo.ss[i])) {
		nknot++;
	     }
	  }
	  printf("%f bp ", (float)inbp/sqinfo.len);
	  numbp += inbp;
	  if (CheckforLonePairs(ct, sqinfo.len)) {
	     lonepairs++;
	     printf("*");
	  }
	  printf("\n");
       }
    }else {
       if (! Infernal2ct(sqinfo.ss, sqinfo.len, FALSE, &ct)) { 
	  printf("[bad trusted structure]\n"); 
	  PrintKHS(stdout, rna, &sqinfo, sqinfo.ss);
	  bad++;
       } else {
	  if (sqinfo.len > maxlen) maxlen = sqinfo.len; 
	  if (sqinfo.len < minlen) minlen = sqinfo.len; 
	  totlen += sqinfo.len;
       }
    }

    /* Cleanup  */
    free(ct);
    FreeSequence(rna, &sqinfo);
  }
  printf("\nIn file %s: \n", argv[optid]);
  printf("Seqs %d with %d bad structures, (%d with lone pairs) \n", 
	total, bad, lonepairs);
  printf("Structures: Max Len %d; Avg Len %d; Min Len %d \n", maxlen, (totlen/total), minlen);
  printf("Basepairing: %d bps and %d knots in %d nts \n",
	numbp/2, nknot/2, totlen);
  printf("\t(%f nt in bp) (%f bp in knots) \n\n", 
	(float)(numbp + nknot)/totlen, (float)nknot/(numbp + nknot));
  SeqfileClose(sqfp);
}


