/* cfgrpt.c
 * Sat Apr 16 16:50:44 EDT 2005 [Boston]
 * 
 * Printout of a model in various ways.
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include "squid/squid.h"
#include "cfg.h"

/* Function: PrintModel, printImodel, printFmodel, 
 * 	printTransitions, printEmissions, 
 * Note: 
 *   produces nice pretty parameter output
 */
void
printModel(FILE *fp, int code, MODEL *cfg)
{
   if (code == PRINT_INT) {
      fprintf(fp, "Integer Form: \n");
      printTransitions(fp, cfg, FALSE);
      printEmissions(fp, cfg, FALSE);

   } else if (code == PRINT_FLT) {
      fprintf(fp, "Float Form: \n");
      printTransitions(fp, cfg, TRUE);
      printEmissions(fp, cfg, TRUE);

   }else {
      fprintf(fp, "Integer Form: \n");
      printTransitions(fp, cfg, FALSE);
      printEmissions(fp, cfg, FALSE);

      fprintf(fp, "Float Form: \n");
      printTransitions(fp, cfg, TRUE);
      printEmissions(fp, cfg, TRUE);
   }
}

void
printImodel(FILE *fp, INTMOD *icfg)
{
   MODEL *temp;

   allocModel(&temp);
   copyImod(icfg, &(temp->imod));
   printModel(fp, PRINT_INT, temp);
   freeModel(temp);
}

void
printFmodel(FILE *fp, PROBMOD *icfg)
{
   MODEL *temp;

   allocModel(&temp);
   copyFmod(icfg, &(temp->fmod));
   printModel(fp, PRINT_FLT, temp);
   freeModel(temp);
}

void
printTransitions(FILE *fp, MODEL *mod, int usefmod)
{
   int i,j;
   int printed;

   fprintf (fp, "Transition Matrix:\n");
   if (usefmod) {
     printf("Use probs\n"); fflush(stdout);
     for (i = 0; i < NDPS; i++) {
       if (Contains[mod->grammar][i]) {
	 printed = 0;
	 fprintf (fp, "Nonterminal %s:\t", dpNAME[Gtype[mod->grammar]][i]);
	 for (j = 0; j < NTRANS; j++) {
	   if (Rules[mod->grammar][i][j]) {
	     if ((mod->fmod.transitions[j] > 0) && (mod->fmod.transitions[j] < 1.0)) {
	       fprintf (fp, "%s: %1.4f ", dptNAME[Gtype[mod->grammar]][j], 
		   mod->fmod.transitions[j]);
	     } else {
	       fprintf (fp, "%s: %1.2e ", dptNAME[Gtype[mod->grammar]][j], 
		   mod->fmod.transitions[j]);
	     }
	     printed++;
	     if (printed%6 == 5) fprintf(fp, "\n\t\t\t");
	   }
	 }
	 fputs("\n", fp);
       }
     }
   } else {
      for (i = 0; i < NDPS; i++) {
	 if (Contains[mod->grammar][i]) {
	    printed = 0;
	    fprintf (fp, "Nonterminal %s:\t", dpNAME[Gtype[mod->grammar]][i]); 
	    for (j = 0; j < NTRANS; j++) {
	       if (Rules[mod->grammar][i][j]) {
		  fprintf (fp, "%s: %4d ", dptNAME[Gtype[mod->grammar]][j], 
			mod->imod.transitions[j]);
		  printed++;
	          if (printed%6 == 5) fprintf(fp, "\n\t\t\t"); 
	       }
	    }
	    fputs("\n", fp);
	 }
      }
   }
   fputs("\n", fp);
}

void
printEmissions(FILE *fp, MODEL *mod, int usefmod)
{
  printEPairwise(fp, mod, usefmod);
  printEAlign(fp, mod, usefmod);
  printESingles(fp, mod, usefmod);
}

void
printEPairwise(FILE *fp, MODEL *mod, int usefmod)
{
   int i, j, k, l;

   fprintf (fp, "Pair Matrix:\n");
   if (usefmod) {
     fprintf (fp, "\t");
     for (k = 0; k < ALPHA; k++) 
       for (l = 0; l < ALPHA; l++) 
	 fprintf (fp, "%4s:%s ", baseNAME[k], baseNAME[l]);

     fprintf (fp, "\n");
     for (i = 0; i < ALPHA; i++) {
       for (j = 0; j < ALPHA; j++) {
	 fprintf (fp, "%4s:%s  ", baseNAME[i], baseNAME[j]);
	 for (k=0; k< ALPHA; k++) {
	   for (l=0; l< ALPHA; l++)
	     if ((mod->fmod.emissions[ePR(idx(i,j),idx(k,l))] > 0) && 
		 (mod->fmod.emissions[ePR(idx(i,j),idx(k,l))] < 1.0)) {
	       fprintf (fp, "%1.4f ", 
		   mod->fmod.emissions[ePR(idx(i,j),idx(k,l))]);
	     } else {
	       fprintf (fp, "%1.3e ", 
		   mod->fmod.emissions[ePR(idx(i,j),idx(k,l))]);
	     }
	 }
	 fputs("\n", fp);
       }
       fputs("\n", fp);
     }
   } else {
     fprintf (fp, "X Y:");         /* Necessary spacing for ints */
      for (k = 0; k < ALPHA; k++) {
	 for (l = 0; l < ALPHA; l++) fprintf (fp, "%4s:%s ", baseNAME[k], baseNAME[l]);
      }
      fprintf (fp, "\n");
      for (i = 0; i < ALPHA; i++) {
	 for (j = 0; j < ALPHA; j++) {
	    fprintf (fp, "%s:%s ", baseNAME[i], baseNAME[j]);
	    for (k=0; k< ALPHA; k++) {
	       for (l=0; l< ALPHA; l++)
		  fprintf (fp, "%6d ", mod->imod.emissions[ePR(idx(i,j),idx(k,l))]);
	    }
	    fputs("\n", fp);
	 }
	 fputs("\n", fp);
      }
   }
}

void
printEAlign(FILE *fp, MODEL *mod, int usefmod)
{
   int i, j;

   fprintf (fp, "Align Matrix:\n");
   if (usefmod) {
      for (i = 0; i < ALPHA; i++) {
	 fprintf (fp, "%6s ", baseNAME[i]);
      }
      fprintf (fp, "\n");
      for (i = 0; i < ALPHA; i++) {
	fprintf (fp, "%s ", baseNAME[i]);
	for (j=0; j< ALPHA; j++) {
	  if ((mod->fmod.emissions[eAL(i,j)] > 0) && 
	      (mod->fmod.emissions[eAL(i,j)] < 1.0)) {
	    fprintf (fp, "%1.4f ", mod->fmod.emissions[eAL(i,j)]);
	  } else {
	    fprintf (fp, "%1.3e ", mod->fmod.emissions[eAL(i,j)]);
	  }
	}
	fputs("\n", fp);
      }

   } else {
      fprintf (fp, "  ");         /* Necessary spacing for ints */
      for (i = 0; i < ALPHA; i++) {
	 fprintf (fp, "%4s ", baseNAME[i]);
      }
      fprintf (fp, "\n");
      for (i = 0; i < ALPHA; i++) {
	 fprintf (fp, "%s ", baseNAME[i]);
	 for (j=0; j< ALPHA; j++) {
	    fprintf (fp, "%4d ", mod->imod.emissions[eAL(i,j)]);
	 }
	 fputs("\n", fp);
      }
   }
}

void
printESingles(FILE *fp, MODEL *mod, int usefmod)
{
   int i;

   fprintf (fp, "Singles Matrix:\n");
   if (usefmod) {
     for (i = 0; i < ALPHA; i++) {
       if ((mod->fmod.emissions[eSS(i)] > 0) && (mod->fmod.emissions[eSS(i)] < 1.0)) {
	 fprintf (fp, "%s %1.4f  ", baseNAME[i], mod->fmod.emissions[eSS(i)]);
       } else {
	 fprintf (fp, "%s %1.3e  ", baseNAME[i], mod->fmod.emissions[eSS(i)]);
       }
     }
   } else {
      for (i = 0; i < ALPHA; i++)
	 fprintf (fp, "%s %4d  ", baseNAME[i], mod->imod.emissions[eSS(i)]);
   }
   fputs("\n\n", fp);
}

/* Functions: printTransL, printEPairL, 
 * 	printEAlignL, printESingL
 * Note: 
 *   produces parameter output in columns for
 *   gnuplot histograms
 */
void
printTransL(FILE *fp, MODEL *mod, int labels)
{
  int i,j;

  if (labels) fprintf (fp, "Transition Matrix:\n");
  for (i = 0; i < NDPS; i++) {
    if (Contains[mod->grammar][i]) {
      if (labels) fprintf (fp, "Nonterminal %s:\n", dpNAME[Gtype[mod->grammar]][i]);
      for (j = 0; j < NTRANS; j++) {
	if (Rules[mod->grammar][i][j]) {
	  if ((mod->fmod.transitions[j] > 0) && (mod->fmod.transitions[j] < 1.0)) {
	    fprintf (fp, "%1.6f\n", mod->fmod.transitions[j]);
	  } else {
	    fprintf (fp, "%1.2e\n", mod->fmod.transitions[j]);
	  } /* if */
	} /* Rules */
      } /* j */
      if (labels) fputs("\n", fp);
    } /* Contains */
  } /* i */
}

void
printEmisL(FILE *fp, MODEL *mod, int labels)
{
  printEPairL(fp, mod, labels);
  printEAlignL(fp, mod, labels);
  printESingL(fp, mod, labels);
}


void
printEPairL(FILE *fp, MODEL *mod, int labels)
{
  int i, j, k, l;

  if (labels) fprintf (fp, "Pair Matrix:\n");
    
  for (i = 0; i < ALPHA; i++) {
    for (j = 0; j < ALPHA; j++) {
      if (labels) fprintf (fp, "%4s:%s\n", baseNAME[i], baseNAME[j]);
      for (k=0; k< ALPHA; k++) {
	for (l=0; l< ALPHA; l++) {
	  if ((mod->fmod.emissions[ePR(idx(i,j),idx(k,l))] > 0) &&
	      (mod->fmod.emissions[ePR(idx(i,j),idx(k,l))] < 1.0)) {
	    fprintf (fp, "%1.6f\n", mod->fmod.emissions[ePR(idx(i,j),idx(k,l))]);
	  } else {
	    fprintf (fp, "%1.3e\n", 
		mod->fmod.emissions[ePR(idx(i,j),idx(k,l))]);
	  }
	} /* l */
      } /* k */
    } /* j */
    if (labels) fputs("\n", fp);
  } /* i */
}

void
printEAlignL(FILE *fp, MODEL *mod, int labels)
{
  int i, j;

  if (labels) fprintf (fp, "Align Matrix:\n");
  for (i = 0; i < ALPHA; i++) {
    for (j=0; j< ALPHA; j++) {
      if ((mod->fmod.emissions[eAL(i,j)] > 0) &&
	  (mod->fmod.emissions[eAL(i,j)] < 1.0)) {
	fprintf (fp, "%1.6f\n", mod->fmod.emissions[eAL(i,j)]);
      } else {
	fprintf (fp, "%1.3e\n", mod->fmod.emissions[eAL(i,j)]);
      }
    }
    if (labels) fputs("\n", fp);
  }
}

void
printESingL(FILE *fp, MODEL *mod, int labels)
{
  int i;

  if (labels) fprintf (fp, "Singles Matrix:\n");
  for (i = 0; i < ALPHA; i++) {
    if ((mod->fmod.emissions[eSS(i)] > 0) && (mod->fmod.emissions[eSS(i)] < 1.0)) {
      fprintf (fp, "%1.6f\n", mod->fmod.emissions[eSS(i)]);
    } else {
      fprintf (fp, "%1.3e\n", mod->fmod.emissions[eSS(i)]);
    }
  }
}


/********************** Multiple models together *****************/
/* Functions: printTransPair, printEPairPair, 
 * 	printEAlignPair, printESingPair
 * Note: 
 *   produces two column comparison output between two models 
 */
void
printTransPair(FILE *fp, MODEL *mod1, MODEL *mod2, int labels)
{
  int i,j;

  if (labels) fprintf (fp, "Transition Matrix:\n");
  for (i = 0; i < NDPS; i++) {
    if (Contains[mod1->grammar][i]) {
      if (labels) fprintf (fp, "Nonterminal %s:\n", dpNAME[Gtype[mod1->grammar]][i]);
      for (j = 0; j < NTRANS; j++) {
	if (Rules[mod1->grammar][i][j]) {
	  if ((mod1->fmod.transitions[j] > 0) && (mod1->fmod.transitions[j] < 1.0)) {
	    fprintf (fp, "%1.6f\t%1.6f\n", mod1->fmod.transitions[j], 
		mod2->fmod.transitions[j]);
	  } else {
	    fprintf (fp, "%1.2e\t%1.2e\n", mod1->fmod.transitions[j], 
		mod2->fmod.transitions[j]);
	  } /* if */
	} /* Rules */
      } /* j */
      if (labels) fputs("\n", fp);
    } /* Contains */
  } /* i */
}

void
printEmisPair(FILE *fp, MODEL *mod1, MODEL *mod2, int usefmod)
{
  printEPairPair(fp, mod1, mod2, usefmod);
  printEAlignPair(fp, mod1, mod2, usefmod);
  printESingPair(fp, mod1, mod2, usefmod);
}


void
printEPairPair(FILE *fp, MODEL *mod1, MODEL *mod2, int labels)
{
  int i, j, k, l;

  if (labels) fprintf (fp, "Pair Matrix:\n");
    
  for (i = 0; i < ALPHA; i++) {
    for (j = 0; j < ALPHA; j++) {
      if (labels) fprintf (fp, "%4s:%s\n", baseNAME[i], baseNAME[j]);
      for (k=0; k< ALPHA; k++) {
	for (l=0; l< ALPHA; l++) {
	  if ((mod1->fmod.emissions[ePR(idx(i,j),idx(k,l))] > 0) &&
	      (mod1->fmod.emissions[ePR(idx(i,j),idx(k,l))] < 1.0)) {
	    fprintf (fp, "%1.6f\t%1.6f\n", mod1->fmod.emissions[ePR(idx(i,j),idx(k,l))],
		mod2->fmod.emissions[ePR(idx(i,j),idx(k,l))]);
	  } else {
	    fprintf (fp, "%1.3e\t%1.3e\n", 
		mod1->fmod.emissions[ePR(idx(i,j),idx(k,l))],
		mod2->fmod.emissions[ePR(idx(i,j),idx(k,l))]);
	  }
	} /* l */
      } /* k */
    } /* j */
    if (labels) fputs("\n", fp);
  } /* i */
}

void
printEAlignPair(FILE *fp, MODEL *mod1, MODEL *mod2, int labels)
{
  int i, j;

  if (labels) fprintf (fp, "Align Matrix:\n");
  for (i = 0; i < ALPHA; i++) {
    for (j=0; j< ALPHA; j++) {
      if ((mod1->fmod.emissions[eAL(i,j)] > 0) &&
	  (mod1->fmod.emissions[eAL(i,j)] < 1.0)) {
	fprintf (fp, "%1.6f\t%1.6f\n", mod1->fmod.emissions[eAL(i,j)],
	    mod2->fmod.emissions[eAL(i,j)]);
      } else {
	fprintf (fp, "%1.3e\t%1.3e\n", mod1->fmod.emissions[eAL(i,j)],
	    mod2->fmod.emissions[eAL(i,j)]);
      }
    }
    if (labels) fputs("\n", fp);
  }
}

void
printESingPair(FILE *fp, MODEL *mod1, MODEL *mod2, int labels)
{
  int i;

  if (labels) fprintf (fp, "Singles Matrix:\n");
  for (i = 0; i < ALPHA; i++) {
    if ((mod1->fmod.emissions[eSS(i)] > 0) && (mod1->fmod.emissions[eSS(i)] < 1.0)) {
      fprintf (fp, "%1.6f\t%1.6f\n", mod1->fmod.emissions[eSS(i)],
	  mod2->fmod.emissions[eSS(i)]);
    } else {
      fprintf (fp, "%1.3e\t%1.3e\n", mod1->fmod.emissions[eSS(i)],
	  mod2->fmod.emissions[eSS(i)]);
    }
  }
}

/* Functions: printTransQuad, printEPairQuad, 
 * 	printEAlignQuad, printESingQuad
 * Note: 
 *   produces four column comparison output 
 *   between four models (mean1 stddev1 mean2 stddev2)
 */
void
printTransQuad(FILE *fp, MODEL *mod1, MODEL *mod2, 
    MODEL *mod3, MODEL *mod4, int labels)
{
  int i,j;

  if (labels) fprintf (fp, "Transition Matrix:\n");
  for (i = 0; i < NDPS; i++) {
    if (Contains[mod1->grammar][i]) {
      if (labels) fprintf (fp, "Nonterminal %s:\n", dpNAME[Gtype[mod1->grammar]][i]);
      for (j = 0; j < NTRANS; j++) {
	if (Rules[mod1->grammar][i][j]) {
	  if ((mod1->fmod.transitions[j] > 0) && (mod1->fmod.transitions[j] < 1.0)) {
	    fprintf (fp, "%1.6f\t%1.6f\t%1.10f\t%1.10f\n", mod1->fmod.transitions[j], 
		mod2->fmod.transitions[j], mod3->fmod.transitions[j], mod4->fmod.transitions[j]);
	  } else {
	    fprintf (fp, "%1.2e\t%1.2e%1.3e%1.3e\n", mod1->fmod.transitions[j], 
		mod2->fmod.transitions[j], mod3->fmod.transitions[j], mod4->fmod.transitions[j]);
	  } /* if */
	} /* Rules */
      } /* j */
      if (labels) fputs("\n", fp);
    } /* Contains */
  } /* i */
}

void
printEPairQuad(FILE *fp, MODEL *mod1, MODEL *mod2, 
    MODEL *mod3, MODEL *mod4, int labels)
{
  int i, j, k, l;

  if (labels) fprintf (fp, "Pair Matrix:\n");
    
  for (i = 0; i < ALPHA; i++) {
    for (j = 0; j < ALPHA; j++) {
      if (labels) fprintf (fp, "%4s:%s\n", baseNAME[i], baseNAME[j]);
      for (k=0; k< ALPHA; k++) {
	for (l=0; l< ALPHA; l++) {
	  if ((mod1->fmod.emissions[ePR(idx(i,j),idx(k,l))] > 0) &&
	      (mod1->fmod.emissions[ePR(idx(i,j),idx(k,l))] < 1.0)) {
	    fprintf (fp, "%1.6f\t%1.6f\t%1.10f\t%1.10f\n", mod1->fmod.emissions[ePR(idx(i,j),idx(k,l))],
		mod2->fmod.emissions[ePR(idx(i,j),idx(k,l))],
		mod3->fmod.emissions[ePR(idx(i,j),idx(k,l))],
		mod4->fmod.emissions[ePR(idx(i,j),idx(k,l))]);
	  } else {
	    fprintf (fp, "%1.3e\t%1.3e%1.3e%1.3e\n", 
		mod1->fmod.emissions[ePR(idx(i,j),idx(k,l))],
		mod2->fmod.emissions[ePR(idx(i,j),idx(k,l))],
		mod3->fmod.emissions[ePR(idx(i,j),idx(k,l))],
		mod4->fmod.emissions[ePR(idx(i,j),idx(k,l))]);
	  }
	} /* l */
      } /* k */
    } /* j */
    if (labels) fputs("\n", fp);
  } /* i */
}

void
printEAlignQuad(FILE *fp, MODEL *mod1, MODEL *mod2,
    MODEL *mod3, MODEL *mod4, int labels)
{
  int i, j;

  if (labels) fprintf (fp, "Align Matrix:\n");
  for (i = 0; i < ALPHA; i++) {
    for (j=0; j< ALPHA; j++) {
      if ((mod1->fmod.emissions[eAL(i,j)] > 0) &&
	  (mod1->fmod.emissions[eAL(i,j)] < 1.0)) {
	fprintf (fp, "%1.6f\t%1.6f\t%1.10f\t%1.10f\n", mod1->fmod.emissions[eAL(i,j)],
	    mod2->fmod.emissions[eAL(i,j)],
	    mod3->fmod.emissions[eAL(i,j)],
	    mod4->fmod.emissions[eAL(i,j)]);
      } else {
	fprintf (fp, "%1.3e\t%1.3e%1.3e%1.3e\n", mod1->fmod.emissions[eAL(i,j)],
	    mod2->fmod.emissions[eAL(i,j)],
	    mod3->fmod.emissions[eAL(i,j)],
	    mod4->fmod.emissions[eAL(i,j)]);
      }
    }
    if (labels) fputs("\n", fp);
  }
}

void
printESingQuad(FILE *fp, MODEL *mod1, MODEL *mod2,
    MODEL *mod3, MODEL *mod4, int labels)
{
  int i;

  if (labels) fprintf (fp, "Singles Matrix:\n");
  for (i = 0; i < ALPHA; i++) {
    if ((mod1->fmod.emissions[eSS(i)] > 0) && (mod1->fmod.emissions[eSS(i)] < 1.0)) {
      fprintf (fp, "%1.6f\t%1.6f\t%1.10f\t%1.10f\n", mod1->fmod.emissions[eSS(i)],
	  mod2->fmod.emissions[eSS(i)], mod3->fmod.emissions[eSS(i)], mod4->fmod.emissions[eSS(i)]);
    } else {
      fprintf (fp, "%1.3e\t%1.3e%1.3e%1.3e\n", mod1->fmod.emissions[eSS(i)],
	  mod2->fmod.emissions[eSS(i)], mod3->fmod.emissions[eSS(i)], mod4->fmod.emissions[eSS(i)]);
    }
  }
}

