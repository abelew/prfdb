/* options.c
 * Routines for processing a universal set of options 
 */

#include<string.h>
#include<ctype.h>

#include"squid/squid.h"
#include"squid/sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"options.h"
#include"version.h"
#include"consan.h"

struct opt_s OPTIONS[] = {
  { "-h",        TRUE,  sqdARG_NONE  },  
  { "-d",        TRUE,  sqdARG_NONE  }, /* debugg */
  { "-v",        TRUE,  sqdARG_NONE  }, /* verbose */
  { "-g",        TRUE,  sqdARG_STRING}, /* grammar */
  { "-m",        TRUE,  sqdARG_STRING}, /* modelfile */
  { "-o",        TRUE,  sqdARG_STRING}, /* outfile */
  { "-s",        TRUE,  sqdARG_STRING}, /* savefile */
  { "-p",        TRUE,  sqdARG_STRING}, /* pinfile */
  { "--pt",      FALSE, sqdARG_STRING}, /* tablefile */
  { "--al",      FALSE, sqdARG_NONE  }, /* usegiven */
  { "-x",        TRUE,  sqdARG_NONE  }, /* parameterout */
  { "-t",        TRUE,  sqdARG_NONE  }, /* traceback */
/* End of standard options */
  { "-c",        TRUE,  sqdARG_NONE  }, /* copt */
  { "-l",        TRUE,  sqdARG_NONE  }, /* linearize */
  { "-f",        TRUE,  sqdARG_NONE  }, /* fopt */
  { "-q",        TRUE,  sqdARG_NONE  }, /* stockout */
  { "-n",        TRUE,  sqdARG_NONE  }, /* weights */
  { "-V",        TRUE,  sqdARG_NONE  }, /* voronoi */
  { "-G",        TRUE,  sqdARG_NONE  }, /* gscweights */
  { "-S",        TRUE,  sqdARG_NONE  }, /* suppress */
  { "--self",    FALSE, sqdARG_NONE  }, /* selfvself */
  { "--all",     FALSE, sqdARG_NONE  }, /* allpairs */
  { "-C",        TRUE,  sqdARG_INT   }, /* Coption */
  { "-T",        TRUE,  sqdARG_INT   }, /* tie */
  { "-W",        TRUE,  sqdARG_INT   }, /* win */
  { "-M",        TRUE,  sqdARG_INT   }, /* Moption */
  { "-P",        TRUE,  sqdARG_INT   }, /* Poption */
  { "-z",        TRUE,  sqdARG_INT   }, /* Zopt */
  { "-Z",        TRUE,  sqdARG_FLOAT }, /* zoption */
};

#define NOPTIONS (sizeof(OPTIONS) / sizeof(struct opt_s))

/* Function: processOpts
 * Date:     RDD, Thu Nov 15 17:52:31 2001 [St. Louis]
 *
 * Purpose:  proccess a standard set of options for CONUS
 *
 * Args:     
 *     	options		datastructure containing settings
 *	optid		iterator to command line options
 *	argc		command line information
 *	argv		command line information
 *	usage		program usage statement, printed on failure.
 *
 * Returns:  TRUE if options parsed properly; FALSE otherwise
 */
int 
processOpts(OPTS *options, int *optid, int argc, char **argv, char *usage, char *optsline)
{
  char *optarg; char *optname;
  char *grmr;			/* Loaded grammar value */

  /* Set defaults in options */
  grmr = NULL;
  options->grammar 	= STA;

  options->verbose       = FALSE; options->debugg 	= FALSE; 
  options->traceback     = FALSE; options->fopt	= FALSE;
  options->parameterout	 = FALSE;

  options->modelfile	= NULL; options->savefile     	= NULL; 
  options->tablefile    = NULL; options->pinfile	= NULL; 

  options->stockout 	= FALSE; options->tie		= LRTIE; 
  options->weights	= TRUE;  options->copt = FALSE;
  options->voronoi	= FALSE; options->gscweights 	= FALSE;
  options->suppress	= FALSE; 
  options->selfvself	= FALSE; options->allpairs 	= FALSE;
  options->cset	   	= FALSE; options->usegiven	= FALSE; 

  options->pinopt 	= QRADIUS; options->Zoption 	= 1.0;
  options->mset		= FALSE; options->Moption 	= 2000;
  options->zset 	= FALSE;  options->Poption	= 0;
  options->pset		= FALSE;  options->Woption = 5;
  options->wset		= FALSE;  options->Coption = 10;
  options->linear 	= FALSE;  

  options->ofp = stdout;

  /* Intepret command line arguments */
  while (Getopt(argc, argv, OPTIONS, NOPTIONS, optsline, optid, 
	&optname, &optarg)) {
     if (strcmp(optname, "-v") == 0) options->verbose = TRUE;
     else if (strcmp(optname, "-g") == 0) grmr			= optarg;
     else if (strcmp(optname, "-d") == 0) options->debugg	= TRUE;
     else if (strcmp(optname, "-t") == 0) options->traceback 	= TRUE;
     else if (strcmp(optname, "-f") == 0) options->fopt		= TRUE;
     else if (strcmp(optname, "-x") == 0) options->parameterout	= TRUE;
     else if (strcmp(optname, "-s") == 0) options->savefile	= optarg;
     else if (strcmp(optname, "-q") == 0) options->stockout	= TRUE;
     else if (strcmp(optname, "-l") == 0) options->linear 	= TRUE;
     else if (strcmp(optname, "-m") == 0) options->modelfile	= optarg;
     else if (strcmp(optname, "-n") == 0) options->weights	= FALSE;
     else if (strcmp(optname, "-V") == 0) options->voronoi 	= TRUE;
     else if (strcmp(optname, "-G") == 0) options->gscweights 	= TRUE;
     else if (strcmp(optname, "-T") == 0) options->tie		= atoi(optarg);
     else if (strcmp(optname, "-S") == 0) options->suppress	= TRUE;
     else if (strcmp(optname, "--pt") == 0) options->tablefile	= optarg;
     else if (strcmp(optname, "--al") == 0) options->usegiven  = TRUE;
     else if (strcmp(optname, "--self") == 0) options->selfvself = TRUE;
     else if (strcmp(optname, "--all") == 0) options->allpairs = TRUE;
     else if (strcmp(optname, "-z") == 0) options->pinopt = atoi(optarg);
     else if (strcmp(optname, "-p") == 0) {
       options->pinfile 	= optarg;
     } else if (strcmp(optname, "-M") == 0) {
       options->mset = TRUE;
       options->Moption = atoi(optarg);
     } else if (strcmp(optname, "-Z") == 0) {
       options->Zoption = atof(optarg);
       if ((options->Zoption < 0) || (options->Zoption > 1.0))
	 options->Zoption = 0.5;
       options->zset = TRUE;
     } else if (strcmp(optname, "-C") == 0) {
       options->Coption = atoi(optarg);
       options->cset = TRUE;
     } else if (strcmp(optname, "-P") == 0) {
       options->Poption = atoi(optarg);
       options->pset = TRUE;
   } else if (strcmp(optname, "-W") == 0) {
       options->Woption = atoi(optarg);
       options->wset = TRUE;
     } else if (strcmp(optname, "-c") == 0) {
       options->copt = TRUE; /* force recalc weights in training */
     } else if (strcmp(optname, "-o") == 0) {
       if ((options->ofp = fopen(optarg, "w")) == NULL) {
	 Die("Failed to open output file %s!", optarg);
       }
     } else if (strcmp(optname, "-h") == 0) {
	puts(BANNER);
	printf("         Sankoff %s (%s)", RELEASE, RELEASEDATE);
	printf("%s\n", usage);
	puts(optsline);
	return FALSE;
     }
  }

  /* Process selected grammar -- convert input string into a grammar choice */
  if (grmr != NULL) options->grammar = processGrammarChoice(grmr);
  if (options->grammar >= GMR) 
     Die("Improperly specified grammar!\n NUS, YRN, MNG, or STA\n"); 

  return TRUE;
}

/* Function: setupWeights
 *
 * Purpose: given a MSA file, ensure that the weighting
 * 	is setup like we've specified in the options
 *
 * Args:
 * 	msa		the multiple alignment
 * 	settings	the designated weighting scheme
 *
 * Returns:
 * 	TRUE if all goes well; FALSE otherwise
 * 	Modifies msa->wgt array.
 */
int
setupWeights(MSA *msa, OPTS settings)
{
  int i;

  if (settings.weights) {
    printf("Calculate Weights: ");
    if (settings.voronoi) {	/* Use voronoi weights */
      printf("Voronoi\n");
      VoronoiWeights(msa->aseq, msa->nseq, msa->alen, msa->wgt);
    } else if (settings.gscweights) {	/* Use GSC weights */
      printf("GSC\n");
      GSCWeights(msa->aseq, msa->nseq, msa->alen, msa->wgt);
    } else {
      printf("BlosumWeights %f\n", settings.Zoption);
      BlosumWeights(msa->aseq, msa->nseq, msa->alen, 
	  settings.Zoption, msa->wgt);
    }
  } else {
    /* No weighting; Let's be extra paranoid  */
    for (i = 0; i < msa->nseq; i++) {
      msa->wgt[i] = 1.0;
    }
  }
     
   return 1;
}

/* Function: processGrammarChoice
 * Date:     RDD, Thu Nov 15 17:52:41 2001 [St. Louis]
 *
 * Purpose:  convert grammar input string to grammar code
 *
 * Args:   
 *	grammar		Grammar choice as a string 
 *
 * Returns:  
 *	grammar choice as it's code (see cfg.h)
 *	Returns GMR if unknown grammar selected
 */
int
processGrammarChoice (char *grammar)
{
  if (strcmp(grammar, "YRN") == 0) {
    printf("Using Stacking YRN Sankoff Grammar\n");
    return YRN;
  } else if (strcmp(grammar, "YR2") == 0) {
    printf("Using Stacking YR2 (N) Sankoff Grammar\n");
    return YR2;
  } else if (strcmp(grammar, "STA") == 0) {
    printf("Using Stacking STA Sankoff Grammar\n");
    return STA;
  } else if (strcmp(grammar, "MNG") == 0) {
    printf("Using MNG Sankoff Grammar\n");
    return MNG;
  } else {
    printf("Using Nussinov Sankoff grammar\n");
    return NUS;
  }
}

/* Function: printOptions
 * Date:     RDD, Thu Nov 15 17:52:48 2001 [St. Louis]
 *
 * Purpose: debugging function.  Prints contents of
 *	opts struct (see options.h) 
 *
 * Args:    
 *	ofp	Where to print 
 *	options	Which settings/options to print 
 *
 * Returns:  -nothing-
 */
void
printOptions (FILE *ofp, OPTS *options)
{
  fprintf(ofp, "Current Settings:\n");
  if (options->grammar < GMR) {
    fprintf(ofp, "Options: Grammar is %s\n", grNAME[options->grammar]);
  } else {
    fprintf(ofp, "Improperly specified grammar!\n");
  }

  if (options->verbose) fprintf(ofp, "Verbose output mode\n");
  if (options->debugg) fprintf(ofp, "Debug Mode\n");
  if (options->traceback) fprintf(ofp, "Report tracebacks\n");
  if (options->fopt) fprintf(ofp, "Report Fill Matrix\n");
  if (options->parameterout) fprintf(ofp, "Output Parameters\n");
  if (options->stockout) fprintf(ofp, "Produce Stockholm Output\n");
  if (options->modelfile != NULL) 
    fprintf(ofp, "Using modelfile: %s\n", options->modelfile);

  if (options->weights) {
     if (options->copt) {
	if (options->voronoi) {
	   printf("Using calculated voronoi weights\n");
	} else {
	   printf("Using calculated GSC weights\n");
	}
     } else {
	if (options->voronoi) {
	   printf("Using voronoi weights if weights not provided\n");
	} else {
	   printf("Using GSC weights if weights not provided\n");
	}
     }
  } else {
     printf("Sequences are unweighted\n");
  }
}

