/* hmm.c
 * Mon Apr 18 13:34:15 EDT 2005 [Boston]
 *
 * Replacement of Holmes' dpswalign.
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>
#include <ctype.h>

#include "squid.h"
#include "cfg.h"
#include "consan.h"
#include "dps.h"

#define dpM	0
#define dpX	1
#define dpY	2
#define HMMDP	3

/* Function: allocHmmDP, freeHmmDP 
 * mx[v][i][j] where v is dp matrix
 * 		     i is lenX
 * 		     j is lenY
 * */ 
void
allocHmmDP(int lenX, int lenY, double ****ret_mx) 
{
  double ***mx;
  int i,v;

  if ((mx = (double ***)malloc(HMMDP * sizeof(double **))) == NULL)
    Die("Malloc of HMM Matrix Failed!\n");
  for (v = 0; v < HMMDP; v++) {
    if ((mx[v] = (double **) malloc (lenX * sizeof (double *))) == NULL) 
      Die("Malloc of HMM Matrix LenX Failed!\n");
    if ((mx[v][0] = (double *) malloc (lenX * lenY * sizeof (double))) == NULL) 
	Die("Malloc of HMM Matrix Inner Mtx Failed!\n");
    for (i = 0; i < lenX; i++) {
      mx[v][i] = mx[v][0] + (i * lenY);
    }
  }
  *ret_mx = mx;
}

void
freeHmmDP(double ***mx)
{
  int v;

  for (v = 0; v < HMMDP; v++) {
    free(mx[v][0]);
    free(mx[v]);
  }
  free(mx);
}

/* Function: forwardHmmDP */
int
forwardHmmDP(SEQUENCE X, SEQUENCE Y, HMMMOD *model)
{
  double ***matx;
  double cursc;

 /* SetAlphabet(hmmNUCLEIC); */

  allocHmmDP(X->len, Y->len, &matx);

  /* Init(); */
  for (i = 0; i < X-len; i++) {
    for (k = 0; k < Y->len, k++) {
      matx[dpM][i][j] = -BIGINT;
      matx[dpX][i][j] = -BIGINT;
      matx[dpY][i][j] = -BIGINT;
    }
  }

  /* Fill(); */
  for (i = 0; i < X-len; i++) {
    for (k = 0; k < Y->len, k++) {
      /* M -> M | X | Y */
      cursc = DLogsum((matx[dpM][i-1][k-1] + emis(dpM) + trans(dpM)),
	  (matx[dpX][i-1][k] + emis(Ix) + trans (Ix)));
      cursc = DLogsum(cursc, (matx[dpY][i][k-1] + emis(Iy) + trans(Iy)));
      matx[dpM][i][k] = cursc;

      /* X -> M | X */
      cursc = DLogsum((matx[dpM][i-1][k-1] + emis(dpM) + trans(dpM)),
	  (matx[dpX][i-1][k] + emis(Ix) + trans (Ix)));
      matx[dpX][i][k] = cursc;
 
      /* Y -> M | Y */
      cursc = DLogsum((matx[dpM][i-1][k-1] + emis(dpM) + trans(dpM)),
	  (matx[dpY][i-1][k] + emis(Iy) + trans (Iy)));
      matx[dpY][i][k] = cursc;
           
    }
  }

  /* freeHmmDP(matx); */
}

/* Function: backwardHmmDP*/
int
backwardHmmDP(SEQUENCE X, SEQUENCE Y, HMMMOD *model)
{
  double ***matx;
  double cursc;

  allocHmmDP(X->len, Y->len, &matx);

  /* Init(); */
  for (i = 0; i < X-len; i++) {
    for (k = 0; k < Y->len, k++) {
      matx[dpM][i][j] = -BIGINT;
      matx[dpX][i][j] = -BIGINT;
      matx[dpY][i][j] = -BIGINT;
    }
  }

  /* Fill(); */
  for (i = X->len-1; i > 0; i--) {
    for (k = Y->len-1; k > 0, k--) {
      /* M -> M | X | Y */
      cursc = DLogsum((matx[dpM][i+1][k+1] + emis(dpM) + trans(dpM)),
	  (matx[dpX][i+1][k] + emis(Ix) + trans (Ix)));
      cursc = DLogsum(cursc, (matx[dpY][i][k+1] + emis(Iy) + trans(Iy)));
      matx[dpM][i][k] = cursc;

      /* X -> M | X */
      cursc = DLogsum((matx[dpM][i+1][k+1] + emis(dpM) + trans(dpM)),
	  (matx[dpX][i+1][k] + emis(Ix) + trans (Ix)));
      matx[dpX][i][k] = cursc;
 
      /* Y -> M | Y */
      cursc = DLogsum((matx[dpM][i+1][k+1] + emis(dpM) + trans(dpM)),
	  (matx[dpY][i+1][k] + emis(Iy) + trans (Iy)));
      matx[dpY][i][k] = cursc;
           
    }
  }

  /* freeHmmDP(matx); */
}

/* Function: buildPtable */
buildPtable(SEQUENCE X, SEQUENCE Y)
{
  forwardHmmDP();
  backwardHmmDP();
  /* Calculate Posterior Table */
}

/* Function: optaccDP */
optaccDP(SEQUENCE X, SEQUENCE Y, float **ptable)
{
  Init();
  Fill();
  Traceback();
}

/* Function: trainHmmDP */
trainHmmDP()
{
  /* for each example */
    /* input2trace */
    /* traceCount */
  /* Probify counts */
}
