/* pairwise.c 
 * Mon Feb 17 16:27:46 CST 2003
 *
 * Manipulation of datastructures for 
 * pairwise information, including
 * constraints.
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <strings.h>
#include <string.h>	/* memset */
#include <math.h>
#include <ctype.h> /* toupper */

#include "squid/squid.h"
#include "cfg.h"
#include "consan.h"
#include "alphabet.h"	/* Digitize */
#include "dps.h"
#include "trace.h"

int msa2seqpair(MSA *msa, int i, int j, char *conss, SEQPR **rnas);

/* Function: allocSeqPair, freeSeqPair,
 * 	 allocAlignment, freeAlignment,
 * 	 allocConstraints, freeConstraints,
 *
 * Date:     Wed Feb 19 16:04:12 CST 2003 [St Louis]
 *
 * Purpose: Allocate and initalized parts of
 * 	pairwise sequences datastructures
 *
 */
int
allocSeqPair(SEQPR **ret_seqs)
{
   SEQPR *seqs;

   if ((seqs = (SEQPR *) malloc(sizeof(SEQPR))) == NULL) 
      Die("Can't allocate SEQPR\n");

   seqs->sequence[SEQX] = NULL; 
   seqs->sequence[SEQY] = NULL; 

   seqs->alignment = NULL;
   seqs->c_info = NULL;

   *ret_seqs = seqs;
   return 1;
}
void
freeSeqPair(SEQPR *seqs)
{
   if (seqs->sequence[SEQX] != NULL) freeSequence(seqs->sequence[SEQX]);
   if (seqs->sequence[SEQY] != NULL) freeSequence(seqs->sequence[SEQY]);
   if (seqs->alignment != NULL) freeAlignment(seqs->alignment);
   if (seqs->c_info != NULL) freeConstraints(seqs->c_info); 
   free(seqs);
}

int
allocSequence(char *seq, char *name, char *desc, int len, char *ss, 
      SEQUENCE **ret_seq)
{
   SEQUENCE *sequence;

   /* Digitize Sequences */
   SetAlphabet(hmmNUCLEIC);

   if ((sequence = (SEQUENCE *) malloc(sizeof(SEQUENCE))) == NULL)
      Die("Can't allocate Alignment\n");

   sequence->len = len;
   sequence->name[0] = '\0';
   sequence->desc[0] = '\0';
   sequence->ss = NULL;
   sequence->seq = NULL;

   /* Sequence Information Defaults */
   if (seq != NULL) {
      sequence->seq = (char *)malloc(sizeof(char)*len+1);
      strncpy(sequence->seq, seq, len);
      sequence->seq[len] = '\0';
      sequence->dseq = DigitizeSequence(seq, len);
   }

   if (ss != NULL) {
      sequence->ss = (char *)malloc(sizeof(char)*len+1);
      strncpy(sequence->ss, ss, len);
      sequence->ss = ss;
   }
   
   /* Keep local copy */
   if (name != NULL) {
     strncpy(sequence->name, name, 63);
     sequence->name[64] = '\0';
   }
   if (desc != NULL) {
      strncpy(sequence->desc, desc, 127);
     sequence->desc[128] = '\0';
   }

   *ret_seq = sequence;
   return 1;
}

void
freeSequence(SEQUENCE *sequence)
{
   if (sequence->seq != NULL) free(sequence->seq);
   if (sequence->dseq != NULL) free(sequence->dseq);
   if (sequence->ss != NULL) free(sequence->ss);
   free(sequence);
}

int
allocAlignment(int length, float weight, ALIGN **linmnt)
{
   ALIGN *align;

   if ((align = (ALIGN *) malloc(sizeof(ALIGN))) == NULL)
      Die("Can't allocate Alignment\n");

   align->alen = length;
   align->prwgt = weight;
   align->aliid = -1.0;

   /* Allocate memory for this alignment */
   if ((align->ss = (char *) malloc(sizeof(char) * (length+2))) == NULL)
      Die("malloc ss failed");
   memset(align->ss, '.', length);
   align->ss[length] = '\0';

   if ((align->pins = (char *) malloc(sizeof(char) * (length+2))) == NULL)
     Die("malloc align pins failed");
   memset(align->pins, '.', length);
   align->pins[length] = '\0';

   if ((align->aseqs[SEQX] = (char *) malloc(sizeof(char) * (length+2))) == NULL)
      Die("malloc seqx failed");
   memset(align->aseqs[SEQX], '.', length);
   align->aseqs[SEQX][length] = '\0';

   if ((align->aseqs[SEQY] = (char *) malloc(sizeof(char) * (length+2))) == NULL)
      Die("malloc seqy failed");
   memset(align->aseqs[SEQY], '.', length);
   align->aseqs[SEQY][length] = '\0';

   *linmnt = align;
   return 1;
}
void 
freeAlignment(ALIGN *linement)
{
   if (linement->aseqs[SEQX] != NULL) free(linement->aseqs[SEQX]);
   if (linement->aseqs[SEQY] != NULL) free(linement->aseqs[SEQY]);
   if (linement->ss != NULL) free(linement->ss);
   if (linement->pins != NULL) free(linement->pins);
   free(linement);
}

void
makeGenericPair(SEQPR **sp, int lenX, int lenY) 
{
  SEQPR *seqpair;
  SEQUENCE *sX;
  SEQUENCE *sY;

  allocSeqPair(&seqpair);
  makeGenericSeq(&sX, lenX); 
  makeGenericSeq(&sY, lenY); 

  addSequence(sX, seqpair);
  addSequence(sY, seqpair);

  *sp = seqpair;
}

/* Generate a generic sequence pair with randomly 
 * generated sequences of length len */
void
makeGenericSeq(SEQUENCE **s, int len)
{
  char *sq;
  char *dsq;
  int i;
  SEQUENCE *sn;

  SetAlphabet(hmmNUCLEIC);

  /* Generate random sequence of length len */
  dsq = MallocOrDie ((len) * sizeof(char));
  for (i= 0; i < len; i++)
     dsq[i] = CHOOSE(4);
  sq = DedigitizeSequence(dsq, len);

  allocSequence(sq, NULL, NULL, len, NULL, &sn);
  
  *s = sn;
}

/* Function: addSequence
 *
 * Note: First time called will define as 'X'
 * 	Second time called will be 'Y'
 *
 * Throws error if you call more than twice.
 */
int
addSequence(SEQUENCE *sqn, SEQPR *seqpr) 
{
   if (seqpr->sequence[SEQX] == NULL) {
      seqpr->sequence[SEQX] = sqn;
   } else if (seqpr->sequence[SEQY] == NULL) {
      seqpr->sequence[SEQY] = sqn;
   } else {
      return 0;
   }
   return 1;
}

/* Function: readSequence 
 * Date:     Wed Feb 19 16:14:10 CST 2003 [St Louis]
 *
 * Purpose: grab from a file the frist sequence
 * 	and produce a sequence from it and add
 * 	that to a growing sequence pair.
 */
int
readSequence(char *filename, SEQPR *seqs)
{
   SQFILE *sqfp;
   SQINFO sqinfo;
   int sformat;
   char *seq;
   SEQUENCE *sq;

   /* Read input file into RNA array and filter for non-RNA residues */
   if ((sqfp = SeqfileOpen(filename, SQFILE_UNKNOWN, NULL)) == NULL) 
      Die("Failed to open sequence file %s\n", filename);

   /* Read in a sequence */
   if (!(ReadSeq(sqfp, sformat, &seq, &sqinfo)))
      Die("Failure to read sequence file %s\n!", filename);

   /* Standardize sequences */
   s2upper(seq);
   StripDegeneracy(seq);
   ToRNA(seq);

   if (!(allocSequence(seq, sqinfo.name, NULL, sqinfo.len, NULL, &sq))) 
      Die("Failure to build Sequence for %s\n!", sqinfo.name);

   FreeSequence(seq, &sqinfo);
   SeqfileClose(sqfp);

   if (!(addSequence(sq, seqs))) {
      freeSequence(sq);
      return 0;
   } else {
      return 1;
   }
}

/* Function: addAlignment
 */
int
addAlignment(ALIGN *aln, SEQPR *seqpr) 
{
   seqpr->alignment = aln;
   return 1;
}

/* Function: msa2pairwise
 * Date:     Thu Feb 27 10:27:43 CST 2003 [St Louis]
 *
 * Purpose: Given an MSA aligned pair 
 * 	produce the pairwise alignment 
 *
 * Returns:  -void -
 */
void
msa2pairwise(int msalen, char *ss, char *seqX, char *seqY, 
      float pairweight, ALIGN **ret_aln)
{
   ALIGN *aln;
   int i, newlen, j;
   int *ct;
   int debug = FALSE;

   /* Verify ss string */
   if (ss != NULL) {
     if (! KHS2ct(ss, msalen, FALSE, &ct)) {
       Warn("msa2pair structure string is inconsistent"); 
     }
   }

   /* Determine alignment length when all gap columns 
    * (ie portions of MSA where these two seqs are both gaps) 
    * are removed.*/
   newlen = 0;
   for (i = 0; i < msalen; i++) {
      if (!(isgap(seqX[i]) && isgap(seqY[i]))) {
	 newlen++;
      }
   }
   if (debug) printf("msalen %d newlen %d\n", msalen, newlen); fflush(stdout);
   allocAlignment(newlen, pairweight, &aln);

   /* Fix consensus structure string -- basepairs aligned to 
    * gaps don't make sense, so we've got to eliminate them. */
   for (i = 0; i < msalen; i++) {
      if (!(isgap(seqX[i]) && isgap(seqY[i]))) {
	/* Can't be bp if one of sequence is gap */
	if (ss != NULL) {
	  if (isgap(seqX[i]) || isgap(seqY[i])) {
	    if (ct[i] >= 0) {
	      ct[ct[i]] = -1;
	      ct[i] = -1;
	    }
	  } 
	}
      } else {	
	 /* Make sure this whole gap column doesn't 
	    align to a structure region. */
	if (ss != NULL) {
	  if (ct[i] >= 0) { ct[ct[i]] = -1; }
	}
      }
   }

   /* Copy MSA aligned sequences into pairwise alignment,
    * eliminating all gap columns */
   j = 0;
   for (i = 0; i < msalen; i++) {
     if (!(isgap(seqX[i]) && isgap(seqY[i]))) {
       aln->aseqs[SEQX][j] = seqX[i];
       aln->aseqs[SEQY][j] = seqY[i];
       if (ss != NULL) {
	 if (ct[i] < 0) aln->ss[j] = '.';
	 else if (ct[i] > i) aln->ss[j] = '>';
	 else aln->ss[j] = '<';
       } else {
	 aln->ss[j] = '.';
       }
       j++;
     }
   }
   aln->aseqs[SEQX][newlen] = '\0'; aln->aseqs[SEQY][newlen] = '\0';
   aln->ss[newlen] = '\0';

   if (ss != NULL) free(ct);

   alignID(aln);	/* Determine alignment identity */

   /* Quick check on lengths */
   if (newlen > aln->alen) *ret_aln = NULL;
   else *ret_aln = aln;
}

/* Function: aln2seqpair
 *
 * Purpose: Given a pairwise alignment (ALIGN)
 * 	dealign the sequences into a Sequence pair.
 */
void
aln2seqpair(ALIGN *aln, char *Xname, char *Yname, SEQPR **ret_seqs)
{
   SEQPR *pair;
   char *s;
   char name[64];
   int len;
   SEQUENCE *X;
   SEQUENCE *Y;

   /* Allocate Memory for datastructures */
   allocSeqPair(&pair);

   len = DealignedLength(aln->aseqs[SEQX]);
   dealignSequence(aln->aseqs[SEQX], aln->alen, &s);
   ToRNA(s);

   if (Xname != NULL) {
      strncpy(name, Xname, 62);
      allocSequence(s, name, NULL, len, NULL, &X);
   } else {
      allocSequence(s, NULL, NULL, len, NULL, &X);
   }
   addSequence(X, pair);
   free(s);

   len = DealignedLength(aln->aseqs[SEQY]); 
   dealignSequence(aln->aseqs[SEQY], aln->alen, &s);
   ToRNA(s);

   if (Yname != NULL) {
      strncpy(name, Yname, 62);
      allocSequence(s, name, NULL, len, NULL, &Y);
   } else {
      allocSequence(s, NULL, NULL, len, NULL, &Y);
   }
   addSequence(Y, pair);

   free(s);
   *ret_seqs = pair;
}

void
dealignSequence(char *original, int msalen, char **gapless)
{
   int rlen, nlen;
   char *new;

   new = (char *) malloc(sizeof(char) *msalen+1);

   for (nlen = rlen = 0; rlen < msalen; rlen++) {
      if (!(isgap(original[rlen]))) {
	 new[nlen] = original[rlen];
	 nlen++;
      }
   }
   new[nlen] = '\0'; new[msalen] = '\0';
   *gapless = new;
}

/* Function: copySequence, copyAlignment,
 * 		copySeqPair, copyCoordinates
 */
void
copySequence(SEQUENCE *from, SEQUENCE *to)
{
   allocSequence(from->seq, from->name, from->desc, 
	 	from->len, from->ss, &to);
}

void
copyAlignment(ALIGN *from, ALIGN *to)
{
   int i;

   if ((to = (ALIGN *) malloc(sizeof(ALIGN))) == NULL)
      Die("Can't allocate Alignment\n");

   to->alen = from->alen;
   to->prwgt = from->prwgt;
   to->aliid = from->aliid;

   /* Allocate memory for this alignment */
   if ((to->ss = (char *) malloc (sizeof(char) * from->alen+1)) == NULL)
      Die("malloc ss failed");

   if ((to->pins = (char *) malloc (sizeof(char) * from->alen+1)) == NULL)
      Die("malloc apins failed");

   if ((to->aseqs[SEQX] = (char *) malloc (sizeof(char) * from->alen+1)) == NULL)
      Die("malloc seqx failed");

   if ((to->aseqs[SEQY] = (char *) malloc (sizeof(char) * from->alen+1)) == NULL)
      Die("malloc seqy failed");

   for (i = 0; i < from->alen; i++) {
      to->aseqs[SEQX][i] = from->aseqs[SEQX][i];
      to->aseqs[SEQY][i] = from->aseqs[SEQY][i];
      to->ss[i] = from->ss[i];
      to->pins[i] = from->pins[i];
   }
   to->aseqs[SEQX][from->alen] = '\0';
   to->aseqs[SEQY][from->alen] = '\0';
   to->ss[from->alen] = '\0';
   to->pins[from->alen] = '\0';
}

void
copySeqPair(SEQPR *from, SEQPR *to)
{
   allocSeqPair(&to);
   copySequence(from->sequence[SEQX], to->sequence[SEQX]);
   copySequence(from->sequence[SEQY], to->sequence[SEQY]);

   if (from->alignment != NULL)
      copyAlignment(from->alignment, to->alignment);
   /*
   if (from->c_info != NULL) 
      copyConstraints(from->c_info, to->c_info);
      */
}

/* Function: printSeqPair
 * Date:     Wed Feb 19 13:34:31 CST 2003 [St Louis]
 */
void
printSeqPair(FILE *fp, SEQPR *seqs)
{
   fprintf(fp, "\nOK Boss! Here is what we know on this pair:\n");

   if (seqs->sequence[SEQX] != NULL) {
      fprintf(fp, "Sequence X: \n");
      printSequence(fp, seqs->sequence[SEQX]);
   } else {
     fprintf(fp, "Sequence X Unavailable \n");
   }
   if (seqs->sequence[SEQY] != NULL) {
      fprintf(fp, "Sequence Y: \n");
      printSequence(fp, seqs->sequence[SEQY]);
   } else {
     fprintf(fp, "Sequence Y Unavailable \n");
   }

   if (seqs->alignment != NULL) {
     printAlignment(fp, seqs->alignment);
   } else {
     fprintf(fp, "Structural Alignment Unavailable \n");
   }

   if (seqs->c_info != NULL) {
      printConstraints(fp, seqs->sequence[SEQX]->len, seqs->c_info, TRUE); 
   } else {
      fprintf(fp, "No constraint information provided\n");
   }
}

/* Function: printSequence()
 */
void   
printSequence(FILE *fp, SEQUENCE *seq)
{
   int i, j, start;

   if ((seq->desc != NULL) && (seq->name != NULL))
     fprintf(fp, "%s (%s)\n", seq->name, seq->desc);
   else if (seq->name != NULL) 
     fprintf(fp, "%s \n", seq->name);
   else 
     fprintf(fp, "No name available.\n");

   start = 0;
   printf("Length: %d\n", seq->len);
   if (seq->seq != NULL) {
     for (i = 0; i < seq->len; i++) {
       fprintf(fp, "%c", seq->seq[i]);
       if (i%40 == 39) { 
	 fprintf(fp, "\n"); 
	 if (seq->ss != NULL) {
	   for (j = start; j < i; j ++) {
	     fprintf(fp, "%c", seq->ss[j]);
	     if (j%40 == 39) { printf("\n\n"); }
	   }
	 }
	 start = i;
       }
     }
   }
   fprintf(fp, "\n");
}

/* Function: printAlignment()
 */
void   
printAlignment(FILE *fp, ALIGN *aln)
{
  char seqXbuf[51];
  char seqYbuf[51];
  char strucbuf[51];
  char pinsbuf[51];
  int  nchar;
  int  pos;

  fprintf(fp, "Alignment wgt: %f\tid: %f\n", aln->prwgt, aln->aliid);

  for (pos = 0; pos < aln->alen; pos += 50)
    {
      strncpy(seqXbuf,   aln->aseqs[SEQX] + pos, 50); seqXbuf[50] = '\0';
      strncpy(seqYbuf,   aln->aseqs[SEQY] + pos, 50); seqYbuf[50] = '\0';
      strncpy(strucbuf, aln->ss + pos,   50); strucbuf[50] = '\0';
      strncpy(pinsbuf, aln->pins + pos,   50); pinsbuf[50] = '\0';
      nchar = strlen(seqXbuf);
      
      fprintf(fp, "%4d %s %4d\n", pos+1, seqXbuf, pos + nchar);
      fprintf(fp, "%4d %s %4d\n", pos+1, seqYbuf, pos + nchar);
      fprintf(fp, "     %s\n", strucbuf);
      fprintf(fp, "     %s\n", pinsbuf);
      fputs("\n", fp);
    }
}

int
compareAlignments(ALIGN *given, ALIGN *calc, int USE_STRUCT, float *ret_score)
{
   float alignscore;

   int *ref;
   int apos;

   /* Sequence sanity check */

   /* Pairwise Alignment score */
   if (USE_STRUCT) {
      /* Pairwise Alignment score considering only paired residues */
      if (given->ss != NULL) {
	 ref = (int *) MallocOrDie(sizeof(int)*given->alen);
	 for (apos = 0; apos < given->alen; apos++) {
	    ref[apos] = (isgap(given->ss[apos])) ? FALSE : TRUE;
	 }
	 alignscore = CompareRefPairAlignments(ref, 
	       given->aseqs[SEQX], given->aseqs[SEQY], 
	       calc->aseqs[SEQX], calc->aseqs[SEQY]);
      } else {
	 alignscore = -1;
      }
      free(ref);

   } else {
      alignscore = ComparePairAlignments(given->aseqs[SEQX], 
	    given->aseqs[SEQY], calc->aseqs[SEQX], calc->aseqs[SEQY]);
   }

   *ret_score = alignscore;

   return 1;
}

/* Function: checkAlignment, checkSequence, checkSeqPair
 */
int
checkSequence(SEQUENCE *seq)
{
   int i;
   int v;
   char *dsq;

   /* Really basic sanity checks */
   if (seq->len < 1) return 0;

   /* Should check name and desc for valid info too */

   /* Check that sequence contains only RNA valid values */
   for (i = 0; i < seq->len; i++) {
     v = toupper(seq->seq[i]);
     /* if (strchr("ACGU", v) == NULL) return 0; */
   }
   /* Reverse digitize routine, do we get original sequence? */
   dsq = DedigitizeSequence(seq->dseq, seq->len);
   if (strcmp(dsq, seq->seq) != 0) return 0;

   /* If we've been given a secondary structure, check
    * it for sanity relative to both base pairings and 
    * coordination with this sequence 
    */
   if (seq->ss != NULL) {
      if (!(VerifyKHS(seq->name, seq->ss, FALSE))) return 0;
      if (!(khsSanity(seq->seq, seq->ss))) return 0;
   }
   return 1;
}

int
checkAlignment(ALIGN *aln)
{
   int i;
   char v, w;

   if (aln->alen < 1) return 0;
   if (aln->prwgt < 0.0) return 0;
   if (aln->aliid < 0.0) return 0;

   /* Check that sequence contains only RNA valid values */
   for (i = 0; i < aln->alen; i++) {
     v = toupper(aln->aseqs[SEQX][i]);
     w = toupper(aln->aseqs[SEQY][i]);
     /* Check that at most one of two sequences is a gap.
      * Check that if not a gap these characters are valid RNA alphabet.
      */
   }
  
   /* If secondary structure given, check it's integrity */
   if (aln->ss != NULL) {
      if (!(VerifyKHS("Alignment", aln->ss, FALSE))) return 0;
   }

   return 1;
}

/* Sun Oct  9 14:10:47 EDT 2005 [revised to utilize 
 * Sean's PairwiseIdentity in aligneval.c]
 */
int
alignID(ALIGN *aln)
{
   float pid;

   if (aln->alen < 1) return 0.;

   pid = PairwiseIdentity(aln->aseqs[SEQX], aln->aseqs[SEQY]);
   aln->aliid = pid;

   return 1;
}

int
checkSeqPair(SEQPR *sqpair)
{
   if (!(checkSequence(sqpair->sequence[SEQX]))) return 0;
   if (!(checkSequence(sqpair->sequence[SEQY]))) return 0;
   if (sqpair->alignment != NULL) {
      if (!(checkAlignment(sqpair->alignment))) return 0;
   }
   /*
   if (sqpair->c_info != NULL) {
      if (!(checkConstraints(sqpair->c_info))) return 0;
   }
   */
   return 1;
}

/* Function: msa2seqpair
 *
 * Date: Tue May 20 14:28:58 CDT 2003
 *
 * Purpose: Given two aligned sequences return a
 * SEQPR structure containing their alignment and their
 * dealigned information.
 *
 */
int
msa2seqpair(MSA *msa, int i, int j, char *conss, SEQPR **rnas)
{
   ALIGN *ralign;
   SEQPR *rna;

   /* We don't always have consensus structure, but if we
    * do we'd like to make sure it makes sense */
   if (conss != NULL) {
     if (!(VerifyKHS(msa->sqname[i], conss, TRUE) == TRUE)) {
       printf("Failed VerifyKHS in msa2seqpair\n"); 
       fflush(stdout);
       return 0;
     }
   }
   msa2pairwise(msa->alen, conss, msa->aseq[i], msa->aseq[j], 
       (msa->wgt[i] * msa->wgt[j]), &ralign);
   /* printAlignment(stdout, ralign); fflush(stdout);    */
   aln2seqpair(ralign, msa->sqname[i], msa->sqname[j], &rna);
   /* printSeqPair(stdout, rna); fflush(stdout);  */
   rna->alignment = ralign;
   *rnas = rna;
   return 1;
}

/* Function: printStockholm()
 * 
 * Purpose:  Print a sequence/structure representation.
 *
 * Args:     fp     - open file pointer to write to
 *           seqs   - pairwise sequence info
 *                    
 * Return:  void.                   
 */
void   
printStockholm(FILE *fp, SEQPR *seqs, char *infolines, int closestock)
{
  char seqXbuf[51]; char seqYbuf[51];
  char strucbuf[51];
  char pinbuf[51];

  char temp[64];
  int nameswap;

  ALIGN *alignment;
  int  nchar;
  int  pos;

  alignment = seqs->alignment;
  nameswap = FALSE;

  if (alignment != NULL) {
    fprintf(fp, "# STOCKHOLM 1.0\n\n");
    fprintf(fp, "#=GF SC\t %f\n", seqs->alignment->prwgt);
    /* Problem: PI means previous identifier to Pfam */
    fprintf(fp, "#=GF PI\t %f\n", seqs->alignment->aliid);
    if (seqs->c_info != NULL) {
      fprintf(fp, "#=GF ME\t %s  Num: %d  Win: %d  Cutoff: %0.2f\n", 
	  pinNAME[seqs->c_info->code], seqs->c_info->num, 
	  seqs->c_info->win, seqs->c_info->cutoff);
    }
    fprintf(fp, "\n");
    if (infolines != NULL) {
      fprintf(fp, "%s\n", infolines);
    }

    for (pos = 0; pos < alignment->alen; pos += 50) {
      strncpy(seqXbuf, alignment->aseqs[SEQX] + pos, 50); seqXbuf[50] = '\0';
      strncpy(seqYbuf, alignment->aseqs[SEQY] + pos, 50); seqYbuf[50] = '\0';

      if (alignment->ss != NULL) 
	strncpy(strucbuf, alignment->ss + pos, 50); 
      strucbuf[50] = '\0';

      /* Mark columns which were utilized for pins */
      if (seqs->c_info != NULL) 
	strncpy(pinbuf, alignment->pins + pos, 50); 
      pinbuf[50] = '\0';

      nchar = strlen(seqXbuf);

      if (strcmp(seqs->sequence[SEQX]->name, 
	    seqs->sequence[SEQY]->name) == 0) {
	strcpy(temp, seqs->sequence[SEQY]->name);
	strcpy(seqs->sequence[SEQY]->name, "self");
	nameswap = TRUE;
      }

      fprintf(fp, "%-20s\t%s\n", seqs->sequence[SEQX]->name, seqXbuf);
      fprintf(fp, "%-20s\t%s\n", seqs->sequence[SEQY]->name, seqYbuf);
      if (alignment->ss != NULL) 
	fprintf(fp, "#=GC SS_cons\t\t%s\n", strucbuf);
      if (seqs->c_info != NULL) {
	fprintf(fp, "#=GC PN \t\t%s\n", pinbuf);
      }
      fputs("\n", fp);
    }

    if (nameswap) 
      strcpy(seqs->sequence[SEQY]->name, temp);
    if (closestock) fputs("//\n\n", fp);
  }
}

/* Function: printAFASTA()
 * 
 * Purpose:  Print a pair of sequences in FASTA format
 * Note: Written to produce DART input (I. Holmes),
 *   therefore names are arbitrarily set.
 * 
 * Args:     fp     - open file pointer to write to
 *           seqs   - pairwise sequence info
 *                    
 * Return:  void.                   
 */
void   
printAFASTA(FILE *fp, SEQPR *seqs)
{
  char seqbuf[51];
  int  pos;

  /* Real name of sequence is in:
   * seqs->sequence[SEQX]->name 
   * but DART only accepts single word (alphnumeric, no symbols)
   * so to make things easier for later read in, we're using an
   * arbitrary holder here. */
  fprintf(fp, ">%s\n", "SEQX");  
  for (pos = 0; pos < seqs->sequence[SEQX]->len; pos+=50) {
    strncpy(seqbuf, seqs->sequence[SEQX]->seq + pos, 50); seqbuf[50] = '\0';
    fprintf(fp, "%s\n", seqbuf);
  }

  fprintf(fp, ">%s\n", "SEQY");

  for (pos = 0; pos < seqs->sequence[SEQY]->len; pos+=50) {
    strncpy(seqbuf, seqs->sequence[SEQY]->seq + pos, 50); seqbuf[50] = '\0';
    fprintf(fp, "%s\n", seqbuf);
  }
}

/* Function: printAln2Single()
 * 
 * Purpose:  Print a sequence/structure representation.
 *
 * Args:     fp     - open file pointer to write to
 *           seqs   - pairwise sequence info
 *                    
 * Return:  void.                   
 */
void   
printAln2Single(FILE *fp, SEQPR *seqs)
{
  char seqXbuf[51]; char seqYbuf[51];
  char strucbuf[51];
  char pinbuf[51];

  char temp[64];
  int nameswap;

  ALIGN *alignment;
  int  nchar;
  int  pos;

  alignment = seqs->alignment;
  nameswap = FALSE;

  if (alignment != NULL) {
    fprintf(fp, "# STOCKHOLM 1.0\n\n");
    fprintf(fp, "#=GF SC\t %f\n", seqs->alignment->prwgt);
    fprintf(fp, "\n");

    for (pos = 0; pos < alignment->alen; pos += 50) {
      strncpy(seqXbuf, alignment->aseqs[SEQX] + pos, 50); seqXbuf[50] = '\0';

      if (alignment->ss != NULL) 
	strncpy(strucbuf, alignment->ss + pos, 50); 
      strucbuf[50] = '\0';

      /* Mark columns which were utilized for pins */
      if (seqs->c_info != NULL) 
	strncpy(pinbuf, alignment->pins + pos, 50); 
      pinbuf[50] = '\0';

      nchar = strlen(seqXbuf);

      fprintf(fp, "%-20s\t%s\n", seqs->sequence[SEQX]->name, seqXbuf);
      if (alignment->ss != NULL) 
	fprintf(fp, "#=GR %s SS\t\t%s\n", seqs->sequence[SEQX]->name, strucbuf);
      fputs("\n", fp);
    }
    fputs("//\n\n", fp);

    fprintf(fp, "# STOCKHOLM 1.0\n\n");
    fprintf(fp, "#=GF SC\t %f\n", seqs->alignment->prwgt);
    fprintf(fp, "\n");
    for (pos = 0; pos < alignment->alen; pos += 50) {
      strncpy(seqYbuf, alignment->aseqs[SEQY] + pos, 50); seqYbuf[50] = '\0';

      if (alignment->ss != NULL) 
	strncpy(strucbuf, alignment->ss + pos, 50); 
      strucbuf[50] = '\0';

      fprintf(fp, "%-20s\t%s\n", seqs->sequence[SEQY]->name, seqYbuf);
      if (alignment->ss != NULL) 
	fprintf(fp, "#=GF %s SS\t\t%s\n", seqs->sequence[SEQY]->name, strucbuf);
      fputs("\n", fp);
    }
    fputs("//\n\n", fp);

    if (nameswap) 
      strcpy(seqs->sequence[SEQY]->name, temp);
  }
}

