/* constraints.c 
 * Mon Feb 17 16:27:46 CST 2003
 *
 * Manipulation of datastructures for constraint information.
 *
 * We read the constraints file into a linked list of COORDS.
 * We then convert this linked list into a CNSRNT set for
 * use in THE algorithm.  We can check on the integrity of
 * constraints both as a bag of COORDS and as a CNSRNT.
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <limits.h>
#include <math.h>
#include <string.h> /* strcmp */

#include "squid/squid.h"
#include "cfg.h"
#include "consan.h"
#include "alphabet.h"	/* Digitize */
#include "dps.h"

/* Function: allocConstraints, freeConstraints,
 *
 * Date:     Wed Feb 19 16:04:12 CST 2003 [St Louis]
 *
 * Purpose: Allocate and initalized parts of
 * 	pairwise sequences datastructures
 */
int
allocConstraints(CNSRNT **constraints) 
{
   CNSRNT *cons;

   if ((cons= (CNSRNT *) malloc(sizeof(CNSRNT))) == NULL) {
      return 0;
   }

   /* Constraint Information */
   cons->Yval = NULL;
   cons->code = PTYPES;
   cons->sL = NULL; cons->sR = NULL;
   cons->isXconstraint = NULL;
   cons->isYconstraint = NULL;

   *constraints = cons;
   return 1;
}

int
allocCons(CNSRNT **constraints, int Xlen, int Ylen) 
{
   CNSRNT *cons;

   if ((cons = (CNSRNT *) malloc(sizeof(CNSRNT))) == NULL) {
      return 0;
   }

   /* Constraint Information 
    * Must allocate to Xlen+1 because we'll need to keep n+1 possible
    * values for i because the length might be zero (in which case i
    * becomes j+1)!
    * */
   if ((cons->sL = (int *) malloc(sizeof(int) * (Xlen+1))) == NULL) 
      Die("Malloc of left\n");
   if ((cons->sR= (int *) malloc(sizeof(int) * (Xlen+1))) == NULL) 
      Die("Malloc of right\n");
   if ((cons->Yval = (int *) malloc(sizeof(int) * (Xlen+1))) == NULL) 
      Die("Malloc of Yvals\n");
   if ((cons->isXconstraint = (char *) malloc(sizeof(char) * (Xlen+1))) == NULL) 
      Die("Malloc of isXcon\n");
   if ((cons->isYconstraint = (char *) malloc(sizeof(char) * (Ylen+1))) == NULL) 
      Die("Malloc of isYcon\n");

   *constraints = cons;
   return 1;
}

void 
freeConstraints(CNSRNT *constraints)
{
   /* Free constraints contents */
   if (constraints->Yval != NULL) free(constraints->Yval);
   if (constraints->sL != NULL) free(constraints->sL);
   if (constraints->sR != NULL) free(constraints->sR);
   if (constraints->isXconstraint != NULL) free(constraints->isXconstraint);
   if (constraints->isYconstraint != NULL) free(constraints->isYconstraint);
   free(constraints);
}

void
loadConstraints(char *filename, SEQPR *seqs)
{
   COORDS *cordlist;
   CNSRNT *constraints;

   /* Setup Constraint information from this file */
   readConstraints(filename, seqs->sequence[SEQX]->name, 
	 	seqs->sequence[SEQY]->name, &cordlist);
   buildConstraints(seqs->sequence[SEQX]->len, seqs->sequence[SEQY]->len,
	 cordlist, GIVEN, &constraints);
   freeCoordList(cordlist);

   /* Set pointers appropriately */
   seqs->c_info = constraints;
}

/* Function: readConstraints
 * Date:     Tue Feb 18 13:41:31 CST 2003 [St Louis]
 *
 * Purpose: Given a filename, read in the constraints
 * 	and return an array of COORDS corresponding to them.
 *
 * FORMAT: 
 *     constraints are assumed to be given with one 
 *     constraint per line of the file, separated by a space,
 *     constraints file numbering assumes 1 ... length
 *
 * Args:     
 * 	filename	file to get constraints from
 * 	nameX		Name of the sequence we're calling X
 * 	nameY		Name of the sequence we're calling Y
 *
 * Returns:  
 *	 ret_segs	array of constraints (as COORDS)
 *	 (int)		number of constraints in array.
 */
int
readConstraints(char *filename, char *nameX, char *nameY, COORDS **ret_segs)
{
   FILE *ifp;
   int x, y, i;
   COORDS *head;
   int Xfirst = TRUE;		/* Which order are coords presented? */
   char idx[SQINFO_NAMELEN];
   char idy[SQINFO_NAMELEN];

   ifp = fopen(filename, "r");

   /* Read in identifying info line */
   fscanf(ifp, "%s %s \n", idx, idy);

   /* Associate a particular column with our "X" 
    * strcmp returns zero only if idy and nameX are absolutely identical
    * So it defaults to Xfirst unless the Y id line in the con file
    * ABSOLUTELY matches our nameX.
    * */
   if (strcmp(idy, nameX) == 0) { 
     printf("X not first\n"); fflush(stdout); 
     Xfirst = FALSE; 
   }

   /* Could/should probablly do more checking here -- 
    * what if neither name matches with our sequences?!
    * What if only one does?  */

   head = (COORDS *)initCoordList();

   i = 0;
   while (fscanf(ifp, "%d %d\n", &x, &y) == 2) {
     if (Xfirst) {
       iCoordListX(head, x-1, y-1, 0.0);
     } else {
       iCoordListX(head, y-1, x-1, 0.0);
     }
     i++;		/* keep count of how many constraints */
   }
   fclose(ifp);

   *ret_segs = head;
   return i;
}

/* Function: buildConstraints
 * Date:     Wed Feb 19 12:36:20 CST 2003 [St Louis]
 *
 * Purpose: Build segment edge mappings for a given set of constraints
 * 
 * Assumptions: assumes these constraints are ordered and 
 * 	passed the checkConstraints test.
 *
 * Args:     
 * 	Xlen	length of our X sequence
 * 	Ylen	length of our Y sequence
 * 	cons	constraints list to check (FREE'D HERE)
 * 	code	HOW were these constraints derived?
 *
 * Returns:  
 * 	ret_cons	constraints mapping
 */
void
buildConstraints(int Xlen, int Ylen, COORDS *cons, 
    int code, CNSRNT **ret_cons)
{
   int x, y;
   COORDS *cur, *prev;
   CNSRNT *cnts;

   /* printf("Xlen %d Ylen %d\n", Xlen, Ylen); */
   allocCons(&cnts, Xlen, Ylen);
   cnts->code = code;
   /* printCoordList(stdout, cons); */

   /* Need to build in some checks -- because this far we've not
    * done anything to verify that the constraints given are sane.
    */

   /* Defaults */
   for (x = 0; x <= Xlen; x++) {	
      cnts->Yval[x] = -1; 
   }

   /* Set up mapping of X to Y */
   cur = cons->next; prev = cons;
   for (x = 0; x <= Xlen; x++) {
     /* Current position is a constraint */
     if ((cur != NULL) && (cur->posX == x)) {	
       cnts->isXconstraint[x] = TRUE;
         cnts->Yval[x] = cur->posY; 
	 /* If first constraint, left edge is by def 0 */
	 if (prev->posY == -1) cnts->sL[x] = 0;
	 else cnts->sL[x] = prev->posY;
	 prev = cur; cur = cur->next;	/* Next coordinate in list */
	 /* If last constraint, right edge is by def Xlen-1 */
	 if (cur == NULL) cnts->sR[x] = Ylen-1;
	 else cnts->sR[x] = cur->posY;
      } else {
         cnts->Yval[x] = -1; 
	 cnts->isXconstraint[x] = FALSE;
	 /* If left of first constraint, left edge is by def 0 */
	 if (prev->posY == -1) cnts->sL[x] = 0;
	 else cnts->sL[x] = prev->posY;
	 /* If right of last constraint, right edge is by def Ylen-1 */
         if (cur == NULL) cnts->sR[x] = Ylen-1;
	 else cnts->sR[x] = cur->posY;
      }
   }
   
   /* Label positions in Y if constraints */
   cur = cons->next; prev = cons;
   for (y = 0; y <= Ylen; y++) {	
      if ((cur != NULL) && (cur->posY == y)) {
        cnts->isYconstraint[y] = TRUE;
	prev = cur; cur = cur->next;	/* Next item in list */
      } else {
        cnts->isYconstraint[y] = FALSE;
      }
   }

   *ret_cons = cnts;
}

/* Function: gatherConstraints
 * Date: RDD, Mon Oct  4 15:51:54 CDT 2004 [St Louis]
 *
 * Purpose: Given a set of constraints, extract the 
 * 	pins this represents
 *
 * Args:
 *   cons	constraints to extract pins from
 *   head	list of pins generated (allocated here; free elsewhere)
 *
 * Returns: 
 *    number of possible pins
 */
int
gatherConstraints(CNSRNT *cons, int Xlen, COORDS **ret_head)
{
  int i, num;                /* alignment coordinates */
  COORDS *head;

  head = initCoordList();

  for (i = 0; i < Xlen; i++) {
    if (cons->isXconstraint[i]) {
      iCoordListX(head, i, cons->Yval[i], 0.0);
      num++;
    }
  }

  *ret_head = head;
  return num;
}

void
setCNTMethod(CNSRNT *cons, int num, int win, float cutoff) 
{
  cons->num = num;
  cons->win = win;
  cons->cutoff = cutoff;
}

void
printCNTMethod(int code)
{
  switch (code) {
    case GIVEN: 
      printf("Using GIVEN constraints");
      break;
    case XBEST: 
      printf("Using XBEST constraints");
		break;
    case QUALITY: 
      printf("Using QUALITY constraints");
		break;
    case SPACED: 
      printf("Using SPACED constraints");
		  break;
    case QRADIUS: 
      printf("Using QRADIUS constraints");
		 break;
    case GALIGN: 
      printf("Using GALIGN constraints");
		  break;
    case PTYPES: 
      printf("Unspecified constraints");
		 break;
  }
}

/* Function: printConstraints 
 * Date:     Wed Feb 19 13:34:31 CST 2003 [St Louis]
 *
 * Purpose: debugging function, print constraints
 * 
 * Args:     
 * 	cons	Constraint information
 * 	print_map	Do we also want to print mappings?
 *
 * Returns:  -void-
 */
void
printConstraints(FILE *ofp, int lenX, CNSRNT *cons, int print_map)
{
   int i;

   printf("Constraints:\n");
   printCNTMethod(cons->code);
   for (i = 0; i < lenX; i++) {
      if (cons->isXconstraint[i]) 
        fprintf(ofp, "%d:%-d ", i, cons->Yval[i]);
   }
   printf("\n");

   if (print_map) {
      for (i = 0; i < lenX; i++) {
	 if (cons->isXconstraint[i]) 		/* Mark constraints */
	    fprintf(ofp, "i* %d sL %d sR %d \n", i, cons->sL[i], cons->sR[i]);
	 else
	    fprintf(ofp, "i %d sL %d sR %d \n", i, cons->sL[i], cons->sR[i]);
      } 
      /* For i = lenX we have an edge value in our matrix: */
      if (cons->isXconstraint[i]) 		/* Mark constraints */
	fprintf(ofp, "E i* %d sL %d sR %d \n", i, cons->sL[i], cons->sR[i]);
      else
	fprintf(ofp, "E i %d sL %d sR %d \n", i, cons->sL[i], cons->sR[i]);

   }
}

/* Regression Test */

  int
checkConstraints(ALIGN *align, CNSRNT *cinfo)
{
  int i;                /* alignment coordinates */
  int xpos, ypos;       /* sequence coordinates */

  xpos = 0; ypos = 0;

  for (i = 0; i < align->alen; i++) {
    /* If we've got legal characters (not gaps)! */
    if (strchr(Alphabet,
	  (char)toupper((int)align->aseqs[SEQX][i])) != NULL) {
      if (strchr(Alphabet,
	    (char)toupper((int)align->aseqs[SEQY][i])) != NULL) {
	/* Then we've got a possible pin! */
	if (cinfo->isXconstraint[xpos]) {
	  if (cinfo->Yval[xpos] != ypos) {
	    printf("Here's the problem ALIGN: %d %d %d\n", xpos, ypos, i);
	    return 0;
	  }
	}
	ypos++;
      } else {
	/* If we think X is a constraint but it aligns to a gap */
	if (cinfo->isXconstraint[xpos]) {
	  printf("Here's the problem X only: %d %d %d\n", xpos, ypos, i);
	  return 0;
	}
      }
      xpos++;
    } else if (strchr(Alphabet,
	  (char)toupper((int)align->aseqs[SEQY][i])) != NULL) {
      /* If we think Y is a constraint but it aligns to a gap */
      if (cinfo->isYconstraint[ypos]) {
	printf("Here's the problem Y only: %d %d %d\n", xpos, ypos, i);
	return 0;
      }
      ypos++;
    }
  }
  return 1;
}

