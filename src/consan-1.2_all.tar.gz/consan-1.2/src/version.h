#define PACKAGE     "Sankoff"
#define RELEASE     "0.1"
#define RELEASEDATE "in progress"
#define COPYRIGHT   "Copyright (C) 2003 HHMI/Washington University School of Medicine"
#define LICENSE     "Freely distributed under the GNU General Public License (GPL)"
#define BANNER	    "Sankoff: Full Implementation of Sankoff 1985"

