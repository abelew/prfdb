/* posteriors.c */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h> /* toupper */
#include <string.h> /* strchr */
#include <math.h> /* log */

#include "squid.h"
#include "cfg.h"
#include "consan.h"
#include "alphabet.h"
#include "options.h"

/* Function: getOAlign
 * Purpose:
 *   Given posttable, calculate opt acc alignment 
 *   (This is the Holmes' DP algorithm)
 * Args:
 * Returns:
 *   ret_oalign	optimal accuracy alignment
 *   boolean of failure/success
 */
int
getOAlign(float **ptable, ALIGN **ret_align)
{
  /* To be written, this is what Holmes' code 
   * does, so we really only need this for
   * completeness. */
  return 0;
}

/* Function: getPTable
 * Date: Fri Apr  1 16:02:07 EST 2005 [Boston]
 * Purpose:
 *   Given an alignment, calculate posteriors 
 * Args:
 *   align	given alignment
 * Returns:
 *   posttable	posterior table
 *   boolean of failure/success
 */
int
getPTable(ALIGN *align, float ***posttable)
{
  SEQPR *spair;
  SEQPR *tmp;

  aln2seqpair(align, "SEQX", "SEQY", &spair);
  runHolmes(spair, FALSE, TRUE, posttable, &tmp);
  freeSeqPair(tmp);
  freeSeqPair(spair);
  return 1;
}

/* Function: runHolmes 
 *
 * Purpose:  read in posterior table & opt acc alignment
 *   Expects output format of I. Holmes' dpswalign
 *   which is 2D table with first sequence as columns
 *
 * NOTE: Needs to check for existance of DART first!
 * DART Options: 
 * -oa says give us optimal accuracy alignment (default is Viterbi)
 * -pt <PREFIX> says produce posterior table file with this prefix 
 *
 * Args:
 *
 * Returns:  
 *   TRUE if parsed properly; FALSE otherwise
 */
void
runHolmes(SEQPR *spair, int verbose, int cleanup, float ***posttable, 
    	SEQPR **ret_opair)
{
  FILE *dfp;
  char command[1028];
  float **ptable;
  MSAFILE *sfp2; MSA *optmsa;
  ALIGN *optalign;
  SEQPR *opair;
  char tfile[200];
  char toutfile[200];
  char pfile[200];
  char rnum[32];
  double rand;
  int debug = FALSE;

  sre_srandom(time(0));
  opair = NULL;

  if (verbose) { printf("In runHolmes\n%s\n%s\n", DARTLOCATION, SCRATCH); }

  /* We need random names for temp files if they
   * are to work on the cluster */
  rand = sre_random();
  strcpy(tfile, SCRATCH);
  sprintf(rnum, "t%03d", (int)(102432 * rand));
  strcat(tfile, rnum);
  strcat(tfile, ".tmp\0");
  if (debug) printf("%s\n", tfile); fflush(stdout);

  /* Build input file to dart */
  dfp = fopen(tfile, "w");
  printAFASTA(dfp, spair);
  fflush(dfp);
  fclose(dfp);

  rand = sre_random();
  strcpy(pfile, SCRATCH);
  sprintf(rnum, "p%03d", (int)(104726 * rand));
  strcat(pfile, rnum);
  if (debug) printf("%s\n", pfile);

  rand = sre_random();
  strcpy(toutfile, SCRATCH);
  sprintf(rnum, "o%03d", (int)(103891 * rand));
  strcat(toutfile, rnum);
  strcat(toutfile, ".tmp\0");
  if (debug) printf("%s\n", toutfile);

  /* Run DART */
  dfp = fopen(toutfile, "w");
  fprintf(dfp, "# STOCKHOLM 1.0\n\n");
  fflush(dfp);
  fclose(dfp);
  sprintf(command, "%s -oa -pt %s %s >> %s", 
      	DARTLOCATION, pfile, tfile, toutfile); 
  if (debug) printf("%s\n", command); 
  system(command);

  /* Read in posterior table */
  sprintf(command, "%s-SEQX-SEQY", pfile);
  if (debug) printf("%s\n", command);
  readPosteriors(command, spair->sequence[SEQX]->len, 
      spair->sequence[SEQY]->len, &ptable);
  if (verbose)
    printPosteriors(ptable, spair->sequence[SEQX]->len,
	spair->sequence[SEQY]->len);
  *posttable = ptable;

  /* Get opt acc alignment */
  if ((sfp2 = MSAFileOpen(toutfile, SQFILE_UNKNOWN, NULL)) == NULL)
    Die("Failed to open dart output\n");
  if ((optmsa = MSAFileRead(sfp2)) != NULL) {
    standardizeMSA(optmsa);
    msa2pairwise(optmsa->alen, NULL, optmsa->aseq[0],
	optmsa->aseq[1], 1.0, &optalign);
    aln2seqpair(optalign, spair->sequence[SEQX]->name, 
	spair->sequence[SEQY]->name, &opair);
    addAlignment(optalign, opair);
    if (verbose) printSeqPair(stdout, opair);
  } else {
    opair = NULL;
  }
  MSAFree(optmsa);
  MSAFileClose(sfp2);

  /* Remove temporary files created by DART */
  if (cleanup) {
    sprintf(command, "rm %s-SEQX-SEQY %s %s", pfile, tfile, toutfile);
    if (debug) printf("%s\n", command);
    system(command);
  }

  *ret_opair = opair;
}

/******************* Posterior Table *******************/
/* Function: readPosteriors 
 * Date:     RDD, Sat Jul 10 13:24:55 CDT 2004
 *
 * Purpose:  read in posterior table 
 *   Expects output format of I. Holmes' dpswalign
 *   which is 2D table with first sequence as columnss
 *
 * Args:
 *   filename	name of posterior file (e.g. from I. Holmes)
 *   columns	number of columns
 *   rows	number of rows 
 *   ret_table	posterior table read in, allocated here (free elsewhere)
 *
 * Returns:  
 *   TRUE if parsed properly; FALSE otherwise
 */
int
readPosteriors (char *filename, int columns, int rows, float ***ret_table)
{
  FILE *ifp;
  float tmp;
  float **ptable;
  int i, j;

  /* Allocate table to appropriate size */
  if ((ptable = (float **) malloc (rows * sizeof(float *))) == NULL)
    	Die("malloc columns failed");
  for (i = 0; i < rows; i++) {
    if ((ptable[i] = (float *) malloc (columns * sizeof(float))) == NULL) 
      Die("malloc rows failed");
  }

  /* open file pointer to posterior table */
  ifp = fopen(filename, "r");

  for (i = 0; i < rows; i++) {
    for (j = 0; j < columns; j++) {
      fscanf(ifp, "%e ", &tmp);
      ptable[i][j] = tmp;
    }
    fscanf(ifp, "\n");
  }

  fclose(ifp);
  *ret_table = ptable;

  return 1;
}

void
freePosteriors(float **ptable, int rows)
{
  int i;

  for (i = 0; i < rows; i++) {
    free(ptable[i]);
  }
  free(ptable);
}

/* Function: printPosteriors 
 * Date:     RDD, Sat Jul 10 13:29:41 CDT 2004
 *
 * Purpose:  print out the posterior table 
 *
 * Args:
 *   ptable	posterior table
 *   columns	number of columns
 *   rows	number of rows 
 *
 * Returns:  -void-
 */
void
printPosteriors(float **ptable, int columns, int rows)
{
  int i, j;

  for (j = 0; j < columns; j++) {
      printf("%d\t", j);
  }
  printf("\n");

  for (i = 0; i < rows; i++) {
    for (j = 0; j < columns; j++) {
      printf("%-10.9f\t", ptable[i][j]);
    }
    printf("\n");
  }
}

void
printPost2column(float **ptable, int columns, int rows)
{
  int i, j;

  for (i = 0; i < rows; i++) {
    for (j = 0; j < columns; j++) {
      printf("%d\t%d\t%e\n", i, j, ptable[i][j]);
    }
    printf("\n");
  }
}

/* Function: scoreList
 * Date: RDD, Fri Sep  3 11:35:09 CDT 2004 [St Louis]
 *
 * Purpose: Given a set of positions (pins), 
 * 	score them according to our posterior table
 *
 * Args:
 *   head	head of list of positions
 *   ptable	posterior table
 *
 * Returns:  void
 */
void
scoreList(COORDS *head, float **ptable)
{
  COORDS *curpin;

  curpin = head;
  while (curpin->next != NULL) {
    curpin = curpin->next;
    /* Recall that I. Holmes table is in Y/X order */
    curpin->score = ptable[curpin->posY][curpin->posX];
  }
}

void
testPosteriors(float **ptable, int columns, int rows, ALIGN *given, 
    PSTATS *ret_stats)
{
  int i,j, idx;
  COORDS *alignset;

  /* Convert alignment into "correct" pins */
  align2pins(given, &alignset);

  /* Check each entry in ptable */
  for (i = 0; i < rows; i++) {
    for (j = 0; j < columns; j++) {
      idx = (int)((ptable[i][j] * 100) + 0.5);
      ret_stats->totalp[idx]++;
      if (inList(alignset, i, j)) {
        ret_stats->tcorr[idx]++;
      }
      /* printf("i %d j %d: %1.4f %d\n", i, j, ptable[i][j], idx); */
    }
  }
  freeCoordList(alignset);
}

