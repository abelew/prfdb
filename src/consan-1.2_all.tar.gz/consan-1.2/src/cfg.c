/* cfg.c
 * RDD, Fri Feb  7 15:43:58 CST 2003 [St Louis]
 * 
 * Manipulation of a pairSCFG as a datastructure
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include "squid/squid.h"
#include "cfg.h"

/* Function: allocModel, freeModel
 * Date: Thu May  8 13:58:25 CDT 2003 [St Louis]
 *
 * Args: 
 * 	ret_cfg	model to allocate
 *
 * Returns:
 * 	TRUE if successful; FALSE otherwise
 */
int
allocModel(MODEL **ret_cfg)
{
   MODEL *model;

   model = (MODEL *)malloc(sizeof(MODEL));
   model->grammar = STA;	/* The default grammar! */

   allocImod(&(model->imod));
   allocFmod(&(model->fmod));

   *ret_cfg = model;
   return 1;
}

void
allocImod(INTMOD *imod)
{
   imod->transitions = (int *)malloc(sizeof(int)*NTRANS); 
   imod->emissions = (int *)malloc(sizeof(int)*ECOUNT); 
}

void 
allocFmod(PROBMOD *fmod)
{
   fmod->transitions = (float *)malloc(sizeof(float)*NTRANS); 
   fmod->emissions = (float *)malloc(sizeof(float)*ECOUNT); 
}

void
freeImod(INTMOD *imod)
{
   free(imod->emissions);
   free(imod->transitions);
}

void
freeFmod(PROBMOD *fmod)
{
   free(fmod->emissions);
   free(fmod->transitions);
}

void
freeModel(MODEL *cfg)
{
   freeImod(&(cfg->imod));
   freeFmod(&(cfg->fmod));
   free(cfg);
}

/* Function: ZeroModel, zeroImod, zeroFmod
 * Date: Thu May  8 14:51:12 CDT 2003 [St Louis]
 *
 * Args:
 *     cfg	model to zero
 *
 * Returns:
 */
void
ZeroModel(MODEL *cfg)
{
   zeroImod(&(cfg->imod));
   zeroFmod(&(cfg->fmod));
}

void
zeroImod(INTMOD *imod)
{
   int i;

   for (i = 0; i < NTRANS; i++) {
      imod->transitions[i] = 0;
   }
   for (i = 0; i < ECOUNT; i++) {
      imod->emissions[i] = 0;
   }
}

void
zeroFmod(PROBMOD *fmod)
{
   int i;

   for (i = 0; i < NTRANS; i++) {
      fmod->transitions[i] = 0.;
   }
   for (i = 0; i < ECOUNT; i++) {
      fmod->emissions[i] = 0.;
   }
}

/* Function: equalModel, equalImod, equalFmod
 * Date: Thu May 29 15:52:38 CDT 2003 [St Louis]
 *
 * Purpose: Confirm that two models are identical.
 * 	- For integers we can do simple equals checks.
 * 	- For floats can we be so strict or should we
 * 	allow a little slop?  (approximately equal)
 *
 * Args:
 * 	mod1, mod2	Models to compare	
 *
 * Returns:	
 * 	TRUE	 if models are identical
 * 	FALSE	 otherwise
 */
int
equalModel(MODEL *mod1, MODEL *mod2)
{
   if (mod1->grammar != mod2->grammar) return 0;
   if (equalImod(&(mod1->imod), &(mod2->imod)))
     if (equalFmod(&(mod1->fmod), &(mod2->fmod)))
	return 1;
   return 0;
}

int
equalImod(INTMOD *imod1, INTMOD *imod2)
{
   int i;

   for (i = 0; i < NTRANS; i++) {
      if (imod1->transitions[i] != imod2->transitions[i]) return 0;
   }
   for (i = 0; i < ECOUNT; i++) {
      if (imod1->emissions[i] != imod2->emissions[i]) return 0;
   }
   return 1;
}

int
equalFmod(PROBMOD *fmod1, PROBMOD *fmod2)
{
   int i;

   for (i = 0; i < NTRANS; i++) {
      if (fmod1->transitions[i] != fmod2->transitions[i]) return 0;
   }
   for (i = 0; i < ECOUNT; i++) {
      if (fmod1->emissions[i] != fmod2->emissions[i]) return 0;
   }
   return 1;
}

/* Function: CopyModel, copyImod, copyFmod
 * Date: Thu May  8 14:59:10 CDT 2003 [St Louis]
 *
 * Args:
 * 	from	original model
 * 	to	copy to produce 
 *
 * Returns:	
 */
int
CopyModel(MODEL *from, MODEL *to)
{
   /* Right now we'll assume that the location we want
    * to copy this to has already been allocated to the
    * same type of emission matrix.  If not, we can't
    * copy and should return an error.
    */
   if (to->grammar != from->grammar) return 0;

   copyImod(&(from->imod), &(to->imod));
   copyFmod(&(from->fmod), &(to->fmod));
   return 1;
}

void
copyImod(INTMOD *from, INTMOD *to)
{
   int i;

   for (i = 0; i < NTRANS; i++) {
      to->transitions[i] = from->transitions[i];
   }
   for (i = 0; i < ECOUNT; i++) {
      to->emissions[i] = from->emissions[i];
   }
}

void
copyFmod(PROBMOD *from, PROBMOD *to)
{
   int i;

   for (i = 0; i < NTRANS; i++) {
      to->transitions[i] = from->transitions[i];
   }
   for (i = 0; i < ECOUNT; i++) {
      to->emissions[i] = from->emissions[i];
   }
}

/* Function: addModel, addImod, addFmod
 * Date: Thu May  8 14:51:12 CDT 2003 [St Louis]
 *
 * Args:
 *     cfg	model to zero
 *
 * Returns:
 */
void
addModel(MODEL *tot, MODEL *add)
{
   addImod(&(tot->imod), &(add->imod));
   addFmod(&(tot->fmod), &(add->fmod));
}

void
addImod(INTMOD *tot, INTMOD *add)
{
   int i;

   for (i = 0; i < NTRANS; i++) {
      tot->transitions[i] += add->transitions[i];
   }
   for (i = 0; i < ECOUNT; i++) {
      tot->emissions[i] += add->emissions[i];
   }
}

void
addFmod(PROBMOD *tot, PROBMOD *add)
{
   int i;

   printf("THERE!\n\n"); fflush(stdout);
   for (i = 0; i < NTRANS; i++) {
     printf("%d\n", i); fflush(stdout);
      tot->transitions[i] += add->transitions[i]; 
   }
   printf("THERE!\n\n"); fflush(stdout);
   for (i = 0; i < ECOUNT; i++) {
      tot->emissions[i] += add->emissions[i];
   }
   printf("THERE!\n\n"); fflush(stdout);
}

/* Functions: makeScoringModel 
 * Date: Sun Feb 16 17:42:22 CST 2003 [St Louis]
 *
 * Purpose: Use standard Nussionv +1 scoring
 *
 * Returns: void
 */
void
makeScoringModel(INTMOD *sc)
{
   int i, j, k, l;
   char ci, cj, ck, cl;

   for (i=0; i < NTRANS; i++) {
      sc->transitions[i] = 0;
   }
   for (i=0; i < ALPHA; i++) {
      sc->emissions[eSS(i)] = 0;
   }
   for (i=0; i < ALPHA; i++) {
      ci = baseNAME[i][0];
      for (j=0; j < ALPHA; j++) {
	 cj = baseNAME[j][0];
	 for (k=0; k < ALPHA; k++) {
	    ck = baseNAME[k][0];
	    for (l=0; l < ALPHA; l++) {
	       cl = baseNAME[l][0];
	       if (isRNAComplement(ci,cj, TRUE)) {
		  if (isRNAComplement(ck,cl, TRUE)) {
		     sc->emissions[ePR(idx(i,j),idx(k,l))] = 4;
		  } else {
		     sc->emissions[ePR(idx(i,j),idx(k,l))] = 2;
		  }
	       } else {
		  if (isRNAComplement(ck,cl, TRUE)) {
		     sc->emissions[ePR(idx(i,j),idx(k,l))] = 2;
		  }
	       }
	    }
	    if (isIdentical(ci,ck)) {
	       sc->emissions[eAL(i,k)] = 1;
	    } else {
	       sc->emissions[eAL(i,k)] = 0;
	    }
	 }
      }
   }
}

/* Functions: handCodedModel 
 * Date: Tue Feb 18 15:51:38 CST 2003 [St Louis]
 *
 * Purpose: Use set of hard coded probabilities
 *  	for model parameters
 *
 * Returns: void
 */
void 
handCodedModel(INTMOD *sc)
{
   int i, j, k, l;
   float pairs[4][4];

   hcTransNUS(sc);

   /* Pairs probabilities : from conus's unaY16S.mod */
   pairs[ntA][ntA] = .0020;
   pairs[ntA][ntC] = .0022;
   pairs[ntA][ntG] = .0038;
   pairs[ntA][ntU] = .1334; 
   pairs[ntC][ntA] = .0011;
   pairs[ntC][ntC] = .0007;
   pairs[ntC][ntG] = .2499;
   pairs[ntC][ntU] = .0013;
   
   pairs[ntG][ntA] = .0036;
   pairs[ntG][ntC] = .2818;
   pairs[ntG][ntG] = .0016;
   pairs[ntG][ntU] = .0738;
   
   pairs[ntU][ntA] = .1622;
   pairs[ntU][ntC] = .0014;
   pairs[ntU][ntG] = .0773;
   pairs[ntU][ntU] = .0037;
   
   for (i=0; i < ALPHA; i++) {
      for (j=0; j < ALPHA; j++) {
	 for (k=0; k < ALPHA; k++) {
	    for (l=0; l < ALPHA; l++) {
	       sc->emissions[ePR(idx(i,j),idx(k,l))] = 
		  		asIntLog(pairs[i][j] * pairs[k][l]);
	       if (i == k) sc->emissions[eAL(i,k)] = asIntLog(0.22);
	       else sc->emissions[eAL(i,k)] = asIntLog(0.01);
	    }
	 }
      }
   }
}

