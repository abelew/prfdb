/* pins.c 
 *
 * Keeping pins as a linked list of corresponding
 * pin positions.  The coordinate system of the pins
 * is each sequences' native coordinates (not the alignment).
 *
 * COORDS defined in consan.h
 * PSTATS defined in consan.h
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h> /* toupper */
#include <string.h> /* strchr */
#include <math.h> /* log */

#include "squid.h"
#include "cfg.h"
#include "consan.h"
#include "alphabet.h"
#include "options.h"

/* Function: initCoordList, freeCoordList,
 * Date:     Sat Jul 10 13:52:07 CDT 2004
 *
 * Note: As written this behaves very much like
 *   the trace_s structure -- the head node is empty
 *   and is a place holder.
 *
 * Purpose: Management of lists of coordinates (pins)
 */
  COORDS *
initCoordList(void)
{
  COORDS *head;

  if ((head = (COORDS *) malloc(sizeof(COORDS))) == NULL)
    Die("Malloc of contraint array failed\n");

  head->posX = -1;
  head->posY = -1;
  head->score = 0.0;
  head->correct = FALSE;
  head->next = NULL;
  head->prev = NULL;

  return head;
}

COORDS *
newCoord(int posX, int posY, float score)
{
  COORDS *head;

  if ((head = (COORDS *) malloc(sizeof(COORDS))) == NULL)
    Die("Malloc of contraint array failed\n");

  head->posX = posX;
  head->posY = posY;
  head->score = score;
  head->correct = FALSE;
  head->next = NULL;
  head->prev = NULL;

  return head;
}

void
destroyCoord(COORDS *cons)
{
  free(cons);
  cons = NULL;
}

  void
freeCoordList(COORDS *cons)
{
  COORDS *cur;
  COORDS *nxt;

  cur = cons;
  while (cur != NULL) {
    nxt = cur->next;
    free(cur);
    cur = nxt;
  }
  cons = NULL;
}

  void
copyCoordinates(COORDS *from, COORDS *to)
{
  to->posX = from->posX;
  to->posY = from->posY;

  to->score = from->score;
  to->correct = from->correct;
}

  void
printCoordList(FILE *ofp, COORDS *head, int withscore)
{
  COORDS *cur;

  cur = head->next;
  fprintf(ofp, "\n");
  while (cur != NULL) {
    /* Stick to convention that output refers to 
     * positions 1 to L rather than C convention of 0 to L-1 */
    fprintf(ofp, "%d:%-d ", cur->posX+1, cur->posY+1);
    if (withscore) fprintf(ofp, "(%f) ", cur->score);
    cur = cur->next;
  }
  fprintf(ofp, " END\n");
}

 int 
countCoordList(COORDS *head)
{
  COORDS *cur;
  int cnt;

  cnt = 0;
  cur = head->next;
  while (cur != NULL) {
    cnt++;
    cur = cur->next;
  }
  return cnt;
}

/* Function:  attachCoordList
 * Date:     Sat Jul 10 13:52:07 CDT 2004
 *
 * Purpose: manage insertion of new data
 *
 * Args: 
 *   parent	who you want to be the parent of new node
 *   posX, posY	coordinates of new pin
 *
 * Returns:
 *   pointer to the new node
 */
  COORDS *
attachCoordList(COORDS *parent, int posX, int posY, float score)
{
  COORDS *current;

  if ((current = (COORDS *) malloc(sizeof(COORDS))) == NULL)
    Die("Malloc of contraint array failed\n");
  current->posX = posX;
  current->posY = posY;
  current->score = score;
  current->correct = FALSE;
  current->next = parent->next;
  current->prev = parent;
  if (current->next != NULL) {
    current->next->prev = current; 
  }
  parent->next = current;

  return current;
}

/* Function: findBestList 
 * Date:     Tue Apr 19 14:17:23 EDT 2005 [Somerville, MA]
 *
 * Purpose: Determine Best scoring coordinate in list
 * 	(Assumes ordered by Xpos, not score)
 *
 * Args: 
 *   head	  Pin list
 *
 * Returns:
 *   pointer to best coordinate
 */
COORDS *
findBestList(COORDS *head)
{
  COORDS *current;
  COORDS *best;
  float bestsc = 0.0;

  if (head == NULL) return NULL;

  current = head->next;

  /* Find Xcoord */
  while (current != NULL) {
    if (current->score > bestsc) {
      bestsc = current->score;
      best = current;
    }
    current = current->next;
  }

  return best;
}

/* Function: inList 
 * Date:     Tue Apr 19 09:15:44 EDT 2005 [Cambridge, MA]
 *
 * Purpose: Test if a specified "pin" is in a list.
 *
 * Args: 
 *   head	  Pin list
 *   posX, posY	  coordinates of proposed pin
 *
 * Returns:
 *   TRUE if proposed pin is in list 
 *   FALSE otherwise
 */
  int
inList(COORDS *head, int posX, int posY)
{
  COORDS *current;
  COORDS *prev;

  if (head == NULL) return FALSE;

  current = head->next;
  prev = head;

  /* Find Xcoord */
  while ((current != NULL) && (current->posX != posX)) {
    prev = current;
    current = current->next;
  }

  /* Check that Y coord is correct */
  if (current == NULL) { /* At end of list */
    return FALSE;
  } else {
    if (current->posY == posY) return TRUE;
  }
  return FALSE;
}

/* Function: iCoordListX
 * Date:     Sat Jul 10 19:17:59 CDT 2004
 *
 * Purpose: manage insertion of new data
 *    in an ordered fashion (maintains ordered list)
 *    based on posX
 *
 * Args: 
 *   head	  Pin list
 *   posX, posY	  coordinates of new pin
 *   score	  posterior of new pin
 *
 * Returns:
 *   TRUE if new pin is OK
 *   FALSE is new pin causes criss-cross
 *   	or other problem exists
 */
  int
iCoordListX(COORDS *head, int posX, int posY, float score)
{
  COORDS *current;
  COORDS *prev;

  if (head == NULL) return FALSE;

  current = head->next;
  prev = head;

  /* Find proper insertion point */
  while ((current != NULL) && (current->posX < posX)) {
    prev = current;
    current = current->next;
  }

  /* Check that Y coord is consistent */
  if (current == NULL) { /* At end of list */
    if (prev->posY > posY) return FALSE;
  } else {
    if ((current->posY < posY) || (prev->posY > posY)) 
      return FALSE;
  }

  /* If we got here then the pin is consistent. */
  current = attachCoordList(prev, posX, posY, score);

  return TRUE;
}

/* Function: iCoordListS
 * Date:     Fri Sep  3 11:48:20 CDT 2004 [St Louis]
 *
 * Purpose: manage insertion of new data
 *    in an ordered fashion (maintains ordered list)
 *    based on score 
 *
 * Args: 
 *   head	  Pin list
 *   posX, posY	  coordinates of new pin
 *   score	  posterior of new pin
 *
 * Returns:
 *   TRUE if new pin is OK
 *   FALSE is new pin causes criss-cross
 *   	or other problem exists
 */
  int
iCoordListS(COORDS *head, int posX, int posY, float score)
{
  COORDS *current;
  COORDS *prev;

  if (head == NULL) return FALSE;
  current = head->next; prev = head;

  /* Find proper insertion point */
  while ((current != NULL) && (current->score > score)) {
    prev = current;
    current = current->next;
  }
  current = attachCoordList(prev, posX, posY, score);

  return TRUE;
}

/* Function: rmSetCoord
 * Date:     Tue Apr 19 14:07:36 EDT 2005 [Cambridge, MA]
 *
 * Purpose: remove (delete) a set of 
 * elements from a coordinate list
 *
 * Args: 
 *   head	  Pin list
 *   rmlist	Pin list to remove from head
 *
 * Returns:
 *   TRUE if removal is OK
 *   FALSE otherwise
 */
  int
rmSetCoords(COORDS *head, COORDS *rmlist)
{
  COORDS *cur;

  if (head == NULL) return FALSE;
  /* printCoordList(stdout, rmlist, TRUE); */

  cur = rmlist->next;
  while (cur != NULL) {
    if (rmCoordList(head, cur->posX, cur->posY))
      cur = cur->next;
    else return FALSE;
  }
  freeCoordList(rmlist);

  return TRUE;
}

/* Function: rmCoordList
 * Date:     Tue Apr 19 14:07:36 EDT 2005 [Cambridge, MA]
 *
 * Purpose: remove (delete) an element from the
 * 	coordinate list
 *
 * Args: 
 *   head	  Pin list
 *   posX, posY	  coordinates of pin to remove
 *
 * Returns:
 *   TRUE if removal is OK
 *   FALSE otherwise
 */
  int
rmCoordList(COORDS *head, int posX, int posY)
{
  COORDS *current;
  COORDS *prev, *next;

  if (head == NULL) return FALSE;
  printf("Looking for x: %d y %d \n", posX, posY);

  current = head->next;
  prev = head;

  /* Find proper insertion point */
  while ((current != NULL) && (current->posX != posX)) {
    prev = current;
    current = current->next;
  }
  printf("X: %d \n", current->posX);


  /* Check that Y coord is consistent */
  if (current == NULL) { /* At end of list */
    return FALSE;
  } else {
    next = current->next;
    if (current->posY == posY) {
      printf("Y %d  %f \n", current->posY, current->score);
      /* Found guy to remove */
      prev->next = current->next;
      if (next != NULL) {
	next->prev = prev;
      } 
      free(current);
      return TRUE;
    }
  }
  return FALSE;
}

/* Function: rmXList
 * Date:     Tue Apr 19 14:07:36 EDT 2005 [Cambridge, MA]
 *
 * Purpose: remove (delete) an element from the
 * 	coordinate list
 *
 * Args: 
 *   head	  Pin list
 *   posX	coordinate of pin to remove
 *
 * Returns:
 * 	value of Y at removed X
 */
  int
rmXList(COORDS *head, int posX)
{
  COORDS *current;
  COORDS *prev, *next;
  int Ypos;

  if (head == NULL) return -1;

  current = head->next;
  prev = head;

  /* Find proper insertion point */
  while ((current != NULL) && (current->posX != posX)) {
    prev = current;
    current = current->next;
  }

  if (current == NULL) { /* At end of list */
    return FALSE;
  } else {
    if (current->posX == posX) { /* rampant paranoia */
      Ypos = current->posY;
      next = current->next;
      prev->next = current->next;
      if (next != NULL) {
	next->prev = prev;
      } 
      free(current);
      return Ypos;
    }
  }
  return -1;
}

/* Function: rmBestList
 * Date:     Tue Apr 19 14:07:36 EDT 2005 [Cambridge, MA]
 *
 * Purpose: return best element from the
 * 	coordinate list (which is removed)
 *
 * Args: 
 *   head	  Pin list
 *
 * Returns:
 *   pointer to best coordinate
 */
COORDS *
rmBestList(COORDS *head)
{
  COORDS *current;
  COORDS *prev;
  COORDS *best;
  float bestsc = 0.0;

  if (head == NULL) return NULL;

  current = head->next;
  prev = head;

  /* Find Xcoord */
  while (current != NULL) {
    if (current->score > bestsc) {
      bestsc = current->score;
      best = current;
    } else {
      prev = current;
      current = current->next;
    }
  }
  /* Remove the found best from the list */
  prev = best->prev; current = best;
  prev->next = current->next;
  if (current->next != NULL) 
    current->next->prev = current->prev;
  current = current->next;
  best->next = NULL; best->prev = NULL;

  return best;

}
/******************************************************************/

/* Function: annot2pins
 * Date: RDD, Sat Jul 22 14:57:00 EDT 2006 [Benasque, Spain]
 *
 * Purpose: Given a pin string (e.g: .....*...), build list of
 * pins specified.
 *
 * NOTES: Always lists the SEQX coordinate first; maintains the
 * system wide assumption that constraint files will be indexed
 * from 1 to L (whereas code uses 0 to L-1).
 *
 * Args:
 *   align	alignment associated with pin string.
 *   pinstring	string of pin annotations 
 *   head	list of pins generated (allocated here; free elsewhere)
 *
 * Returns: 
 *    number of pins found
 */
int
annot2pins(ALIGN *align, char *pinstring, COORDS **ret_head)
{
  int i, num;                /* string (alignment) coordinates */
  int xpos, ypos;       /* sequence coordinates */
  COORDS *head;

  if (align == NULL) return -1;
  if (pinstring == NULL) return -1;
  if (strlen(pinstring) != align->alen) return -1;

  xpos = 0; ypos = 0; num = 0;
  head = initCoordList();

  for (i = 0; i < align->alen; i++) {
    /* If we've got legal characters (not gaps)! */
    if (strchr(Alphabet,
	  (char)toupper((int)align->aseqs[SEQX][i])) != NULL) {
      if (strchr(Alphabet,
	    (char)toupper((int)align->aseqs[SEQY][i])) != NULL) {
	/* Then we've can consider this a possible pin column 
	 * and check for the asterisk in our pinstring! */
	if (pinstring[i] == '*') {
	  /* found an asterisk, so we've got a pin */
	  iCoordListX(head, xpos, ypos, 0.0);
	  num++;
	}
	ypos++;
      }
      xpos++;
    } else if (strchr(Alphabet,
	  (char)toupper((int)align->aseqs[SEQY][i])) != NULL) {
      ypos++;
    }
  }
  *ret_head = head;
  return num;
}

/* Function: align2pins 
 * Date: RDD, Wed Jun 23 13:33:05 CDT 2004 [St Louis]
 *
 * Purpose: Given an alignment, list the possible pins.
 *
 * NOTES: Always lists the SEQX coordinate first; maintains the
 * system wide assumption that constraint files will be indexed
 * from 1 to L (whereas code uses 0 to L-1).
 *
 * Args:
 *   align	alignment to generate pins from
 *   head	list of pins generated (allocated here; free elsewhere)
 *
 * Returns: 
 *    number of possible pins
 */
int
align2pins(ALIGN *align, COORDS **ret_head)
{
  int i, num;                /* alignment coordinates */
  int xpos, ypos;       /* sequence coordinates */
  COORDS *head;

  if (align == NULL) return -1;

  xpos = 0; ypos = 0; num = 0;
  head = initCoordList();

  for (i = 0; i < align->alen; i++) {
    /* If we've got legal characters (not gaps)! */
    if (strchr(Alphabet,
	  (char)toupper((int)align->aseqs[SEQX][i])) != NULL) {
      if (strchr(Alphabet,
	    (char)toupper((int)align->aseqs[SEQY][i])) != NULL) {
	/* Then we've got a possible pin! */
        iCoordListX(head, xpos, ypos, 0.0);
	num++;
	ypos++;
      }
      xpos++;
    } else if (strchr(Alphabet,
	  (char)toupper((int)align->aseqs[SEQY][i])) != NULL) {
      ypos++;
    }
  }
  *ret_head = head;
  return num;
}

/* Function: checkPinConsistent 
 * Date:     RDD, Sat Jul 10 14:07:26 CDT 2004
 *
 * Purpose:  
 *   verify that a given set of pins are 
 *   consistent with a particular alignment
 *
 * Args:
 *   pins	list of pins to check
 *   align	pairwise alignment 
 *
 * Returns:  
 *    TRUE if no errors; FALSE if error encountered 
 */
int
checkPinConsistent(COORDS *pins, ALIGN *align)
{
  COORDS *alignset;	/* Pins implied by alignment */
  COORDS *curpin;	/* placeholder in pin set */
  COORDS *anext;	/* placeholder in alignment set */

  /* Build list of possible pins from alignment */
  align2pins(align, &alignset);

  curpin = pins; anext = alignset;
  /* Check given pins against alignment set */
  while (curpin->next != NULL) {
    /* We start this way because of our convention of
     * the head of the list being an empty placeholder */
    curpin = curpin->next; 
    while (anext->posX != curpin->posX) {
      anext = anext->next;
      if (anext == NULL) {
	/* Because lists are ordered, if we run out
	 * of alignment pins to check then these lists
	 * are not consistent */
	return FALSE;
      } 
    }
    if (anext->posY !=curpin->posY) {
      /* If an Xpos doesn't agree with corresponding Ypos
       * then the lists are not consistent */
	return FALSE;
    }
  }

  /* Free alignment set (no longer needed) */
  freeCoordList(alignset);
  return 1;
}

/* Function: align2CoordMap 
 * Date: RDD, Mon Oct 18 16:57:37 CDT 2004 [St Louis]
 *
 * Purpose: Given an alignment, build a mapping of coordinates
 * 	in sequence X relative to sequence Y (not alignment coords)
 *
 * Args:
 *   align	alignment to generate pins from
 *   map	coordinate in Y for each position of X
 *
 * Returns:  
 *   number of columns without gaps
 */
int
align2CoordMap(ALIGN *align, int **XYmap)
{
  int i, num;
  int xpos, ypos;       /* sequence coordinates */
  int *map;

  if (align == NULL) return -1;

  xpos = 0; 
  for (i = 0; i < align->alen; i++) {
    if (strchr(Alphabet,
	  (char)toupper((int)align->aseqs[SEQX][i])) != NULL) {
      xpos++;
    }
  }
  map = (int *)malloc(sizeof(int) * xpos);

  xpos = ypos = 0;  num = 0;
  for (i = 0; i < align->alen; i++) {
    /* If we've got legal characters (not gaps)! */
    if (strchr(Alphabet,
	  (char)toupper((int)align->aseqs[SEQX][i])) != NULL) {
      if (strchr(Alphabet,
	    (char)toupper((int)align->aseqs[SEQY][i])) != NULL) {

	map[xpos] = ypos;
	num++;
	ypos++;
      } else {
	map[xpos] = -1;
      }
      xpos++;
    } else if (strchr(Alphabet,
	  (char)toupper((int)align->aseqs[SEQY][i])) != NULL) {
      ypos++;
    }
  }

  *XYmap = map;
  return num;
}

/*********************** Pin Statistics **********************/
void 
ZeroPinStats (PSTATS *stats)
{
  int i;

  stats->npins = 0;
  stats->pinposs = 0;
  stats->TP = 0;
  stats->FP = 0;
  stats->npairs = 0;

  for (i = 0; i < 101; i++) {
    stats->tcorr[i] = 0;
    stats->totalp[i] = 0;
  }

  stats->psum = 0.0;
  stats->max = 0.0;
  stats->min = 6.0;
}

/* Function: evalConstraints
 * Date:     RDD, Mon Jul 12 09:52:50 CDT 2004
 *
 * Purpose:  
 *   Given a set of pins and a "true" alignment,
 *   determine TP, FP, TN, and FN numbers.
 *
 *   Here we set the correct parameter in the 
 *   COORD structure.  
 *
 * Args:
 *   constraints	constraint info (pins to utilize)
 *   align	"reference/true" pairwise alignment 
 *   ret_stats	statistics gathered for this alignment
 *   		(allocated elsewhere; zero elsewhere)
 *
 * Returns:  -void-
 */
void
evalConstraints(CNSRNT *constraints, int Xlen, ALIGN *align, PSTATS *ret_stats)
{
  COORDS *pins;		/* Pins implied by constraint info */

  /* Build list of pins from constraint info */
  gatherConstraints(constraints, Xlen, &pins);
  evalPins(pins, align, ret_stats, FALSE);
}

/* Function: evalPins 
 * Date:     RDD, Mon Jul 12 09:52:50 CDT 2004
 *
 * Purpose:  
 *   Given a set of pins and a "true" alignment,
 *   determine TP, FP, TN, and FN numbers.
 *
 *   Here we set the correct parameter in the 
 *   COORD structure.  
 *
 * Args:
 *   pins	pins to test 
 *   align	"reference/true" pairwise alignment 
 *   ret_stats	statistics gathered for this alignment
 *   		(allocated elsewhere; zero elsewhere)
 *
 * Returns:  Number of pins correct 
 */
int
evalPins(COORDS *pins, ALIGN *align, PSTATS *ret_stats, int printtrue)
{
  COORDS *curpin;	/* placeholder in pin set */
  int *map;	/* Alignment map of XY */
  int Xpos, idx;
  int correct = 0;

  /* Build list of possible pins from alignment */
  Xpos = align2CoordMap(align, &map);
  ret_stats->pinposs += Xpos;
  ret_stats->npairs++;

  curpin = pins; 
  /* Check given pins against alignment set */
  while (curpin->next != NULL) {
    /* We start this way because of our convention of
     * the head of the list being an empty placeholder */
    curpin = curpin->next; 
    ret_stats->npins++;
    ret_stats->psum += curpin->score;
    idx = (int)((curpin->score * 100) + 0.5);
    if (curpin->score > ret_stats->max) ret_stats->max = curpin->score;
    if (curpin->score < ret_stats->min) ret_stats->min = curpin->score;

    if (map[curpin->posX] == curpin->posY) {
      /* This pin is correct */
      ret_stats->TP++;
      ret_stats->tcorr[idx]++;
      correct++;
    } else {
      /* This pin is incorrect */
      ret_stats->FP++;
    }
    ret_stats->totalp[idx]++;
  }

  return correct;
}

void
printPinStats(PSTATS pstat, int summary) 
{
  int i;

  if (summary) {
    printf("Num Pins Eval: %d\n", pstat.npins);
    printf("Num Align Pos Eval: %d\n", (int)pstat.pinposs);
    printf("Num Pairwise Alignments: %d\n", pstat.npairs);
    printf("TP pins: %d\n", pstat.TP);
    printf("FP pins: %d\n", pstat.FP);
    printf("Percent Correct: %f\n", (float)pstat.TP/(float)pstat.npins);
  } else {
    for (i = 0; i < 101; i++) {
      if (pstat.totalp[i] == 0) {
	printf("%d\t%1.4f\t%d\t%d\n", i, 0.0, 
	    pstat.tcorr[i], pstat.totalp[i]);
      } else {
	printf("%d\t%1.4f\t%d\t%d\n", i, 
	    100*((float)pstat.tcorr[i]/(float)pstat.totalp[i]),
	    pstat.tcorr[i], pstat.totalp[i]);
      }
    }
  }
}

