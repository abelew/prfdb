/* dps.c
 * Sat Jan 25 10:25:19 CST 2003
 * 
 * Allocation, free'ing, printing of the full
 * straightforward (no constraints; contains zero rows)
 * fill matrix 
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>
#include <ctype.h>

#include "squid.h"
#include "cfg.h"
#include "consan.h"
#include "dps.h"

/* Function: allocFillMx, freeFillMx
 * Date:     Sat Jan 25 10:27:42 CST 2003 [St Louis]
 *
 * Purpose: Allocate space for the DP fill matrix 
 *
 * Assumption:
 * 	Allocates only 1/2 of matrix
 * 	Assumes (j,d1,l,d2) notation
 * 	Allocates for an integer fill matrix
 *
 * Notes: This is a 5D matrix 
 * (Nonterminal * LengthX * 1/2 LengthX * LengthY * 1/2 LengthY)
 * The nz versions do NOT allocate the zero distance element --
 * [which is just filled on initialization and therefore could
 * be ignored in favor of initializing d = 1 rows instead.]
 *
 * Args:     
 *      grammar	Current grammar to utilize
 *	lenX	length of the sequence (j, d1)
 *	lenY	length of the sequence (l, d2)
 *	ret_mx	pointer to the allocated space (returned)
 *
 * Returns:  void
 */
void
allocFillMx(int grammar, int lenX, int lenY, int ******ret_mx)
{
  int *****mx;
  int v, j, d, l;
  int Dsize, Xsize, Ysize;

  if ((mx = (int *****) malloc (NDPS * sizeof(int ****))) == NULL) 
     Die("malloc nonterminals failed");
  /* For each nonterminal, allocate a 4D matrix */
  for (v = 0; v < NDPS; v++) {
     if (Contains[grammar][v]) {
	if ((mx[v] = (int ****) malloc (lenX * sizeof(int ***))) == NULL)
	   Die("malloc j failed");
	for (j = 0; j < lenX; j++) {
	   Xsize = j + 2;	/* number of d1 cells */
	   if ((mx[v][j] = (int ***) malloc (Xsize * sizeof(int **))) == NULL)
	      Die("malloc d1 failed");
	   /* For each (j, d1) pair in seq X, allocate a seq Y 2D matrix */
	   for (d = 0; d < Xsize; d++) {
	      if ((mx[v][j][d] = (int **) malloc (lenY * sizeof(int *))) == NULL)
		 Die("malloc l failed");
	      Dsize = ((lenY * (lenY+1))/2) + lenY; /* Size of (l, d2) */
	      if ((mx[v][j][d][0] = (int *) malloc (Dsize * sizeof(int))) == NULL)
		 Die("malloc d2 failed");
	      for (l = 1; l < lenY; l++) {
		 Ysize = (l*(l+1)/2) + l; /* distance from position 0 to row d */
		 mx[v][j][d][l] = mx[v][j][d][0] + Ysize;
	      }	/* End for d */
	   }	/* End for l */
	}	/* End for j */
     } else {	/* End if contains */
	mx[v] = NULL;
     }
  }
  *ret_mx = mx;
}

void
freeFillMx(int grammar, int lenX, int *****mx) 
{
   int v, j, d;

   for (v = 0; v < NDPS; v++) {
      if (Contains[grammar][v]) {
	 for (j = 0; j < lenX; j++) {
	    for (d = 0; d < (j+2); d++) {
	       free(mx[v][j][d][0]);
	       free(mx[v][j][d]);
	    }
	    free(mx[v][j]);
	 }
	 free(mx[v]);
      }
   }
   free(mx);
}

/* Function: patternFillMx, zeroFillMx
 * Date:     Sat Jan 25 19:07:45 CST 2003 [St Louis]
 *
 * Purpose: Fill allocated space with known values
 *
 * Args:     
 *      grammar	Current grammar to utilize
 *	len	length of the sequence
 *	ret_mx	pointer to the allocated space (returned)
 *
 * Returns:  void
 */
void
patternFillMx(int grammar, int lenX, int lenY, int *****mx) 
{
   int v, j, l, d1, d2;
   int cnt = 0;

   for (v = 0; v < NDPS; v++) {
      if (Contains[grammar][v]) {
	 for (j = 0; j < lenX; j++) {
	    for (d1 = 0; d1 < j+2; d1++) {
	       for (l = 0; l < lenY; l++) {
		  for (d2 = 0; d2 < l+2; d2++) {
		     mx[v][j][d1][l][d2] = cnt++;
		  }	/* End d2 */
	       }	/* End l */
	    }	/* End d1 */
	 }	/* End j */
      } /* End contains */
   }
}

void
zeroFillMx(int grammar, int lenX, int lenY, int *****mx) 
{
   int v, j, l, d1, d2;

   for (v = 0; v < NDPS; v++) {
      if (Contains[grammar][v]) {
	 for (j = 0; j < lenX; j++) {
	    for (d1 = 0; d1 < j+2; d1++) {
	       for (l = 0; l < lenY; l++) {
		  for (d2 = 0; d2 < l+2; d2++) {
		     mx[v][j][l][d1][d2] = 0; 
		  }	/* End d2 */
	       }	/* End l */
	    }	/* End d1 */
	 }	/* End j */
      } /* End contains */
   }
}

/* Function: fakeAllocMx 
 * Date:     Sat Jan 25 12:11:50 CST 2003 [St Louis]
 *
 * Purpose: Estimate Memory Requirements for 
 * 	a sequence of a particular length
 *
 * Assumption: Allocation as per allocFillMx
 *
 * Args:     
 *      grammar	Current grammar to utilize
 *	len	length of the sequence
 *
 * Returns: 
 * 	size in kilobytes of requested allocation
 */
unsigned
fakeAllocMx(int grammar, int lenX, int lenY)
{
  unsigned bytes;
  unsigned kilos;
  int v, j, d;
  int Dsize, Xsize;

  bytes = 0;
  kilos = 0;

  for (v = 0; v < NDPS; v++) {
     if (Contains[grammar][v]) {
	/* Outer allocation is for the X matrix (j x dx) */
	for (j = 0; j < lenX; j++) {
	   Xsize = j + 2;
	   bytes = (Xsize * sizeof(int **));
	   /* Inner allocation is for the Y matrix (l x dy) */
	   for (d = 0; d < Xsize; d++) {
	      bytes += (lenY * sizeof(int *));
	      /* Size of (l, d2) */
	      Dsize = ((lenY * (lenY+1))/2) + lenY;	
	      bytes += (Dsize * sizeof(int));
	   }
	   kilos += (int)ceilf((float)bytes/1024.);
	}
	bytes = (lenX * sizeof(int ***));
	kilos += (int)ceilf((float)bytes/1024.);
     }
  }
  bytes = (NDPS * sizeof(int ****));
  kilos += (int)ceilf((float)bytes/1024.);
  return (kilos);
}

/* Function: printAlignMx
 * Date:    Sat Jan 25 19:08:40 CST 2003 [St Louis]
 *
 * Purpose:  (debugging)
 *   For a particular v, d1, d2 print the j, l matrix
 *
 * Args:     fp   - open FILE ptr to write to (stdout, perhaps)
 *           mx   - DP matrix, 
 *           seqs - sequences and their lengths
 *           v	  - for which non-terminal
 *           d1   - distance in X
 *           d2   - distance in Y 
 *
 * Notes: 
 *   - giving d1 = d2 = 0 (or is it 1?) should give 
 *     an alignment matrix devoid of secondary structure.
 *   - If d1 and or d2 are outside the allocation size, 
 *     we'll scale them down to zero and mark them in output
 *     with an asterisk (*)
 *   - If we request a nonterminal illegal under this
 *     grammar then print a message to that effect.
 *
 * Return:
 */
void
printAlignMx(FILE *fp, int *****mx, SEQUENCE *seqX, SEQUENCE *seqY, 
      int v, int d1, int d2, int gmr)
{
   int j, l;
   int dx, dy;
   int Xlen, Ylen;

   Xlen = seqX->len;
   Ylen = seqY->len;

   if (mx[v] == NULL) {
     fprintf(fp, "The requested nonterminal unavailable in this matrix\n");
     return;
   }

   fprintf(fp, "Printing %s (j,l) matrix for dx = %d dy = %d\n", 
	 dpNAME[Gtype[gmr]][v], d1, d2);

   fprintf(fp, "%9s ", " ");
   for (l = 0; l < Ylen; l++) {
      fprintf(fp, "%9d ", l);
   }
   fputs("\n", fp);
   fprintf(fp, "%9s ", " "); 
   for (l = 0; l < Ylen; l++) {
      fprintf(fp, "%9c ", toupper(seqY->seq[l])); 
   }
   fputs("\n", fp);

   /* If requested distances are greater than possible
    * then default to zero distance.
    */
   for (j = 0; j < Xlen; j++) {
      if (d1 >= j+2) {
	 dx = 0;
         fprintf(fp, "%4d*%4c ", j, toupper(seqX->seq[j]));
      } else {
	 dx = d1;
         fprintf(fp, "%4d %4c  ", j, toupper(seqX->seq[j]));
      }
      for (l = 0; l < Ylen; l++) {
	 if (d2 >= l+2) {
	    dy = 0;
	    fprintf(fp, "%8d* ", mx[v][j][dx][l][dy]);
	 } else {
	    dy = d2;
	    fprintf(fp, "%8d  ", mx[v][j][dx][l][dy]);
	 }
      }
      fputs("\n", fp);
   }
   fputs("\n", fp);
   fflush(stdout);
}

/* Function: printFoldMx
 * Date:    Sat Jan 25 19:16:43 CST 2003 [St Louis]
 *
 * Purpose:  (debugging)
 *   For a particular v, j, l print the d1, d2 matrix
 *
 * Args:     fp   - open FILE ptr to write to (stdout, perhaps)
 *           mx   - DP matrix, 
 *           seqs - sequences and their lengths
 *           v	  - for which non-terminal
 *           j    - position in X
 *           l    - position in Y 
 *
 * Notes: 
 *   - If we request a nonterminal illegal under this
 *     grammar then print a message to that effect.
 *
 * Return:   (void)
 */
void
printFoldMx(FILE *fp, int *****mx, SEQUENCE *seqX, SEQUENCE *seqY, 
      int v, int j, int l, int gmr)
{
   int d1, d2;
   int Xlen, Ylen;

   Xlen = seqX->len;
   Ylen = seqY->len;
   
   if (mx[v] == NULL) {
     fprintf(fp, "The requested nonterminal unavailable in this matrix\n");
     return;
   }

   fprintf(fp, "Printing %s (d1,d2) matrix for j = %d (%c) l = %d (%c)\n", 
	 dpNAME[Gtype[gmr]][v], j, toupper(seqX->seq[j]), l, toupper(seqY->seq[l]));

   fprintf(fp, "%4s ", " ");
   for (d2 = 0; d2 < l+2; d2++) {
      fprintf(fp, "%9d ", d2);
   }
   fputs("\n", fp);

   for (d1 = 0; d1 < j+2; d1++) {
      fprintf(fp, "%4d ", d1);
      for (d2 = 0; d2 < l+2; d2++) {
	 fprintf(fp, "%9d ", mx[v][j][d1][l][d2]);
      }
      fputs("\n", fp);
   }
   fputs("\n", fp);
   fflush(stdout);
}

/* Function: printYFoldMx
 * Date:    Sat Jan 25 19:28:13 CST 2003 [St Louis]
 *
 * Purpose:  (debugging)
 *   For a particular v, j, d1 print the l, d2 matrix
 *
 * Args:     fp   - open FILE ptr to write to (stdout, perhaps)
 *           mx   - DP matrix, 
 *           seqs - sequences and their lengths
 *           v	  - for which non-terminal
 *           j    - position in X
 *           d1   - distance in X 
 *
 * Notes: 
 *   - If d1 is outside the allocation size, 
 *     we'll scale it down to zero and mark it in output
 *     with an asterisk (*)
 *   - If we request a nonterminal illegal under this
 *     grammar then print a message to that effect.
 *
 * Return:   (void)
 */
void
printYFoldMx(FILE *fp, int *****mx, SEQUENCE *seqX, SEQUENCE *seqY, 
      int v, int j, int d1, int gmr)
{
   int l, d2;
   int dx;
   int Xlen, Ylen;

   Xlen = seqX->len;
   Ylen = seqY->len;

   if (mx[v] == NULL) {
     fprintf(fp, "The requested nonterminal unavailable in this matrix\n"); 
     return;
   }

   /* If request a distance in Y which isn't possible 
    * we'll arbitrarily reset to zero 
    */
   if (d1 >= j+2) {
      dx = 0;
      fprintf(fp, "Printing %s (l,dy) matrix for j = %d (%c) d1 = %d* \n",
	    dpNAME[Gtype[gmr]][v], j, toupper(seqX->seq[j]), dx);
   } else {
      dx = d1;
      fprintf(fp, "Printing %s (l,dy) matrix for j = %d (%c) d1 = %d \n", 
	    dpNAME[Gtype[gmr]][v], j, toupper(seqX->seq[j]), dx);
   }

   fprintf(fp, "%9s ", " ");
   for (d2 = 0; d2 < Ylen+1; d2++) {
      fprintf(fp, "%9d ", d2);
   }
   fputs("\n", fp);

   for (l = 0; l < Ylen; l++) {
      fprintf(fp, "%4d%5c ",l, toupper(seqY->seq[l])); 
      for (d2 = 0; d2 < Ylen+1; d2++) {
	 if (d2-1 <= l) fprintf(fp, "%9d ", mx[v][j][dx][l][d2]);
	 else fprintf(fp, "%9s ", "-");
      }
      fputs("\n", fp);
   }
   fflush(stdout);
}

/* Function: printXFoldMx
 * Date:    Sat Jan 25 19:42:11 CST 2003 [St Louis]
 *
 * Purpose:  (debugging)
 *   For a particular v, l, d2 print the j, d1 matrix
 *
 * Args:     fp   - open FILE ptr to write to (stdout, perhaps)
 *           mx   - DP matrix, 
 *           seqs - sequences and their lengths
 *           v	  - for which non-terminal
 *           l    - position in Y
 *           d2   - distance in Y 
 *
 * Notes: 
 *   - If d2 is outside the allocation size, 
 *     we'll scale it down to zero and mark it in output
 *     with an asterisk (*)
 *   - If we request a nonterminal illegal under this
 *     grammar then print a message to that effect.
 *
 * Return:   (void)
 */
void
printXFoldMx(FILE *fp, int *****mx, SEQUENCE *seqX, SEQUENCE *seqY,
      int v, int l, int d2, int gmr)
{
   int j, d1;
   int dy;
   int Xlen, Ylen;

   Xlen = seqX->len;
   Ylen = seqY->len;

   if (mx[v] == NULL) {
     fprintf(fp, "The requested nonterminal unavailable in this matrix\n");
     return;
   }

   /* If request a distance in Y which isn't possible 
    * we'll arbitrarily reset to zero 
    */
   if (d2 >= l+2) {
      dy = 0;
      fprintf(fp, "Printing %s (j,dx) matrix for l = %d (%c) d2 = %d* \n",
	    dpNAME[Gtype[gmr]][v], l, toupper(seqY->seq[l]), dy);
   } else {
      dy = d2;
      fprintf(fp, "Printing %s (j,dx) matrix for l = %d (%c) d2 = %d \n", 
	    dpNAME[Gtype[gmr]][v], l, toupper(seqY->seq[l]), dy);
   }

   fprintf(fp, "%9s ", " ");
   for (d1 = 0; d1 < Xlen+1; d1++) {
      fprintf(fp, "%9d ", d1);
   }
   fputs("\n", fp);

   for (j = 0; j < Xlen; j++) {
      fprintf(fp, "%4d%5c ",j, toupper(seqX->seq[j])); 
      for (d1 = 0; d1 < Xlen+1; d1++) {
	 if (d1-1 <= j) fprintf(fp, "%9d ", mx[v][j][d1][l][dy]);
	 else fprintf(fp, "%9s ", "-");
      }
      fputs("\n", fp);
   }
   fflush(stdout);
}
