/* cyk.c
 * RDD, Sun Feb 16 18:25:43 CST 2003 [St Louis]
 *
 * The main routine for doing the major 
 * manipulations of DP for CYK
 *
 * These implementations assume a digitized sequence.
 * See alphabet.c and alphabet.h for more details.
 */

#include <stdio.h>
#include "squid.h"
#include "cfg.h"
#include "consan.h"
#include "trace.h"	/* struct trace_s */
#include "options.h"	/* OPTS */
#include "alphabet.h"	/* Digitize */
#include "grammars.h"
#include "dps.h"
#include "cyk.h"

/*********************** CYK **********************************/
/* Function: CYK 
 * Date:     RDD, Sun Feb 16 18:26:50 CST 2003 [St Louis]
 *
 * Purpose:  CYK algorithm outline for scoring grammars
 * 	if you give it constraints use full RED version
 * 	if no constraints, use FUL version.
 *
 * Args:    
 *     drna	rna sequence 
 *     len	length of sequence
 *     grammar	which grammar to utilize (see cfg.h)
 *     scmodel  scoring paramters 
 *     output   command line options (varies output)	
 *     ss	secondary structure in ctformat 
 *     		if given, calculates conditional CYK 
 *     		if NULL, calculates full CYK 
 *
 * Returns:  
 * 	*ret_score	Score of best parse
 * 	pointer to head best parse traceback tree 
 * 	NULL on failure
 */
struct trace_s *
CYK(SEQPR *seqs, MODEL *model, OPTS *opts, int *ret_score)
{
  int *****matx;
  struct trace_s *tr;
  int Xlen, Ylen;
  int redversion;
  int debug = FALSE;

  if (debug) printf("IN CYK!\n"); fflush(stdout);

  tr = NULL;
  Xlen = seqs->sequence[SEQX]->len;
  Ylen = seqs->sequence[SEQY]->len;

  if (seqs->c_info != NULL) {	/* We have constrain info: RED */
    redversion = TRUE;		
  } else {			/* Without constraints, must be FUL */
    redversion = FALSE;
  }

  /* If digitized unavailable, throw an error! */
  if ((seqs->sequence[SEQX]->dseq == NULL) || 
      (seqs->sequence[SEQY]->dseq == NULL)) 
     Die("Sequences not digitized\n");
  if (debug) printf("Setup Complete !\n"); fflush(stdout);

  /* If using RED version, we do reduced allocation.
   * Otherwise we do full version (for CON and FUL) */
  if (redversion) {
    if (debug) printf("Allocating RED!\n"); fflush(stdout);
    allocRedFillMx(model->grammar, seqs->c_info,
	seqs->sequence[SEQX]->len, seqs->sequence[SEQY]->len, &matx);  
    if (debug) printf("Allocated!\n"); fflush(stdout);
  } else {
    if (debug) printf("Allocating FULL!\n"); fflush(stdout);
    allocFillMx(model->grammar, Xlen, Ylen, &matx);
  }
  if (debug) { printf("Allocated\n"); fflush(stdout); }

  /* Now we want to fill the full N^4 matrix. */
  if (redversion) {
    rccykFillSTA(seqs, &(model->imod), matx);
  } else {
    cykFillMx(seqs, model, matx, FALSE);
  }
  if (debug) { printf("Filled\n"); fflush(stdout); }

  /* With a filled matrix, we know what the best score is. */
  if (redversion) {
    *ret_score = matx[0][Xlen-1][Xlen]\
      [((Ylen-1)-seqs->c_info->sL[Xlen-1])][0]; 
  } else {
    *ret_score = matx[0][Xlen-1][Xlen][Ylen-1][Ylen]; 
  }
  if (debug)  
    printf("Score Set %d\n", *ret_score); fflush(stdout); 

  /* Now we want to traceback to get the structure. */
  if (redversion) {
    /* Could the CON version use this routine? */
    if (debug) {printf("Use RED traceback\n"); fflush(stdout); }
    tr = rccykTraceSTA(seqs, &(model->imod), matx); 
  } else {
    tr = cykTraceMx(seqs, model, matx);
  }
  if (opts->traceback) printTrace(stdout, tr, seqs); 
  if (debug) { printf("Traced\n"); fflush(stdout); }

  /* Now clean up after ourselves. */
  if (redversion) {
    freeRedFillMx(model->grammar, Xlen, matx);   
  } else {
    freeFillMx(model->grammar, Xlen, matx); 
  }

  return (tr);
}

/* Debugging version */
struct trace_s *
cykDB(SEQPR *seqs, MODEL *model, OPTS *opts, int *ret_score)
{
  int *****matx;
  int *****fullmatx;
  struct trace_s *tr;
  struct trace_s *fulltr;
  int Xlen, Ylen;
  int redversion;
  int debug = TRUE;

  tr = NULL;
  Xlen = seqs->sequence[SEQX]->len;
  Ylen = seqs->sequence[SEQY]->len;

  if (seqs->c_info != NULL) {	/* We have constrain info -> RED */
    redversion = TRUE;		
  } else {			/* Without constraints, must be FUL */
    redversion = FALSE;
  }

  /* If digitized unavailable, throw an error! */
  if ((seqs->sequence[SEQX]->dseq == NULL) || 
      (seqs->sequence[SEQY]->dseq == NULL)) 
     Die("Sequences not digitized\n");

  /* If using RED version, we do reduced allocation.
   * Otherwise we do full version */
  if (redversion) {
    allocRedFillMx(model->grammar, seqs->c_info,
	seqs->sequence[SEQX]->len, seqs->sequence[SEQY]->len, &matx);  
    allocFillMx(model->grammar, Xlen, Ylen, &fullmatx);
  } else {
    allocFillMx(model->grammar, Xlen, Ylen, &matx);
  }
  if (debug) { printf("Allocated\n"); fflush(stdout); }

  /* Now we want to fill the full N^4 matrix. */
  if (redversion) {
    cykFillMx(seqs, model, fullmatx, FALSE);
    rccykFillSTA(seqs, &(model->imod), matx);
  } else {
    cykFillMx(seqs, model, matx, FALSE);
  }
  if (debug) { printf("Filled\n"); fflush(stdout); }

  /* With a filled matrix, we know what the best score is. */
  if (redversion) {
    checkCells(seqs, matx, fullmatx);
    *ret_score = matx[0][Xlen-1][Xlen]\
      [((Ylen-1)-seqs->c_info->sL[Xlen-1])][0]; 
  } else {
    *ret_score = matx[0][Xlen-1][Xlen][Ylen-1][Ylen]; 
  }
  if (debug) { printf("Score Set %d\n", *ret_score); fflush(stdout); }

  /* Now we want to traceback to get the structure. */
  if (redversion) {
    /* Could the CON version use this routine? */
    fulltr = cykTraceMx(seqs, model, fullmatx);
    tr = rccykTraceSTA(seqs, &(model->imod), matx); 
  } else {
    tr = cykTraceMx(seqs, model, matx);
  }
  if (opts->traceback) printTrace(stdout, tr, seqs); 
  if (debug) { printf("Traced\n"); fflush(stdout); }

  /* Now clean up after ourselves. */
  if (redversion) {
    freeRedFillMx(model->grammar, Xlen, matx);   
  } else {
    freeFillMx(model->grammar, Xlen, matx); 
  }

  return (tr);
}


/* Function: cykFillMx 
 * Date:     Sun Feb 16 18:44:17 CST 2003 [St Louis]
 * 
 * Purpose:  Fills CYK matrix for any specified grammar
 * 	cyk version does full sankoff
 * 	ccyk version does constrained sankoff
 * 
 * Assumption: Fill matrix already allocated and initialized
 * 
 * Args:    
 * 	seqs	sequences and constraint info
 * 	model	parameter and grammar info
 * 	mx	fill matrix
 * 	constrain	boolean: Use constraints?
 *
 * Returns:  
 * 	TRUE if successful
 * 	FALSE if detected an error
 */
int
cykFillMx(SEQPR *seqs, MODEL *model, int *****mx, int constrain)
{
   if (Gtype[model->grammar] == NGMR) {
      if (constrain) return 0;
      else 
	cykFillNUS(seqs->sequence[SEQX], seqs->sequence[SEQY], &(model->imod), 
	    	model->grammar, mx);
   } else {
      if (constrain) ccykFillSTA(seqs, &(model->imod), mx);
      else 
	 cykFillSTA(seqs->sequence[SEQX], seqs->sequence[SEQY], &(model->imod), 
	    	model->grammar, mx);
   }
   return TRUE;
}

/* Function: cykTraceMx 
 * Date:     Sun Feb 16 18:44:17 CST 2003 [St Louis]
 * 
 * Purpose:  Build traceback tree for grammars (distribution function)
 * 	cyk version does full sankoff
 * 	ccyk version does constrained sankoff
 * 
 * Args:
 * 	seqs	sequences and constraint info
 * 	model	parameter and grammar info
 * 	mx	fill matrix
 * 	constrain	boolean: Use constraints?
 *      
 * Returns: 
 * 	pointer to head of resulting traceback tree
 * 	is NULL if an error occured.
 */
struct trace_s *
cykTraceMx(SEQPR *seqs, MODEL *model, int *****mx)
{
   struct trace_s *tr;

   tr = NULL;

   if (Gtype[model->grammar] == NGMR) {
      tr = cykTraceNUS(seqs->sequence[SEQX], seqs->sequence[SEQY], 
	    &(model->imod), model->grammar, mx);
   } else {
      tr = cykTraceSTA(seqs->sequence[SEQX], seqs->sequence[SEQY], 
	    &(model->imod), model->grammar, mx);
   }
   return (tr);
}


