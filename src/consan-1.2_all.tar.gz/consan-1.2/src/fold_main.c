/* fold_main.c 
 * RDD, Mon Feb 17 14:40:35 CST 2003 [St Louis]
 *
 * Takes in two sequence files and finds the
 * structural alignment between them.  A third
 * (optional) file may contain the pins to utilize
 * by the constrained algorithm.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<time.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"consan.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"
#include"cyk.h"

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-m <file>     : Use parameters, grammar and scoring specified in model <file> \n\
-M <int>      : Ensure that pin selection results in something near X Mbytes memory \n\
-C <int>      : use <int> pins from trusted alignment \n\
-P <int>      : use <int> predicted pins \n\
-V	      : output as single sequences rather than pair \n\
-f 	      : execute full (unconstrained) algorithm \n\
-x            : print out parameters of model \n\
-t            : print traceback\n\
-d            : debugging output \n\
-v            : verbose output \n\
-f            : debugging, print fill matrix from cyk \n\
";
static char usage[]  = "Usage: sfold [-options] <seqfile1> <seqfile2>\n";

  int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;

  /* ReadSeq variables */
  SEQPR *seqs;
  int score;
  int numfiles;

  /* Models info */
  MODEL *model;
  struct trace_s *trc = NULL;

  time_t starttime, endtime;
  double secused;

  /* pinsetup variables */
  int cando = TRUE;

  starttime = time(NULL);

  if (!(processOpts(&settings, &optid, argc, argv, usage, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  numfiles = argc - optid;
  if (numfiles < 2) 
    Die("Incorrect number of command line arguments.\n%s\n%s\n", usage, optsline);

  setupModel(&settings, &model);
  if (settings.parameterout) printModel(stdout, PRINT_INT, model);
  if (settings.verbose) printOptions(settings.ofp, &settings);

  allocSeqPair(&seqs);
  readSequence(argv[optid], seqs);
  optid++;
  readSequence(argv[optid], seqs);
  optid++;

  trc = NULL;
  if (!settings.fopt) {
    if (numfiles == 3) {
      loadConstraints(argv[optid], seqs);
      if (settings.mset) 
	forceMemSize(settings, seqs, NULL, NULL);
    } else {
      cando = setupPins(settings, seqs);
    }
  }

  /* printSeqPair(stdout, seqs); */
  if (cando) 
    trc = (struct trace_s *)CYK(seqs, model, &settings, &score);     

  if (trc != NULL) {
    trace2alignment(trc, seqs, &(seqs->alignment));
    FreeTrace(trc);
    if (settings.debugg) printSeqPair(stdout, seqs);

    if (settings.voronoi) {
      printAln2Single(stdout, seqs);
    } else {
      printStockholm(stdout, seqs, NULL, FALSE);
    }
  } else {
    printf("Trace is NULL\n"); 
  }
  fflush(stdout);

  /* Cleanup  */
  freeSeqPair(seqs);
  freeModel(model);

  endtime = time(NULL);
  secused = difftime(endtime, starttime);

  if (!settings.voronoi) {
    fprintf(stdout, "\n#=GF TIME  %.1f\n", secused);
    fprintf(stdout, "\n//\n");
  }

  return 0;
}
