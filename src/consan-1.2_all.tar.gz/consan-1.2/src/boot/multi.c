#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"../squid/squid.h"
#include"../squid/sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../alphabet.h"

#include"opts.h"
#include"bstat.h"

static char optsline[]  = "\
  where options are:\n\
  -h            : get help \n\
  -v            : verbose \n\
  -m <map>      : map of samples\n\
  ";
static char usage[]  = "Usage: multi -m <map> <files>\n";

int 
main (int argc, char **argv) 
{
  int optid;
  OPTM settings;
  int **map;
  int size, iter;

  PDATA **dataset;
  PDATA **rep;

  int i, lsize;
  PDATA *sum, *rsum;
  float *sens, *ppv;
  double sensum, ppvsum;
  double meansen, varsen, sdsen;
  double meanppv, varppv, sdppv;

  if (!(processOpt(&settings, &optid, argc, argv, usage, optsline))) {
    printf("Bad Options\n\n");
    exit(0);
  }
  if (settings.help) Die("%s %s\n", usage, optsline);
  if (settings.mapfile == NULL) 
    Die("Must specify map file!\n%s %s\n", usage, optsline);

  /* Load the original dataset */
  iter = loadSampMap(settings.mapfile, &size, &map);

  /* setup stats elements */
  sum = allocPdata();
  rsum = allocPdata();
  if ((sens = (float *)malloc(sizeof(float)*iter)) == NULL)
    Die("sensitivity matrix allocation error!\n");
  if ((ppv = (float *)malloc(sizeof(float)*iter)) == NULL)
    Die("ppv matrix allocation error!\n");

  setupReplicate(&rep, size);

  /* Foreach file to test */
  while(!(argc - optid < 1)) {
    lsize = loadOriginal(argv[optid], &dataset);
    calcStats(dataset, lsize, sum);
    if (lsize != size) {
      printf("ERROR! %s not proper size, ignoring\n", argv[optid]);
    } else {
      sensum = 0.; ppvsum = 0.;
      /* For set number of iterations */
      for (i = 0; i < iter; i++) {
	/* generate a replicate */
	genReplMap(map, i, dataset, size, rep);
	/* Calc stats on replicate */
	calcStats(rep, size, rsum);
	sens[i] = (double)rsum->numcorrect / (double)rsum->numtrust;
	ppv[i] = (double)rsum->numcorrect / (double)rsum->numpred;
	sensum += sens[i];
	ppvsum += ppv[i];
      }
      /* Run statistics */
      meansen = sensum / iter;
      meanppv = ppvsum / iter;
      sensum = 0.; ppvsum = 0.;
      for (i = 0; i < iter; i++) {
	sensum += (sens[i] - meansen) * (sens[i] - meansen);
	ppvsum += (ppv[i] - meanppv) * (ppv[i] - meanppv);
      }
      varsen = sensum / (iter - 1);
      varppv = ppvsum / (iter - 1);
      sdsen = sqrt(varsen);
      sdppv = sqrt(varppv);

      printf("Original Dataset Statistics: %s\n", argv[optid]);
      printPdata(sum);
      printf("Bootstrapping Results: (Sample %d)\n", iter);
      printf("Sensitivity Mean: %f\tVariance %f\tStd.Dev. %f\n",
	  meansen, varsen, sdsen);
      printf("PPV Mean: %f\tVariance %f\tStd.Dev. %f\n",
	  meanppv, varppv, sdppv);
    }

    /* Free dataset */
    freeReplicate(dataset, lsize);
    optid++;
  }

  return 0;
}
