/* Use bootstrapping to get variance and std. dev estimates for sample */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"../squid/squid.h"
#include"../squid/sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../alphabet.h"

#include"opts.h"
#include"bstat.h"

static char optsline[]  = "\
  where options are:\n\
  -h            : get help \n\
  -v            : verbose \n\
  -i <int>      : Sampling iterations (100) \n\
  -d <file>     : Output diff data to <file>\n\
  ";
static char usage[]  = "Usage: bstrap <file>\n";

int 
main (int argc, char **argv) 
{
  OPTM settings;
  int optid, size;
  FILE *hfp;
  PDATA *orig;		/* Original data */
  PDATA *summary;	/* Original sample stats */
  PDATA ***perm;	/* Bootstrap permutations */
  BSTATS *pstats;	/* Bootstrap iteration statistics */
  BSTATS *mean;		/* Bootstrap mean */
  BSTATS *var;		/* Bootstrap Variance */
  BSTATS *stdev;		/* Bootstrap Standard Deviation */

  sre_srandom(time(0));
  if (!(processOpt(&settings, &optid, argc, argv, usage, optsline))) {
    printf("Bad Options\n\n");
    exit(0);
  }
  if (settings.help) Die("%s %s\n", usage, optsline);

  if (settings.histfile != NULL) {
    hfp = fopen(settings.histfile, "w");
  }

  /* Load the original dataset */
  size = loadOriginal(argv[optid], &orig);
  /* Calc stats on original dataset */
  OriginalStats(orig, size, &summary);
  printOstats(summary);

  /* Create a bootstrap permutation of data */
  calcPermDeNovo(orig, settings.iter, size, &perm);
  /* Generate statistics for this permutation */
  PermStats(perm, settings.iter, size, &pstats);
  MeanPermStats(pstats, &mean);
  VarPermStats(pstats, mean, &var);
  StdevPermStats(var, &stdev);

  /* Report results */
  printBstrap(mean, var, stdev, settings.iter);
  return 0;
}

