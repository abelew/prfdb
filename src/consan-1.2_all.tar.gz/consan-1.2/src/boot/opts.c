#include<string.h>
#include<ctype.h>

#include"../squid/squid.h"
#include"../squid/sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"opts.h"

struct opt_s OPTION[] = {
  { "-h",        TRUE,  sqdARG_NONE  },
  { "-v",        TRUE,  sqdARG_NONE  },
  { "-d",        TRUE,  sqdARG_STRING},
  { "-m",        TRUE,  sqdARG_STRING},
  { "-a",	 TRUE,  sqdARG_NONE  },
  { "-i",        TRUE,  sqdARG_INT   },
};

#define NOPTION (sizeof(OPTION) / sizeof(struct opt_s))


int
processOpt(OPTM *options, int *optid, int argc, 
    char **argv, char *usage, char *optsline)
{
  char *optarg; char *optname;

  /* Set defaults in options */
  options->help = FALSE;
  options->verbose = FALSE;
  options->alignment = FALSE;
  options->iter = 10000; /* Default bootstrap value */

  options->histfile = NULL;
  options->mapfile = NULL;

  /* Intepret command line arguments */
  while (Getopt(argc, argv, OPTION, NOPTION, optsline, optid,
	&optname, &optarg)) {
    if (strcmp(optname, "-h") == 0) options->help = TRUE;
    else if (strcmp(optname, "-d") == 0) options->histfile    = optarg;
    else if (strcmp(optname, "-m") == 0) options->mapfile    = optarg;
    else if (strcmp(optname, "-v") == 0) options->verbose      = TRUE;
    else if (strcmp(optname, "-a") == 0) options->alignment   = TRUE;
    else if (strcmp(optname, "-i") == 0) options->iter = atoi(optarg);
  }

  return TRUE;
}


