#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"../squid/squid.h"
#include"../squid/sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"opts.h"
#include"bstat.h"

static char optsline[]  = "\
  where options are:\n\
  -h            : get help \n\
  -i <int>      : Sampling iterations (100) \n\
  ";
static char usage[]  = "Usage: mtest <options> \n";

int 
main (int argc, char **argv) 
{
  OPTM settings;
  int optid, r, n, i, j, err;
  int **map;
  int **reload;
  FILE *ofp;

  if (!(processOpt(&settings, &optid, argc, argv, usage, optsline))) {
    printf("Bad Options\n\n");
    exit(0);
  }
  if (settings.help) Die("%s %s\n", usage, optsline);

  createSampMap(settings.iter, 10, &map);

  ofp = fopen("testfile", "w");
  writeSampMap(ofp, map, settings.iter, 10);
  fclose(ofp);

  loadSampMap("testfile", &r, &n, &reload);

  /* testLoad */
  err = 0;
  if (n != 10) {
    printf("Sample Size wrong!\n");
    err = 1;
  }
  if (r != settings.iter) {
    printf("Iter Size wrong!\n");
    err = 1;
  }
  for (i = 0; i < r; i++) {
    for (j = 0; j < n; j++) {
      if (map[i][j] != reload[i][j]) {
	printf("Error in reload at %d %d\n", i, j);
	err = 1;
      }
    }
  }
  if (!err) printf("No errors, test complete!\n");

  destroySampMap(map, settings.iter);

  return 0;
}

