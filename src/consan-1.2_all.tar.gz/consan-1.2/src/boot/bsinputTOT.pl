#!/usr/bin/perl

while(<>) {
  if (/PAIR TOTALS:/) {
    $totals = 1;
  }
  if ($totals && (/\s+(\d+)\/(\d+) trusted pairs .+/)) {
    $cor = $1; $trust = $2;
  } elsif ($totals && (/\s+(\d+)\/(\d+) predicted pairs .+/)) {
    $pred = $2; $totals = 0;
    print $cor . "\t" . $trust . "\t" . $pred . "\t" . $acorrect . "\t" . $atotal . "\t" . $aliid . "\n";
  } elsif (/Correctly predicted Symbols:\s+(\d+)\/(\d+)/) {
    $acorrect = $1; $atotal = $2;
  } elsif (/Alignment .+ vs .+ \(Given per. id:\s+(.+)\)/) {
      $aliid = $1;
  }
}
