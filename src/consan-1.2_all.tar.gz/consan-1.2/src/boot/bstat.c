/* Use bootstrapping to get variance and std. dev for sample */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"../squid/squid.h"
#include"../squid/sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../alphabet.h"

#include"bstat.h"

/* Function: allocPdata, copyPdata
 * Purpose: 
 *   manipulate PDATA objects 
 *
 * Free a node by simply free(node);
 */
PDATA *
allocPdata()
{
  PDATA *node;

  if ((node = (PDATA *)malloc(sizeof(PDATA))) == NULL)
    Die("malloc current element of pdata failed\n");
  node->numcorrect = 0;
  node->numtrust = 0;
  node->numpred = 0;
  node->aliid = 0;
  node->alitot = 0;
  node->next = NULL;

  return node;
}

void
zeroPdata(PDATA *node)
{
  node->numcorrect = 0;
  node->numtrust = 0;
  node->numpred = 0;
  node->aliid = 0;
  node->alitot = 0;
  node->next = NULL;
}

void
copyPdata(PDATA *from, PDATA *to)
{
  to->numcorrect = from->numcorrect;
  to->numtrust = from->numtrust;
  to->numpred = from->numpred;
  to->aliid = from->aliid;
  to->alitot = from->alitot;
  to->next = from->next;
}

void
printPdata(PDATA *node)
{
  printf("%d\t%d\t%d\t%d\t%d\n", node->numcorrect, node->numtrust,
      	node->numpred, node->aliid, node->alitot);
  if ((node->numtrust != 0) && (node->numpred != 0) && (node->alitot != 0)) {
    printf("Sensitivity %f\tPPV %f\tAlignID %f\n",
	(double)node->numcorrect/(double)node->numtrust,
	(double)node->numcorrect/(double)node->numpred,
	(double)node->aliid/(double)node->alitot);
  }
}

/* Functions: createSampMap, destroySampMap,
 * 		writeSampMap, loadSampMap
 * Purpose:
 *   create r x n array of integers 
 *   where each row (length n) contains the indicies 
 *   of the original data selected for this replicate
 * Args:
 *   repnum - (r) number of replicates
 *   samsize - (n) number of samples
 */
int
createSampMap(int repnum, int samsize, int ***ret_map)
{
  int i,j;
  int dice;
  int **map;

  sre_srandom(time(0));

  /* Allocate map here */
  if ((map = (int **)malloc(sizeof(int *)*repnum)) == NULL)
    Die("Map allocation failed: createSampMap\n");
  for (i = 0; i < repnum; i++) {
    if ((map[i] = (int *)malloc(sizeof(int)*samsize)) == NULL)
      Die("Map inner allocation failed: createSampMap\n");
  }

  /* For set number of iterations */
  for (i = 0; i < repnum; i++) {
    for (j = 0; j < samsize; j++) {
      dice = (int)(samsize * sre_random());
      map[i][j] =  dice;
    }
  }
  *ret_map = map;

  return 1;
}

void
destroySampMap(int **map, int repnum)
{
  int i;

  for (i=0; i < repnum; i++) {
    free(map[i]);
  }
  free(map);
}

int
writeSampMap(FILE *ofp, int **map, int repnum, int samsize)
{
  int i,j;

  fprintf(ofp, "%d\n", repnum);
  fprintf(ofp, "%d\n", samsize);
  /* For set number of iterations */
  for (i = 0; i < repnum; i++) {
    for (j = 0; j < samsize; j++) {
      fprintf(ofp, "%d ", map[i][j]);
    }
    fprintf(ofp, "\n");
  }
  return 1;
}

int
loadSampMap(char *filename, int *ret_r, int *ret_n, int ***ret_map)
{
  FILE *ifp;
  int i, j;
  int iter, ssize;
  int **map;

  ifp = fopen(filename, "r");

  fscanf(ifp, "%d\n", &iter);
  fscanf(ifp, "%d\n", &ssize);

  if ((map = (int **)malloc(sizeof(int *)*iter)) == NULL)
    Die("Map allocation failed\n");
  for (i = 0; i < iter; i++) {
    if ((map[i] = (int *)malloc(sizeof(int)*ssize)) == NULL)
      Die("Map inner allocation failed\n");
  }

  for (i = 0; i < iter; i++) {
    for (j = 0; j < ssize; j++) {
      fscanf(ifp, "%d ", &map[i][j]);
    }
  }

  *ret_r = iter;
  *ret_n = ssize;
  *ret_map = map;

  return 1;
}

/* Function: loadOriginal
 * Args:
 *   filename -- name of file containing original results
 *   dset -- contents of file returned as n array of PDATA
 * Returns:
 *   size of PDATA (n)
 */
int
loadOriginal(char *filename, PDATA **dset)
{
  FILE *ifp;
  int cor, trust, pred;
  int acor, atot;
  int tokens, outputs;
  char line[128];
  char *stok;
  PDATA *prev, *cur;
  PDATA *darray;

  prev = cur = NULL;
  outputs = 0;
  ifp = fopen(filename, "r");

  /* Read in outputs info line by line */
  while (fgets(line, 128, ifp) != NULL) {
    if ((stok = strtok(line, " \t\n")) == NULL) {
      printf("NO TOLKENS\n");
    }
    cor = atoi(stok); tokens = 1;
    while ((stok = strtok(NULL, " \t\n")) != NULL) {
      if (tokens == 1) {
	trust = atoi(stok);
	tokens++;
      } else if (tokens == 2) {
	pred = atoi(stok);
	tokens++;
      } else if (tokens == 3) {
	acor = atoi(stok);
	tokens++;
      } else if (tokens == 4) {
	atot = atoi(stok);
	tokens++;
      } else {
	tokens++;
      }
    }
    if (tokens < 5) printf("INSUFFICENT FIELDS!\n");
    cur = allocPdata();
    cur->numcorrect = cor;
    cur->numtrust = trust;
    cur->numpred = pred;
    cur->aliid = acor;
    cur->alitot = atot;
    cur->next = prev;
    prev = cur;
    outputs++;
  }
  fclose(ifp);
  /* At this point we have a linked list with outputs 
   * elements and head at prev */
  
  /* Setup an array of these guys because that's faster
   * for accessing */
  cur = prev;
  if ((darray = (PDATA*)malloc(sizeof(PDATA)*outputs)) == NULL) 
    Die("malloc darray of pdata failed\n");
  for (cor = 0; cor < outputs; cor++) {
    if (cur == NULL) printf("Problem!\n");
    copyPdata(cur, &(darray[cor]));
    prev = cur; cur = cur->next;
    free(prev);
  }
  *dset = darray;

  return outputs;
}

void
OriginalStats(PDATA *original, int n, PDATA **ret_ostats)
{
  PDATA *summary;
  int i;

  summary = allocPdata();  

  for (i = 0; i < n; i++) {
    summary->numcorrect += original[i].numcorrect;
    summary->numtrust += original[i].numtrust;
    summary->numpred += original[i].numpred;
    summary->aliid += original[i].aliid;
    summary->alitot += original[i].alitot;
  }
  /* printPdata(summary); */

  *ret_ostats = summary;
}

/* Functions: setupPermutation, freePermutation
 * Purpose: 
 *   allocate r x n array of PDATA
 */
void
setupPermutation(PDATA ****rep, int r, int n)
{
  PDATA ***cur;
  int i;

  if ((cur = (PDATA ***)malloc(sizeof(PDATA **)*r)) == NULL)
    Die("malloc of permutation replicates failed\n");
  for (i = 0; i < r; i++) {
    if ((cur[i] = (PDATA **)malloc(sizeof(PDATA *)*n)) == NULL)
      Die("malloc of permutation datasize failed\n");
  }

  *rep = cur;
}

void
freePermutation(PDATA ***rep, int r)
{
  int i;

  for (i=0; i < r; i++) {
    free(rep[i]);
  }
  free(rep);
}

int
calcPermFromMap(int **map, PDATA *original, int r, int n, PDATA ****ret_perm)
{
  int i, j, index;
  PDATA ***perm;

  setupPermutation(&perm, r, n);

  for (i = 0; i < r; i++) {
    for (j = 0; j < n; j++) {
      index = map[i][j];
      perm[i][j] = &(original[index]);
    }
  }
  *ret_perm = perm;

  return 1;
}

int
calcPermDeNovo(PDATA *original, int r, int n, PDATA ****ret_perm)
{
  int i, j, dice;
  PDATA ***perm;

  setupPermutation(&perm, r, n);
  for (i = 0; i < r; i++) {
    for (j = 0; j < n; j++) {
      dice = (int)(n * sre_random());
      perm[i][j] = &(original[dice]);
    }
  }
  *ret_perm = perm;

  return 1;
}

/* Common statistics to gather on any permutation */
BSTATS *
allocBstats(int r)
{
  BSTATS *node;
  int i;

  if ((node = (BSTATS *)malloc(sizeof(BSTATS))) == NULL)
    Die("malloc of bstats failed\n");
  node->reps = r;

  if ((node->sensitivity = (float *)malloc(sizeof(float)*r)) == NULL)
    Die("BStats: sensitivity matrix allocation error!\n");
  if ((node->ppv = (float *)malloc(sizeof(float)*r)) == NULL)
    Die("BStats: ppv matrix allocation error!\n");
  if ((node->ali = (float *)malloc(sizeof(float)*r)) == NULL)
    Die("BStats: ali matrix allocation error!\n");

  for (i = 0; i < r; i++) {
    node->sensitivity[r] = 0.;
    node->ppv[r] = 0.;
    node->ali[r] = 0.;
  }

  return node;
}

void
freeBstats(BSTATS *stats)
{
  free(stats->sensitivity);
  free(stats->ppv);
  free(stats->ali);
  free(stats);
}

void 
DiffStats(PDATA ***perm1, PDATA ***perm2, int r, int n, PDATA **ret_difs)
{
  int i,j;
  PDATA *sums;
  PDATA *sample;

  if ((sample = (PDATA*)malloc(sizeof(PDATA)*r)) == NULL) 
    Die("malloc array of diffs failed\n");
  sums = allocPdata();

  for (i = 0; i < r; i++) {
    for (j = 0; j < n; j++) {
      sums->numcorrect += 
	(perm1[i][j]->numcorrect - perm2[i][j]->numcorrect);
      sums->aliid += 
	(perm1[i][j]->aliid - perm2[i][j]->aliid);
    }
    copyPdata(sums, &(sample[i]));
    zeroPdata(sums);
  }
  free(sums);
  *ret_difs = sample;
}

void 
PermStats(PDATA ***permutation, int r, int n, BSTATS **ret_stats)
{
  int i,j;
  PDATA *sample;
  PDATA *instance;
  BSTATS *pstats;

  sample = allocPdata();
  pstats = allocBstats(r);
  printf("Allocated\n"); fflush(stdout);

  for (i = 0; i < r; i++) {
    for (j = 0; j < n; j++) {
      instance = permutation[i][j];
      sample->numcorrect += instance->numcorrect;
      sample->numtrust += instance->numtrust;
      sample->numpred += instance->numpred;
      sample->aliid += instance->aliid;
      sample->alitot += instance->alitot;
    }
    pstats->sensitivity[i] = 
      (double)sample->numcorrect / (double)sample->numtrust;
    pstats->ppv[i] = 
      (double)sample->numcorrect / (double)sample->numpred;
    pstats->ali[i] = 
      (double)sample->aliid / (double)sample->alitot;
    zeroPdata(sample);
  }

  *ret_stats = pstats;
}

void
MeanPermStats(BSTATS *pstats, BSTATS **ret_mean)
{
  int i;
  BSTATS *sum, *mean;

  sum = allocBstats(1);
  mean = allocBstats(1);

  for (i = 0; i < pstats->reps; i++) {
   sum->sensitivity[0] += pstats->sensitivity[i]; 
   sum->ppv[0] += pstats->ppv[i]; 
   sum->ali[0] += pstats->ali[i];
  }

  mean->sensitivity[0] = sum->sensitivity[0] / pstats->reps;
  mean->ppv[0] = sum->ppv[0] / pstats->reps;
  mean->ali[0] = sum->ali[0] / pstats->reps;

  *ret_mean = mean;
}

  void
VarPermStats(BSTATS *pstats, BSTATS *mean, BSTATS **ret_var)
{
  int i;
  BSTATS *sum;
  BSTATS *var;

  sum = allocBstats(1);
  var = allocBstats(1);

  for (i = 0; i < pstats->reps; i++) {
    sum->sensitivity[0] += (pstats->sensitivity[i] - mean->sensitivity[0]) * 
      (pstats->sensitivity[i] - mean->sensitivity[0]);
    sum->ppv[0] += (pstats->ppv[i] - mean->ppv[0]) * 
      (pstats->ppv[i] - mean->ppv[0]);
    sum->ali[0] += (pstats->ali[i] - mean->ali[0]) * 
      (pstats->ali[i] - mean->ali[0]);
  }
  var->sensitivity[0] = sum->sensitivity[0] / (pstats->reps -1);
  var->ppv[0] = sum->ppv[0] / (pstats->reps -1);
  var->ali[0] = sum->ali[0] / (pstats->reps -1);

  *ret_var = var;
}

void
StdevPermStats(BSTATS *var, BSTATS **ret_stdev)
{
  BSTATS *stdev;

  stdev = allocBstats(1);

  stdev->sensitivity[0] = sqrt(var->sensitivity[0]);
  stdev->ppv[0] = sqrt(var->ppv[0]);
  stdev->ali[0] = sqrt(var->ali[0]);

  *ret_stdev = stdev;
}

/* Reporting */
void
printCBstats(BSTATS *data)
{
  printf("Sens %f\tPPV %f\tAlign %f\t",
      data->sensitivity[0], data->ppv[0], data->ali[0]);
}

void
printOstats(PDATA *summary)
{
  printf("Original Dataset Statistics:\n");
  printPdata(summary);
}

void
printBstrap(BSTATS *mean, BSTATS *var, BSTATS *stdev, int r)
{
  printf("Bootstrapping Results: (Sample %d)\n", r);
  printf("MEANS:\t\t"); printCBstats(mean); printf("\n");
  printf("VARIANCE:\t"); printCBstats(var); printf("\n");
  printf("STD.DEV.:\t"); printCBstats(stdev); printf("\n");
}

void
printHistPer(float *data, int n)
{
  int i, b;
  int bins[101];

  /* Calculate histogram of percent numbers, 
   * binning on 1 percent with rounding. */
  for (i = 0; i < 101; i++) {
    bins[i] = 0;
  }

  for (i = 0; i < n; i++) {
    b = ((int)(data[i] * 100));
    if ((data[i] - b) > 0.5) b++;	/* Round */
    bins[b]++;
  }

  for (i = 0; i < 101; i++) {
    printf("%d\t%d\n", i, bins[i]);
  }
}

void
printDiffNcor(PDATA *data, int r) 
{
  int i;

  for (i = 0; i < r; i++) {
    printf("%d\n", data[i].numcorrect);
  }
}

void
printDiffAli(PDATA *data, int r) 
{
  int i;

  for (i = 0; i < r; i++) {
    printf("%d\n", data[i].aliid);
  }
}

void
printHistBP(PDATA *data, int r, FILE *hfp)
{
  int i, b, idx;
  int *bins;
  int min = 10000;
  int max = -10000;
  int fiveper, begin, middle;
  int test, neg;

  for (i = 0; i < r; i++) {
    if (data[i].numcorrect < min) min = data[i].numcorrect;
    if (data[i].numcorrect > max) max = data[i].numcorrect;
  } 
  b = max - min;

  if ((bins = (int *)malloc(sizeof(int)*b)) == NULL)
    Die("malloc histogram failed\n");
  for (i = 0; i < b; i++) {
    bins[i] = 0;
  }

  for (i = 0; i < r; i++) {
    idx = data[i].numcorrect - min;
    bins[idx]++;
  }

  fiveper = (int)((double)r * 0.05);
  begin = middle = test = neg = 0;
  for (i = 0; i < b; i++) {
    begin += bins[i];
    if ((begin > fiveper) && (middle < (r - (2*fiveper)))) {
      /* Do we cross the zero point? */
      if ((i+min) < 0) neg = 1;
      else if (neg && ((i+min) >= 0)) test = 1;
      /* Do we want to output the whole histogram? */
      if (hfp != NULL) fprintf(hfp, "%d\t%d\n", i + min, bins[i]);
      middle += bins[i];
    }
  }
  if (test) printf("Not significantly different");
  else printf("Passed Test: ARE Significantly Different!\n");
}

void
printHistAC(PDATA *data, int r, FILE *hfp)
{
  int i, b, idx;
  int *bins;
  int min = 10000;
  int max = -10000;
  int fiveper, begin, middle;
  int neg, test;

  for (i = 0; i < r; i++) {
    if (data[i].aliid < min) min = data[i].aliid;
    if (data[i].aliid > max) max = data[i].aliid;
  } 
  b = max - min;

  if ((bins = (int *)malloc(sizeof(int)*b)) == NULL)
    Die("malloc histogram failed\n");
  for (i = 0; i < b; i++) {
    bins[i] = 0;
  }

  for (i = 0; i < r; i++) {
    idx = data[i].aliid - min;
    bins[idx]++;
  }

  fiveper = (int)((double)r * 0.05);
  begin = middle = test = neg = 0;
  for (i = 0; i < b; i++) {
    begin += bins[i];
    if ((begin > fiveper) && (middle < (r - (2*fiveper)))) {
      /* Do we cross the zero point? */
      if ((i+min) < 0) neg = 1;
      else if (neg && ((i+min) >= 0)) test = 1;
      /* Do we want to output the whole histogram? */
      if (hfp != NULL) fprintf(hfp, "%d\t%d\n", i + min, bins[i]);
      middle += bins[i];
    }
  }
  if (test) printf("Not significantly different");
  else printf("Passed Test: ARE Significantly Different!\n");
}
