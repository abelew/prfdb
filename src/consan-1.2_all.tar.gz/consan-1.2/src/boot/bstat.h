#ifndef BSTATS_H_INCLUDED
#define BSTATS_H_INCLUDED

/* The bootstrapping data structures consist of:
 *
 * 1. A single instance of the performance numbers (PDATA).
 *
 * 2. A map of the sampling -- a r x n set of integers where
 *    r = number of replicates
 *    n = sample size
 * this allows one to generate a single permutation for multiple
 * different original datasets. (int **)
 *
 * 3. Original data -- a n array of PDATA (PDATA *)
 *
 * 4. A permutation -- a r x n set of PDATA*.  This is a single
 * instance of bootstrapping.  To save memory, this points to
 * elements in the original data! (PDATA ***)
 *
 * 5. Cummulative statistics for a particular permutation. 
 * Stats exist for every sample (r).  (BSTATS)
 *
 * 6. Differences Array -- an r array of PDATA (PDATA *) 
 * which contains the differences between two permutations.
 */

struct perfdata {
  int numcorrect;
  int numtrust;
  int numpred;
  int aliid;
  int alitot;

  struct perfdata *next;
};
typedef struct perfdata PDATA;

struct bStats {
  int reps;

  float *sensitivity;
  float *ppv;
  float *ali;
};
typedef struct bStats BSTATS;

extern PDATA *allocPdata();
extern void zeroPdata(PDATA *node);
extern void copyPdata(PDATA *from, PDATA *to);
extern void printPdata(PDATA *node);
extern int createSampMap(int repnum, int samsize, int ***ret_map);
extern void destroySampMap(int **map, int repnum);
extern int writeSampMap(FILE *ofp, int **map, int repnum, int samsize);
extern int loadSampMap(char *filename, int *ret_r, int *ret_n, int ***ret_map);
extern int loadOriginal(char *filename, PDATA **dset);
extern void setupPermutation(PDATA ****rep, int r, int n);
extern void freePermutation(PDATA ***rep, int r);
extern int calcPermFromMap(int **map, PDATA *original, int r, 
    int n, PDATA ****ret_perm);
extern int calcPermDeNovo(PDATA *original, int r, int n, PDATA ****ret_perm);
extern BSTATS *allocBstats(int r);
extern void freeBstats(BSTATS *stats);
extern void DiffStats(PDATA ***perm1, PDATA ***perm2, int r, int n, 
    		PDATA **rets_difs);
extern void PermStats(PDATA ***permutation, int r, int n, BSTATS **ret_stats);
extern void MeanPermStats(BSTATS *pstats, BSTATS **ret_mean);
extern void VarPermStats(BSTATS *pstats, BSTATS *mean, BSTATS **ret_var);
extern void StdevPermStats(BSTATS *var, BSTATS **ret_stdev);
extern void OriginalStats(PDATA *original, int n, PDATA **ret_ostats);

extern void printCBstats(BSTATS *data);
extern void printOstats(PDATA *summary);
extern void printBstrap(BSTATS *mean, BSTATS *var, BSTATS *stdev, int r);
extern void printHistPer(float *data, int n);
extern void printDiffNcor(PDATA *data, int r);
extern void printDiffAli(PDATA *data, int r);
extern void printHistAC(PDATA *data, int r, FILE *hfp);
extern void printHistBP(PDATA *data, int r, FILE *hfp);

#endif
