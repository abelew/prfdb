#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"../squid/squid.h"
#include"../squid/sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../alphabet.h"

#include"opts.h"
#include"bstat.h"

static char optsline[]  = "\
  where options are:\n\
  -h            : get help \n\
  -v            : verbose \n\
  -m <map>      : map of samples\n\
  ";
static char usage[]  = "Usage: multi -m <map> <files>\n";

int 
main (int argc, char **argv) 
{
  OPTM settings;
  int optid, size, iter;
  int **map;
  int lsize;
  PDATA *orig;
  PDATA ***perm;
  BSTATS *pstats;       /* Bootstrap iteration statistics */
  BSTATS *mean;         /* Bootstrap mean */
  BSTATS *var;          /* Bootstrap Variance */
  BSTATS *stdev;        /* Bootstrap Standard Deviation */

  if (!(processOpt(&settings, &optid, argc, argv, usage, optsline))) {
    printf("Bad Options\n\n");
    exit(0);
  }
  if (settings.help) Die("%s %s\n", usage, optsline);

  if (settings.mapfile != NULL) {
    /* Load the original dataset */
    loadSampMap(settings.mapfile, &iter, &size, &map);
  } else {
    map == NULL;
  }

  /* Foreach file to test */
  while(!(argc - optid < 1)) {

    lsize = loadOriginal(argv[optid], &orig);
    if (map == NULL) {
      createSampMap(settings.iter, lsize, &map);
      printf("Created Sample Map using Size %d and %d Iters\n", 
	  lsize, settings.iter);
      size = lsize; iter = settings.iter;
    }
    if (size != lsize) {
      printf("ERROR! Datasets of incompatable size!\n");
      printf("Ignoring %s\n", argv[optid]);
    } else {
      printf("\nFor sample: %s\n", argv[optid]);
      calcPermFromMap(map, orig, iter, size, &perm);

      /* Gather Stats on this data set */
      PermStats(perm, iter, size, &pstats);
      MeanPermStats(pstats, &mean);
      VarPermStats(pstats, mean, &var);
      StdevPermStats(var, &stdev);
      /* Report results */
      printBstrap(mean, var, stdev, iter);
      freePermutation(perm, iter);
    }
    optid++;
  }

  return 0;
}
