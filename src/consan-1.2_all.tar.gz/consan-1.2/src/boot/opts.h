#ifndef OPTM_H_INCLUDED
#define OPTM_H_INCLUDED

struct opt {
   int help;
   int verbose;
   int alignment;

   int iter;

   char *histfile;
   char *mapfile;
};
typedef struct opt OPTM;

int processOpt(OPTM *options, int *optid, int argc, 
    char **argv, char *usage, char *optsline); 

#endif
