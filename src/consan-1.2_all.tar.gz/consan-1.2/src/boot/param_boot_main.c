/* param_boot.c 
 * Tue Apr 12 14:04:43 EDT 2005 [Boston]
 *
 * Parameter bootstrapping.  Take in a training set (which may
 * be composed of multiple families).  For each family within the
 * training set, sample sequences from that family to use as
 * a specific instance of the training set.  Build the model(s)
 * and calculate statistics over the set of models built.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"../squid/squid.h"
#include"../squid/sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../consan.h"
#include"../trace.h"
#include"opts.h"
#include"bstat.h"

#define IDX 0
#define JDX 1

static char optsline[]  = "\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-v            : verbose output \n\
-i <int>      : Sampling iterations (100) \n\
-m <filename> : save mean to <filename> as model \n\
-d <filename> : save stdev to <filename> as model \n\
";
static char usage[]  = "Usage: pboot [-options] <training set files> \n";

void gatherCounts(MODEL **scfg, char *filename, int grammar, OPTM settings);
int khs2count(PROBMOD *counts, MSA *msa, int i, int j, char *conss, 
      OPTM settings);
int setupImap(int n, int ***ret_imap);
extern void standardizeMSA(MSA *msa);
extern int msa2seqpair(MSA *msa, int i, int j, char *conss, SEQPR **rnas);
void ParMean(MODEL **models, int r, MODEL **ret_mean);
void ParVar(MODEL **models, MODEL *mean, int r, MODEL **ret_var);
void ParStdDev(MODEL *var, int r, MODEL **ret_stddev);

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid, r; 
  OPTM settings;
  MODEL **scfg;
  MODEL *mean, *var, *stdev;
  FILE *ofp;

  /**** parse arguments *****/
  if (!(processOpt(&settings, &optid, argc, argv, usage, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }
  if (argc - optid < 1) 
	  Die("Incorrect number of command line arguments.\n%s\n%s\n",
	      usage, optsline);

  /* Setup X bootstrapping models in which to gather counts */
  if ((scfg = (MODEL **)malloc(sizeof(MODEL *)*settings.iter)) == NULL) 
       Die("Multiple Model Allocation Failed\n");
  for (r = 0; r < settings.iter; r++) {
   allocModel(&scfg[r]); 
   ZeroModel(scfg[r]);
  }

  /* For each training file */
  while (!(argc - optid < 1)) {
    /* For each family in that file */
      /* Generate X bootstrapping samplings of sequences */
      /* Gather Counts for each sampled set */
    printf("Training set %s\n", argv[optid]); fflush(stdout);
    gatherCounts(scfg, argv[optid], STA, settings);
    optid++;
  }

  /* Convert counts for all X samples into probs */
  for (r = 0; r < settings.iter; r++) {

    /* Here 4 = LRTIE but defined in options.c which I'm
     * not using in the boot directory.  Suboptimal, but
     * at this point I'm more worried about getting done. */
    ProbifySCFG(STA, &(scfg[r]->fmod), NULL, 4, &(scfg[r]->fmod));
    /* LogifySCFG(STA, &(scfg[r]->fmod), &(scfg[r]->imod)); */

  }

  /* Gather statistics over all samples */
  ParMean(scfg, settings.iter, &mean);
  printf("MEAN: \n");
  printModel(stdout, PRINT_FLT, mean);
  if (settings.mapfile != NULL) {
    ofp = fopen(settings.mapfile, "w");
    SaveSCFG(ofp, mean);
    fclose(ofp);
  }

  ParVar(scfg, mean, settings.iter, &var);
  ParStdDev(var, settings.iter, &stdev);
  printf("STD DEV: \n");
  printModel(stdout, PRINT_FLT, stdev);
  if (settings.histfile != NULL) {
    ofp = fopen(settings.histfile, "w");
    SaveSCFG(ofp, stdev);
    fclose(ofp);
  }

  for (r = 0; r < settings.iter; r++) {
    freeModel(scfg[r]);
  }
  free(scfg);
  free(mean); free(var); free(stdev);
  return 1;
}

/* Function: gatherCounts
 * Date:     Fri Feb 28 13:37:21 CST 2003 [I-44 mile 302, OK]
 *
 * Purpose: Convert training sequences into counts
 *
 * Args:    
 *	 counts		integer form of model to keep counts
 *	 filename	training file name
 *	 grammar	which grammar to utilize
 *	 settings	command line options
 *
 * Returns:  nothing
 */
void
gatherCounts(MODEL **scfg, char *filename, int grammar, OPTM settings)
{
  MSAFILE *sfp; MSA *msa;
  int i,j, r,s;
  char *conss;
  int **rmap;
  int **imap;
  int ssize;

  if ((sfp = MSAFileOpen(filename, SQFILE_UNKNOWN, NULL)) == NULL)
    Die("Failed to open sequence file %s\n", filename);

  /* For each family in the input MSA file */
  while ((msa = MSAFileRead(sfp)) != NULL) {
     standardizeMSA(msa);
     /* setupWeights(msa, settings) default 
      * from ../options.c*/
     BlosumWeights(msa->aseq, msa->nseq, msa->alen, 1.0, msa->wgt);

     /* Have n(n-1)/2 pairs.  Want to sample from those.
      * Build an integer map from a pair number to the
      * i and j sequences composed in that pair.  There
      * is probablly a mathematical formula for this,
      * but I'm being lazy. */
     ssize = setupImap(msa->nseq, &imap);
     createSampMap(settings.iter, ssize, &rmap);

     /* For each sampling */
     for (r = 0; r < settings.iter; r++) {
       /* For each pair in the sample */
       for (s = 0; s < ssize; s++) {
	 /* Determine which pair it refers to */
	 i = imap[rmap[r][s]][IDX];
	 j = imap[rmap[r][s]][JDX];

	 /* Build the structure info for that pair */
	 if (msa->ss != NULL) {
	   calcConsStruct(msa->ss[i], msa->aseq[i], msa->ss[j], 
	       msa->aseq[j], msa->alen, &conss);
	 } else if (msa->ss_cons != NULL) {
	   conss = msa->ss_cons;
	 } else {
	   Die("File %s contains no useable structure information!\n", 
	       filename);
	 }

	 /* Count the pair in this sample */
	 khs2count(&(scfg[r]->fmod), msa, i, j, conss, settings);

	 if (msa->ss != NULL) free(conss);
       }
     }

     MSAFree(msa);
  }
  MSAFileClose(sfp);
}

/* Function: khs2count
 *
 * Purpose: 
 *    Count a particular khs entry from a MSA.
 */
int
khs2count(PROBMOD *counts, MSA *msa, int i, int j, char *conss, OPTM settings)
{
   SEQPR *rnas;
   struct trace_s *trc;

   if (msa2seqpair(msa, i, j, conss, &rnas)) {
      if (khs2trace(rnas->alignment->ss, rnas->alignment->alen, 
	       rnas->alignment->aseqs[SEQX], rnas->alignment->aseqs[SEQY], 
	       STA, &trc)) {
	 traceCount(rnas->alignment->prwgt, rnas->sequence[SEQX]->dseq,
	       rnas->sequence[SEQY]->dseq, trc, STA, counts);
         FreeTrace(trc);
      } else {
         printf("Failed khs2count's if within msa2seqpair \n"); fflush(stdout);
         freeSeqPair(rnas);
	 return 0;
      }
      freeSeqPair(rnas);
   } else {
      printf("Failed khs2count's msa2seqpair if\n");
      fflush(stdout);    
      return 0;
   }
   return 1;
}

int
setupImap(int n, int ***ret_imap)
{
  int i,j,pair, ssize;
  int **imap;

  ssize = n * (n-1) / 2;

  if ((imap = (int **)malloc(sizeof(int *)*ssize)) == NULL) {
    Die("IMAP allocation failed!\n");
  }
  for (i = 0; i < ssize; i++) {
    if ((imap[i] = (int *) malloc(sizeof(int) * 2)) == NULL) {
       Die("IMAP inner allocation failed! %d \n", i);
    }
  }
  pair = 0;
  for (i = 0; i < (n-1); i++) {
    for (j = i+1; j < n; j++) {
      imap[pair][IDX] = i;
      imap[pair][JDX] = j;
      pair++;
    }
  }
  *ret_imap = imap;

  return ssize;
}

void
ParMean(MODEL **models, int r, MODEL **ret_mean)
{
  int i,j;
  MODEL *average;

  allocModel(&average); 
  ZeroModel(average);

  for (i = 0; i < r; i++) {
    for (j = 0; j < NTRANS; j++) {
      average->fmod.transitions[j] += models[i]->fmod.transitions[j];
    }
    for (j = 0; j < ECOUNT; j++) {
      average->fmod.emissions[j] += models[i]->fmod.emissions[j];
    }
  }
  
  for (i = 0; i < NTRANS; i++) {
    average->fmod.transitions[i] = average->fmod.transitions[i] / r; 
  }
  for (i = 0; i < ECOUNT; i++) {
    average->fmod.emissions[i] = average->fmod.emissions[i] / r; 
  }

  *ret_mean = average;
}

void 
ParVar(MODEL **models, MODEL *mean, int r, MODEL **ret_var)
{
  int i,j;
  MODEL *sum;
  MODEL *var;

  allocModel(&sum); ZeroModel(sum);
  allocModel(&var); ZeroModel(var);

  for (i = 0; i < r; i++) {
    for (j = 0; j < NTRANS; j++) {
      sum->fmod.transitions[j] += 
	(models[i]->fmod.transitions[j] - mean->fmod.transitions[j]) *
	(models[i]->fmod.transitions[j] - mean->fmod.transitions[j]);
    }
    for (j = 0; j < ECOUNT; j++) {
      sum->fmod.emissions[j] += 
	(models[i]->fmod.emissions[j] - mean->fmod.emissions[j]) *
	(models[i]->fmod.emissions[j] - mean->fmod.emissions[j]);
    }
  }

  for (i = 0; i < NTRANS; i++) {
    var->fmod.transitions[i] = sum->fmod.transitions[i] / (r-1); 
  }
  for (i = 0; i < ECOUNT; i++) {
    var->fmod.emissions[i] = sum->fmod.emissions[i] / (r-1); 
  }
  freeModel(sum);

  *ret_var = var;
}

void 
ParStdDev(MODEL *var, int r, MODEL **ret_stddev)
{
  int i;
  MODEL *stddev;

  allocModel(&stddev); ZeroModel(stddev);

  for (i = 0; i < NTRANS; i++) {
    stddev->fmod.transitions[i] = sqrt(var->fmod.transitions[i]);
  }
  for (i = 0; i < ECOUNT; i++) {
    stddev->fmod.emissions[i] = sqrt(var->fmod.emissions[i]);
  }

  *ret_stddev = stddev;
}
