#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include"../squid/squid.h"
#include"../squid/sqfuncs.h"   /* Squid functions */ 

#include"../cfg.h"
#include"../alphabet.h"

#include"opts.h"
#include"bstat.h"

static char optsline[]  = "\
  where options are:\n\
  -h            : get help \n\
  -v            : verbose \n\
  -a            : Report on Alignment Columns rather than base pairs \n\
		  (By default the report is for base pairs.) \n\
  -i <int>      : Sampling iterations (100) \n\
  -d <filename> : Write histogram to filename \n\
  ";
static char usage[]  = "Usage: sdtest <meth1> <meth2>\n";

int 
main (int argc, char **argv) 
{
  OPTM settings;
  int optid, size, iter;
  int **map;
  int S1size, S2size;
  PDATA *S1, *S2;
  PDATA ***S1perm, ***S2perm;
  PDATA *difs;
  FILE *hfp;

  sre_srandom(time(0));
  if (!(processOpt(&settings, &optid, argc, argv, usage, optsline))) {
    printf("Bad Options\n\n");
    exit(0);
  }
  if (settings.help) Die("%s %s\n", usage, optsline);
  /* Must have specified two files to compare */
  if (argc - optid != 2)
    Die("Incorrect number of command line arguments.\n%s\n%s\n",
	usage, optsline);

  if (settings.mapfile != NULL) {
    /* Load the original dataset */
    loadSampMap(settings.mapfile, &iter, &size, &map);
  } else 
    map == NULL;
  }

  if (settings.histfile != NULL) {
    hfp = fopen(settings.histfile, "w");
  } else {
    hfp = NULL;
  }

  S1size = loadOriginal(argv[optid], &S1);
  optid++;
  S2size = loadOriginal(argv[optid], &S2);
  if (S1size != S2size) 
    Die("Can not compare sets of different size!\n");

  if (map == NULL) {
    createSampMap(settings.iter, S1size, &map);
    iter = settings.iter;
  } else {
    if (size != S1size) {
      Die("Map of incompatible Size, Stopping!\n");
    }
  }

  calcPermFromMap(map, S1, iter, S1size, &S1perm);
  calcPermFromMap(map, S2, iter, S2size, &S2perm);

  DiffStats(S1perm, S2perm, iter, S1size, &difs);
  if (settings.alignment) printHistAC(difs, iter, hfp);
  else printHistBP(difs, iter, hfp);

  return 0;
}

