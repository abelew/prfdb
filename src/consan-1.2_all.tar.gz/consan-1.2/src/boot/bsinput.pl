#!/usr/bin/perl

while(<>) {
  if (/\s+(\d+)\/(\d+) trusted pairs .+/) {
    if (defined($cor)) {
      print $cor . "\t" . $trust . "\t" . $pred . "\t1\t1\n";
    }
    $cor = $1; $trust = $2;
  } elsif (/\s+(\d+)\/(\d+) predicted pairs .+/) {
    $pred = $2;
  }
}
