/* compare_main.c 
 * RDD, Thu Feb 27 16:27:27 CST 2003 [St Louis]
 *
 * Assumes the stockholm format has been co-opted
 * for managing pairwise data.  This is the nuts and
 * bolts function of the constrained sankoff paper.
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<time.h>

#include"squid.h"
#include"sqfuncs.h"   /* Squid functions */ 

#include"cfg.h"
#include"consan.h"
#include"version.h"
#include"trace.h"
#include"alphabet.h"
#include"options.h"
#include"stats.h"
#include"cyk.h"

int outputGivenPair(FILE *ofp, MSA *msa, int i, int j, OPTS settings);

static char optsline[]  = "\
[Given a MSA, calculate foldings for all pairs.  Output two files -- \n\
predicted pairs to stdout and given pairs to a required -s file.] \n\
where options are:\n\
-h            : print short help, usage info, and grammar description\n\
-s <file>     : Output of given structure in ordered pairs (needed for comppair) \n\
-M <int>      : Ensure that pin selection results in something near X Mbytes memory \n\
-C <int>      : do CYK and use <int> pins from trusted alignment \n\
-P <int>      : do CYK and use <int> predicted pins )\n\
-f 	      : do full sankoff (no constraints) \n\
-t            : print traceback\n\
-d            : debugging output \n\
-v            : verbose output \n\
-S            : suppress extra output \n\
";
static char usage[]  = "Usage: scompare [-options] <test msa> \n";

int 
main (int argc, char **argv) 
{
  /**** arguments variables *****/
  int   optid; 
  OPTS settings;
  MODEL *scfg;
  FILE *ofp;
  MSAFILE *sfp;  MSA *msa;	/* Handles for current MSA */
  int i,j;			/* generic loop indicies */
  SEQPR *rnas;			/* Current pair to analyze */
  struct trace_s *trc;		/* Traceback for current pair */
  int score;
  ALIGN *newalign;		/* Predicted alignment according to our model */
  ALIGN *temp;		/* Placeholder */
  FILE *givenofp;		/* Output given structures if asked */
  int npairs, pairsignored;	/* Counters */
  int cando = TRUE;

  time_t starttime, endtime;
  double secused;
  int pextrainfo = FALSE;	/* Include extra info in stockholm files */

  starttime = time(NULL);

  /**** parse arguments *****/
  if (!(processOpts(&settings, &optid, argc, argv, usage, optsline))) {
    printf("%s\n\n", usage);
    exit(0);
  }

  /* Must have specified at least one test file */
  if (argc - optid < 1) 
	  Die("Incorrect number of command line arguments.\n%s\n%s\n",
			  usage, optsline);

  setupModel(&settings, &scfg);
  if (settings.debugg) printModel(stdout, PRINT_INT, scfg);

  if (settings.savefile != NULL) {
     givenofp = fopen(settings.savefile, "w");
  }

  npairs = pairsignored = 0;

  /* For each test file */
  while (!(argc - optid < 1)) {
     if (settings.debugg) printf("Test set %s\n", argv[optid]); fflush(stdout);

     if ((sfp = MSAFileOpen(argv[optid], SQFILE_UNKNOWN, NULL)) == NULL)
	Die("Failed to open sequence file %s\n", argv[optid]);

     /* For each MSA in the current file */
     while ((msa = MSAFileRead(sfp)) != NULL) {
       standardizeMSA(msa);

       if (settings.suppress && (msa->nseq == 2)) {
	 pextrainfo = TRUE;
       }

     /* For each possible pair in the current MSA */
       for (i = 0; i < msa->nseq; i++) {
	 for (j = i+1; j < msa->nseq; j++) {
	   trc = NULL;

	   if (msa2seqpair(msa, i, j, NULL, &rnas)) {
	     if (!(containsAmbiguous(rnas->sequence[SEQX]->seq, 
		     rnas->sequence[SEQX]->len) &&
		   containsAmbiguous(rnas->sequence[SEQY]->seq, 
		     rnas->sequence[SEQY]->len))) {
	       npairs++;

	       if (!settings.fopt) {	
		 cando = setupPins(settings, rnas); 
	         /* printSeqPair(stdout, rnas); fflush(stdout);  */
	       } else {   /* If requesting FULL */
		 if (settings.mset) 
		   forceMemSize(settings, rnas, NULL, NULL);
	       }
	       trc = (struct trace_s *)CYK(rnas, scfg, &settings, &score);

	       if (trc != NULL) {
		 trace2alignment(trc, rnas, &newalign);
		 newalign->prwgt = score; 
		 FreeTrace(trc);

		 temp = rnas->alignment;
		 rnas->alignment = newalign;
		 printStockholm(stdout, rnas, NULL, !pextrainfo);
		 freeAlignment(temp);
	       } else {
		 if (settings.debugg) 
		   printf("\nNOTICE!!!! Pred. Struct. NULL!!!! NOTICE!!!\n\n");
	       }
	     } else {
	       pairsignored++;
	       if (settings.debugg) {
		 printf("Contains N\n"); fflush(stdout);
	       }
	     } /* containsAmbiguous */
	     freeSeqPair(rnas);
	   } /* if msa2seqpair */
	 } /* for j */
       } /* for i */
       MSAFree(msa);
     } /* for all MSA in this file */
     MSAFileClose(sfp);
     optid++;
  } /* for all files */

  if (settings.savefile != NULL) {
    fclose(givenofp);
  }

  endtime = time(NULL);
  secused = difftime(endtime, starttime);

  if (!settings.suppress) {
    printf("%d Pairs Examined\n", (npairs+pairsignored));
    printf("\t%d Tested, %d Ignored\n", npairs, pairsignored);
    printf("Times WALL %.1f\n", secused);
  }
  if (pextrainfo) {
    fprintf(stdout, "\n#=GF TIME  %.1f\n", secused);
    fprintf(stdout, "\n//\n");
  }

  freeModel(scfg);

  return 0;
}
