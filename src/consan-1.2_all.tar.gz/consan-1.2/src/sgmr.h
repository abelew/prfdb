#ifndef SGMR_H_INCLUDED
#define SGMR_H_INCLUDED

/* DP non-terminals: Productions */
/* Nonterminals for MNG and STA grammars */
#define dpS	0
#define dpLx    1
#define dpLy    2
#define dpT	3
#define dpRx    4
#define dpRy    5
#define dpP	6	/* For stacking version */
#define dpN	7	/* For stacking version */

/***********************************************/
/* Rules for RGMR grammars: */
#define TSS	0	/* S -> (xy)S */
#define TSLX	1	/* S -> (x-)Lx */
#define TSLY	2	/* S -> (-y)Ly */
#define TST	3	/* S -> T */
#define TSE	4	/* S -> end */

#define TTT	5	/* T -> T(xy) */
#define TTRX	6	/* T -> Rx(x-) */
#define TTRY	7	/* T -> Ry(-y) */
#define TTS	8	/* T -> (xy)S(xy) */
#define TTP	8	/* T -> (xy)P(xy) STA */
#define TTB	9	/* T -> T (xy)S/P(xy) STA */

#define TLXS	10	/* Lx -> (xy)S */
#define TLXX	11	/* Lx -> (x-)Lx */
#define TLXT	12	/* Lx -> T */
#define TLXE	13	/* Lx -> end */

#define TLYS	14	/* Ly -> (xy)S */
#define TLYY	15	/* Ly -> (-y)Ly */
#define TLYT	16	/* Ly -> T */
#define TLYE	17	/* Ly -> end */

#define TRXT	18	/* Rx -> T(xy) */
#define TRXX	19	/* Rx -> Rx(x-) */
#define TRXS	20	/* Rx -> (xy)S(xy) */
#define TRXP	20	/* Rx -> (xy)P(xy) */
#define TRXB	21	/* Rx -> T (xy)S/P(xy) STA */

#define TRYT	22	/* Ry -> T(xy) */
#define TRYY	23	/* Ry -> Ry(-y) */
#define TRYS	24	/* Ry -> (xy)S(xy) */
#define TRYP	24	/* Ry -> (xy)P(xy) */
#define TRYB	25	/* Ry -> T (xy)S/P(xy) STA */

#define NR_MNG	26

/* Transitions below for STA */
#define TPP	 26	/* P -> (xy)P(x'y') */
#define TPN	 27	/* P -> (xy)N(x'y') */

#define TNS	 28	/* N -> (xy)S */ 
#define TNLX     29	/* N -> (x-)Lx */ 
#define TNLY     30	/* N -> (-y)Ly */ 
#define TNT	 31	/* N -> T(xy) */
#define TNRX     32	/* N -> Rx(x-) */
#define TNRY     33	/* N -> Ry(-y) */
#define TNB      34	/* N -> T (xy)P(x'y') */

/* S, Lx, and Ly are collectively all L states (0 <= L <= 2) */
#define isLstate(idx)  ((((idx) >= 0) && ((idx) < 3)) ? 1 : 0)
/* T, Rx, and Ry are collectively all R states (3 <= L <= 5) */
#define isRstate(idx)  ((((idx) > 2) && ((idx) < 6)) ? 1 : 0)

#endif /* SGMR_H_INCLUDED */
