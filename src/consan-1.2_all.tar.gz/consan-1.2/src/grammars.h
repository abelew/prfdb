extern void cykInitNUS(SEQUENCE *seqX, SEQUENCE *seqY, INTMOD *model, 
      int grammar, int *****mx);
extern void cykFillNUS(SEQUENCE *seqX, SEQUENCE *seqY, INTMOD *model, 
      int grammar, int *****mx);
extern struct trace_s * cykTraceNUS(SEQUENCE *seqX, SEQUENCE *seqY, 
      INTMOD *model, int grammar, int *****mx);
extern int khs2traceNUS(struct tracestack_s *dolist, int *ct, 
      char *Xseq, char *Yseq);
extern int khs2traceYRN(struct tracestack_s *dolist, int *ct, 
      int grammar, char *Xseq, char *Yseq);

extern void cykFillSTA(SEQUENCE *seqX, SEQUENCE *seqY, INTMOD *model, 
      int grammar, int *****mx);
extern struct trace_s * cykTraceSTA(SEQUENCE *seqX, SEQUENCE *seqY, 
      INTMOD *model, int grammar, int *****mx);

extern int khs2traceMNG(struct tracestack_s *dolist, int *ct, 
      char *Xseq, char *Yseq);
extern int khs2traceSTA(struct tracestack_s *dolist, int *ct, 
      char *Xseq, char *Yseq);

extern void ccykDebugSTA(SEQUENCE *seqX, SEQUENCE *seqY, INTMOD *model, 
      int *****mx);
extern void ccykFillSTA(SEQPR *seqs, INTMOD *model, int *****mx);


extern void rccykInitSTA(SEQPR * seqs, INTMOD *model, int *****mx);
extern void rccykFillSTA(SEQPR *seqs, INTMOD *model, int *****mx);
extern void checkCells(SEQPR *seqs, int *****mx, int *****fmx);
extern struct trace_s * rccykTraceSTA(SEQPR * seqs, INTMOD *model, int *****mx);



