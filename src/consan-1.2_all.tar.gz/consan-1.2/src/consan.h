#ifndef CONSAN_H_INCLUDED
#define CONAN_H_INCLUDED

#define NXOR(a, b)   ((!isXconstraint[(a)] && !isYconstraint[(b)])||((isXconstraint[(a)] && isYconstraint[(b)]) && (Yval[(a)] == (b)))) 

#define SEQX	0
#define SEQY	1
#define ALIGNLEN  60

/* Pin selection methods */
#define GIVEN	0	/* use given pins */
#define XBEST	1	/* select x best pins */
#define QUALITY	2	/* select all > quality */
#define SPACED  3	/* select based on spacing (radius) only */
#define QRADIUS	4	/* select > quality with protection radius */
#define GALIGN	5	/* use pins from a given alignment */
#define PTYPES	6

#define DARTLOCATION "dpswalign" /* Executeable */
/* Note that the SCRATCH variable assumes a directory ... therefore
 * it must end with the trailing "/" character! */
#define SCRATCH      "tmp/"



extern char *pinNAME[PTYPES];

/* Coordinates of a pin, links
 * positions in X to positions in Y */
struct coordpair_s {
   int posX;
   int posY;

   float score;		/* Posterior, if we've got it */
   int correct;		/* Boolean -- is this pin correct? */

   struct coordpair_s *next;
   struct coordpair_s *prev;
};
typedef struct coordpair_s COORDS;

/* Statistics about the pins -- quality metrics */
struct pinstats {
  int npins;            /* Total number of pins evaluated */
  int npairs;            /* Total number of pairwise alignments evaluated */
  long pinposs;          /* Total number of possible pins (no gap positions) */

  int TP;               /* Pins suggested in true alignment */
  int FP;               /* Pins suggested not in true alignment */

  int tcorr[101];
  int totalp[101];

  float psum;
  float max;
  float min;
};
typedef struct pinstats PSTATS;

/* Single sequence information.
 * This is something like SQINFO in squid, but
 * that's overkill for most Sankoff uses.  Plus
 * SQINFO doesn't actually keep the sequence itself.
 */
struct sequence_s {
   char *seq;
   char *dseq;

   char name[64];
   char desc[128];
   int len;		/* Length is # columns.  
			   So allocation of chars 
			   must be len+1 (for \0) */

   char *ss;
};
typedef struct sequence_s SEQUENCE;

/* Pairwise sequence alignment bare essentials.
 * This could be kept in SQUID's MSA, but that would
 * be overkill for most Sankoff uses.
 */
struct alignment_s {
   char *aseqs[2];      /* Aligned sequences, contains gaps */
   char *ss;    	/* in KHS format */
   char *pins;    	/* Mark pinned positions, if any */
   int alen;		/* Length is # columns */
   float prwgt;
   float aliid;		/* Alignment identity */
};
typedef struct alignment_s ALIGN;

/* Constraint information necessary for THE algorithm */
struct constraints_s {
  int code;	/* Derivation Code */
  /* Selection method parameters */
  int num;
  int win;
  float cutoff;
  /* Boolean Constraint Map */
  char *isXconstraint;	/* TRUE if constraint; FALSE otherwise */
  char *isYconstraint;	/* TRUE if constraint; FALSE otherwise */
  /* Mapping of pos in X to range in Y */
  int *Yval;	/* Constraint value in Y */
  int *sL;     /* constraint to the left of this region */
  int *sR;     /* constraint to the right of this region */
};
typedef struct constraints_s CNSRNT;

/* Since passing two sequences and a bunch of
 * info about them around alot, we'll define
 * a holder.
 */
struct seqpair_s {
   /* Individual sequence information kept in SQUID's SQINFO
    *          * See sqio.c for routines on this datastructure */
   SEQUENCE *sequence[2];
   ALIGN *alignment;
   CNSRNT *c_info;
};
typedef struct seqpair_s SEQPR;

#define ABSDIST(a,b)	(((a) > (b))? ((a)-(b)):((b)-(a))) 

/* pairwise.c */
extern int allocSeqPair(SEQPR **ret_seqs);
extern void freeSeqPair(SEQPR *seqs);
extern int allocSequence(char *seq, char *name, char *desc, 
    int len, char *ss, SEQUENCE **ret_seq);
extern void freeSequence(SEQUENCE *sequence);
extern int allocAlignment(int length, float weight, ALIGN **linmnt);
extern void freeAlignment(ALIGN *linement);
extern int addSequence(SEQUENCE *sqn, SEQPR *seqpr);
extern int addAlignment(ALIGN *aln, SEQPR *seqpr);
extern void printAln2Single(FILE *fp, SEQPR *seqs);
extern void msa2pairwise(int msalen, char *ss, char *seqX, char *seqY,
          float pairweight, ALIGN **ret_aln);
extern int readSequence(char *filename, SEQPR *seqs);
extern void aln2seqpair(ALIGN *aln, char *Xname, char *Yname, SEQPR **ret_seqs);
extern void dealignSequence(char *original, int msalen, char **gapless);
extern void copySequence(SEQUENCE *from, SEQUENCE *to);
extern void copyAlignment(ALIGN *from, ALIGN *to);
extern void copySeqPair(SEQPR *from, SEQPR *to);
extern void copyCoordinates(COORDS *from, COORDS *to);
extern void printSeqPair(FILE *fp, SEQPR *seqs);
extern void printSequence(FILE *fp, SEQUENCE *seq);
extern void printAlignment(FILE *fp, ALIGN *aln);
extern int compareAlignments(ALIGN *given, ALIGN *calc, 
    int USE_STRUCT, float *ret_score);
extern int checkSequence(SEQUENCE *seq);
extern void printStockholm(FILE *fp, SEQPR *seqs, char *infolines, int closestock);
extern void printAFASTA(FILE *fp, SEQPR *seqs);
extern void makeGenericPair(SEQPR **sp, int lenX, int lenY);
extern void makeGenericSeq(SEQUENCE **s, int len);
extern int alignID(ALIGN *aln);

/* pins.c */
extern COORDS *initCoordList(void);
extern COORDS *newCoord(int posX, int posY, float score);
extern void destroyCoord(COORDS *cons);
extern void freeCoordList(COORDS *cons);
extern void copyCoordinates(COORDS *from, COORDS *to);
extern int countCoordList(COORDS *head);
extern void printCoordList(FILE *ofp, COORDS *head, int withscore);
extern COORDS *attachCoordList(COORDS *parent, int posX, int posY, 
    float score);
extern COORDS * findBestList(COORDS *head);
extern int inList(COORDS *head, int posX, int posY);
extern int iCoordListX(COORDS *head, int posX, int posY, float score);
extern int iCoordListS(COORDS *head, int posX, int posY, float score);
extern int rmCoordList(COORDS *head, int posX, int posY);
extern COORDS * rmBestList(COORDS *head);
extern int align2pins(ALIGN *align, COORDS **ret_head);
extern int checkPinConsistent(COORDS *pins, ALIGN *align);
extern int align2CoordMap(ALIGN *align, int **XYmap);
extern void ZeroPinStats (PSTATS *stats);
extern void evalConstraints(CNSRNT *constraints, int Xlen, ALIGN *align, 
    PSTATS *ret_stats);
extern int evalPins(COORDS *pins, ALIGN *align, PSTATS *ret_stats, 
    int printtrue);
extern void printPinStats(PSTATS pstat, int summary);
  extern int rmSetCoords(COORDS *head, COORDS *rmlist);
  extern int rmXList(COORDS *head, int posX);

/* posteriors.c */
extern int getPTable(ALIGN *align, float ***posttable);
extern void runHolmes(SEQPR *spair, int verbose, int cleanup, 
    float ***posttable, SEQPR **ret_opair);
extern int readPosteriors (char *filename, int columns, int rows, 
    float ***ret_table);
extern void freePosteriors(float **ptable, int rows);
extern void printPosteriors(float **ptable, int columns, int rows);
extern void printPost2column(float **ptable, int columns, int rows);
extern void scoreList(COORDS *head, float **ptable);
extern void testPosteriors(float **ptable, int columns, int rows, ALIGN *given,
    PSTATS *ret_stats);

/* pinselect.c */
/* extern float setupPins(OPTS settings, SEQPR *rnas); */
extern int alignPostBest(float **ptable, ALIGN *optacc, int npins, 
    COORDS **ret_pins);
extern int alignSpaced(ALIGN *galign, float **ptable, int npins, 
    int W, COORDS **ret_pins);
extern int qualityPins(float **ptable, ALIGN *optacc, float edge, 
    COORDS **ret_pins);
extern int qualitySpaced(float **ptable, ALIGN *optacc, float edge, int W,
        COORDS **ret_pins);
extern int justBest(float **ptable, int columns, int rows, int npins, 
    COORDS **ret_pins);
extern int spacedBest(float **ptable, int columns, int rows, int npins, 
    COORDS **ret_pins);
extern int singleBest(float **ptable, int colmin, int colmax, 
    		int rowmin, int rowmax, COORDS **ret_pin);
extern int buildBestSet(COORDS *head, float **ptable, int colmin, 
    int colmax, int rowmin, int rowmax);

/* constraint.c */
extern int gatherConstraints(CNSRNT *cons, int Xlen, COORDS **ret_head);
extern int allocConstraints(CNSRNT **constraints);
extern int allocCons(CNSRNT **constraints, int Xlen, int Ylen);
extern void freeConstraints(CNSRNT *constraints);
extern void createConstraints(char *filename, SEQPR *seqs);
extern int readConstraints(char *filename, char *nameX, char *nameY, 
    COORDS **ret_segs);
extern void buildConstraints(int Xlen, int Ylen, COORDS *cons, 
    int code, CNSRNT **ret_cons);
extern void printConstraints(FILE *ofp, int lenX, 
    CNSRNT *cons, int print_map);
extern void loadConstraints(char *filename, SEQPR *seqs);
extern void printCNTMethod(int code);
extern void setCNTMethod(CNSRNT *cons, int num, int win, float cutoff);

extern int checkConstraints(ALIGN *align, CNSRNT *cinfo);


#endif /* CONSAN_H_INCLUDED */
