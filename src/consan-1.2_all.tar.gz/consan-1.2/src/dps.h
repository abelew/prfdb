/* dps.h */

/* A fill matrix is a five dimensional integer matrix 
 * The matrix is kept as mtx[nonterminal][j][d1][l][d2]
 * where (j,d1) are coordinates in X, 
 * (l, d2) are coordinates in Y,
 * and v is the nonterminal of the grammar.
 */ 

/* The simplest version of these allocate a half matrix for each DPS. */
extern void allocFillMx(int grammar, int lenX, int lenY, int ******ret_mx);
extern void freeFillMx(int grammar, int lenX, int *****mx);
extern void patternFillMx(int grammar, int lenX, int lenY, int *****mx);
extern void zeroFillMx(int grammar, int lenX, int lenY, int *****mx); 
extern unsigned fakeAllocMx(int grammar, int lenX, int lenY);
extern void printAlignMx(FILE *fp, int *****mx, SEQUENCE *seqX, SEQUENCE *seqY,
      int v, int d1, int d2, int gmr);
extern void printFoldMx(FILE *fp, int *****mx, SEQUENCE *seqX, SEQUENCE *seqY,
      int v, int j, int l, int gmr);
extern void printYFoldMx(FILE *fp, int *****mx, SEQUENCE *seqX, SEQUENCE *seqY,
      int v, int j, int d1, int gmr);
extern void printXFoldMx(FILE *fp, int *****mx, SEQUENCE *seqX, SEQUENCE *seqY,
      int v, int l, int d2, int gmr);

/* You can change the initialization so that you do not need to keep 
 * the distance equals zero elements within the matrix. */
extern void allocFillMx_nz(int grammar, int lenX, int lenY, int ******ret_mx);
extern void freeFillMx_nz(int grammar, int lenX, int *****mx);
extern void patternFillMx_nz(int grammar, int lenX, int lenY, int *****mx);
extern void zeroFillMx_nz(int grammar, int lenX, int lenY, int *****mx); 
extern unsigned fakeAllocMx_nz(int grammar, int lenX, int lenY);
extern void printAlignMx_nz(FILE *fp, int *****mx, SEQUENCE *seqX, 
      SEQUENCE *seqY, int v, int d1, int d2, int gmr);
extern void printFoldMx_nz(FILE *fp, int *****mx, SEQUENCE *seqX, 
      SEQUENCE *seqY, int v, int j, int l, int gmr);
extern void printYFoldMx_nz(FILE *fp, int *****mx, SEQUENCE *seqX, 
      SEQUENCE *seqY, int v, int j, int d1, int gmr);
extern void printXFoldMx_nz(FILE *fp, int *****mx, SEQUENCE *seqX, 
      SEQUENCE *seqY, int v, int l, int d2, int gmr);

/* Even more memory saving -- we can use knowledge of the constraints
 * to allocate only the segments specified.  */
extern void allocRedFillMx(int grammar, CNSRNT *constraint,
      int lenX, int lenY, int ******ret_mx);
extern void freeRedFillMx(int grammar, int lenX, int *****mx);
extern void zeroRedFillMx(int grammar, int *sL, int *sR, int lenX, int lenY, 
      int *****mx);
extern unsigned fakeRedAllocMx(int grammar, int *sL, int *sR, 
      int lenX, int lenY);
extern void printRedAlignMx(FILE *fp, int *****mx, SEQUENCE *seqX, 
      SEQUENCE *seqY, int v, int d1, int d2, int gmr, int *sL, int *sR);
extern void printRedFoldMx(FILE *fp, int *****mx, SEQUENCE *seqX, 
      SEQUENCE *seqY, int v, int j, int l, int gmr, int *sL, int *sR);
extern void printRedYFoldMx(FILE *fp, int *****mx, SEQUENCE *seqX, 
      SEQUENCE *seqY, int v, int j, int d1, int gmr, int *sL, int *sR);


