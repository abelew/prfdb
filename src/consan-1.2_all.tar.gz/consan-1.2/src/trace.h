#ifndef TRACE_H_INCLUDED
#define TRACE_H_INCLUDED

/* Structure: trace_s
 * 
 * Binary tree structure for storing an RNA structure,
 * derived as a traceback of an alignment of SCFG to sequence.
 */
struct trace_s {
  /* Alignment coordinates */
  int emitl;	/* left position in ALIGNMENT coordinates */
  int emitr;	/* right position in ALIGNMENT coordinates */

  /* For first sequence (X) */
  int emitLx;			/* i position (0..N-1) or -1 if nothing   */
  int emitRx;			/* j position (0..N-1) or -1 if nothing   */

  /* For second sequence (Y) */
  int emitLy;			/* k position (0..M-1) or -1 if nothing   */
  int emitRy;			/* l position (0..M-1) or -1 if nothing   */

  int transition;               /* Transition to this node */
  int nonterminal;		/* Nonterminal type for this node */

  struct trace_s *nxtl;		/* ptr to left (or only) branch, or NULL for end  */
  struct trace_s *nxtr;		/* ptr to right branch (for BIF only, else NULL)  */
  struct trace_s *prv;          /* ptr to parent                                  */
};

/* Structure: tracestack_s
 *
 * A pushdown stack used for traversing a binary tree of trace_s structures.
 */
struct tracestack_s {
  struct trace_s      *node;
  struct tracestack_s *nxt;
};

/* in trace.c */
extern void traceCount(float wgt, char *dseqX, char *dseqY, struct trace_s *tr, 
      int grammar, PROBMOD *cfg);
extern struct trace_s * InitTrace(void);
extern struct trace_s * AttachTrace(struct trace_s *parent, int nonterminal, 
      int emitLx, int emitRx, int emitLy, int emitRy, int transition);
extern struct trace_s * AttachATrace(struct trace_s *parent, int nonterminal, 
      int emitl, int emitr, int emitLx, int emitRx, int emitLy, int emitRy, 
      int transition);
extern void FreeTrace(struct trace_s *tr);
extern struct tracestack_s * InitTracestack(void);
extern void PushTracestack(struct tracestack_s *stack, struct trace_s *tracenode);
extern struct trace_s * PopTracestack(struct tracestack_s *stack);
extern void FreeTracestack(struct tracestack_s *stack);
extern void printTrace(FILE *fp, struct trace_s *tr, SEQPR *seqs);
extern void printTraceGC(FILE *fp, struct trace_s *tr);
extern int compareTrace(struct trace_s *tr1, struct trace_s *tr2);

extern void trace2alignment(struct trace_s *tr, SEQPR *seqs, ALIGN **align);

/* in khs.c */
extern int khs2trace(char *ss, int len, char *seqX, char *seqY,
              int grammar, struct trace_s **ret_tr);

#endif /* TRACE_H_INCLUDED */

