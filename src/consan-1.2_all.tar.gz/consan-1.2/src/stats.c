/* stats.c
 * Routines for gathering structure comparative statistics
 */

#include<string.h>
#include<ctype.h>

#include"squid.h"

#include"cfg.h"
#include"options.h"
#include"stats.h"

/* Function: CompStruct
 * Date:     RDD, Thu Nov 15 17:51:38 2001 [St. Louis]
 *
 * Purpose:  Compare a predicted (test) structure to
 * 	a given (trusted) structure.  Collect statistics
 * 	about accuracy of prediction.
 *
 * Args:
 *      len             Length of alignment
 *      trusted         given structure
 *      test            predicted structure
 *      totals          Where to store totals
 *                      (add to existing numbers)
 *      iseq            Flag for verbose output.
 *      do_mathews      Turn on Mathews +/- method of evaluation bp
 *      ct_knots        Turn on knots as bases in structure
 *
 * Returns:
 *      TRUE            if comparison executed correctly
 *      FALSE           if problem with either KHS formatted structure
 *
 *      totals          is filled (adds to current values in totals)
 */
int
CompStruct (int len, char *trusted, char *test, STATS *totals,
    int iseq, int do_mathews, int ct_knots)
{   
  int *trusted_ct;  int *test_ct;
  int pos;

  int kpairs;     /* count of base pairs in a known (trusted) structure     */
  int tpairs;     /* count of base pairs in a test (predicted) structure    */
  int kcorrect;   /* # bp in a known structure that are correctly predicted */
  int tcorrect;   /* # bp in a test structure that are true                 */

  float sensitivity, specificity;

  if (! KHS2ct(trusted, len, ct_knots, &trusted_ct)) {
    printf("[bad trusted structure]\n");
    free(trusted_ct); return (FALSE);
  }
  if (! KHS2ct(test, len, ct_knots, &test_ct)) {
    printf("[bad predicted/test structure]\n");
    free(test_ct); free(trusted_ct);
    return (FALSE);
  }

  tpairs = tcorrect = 0;        /* Test Structure */
  kpairs = kcorrect = 0;        /* Trusted Structure */

  for (pos = 0; pos < len; pos++) {
    /* Sensitivity */
    if (trusted_ct[pos] > pos) {       /* Known bp in trusted seq */
      kpairs++;
      if (do_mathews) {
	if (test_ct[pos] == trusted_ct[pos] ||                       /* i,j */
	    (pos > 0  && test_ct[pos-1] == trusted_ct[pos]) ||     /* i-1, j */
	    (pos < len  && test_ct[pos+1] == trusted_ct[pos]) ||   /* i+1, j */
	    (test_ct[pos] > 0 && test_ct[pos] == trusted_ct[pos]-1) || /* i, j-1 */
	    (test_ct[pos] > 0 && test_ct[pos] == trusted_ct[pos]+1))  /* i, j+1 */
	  kcorrect++;
      } else {
	if (test_ct[pos] == trusted_ct[pos] ) kcorrect++;
      }
    }
    /* PPV */
    if (test_ct[pos] > pos) {  /* Known bp in test seq */
      tpairs++;
      if (do_mathews) {
	if (trusted_ct[pos] == test_ct[pos] ||                       /* i,j */
	    (pos > 0  && trusted_ct[pos-1] == test_ct[pos]) ||     /* i-1, j */
	    (pos < len  && trusted_ct[pos+1] == test_ct[pos]) ||   /* i+1, j */
	    (trusted_ct[pos] > 0 && trusted_ct[pos] == test_ct[pos]-1) || /* i, j-1 */
	    (trusted_ct[pos] > 0 && trusted_ct[pos] == test_ct[pos]+1))  /* i, j+1 */
	  tcorrect++;
      } else {
	if (trusted_ct[pos] == test_ct[pos] ) tcorrect++;
      }
    }
  }

  /* Note: Under default rule tcorrect = kcorrect; but not necessarily
   *       * the case under relaxed mathews criteria */
  totals->trust_pairs += kpairs;
  totals->test_pairs += tpairs;

  totals->trust_correct += kcorrect;
  totals->test_correct += tcorrect;

  totals->nseq++;
  totals->positions += len;

  sensitivity = 100. * (float) kcorrect/ (float) kpairs;
  specificity = 100. * (float) tcorrect/ (float) tpairs;

  /* print out per sequence info */
  if (iseq) {
    printf(" ==  %.2f  %.2f\n", sensitivity, specificity);
    printf("   %d/%d trusted pairs correctly predicted (%.2f%% sensitivity)\n",
	kcorrect, kpairs, sensitivity);
    printf("   %d/%d predicted pairs are true (%.2f%% PPV/specificity)\n",
	tcorrect, tpairs, specificity);
    puts("");
  }

  free(test_ct); free(trusted_ct);
  return 1;
}

/* Function: PrintTableHeader
 * Date:     RDD, Sat Dec  8 16:28:29 2001 [St. Louis]
 *
 * Purpose:  Print header for permutation test table
 *
 * Note: This header assumes PrintTableLine is
 * 	used to produce each line of statistics.  This
 * 	allows computation to occur between lines.  However,
 * 	it does make the output table "break" if verbose 
 * 	outputs are requested as they will interrupt the table.
 */
void
PrintTableHeader()
{
  printf("\nDataset\t\t\tSeqs\tPositions\tSens\tMin\tMax\tSpec\tMin\tMax\tCval\tAcc\tMin\tMax\n");
  printf("========\t\t====\t=========\t====\t===\t===\t====\t===\t===\t====\t===\t===\t===\n");
}

/* Function: PrintTableLine
 * Date:     RDD, Sat Dec  8 16:28:36 2001 [St. Louis]
 *
 * Purpose:  Print a single line for each set of stats gathered.
 *
 * Args:     
 * 	label		A string label for this line.
 * 	statistics	Gathered pos/neg numbers for test 
 * 	
 * Note: This is assumed to be used with PrintTableHeader.
 * 	This allows computation to occur between lines.  However,
 * 	it does make the output table "break" if verbose 
 * 	outputs are requested as they will interrupt the table.
 */
void
PrintTableLine (char * label, STATS statistics, int outputrange)
{
   float sens, spec, acc, cval;
   char outlabel[25];
   int len;
   char *tmp;

   sens = 100. * (float) statistics.correct/ (float) statistics.trusted;
   spec = 100. * (float) statistics.correct/ (float) statistics.predicted;
   cval = sqrt(sens*spec);
   acc = 100. * (float) (statistics.dscorrect + statistics.sscorrect) / (float) statistics.positions;

   /* Could format output depending on size of test sets */
   if (outputrange) {
      /* Format Dataset name to fit in our output dimensions */
      len = strlen(label);
      if (len > 20) {
        tmp = &(label[(len-20)]);
      } else {
	 tmp = label;
      }
      strncpy(outlabel, tmp, 20);
      outlabel[21] = '\0';
      
      printf("%-20s\t%5d\t%8d\t%.2f%%\t%.2f%%\t%.2f%%\t%.2f%%\n",
	    outlabel, statistics.npairs, statistics.positions, 
	    sens, spec, cval, acc);
   } else {
      printf("%-20s\t%5d\t%8d\t%.2f%%\t   \t   \t%.2f%%\t   \t   \t%.2f%%\t%.2f%%\n",
	    label, statistics.npairs, statistics.positions, 
	    sens, spec, cval, acc);
   }
}

/* Function: accumulateStats 
 * Date:     RDD, Sat Dec  8 16:28:49 2001 [St. Louis]
 *
 * Purpose:  set contents of STAT structre to zero.
 */
void
accumulateStats (STATS *newtotals, STATS *globals)
{
  globals->nseq = globals->nseq + newtotals->nseq;
  globals->npairs = globals->npairs + newtotals->npairs;
  globals->Nfree = globals->Nfree + newtotals->Nfree;
  globals->containN = globals->containN + newtotals->containN;
  globals->positions = globals->positions + newtotals->positions;

  globals->trust_pairs = globals->trust_pairs + newtotals->trust_pairs;
  globals->test_pairs = globals->test_pairs + newtotals->test_pairs;
  globals->trust_correct = globals->trust_correct + newtotals->trust_correct;
  globals->test_correct = globals->test_correct + newtotals->test_correct;

  globals->trusted = globals->trusted + newtotals->trusted;
  globals->predicted = globals->predicted + newtotals->predicted;
  globals->correct = globals->correct + newtotals->correct;

  globals->dscorrect = globals->dscorrect + newtotals->dscorrect;
  globals->sscorrect = globals->sscorrect + newtotals->sscorrect;
}

/* Function: PrintTotals
 * Date:     RDD, Thu Nov 15 17:51:47 2001 [St. Louis]
 *
 * Purpose:  Print test set totals in paragraph format.
 */
float
PrintTotals(STATS *statistics, int withranges, int withcs)
{
  float sensitivity, specificity;
  float cval;

  /* If either denominator is 0 -- then by def sens and spec are zero */
  if (statistics->trust_pairs > 0) {
    sensitivity = 100. * (float) statistics->trust_correct / 
      (float) statistics->trust_pairs;
  } else { sensitivity = 0.0; }
  if (statistics->test_pairs > 0) {
  specificity = 100. * (float) statistics->test_correct / 
    			(float) statistics->test_pairs;
  } else {specificity = 0.0; }

  cval = sqrt(sensitivity*specificity);

  /* And the final summary: */
  if (withranges) {
    puts("");
    printf("Overall structure prediction accuracy");
    printf("(%d sequences, %d positions)  Cval: %.2f%%\n",
	statistics->nseq, statistics->positions, cval);
    printf("   %d/%d trusted pairs correctly predicted (%.2f%% sensitivity\n",
	statistics->trust_correct, statistics->trust_pairs, sensitivity);
    printf("   %d/%d predicted pairs are true (%.2f%% PPV/specificity)\n",
	statistics->test_correct, statistics->test_pairs, specificity);
    puts("");
  } else {
    printf("Overall structure prediction accuracy");
    printf("(%d sequences, %d positions)  Cval: %.2f%%\n",
	statistics->nseq, statistics->positions, cval);
    printf("   %d/%d trusted pairs correctly predicted (%.2f%% sensitivity)\n",
	statistics->trust_correct, statistics->trust_pairs, sensitivity);
    printf("   %d/%d predicted pairs are true (%.2f%% PPV/specificity)\n",
	statistics->test_correct, statistics->test_pairs, specificity);
    puts("");
  }

  return cval;
}

/* Function: ZeroStats
 * Date:     RDD, Sat Dec  8 16:28:49 2001 [St. Louis]
 *
 * Purpose:  set contents of STAT structre to zero.
 */
void
ZeroStats (STATS *statistics)
{ 
  statistics->nseq = 0;
  statistics->npairs = 0;
  statistics->Nfree = 0; 
  statistics->containN = 0; 

  statistics->trust_pairs = 0;
  statistics->test_pairs= 0;
  statistics->trust_correct = 0;
  statistics->test_correct = 0;
  statistics->positions = 0;

  statistics->correct = 0;
  statistics->trusted = 0;
  statistics->predicted = 0;

  statistics->dscorrect = 0;
  statistics->sscorrect = 0;

}

int
testAlignPairs (MSA *kmsa, MSA *tmsa)
{
  int    idx;                   /* counter for sequences                     */
  char **kraw;                  /* dealigned trusted seqs                    */
  char **traw;                  /* dealigned test sequences                  */

  /* test that they're the same! */
  if (kmsa->nseq != tmsa->nseq) {
     Die("files %s and %s do not contain same number of seqs!\n", 
	 kmsa->name, tmsa->name); 
    return 0;
  }

  for (idx = 0; idx < kmsa->nseq; idx++)
  {
    s2upper(kmsa->aseq[idx]);
    s2upper(tmsa->aseq[idx]);
  }
  /* another sanity check */
  for (idx = 0; idx < kmsa->nseq; idx++)
    if (strcmp(kmsa->sqname[idx], tmsa->sqname[idx]) != 0) {
      Die("seqs in %s and %s don't seem to be in the same order\n  (%s != %s)",
	  kmsa->name, tmsa->name, kmsa->sqname[idx], tmsa->sqname[idx]);
      return 0;
    }

  /* and *another* sanity check */
  DealignAseqs(kmsa->aseq, kmsa->nseq, &kraw);
  DealignAseqs(tmsa->aseq, tmsa->nseq, &traw);
  for (idx = 0; idx < kmsa->nseq; idx++)
    if (strcmp(kraw[idx], traw[idx]) != 0) {
      Die("raw seqs in %s and %s are not the same (died at %s, number %d)\n",
	  kmsa->name, tmsa->name, kmsa->sqname[idx], idx);
      return 0; 
	  }
  Free2DArray((void **) kraw, kmsa->nseq);
  Free2DArray((void **) traw, tmsa->nseq);

  return 1;
}
