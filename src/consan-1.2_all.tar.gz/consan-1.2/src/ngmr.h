#ifndef NGMR_H_INCLUDED
#define NGMR_H_INCLUDED

/* DP non-terminals: Productions */
/* Nonterminals for NUS and YRN grammars */
#define dpS      0 
#define dpLm     1
#define dpLx     2
#define dpLy     3
#define dpRm     4
#define dpRx     5
#define dpRy     6
#define dpP	 7	/* For stacking version */
#define dpN	 8	/* For stacking version */

/***********************************************/
/* Rules for NGMR grammars: */
#define TSS      0	/* S -> (xy)S(x'y')  NUS */
#define TSP      0	/* S -> (xy)P(x'y')  YRN */
#define TSLM     1	/* S -> (xy)Lm */ 
#define TSLX     2	/* S -> (x-)Lx */ 
#define TSLY     3	/* S -> (-y)Ly */ 
#define TSRM     4	/* S -> Rm(xy) */
#define TSRX     5	/* S -> Rx(x-) */
#define TSRY     6	/* S -> Ry(-y) */
#define TSB      7	/* S -> Lm S */

#define TLMS     8	/* Lm -> (xy)S(x'y') NUS */
#define TLMP     8	/* Lm -> (xy)P(x'y') YRN */
#define TLMM     9	/* Lm -> (xy)Lm */ 
#define TLMX     10	/* Lm -> (x-)Lx */ 
#define TLMY     11	/* Lm -> (-y)Ly */ 

#define TLXS     12	/* Lx -> (xy)S(x'y') NUS */
#define TLXP     12	/* Lx -> (xy)P(x'y') YRN */
#define TLXM     13	/* Lx -> (xy)Lm */ 
#define TLXX     14	/* Lx -> (x-)Lx */ 

#define TLYS     15	/* Ly -> (xy)S(x'y') NUS */
#define TLYP     15	/* Ly -> (xy)P(x'y') YRN */
#define TLYM     16	/* Ly -> (xy)Lm */ 
#define TLYY     17	/* Ly -> (-y)Ly */ 

#define TRMM     18	/* Rm -> Rm(xy) */ 
#define TRMX     19	/* Rm -> Rx(x-) */ 
#define TRMY     20	/* Rm -> Ry(-y) */ 
#define TRME     21	/* Rm -> end */ 

#define TRXM     22	/* Rx -> Rm(xy) */ 
#define TRXX     23	/* Rx -> Rx(x-) */ 
#define TRXE     24	/* Rx -> end */ 

#define TRYM     25	/* Ry -> Rm(xy) */ 
#define TRYY     26	/* Ry -> Ry(-y) */ 
#define TRYE     27	/* Ry -> end */ 

	/* Transitions below for YRN only */

#define TPP	 28	/* P -> (xy)P(x'y') */
#define TPN	 29	/* P -> (xy)N(x'y') */

#define TNLM     30	/* N -> (xy)Lm */ 
#define TNLX     31	/* N -> (x-)Lx */ 
#define TNLY     32	/* N -> (-y)Ly */ 
#define TNRM     33	/* N -> Rm(xy) */
#define TNRX     34	/* N -> Rx(x-) */
#define TNRY     35	/* N -> Ry(-y) */
#define TNB      36	/* N -> Lm S */

/* Lm, Lx, and Ly are collectively all L states (1 <= L <= 3) */
#define isLstate(idx)  ((((idx) > 0) && ((idx) < 4)) ? 1 : 0)
/* Rm, Rx, and Ry are collectively all R states (4 <= L <= 6) */
#define isRstate(idx)  ((((idx) > 3) && ((idx) < 7)) ? 1 : 0)

#endif /* NGMR_H_INCLUDED */
