/* misc.c 
 *
 * Assorted utility functions 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "squid/squid.h"
#include "alphabet.h"	/* Digitize */
#include "cfg.h"

void
standardizeMSA(MSA *msa)
{
   int i;

   /* Ensure a consistent alphabet -- in this case all uppers */
   for (i = 0; i < msa->nseq; i++) {
      s2upper(msa->aseq[i]);
      StripDegeneracy(msa->aseq[i]); 
      ToRNA(msa->aseq[i]);
   }
}

/* Function: dealignedCoord 
 * Date:     RDD, Thu Feb 27 16:18:56 CST 2003 [St Louis]
 *
 * Purpose: we need to translate an aligned coordinate 
 * of a bifurcation to a sequence specific coordinate
 * (which will be independent of gaps).
 *
 * Args:     
 * 	aseq	Aligned Sequence (may contain gaps) 
 * 	startp	alignment left edge 
 * 	stopp   alignment right edge 
 * 	start	startp in dealigned coordinate system
 *
 * Returns:
 * 	stopp in dealigned coordinate sytem
 */
   int
dealignedCoord(char *aseq, int startp, int stopp, int start)
{
   int i, rlen;

   rlen = 0;
   for (i = startp; i <= stopp; i++) {
      if (! isgap(aseq[i])) rlen++;
   }
   return (rlen + start - 1);
}

/* Function: isRNAComplement()
 * 
 * Purpose:  Returns TRUE if sym1, sym2 are Watson-Crick complementary.
 *           If allow_gu is TRUE, GU pairs also return TRUE.
 */
int
isRNAComplement(char sym1, char sym2, int allow_gu)
{
  sym1 = toupper(sym1);
  sym2 = toupper(sym2);

  if ((sym1 == 'A' && sym2 == 'U') ||
      (sym1 == 'C' && sym2 == 'G') ||
      (sym1 == 'G' && sym2 == 'C') ||
      (sym1 == 'U' && sym2 == 'A') ||
      (allow_gu && sym1 == 'G' && sym2 == 'U') ||
      (allow_gu && sym1 == 'U' && sym2 == 'G'))
    return 1;
  else
    return 0;
}

int
isRNAbp(int pairidx, int allow_gu)
{
  if ((pairidx == 3)/* AU */ || (pairidx == 6)/* CG */
  	|| (pairidx == 9)/* GC */ || (pairidx == 12))/* UA */ 
     return TRUE;
  else if (allow_gu) 
     if ((pairidx == 11)/* GU */ || (pairidx == 14))/* UG */
	return TRUE;

  return FALSE;
}

/* Function: isIdentical()
 * 
 * Purpose:  Returns TRUE if sym1, sym2 are identical.
 */
int
isIdentical(char sym1, char sym2)
{
  sym1 = toupper(sym1);
  sym2 = toupper(sym2);

  if ((sym1 == 'A' && sym2 == 'A') ||
      (sym1 == 'C' && sym2 == 'C') ||
      (sym1 == 'G' && sym2 == 'G') ||
      (sym1 == 'U' && sym2 == 'U')) 
    return 1;
  else
    return 0;
}

/* Function: find_split
 *
 * Purpose: determine if any pairing between a
 * 		given set of coordinates.
 *
 * Args:
 *     ct 	sequence in ct format
 *     i	starting location
 *     j 	ending location
 *
 * Returns:
 * 	-1	no pairs exist between i and j
 * 	num	endpoint of left most stem
 */
int
find_split (int *ct, int i, int j)
{
  int k;
 
  for (k = i; k <= j; k++) {
    if (ct[k] >= 0) {
      /* printf("FOUND at %d, %d\n", k, ct[k]); */
      return ct[k];
    }
  }
  return -1;
}

/* Function: mismatch_label
 *
 * Purpose: convert single pair internal loops 
 *		to mismatches 
 *
 * Args:
 *	ct	structure represented in ct format
 *	len	sequence length
 * 
 * Returns: nothing
 */
void
mismatch_label(int *ct, int len)
{
  int i, j;

  for (i = 0; i < (len-2); i++) {
    j = ct[i]; 
	/* i participates in a downstream pairing interaction */
    if ((j >= 0) && (j > i)) {	
	/* between adjacent basepairs is a single paired internal loop */
      if ((ct[i+2] == j-2) && (ct[i+1] == -1) && (ct[j-1] == -1)) {
	/* Relabel internal loop as paired (effectively, a mismatch) */
	ct[i+1] = j-1;
	ct[j-1] = i+1;
      }
    }
  }
}

/* Function: print_CT()
 * 
 * Purpose:  Converts the output of program to the "connect" format.
 *           It allows to convert any fragment of the sequence.
 *           
 * Args:     ofp	      - where to send the output
 *           seq      - sequence to fold. 
 *           len      - seq length
 *           ss       - secondary structure in CT form.
 *                      ss[i] = j  if position i paired to position j
 *                      ss[i] = -1 if position i is unpaired
 *         
 * Return:   (void)
 */
void
print_CT(FILE *ofp, char *seq, int len, int *ss, char *name)
{
  int i;          /* initial position of fragment. 0,..,d-1 */

  /*
  fprintf(ofp,"\n ct_output \n");
  fprintf(ofp,"----------------------------------------------------------------------\n");
  */

  fprintf(ofp, "%5d \t %s\n", len, name);
  for (i = 0; i < len; i++) {
    fprintf(ofp, "%5d %c   %5d %4d %4d %4d\n",
            i+1, seq[i], i, i+2, (ss[i] != -1)? ss[i]+1:0, i);
  }
  /* fprintf(ofp, "\n"); */
}

/* Function: containsAmbiguous
 * Date:     RDD, Thu Nov 15 17:51:27 2001 [St. Louis]
 *
 * Purpose:  Test for non {ACGTU} bases
 *
 * Args:     
 * 	rna	Sequence to test
 * 	len	Length of sequence
 *
 * Returns:  
 * 	TRUE 	if contains an unknown base
 * 	FALSE 	otherwise
 */
int
containsAmbiguous(char *rna, int len)
{
  int i;
  char *drna;

  drna = DigitizeSequence(rna, len);

  for (i = 0; i < len; i++) {
    if (drna[i] > ALPHA) {
      return TRUE;
    }
  }

  free(drna);
  return FALSE;
}

void
truncateName(char *Xname, char **ret_X)
{
   char *tmp;
   char *outlabelX;
   int len;


   if ((outlabelX = (char *) malloc(sizeof(char) * 23)) == NULL)
      Die("Label X truncation \n");

   /* Format Names to fit our output */
   len = strlen(Xname);
   if (len > 20) {
      tmp = &(Xname[(len-20)]);
   } else {
      tmp = Xname;
   }
   strncpy(outlabelX, tmp, 20);
   outlabelX[21] = '\0';

   *ret_X = outlabelX;
}

/* Function: StripDegeneracy()
 * Date: Wed Apr 28 09:42:04 CDT 2004
 * Note: Taken from E. Rivas' pknots, but reads like Sean wrote it
 * 
 * Purpose:  Convert degenerate nucleotides into a random choice
 *           of ACGU. String is guaranteed to contain only
 *           ACGU. when it comes out (all gaps converted to '.'). 
 *           
 * Args:     seq    - sequence to strip (null-terminated)
 *           
 * Return:   (void)
 */
void
StripDegeneracy(char *seq)
{
  char *wp; /* write pointer (where we're writing seq) */
  char *rp; /* read pointer (where we're reading seq)  */

  for (wp = rp = seq; *rp != '\0'; rp++)
    {
      if (isgap(*rp)) *wp++ = '.';
      else if (strchr("ACGU", *rp)) *wp++ = *rp;
      else 
	{
	  /* then it's a degenerate symbol.
	   * According to alphabet, choose a single symbol to represent it.
	   * note the too-clever scheme for random choice: "ABC"[random() % 3]
	   */
	  switch (*rp) {
	  case 'B': *wp++ = "CGU" [random() % 3]; break;
	  case 'D': *wp++ = "AGU" [random() % 3]; break;
	  case 'H': *wp++ = "ACU" [random() % 3]; break;
	  case 'K': *wp++ = "GU"  [random() % 2]; break;
	  case 'M': *wp++ = "AC"  [random() % 2]; break;
	  case 'N': *wp++ = "ACGU"[random() % 4]; break;
	  case 'R': *wp++ = "AG"  [random() % 2]; break;
	  case 'S': *wp++ = "CG"  [random() % 2]; break;
	  case 'T': *wp++ = 'U';                  break;
	  case 'V': *wp++ = "ACG" [random() % 3]; break;
	  case 'W': *wp++ = "AU"  [random() % 2]; break;
	  case 'X': *wp++ = "ACGU"[random() % 4]; break;
	  case 'Y': *wp++ = "CU"  [random() % 2]; break;
	  default: Die("unrecognized character %c in sequence\n", *rp);
	  }
	}
    }
}

