#ifndef CFG_H_INCLUDED
#define CFG_H_INCLUDED

/* See NOTES for grammar descriptions. */

/* Grammar families -- these are backbones */
#define NGMR	0
#define SGMR	1
#define GTYPE	2

/* Grammar */
#define NUS	0	/* Unambiguous Nussinov pairSCFG */
#define YRN 	1	/* Unambiguous Stacking pairSCFG */
#define YR2	2	/* Unambiguous Stacking pairSCFG */
#define MNG	3
#define STA	4
#define GMR	5

/* See ngmr.h and sgmr.h 
 *
 * These files also contain the
 * specific dp matricies and transition codes 
 * valid for each family of grammars.  Doing it this way
 * allows us to redefine our codes for each family.
 * */
#define NDPS     9
#define NTRANS	 37 	

/***********************************************/

/* Indices for bases */
#define ntA	0
#define ntC	1
#define ntG	2
#define ntU	3
#define ntT	4	/* For compatability with HMMER alphabets */
#define ALPHA   4

#define PRINT_INT  0
#define PRINT_FLT  1
#define PRINT_BTH  2

#define ECOUNT 	276
#define PAIR    (ALPHA * ALPHA)
#define QUAD    (PAIR * PAIR)
#define SEIS    (QUAD * PAIR)

/***********************************************/
/* Emission macro types */
/* Single stranded regions */
#define eSS(nti)        (nti)
/* Alignment regions */
#define eAL(nti,ntk)  (4+(nti)*ALPHA+(ntk)) /* When nt available */
#define eALP(pr)  (4+(pr))              /* When pair number available */
/* Align and Pair regions */
#define ePR(pairX,pairY) (20+(pairX)*PAIR+(pairY))
#define ePRN(i,j,k,l)	(20+((i)+ALPHA*(j))*PAIR+((k)+ALPHA*(l)))

/***********************************************/
/* Convert a pair into a number between 0 and (ALPHA^2 -1) */
#define idx(symi, symj)		((symi)+ALPHA*(symj))
#define dist(i,j)		(abs((j)-(i)+1))
#define dz(i,j)			(abs((j)-(i)))

/* Useful macros */
#define LN2         0.69314718056
#define LN2INV      1.44269504089
#define LOG2(x)     ((x) == 0.0 ? -HUGE_VAL : log(x) * LN2INV)
#define EXP2(x)      (exp((x) * LN2 ))
#define LOGSUM_TBL  20000	/* controls precision on Logsum() */
#define BIGINT     9999999	/* prohibition without overflow */
/* Note: values of 999999 and smaller are too small for groupI's score */
#define BIGFLOAT   999999.99	/* prohibition without overflow */

#define accuracy  0.99
#define MARGIN    0.001
#define MARGIN2   0.01

/* Parameters pulled from HMMERs config.h file that are relevant to alphabet.c */
#define INTSCALE    1000.0      /* scaling constant for floats to integer scores   */
#define INFTY       987654321   /* infinity for purposes of integer DP cells       */
#define HLEN    1          /* minimum hairpin loops length (j-i) > HLEN */

/* Names -- useful for debugging; see globals.c */
extern char *grNAME[GMR];
extern char *baseNAME[ALPHA];
extern char *pairNAME[PAIR];
extern char *dpNAME[GTYPE][NDPS];
extern char *dptNAME[GTYPE][NTRANS];
extern int Gtype[GMR];
extern int Contains[GMR][NDPS];
extern int GapOpen[GTYPE][NTRANS];
extern int GapExtend[GTYPE][NTRANS];
extern int Rules[GMR][NDPS][NTRANS];

/*********************** structures ***********************/
struct sankint_s {
   int *transitions;
   int *emissions;
};
typedef struct sankint_s INTMOD;

struct sankfloat_s{
   float *transitions;
   float *emissions;
};
typedef struct sankfloat_s PROBMOD;

struct modelparam_s {
   int grammar;		

   PROBMOD fmod;
   INTMOD  imod;
};
typedef struct modelparam_s MODEL;

#define sre_isascii(c)   (!((c) & ~0177))

/*********************** headers *****************************/
/* cfg.c */
extern int allocModel(MODEL **ret_cfg);
extern void allocImod(INTMOD *imod);
extern void allocFmod(PROBMOD *fmod);
extern void freeImod(INTMOD *imod);
extern void freeFmod(PROBMOD *fmod);
extern void freeModel(MODEL *cfg);
extern void ZeroModel(MODEL *cfg);
extern void zeroImod(INTMOD *imod);
extern void zeroFmod(PROBMOD *fmod);
extern int equalModel(MODEL *mod1, MODEL *mod2);
extern int equalImod(INTMOD *imod1, INTMOD *imod2);
extern int equalFmod(PROBMOD *fmod1, PROBMOD *fmod2);
extern int CopyModel(MODEL *from, MODEL *to);
extern void copyImod(INTMOD *from, INTMOD *to);
extern void copyFmod(PROBMOD *from, PROBMOD *to);
extern void addModel(MODEL *tot, MODEL *add);
extern void addImod(INTMOD *tot, INTMOD *add);
extern void addFmod(PROBMOD *tot, PROBMOD *add);
extern void makeScoringModel(INTMOD *sc);
extern void handCodedModel(INTMOD *sc);

/* cfgrpt */
extern void printModel(FILE *fp, int code, MODEL *cfg);
extern void printImodel(FILE *fp, INTMOD *icfg);
extern void printFmodel(FILE *fp, PROBMOD *icfg);
extern void printTransitions(FILE *fp, MODEL *mod, int usefmod);
extern void printEmissions(FILE *fp, MODEL *mod, int usefmod);
extern void printEPairwise(FILE *fp, MODEL *mod, int usefmod);
extern void printEAlign(FILE *fp, MODEL *mod, int usefmod);
extern void printESingles(FILE *fp, MODEL *mod, int usefmod);
extern void printStacking(FILE *fp, MODEL *mod, int usefmod);
extern void printTransL(FILE *fp, MODEL *mod, int labels);
extern void printEmisL(FILE *fp, MODEL *mod, int labels);
extern void printEPairL(FILE *fp, MODEL *mod, int labels);
extern void printEAlignL(FILE *fp, MODEL *mod, int labels);
extern void printESingL(FILE *fp, MODEL *mod, int labels);
extern void printTransPair(FILE *fp, MODEL *mod1, MODEL *mod2, int labels);
extern void printEmisPair(FILE *fp, MODEL *mod1, MODEL *mod2, int usefmod);
extern void printEPairPair(FILE *fp, MODEL *mod1, MODEL *mod2, int labels);
extern void printEAlignPair(FILE *fp, MODEL *mod1, MODEL *mod2, int labels);
extern void printESingPair(FILE *fp, MODEL *mod1, MODEL *mod2, int labels);
extern void printTransQuad(FILE *fp, MODEL *mod1, MODEL *mod2,
          MODEL *mod3, MODEL *mod4, int labels);
extern void printEPairQuad(FILE *fp, MODEL *mod1, MODEL *mod2,
          MODEL *mod3, MODEL *mod4, int labels);
extern void printEAlignQuad(FILE *fp, MODEL *mod1, MODEL *mod2,
          MODEL *mod3, MODEL *mod4, int labels);
extern void printESingQuad(FILE *fp, MODEL *mod1, MODEL *mod2,
          MODEL *mod3, MODEL *mod4, int labels);

/* cfgio.c */
void byteswap(char *swap, int nbytes);
int SaveSCFG(FILE *ofp, MODEL *cfg);
int ReadSCFG(FILE *ofp, MODEL **ret_cfg);
int CheckModel (PROBMOD *prmodel, int grammar);

/* cfgmodel.c: Contains routines for probabilistic manipulations */
void plusOnePrior(INTMOD *scores);
void DLogifySCFG(int grammar, PROBMOD *cfg, PROBMOD *ret_icfg);
void LogifySCFG(int grammar, PROBMOD *cfg, INTMOD *ret_icfg);
void InvLogifySCFG(int grammar, INTMOD *cfg, PROBMOD *ret_icfg);
void InvDLogifySCFG(int grammar, PROBMOD *cfg, PROBMOD *ret_icfg);
void ProbifySCFG(int grammar, PROBMOD *icfg, INTMOD *prior, int tie, PROBMOD *ret_cfg);
void probifyEmissions(PROBMOD *icfg, PROBMOD *ret_cfg);
void probifyTransitions(int grammar, PROBMOD *icfg, PROBMOD *ret_cfg);
void addPrior(int grammar, PROBMOD *icfg, INTMOD *prior, PROBMOD *ret_cfg);
void tieXYEmissions(PROBMOD *icfg);
void tieOETransitions(int grammar, PROBMOD *icfg);
void tieLRTransitions(int grammar, PROBMOD *icfg);
void tieXYTransitions(int grammar, PROBMOD *icfg);
void tieGTransitions(int grammar, PROBMOD *icfg);

/* rdd_math.c */
extern int asIntLog (float prob);
extern float asLog (float prob);
extern float asFloatProb (int prob);
extern float asProb (double prob);
extern float LogSum(float p1, float p2);
extern inline int ILogsum(int p1, int p2);
extern inline double DLogsum(double p1, double p2);
extern int ILogsumSet(int *intprobs, int num);

/* misc.c */
extern int dealignedCoord(char *aseq, int startp, int stopp, int start);
extern int isRNAComplement(char sym1, char sym2, int allow_gu);
extern int isRNAbp(int pairidx, int allow_gu);
extern int isIdentical(char sym1, char sym2);
extern int find_split (int *ct, int i, int j);
extern void mismatch_label(int *ct, int len);
extern void print_CT(FILE *ofp, char *seq, int len, int *ss, char *name);
extern int containsAmbiguous (char *rna, int len);
extern void truncateName(char *Xname, char **ret_X);
extern void StripDegeneracy(char *seq);

/* khs.c */
extern int calcConsStruct(char *ss1, char *seq1, char *ss2, char *seq2,
              int len, char **ret_css);
extern int KHS2ct(char *ss, int len, int allow_pseudoknots, int **ret_ct);
extern int VerifyKHS(char *name, char *ss, int wordy);
extern int khsSanity(char *seq, char *ss);

#endif /* CFG_H_INCLUDED */
