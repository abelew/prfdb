/* cfgio.c
 * I/O of models to/from disk files
 * RDD, Wed Oct 17 17:03:10 CDT 2001
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "squid/squid.h"
#include "cfg.h"

/* Magic Number is Sank (as ascii codes) + 80808080 */
static int v10magic     = 0xf4184137;
static int v10swap 	= 0x374118f4;

/* Function: byteswap()
 * from HMMer's hmmio.c -- SRE, Sun Feb 12 10:26:22 1995              
 * 
 * Purpose:  (from hmmio.c)
 * 	Swap between big-endian and little-endian.
 *           For example:
 *               int foo = 0x12345678;
 *               byteswap((char *) &foo, sizeof(int));
 *               printf("%x\n", foo)
 *           gives 78563412.
 *           
 *       I don't fully understand byte-swapping issues.
 *       However, I have tested this on chars through floats,
 *       on various machines:
 *               SGI IRIX 4.0.5, SunOS 4.1.3, DEC Alpha OSF/1, Alliant
 *               
 *       Note: this is only a partial solution to the problem of
 *           binary file portability. 32 bit integers are assumed by HMMER,
 *           for instance. This should be true for all UNIX, VAX, and WinNT
 *           platforms, I believe.     
 *
 */
void
byteswap(char *swap, int nbytes)
{
  int  x;
  char byte;
  
  for (x = 0; x < nbytes / 2; x++)
    {
      byte = swap[nbytes - x - 1];
      swap[nbytes - x - 1] = swap[x];
      swap[x] = byte;
    }
}

/* Function: SaveSCFG()
 * Date:     RDD, Fri Feb 28 11:23:00 CST 2003 [I-44 mile 100, MO]
 * 
 * Purpose:  Write a pair SCFG to disk in binary format.
 *           Return 1 on success, 0 on failure
 *
 * Args:
 * 	ofp	-- to where to write the file
 * 	ret_cfg -- the model which should be written
 *
 * Return:   
 *      1 on success, 0 on failure
 */
int
SaveSCFG(FILE *ofp, MODEL *cfg)
{
   int i, edge;

   if (SaveHeader(ofp, cfg->grammar))
      if (SaveTrans(ofp, cfg))
	 if (SaveEmiss(ofp, cfg))
	    return 1;
   return 0;
}

/* Function: ReadSCFG()
 * Date:     RDD, Fri Feb 28 11:31:57 CST 2003 [I-44 mile 88, MO]
 * 
 * Purpose:  Read an SCFG from disk in binary format.
 *           
 * Args:
 * 	ofp	-- from where to read the file
 * 	ret_cfg -- space in which to store read model (allocated elsewhere)
 *
 * Return:   
 *      1 on success, 0 on failure
 */
int 
ReadSCFG(FILE *ofp, MODEL **ret_cfg)
{
  int i, edge;
  int magic;
  int do_byteswap = 0;
  MODEL *cfg = NULL;
  int gmr;

  if (!ReadHeader(ofp, &do_byteswap, &gmr)) return 0;
  if (!allocModel(&cfg)) return 0;
  /* Check if we're using the right grammar */
  if (!ReadTrans(ofp, cfg)) return 0;
  if (!ReadEmiss(ofp, cfg)) return 0;
  if (do_byteswap) {
     for (i = 0; i < ECOUNT; i++) {
	byteswap((char*)&(cfg->fmod.emissions[i]), sizeof(float));
	byteswap((char*)&(cfg->imod.emissions[i]), sizeof(int));
     }
     for (i = 0; i < NTRANS; i++) {
	byteswap((char*)&(cfg->fmod.transitions[i]), sizeof(float));
	byteswap((char*)&(cfg->imod.transitions[i]), sizeof(int));
     }
  }
  *ret_cfg = cfg;
  return 1;
}

/* Function: SaveHeader()
 * Date:     RDD, Fri Sep 10 16:04:01 CDT 2004 [St Louis]
 * 
 * Purpose:  
 *   write appropriate header info to identify what is 
 *   in this save file.
 *
 * Args:
 * 	ofp	-- to where to write the file
 * 	grammar -- grammar for this set of parameters
 *
 * Return:   
 *      1 on success, 0 on failure
 */
int
SaveHeader(FILE *ofp, int grammar)
{
  /* Defines model */
  if (fwrite(&v10magic, sizeof(int), 1, ofp) < 1) return 0;
  if (fwrite(&(grammar), sizeof(int), 1, ofp) < 1) return 0;
  return 1;
}

/* Function: ReadHeader()
 * Date:     RDD, Fri Sep 10 16:05:21 CDT 2004 [St Louis]
 * 
 * Purpose:  
 * 	Read header info from disk to determine what
 * 	kind of save file we're trying to load.
 *           
 * Args:
 * 	ofp	-- from where to read the file
 * 	ret_dbs -- return value (dobyteswap)
 * 	ret_gmr	-- return value (grammar)
 *
 * Return:   
 *      1 on success, 0 on failure
 */
int 
ReadHeader(FILE *ofp, int *ret_dbs, int *ret_gmr)
{
  int magic;
  int do_byteswap = 0;
  int gmr;

  if (fread(&magic, sizeof(int), 1, ofp) < 1)
    { Warn("Failed to read magic number from SCFG save file"); return 0; }
  if (magic == v10swap) {
    do_byteswap = 1;
    byteswap((char *)&magic, sizeof(int));
  } 
  if (magic == v10magic) {
      if (fread(&(gmr), sizeof(int), 1, ofp) < 1)
	  { Warn("fread failed on SCFG save file: grammar type"); return 0; }
      if (do_byteswap) { byteswap((char*)&(gmr), sizeof(int)); }
  } else { 
    Warn("bad magic on that SCFG save file"); return 0; 
  }

  *ret_dbs = do_byteswap;
  *ret_gmr = gmr;

  return 1;
}

/* Function: SaveTrans()
 * Date:     RDD, Fri Sep 10 15:59:04 CDT 2004 [St Louis]
 * 
 * Purpose:  Write just the transition parameters of 
 * 	a SCFG to disk in binary format.
 *
 * Args:
 * 	ofp	-- to where to write the file
 * 	ret_cfg -- the model which should be written
 *
 * Return:   
 *      1 on success, 0 on failure
 */
int
SaveTrans(FILE *ofp, MODEL *cfg)
{
  /* Transitions */
  if (fwrite(&(cfg->fmod.transitions[0]), sizeof(float), NTRANS , ofp) < NTRANS) 
     return 0;
  if (fwrite(&(cfg->imod.transitions[0]), sizeof(int), NTRANS , ofp) < NTRANS) 
     return 0;
  return 1;
}

/* Function: ReadTrans()
 * Date:     RDD, Fri Sep 10 16:00:13 CDT 2004 [St Louis]
 * 
 * Purpose:  Read transitions from an SCFG in binary format.
 *           
 * Args:
 * 	ofp	-- from where to read the file
 * 	ret_cfg -- space in which to store read model (allocated elsewhere)
 *
 * Return:   
 *      1 on success, 0 on failure
 */
int 
ReadTrans(FILE *ofp, MODEL *cfg)
{
  if (fread(&(cfg->fmod.transitions[0]), sizeof(float), NTRANS, ofp) < NTRANS)
  { Warn("fread failed on SCFG save file: transitions"); return 0; }
  if (fread(&(cfg->imod.transitions[0]), sizeof(int), NTRANS, ofp) < NTRANS)
  { Warn("fread failed on SCFG save file: transitions score"); return 0; }

  return 1;
}

/* Function: SaveEmiss()
 * Date:     RDD, Fri Sep 10 16:01:33 CDT 2004 [St Louis]
 * 
 * Purpose:  Write just the transition parameters of 
 * 	a SCFG to disk in binary format.
 *
 * Args:
 * 	ofp	-- to where to write the file
 * 	ret_cfg -- the model which should be written
 *
 * Return:   
 *      1 on success, 0 on failure
 */
int
SaveEmiss(FILE *ofp,MODEL *cfg)
{
   int i, edge;

   /* Emissions */
   if (fwrite(&(cfg->fmod.emissions[0]), sizeof(float), ECOUNT, ofp) < ECOUNT)
     return 0;
   if (fwrite(&(cfg->imod.emissions[0]), sizeof(int), ECOUNT, ofp) < ECOUNT) 
     return 0;
   return 1;
}

/* Function: ReadEmiss()
 * Date:     RDD, Fri Sep 10 16:02:26 CDT 2004 [St Louis]
 * 
 * Purpose:  Read transitions from an SCFG in binary format.
 *           
 * Args:
 * 	ofp	-- from where to read the file
 * 	ret_cfg -- space in which to store read model (allocated elsewhere)
 *
 * Return:   
 *      1 on success, 0 on failure
 */
int 
ReadEmiss(FILE *ofp,MODEL *cfg)
{
  int i, edge;

  if (fread(&(cfg->fmod.emissions[0]), sizeof(float), ECOUNT, ofp) < ECOUNT)
  { Warn("fread failed on SCFG save file: emissions"); return 0; }
  if (fread(&(cfg->imod.emissions[0]), sizeof(int), ECOUNT, ofp) < ECOUNT)
  { Warn("fread failed on SCFG save file: emissions score"); return 0; }

  return 1;
}


