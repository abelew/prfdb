#ifndef STATS_H_INCLUDED
#define STATS_H_INCLUDED

/* General structure definition  terms */
struct structurestats {
  int nseq;             /* Total number of sequence */
  int npairs;		/* Total number of sequence pairs */
  int Nfree;            /* Sequences which are N free */
  int containN;         /* Sequences which contain N's */

  int trust_pairs;      /* Total bp in all trusted structures */
  int test_pairs;       /* Total bp in all test structures */
  int trust_correct;    /* Total correct pred bp in trusted structures */
  int test_correct;     /* Total true bp in test structures */
  int positions;        /* Total number of bp */

  int trusted;		/* Pairs in given structures */
  int predicted;	/* Pairs predicted by grammar */
  int correct;		/* Pairs predicted correctly by grammar */

  int dscorrect;	/* Pairing positions correctly predicted */
  int sscorrect;	/* Sigle stranded regions correctly predicted */
};
typedef struct structurestats STATS;

extern int CompStruct (int len, char *trusted, char *test, STATS *totals,
    int iseq, int do_mathews, int ct_knots);

extern void PrintTableHeader();
extern void PrintTableLine (char *label, STATS statistics, int withranges);
extern void accumulateStats (STATS *total, STATS *global);
extern float PrintTotals (STATS *statistics, int withranges, int withcs);
extern void ZeroStats (STATS *statistics);
extern int testAlignPairs (MSA *kmsa, MSA *tmsa);

#endif
