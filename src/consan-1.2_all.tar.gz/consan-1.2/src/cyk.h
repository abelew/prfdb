/* cyk.c */
struct trace_s * CYK(SEQPR *seqs, MODEL *model, OPTS *opts, int *ret_score);
int verifyCYK (SEQPR *seqs, MODEL *model, 
    OPTS *opts, int *ret_score);
int ccykDebugMx(SEQPR *seqs, MODEL *model, int *****mx);
int cykFillMx(SEQPR *seqs, MODEL *model, int *****mx, int constrain);
struct trace_s * cykTraceMx(SEQPR *seqs, MODEL *model, int *****mx);



