/*************************************/
/* Constrained Sankoff:: CYK algorithm */
/* In reduced memory */
/***************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "consan.h"
#include "sgmr.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"

/* This code uses a potentially confusing indexing convention.
 * The matrix is allocated (dprm.c) and filled as:
 * 	[v][j][dx][l][k]
 * The use of (l,k) rather than (l,dy) is because it's 
 * intuitively simpler with constraints.  The tradeoff is
 * that this now not a windowing ready implementation, but
 * conceptually the difference is easy to change once this
 * version works.  [Note that if (l, dy) the each dy is a
 * column in the matrix.  As (l, k) each dy is a diagonal.
 * This may have stride issues which reduce performance.  So
 * converting back to (l, dy) is a long term goal.]
 *
 * In general there are two coordinate systems:
 * 1) The sequence coordinates -- this is how we think of
 * doing full Sankoff.
 * 2) The allocation coordinates -- this shifts the l and 
 * k coordinates to the allocated indicies.  The shift is:
 * 	al = l - sL[j];		ak = k - sL[i];
 *
 * Question: Do we need to check additional boundaries in
 * reduced coordinate space, or will our current boundary
 * checks suffice?
 */

/* Function: rccykInitSTA */
  void
rccykInitSTA(SEQPR * seqs, INTMOD *model, int *****mx)
{
  int j, i, dx, l, k, dy;	/* Indicies */
  int ledge;		/* Edge for l values */
  int *sL, *sR;		/* Segement coordinate arrays */
  int Xlen, Ylen;	/* Lengths, for readability */
  int al, ak;		/* Allocated coordinates */

  sL = seqs->c_info->sL;
  sR = seqs->c_info->sR;
  Xlen = seqs->sequence[SEQX]->len;
  Ylen = seqs->sequence[SEQY]->len;

  for (dx = 0; dx <= Xlen; dx++) {
    for (j = (dx > 0)? dx-1: 0; j < Xlen; j++) {
      i = j - dx +1;

      for (dy = ((sL[j] >= sR[i]) ? (sL[j] - sR[i]+1): 0); 
	  dy <= (sR[j] - sL[i] +1); dy++) {

	/* Loop ends at min sR[j] unless 
	 * sR[i] != sR[j] and sR[i] + dy -1) */
	ledge = ((sR[i] == sR[j])? sR[j] : 
	    ((sR[i] + dy -1 < sR[j])? (sR[i] + dy -1) : sR[j])); 
	/* Loop begins at max (sL[j], sL[i] + dy -1) */
	for (l = ((sL[j] > sL[i] + dy -1)? sL[j] : sL[i] + dy -1); 
	    l <= ledge; l++) { 
	  k = l - dy +1;
	  al = l - sL[j];
	  ak = k - sL[i];

	  mx[dpS][j][dx][al][ak] = -BIGINT;
	  mx[dpT][j][dx][al][ak] = -BIGINT;
	  mx[dpN][j][dx][al][ak] = -BIGINT;
	  mx[dpP][j][dx][al][ak] = -BIGINT;
	  mx[dpRx][j][dx][al][ak] = -BIGINT;
	  mx[dpRy][j][dx][al][ak] = -BIGINT;
	  mx[dpLx][j][dx][al][ak] = -BIGINT;
	  mx[dpLy][j][dx][al][ak] = -BIGINT;
	  
	} /* for l */
      } /* for dy */
    } /* for j */
  } /* for dx */
}


/* Function: rccykFillSTA
 * Date:     Wed Nov 19 07:55:41 CST 2003 [Oxford, UK]
 *
 * Purpose:  Fills CYK matrix 
 * Assumption: Fill matrix already allocated.
 * 	Assumes reduced space allocation.
 * 	Assumes no prior initialization.
 *
 * Note: This is a LONG function -- but runs much faster 
 * when kept together as opposed to breaking into subroutines.
 *
 * Args:    
 * 	seqs	sequences and constraint info
 * 	model	parameter and grammar info
 * 	mx	fill matrix
 *
 * Returns:  void 
 */
void
rccykFillSTA(SEQPR *seqs, INTMOD *model, int *****mx)
{
  int i, j, dx, a;	/* Sequence x indicies */
  int k, l, dy, b;	/* Sequence y indicies */
  int al, ak, ab;	/* allocation coordinates */
  int debug = FALSE;
  int dbugbif = FALSE;

  int ledge, bedge;
  int max, bifmax, cursc;      
  int Pap, Sm, Lx, Ly, Tm, Rx, Ry; /* Common values for rules */

  int Xlen, Ylen;
  char *isXconstraint;
  char *isYconstraint;
  int *sL; int *sR, *Yval;

  /* Using local pointers to make the code more readable;
   * may also help with some compiler optimizations */
  Xlen = seqs->sequence[SEQX]->len;
  Ylen = seqs->sequence[SEQY]->len;
  sL = seqs->c_info->sL;
  sR = seqs->c_info->sR;
  /* Must define isXconstraint isYconstraint and Yval for NXOR macro to work */
  isXconstraint = seqs->c_info->isXconstraint;
  isYconstraint = seqs->c_info->isYconstraint;
  Yval = seqs->c_info->Yval;

  if (debug) { printf("RED Fill:: Xlen %d Ylen %d\n", Xlen, Ylen); }

  for (dx = 0; dx <= Xlen; dx++) {
    if (debug) { printf("dx = %d\n", dx); } 
    for (j = (dx > 0)? dx-1: 0; j < Xlen; j++) {
      i = j - dx +1;
      if (debug) {
	if (isXconstraint[i] && isXconstraint[j]) 
	  printf("\t i* = %d j* = %d\n", i, j); 
	else if (isXconstraint[i]) printf("\t i* = %d j = %d\n", i, j); 
	else if (isXconstraint[j]) printf("\t i = %d j* = %d\n", i, j); 
	else printf("\t i = %d j = %d\n", i, j); 
	fflush(stdout);
      }

      for (dy = ((sL[j] >= sR[i]) ? (sL[j] - sR[i]+1): 0); 
	  dy <= (sR[j] - sL[i] +1); dy++) {
	if (debug) { printf(" dy = %d\n", dy); }

	/* Loop ends at min sR[j] unless 
	 * sR[i] != sR[j] and sR[i] + dy -1) 
	 * */
	ledge = ((sR[i] == sR[j])?  sR[j] : 
	    /* ((dy == 0)? sR[j]-1 : sR[j]) :  */
	     ((sR[i] + dy -1 < sR[j])? (sR[i] + dy -1) : sR[j])); 
	/* Loop begins at max (sL[j], sL[i] + dy -1) */
	for (l = ((sL[j] > sL[i] + dy -1)? sL[j] : sL[i] + dy -1); 
	    l <= ledge; l++) { 
	  k = l - dy +1;

	  if (debug) {
	    if (isYconstraint[k] && isYconstraint[l]) 
	      printf("\t\t k* = %d l* = %d\n", k, l); 
	    else if (isYconstraint[k]) 
	      printf("\t\t k* = %d l = %d\n", k, l); 
	    else if (isYconstraint[l]) 
	      printf("\t\t k = %d l* = %d\n", k, l); 
	    else printf("\t\t k = %d l = %d\n", k, l); 
	    fflush(stdout);
	  }

	  /* Set allocation coordinates */
	  al = l - sL[j];	ak = k - sL[i];

	  /* The distances are zero iterations are initialization
	   * instances.  We deal with them separately.  */

	  /*************** dx == dy == 0 ***********************/
	  if ((dx == 0) && (dy == 0)) {
	    mx[dpS][j][dx][al][ak] = model->transitions[TSE];
	    mx[dpLx][j][dx][al][ak] = model->transitions[TLXE];
	    mx[dpLy][j][dx][al][ak] = model->transitions[TLYE];
	    mx[dpT][j][dx][al][ak] = -BIGINT;
	    mx[dpRx][j][dx][al][ak] = -BIGINT;
	    mx[dpRy][j][dx][al][ak] = -BIGINT;
	    mx[dpP][j][dx][al][ak] = -BIGINT;
	    mx[dpN][j][dx][al][ak] = -BIGINT;

	  /******************* dx == 0 ***********************/
	  } else if (dx == 0) {
	    if (!isYconstraint[k]) {
	      mx[dpS][j][dx][al][ak] = 
		mx[dpLy][j][dx][al][ak+1] +
		model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[k])] +
		model->transitions[TSLY];
	      mx[dpLy][j][dx][al][ak] = 
		mx[dpLy][j][dx][al][ak+1] +
		model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[k])] +
		model->transitions[TLYY];
	      mx[dpN][j][dx][al][ak] = 
		mx[dpLy][j][dx][al][ak+1] +
		model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[k])] +
		model->transitions[TNLY];
	    } else {
	      mx[dpS][j][dx][al][ak] = -BIGINT;
	      mx[dpLy][j][dx][al][ak] = -BIGINT;
	      mx[dpN][j][dx][al][ak] = -BIGINT;
	    }
	    mx[dpLx][j][dx][al][ak] = -BIGINT;
	    mx[dpT][j][dx][al][ak] = -BIGINT;
	    mx[dpRx][j][dx][al][ak] = -BIGINT;
	    mx[dpRy][j][dx][al][ak] = -BIGINT;
	    mx[dpP][j][dx][al][ak] = mx[dpN][j][dx][al][ak] +
	      model->transitions[TPN];

	  /******************* dy == 0 ***********************/
	  } else if (dy == 0) {
	    if (!isXconstraint[i]) {
	      mx[dpS][j][dx][al][ak] = 
		mx[dpLx][j][dx-1][al][(k - sL[i+1])] +
		model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[i])] +
		model->transitions[TSLX];
	      mx[dpLx][j][dx][al][ak] = 
		mx[dpLx][j][dx-1][al][(k - sL[i+1])] +
		model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[i])] +
		model->transitions[TLXX];
	      mx[dpN][j][dx][al][ak] = 
		mx[dpLx][j][dx-1][al][(k - sL[i+1])] +
		model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[i])] +
		model->transitions[TNLX];
	    } else {
	      mx[dpS][j][dx][al][ak] = -BIGINT;
	      mx[dpLx][j][dx][al][ak] = -BIGINT;
	      mx[dpN][j][dx][al][ak] = -BIGINT;
	    }
	    mx[dpLy][j][dx][al][ak] = -BIGINT;
	    mx[dpT][j][dx][al][ak] = -BIGINT;
	    mx[dpRx][j][dx][al][ak] = -BIGINT;
	    mx[dpRy][j][dx][al][ak] = -BIGINT;
	    mx[dpP][j][dx][al][ak] = mx[dpN][j][dx][al][ak] +
	      model->transitions[TPN];

	  /******************* dx != 0 && dy != 0  ********************/
	  } else {
	    /* We use the constraint information to know when an
	     * emission is permissible or not (at an edge of a 
	     * segment or a constraint).  */

	    /* (-y)Ly */
	    Ly = -BIGINT; 
	    if (!isYconstraint[k]) {	
	      Ly = mx[dpLy][j][dx][al][ak+1]
		+ model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[k])];
	    }

	    /* (x-)Lx */
	    Lx = -BIGINT;
	    if (!isXconstraint[i]) { 
	      /* Because changing i may change the segment for k,
	       * we've got to be certain we're accessing the right ak */
	      Lx = mx[dpLx][j][dx-1][al][(k-sL[i+1])] 
		+ model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[i])];
	    }

	    /* (xy)S */
	    Sm = -BIGINT;
	    if (NXOR(i,k)) { 
	      Sm = mx[dpS][j][dx-1][al][(k-sL[i+1])+1] 
		+ model->emissions[eAL(seqs->sequence[SEQX]->dseq[i],
		    seqs->sequence[SEQY]->dseq[k])];
	    }

	    /* Rx(x-) */
	    Rx = -BIGINT;
	    if (!isXconstraint[j]) { 
	      if ((j>0)&&(l>0)) {
		/* Because changing j may change the segment for l,
		 * we've got to be certain we're accessing the right al */
		Rx = mx[dpRx][j-1][dx-1][(l-sL[j-1])][ak] 
		  + model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[j])];
	      }
	    }

	    /* Ry(-y) */
	    Ry = -BIGINT;
	    if (!isYconstraint[l]) {		
	      if ((j>0)&&(l>0)) {
		Ry = mx[dpRy][j][dx][al-1][ak]
		  + model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[l])];
	      }
	    }

	    /* T(xy) */
	    Tm = -BIGINT;
	    if (NXOR(j,l)) { 
	      if ((j>0)&&(l>0)) {
		/* moving j could change l segment */
		Tm = mx[dpT][j-1][dx-1][(l-sL[j-1])-1][ak] 
		  + model->emissions[eAL(seqs->sequence[SEQX]->dseq[j],
		      seqs->sequence[SEQY]->dseq[l])];
	      }
	    }

	    /* (xy)P(x'y') */
	    Pap = -BIGINT;
	    if (NXOR(i,k) && NXOR(j,l)) { 
	      if ((l > 0) && (j > 0) && (dx > 1) && (dy > 1)) {
		/* Changing i and j could change k and l segments */
		Pap = mx[dpP][j-1][dx-2][(l-sL[j-1])-1][(k-sL[i+1])+1]
		  + model->emissions[ePR(idx(seqs->sequence[SEQX]->dseq[i],
			seqs->sequence[SEQX]->dseq[j]),
		      idx(seqs->sequence[SEQY]->dseq[k],
			seqs->sequence[SEQY]->dseq[l]))]; 
	      }
	    }

	    /* Bifurcation: T (xy)P(x'y') */
	    bifmax = -BIGINT;
	    /* bif only makes sense if enough residues exist in 
	     * both X and Y between at current i,j,k,l coords */
	    if ((dx > 3) && (dy > 3)) {
	      if (NXOR(j,l)) { 
		/* Technically P's minimum resolution is a single
		 * nt in either X or Y -- so a can be j-1
		 * AND T's minimum resolution is a base pair so 
		 * at best a must be i+2 */
		for (a = i+2; a < j; a++) {
		  if (dbugbif) printf("\t\t\t\t a = %d \n", a);  
		  if (isXconstraint[a]) {	/* a is a constraint */
		    /* Then only time we can bifurcate when a is a 
		     * constrain is if b is a's matching pair */
		    b = seqs->c_info->Yval[a];
		    ab = b - sL[a];
		    if (dbugbif) 
		      printf("\t\t\t\t\t *b = %d \n", b); fflush(stdout); 
		    /* Once we've set a & b, we still should only check
		     * if the resulting length implications for T and P
		     * make sense.
		     *
		     * Define |xP| as length of sequence in x in P state.
		     *
		     * |yP| >= 0 && |yT| >= 0 
		     * if |xP| == 0 then |yP| > 0  
		     * if |xT| == 0 then |yT| > 0 
		     *
		     * Said another way -- 
		     * 	|xP|+|yP|>= 1
		     * 	|xT|+|yT|>= T && |xT|>=2 && |yT|>=2
		     */
		    if (((dist(b+1, l-1) + dist(a+1, j-1)) >= 1) &&
			((dist(k, b-1) >= 2) && (dist(i, a-1) >=2) &&
			 ((dist(k, b-1) + dist(i, a-1)) >= 5))) {
		      cursc = 
			mx[dpP][j-1][dist(a+1,j-1)]\
			[(l-sL[j-1])-1][(b-sL[a+1])+1]
			+ mx[dpT][a-1][dist(i,a-1)][(b-sL[a-1])-1][ak]
			+ model->emissions[
			ePR(idx(seqs->sequence[SEQX]->dseq[a], 
			      seqs->sequence[SEQX]->dseq[j]),
			    idx(seqs->sequence[SEQY]->dseq[b], 
			      seqs->sequence[SEQY]->dseq[l]))];
		      if (cursc > bifmax) {
			bifmax = cursc;
			if (dbugbif) printf(" select b %d\n", b); 
		      }

		    } /* length checks */

		  } else { /* a is not a constraint */
		    /* b must in the segment containing a */
		    bedge = ((l < sR[a])? l: sR[a]);
		    for (b = ((k+1 > sL[a])? k+2: sL[a]+1); b < bedge; b++) {
		      if ((j > 0) && (l > 0) && (a > 0) && (b > 0)) {
			/* If b is a constraint; but not a then we
			 * can't bifurcate at this coordinate.  */
			if (!isYconstraint[b]) {
			  if (dbugbif) printf("\t\t\t\t\t b = %d \n", b);  
			  /* Again, once a & b are set, this only makes 
			   * sense if certain length constrictions are met 
			   * see above ... */
			  if (((dist(b+1, l-1) + dist(a+1, j-1)) >= 1) &&
			      ((dist(k, b-1) >= 2) && (dist(i, a-1) >=2) &&
			       ((dist(k, b-1) + dist(i, a-1)) >= 5))) {
			    cursc = 
			      mx[dpP][j-1][dist(a+1,j-1)]\
			      [(l-sL[j-1])-1][(b-sL[a+1])+1]
			      + mx[dpT][a-1][dist(i,a-1)][(b-sL[a-1])-1][ak]
			      + model->emissions[
			      ePR(idx(seqs->sequence[SEQX]->dseq[a],
				    seqs->sequence[SEQX]->dseq[j]),
				  idx(seqs->sequence[SEQY]->dseq[b], 
				    seqs->sequence[SEQY]->dseq[l]))];
			    if (cursc > bifmax) {
			      bifmax = cursc;
			      if (dbugbif) printf(" select b %d\n", b); 
			    } /* cursc > bifmax */
			  } /* lengths make sense */
			} /* isYconstraint[b] */
		      } /* check for zeros */
		    } /* for b */
		  } /* else on a not constraint */
		} /* for a values */
	      } /* NXOR */
	    } /* dx > 3 ; dy > 3 */

	    /****************************************************************
	     * Now that I've set which emissions are possible, I ought to be
	     * able to do the fills for each (i,j,k,l) accodingly. 
	     ****************************************************************/

	    /* T -> T(xy) | Rx(x-) | Ry(-y) | (xy)P(x'y') | T (xy)P(x'y') */
	    max = -BIGINT;
	    cursc = Tm + model->transitions[TTT];
	    if (cursc > max) max = cursc;
	    cursc = Rx + model->transitions[TTRX];
	    if (cursc > max) max = cursc;
	    cursc = Ry + model->transitions[TTRY];
	    if (cursc > max) max = cursc;
	    cursc = Pap + model->transitions[TTP];
	    if (cursc > max) max = cursc;
	    cursc = bifmax + model->transitions[TTB];
	    if (cursc > max) max = cursc;
	    mx[dpT][j][dx][al][ak] = max;
	    if (debug) 
	      if (mx[dpT][j][dx][al][ak] > 0) {
		printf("dpT > 0 at %d %d %d %d \n", i, j, k, l);
	      }

	    /* S -> (xy)S | (x-)Lx | (-y)Ly | T | end */
	    max = -BIGINT;
	    cursc = Sm + model->transitions[TSS];
	    if (cursc > max) max = cursc;
	    cursc = Lx + model->transitions[TSLX];
	    if (cursc > max) max = cursc;
	    cursc = Ly + model->transitions[TSLY];
	    if (cursc > max) max = cursc;
	    cursc = mx[dpT][j][dx][al][ak] + model->transitions[TST];
	    if (cursc > max) max = cursc;
	    mx[dpS][j][dx][al][ak] = max;
	    if (debug) 
	      if (mx[dpS][j][dx][al][ak] > 0) { 
		printf("dpS > 0 at %d %d %d %d \n", i, j, k, l);
	      } 

	    /* Lx -> (xy)S | (x-)Lx | T | end */
	    max = -BIGINT;
	    cursc = Sm + model->transitions[TLXS];
	    if (cursc > max) max = cursc;
	    cursc = Lx + model->transitions[TLXX];
	    if (cursc > max) max = cursc;
	    cursc = mx[dpT][j][dx][al][ak] + model->transitions[TLXT];
	    if (cursc > max) max = cursc;
	    mx[dpLx][j][dx][al][ak] = max;
	    if (debug) 
	      if (mx[dpLx][j][dx][al][ak] > 0) {
		printf("dpLx > 0 at %d %d %d %d \n", i, j, k, l);
	      }

	    /* Ly -> (xy)S | (-y)Ly | T | end */
	    max = -BIGINT;
	    cursc = Sm + model->transitions[TLYS];
	    if (cursc > max) max = cursc;
	    cursc = Ly + model->transitions[TLYY];
	    if (cursc > max) max = cursc;
	    cursc = mx[dpT][j][dx][al][ak] + model->transitions[TLYT];
	    if (cursc > max) max = cursc;
	    mx[dpLy][j][dx][al][ak] = max;
	    if (debug) 
	      if (mx[dpLy][j][dx][al][ak] > 0) {
		printf("dpLy > 0 at %d %d %d %d \n", i, j, k, l);
	      }

	    /* Rx -> (xy)T | Rx(x-) | (xy)P(x'y') | T (xy)P(x'y') */
	    max = -BIGINT;
	    cursc = Tm + model->transitions[TRXT];
	    if (cursc > max) max = cursc;
	    cursc = Rx + model->transitions[TRXX];
	    if (cursc > max) max = cursc;
	    cursc = Pap + model->transitions[TRXP];
	    if (cursc > max) max = cursc;
	    cursc = bifmax + model->transitions[TRXB];
	    if (cursc > max) max = cursc;
	    mx[dpRx][j][dx][al][ak] = max;
	    if (debug) 
	      if (mx[dpRx][j][dx][al][ak] > 0) {
		printf("dpRx > 0 at %d %d %d %d \n", i, j, k, l);
	      }

	    /* Ry -> (xy)T | Ry(-y) | (xy)P(x'y') | T (xy)P(x'y') */
	    max = -BIGINT;
	    cursc = Tm + model->transitions[TRYT];
	    if (cursc > max) max = cursc;
	    cursc = Ry + model->transitions[TRYY];
	    if (cursc > max) max = cursc;
	    cursc = Pap + model->transitions[TRYP];
	    if (cursc > max) max = cursc;
	    cursc = bifmax + model->transitions[TRYB];
	    if (cursc > max) max = cursc;
	    mx[dpRy][j][dx][al][ak] = max;
	    if (debug) 
	      if (mx[dpRy][j][dx][al][ak] > 0) {
		printf("dpRy > 0 at %d %d %d %d \n", i, j, k, l);
	      }

	    /* N -> (xy)S | (x-)Lx | (-y)Ly | 
	     * T(xy) | Rx(x-) | Ry(-y) | T (xy)P(x'y') */
	    max = -BIGINT;
	    cursc = Sm + model->transitions[TNS];
	    if (cursc > max) max = cursc;
	    cursc = Lx + model->transitions[TNLX];
	    if (cursc > max) max = cursc;
	    cursc = Ly + model->transitions[TNLY];
	    if (cursc > max) max = cursc;
	    cursc = Tm + model->transitions[TNT];
	    if (cursc > max) max = cursc;
	    cursc = Rx + model->transitions[TNRX];
	    if (cursc > max) max = cursc;
	    cursc = Ry + model->transitions[TNRY];
	    if (cursc > max) max = cursc;
	    cursc = bifmax + model->transitions[TNB];
	    if (cursc > max) max = cursc;
	    mx[dpN][j][dx][al][ak] = max;
	    if (debug) 
	      if (mx[dpN][j][dx][al][ak] > 0) {
		printf("dpN > 0 at %d %d %d %d \n", i, j, k, l);
	      }

	    /* P -> (xy)P(x'y') | N */
	    max = -BIGINT; 
	    cursc = Pap + model->transitions[TPP];
	    if (cursc > max) max = cursc;
	    /* N */
	    cursc = mx[dpN][j][dx][al][ak] + model->transitions[TPN];
	    if (cursc > max) max = cursc;
	    mx[dpP][j][dx][al][ak] = max;
	    if (debug) 
	      if (mx[dpP][j][dx][al][ak] > 0) {
		printf("dpP > 0 at %d %d %d %d \n", i, j, k, l);
	      }
	  } /* no zero distances */
	} /* l */
      } /* dy */
    } /* j */
  } /* dx */
}

/* Function: rccykTraceSTA
 * Date:     Mon May 24 14:34:22 CDT 2004 [St Louis]
 *
 * Purpose:  Build traceback tree for full STA grammar 
 * Assumption: Fill matrix already allocated and filled
 *
 * Args:
 * 	seqX	first sequence
 * 	seqY	second sequence
 * 	model	parameter and grammar info
 * 	grammar	Good for STA or ST2
 * 	mx	fill matrix
 *
 * Returns: traceback tree
 */
  struct trace_s *
rccykTraceSTA(SEQPR *seqs, INTMOD *model, int *****mx)
{
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */
  int i, j, dx, a;	/* Sequence x indicies */
  int k, l, dy, b; 	/* Sequence y indicies */
  int ak, al, ab;	/* Sequence y indicies (allocated coords) */
  int bedge;
  int mtx;

  int Xlen, Ylen;
  char *isXconstraint;
  char *isYconstraint;
  int *sL; int *sR, *Yval;

  int debug = FALSE;	/* Turns on exterme debugging output */

  if (debug) {
    printf("begin rccyk TracesSTA \n");
    fflush(stdout);
  }
  /* Using local pointers to make the code more readable;
   * may also help with some compiler optimizations */
  Xlen = seqs->sequence[SEQX]->len;
  Ylen = seqs->sequence[SEQY]->len;
  sL = seqs->c_info->sL;
  sR = seqs->c_info->sR;
  /* Must define isXconstraint isYconstraint and Yval for NXOR macro to work */
  isXconstraint = seqs->c_info->isXconstraint;
  isYconstraint = seqs->c_info->isYconstraint;
  Yval = seqs->c_info->Yval;

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, 
      AttachTrace (parsetree, dpS, 0, (Xlen-1), 0, (Ylen-1), NTRANS));

  if (debug) {
    printf("begin While Loop \n");
    fflush(stdout);
  }
  /* Repeat until stack is empty */
  while ((curr = PopTracestack(stack))) {
    /* Set indicies from item in stack */
    mtx = curr->nonterminal; 
    i = curr->emitLx; j = curr->emitRx; 
    k = curr->emitLy; l = curr->emitRy; 
    dx = j - i + 1; dy = l - k + 1;
    al = l - sL[j];
    ak = k - sL[i];

    if (debug) printf("%s %d %d %d; %d %d %d (%d, %d) \n", 
	dpNAME[Gtype[STA]][mtx], i, j, dx, k, l, dy, al, ak);

    switch (mtx) {
      /*********************
       *        dpS        *
       *********************/
      case dpS: 
	if (debug) printf("dpS\n");
	fflush(stdout);
	if ((i > j) && (k > l)) {	/* End of both sequences */
	  curr->emitLx = -1; curr->emitRx = -1; 
	  curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TSE;
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpS  %5d  %5d  %5d  %5d  TSE %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	    fflush(stdout);
	  }
	} else if (i > j) {		/* Ran out of X, more Y exists */
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	  curr->transition = TSLY;
	  PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpS  %5d  %5d  %5d  %5d  TSLY   %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	    fflush(stdout);
	  }
	} else if (k > l) {		/* Ran out of Y, more X exists */
	  curr->emitLy = -1; curr->emitRx = -1; curr->emitRy = -1;
	  curr->transition = TSLX;
	  PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpS  %5d  %5d  %5d  %5d  TSLX %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	    fflush(stdout);
	  }
	} else if (NXOR(i,k) && (mx[dpS][j][dx-1][al][(k-sL[i+1])+1]  
	      + model->emissions[eAL(seqs->sequence[SEQX]->dseq[i],
		seqs->sequence[SEQY]->dseq[k])]
	      + model->transitions[TSS] == mx[dpS][j][dx][al][ak])) {
	  curr->emitRx = -1; curr->emitRy = -1;
	  curr->transition = TSS;
	  PushTracestack(stack, AttachTrace(curr, dpS, i+1, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpS  %5d  %5d  %5d  %5d  TSS  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	    fflush(stdout);
	  }
	} else if ((!isXconstraint[i]) && (mx[dpLx][j][dx-1][al][(k-sL[i+1])] 
	      + model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[i])] 
	      + model->transitions[TSLX] == mx[dpS][j][dx][al][ak])) {
	  curr->emitLy = -1; curr->emitRx = -1; curr->emitRy = -1;
	  curr->transition = TSLX;
	  PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpS  %5d  %5d  %5d  %5d  TSLX %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	    fflush(stdout);
	  }
	} else if ((!isYconstraint[k]) && (mx[dpLy][j][dx][al][ak+1] 
	      + model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[k])] 
	      + model->transitions[TSLY] == mx[dpS][j][dx][al][ak])) {
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	  curr->transition = TSLY;
	  PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpS  %5d  %5d  %5d  %5d  TSLY %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	    fflush(stdout);
	  }
	} else {
	  /* if (mx[dpT][j][dx][al][ak] 
	     + model->transitions[TSS] == mx[dpS][j][dx][al][ak])  */
	  curr->emitLx = -1; curr->emitRx = -1; 
	  curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TST;
	  PushTracestack(stack, AttachTrace(curr, dpT, i, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpS  %5d  %5d  %5d  %5d  TST  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	    fflush(stdout);
	  }
	}
	break;

      /*********************
       *        dpP        *
       *********************/
      case dpP:
	if (debug) printf("dpP\n");
	fflush(stdout);
	if ((i > j) && (k > l)) {
	  printf("\nSHIT: Bad transition in dpP\n");
	  /* Want to check dpP state -- which we'd prefer to use
	   * if we can -- but we can't continue in P if:
	   * a) i == j [ie. one nt left]
	   * b) NXOR(i,k) or NXOR(j,l) fails [ie. inconsistent pins]
	   * so we have to check these first. */
	} else if ((i >= j) || (k >= l)) {
	  /* Insufficient nts left in either sequence, so we
	   * must end (P -> N) ... note that this is a repeat of
	   * below but this allows the logic in the P->P to be 
	   * shorter and more to the point. */
	  curr->transition = TPN;
	  curr->emitLx = -1; curr->emitLy = -1;
	  curr->emitRx = -1; curr->emitRy = -1;
	  PushTracestack(stack, AttachTrace(curr, dpN, i, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpP  %5d  %5d  %5d  %5d  TPN   %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if ((NXOR(i,k) && NXOR(j,l) &&
	    (mx[dpP][j-1][dx-2][(l-sL[j-1])-1][(k-sL[i+1])+1] 
	     + model->transitions[TPP] + model->emissions[
	     ePRN(seqs->sequence[SEQX]->dseq[i],seqs->sequence[SEQX]->dseq[j],\
	       seqs->sequence[SEQY]->dseq[k],seqs->sequence[SEQY]->dseq[l])]
	     == mx[dpP][j][dx][al][ak]))) {
	  curr->transition = TPP;
	  PushTracestack(stack, AttachTrace(curr, 
		dpP, i+1, j-1, k+1, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpP  %5d  %5d  %5d  %5d  TPP  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else {
	  curr->transition = TPN;
	  curr->emitLx = -1; curr->emitLy = -1;
	  curr->emitRx = -1; curr->emitRy = -1;
	  PushTracestack(stack, AttachTrace(curr, dpN, i, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpP  %5d  %5d  %5d  %5d  TPN   %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	}
	break;

      /*********************
       *        dpN        *
       *********************/
      case dpN:
	if (debug) printf("dpN\n");
	fflush(stdout);
	if ((i > j) && (k > l)) {
	  printf("\nSHIT: Bad transition in dpN\n");
	} else if (i > j) {		/* Ran out of X, more Y exists */
	  curr->transition = TNLY;
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	  PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNLY  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (k > l) {		/* Ran out of Y, more X exists */
	  curr->emitRx = -1; curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TNLX;
	  PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNLX  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (NXOR(j,l) && (mx[dpT][j-1][dx-1][(l-sL[j-1])-1][ak]
	      + model->emissions[eAL(seqs->sequence[SEQX]->dseq[j],
		seqs->sequence[SEQY]->dseq[l])]
	      + model->transitions[TNT] == mx[dpN][j][dx][al][ak])) {
	  curr->emitLx = -1; curr->emitLy = -1; curr->transition = TNT;
	  PushTracestack(stack, AttachTrace(curr, dpT, i, j-1, k, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNT  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if ((!isYconstraint[l]) && (mx[dpRy][j][dx][al-1][ak] + 
	      model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[l])] + 
	      model->transitions[TNRY] == mx[dpN][j][dx][al][ak])) {
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1;
	  curr->transition = TNRY;
	  PushTracestack(stack, AttachTrace(curr, dpRy, i, j, k, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNRY  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if ((!isXconstraint[j]) && 
	    (mx[dpRx][j-1][dx-1][(l-sL[j-1])][ak] + 
	     model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[j])] + 
	     model->transitions[TNRX] == mx[dpN][j][dx][al][ak])) {
	  curr->emitLx = -1; curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TNRX;
	  PushTracestack(stack, AttachTrace(curr, dpRx, i, j-1, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNRX  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	
	} else if (NXOR(i,k) && (mx[dpS][j][dx-1][al][(k-sL[i+1])+1] 
	      + model->transitions[TNS]
	      + model->emissions[eAL(seqs->sequence[SEQX]->dseq[i],
		seqs->sequence[SEQY]->dseq[k])] 
	      == mx[dpN][j][dx][al][ak])) {
	  curr->emitRx = -1; curr->emitRy = -1; curr->transition = TNS;
	  PushTracestack(stack, AttachTrace(curr, dpS, i+1, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNS  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (!isXconstraint[i] && (mx[dpLx][j][dx-1][al][(k-sL[i+1])] 
	      + model->transitions[TNLX]
	      + model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[i])] 
	      == mx[dpN][j][dx][al][ak])) {
	  curr->emitRx = -1; curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TNLX;
	  PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNLX  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (!isYconstraint[k] && (mx[dpLy][j][dx][al][ak+1] 
	      + model->transitions[TNLY]
	      + model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[k])] 
	      == mx[dpN][j][dx][al][ak])) {
	  curr->transition = TNLY;
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	  PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNLY  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	  /* We want to do this state last so we minimize the number of
	   * times we're doing this internal loop */
	} else {
	  /* printf("Check bif in N\n"); */
	  if (NXOR(j,l)) {
	    for (a = i+2; a < j; a++) {
	      /* if (debug) printf("\t\t\t\t a = %d \n", a);  */
	      if (isXconstraint[a]) {	/* a is a constraint */
		/* Then only time we can bifurcate is if b is
		 * a's matching pair */
		/* printf("a is constraint\n"); fflush(stdout); */
		b = seqs->c_info->Yval[a];
		ab = b - sL[a];
		if (mx[dpP][j-1][dist(a+1,j-1)][(l-sL[j-1])-1][(b-sL[a+1])+1]
		    + mx[dpT][a-1][dist(i,a-1)][(b-sL[a-1])-1][ak]
		    + model->emissions[ePR(idx(seqs->sequence[SEQX]->dseq[a], 
			seqs->sequence[SEQX]->dseq[j]),
		      idx(seqs->sequence[SEQY]->dseq[b], 
			seqs->sequence[SEQY]->dseq[l]))] 
		    + model->transitions[TNB] ==
		    mx[dpN][j][dx][al][ak]) {
		  curr->emitLx = a; curr->emitLy = b; 
		  curr->transition = TNB;
		  PushTracestack(stack, 
		      AttachTrace(curr, dpP, a+1, j-1, b+1, l-1, NTRANS));
		  PushTracestack(stack, 
		      AttachTrace(curr, dpT, i, a-1, k, b-1, NTRANS));
		  if (debug) {
		    fprintf(stdout, 
			"(%#12x) dpN  %5d  %5d  %5d  %5d  TNB  %#10x  %#10x \n", 
			(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
			curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
		  }
		  a = j;        /* Short circuit */

		}
	      } else { /* a is not a constraint */
		/* b must in the segment containing a */
		bedge = ((l < sR[a])? l: sR[a]);
		/* printf("a NOT constraint\n"); fflush(stdout); */
		for (b = ((k+1 > sL[a])? k+2: sL[a]+1); b < bedge; b++) {
		  /* If be is a constraint; but not a then we
		   * can't bifurcate at this coordinate.  */
		  if ((j > 0) && (l > 0) && (a > 0) && (b > 0)) {
		    if (!isYconstraint[b] && mx[dpP][j-1][dist(a+1,j-1)]\
			[(l-sL[j-1])-1][(b-sL[a+1])+1]
			+ mx[dpT][a-1][dist(i,a-1)][(b-sL[a-1])-1][ak]
			+ model->emissions[
			ePR(idx(seqs->sequence[SEQX]->dseq[a],
			    seqs->sequence[SEQX]->dseq[j]),
			  idx(seqs->sequence[SEQY]->dseq[b], 
			    seqs->sequence[SEQY]->dseq[l]))] 
			+ model->transitions[TNB] ==
			mx[dpN][j][dx][al][ak]) {
		      curr->emitLx = a; curr->emitLy = b; 
		      curr->transition = TNB;
		      PushTracestack(stack, 
			  AttachTrace(curr, dpP, a+1, j-1, b+1, l-1, NTRANS));
		      PushTracestack(stack, 
			  AttachTrace(curr, dpT, i, a-1, k, b-1, NTRANS));
		      if (debug) {
			fprintf(stdout, 
			    "(%#12x) dpN  %5d  %5d  %5d  %5d  TNB  %#10x  %#10x \n", 
			    (int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
			    curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
		      }
		      b = bedge; a = j;        /* Short circuit */
		    }
		  } /* check for zero values */
		} /* for b */
	      } /* if a is constraint */
	    } /* for a */
	  }
	}
	break;

      /*********************
       *        dpT        *
       *********************/
      case dpT:
	if (debug) printf("dpT\n");
	fflush(stdout);
	if ((i > j) || (k > l)) {
	  printf("\nSHIT: Bad transition in dpT\n");
	} else if (NXOR(j,l) && (mx[dpT][j-1][dx-1][(l-sL[j-1])-1][ak] 
	      + model->emissions[eAL(seqs->sequence[SEQX]->dseq[j], 
		seqs->sequence[SEQY]->dseq[l])]
	      + model->transitions[TTT] == mx[dpT][j][dx][al][ak])) {
	  curr->emitLx = -1; curr->emitLy = -1;
	  curr->transition = TTT;
	  PushTracestack(stack, AttachTrace(curr, dpT, i, j-1, k, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpT  %5d  %5d  %5d  %5d  TTT  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (!isXconstraint[j] && (mx[dpRx][j-1][dx-1][(l-sL[j-1])][ak] + 
	      model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[j])]
	      + model->transitions[TTRX] == mx[dpT][j][dx][al][ak])) {
	  curr->emitLx = -1; curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TTRX;
	  PushTracestack(stack, AttachTrace(curr, dpRx, i, j-1, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpT  %5d  %5d  %5d  %5d  TTRX  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (!isYconstraint[l] && (mx[dpRy][j][dx][al-1][ak] + 
	      model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[l])]
	      + model->transitions[TTRY] == mx[dpT][j][dx][al][ak]))  {
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1;
	  curr->transition = TTRY;
	  PushTracestack(stack, AttachTrace(curr, dpRy, i, j, k, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpT  %5d  %5d  %5d  %5d  TTRY  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (NXOR(i,k) && NXOR(j,l) && 
	    (mx[dpP][j-1][dx-2][(l-sL[j-1])-1][(k-sL[i+1])+1] 
	     + model->emissions[ePR(idx(seqs->sequence[SEQX]->dseq[i],
		 seqs->sequence[SEQX]->dseq[j]),
	       idx(seqs->sequence[SEQY]->dseq[k],
		 seqs->sequence[SEQY]->dseq[l]))] 
	     + model->transitions[TTP] == mx[dpT][j][dx][al][ak])) {
	  curr->transition = TTP;
	  PushTracestack(stack, 
	      AttachTrace(curr, dpP, i+1, j-1, k+1, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpT  %5d  %5d  %5d  %5d  TTP   %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else {
	  if NXOR(j,l) {
	    for (a = i+2; a < j; a++) {
	      /* if (debug) printf("\t\t\t\t a = %d \n", a);  */
	      if (isXconstraint[a]) {	/* a is a constraint */
		/* Then only time we can bifurcate is if b is
		 * a's matching pair */
		b = seqs->c_info->Yval[a];
		ab = b - sL[a];
		if (mx[dpP][j-1][dist(a+1,j-1)][(l-sL[j-1])-1][(b-sL[a+1])+1]
		    + mx[dpT][a-1][dist(i,a-1)][(b-sL[a-1])-1][ak]
		    + model->emissions[ePR(idx(seqs->sequence[SEQX]->dseq[a], 
			seqs->sequence[SEQX]->dseq[j]),
		      idx(seqs->sequence[SEQY]->dseq[b], 
			seqs->sequence[SEQY]->dseq[l]))] 
		    + model->transitions[TTB] ==
		    mx[dpT][j][dx][al][ak]) {
		  curr->emitLx = a; curr->emitLy = b; 
		  curr->transition = TTB;
		  PushTracestack(stack, 
		      AttachTrace(curr, dpP, a+1, j-1, b+1, l-1, NTRANS));
		  PushTracestack(stack, 
		      AttachTrace(curr, dpT, i, a-1, k, b-1, NTRANS));
		  if (debug) {
		    fprintf(stdout, 
			"(%#12x) dpN  %5d  %5d  %5d  %5d  TTB  %#10x  %#10x \n", 
			(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
			curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
		  }
		  a = j;        /* Short circuit */
		}
	      } else { /* a is not a constraint */
		/* b must in the segment containing a */
		bedge = ((l < sR[a])? l: sR[a]);
		for (b = ((k+1 > sL[a])? k+2: sL[a]+1); b < bedge; b++) {
		  /* If be is a constraint; but not a then we
		   * can't bifurcate at this coordinate.  */
		  if ((j > 0) && (l > 0) && (a > 0) && (b > 0)) {
		    if (!isYconstraint[b] && mx[dpP][j-1][dist(a+1,j-1)]\
			[(l-sL[j-1])-1][(b-sL[a+1])+1]
			+ mx[dpT][a-1][dist(i,a-1)][(b-sL[a-1])-1][ak]
			+ model->emissions[
			ePR(idx(seqs->sequence[SEQX]->dseq[a],
			    seqs->sequence[SEQX]->dseq[j]),
			  idx(seqs->sequence[SEQY]->dseq[b], 
			    seqs->sequence[SEQY]->dseq[l]))] 
			+ model->transitions[TTB] ==
			mx[dpT][j][dx][al][ak]) {
		      curr->emitLx = a; curr->emitLy = b; 
		      curr->transition = TTB;
		      PushTracestack(stack, 
			  AttachTrace(curr, dpP, a+1, j-1, b+1, l-1, NTRANS));
		      PushTracestack(stack, 
			  AttachTrace(curr, dpT, i, a-1, k, b-1, NTRANS));
		      if (debug) {
			fprintf(stdout, 
			    "(%#12x) dpN  %5d  %5d  %5d  %5d  TTB  %#10x  %#10x \n", 
			    (int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
			    curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
		      }
		      b = bedge; a = j;        /* Short circuit */
		    }
		  } /* check for zero values */
		} /* for b */
	      } /* if a is constraint */
	    } /* for a */
	  }
	}
	break;

      /*********************
       *       dpLx        *
       *********************/
      case dpLx: 
	if (debug) printf("dpLx\n");
	fflush(stdout);
	if ((i > j) && (k > l)) {
	  curr->emitLy = -1; curr->emitRx = -1; 
	  curr->emitLx = -1; curr->emitRy = -1;
	  curr->transition = TLXE;
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLx  %5d  %5d  %5d  %5d  TLXE  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }

	} else if (i > j) {		/* Ran out of X, must end */
	  printf("Shit! Bad Transition! dpLx\n");
	} else if (k > l) {
	  curr->emitRx = -1; curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TLXX;
	  PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLx  %5d  %5d  %5d  %5d  TLXX  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (!isXconstraint[i] && (mx[dpLx][j][dx-1][al][(k-sL[i+1])] 
	      + model->transitions[TLXX]
	      + model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[i])] 
	      == mx[dpLx][j][dx][al][ak])) {
	  curr->emitRx = -1; curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TLXX;
	  PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLx  %5d  %5d  %5d  %5d  TLXX  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (NXOR(i,k) && (mx[dpS][j][dx-1][al][(k-sL[i+1])+1] 
	      + model->transitions[TLXS] + model->emissions[eAL(
		seqs->sequence[SEQX]->dseq[i],seqs->sequence[SEQY]->dseq[k])] 
	      == mx[dpLx][j][dx][al][ak])) {
	  curr->emitRx = -1; curr->emitRy = -1; curr->transition = TLXS;
	  PushTracestack(stack, AttachTrace(curr, dpS, i+1, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLx  %5d  %5d  %5d  %5d  TLXS  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else {
	  /* if (mx[dpT][j][dx][al][ak] 
	     + model->transitions[TLXT] == mx[dpLx][j][dx][al][ak])  */
	  curr->emitLx = -1; curr->emitRx = -1; 
	  curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TLXT;
	  PushTracestack(stack, AttachTrace(curr, dpT, i, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLx  %5d  %5d  %5d  %5d  TLXT  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	}
	break;

      /*********************
       *       dpLy        *
       *********************/
      case dpLy: 
	if (debug) printf("dpLy\n");
	fflush(stdout);
	if ((i > j) && (k > l)) {
	  curr->emitLy = -1; curr->emitRx = -1; 
	  curr->emitLx = -1; curr->emitRy = -1;
	  curr->transition = TLYE;
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLy  %5d  %5d  %5d  %5d  TLYE  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (k > l) {		/* Ran out of Y, must end */
	  printf("Shit! Bad Transition! dpLx\n");
	} else if (i > j) {
	  curr->transition = TLYY;
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	  PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLy  %5d  %5d  %5d  %5d  TLYY  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }

	} else if (!isYconstraint[k] && (mx[dpLy][j][dx][al][ak+1] 
	      + model->transitions[TLYY]
	      + model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[k])] 
	      == mx[dpLy][j][dx][al][ak])) {
	  curr->transition = TLYY;
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	  PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLy  %5d  %5d  %5d  %5d  TLYY  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (NXOR(i,k) && (mx[dpS][j][dx-1][al][(k-sL[i+1])+1] 
	      + model->transitions[TLYS] + model->emissions[eAL(
		seqs->sequence[SEQX]->dseq[i],seqs->sequence[SEQY]->dseq[k])] 
	      == mx[dpLy][j][dx][al][ak])) {
	  curr->emitRx = -1; curr->emitRy = -1; curr->transition = TLYS;
	  PushTracestack(stack, AttachTrace(curr, dpS, i+1, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLy  %5d  %5d  %5d  %5d  TLYS  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }

	} else {
	  /* if (mx[dpT][j][dx][al][ak] 
	     + model->transitions[TLYT] == mx[dpLy][j][dx][al][ak])  */
	  curr->emitLx = -1; curr->emitRx = -1; 
	  curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TLYT;
	  PushTracestack(stack, AttachTrace(curr, dpT, i, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLy  %5d  %5d  %5d  %5d  TLYT  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	}
	break;

      /*********************
       *       dpRx        *
       *********************/
      case dpRx: 
	if (debug) printf("dpRx\n");
	fflush(stdout);
	if ((i > j) || (k > l)) {
	  printf("\nSHIT: Bad transition in dpRx\n");
	} else if (NXOR(j,l) && (mx[dpT][j-1][dx-1][(l-sL[j-1])-1][ak] 
	      + model->emissions[eAL(seqs->sequence[SEQX]->dseq[j], 
		seqs->sequence[SEQY]->dseq[l])]
	      + model->transitions[TRXT] == mx[dpRx][j][dx][al][ak])) {
	  curr->emitLx = -1; curr->emitLy = -1;
	  curr->transition = TRXT;
	  PushTracestack(stack, AttachTrace(curr, dpT, i, j-1, k, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpRx %5d  %5d  %5d  %5d  TRXT  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (!isXconstraint[j] && (mx[dpRx][j-1][dx-1][(l-sL[j-1])][ak] 
	      + model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[j])]
	      + model->transitions[TRXX] == mx[dpRx][j][dx][al][ak])) {
	  curr->emitLx = -1; curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TRXX;
	  PushTracestack(stack, AttachTrace(curr, dpRx, i, j-1, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpRx  %5d  %5d  %5d  %5d  TRXX  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (NXOR(i,k) && NXOR(j,l) && 
	    (mx[dpP][j-1][dx-2][(l-sL[j-1])-1][(k-sL[i+1])+1] 
	     + model->emissions[ePR(idx(seqs->sequence[SEQX]->dseq[i],
		 seqs->sequence[SEQX]->dseq[j]),
	       idx(seqs->sequence[SEQY]->dseq[k],
		 seqs->sequence[SEQY]->dseq[l]))] 
	     + model->transitions[TRXP] == mx[dpRx][j][dx][al][ak])) {
	  curr->transition = TRXP;
	  PushTracestack(stack, 
	      AttachTrace(curr, dpP, i+1, j-1, k+1, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpRx  %5d  %5d  %5d  %5d  TRXP  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else {
	  if (NXOR(j,l)) {
	    for (a = i+2; a < j; a++) {
	      /* if (debug) printf("\t\t\t\t a = %d \n", a);  */
	      if (isXconstraint[a]) {	/* a is a constraint */
		/* Then only time we can bifurcate is if b is
		 * a's matching pair */
		b = seqs->c_info->Yval[a];
		ab = b - sL[a];
		if (mx[dpP][j-1][dist(a+1,j-1)][(l-sL[j-1])-1][(b-sL[a+1])+1]
		    + mx[dpT][a-1][dist(i,a-1)][(b-sL[a-1])-1][ak]
		    + model->emissions[ePR(idx(seqs->sequence[SEQX]->dseq[a], 
			seqs->sequence[SEQX]->dseq[j]),
		      idx(seqs->sequence[SEQY]->dseq[b], 
			seqs->sequence[SEQY]->dseq[l]))] 
		    + model->transitions[TRXB] ==
		    mx[dpRx][j][dx][al][ak]) {
		  curr->emitLx = a; curr->emitLy = b; 
		  curr->transition = TRXB;
		  PushTracestack(stack, 
		      AttachTrace(curr, dpP, a+1, j-1, b+1, l-1, NTRANS));
		  PushTracestack(stack, 
		      AttachTrace(curr, dpT, i, a-1, k, b-1, NTRANS));
		  if (debug) {
		    fprintf(stdout, 
			"(%#12x) dpN  %5d  %5d  %5d  %5d  TRXB  %#10x  %#10x \n", 
			(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
			curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
		  }
		  a = j;        /* Short circuit */
		}
	      } else { /* a is not a constraint */
		/* b must in the segment containing a */
		bedge = ((l < sR[a])? l: sR[a]);
		for (b = ((k+1 > sL[a])? k+2: sL[a]+1); b < bedge; b++) {
		  /* If be is a constraint; but not a then we
		   * can't bifurcate at this coordinate.  */
		  if ((j > 0) && (l > 0) && (a > 0) && (b > 0)) {
		    if (!isYconstraint[b] && mx[dpP][j-1][dist(a+1,j-1)]\
			[(l-sL[j-1])-1][(b-sL[a+1])+1]
			+ mx[dpT][a-1][dist(i,a-1)][(b-sL[a-1])-1][ak]
			+ model->emissions[
			ePR(idx(seqs->sequence[SEQX]->dseq[a],
			    seqs->sequence[SEQX]->dseq[j]),
			  idx(seqs->sequence[SEQY]->dseq[b], 
			    seqs->sequence[SEQY]->dseq[l]))] 
			+ model->transitions[TRXB] ==
			mx[dpRx][j][dx][al][ak]) {
		      curr->emitLx = a; curr->emitLy = b; 
		      curr->transition = TRXB;
		      PushTracestack(stack, 
			  AttachTrace(curr, dpP, a+1, j-1, b+1, l-1, NTRANS));
		      PushTracestack(stack, 
			  AttachTrace(curr, dpT, i, a-1, k, b-1, NTRANS));
		      if (debug) {
			fprintf(stdout, 
			    "(%#12x) dpN  %5d  %5d  %5d  %5d  TRXB  %#10x  %#10x \n", 
			    (int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
			    curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
		      }
		      b = bedge; a = j;        /* Short circuit */
		    }
		  } /* check for zero values */
		} /* for b */
	      } /* if a is constraint */
	    } /* for a */
	  }
	}
	break;

      /*********************
       *       dpRy        *
       *********************/
      case dpRy: 
	if (debug) printf("dpRy\n");
	fflush(stdout);
	if ((i > j) || (k > l)) {
	  printf("\nSHIT: Bad transition in dpRy\n");
	} else if (NXOR(j,l) && (mx[dpT][j-1][dx-1][(l-sL[j-1])-1][ak] 
	      + model->emissions[eAL(seqs->sequence[SEQX]->dseq[j], 
		seqs->sequence[SEQY]->dseq[l])]
	      + model->transitions[TRYT] == mx[dpRy][j][dx][al][ak])) {
	  curr->emitLx = -1; curr->emitLy = -1;
	  curr->transition = TRYT;
	  PushTracestack(stack, AttachTrace(curr, dpT, i, j-1, k, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpRy  %5d  %5d  %5d  %5d  TRYT  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (!isYconstraint[l] && (mx[dpRy][j][dx][al-1][ak] 
	      + model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[l])]
	      + model->transitions[TRYY] == mx[dpRy][j][dx][al][ak])) {
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1;
	  curr->transition = TRYY;
	  PushTracestack(stack, AttachTrace(curr, dpRy, i, j, k, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpRy  %5d  %5d  %5d  %5d  TRYY  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (NXOR(i,k) && NXOR(j,l) &&
	    (mx[dpP][j-1][dx-2][(l-sL[j-1])-1][(k-sL[i+1])+1] 
	     + model->emissions[ePR(idx(seqs->sequence[SEQX]->dseq[i],
		 seqs->sequence[SEQX]->dseq[j]),
	       idx(seqs->sequence[SEQY]->dseq[k],
		 seqs->sequence[SEQY]->dseq[l]))] 
	     + model->transitions[TRYP] == mx[dpRy][j][dx][al][ak])) {
	  curr->transition = TRYP;
	  PushTracestack(stack, 
	      AttachTrace(curr, dpP, i+1, j-1, k+1, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpRy  %5d  %5d  %5d  %5d  TRYP  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else {
	  if (NXOR(j,l)) {
	    for (a = i+2; a < j; a++) {
	      /* if (debug) printf("\t\t\t\t a = %d \n", a);  */
	      if (isXconstraint[a]) {	/* a is a constraint */
		/* Then only time we can bifurcate is if b is
		 * a's matching pair */
		b = seqs->c_info->Yval[a];
		ab = b - sL[a];
		if (mx[dpP][j-1][dist(a+1,j-1)][(l-sL[j-1])-1][(b-sL[a+1])+1]
		    + mx[dpT][a-1][dist(i,a-1)][(b-sL[a-1])-1][ak]
		    + model->emissions[ePR(idx(seqs->sequence[SEQX]->dseq[a], 
			seqs->sequence[SEQX]->dseq[j]),
		      idx(seqs->sequence[SEQY]->dseq[b], 
			seqs->sequence[SEQY]->dseq[l]))] 
		    + model->transitions[TRYB] ==
		    mx[dpRy][j][dx][al][ak]) {
		  curr->emitLx = a; curr->emitLy = b; 
		  curr->transition = TRYB;
		  PushTracestack(stack, 
		      AttachTrace(curr, dpP, a+1, j-1, b+1, l-1, NTRANS));
		  PushTracestack(stack, 
		      AttachTrace(curr, dpT, i, a-1, k, b-1, NTRANS));
		  if (debug) {
		    fprintf(stdout, 
			"(%#12x) dpN  %5d  %5d  %5d  %5d  TRYB  %#10x  %#10x \n", 
			(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
			curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
		  }
		  a = j;        /* Short circuit */
		}
	      } else { /* a is not a constraint */
		/* b must in the segment containing a */
		bedge = ((l < sR[a])? l: sR[a]);
		for (b = ((k+1 > sL[a])? k+2: sL[a]+1); b < bedge; b++) {
		  /* If be is a constraint; but not a then we
		   * can't bifurcate at this coordinate.  */
		  if ((j > 0) && (l > 0) && (a > 0) && (b > 0)) {
		    if ((!isYconstraint[b]) && (mx[dpP][j-1][dist(a+1,j-1)]\
			  [(l-sL[j-1])-1][(b-sL[a+1])+1]
			  + mx[dpT][a-1][dist(i,a-1)][(b-sL[a-1])-1][ak]
			  + model->emissions[
			  ePR(idx(seqs->sequence[SEQX]->dseq[a],
			      seqs->sequence[SEQX]->dseq[j]),
			    idx(seqs->sequence[SEQY]->dseq[b], 
			      seqs->sequence[SEQY]->dseq[l]))] 
			  + model->transitions[TRYB] ==
			  mx[dpRy][j][dx][al][ak])) {
		      curr->emitLx = a; curr->emitLy = b; 
		      curr->transition = TRYB;
		      PushTracestack(stack, 
			  AttachTrace(curr, dpP, a+1, j-1, b+1, l-1, NTRANS));
		      PushTracestack(stack, 
			  AttachTrace(curr, dpT, i, a-1, k, b-1, NTRANS));
		      if (debug) {
			fprintf(stdout, 
			    "(%#12x) dpN  %5d  %5d  %5d  %5d  TRYB  %#10x  %#10x \n", 
			    (int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
			    curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
		      }
		      b = bedge; a = j;        /* Short circuit */
		    }
		  } /* check for zero values */
		} /* for b */
	      } /* if a is constraint */
	    } /* for a */
	  } else {
	    printf("Why are you here? dpRy failed bif NXOR\n");
	  }
	}
	break;
      default: 
	break;
    }
  } /* end while stack not empty*/
  FreeTracestack(stack);
  return parsetree;
}

/* Cell by cell comparison of the RED version (mx) 
 * to full Sankoff matrix (fmx).  This check is 
 * expensive!
 */
void
checkCells(SEQPR *seqs, int *****mx, int *****fmx)
{
  int i, j, dx;	/* Sequence x indicies */
  int k, l, dy;	/* Sequence y indicies */
  int al, ak;	/* allocation coordinates */
  int ledge;
  int debug = FALSE;

  int Xlen, Ylen;
  char *isXconstraint;
  char *isYconstraint;
  int *sL; int *sR, *Yval;
  int madeit;

  /* Using local pointers to make the code more readable;
   * may also help with some compiler optimizations */
  Xlen = seqs->sequence[SEQX]->len;
  Ylen = seqs->sequence[SEQY]->len;
  sL = seqs->c_info->sL;
  sR = seqs->c_info->sR;
  /* Must define isXconstraint isYconstraint and Yval for NXOR macro to work */
  isXconstraint = seqs->c_info->isXconstraint;
  isYconstraint = seqs->c_info->isYconstraint;
  Yval = seqs->c_info->Yval;

  if (debug) { printf("X len %d Ylen %d\n", Xlen, Ylen); }

  madeit = FALSE;
  for (dx = 0; dx <= Xlen; dx++) {
    for (j = (dx > 0)? dx-1: 0; j < Xlen; j++) {
      i = j - dx +1;

      for (dy = ((sL[j] >= sR[i]) ? (sL[j] - sR[i]+1): 0); 
	  dy <= (sR[j] - sL[i] +1); dy++) {
	/* Loop ends at min sR[j] unless 
	 * sR[i] != sR[j] and sR[i] + dy -1) */
	/* ledge = ((sR[i] == sR[j])?  ((dy == 0)? sR[j]-1 : sR[j]) : */
	ledge = ((sR[i] == sR[j])? sR[j] :  
	    ((sR[i] + dy -1 < sR[j])? (sR[i] + dy -1) : sR[j])); 
	/* Loop begins at max (sL[j], sL[i] + dy -1) */
	for (l = ((sL[j] > sL[i] + dy -1)? sL[j] : sL[i] + dy -1); 
	    l <= ledge; l++) { 
	  k = l - dy +1;

	  /* Set allocation coordinates */
	  al = l - sL[j];	ak = k - sL[i];

	  if (mx[dpT][j][dx][al][ak] != fmx[dpT][j][dx][l][dy]) {
	    printf("Problem! dpT[%d][%d][%d][%d] (al %d ak %d) \n", 
		j, dx, l, dy, al, ak);
	    printf("RED %d CON %d\n", mx[dpT][j][dx][al][ak],
		fmx[dpT][j][dx][l][dy]);
	  } else if (mx[dpS][j][dx][al][ak] != fmx[dpS][j][dx][l][dy]) {
	    printf("Problem! dpS[%d][%d][%d][%d] (al %d ak %d) \n", 
		j, dx, l, dy, al, ak);
	    printf("RED %d CON %d\n", mx[dpS][j][dx][al][ak],
		fmx[dpS][j][dx][l][dy]);
	  } else if (mx[dpLx][j][dx][al][ak] != fmx[dpLx][j][dx][l][dy]) {
	    printf("Problem! dpLx[%d][%d][%d][%d] (al %d ak %d) \n", 
		j, dx, l, dy, al, ak);
	    printf("RED %d CON %d\n", mx[dpLx][j][dx][al][ak],
		fmx[dpLx][j][dx][l][dy]);
	  } else if (mx[dpLy][j][dx][al][ak] != fmx[dpLy][j][dx][l][dy]) {
	    printf("Problem! dpLy[%d][%d][%d][%d] (al %d ak %d) \n", 
		j, dx, l, dy, al, ak);
	    printf("RED %d CON %d\n", mx[dpLy][j][dx][al][ak],
		fmx[dpLy][j][dx][l][dy]);
	  } else if (mx[dpRx][j][dx][al][ak] != fmx[dpRx][j][dx][l][dy]) {
	    printf("Problem! dpRx[%d][%d][%d][%d] (al %d ak %d) \n", 
		j, dx, l, dy, al, ak);
	    printf("RED %d CON %d\n", mx[dpRx][j][dx][al][ak],
		fmx[dpRx][j][dx][l][dy]);
	  } else if (mx[dpRy][j][dx][al][ak] != fmx[dpRy][j][dx][l][dy]) {
	    printf("Problem! dpRy[%d][%d][%d][%d] (al %d ak %d) \n", 
		j, dx, l, dy, al, ak);
	    printf("RED %d CON %d\n", mx[dpRy][j][dx][al][ak],
		fmx[dpRy][j][dx][l][dy]);
	  } else if (mx[dpN][j][dx][al][ak] != fmx[dpN][j][dx][l][dy]) {
	    printf("Problem! dpN[%d][%d][%d][%d] (al %d ak %d) \n", 
		j, dx, l, dy, al, ak);
	    printf("RED %d CON %d\n", mx[dpN][j][dx][al][ak],
		fmx[dpN][j][dx][l][dy]);
	  } else if (mx[dpP][j][dx][al][ak] != fmx[dpP][j][dx][l][dy]) {
	    printf("Problem! dpP[%d][%d][%d][%d] (al %d ak %d) \n", 
		j, dx, l, dy, al, ak);
	    printf("RED %d CON %d\n", mx[dpP][j][dx][al][ak],
		fmx[dpP][j][dx][l][dy]);
	  } else {
	    madeit = TRUE;
	  }
	  if (!madeit) return;
	  madeit = FALSE;
	}
      }
    }
  }
}


