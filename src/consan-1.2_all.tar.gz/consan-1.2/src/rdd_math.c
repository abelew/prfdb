/* rdd_math.c
 * RDD, Fri Aug 24 12:51:19 2001
 * 
 * Math support routines for manipulating 
 * probabilities and their integer log counterpart.
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#include "squid.h"
#include "cfg.h"
#include "options.h"
#include "rnamat.h"

/* Function: asIntLog
 * Date: RDD, Fri Aug 30 10:03:52 CDT 2002 [St Louis]
 *
 * Purpose: Debugging, convert prob. to int log form
 *
 * Args:
 *     prob	Prob to convert (in float form)
 *
 * Returns:
 * 	Prob in Int log form
 */
int
asIntLog(float prob)
{
   /* If we feed something nearly zero, we need to be
    * assured that we're getting back the int value of prob(zero).
    */
   if (LOG2(prob) < -BIGFLOAT) return -BIGINT;
   /* Adding the 0.5 make the cast effectively round */
   else return ((int) (LOG2(prob) * INTSCALE - 0.5));
}

/* Function: asLog
 * Date: Fri Dec 13 10:28:45 CST 2002 [St Louis]
 *
 * Purpose: Debugging, convert prob. to log form
 *
 * Args:
 *     prob	Prob to convert (in double form)
 *
 * Returns:
 * 	Prob in Int log form
 */
float 
asLog(float prob)
{
   /* If we feed something nearly zero, we need to be
    * assured that we're getting back the int value of prob(zero).
    */
   if (LOG2(prob) < -BIGFLOAT)  return -BIGFLOAT;
      /* Adding the 0.5 make the cast effectively round */
   else  return (LOG2(prob) * INTSCALE); 
}

/* Function: asFloatProb
 * Date: RDD, Fri Aug 30 10:08:50 CDT 2002 [St Louis]
 *
 * Purpose: Debugging, convert int log form to prob 
 *
 * Args:
 *     prob	Prob to convert (in int log form)
 *
 * Returns:
 * 	Prob as a float
 */
float
asFloatProb(int prob)
{
   if (prob <= -BIGINT) return 0.0;
   else return (exp(LN2 * (float)(prob/INTSCALE))); 
}

/* Function: asProb
 * Date: Fri Dec 13 10:28:30 CST 2002 [St Louis]
 *
 * Purpose: Debugging, convert log form to prob 
 *
 * Args:
 *     prob	Prob to convert (in int log form)
 *
 * Returns:
 * 	Prob as a float
 */
float
asProb (double prob)
{
   if (prob <= -BIGFLOAT) return 0.0; 
   else return ((float)(exp(LN2 * (prob/INTSCALE)))); 
}

/* Function: ILogsum()
 * From HMMer's mathsupport.c -- SRE, Mon Nov 11 15:07:33 1996
 * RDD, Thu Jun 20 14:54:03 CDT 2002 [St Louis]
 * 
 * Purpose:  Return the scaled integer log probability of
 *           the sum of two probabilities p1 and p2, where
 *           p1 and p2 are also given as scaled log probabilities.
 *         
 *           log(exp(p1)+exp(p2)) = p1 + log(1 + exp(p2-p1)) for p1 > p2
 *           
 *           For speed, builds a lookup table the first time it's called.
 *
 * Note: LOGSUM_TBL currently set to 20,000 (in cfg.h)
 *           
 * Args:     p1,p2 -- scaled integer log_2 probabilities to be summed
 *                    in probability space.
 *                    
 * Return:   scaled integer log_2 probability of the sum.
 */
inline int 
ILogsum(int p1, int p2)
{
  static int firsttime = 1;
  static int lookup[LOGSUM_TBL];
  int    diff;
  int    i;

  if (firsttime) {
    for (i = 0; i < LOGSUM_TBL; i++) 
      lookup[i] = (int) (INTSCALE * LN2INV *
			 (log(1.+exp(LN2 * (float) -i/INTSCALE))));
    firsttime = 0;
  }

  if (p2 < -BIGINT) return p1;
  else if (p1 < -BIGINT) return p2;

  diff = p1-p2;
  if      (diff >=  LOGSUM_TBL) return p1;
  else if (diff <= -LOGSUM_TBL) return p2;
  else if (diff > 0)            return p1 + lookup[diff];
  else                          return p2 + lookup[-diff];
} 

/* Function: DLogsum()
 * RDD, Fri Dec 20 08:56:01 CST 2002 [Cuba, MO]
 * 
 * Purpose:  Return the scaled log probability of
 *           the sum of two probabilities p1 and p2, where
 *           p1 and p2 are also given as scaled probabilities.
 *         
 *           log(exp(p1)+exp(p2)) = p1 + log(1 + exp(p2-p1)) for p1 > p2
 *           
 * Args:     p1,p2 -- scaled log_2 probabilities to be summed
 *                    in probability space.
 *                    
 * Return:   scaled log_2 probability of the sum.
 */
inline double  
DLogsum(double p1, double p2)
{
  double diff;
  double lookup;

  if (p2 < -BIGFLOAT) return p1;
  else if (p1 < -BIGFLOAT) return p2;

  diff = p1-p2;
  if (diff > 0) {
    lookup = (double) (INTSCALE * LN2INV *
			 (log(1.+exp(LN2 *  -diff/INTSCALE))));
  } else {
    lookup = (double) (INTSCALE * LN2INV *
			 (log(1.+exp(LN2 *  diff/INTSCALE))));
  }

  if      (diff >=  LOGSUM_TBL) return p1;
  else if (diff <= -LOGSUM_TBL) return p2;
  else if (diff > 0)            return p1 + lookup;
  else                          return p2 + lookup;
}

/* Function: ILogsumSet()
 * RDD, Wed Aug 21 16:08:37 CDT 2002 [St Louis]
 *
 * Purpose: Given an array of scaled integer log probabilities,
 * 		calculate the sum across the array.
 *
 * Args:
 *   intprob	scaled integer (log_2) probs
 *   n		size of intprob array
 *
 * Return:  scaled integer prob of sum
 */
int 
ILogsumSet(int *intprob, int n)
{
  static int firsttime = 1;
  static int lookup[LOGSUM_TBL];
  int    diff;
  int    i, temp;

  if (firsttime) {
    for (i = 0; i < LOGSUM_TBL; i++) 
      lookup[i] = (int) (INTSCALE * LN2INV *
			 (log(1.+exp(LN2 * (float) -i/INTSCALE))));
    firsttime = 0;
  }

  if (n == 0) return (-BIGINT);
  if (n == 1) return (intprob[0]);

  /* rddSort(intprob, n);
  for (i = 0; i < n; i++) {
     printf("i %d : %d\n", i, intprob[i]);
  } */

  diff = intprob[0] - intprob[1];
  if (diff >= LOGSUM_TBL) temp = intprob[0];
  else if (diff <= -LOGSUM_TBL) temp = intprob[1];
  else if (diff > 0) temp = intprob[0] + lookup[diff];
  else temp = intprob[1] + lookup[-diff];

  if (n == 2) return temp;

  for (i = 2; i < n; i++) {
     diff = temp - intprob[i];

     if (diff >= LOGSUM_TBL) temp = temp;
     else if (diff <= -LOGSUM_TBL) temp = intprob[i];
     else if (diff > 0) temp = temp + lookup[diff];
     else temp = intprob[i] + lookup[-diff];
  }
  return temp;
} 

/**************** Debugging Fuctions **************/
int 
sanityCheck(int *intprob, int n)
{
   double *asfloats;
   double sum;
   int i;

   asfloats = (double *) malloc(sizeof(double)*n+1);

   sum = 0.0;
   for (i = 0; i < n ; i++) {
      asfloats[i] = asFloatProb(intprob[i]);
      printf("%e %d\n", asfloats[i], intprob[i]);
      sum += asfloats[i];
   }
   return (asIntLog(sum));
}

void
rddSort(int *intprob, int n)
{
   int i, j, temp;

   for (i = 0; i < n; i++) {
      for (j = i+1; j < n; j++) {
	 if (intprob[i] > intprob[j]) {
	    temp = intprob[j];
	    intprob[j] = intprob[i];
	    intprob[i] = temp;
	 }
      }
   }
}

/* Function: CheckDoubleProb()
 * Date:     ER, Tue May 25 13:18:02 CDT 1999  [St. Louis] 
 * 
 * Purpose:  Verify that \sum_{x,y} P(x,y) = 1 
 * 
 * Args:     pdouble - double-argument probability distribution to check 
 * 
 * Returns:  void.  
 */ 
void
CheckDoubleProb(double **pdouble, int dimx, int dimy)
{
  int    x;
  int    y;
  double sum = 0.0;

  for (x = 0; x < dimx; x++)
    for (y = 0; y < dimy; y++){
      if (pdouble[x][y] < -MARGIN) Die ("CheckDoubleProb(dimx=%d,dimy=%d): probabilities are getting too small here P = %f", dimx, dimy, pdouble[x][y]);
      sum += pdouble[x][y];
    }
  
  if (sum > 1.0+MARGIN || sum < 1.0-MARGIN) Die("CheckDoubleProb(dimx=%d,dimy=%d): sum_{x,y} P(x,y) is %f\n", dimx, dimy, sum);
}

/* Function: CheckSingleProb()
 * Date:     ER, Tue May 25 13:18:02 CDT 1999  [St. Louis]
 *
 * Purpose:  Verify that \sum_x P(x) = 1
 *
 * Args:     psingle - single-argument probability distribution to check
 *
 * Returns:  void. 
 */
void
CheckSingleProb(double *psingle, int size)
{
  int x;
  double sum = 0.0;

  for (x = 0; x < size; x++) {
    if (psingle[x] > 1.0+MARGIN) Die ("CheckSingleProb(L=%d): probabilities are getting too large here. P[%d] = %f", size, x, psingle[x]);
    if (psingle[x] < -MARGIN)    Die ("CheckSingleProb(L=%d): probabilities are getting too small here, P[%d] = %f", size, x, psingle[x]);
    sum += psingle[x];
  }
  
  if (sum > 1.0+MARGIN || sum < 1.0-MARGIN) Die ("CheckSingleProb(L=%d): sum_x P(x) is %f\n", size, sum);
}

  void
CheckSingleLog2Prob(double *psingle, int size)
{
  int    x;
  double prob;
  double sum = 0.0;

  for (x = 0; x < size; x++) {
    if (psingle[x] > - 50.) {
      prob = EXP2(psingle[x]);
      if (prob > 1.0+MARGIN) Die ("CheckSingleLog2Prob(L=%d): probabilities are getting too large here. P[%d] = %f", size, x, prob);
      if (prob <    -MARGIN) Die ("CheckSingleLog2Prob(L=%d): probabilities are getting too small here. P[%d] = %f", size, x, prob);
      sum += prob;
    }
  }

  if (sum > 1.0+MARGIN || sum < 1.0-MARGIN) Die ("CheckSingleLog2Prob(L=%d): sum_x P(x) is %f\n", size, sum);
}

void
CheckSYMLog2Prob(double *mat, int edge_size)
{
  int    L;
  int    i;
  int    x, y;
  double prob;
  double sum = 0.0;

  L = edge_size*edge_size;

  for (i = 0; i < L; i++) {

      x = i/edge_size;
      y = i%edge_size;

      if (y <= x) {
	
	if (mat[matrix_index(y,x)] > -50.0) {
	  prob = EXP2(mat[matrix_index(y,x)]);
	  
	  if (prob > 1.0+MARGIN2) Die ("CheckSingleLog2Prob(): probabilities are getting too large here. P[%d] = %f", i, prob);
	  if (prob <    -MARGIN2) Die ("CheckSingleLog2Prob(): probabilities are getting too small here. P[%d] = %f", i, prob);
	  
	  sum += (x == y)? prob : 2.0*prob;
	}
	
      }
  }
  
  if (sum > 1.0+MARGIN2 || sum < 1.0-MARGIN2) Die ("CheckSYMLog2Prob(): sum_x P(x) is %f\n", sum);
}

/* Function: DistributionMeanVar()
 * Date:     ER, Wed Jul 16 15:19:40 CDT 2003   [St. Louis] 
 * 
 * Purpose:  Calculates \sum_{x} x P(x)  
 * 
 * Args:     p - distributio
 * 
 * Returns:  void.  
 */
void
DistributionMeanVar(double *p, int dim, double *ret_mean, double *ret_var)
{
  double mean = 0.0;
  double var  = 0.0;
  int    x;
  
  for (x = 0; x < dim; x++) {
    if (p[x] < -MARGIN) Die ("DistributionAverage(): probabilities are getting too small here P = %f", p[x]);
    mean += x*p[x];
    var  += x*x*p[x];
  }
  
  var -= mean * mean;
  
  var = sqrt(var);

  *ret_mean = mean;
  *ret_var  = var;
}
void
DistributionMean(double *p, int dim, double *ret_mean)
{
  double mean = 0.0;
  int    x;
  
  for (x = 0; x < dim; x++) {
    if (p[x] < -MARGIN) Die ("DistributionAverage(): probabilities are getting too small here P = %f", p[x]);
    mean += x*p[x];
  }
  
  *ret_mean = mean;
}

void
DistributionLogMean(double *p, int dim, double *ret_mean)
{
  double mean = 0.0;
  int    x;
  
  for (x = 0; x < dim; x++) 
    mean +=     x * EXP2(p[x]);

  *ret_mean = mean;
}

void
DistributionLogMeanVar(double *p, int dim, double *ret_mean, double *ret_var)
{
  double mean = 0.0;
  double var  = 0.0;
  int    x;
  
  for (x = 0; x < dim; x++) {
    mean +=     x * EXP2(p[x]);
    var  += x * x * EXP2(p[x]);
  }
  
  var -= mean * mean;
  
  var = sqrt(var);

  *ret_mean = mean;
  *ret_var  = var;
}

