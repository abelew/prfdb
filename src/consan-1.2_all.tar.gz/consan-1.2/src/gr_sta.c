/* gr_sta.c
 * Mon Apr  7 20:48:18 CDT 2003
 *
 * Implementations of the grammar specific functions 
 * for the full Sankoff (STA based)
 *
 * This is the baseline full sankoff implementation 
 * against which all variants will be judged for accuracy 
 * and resource improvement.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "squid.h"
#include "sqfuncs.h"

#include "cfg.h"
#include "consan.h"
#include "sgmr.h"
#include "trace.h"
#include "options.h"
#include "alphabet.h"

/*****************************************
 * Unconstrained Sankoff:: CYK algorithm 
 * By Convention:
 *   i, a, j, dx   in sequence X
 *   k, b, l, dy   in sequence Y
 * Coordinates:
 *    0 <= dx <= Xlen
 *    0 <= j < Xlen
 *    i = j - dx +1
 *    0 <= dy <= Ylen
 *    0 <= l < Ylen
 *    k = l - dy +1
 *****************************************/

/* Function: cykFillSTA
 * Date:     Sun Feb 16 19:15:06 CST 2003 [St Louis]
 *
 * Purpose:  Fills CYK matrix for STA grammar
 * Assumption: Fill matrix already allocated 
 *
 * Notes: This guy is long.  But making function calls
 *   within the loops would be catastrophic to runtime.
 *
 *   We don't assume any initialization -- that way we
 *   need only go through the big loops once.  But it
 *   means more if statements.  Something of a trade-off.
 *
 *   The place where this gets 'trickey' is in dealing
 *   with zero lengths.  Each nonterminal in the grammar
 *   must be delt with specifically for zero length stuff.
 *
 * Args:    
 * 	seqX	sequences to align and fold
 * 	seqY
 * 	model	parameter and grammar info
 * 	grammar	good for STA and ST2
 * 	mx	fill matrix
 *
 * Returns:  void 
 */
  void
cykFillSTA(SEQUENCE *seqX, SEQUENCE *seqY, INTMOD *model, int grammar, int *****mx)
{
  int i, j, dx, a;	/* Sequence x indicies */
  int k, l, dy, b;	/* Sequence y indicies */
  int mP;		/* MNG/STA trick: picking S or P for pairing */
  int Xlen, Ylen;	/* Length - makes code more readable */
  int max, cursc;      
  int stackvalue;
  int debug = FALSE;	/* TRUE turns on extreme debugging output */

  Xlen = seqX->len;
  Ylen = seqY->len;

  /* MNG uses (xy) S (x'y')
   * STA/ST2 uses (xy) P (x'y') */
  if (grammar == MNG) mP = dpS; 
  else mP = dpP;

  /* Here we go ... */
  for (dx = 0; dx <= Xlen; dx++) {	/* dx = 0 previously initialized */
    if (debug) { printf("dx %d\n", dx); }
    for (j = (dx > 0)? dx-1: 0; j < Xlen; j++) {   
      if (debug) { printf("\t j %d\n", j); }
      i = j - dx + 1; 
      for (dy = 0; dy <= Ylen; dy++) { /* dy = 0 previously init */
	if (debug) { printf("\t\t dy %d\n", dy); }
	for (l = (dy > 0)?dy-1: 0; l < Ylen; l++) { 
	  if (debug) { printf("\t\t\t l %d\n", l); }
	  k = l - dy + 1; 

	  /* T -> T(xy) | Rx(x-) | Ry(-y) | (xy)P(x'y') | T (xy)P(x'y') */
	  if ((dx == 0) || (dy == 0)) {
	    mx[dpT][j][dx][l][dy] = -BIGINT;
	  } else {
	    max = -BIGINT;

	    /* T(xy) */
	    if ((j == 0) && (l == 0)) 
	      cursc = mx[dpT][0][dx-1][0][dy-1] 
		+ model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		+ model->transitions[TTT];
	    else if (j == 0) 
	      cursc = mx[dpT][0][dx-1][l-1][dy-1] 
		+ model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		+ model->transitions[TTT];
	    else if (l == 0) 
	      cursc = mx[dpT][j-1][dx-1][0][dy-1] 
		+ model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		+ model->transitions[TTT];
	    else 
	      cursc = mx[dpT][j-1][dx-1][l-1][dy-1] 
		+ model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		+ model->transitions[TTT];
	    if (cursc > max) max = cursc;

	    /* Rx(x-) */
	    if (j == 0) 
	      cursc = mx[dpRx][0][dx-1][l][dy] 
		+ model->emissions[eSS((int)seqX->dseq[j])]
		+ model->transitions[TTRX];
	    else 
	      cursc = mx[dpRx][j-1][dx-1][l][dy] 
		+ model->emissions[eSS((int)seqX->dseq[j])]
		+ model->transitions[TTRX];
	    if (cursc > max) max = cursc;

	    /* Ry(-y) */
	    if (l == 0) 
	      cursc = mx[dpRy][j][dx][0][dy-1] 
		+ model->emissions[eSS((int)seqY->dseq[l])]
		+ model->transitions[TTRY];
	    else 
	      cursc = mx[dpRy][j][dx][l-1][dy-1] 
		+ model->emissions[eSS((int)seqY->dseq[l])]
		+ model->transitions[TTRY];
	    if (cursc > max) max = cursc;

	    /* (xy)P(x'y') */
	    if ((l > 0) && (j > 0) && (dx > 1) && (dy > 1)) 
	      cursc = mx[mP][j-1][dx-2][l-1][dy-2]
		+ model->emissions[ePR(idx(seqX->dseq[i],seqX->dseq[j]),
		    idx(seqY->dseq[k],seqY->dseq[l]))] 
		+ model->transitions[TTP];
	    else 
	      cursc = -BIGINT;
	    if (cursc > max) max = cursc;

	    /* T (xy)P(x'y') */
	    for (a = i+1; a < (j-1); a++) {
	      for (b = k+1; b < (l-1); b++) {
		cursc = mx[mP][j-1][dist(a+1,j-1)][l-1][dist(b+1, l-1)] 
		  + mx[dpT][a-1][dist(i,a-1)][b-1][dist(k,b-1)] 
		  + model->emissions[ePR(
		      idx(seqX->dseq[a], seqX->dseq[j]),
		      idx(seqY->dseq[b], seqY->dseq[l]))]
		  + model->transitions[TTB];
		if (cursc > max) max = cursc;
	      }
	    }
	    mx[dpT][j][dx][l][dy] = max;
	  }

	  /********/

	  /* S -> (xy)S | (x-)Lx | (-y)Ly | T | end */
	  if ((dx == 0) && (dy == 0)) {
	    mx[dpS][j][dx][l][dy] = 
	      model->transitions[TSE];
	  } else if (dx == 0) {
	    mx[dpS][j][dx][l][dy] = 
	      mx[dpLy][j][dx][l][dy-1] +
	      model->emissions[eSS((int)seqY->dseq[k])] +
	      model->transitions[TSLY];
	  } else if (dy == 0) {
	    mx[dpS][j][dx][l][dy] = -BIGINT;
	  } else {
	    max = -BIGINT;

	    /* (xy)S */
	    cursc = mx[dpS][j][dx-1][l][dy-1] 
	      + model->emissions[eAL(seqX->dseq[i],seqY->dseq[k])]
	      + model->transitions[TSS];
	    if (cursc > max) max = cursc;

	    /* (x-)Lx */
	    cursc = mx[dpLx][j][dx-1][l][dy] 
	      + model->emissions[eSS((int)seqX->dseq[i])]
	      + model->transitions[TSLX];
	    if (cursc > max) max = cursc;

	    /* (-y)Ly */
	    cursc = mx[dpLy][j][dx][l][dy-1] 
	      + model->emissions[eSS((int)seqY->dseq[k])]
	      + model->transitions[TSLY];
	    if (cursc > max) max = cursc;

	    /* T */
	    cursc = mx[dpT][j][dx][l][dy] + model->transitions[TST];
	    if (cursc > max) max = cursc;

	    mx[dpS][j][dx][l][dy] = max;
	  }

	  /********/

	  /* Lx -> (xy)S | (x-)Lx | T | end */
	  if ((dx == 0) && (dy == 0)) {
	    mx[dpLx][j][dx][l][dy] = 
	      model->transitions[TLXE];
	  } else if (dx == 0) {
	    mx[dpLx][j][dx][l][dy] = -BIGINT;
	  } else if (dy == 0) {
	    mx[dpLx][j][dx][l][dy] = 
	      mx[dpLx][j][dx-1][l][dy] +
	      model->emissions[eSS((int)seqX->dseq[i])] +
	      model->transitions[TLXX];
	  } else {
	    max = -BIGINT;

	    /* (xy)S */
	    cursc = mx[dpS][j][dx-1][l][dy-1] 
	      + model->emissions[eAL(seqX->dseq[i],seqY->dseq[k])]
	      + model->transitions[TLXS];
	    if (cursc > max) max = cursc;

	    /* (x-)Lx */
	    cursc = mx[dpLx][j][dx-1][l][dy] 
	      + model->emissions[eSS((int)seqX->dseq[i])]
	      + model->transitions[TLXX];
	    if (cursc > max) max = cursc;

	    cursc = mx[dpT][j][dx][l][dy] + model->transitions[TLXT];
	    if (cursc > max) max = cursc;

	    mx[dpLx][j][dx][l][dy] = max;
	  }

	  /********/

	  /* Ly -> (xy)S | (-y)Ly | T | end */
	  if ((dx == 0) && (dy == 0)) {
	    mx[dpLy][j][dx][l][dy] = 
	      model->transitions[TLYE];
	  } else if (dx == 0) {
	    mx[dpLy][j][dx][l][dy] = 
	      mx[dpLy][j][dx][l][dy-1] +
	      model->emissions[eSS((int)seqY->dseq[k])] +
	      model->transitions[TLYY];
	  } else if (dy == 0) {
	    mx[dpLy][j][dx][l][dy] = -BIGINT;
	  } else {
	    max = -BIGINT;

	    /* (xy)S */
	    cursc = mx[dpS][j][dx-1][l][dy-1] 
	      + model->emissions[eAL(seqX->dseq[i],seqY->dseq[k])]
	      + model->transitions[TLYS];
	    if (cursc > max) max = cursc;

	    /* (-y)Ly */
	    cursc = mx[dpLy][j][dx][l][dy-1] 
	      + model->emissions[eSS((int)seqY->dseq[k])]
	      + model->transitions[TLYY];
	    if (cursc > max) max = cursc;

	    cursc = mx[dpT][j][dx][l][dy] + model->transitions[TLYT];
	    if (cursc > max) max = cursc;

	    mx[dpLy][j][dx][l][dy] = max;
	  }

	  /********/

	  /* Rx -> (xy)T | Rx(x-) | (xy)P(x'y') | T (xy)P(x'y') */
	  if ((dx == 0) || (dy == 0)) {
	    mx[dpRx][j][dx][l][dy] = -BIGINT;
	  } else {
	    max = -BIGINT;

	    /* T(xy) */
	    if ((j == 0) && (l == 0)) 
	      cursc = mx[dpT][0][dx-1][0][dy-1] 
		+ model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		+ model->transitions[TRXT];
	    else if (j == 0) 
	      cursc = mx[dpT][0][dx-1][l-1][dy-1] 
		+ model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		+ model->transitions[TRXT];
	    else if (l == 0) 
	      cursc = mx[dpT][j-1][dx-1][0][dy-1] 
		+ model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		+ model->transitions[TRXT];
	    else 
	      cursc = mx[dpT][j-1][dx-1][l-1][dy-1] 
		+ model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		+ model->transitions[TRXT];
	    if (cursc > max) max = cursc;

	    /* Rx(x-) */
	    if (j == 0) 
	      cursc = mx[dpRx][0][dx-1][l][dy] 
		+ model->emissions[eSS((int)seqX->dseq[j])]
		+ model->transitions[TRXX];
	    else 
	      cursc = mx[dpRx][j-1][dx-1][l][dy] 
		+ model->emissions[eSS((int)seqX->dseq[j])]
		+ model->transitions[TRXX];
	    if (cursc > max) max = cursc;

	    /* (xy)P(x'y') */
	    if ((l > 0) && (j > 0) && (dx > 1) && (dy > 1)) 
	      cursc = mx[mP][j-1][dx-2][l-1][dy-2]
		+ model->emissions[ePR(idx(seqX->dseq[i],seqX->dseq[j]),
		    idx(seqY->dseq[k],seqY->dseq[l]))] 
		+ model->transitions[TRXP];
	    else cursc = -BIGINT;
	    if (cursc > max) max = cursc;

	    /* T (xy)P(x'y') */
	    for (a = i+1; a < (j-1); a++) {
	      for (b = k+1; b < (l-1); b++) {
		cursc = mx[mP][j-1][dist(a+1,j-1)][l-1][dist(b+1, l-1)] 
		  + mx[dpT][a-1][dist(i,a-1)][b-1][dist(k,b-1)] 
		  + model->emissions[ePR(
		      idx(seqX->dseq[a], seqX->dseq[j]),
		      idx(seqY->dseq[b], seqY->dseq[l]))]
		  + model->transitions[TRXB];
		if (cursc > max) max = cursc;
	      }
	    }
	    mx[dpRx][j][dx][l][dy] = max;
	  }

	  /********/

	  /* Ry -> (xy)T | Ry(-y) | (xy)P(x'y') | T (xy)P(x'y') */

	  if ((dx == 0) || (dy == 0)) {
	    mx[dpRy][j][dx][l][dy] = -BIGINT;
	  } else {
	    max = -BIGINT;

	    /* T(xy) */
	    if ((j == 0) && (l == 0)) 
	      cursc= mx[dpT][0][dx-1][0][dy-1] 
		+ model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		+ model->transitions[TRYT];
	    else if (j == 0) 
	      cursc = mx[dpT][0][dx-1][l-1][dy-1] 
		+ model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		+ model->transitions[TRYT];
	    else if (l == 0) 
	      cursc = mx[dpT][j-1][dx-1][0][dy-1] 
		+ model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		+ model->transitions[TRYT];
	    else 
	      cursc = mx[dpT][j-1][dx-1][l-1][dy-1] 
		+ model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		+ model->transitions[TRYT];
	    if (cursc > max) max = cursc;

	    /* Ry(-y) */
	    if (l == 0) 
	      cursc = mx[dpRy][j][dx][0][dy-1] 
		+ model->emissions[eSS((int)seqY->dseq[l])]
		+ model->transitions[TRYY];
	    else 
	      cursc = mx[dpRy][j][dx][l-1][dy-1] 
		+ model->emissions[eSS((int)seqY->dseq[l])]
		+ model->transitions[TRYY];
	    if (cursc > max) max = cursc;

	    /* (xy)P(x'y') */
	    if ((l > 0) && (j > 0) && (dx > 1) && (dy > 1)) 
	      cursc = mx[mP][j-1][dx-2][l-1][dy-2]
		+ model->emissions[ePR(idx(seqX->dseq[i],seqX->dseq[j]),
		    idx(seqY->dseq[k],seqY->dseq[l]))] 
		+ model->transitions[TRYP];
	    else cursc = -BIGINT;
	    if (cursc > max) max = cursc;

	    /* T (xy)P(x'y') */
	    for (a = i+1; a < (j-1); a++) {
	      for (b = k+1; b < (l-1); b++) {
		cursc = mx[mP][j-1][dist(a+1,j-1)][l-1][dist(b+1, l-1)] 
		  + mx[dpT][a-1][dist(i,a-1)][b-1][dist(k,b-1)] 
		  + model->emissions[ePR(
		      idx(seqX->dseq[a], seqX->dseq[j]),
		      idx(seqY->dseq[b], seqY->dseq[l]))]
		  + model->transitions[TRYB];
		if (cursc > max) max = cursc;
	      }
	    }
	    mx[dpRy][j][dx][l][dy] = max;
	  }

	  /********/

	  if (grammar != MNG) {
	    /* N -> (xy)S | (x-)Lx | (-y)Ly | 
	     * T(xy) | Rx(x-) | Ry(-y) | T (xy)P(x'y') */
	    if ((dx == 0) && (dy == 0)) {
	      mx[dpN][j][dx][l][dy] = -BIGINT;
	    } else if (dx == 0) {
	      mx[dpN][j][dx][l][dy] = 
		mx[dpLy][j][dx][l][dy-1] + 
		model->emissions[eSS((int)seqY->dseq[k])] +
		model->transitions[TNLY];
	    } else if (dy == 0) {
	      mx[dpN][j][dx][l][dy] = 
		mx[dpLx][j][dx-1][l][dy] + 
		model->emissions[eSS((int)seqX->dseq[i])] +
		model->transitions[TNLX];
	    } else {
	      max = -BIGINT;
	      /* (xy)S */
	      cursc = mx[dpS][j][dx-1][l][dy-1] 
		+ model->emissions[eAL(seqX->dseq[i],seqY->dseq[k])]
		+ model->transitions[TNS];
	      if (cursc > max) max = cursc;

	      /* (x-)Lx */
	      cursc = mx[dpLx][j][dx-1][l][dy] 
		+ model->emissions[eSS((int)seqX->dseq[i])]
		+ model->transitions[TNLX];
	      if (cursc > max) max = cursc;

	      /* (-y)Ly */
	      cursc = mx[dpLy][j][dx][l][dy-1] 
		+ model->emissions[eSS((int)seqY->dseq[k])]
		+ model->transitions[TNLY];
	      if (cursc > max) max = cursc;

	      /* T(xy) */
	      if ((j == 0) && (l == 0)) 
		cursc = mx[dpT][0][dx-1][0][dy-1] 
		  + model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		  + model->transitions[TNT];
	      else if (j == 0) 
		cursc = mx[dpT][0][dx-1][l-1][dy-1] 
		  + model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		  + model->transitions[TNT];
	      else if (l == 0) 
		cursc = mx[dpT][j-1][dx-1][0][dy-1] 
		  + model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		  + model->transitions[TNT];
	      else 
		cursc = mx[dpT][j-1][dx-1][l-1][dy-1] 
		  + model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
		  + model->transitions[TNT];
	      if (cursc > max) max = cursc;

	      /* Rx(x-) */
	      if (j == 0) 
		cursc = mx[dpRx][0][dx-1][l][dy] 
		  + model->emissions[eSS((int)seqX->dseq[j])]
		  + model->transitions[TNRX];
	      else 
		cursc = mx[dpRx][j-1][dx-1][l][dy] 
		  + model->emissions[eSS((int)seqX->dseq[j])]
		  + model->transitions[TNRX];
	      if (cursc > max) max = cursc;

	      /* Ry(-y) */
	      if (l == 0) 
		cursc = mx[dpRy][j][dx][0][dy-1] 
		  + model->emissions[eSS((int)seqY->dseq[l])]
		  + model->transitions[TNRY];
	      else 
		cursc = mx[dpRy][j][dx][l-1][dy-1] 
		  + model->emissions[eSS((int)seqY->dseq[l])]
		  + model->transitions[TNRY];
	      if (cursc > max) max = cursc;

	      /* T (xy)P(x'y') */
	      for (a = i+1; a < (j-1); a++) {
		for (b = k+1; b < (l-1); b++) {
		  cursc = mx[mP][j-1][dist(a+1,j-1)][l-1][dist(b+1, l-1)] 
		    + mx[dpT][a-1][dist(i,a-1)][b-1][dist(k,b-1)] 
		    + model->emissions[ePR(
			idx(seqX->dseq[a], seqX->dseq[j]),
			idx(seqY->dseq[b], seqY->dseq[l]))]
		    + model->transitions[TNB];
		  if (cursc > max) max = cursc;
		}
	      }
	      mx[dpN][j][dx][l][dy] = max;
	    }

	    /* P -> (xy)P(x'y') | (xy)N(x'y') */
	    if ((dx == 0) && (dy == 0)) {
	      mx[dpP][j][dx][l][dy] = -BIGINT;
	    } else if (dx == 0) {
	      mx[dpP][j][dx][l][dy] = 
		mx[dpN][j][dx][l][dy] + 
		model->transitions[TPN];
	    } else if (dy == 0) {
	      mx[dpP][j][dx][l][dy] = 
		mx[dpN][j][dx][l][dy] + 
		model->transitions[TPN];
	    } else {

	      max = -BIGINT; stackvalue = -BIGINT;
	      /* Can't stack at edges */
	      if ((i > 0) && (k > 0) && (j < Xlen-1) && (l < Ylen-1) &&
		  (dx > HLEN+1) && (dy > HLEN+1)) {
		stackvalue = 
		  model->emissions[ePRN(
		      seqX->dseq[i],seqX->dseq[j],\
		      seqY->dseq[k],seqY->dseq[l])];
	      } else { stackvalue = -BIGINT; }

	      if ((l > 0) && (j > 0) && (dx > 1) && (dy > 1))
		cursc = mx[dpP][j-1][dx-2][l-1][dy-2] 
		  + model->transitions[TPP] + stackvalue;
	      else cursc = -BIGINT;
	      if (cursc > max) max = cursc;

	      /* N */
	      cursc = mx[dpN][j][dx][l][dy] + model->transitions[TPN];
	      if (cursc > max) max = cursc;
	      mx[dpP][j][dx][l][dy] = max;
	    }
	  }
	}
      }
    }
  }
  fflush(stdout);
}


/* Function: cykTraceSTA
 * Date:     Sun Feb 16 19:16:04 CST 2003 [St Louis]
 *
 * Purpose:  Build traceback tree for full STA grammar 
 * Assumption: Fill matrix already allocated and filled
 *
 * Args:
 * 	seqX	first sequence
 * 	seqY	second sequence
 * 	model	parameter and grammar info
 * 	grammar	Good for STA or ST2
 * 	mx	fill matrix
 *
 * Returns: traceback tree
 */
  struct trace_s *
cykTraceSTA(SEQUENCE *seqX, SEQUENCE *seqY, INTMOD *model, int grammar, int *****mx)
{
  struct trace_s *parsetree;     /* Head of parse tree */
  struct trace_s *curr;          /* Current node in parse tree */
  struct tracestack_s *stack;    /* Stack for doing traceback */
  int i, j, dx, a;	/* Sequence x indicies */
  int k, l, dy, b;	/* Sequence y indicies */
  int mtx, mP;
  int Xlen, Ylen;

  int debug = FALSE;	/* Turns on exterme debugging output */

  Xlen = seqX->len;
  Ylen = seqY->len;

  if (grammar == MNG) mP = dpS;
  else mP = dpP;

  /* Initialization of Traceback stuff */
  parsetree = InitTrace();
  stack = InitTracestack();

  /* Push initialization elements onto stack */
  PushTracestack(stack, 
      AttachTrace (parsetree, dpS, 0, (Xlen-1), 0, (Ylen-1), NTRANS));

  /* Repeat until stack is empty */
  while ((curr = PopTracestack(stack))) {
    /* Set indicies from item in stack */
    mtx = curr->nonterminal; 
    i = curr->emitLx; j = curr->emitRx; 
    k = curr->emitLy; l = curr->emitRy; 
    dx = j - i + 1; dy = l - k + 1;

    /*
       if (debug) printf("%s %d %d %d; %d %d %d\n", dpNAME[Gtype[STA]][mtx], 
       i, j, dx, k, l, dy);
       */

    switch (mtx) {
      case dpS: 
	if ((i > j) && (k > l)) {	/* End of both sequences */
	  curr->emitLx = -1; curr->emitRx = -1; 
	  curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TSE;
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpS  %5d  %5d  %5d  %5d  TSE %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (i > j) {		/* Ran out of X, more Y exists */
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	  curr->transition = TSLY;
	  PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpS  %5d  %5d  %5d  %5d  TSLY   %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (k > l) {		/* Ran out of Y, more X exists */
	  curr->emitLy = -1; curr->emitRx = -1; curr->emitRy = -1;
	  curr->transition = TSLX;
	  PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpS  %5d  %5d  %5d  %5d  TSLX %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (mx[dpS][j][dx-1][l][dy-1] 
	    + model->emissions[eAL(seqX->dseq[i],seqY->dseq[k])]
	    + model->transitions[TSS] == mx[dpS][j][dx][l][dy]) {
	  curr->emitRx = -1; curr->emitRy = -1;
	  curr->transition = TSS;
	  PushTracestack(stack, AttachTrace(curr, dpS, i+1, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpS  %5d  %5d  %5d  %5d  TSS  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (mx[dpLx][j][dx-1][l][dy] 
	    + model->emissions[eSS((int)seqX->dseq[i])] 
	    + model->transitions[TSLX] == mx[dpS][j][dx][l][dy]) {
	  curr->emitLy = -1; curr->emitRx = -1; curr->emitRy = -1;
	  curr->transition = TSLX;
	  PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpS  %5d  %5d  %5d  %5d  TSLX %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (mx[dpLy][j][dx][l][dy-1] 
	    + model->emissions[eSS((int)seqY->dseq[k])] 
	    + model->transitions[TSLY] == mx[dpS][j][dx][l][dy]) {
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	  curr->transition = TSLY;
	  PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpS  %5d  %5d  %5d  %5d  TSLY %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else {
	  /* if (mx[dpT][j][dx][l][dy] 
	     + model->transitions[TSS] == mx[dpS][j][dx][l][dy])  */
	  curr->emitLx = -1; curr->emitRx = -1; 
	  curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TST;
	  PushTracestack(stack, AttachTrace(curr, dpT, i, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpS  %5d  %5d  %5d  %5d  TST  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} 
	break;
      case dpP:
	if ((i > j) && (k > l)) {
	  printf("\nSHIT: Bad transition in dpP\n");
	} else if ((dx > 1) && (dy > 1) && 
	    (mx[dpP][j-1][dx-2][l-1][dy-2] + model->transitions[TPP]
	     + model->emissions[
	     ePRN(seqX->dseq[i],seqX->dseq[j],\
	       seqY->dseq[k],seqY->dseq[l])]
	     == mx[dpP][j][dx][l][dy])) {
	  curr->transition = TPP;
	  PushTracestack(stack, AttachTrace(curr, 
		dpP, i+1, j-1, k+1, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpP  %5d  %5d  %5d  %5d  TPP  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else {
	  curr->transition = TPN;
	  curr->emitLx = -1; curr->emitLy = -1;
	  curr->emitRx = -1; curr->emitRy = -1;
	  PushTracestack(stack, AttachTrace(curr, dpN, i, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpP  %5d  %5d  %5d  %5d  TPN   %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	}
	break;
      case dpN:
	if ((i > j) && (k > l)) {
	  printf("\nSHIT: Bad transition in dpN\n");
	} else if (i > j) {		/* Ran out of X, more Y exists */
	  curr->transition = TNLY;
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	  PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNLY  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (k > l) {		/* Ran out of Y, more X exists */
	  curr->emitRx = -1; curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TNLX;
	  PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNLX  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (mx[dpT][j-1][dx-1][l-1][dy-1]
	    + model->emissions[eAL(seqX->dseq[j],seqY->dseq[l])]
	    + model->transitions[TNT] == mx[dpN][j][dx][l][dy]) {
	  curr->emitLx = -1; curr->emitLy = -1; curr->transition = TNT;
	  PushTracestack(stack, AttachTrace(curr, dpT, i, j-1, k, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNT  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (mx[dpRx][j-1][dx-1][l][dy] + 
	    model->emissions[eSS((int)seqX->dseq[j])] + 
	    model->transitions[TNRX] == mx[dpN][j][dx][l][dy]) {
	  curr->emitLx = -1; curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TNRX;
	  PushTracestack(stack, AttachTrace(curr, dpRx, i, j-1, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNRX  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (mx[dpRy][j][dx][l-1][dy-1] + 
	    model->emissions[eSS((int)seqY->dseq[l])] + 
	    model->transitions[TNRY] == mx[dpN][j][dx][l][dy]) {
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1;
	  curr->transition = TNRY;
	  PushTracestack(stack, AttachTrace(curr, dpRy, i, j, k, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNRY  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (mx[dpS][j][dx-1][l][dy-1] + model->transitions[TNS]
	    + model->emissions[eAL(seqX->dseq[i],seqY->dseq[k])] 
	    == mx[dpN][j][dx][l][dy]) {
	  curr->emitRx = -1; curr->emitRy = -1; curr->transition = TNS;
	  PushTracestack(stack, AttachTrace(curr, dpS, i+1, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNS  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (mx[dpLx][j][dx-1][l][dy] + model->transitions[TNLX]
	    + model->emissions[eSS((int)seqX->dseq[i])] 
	    == mx[dpN][j][dx][l][dy]) {
	  curr->emitRx = -1; curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TNLX;
	  PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNLX  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (mx[dpLy][j][dx][l][dy-1] + model->transitions[TNLY]
	    + model->emissions[eSS((int)seqY->dseq[k])] 
	    == mx[dpN][j][dx][l][dy]) {
	  curr->transition = TNLY;
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	  PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpN  %5d  %5d  %5d  %5d  TNLY  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	  /* We want to do this state last so we minimize the number of
	   * times we're doing this internal loop */
	} else {
	  if (debug) printf("Check bif in N\n");
	  for (a = i+1; a < (j-1); a++) {
	    for (b = k+1; b < (l-1); b++) {
	      if (mx[dpP][j-1][dist(a+1,j-1)][l-1][dist(b+1, l-1)] 
		  + mx[dpT][a-1][dist(i,a-1)][b-1][dist(k,b-1)] 
		  + model->emissions[ePR(idx(seqX->dseq[a], seqX->dseq[j]),
		    idx(seqY->dseq[b], seqY->dseq[l]))] 
		  + model->transitions[TNB] == mx[dpN][j][dx][l][dy]) {
		curr->emitLx = a; curr->emitLy = b; 
		curr->transition = TNB;
		PushTracestack(stack, 
		    AttachTrace(curr, dpP, a+1, j-1, b+1, l-1, NTRANS));
		PushTracestack(stack, 
		    AttachTrace(curr, dpT, i, a-1, k, b-1, NTRANS));
		if (debug) {
		  fprintf(stdout, 
		      "(%#12x) dpN  %5d  %5d  %5d  %5d  TNB  %#10x  %#10x \n", 
		      (int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		      curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
		}
		b = l; a = j;        /* Short circuit */
	      }
	    }
	  }

	}
	break;
      case dpT:
	if ((i > j) || (k > l)) {
	  printf("\nSHIT: Bad transition in dpT\n");
	} else if (mx[dpT][j-1][dx-1][l-1][dy-1] 
	    + model->emissions[eAL(seqX->dseq[j], seqY->dseq[l])]
	    + model->transitions[TTT] == mx[dpT][j][dx][l][dy]) {
	  curr->emitLx = -1; curr->emitLy = -1;
	  curr->transition = TTT;
	  PushTracestack(stack, AttachTrace(curr, dpT, i, j-1, k, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpT  %5d  %5d  %5d  %5d  TTT  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (mx[dpRx][j-1][dx-1][l][dy] + 
	    model->emissions[eSS((int)seqX->dseq[j])]
	    + model->transitions[TTRX] == mx[dpT][j][dx][l][dy]) {
	  curr->emitLx = -1; curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TTRX;
	  PushTracestack(stack, AttachTrace(curr, dpRx, i, j-1, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpT  %5d  %5d  %5d  %5d  TTRX  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (mx[dpRy][j][dx][l-1][dy-1] + 
	    model->emissions[eSS((int)seqY->dseq[l])]
	    + model->transitions[TTRY] == mx[dpT][j][dx][l][dy])  {
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1;
	  curr->transition = TTRY;
	  PushTracestack(stack, AttachTrace(curr, dpRy, i, j, k, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpT  %5d  %5d  %5d  %5d  TTRY  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if ((dx > 1) && (dy > 1) && 
	    (mx[mP][j-1][dx-2][l-1][dy-2] 
	     + model->emissions[ePR(idx(seqX->dseq[i],seqX->dseq[j]),
	       			idx(seqY->dseq[k],seqY->dseq[l]))] 
	     + model->transitions[TTP] == mx[dpT][j][dx][l][dy])) {
	  curr->transition = TTP;
	  PushTracestack(stack, 
	      AttachTrace(curr, mP, i+1, j-1, k+1, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpT  %5d  %5d  %5d  %5d  TTP   %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else {
	  for (a = i+1; a < (j-1); a++) {
	    for (b = k+1; b < (l-1); b++) {
	      if (mx[mP][j-1][dist(a+1,j-1)][l-1][dist(b+1, l-1)] 
		  + mx[dpT][a-1][dist(i,a-1)][b-1][dist(k,b-1)] 
		  + model->emissions[ePR(idx(seqX->dseq[a], seqX->dseq[j]),
		    idx(seqY->dseq[b], seqY->dseq[l]))] 
		  + model->transitions[TTB] == mx[dpT][j][dx][l][dy]) {
		curr->emitLx = a; curr->emitLy = b; 
		curr->transition = TTB;
		PushTracestack(stack, 
		    AttachTrace(curr, mP, a+1, j-1, b+1, l-1, NTRANS));
		PushTracestack(stack, 
		    AttachTrace(curr, dpT, i, a-1, k, b-1, NTRANS));
		if (debug) {
		  fprintf(stdout, 
		      "(%#12x) dpT  %5d  %5d  %5d  %5d  TTB   %#10x  %#10x \n", 
		      (int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		      curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
		}
		b = l; a = j;        /* Short circuit */
	      }
	    }
	  }
	}
	break;
      case dpLx: 
	if ((i > j) && (k > l)) {
	  curr->emitLy = -1; curr->emitRx = -1; 
	  curr->emitLx = -1; curr->emitRy = -1;
	  curr->transition = TLXE;
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLx  %5d  %5d  %5d  %5d  TLXE  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }

	} else if (i > j) {		/* Ran out of X, must end */
	  printf("Shit! Bad Transition! dpLx\n");
	} else if (k > l) {
	  curr->emitRx = -1; curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TLXX;
	  PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLx  %5d  %5d  %5d  %5d  TLXX  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (mx[dpLx][j][dx-1][l][dy] + model->transitions[TLXX]
	    + model->emissions[eSS((int)seqX->dseq[i])] 
	    == mx[dpLx][j][dx][l][dy]) {
	  curr->emitRx = -1; curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TLXX;
	  PushTracestack(stack, AttachTrace(curr, dpLx, i+1, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLx  %5d  %5d  %5d  %5d  TLXX  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (mx[dpS][j][dx-1][l][dy-1] + model->transitions[TLXS]
	    + model->emissions[eAL(seqX->dseq[i],seqY->dseq[k])] 
	    == mx[dpLx][j][dx][l][dy]) {
	  curr->emitRx = -1; curr->emitRy = -1; curr->transition = TLXS;
	  PushTracestack(stack, AttachTrace(curr, dpS, i+1, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLx  %5d  %5d  %5d  %5d  TLXS  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else {
	  /* if (mx[dpT][j][dx][l][dy] 
	     + model->transitions[TLXT] == mx[dpLx][j][dx][l][dy])  */
	  curr->emitLx = -1; curr->emitRx = -1; 
	  curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TLXT;
	  PushTracestack(stack, AttachTrace(curr, dpT, i, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLx  %5d  %5d  %5d  %5d  TLXT  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	}
	break;
      case dpLy: 
	if ((i > j) && (k > l)) {
	  curr->emitLy = -1; curr->emitRx = -1; 
	  curr->emitLx = -1; curr->emitRy = -1;
	  curr->transition = TLYE;
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLy  %5d  %5d  %5d  %5d  TLYE  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (k > l) {		/* Ran out of Y, must end */
	  printf("Shit! Bad Transition! dpLx\n");
	} else if (i > j) {
	  curr->transition = TLYY;
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	  PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLy  %5d  %5d  %5d  %5d  TLYY  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }

	} else if (mx[dpLy][j][dx][l][dy-1] + model->transitions[TLYY]
	    + model->emissions[eSS((int)seqY->dseq[k])] 
	    == mx[dpLy][j][dx][l][dy]) {
	  curr->transition = TLYY;
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitRy = -1;
	  PushTracestack(stack, AttachTrace(curr, dpLy, i, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLy  %5d  %5d  %5d  %5d  TLYY  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (i > j ) {
	  /* If at this point we're done in X we've got a problem */
	  printf("\nSHIT: Bad transition in dpLy 2\n");
	} else if (mx[dpS][j][dx-1][l][dy-1] + model->transitions[TLYS]
	    + model->emissions[eAL(seqX->dseq[i],seqY->dseq[k])] 
	    == mx[dpLy][j][dx][l][dy]) {
	  curr->emitRx = -1; curr->emitRy = -1; curr->transition = TLYS;
	  PushTracestack(stack, AttachTrace(curr, dpS, i+1, j, k+1, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLy  %5d  %5d  %5d  %5d  TLYS  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }

	} else {
	  /* if (mx[dpT][j][dx][l][dy] 
	     + model->transitions[TLYT] == mx[dpLy][j][dx][l][dy])  */
	  curr->emitLx = -1; curr->emitRx = -1; 
	  curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TLYT;
	  PushTracestack(stack, AttachTrace(curr, dpT, i, j, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpLy  %5d  %5d  %5d  %5d  TLYT  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	}
	break;
      case dpRx: 
	if ((i > j) || (k > l)) {
	  printf("\nSHIT: Bad transition in dpRx\n");
	} else if (mx[dpT][j-1][dx-1][l-1][dy-1] 
	    + model->emissions[eAL(seqX->dseq[j], seqY->dseq[l])]
	    + model->transitions[TRXT] == mx[dpRx][j][dx][l][dy]) {
	  curr->emitLx = -1; curr->emitLy = -1;
	  curr->transition = TRXT;
	  PushTracestack(stack, AttachTrace(curr, dpT, i, j-1, k, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpRx %5d  %5d  %5d  %5d  TRXT  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (mx[dpRx][j-1][dx-1][l][dy] 
	    + model->emissions[eSS((int)seqX->dseq[j])]
	    + model->transitions[TRXX] == mx[dpRx][j][dx][l][dy]) {
	  curr->emitLx = -1; curr->emitLy = -1; curr->emitRy = -1;
	  curr->transition = TRXX;
	  PushTracestack(stack, AttachTrace(curr, dpRx, i, j-1, k, l, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpRx  %5d  %5d  %5d  %5d  TRXX  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if ((dx > 1) && (dy > 1) && (mx[mP][j-1][dx-2][l-1][dy-2] 
	      + model->emissions[ePR(idx(seqX->dseq[i],seqX->dseq[j]),
				idx(seqY->dseq[k],seqY->dseq[l]))] 
	      + model->transitions[TRXP] == mx[dpRx][j][dx][l][dy])) {
	  curr->transition = TRXP;
	  PushTracestack(stack, 
	      AttachTrace(curr, mP, i+1, j-1, k+1, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpRx  %5d  %5d  %5d  %5d  TRXP  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else {
	  if (debug) printf("Check bif \n");
	  for (a = i+1; a < (j-1); a++) {
	    for (b = k+1; b < (l-1); b++) {
	      if (mx[mP][j-1][dist(a+1,j-1)][l-1][dist(b+1, l-1)] 
		  + mx[dpT][a-1][dist(i,a-1)][b-1][dist(k,b-1)] 
		  + model->emissions[ePR(idx(seqX->dseq[a], seqX->dseq[j]),
		    idx(seqY->dseq[b], seqY->dseq[l]))] 
		  + model->transitions[TRXB] == mx[dpRx][j][dx][l][dy]) {
		curr->emitLx = a; curr->emitLy = b;
		curr->transition = TRXB;
		PushTracestack(stack, 
		    AttachTrace(curr, mP, a+1, j-1, b+1, l-1, NTRANS));
		PushTracestack(stack, 
		    AttachTrace(curr, dpT, i, a-1, k, b-1, NTRANS));
		if (debug) {
		  fprintf(stdout, 
		     "(%#12x) dpRx  %5d  %5d  %5d  %5d  TRXB  %#10x  %#10x \n", 
		     (int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		     curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
		}
		b = l; a = j;        /* Short circuit */
	      }
	    }
	  }
	}
	break;
      case dpRy: 
	if ((i > j) || (k > l)) {
	  printf("\nSHIT: Bad transition in dpRy\n");
	} else if (mx[dpT][j-1][dx-1][l-1][dy-1] 
	    + model->emissions[eAL(seqX->dseq[j], seqY->dseq[l])]
	    + model->transitions[TRYT] == mx[dpRy][j][dx][l][dy]) {
	  curr->emitLx = -1; curr->emitLy = -1;
	  curr->transition = TRYT;
	  PushTracestack(stack, AttachTrace(curr, dpT, i, j-1, k, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpRy  %5d  %5d  %5d  %5d  TRYT  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if (mx[dpRy][j][dx][l-1][dy-1] 
	    + model->emissions[eSS((int)seqY->dseq[l])]
	    + model->transitions[TRYY] == mx[dpRy][j][dx][l][dy])  {
	  curr->emitLx = -1; curr->emitRx = -1; curr->emitLy = -1;
	  curr->transition = TRYY;
	  PushTracestack(stack, AttachTrace(curr, dpRy, i, j, k, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpRy  %5d  %5d  %5d  %5d  TRYY  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else if ((dx > 1) && (dy > 1) && 
	    (mx[mP][j-1][dx-2][l-1][dy-2] 
	     + model->emissions[ePR(idx(seqX->dseq[i],seqX->dseq[j]),
	       			idx(seqY->dseq[k],seqY->dseq[l]))] 
	     + model->transitions[TRYP] == mx[dpRy][j][dx][l][dy])) {
	  curr->transition = TRYP;
	  PushTracestack(stack, 
	      AttachTrace(curr, mP, i+1, j-1, k+1, l-1, NTRANS));
	  if (debug) {
	    fprintf(stdout, 
		"(%#12x) dpRy  %5d  %5d  %5d  %5d  TRYP  %#10x  %#10x \n", 
		(int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
	  }
	} else {
	  for (a = i+1; a < (j-1); a++) {
	    for (b = k+1; b < (l-1); b++) {
	      if (mx[mP][j-1][dist(a+1,j-1)][l-1][dist(b+1, l-1)] 
		  + mx[dpT][a-1][dist(i,a-1)][b-1][dist(k,b-1)] 
		  + model->emissions[ePR(idx(seqX->dseq[a], seqX->dseq[j]),
		    idx(seqY->dseq[b], seqY->dseq[l]))] 
		  + model->transitions[TRYB] == mx[dpRy][j][dx][l][dy]) {
		curr->emitLx = a; curr->emitLy = b; 
		curr->transition = TRYB;
		PushTracestack(stack, 
		    AttachTrace(curr, mP, a+1, j-1, b+1, l-1, NTRANS));
		PushTracestack(stack, 
		    AttachTrace(curr, dpT, i, a-1, k, b-1, NTRANS));
		if (debug) {
		  fprintf(stdout, 
		     "(%#12x) dpRy  %5d  %5d  %5d  %5d  TRYB  %#10x  %#10x \n", 
		     (int) curr, curr->emitLx, curr->emitRx, curr->emitLy, 
		     curr->emitRy, (int) curr->nxtl, (int) curr->nxtr);
		}
		b = l; a = j;        /* Short circuit */
	      }
	    }
	  }
	}
	break;
      default: 
	break;
    }
  } /* end while stack not empty*/
  FreeTracestack(stack);
  return parsetree;
}

/***************************** TRAIN ********************************/
/* Function: khs2traceMNG
 * Date:     RDD, Tue Jul 15 17:18:33 CDT 2003 [St Louis]
 *
 * Purpose: Convert KHS to traceback tree properly 
 * 	labeled for MNG grammar.
 *
 * Args:     
 *	dolist  Traceback tree to build from KHS	
 *	ct	KHS info represented as ct format
 *	Xseq	ALIGNED sequence X
 *	Yseq	ALIGNED sequence Y
 *
 * Note: Xseq and Yseq may contain gaps and must be of the same length
 * 		(same length as ct)
 *
 * Returns: FALSE if error encountered
 * 	TRUE otherwise
 *  ** traceback tree in unaligned coordinates **
 */
  int
khs2traceMNG(struct tracestack_s *dolist, int *ct, char *Xseq, char *Yseq)
{
  struct trace_s      *cur;
  int ai, aj;
  int i, j, a, k, l, b;

  while ((cur = PopTracestack(dolist)) != NULL) {
    ai = cur->emitl;           /* 0..len-1 */
    aj = cur->emitr;           /* 0..len-1 */
    i = cur->emitLx; j = cur->emitRx;
    k = cur->emitLy; l = cur->emitRy;

    if (ai > aj) {	/* no more alignment */
      if (cur->nonterminal == dpS) cur->transition = TSE; 
      else if (cur->nonterminal == dpLx) cur->transition = TLXE;
      else /* dpLy */ cur->transition = TLYE; 
      cur->emitLx = -1; cur->emitLy = -1; cur->emitRx = -1; cur->emitRy = -1;
    } else if (ct[ai] == -1) {	/* ai unpaired; single stranded left */
      if (cur->nonterminal == dpS) {
	if (isgap(Xseq[ai])) {        /* seq X is gap so must be in Ly */
	  cur->transition = TSLY;
	  cur->emitLx = -1; cur->emitRx = -1; cur->emitRy = -1;
	  PushTracestack(dolist, 
	      AttachATrace(cur, dpLy, ai+1, aj, i, j, k+1, l, NTRANS));
	} else if (isgap(Yseq[ai])) { /* seq Y is gap so must be in Lx */
	  cur->transition = TSLX;
	  cur->emitLy = -1; cur->emitRx = -1; cur->emitRy = -1;
	  PushTracestack(dolist, 
	      AttachATrace(cur, dpLx, ai+1, aj, i+1, j, k, l, NTRANS));
	} else {                      /* TSS */
	  cur->transition = TSS;
	  cur->emitRx = -1; cur->emitRy = -1;
	  PushTracestack(dolist, 
	      AttachATrace(cur, dpS, ai+1, aj, i+1, j, k+1, l, NTRANS));
	}
      } else if (cur->nonterminal == dpLx) {
	if (isgap(Yseq[ai])) {        /* TLXX */
	  cur->transition = TLXX;
	  cur->emitLy = -1; cur->emitRx = -1; cur->emitRy = -1;
	  PushTracestack(dolist, 
	      AttachATrace(cur, dpLx, ai+1, aj, i+1, j, k, l, NTRANS));
	} else {                      /* TLXS */
	  cur->transition = TLXS;
	  cur->emitRx = -1; cur->emitRy = -1;
	  PushTracestack(dolist, 
	      AttachATrace(cur, dpS, ai+1, aj, i+1, j, k+1, l, NTRANS));
	}
      } else { /* dpLy */
	if (isgap(Xseq[ai])) {        /* TLYY */
	  cur->transition = TLYY;
	  cur->emitLx = -1; cur->emitRx = -1; cur->emitRy = -1;
	  PushTracestack(dolist, 
	      AttachATrace(cur, dpLy, ai+1, aj, i, j, k+1, l, NTRANS));
	} else {                      /* TLYM */
	  cur->transition = TLYS;
	  cur->emitRx = -1; cur->emitRy = -1;
	  PushTracestack(dolist, 
	      AttachATrace(cur, dpS, ai+1, aj, i+1, j, k+1, l, NTRANS));
	}
      }
    } else if (ct[aj] == -1) {	/* aj unpaired; single stranded right */
      if (isLstate(cur->nonterminal)) {
	if (cur->nonterminal == dpS) cur->transition = TST;
	else if (cur->nonterminal == dpLx) cur->transition = TLXT;
	else /* dpLy */ cur->transition = TLYT;
	cur->emitLx = -1; cur->emitRx = -1; 
	cur->emitLy = -1; cur->emitRy = -1;
	PushTracestack(dolist, 
	    AttachATrace(cur, dpT, ai, aj, i, j, k, l, NTRANS));
      } else {	/* isRstate */
	if (cur->nonterminal == dpT) {
	  if (isgap(Xseq[aj])) {        /* seq X is gap so must be in Ry */
	    cur->transition = TTRY;
	    cur->emitLx = -1; cur->emitLy = -1; cur->emitRx = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpRy, ai, aj-1, i, j, k, l-1, NTRANS));
	  } else if (isgap(Yseq[aj])) { /* seq Y is gap so must be in Rx */
	    cur->transition = TTRX;
	    cur->emitLx = -1; cur->emitLy = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpRx, ai, aj-1, i, j-1, k, l, NTRANS));
	  } else {                      /* TTT */
	    cur->transition = TTT;
	    cur->emitLx = -1; cur->emitLy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpT, ai, aj-1, i, j-1, k, l-1, NTRANS));
	  }
	} else if (cur->nonterminal == dpRx) {
	  if (isgap(Yseq[aj])) {        /* TRXX */
	    cur->transition = TRXX;
	    cur->emitLx = -1; cur->emitLy = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpRx, ai, aj-1, i, j-1, k, l, NTRANS));
	  } else {                      /* TRXT */
	    cur->transition = TRXT;
	    cur->emitLx = -1; cur->emitLy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpT, ai, aj-1, i, j-1, k, l-1, NTRANS));
	  }
	} else { /* dpRy */
	  if (isgap(Xseq[aj])) {        /* TRYY */
	    cur->transition = TRYY;
	    cur->emitLx = -1; cur->emitLy = -1; cur->emitRx = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpRy, ai, aj-1, i, j, k, l-1, NTRANS));
	  } else {                      /* TRYM */
	    cur->transition = TRYT;
	    cur->emitLx = -1; cur->emitLy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpT, ai, aj-1, i, j-1, k, l-1, NTRANS));
	  }
	}
      }
    } else if (ct[ai] == aj) {	/* ai pairs to aj */
      if (isLstate(cur->nonterminal)) {
	if (cur->nonterminal == dpS) cur->transition = TST;
	else if (cur->nonterminal == dpLx) cur->transition = TLXT;
	else /* dpLy */ cur->transition = TLYT;
	cur->emitLx = -1; cur->emitRx = -1; 
	cur->emitLy = -1; cur->emitRy = -1;
	PushTracestack(dolist, 
	    AttachATrace(cur, dpT, ai, aj, i, j, k, l, NTRANS));
      } else {	/* isRstate */
	if (cur->nonterminal == dpT) cur->transition = TTS;
	else if (cur->nonterminal == dpRx) cur->transition = TRXS;
	else /* dpRy */ cur->transition = TRYS;
	PushTracestack(dolist, 
	    AttachATrace(cur, dpS, ai+1, aj-1, i+1, j-1, k+1, l-1, NTRANS));
      }
    } else {	/* ai, aj paired but not to each other */
      if (isLstate(cur->nonterminal)) {
	if (cur->nonterminal == dpS) cur->transition = TST;
	else if (cur->nonterminal == dpLx) cur->transition = TLXT;
	else /* dpLy */ cur->transition = TLYT;
	cur->emitLx = -1; cur->emitRx = -1; 
	cur->emitLy = -1; cur->emitRy = -1;
	PushTracestack(dolist,
	    AttachATrace(cur, dpT, ai, aj, i, j, k, l, NTRANS));
      } else { /* isRstate */
	if (cur->nonterminal == dpT) {
	  cur->transition = TTB;
	  a = dealignedCoord(Xseq, ai, ct[aj]-1, i);
	  b = dealignedCoord(Yseq, ai, ct[aj]-1, k);
	  cur->emitLx = a+1; cur->emitLy = b+1;
	  PushTracestack(dolist, 
	    AttachATrace(cur, dpS, ct[aj]+1, aj-1, a+2, j-1, b+2, l-1, NTRANS));
	  PushTracestack(dolist, 
	      AttachATrace(cur, dpT, ai, ct[aj]-1, i, a, k, b, NTRANS));
	} else if (cur->nonterminal == dpRx) {
	  cur->transition = TRXB;
	  a = dealignedCoord(Xseq, ai, ct[aj]-1, i);
	  b = dealignedCoord(Yseq, ai, ct[aj]-1, k);
	  cur->emitLx = a+1; cur->emitLy = b+1;
	  PushTracestack(dolist, 
	    AttachATrace(cur, dpS, ct[aj]+1, aj-1, a+2, j-1, b+2, l-1, NTRANS));
	  PushTracestack(dolist, 
	    AttachATrace(cur, dpT, ai, ct[aj]-1, i, a, k, b, NTRANS));
	} else { /* dpRy */
	  cur->transition = TRYB;
	  a = dealignedCoord(Xseq, ai, ct[aj]-1, i);
	  b = dealignedCoord(Yseq, ai, ct[aj]-1, k);
	  cur->emitLx = a+1; cur->emitLy = b+1;
	  PushTracestack(dolist, 
	    AttachATrace(cur, dpS, ct[aj]+1, aj-1, a+2, j-1, b+2, l-1, NTRANS));
	  PushTracestack(dolist, 
	    AttachATrace(cur, dpT, ai, ct[aj]-1, i, a, k, b, NTRANS));
	}
      }
    }
  }   /* while something's on dolist stack */
  return 1;
}


/* Function: khs2traceSTA
 * Date:     RDD, Tue Jul 15 18:29:05 CDT 2003 [St Louis]
 *
 * Purpose: Convert KHS to traceback tree properly 
 * 	labeled for STA grammar.
 *
 * Args:     
 *	dolist  Traceback tree to build from KHS	
 *	ct	KHS info represented as ct format
 *	Xseq	ALIGNED sequence X
 *	Yseq	ALIGNED sequence Y
 *
 * Note: Xseq and Yseq may contain gaps and must be of the same length
 * 		(same length as ct)
 *
 * Returns: FALSE if error encountered
 * 	TRUE otherwise
 *  ** traceback tree in unaligned coordinates **
 */
  int
khs2traceSTA(struct tracestack_s *dolist, int *ct, char *Xseq, char *Yseq)
{
  struct trace_s      *cur;
  int ai, aj;
  int i, j, a, k, l, b;

  while ((cur = PopTracestack(dolist)) != NULL) {
    ai = cur->emitl;           /* 0..len-1 */
    aj = cur->emitr;           /* 0..len-1 */
    i = cur->emitLx; j = cur->emitRx;
    k = cur->emitLy; l = cur->emitRy;

    if (ai > aj) {	/* no more alignment */
      if (cur->nonterminal == dpS) cur->transition = TSE; 
      else if (cur->nonterminal == dpLx) cur->transition = TLXE;
      else /* dpLy */ cur->transition = TLYE; 
      cur->emitLx = -1; cur->emitLy = -1; cur->emitRx = -1; cur->emitRy = -1;
    } else if (ct[ai] == -1) {	/* ai unpaired; single stranded left */
      switch(cur->nonterminal) {
	case dpS:
	  if (isgap(Xseq[ai])) {        /* seq X is gap so must be in Ly */
	    cur->transition = TSLY;
	    cur->emitLx = -1; cur->emitRx = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpLy, ai+1, aj, i, j, k+1, l, NTRANS));
	  } else if (isgap(Yseq[ai])) { /* seq Y is gap so must be in Lx */
	    cur->transition = TSLX;
	    cur->emitLy = -1; cur->emitRx = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpLx, ai+1, aj, i+1, j, k, l, NTRANS));
	  } else {                      /* TSLM */
	    cur->transition = TSS;
	    cur->emitRx = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpS, ai+1, aj, i+1, j, k+1, l, NTRANS));
	  }
	  break;
	case dpLx:
	  if (isgap(Yseq[ai])) {        /* TLXX */
	    cur->transition = TLXX;
	    cur->emitLy = -1; cur->emitRx = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpLx, ai+1, aj, i+1, j, k, l, NTRANS));
	  } else {                      /* TLXS */
	    cur->transition = TLXS;
	    cur->emitRx = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpS, ai+1, aj, i+1, j, k+1, l, NTRANS));
	  }
	  break;
	case dpLy:
	  if (isgap(Xseq[ai])) {        /* TLYY */
	    cur->transition = TLYY;
	    cur->emitLx = -1; cur->emitRx = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpLy, ai+1, aj, i, j, k+1, l, NTRANS));
	  } else {                      /* TLYS */
	    cur->transition = TLYS;
	    cur->emitRx = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpS, ai+1, aj, i+1, j, k+1, l, NTRANS));
	  }
	  break;
	case dpP:
	  cur->transition = TPN;
	  cur->emitLx = -1; cur->emitRx = -1; 
	  cur->emitLy = -1; cur->emitRy = -1;
	  PushTracestack(dolist, 
	      AttachATrace(cur, dpN, ai, aj, i, j, k, l, NTRANS));
	  break;
	case dpN:
	  if (isgap(Xseq[ai])) {   /* TNLY */
	    cur->transition = TNLY;
	    cur->emitLx = -1; cur->emitRx = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpLy, ai+1, aj, i, j, k+1, l, NTRANS));
	  } else if (isgap(Xseq[aj])) { /* TNLX */
	    cur->transition = TNLX;
	    cur->emitLy = -1; cur->emitRx = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpLx, ai+1, aj, i+1, j, k, l, NTRANS));
	  } else {                 /* TNS */
	    cur->transition = TNS;
	    cur->emitRx = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpS, ai+1, aj, i+1, j, k+1, l, NTRANS));
	  }
	  break;
      }
    } else if (ct[aj] == -1) {	/* aj unpaired; single stranded right */
      if (isLstate(cur->nonterminal)) {
	if (cur->nonterminal == dpS) cur->transition = TST;
	else if (cur->nonterminal == dpLx) cur->transition = TLXT;
	else /* dpLy */ cur->transition = TLYT;
	cur->emitLx = -1; cur->emitRx = -1; 
	cur->emitLy = -1; cur->emitRy = -1;
	PushTracestack(dolist, 
	    AttachATrace(cur, dpT, ai, aj, i, j, k, l, NTRANS));
      } else if (isRstate(cur->nonterminal)) {	
	if (cur->nonterminal == dpT) {
	  if (isgap(Xseq[aj])) {        /* TTRY*/
	    cur->transition = TTRY;
	    cur->emitLx = -1; cur->emitLy = -1; cur->emitRx = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpRy, ai, aj-1, i, j, k, l-1, NTRANS));
	  } else if (isgap(Yseq[aj])) { /* TTRX*/
	    cur->transition = TTRX;
	    cur->emitLx = -1; cur->emitLy = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpRx, ai, aj-1, i, j-1, k, l, NTRANS));
	  } else {                      /* TTT */
	    cur->transition = TTT;
	    cur->emitLx = -1; cur->emitLy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpT, ai, aj-1, i, j-1, k, l-1, NTRANS));
	  }
	} else if (cur->nonterminal == dpRx) {
	  if (isgap(Yseq[aj])) {        /* TRXX */
	    cur->transition = TRXX;
	    cur->emitLx = -1; cur->emitLy = -1; cur->emitRy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpRx, ai, aj-1, i, j-1, k, l, NTRANS));
	  } else {                      /* TRXT */
	    cur->transition = TRXT;
	    cur->emitLx = -1; cur->emitLy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpT, ai, aj-1, i, j-1, k, l-1, NTRANS));
	  }
	} else { /* dpRy */
	  if (isgap(Xseq[aj])) {        /* TRYY */
	    cur->transition = TRYY;
	    cur->emitLx = -1; cur->emitLy = -1; cur->emitRx = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpRy, ai, aj-1, i, j, k, l-1, NTRANS));
	  } else {                      /* TRYM */
	    cur->transition = TRYT;
	    cur->emitLx = -1; cur->emitLy = -1;
	    PushTracestack(dolist, 
		AttachATrace(cur, dpT, ai, aj-1, i, j-1, k, l-1, NTRANS));
	  }
	}
      } else if (cur->nonterminal == dpP) {
	cur->transition = TPN;
	cur->emitLx = -1; cur->emitRx = -1; 
	cur->emitLy = -1; cur->emitRy = -1;
	PushTracestack(dolist, 
	    AttachATrace(cur, dpN, ai, aj, i, j, k, l, NTRANS));
      } else {	/* dpN */
	if (isgap(Xseq[aj])) {   /* TNRY */
	  cur->transition = TNRY;
	  cur->emitLx = -1; cur->emitLy = -1; cur->emitRx = -1;
	  PushTracestack(dolist, 
	      AttachATrace(cur, dpRy, ai, aj-1, i, j, k, l-1, NTRANS));
	} else if (isgap(Yseq[aj])) { /* TNRX */
	  cur->transition = TNRX;
	  cur->emitLx = -1; cur->emitLy = -1; cur->emitRy = -1;
	  PushTracestack(dolist, 
	      AttachATrace(cur, dpRx, ai, aj-1, i, j-1, k, l, NTRANS));
	} else {                 /* TNRM */
	  cur->transition = TNT;
	  cur->emitLx = -1; cur->emitLy = -1;
	  PushTracestack(dolist, 
	      AttachATrace(cur, dpT, ai, aj-1, i, j-1, k, l-1, NTRANS));
	}
      }
    } else if (ct[ai] == aj) {	/* ai pairs to aj */
      if (isLstate(cur->nonterminal)) {
	if (cur->nonterminal == dpS) cur->transition = TST;
	else if (cur->nonterminal == dpLx) cur->transition = TLXT;
	else /* dpLy */ cur->transition = TLYT;
	cur->emitLx = -1; cur->emitRx = -1; 
	cur->emitLy = -1; cur->emitRy = -1;
	PushTracestack(dolist, 
	    AttachATrace(cur, dpT, ai, aj, i, j, k, l, NTRANS));
      } else if (isRstate(cur->nonterminal)) {	/* isRstate */
	if (cur->nonterminal == dpT) cur->transition = TTP;
	else if (cur->nonterminal == dpRx) cur->transition = TRXP;
	else /* dpRy */ cur->transition = TRYP;
	PushTracestack(dolist, 
	    AttachATrace(cur, dpP, ai+1, aj-1, i+1, j-1, k+1, l-1, NTRANS));
      } else {	/* dpP */
	cur->transition = TPP;
	PushTracestack(dolist, 
	    AttachATrace(cur, dpP, ai+1, aj-1, i+1, j-1, k+1, l-1, NTRANS));
      }
    } else {				/* ai, aj paired but not to each other */
      if (isLstate(cur->nonterminal)) {
	if (cur->nonterminal == dpS) cur->transition = TST;
	else if (cur->nonterminal == dpLx) cur->transition = TLXT;
	else /* dpLy */ cur->transition = TLYT;
	cur->emitLx = -1; cur->emitRx = -1; 
	cur->emitLy = -1; cur->emitRy = -1;
	PushTracestack(dolist,
	    AttachATrace(cur, dpT, ai, aj, i, j, k, l, NTRANS));
      } else if (isRstate(cur->nonterminal)) { 
	if (cur->nonterminal == dpT) {
	  cur->transition = TTB;
	  a = dealignedCoord(Xseq, ai, ct[aj]-1, i);
	  b = dealignedCoord(Yseq, ai, ct[aj]-1, k);
	  cur->emitLx = a+1; cur->emitLy = b+1;
	  PushTracestack(dolist, 
	    AttachATrace(cur, dpP, ct[aj]+1, aj-1, a+2, j-1, b+2, l-1, NTRANS));
	  PushTracestack(dolist, 
	    AttachATrace(cur, dpT, ai, ct[aj]-1, i, a, k, b, NTRANS));
	} else if (cur->nonterminal == dpRx) {
	  cur->transition = TRXB;
	  a = dealignedCoord(Xseq, ai, ct[aj]-1, i);
	  b = dealignedCoord(Yseq, ai, ct[aj]-1, k);
	  cur->emitLx = a+1; cur->emitLy = b+1;
	  PushTracestack(dolist, 
	    AttachATrace(cur, dpP, ct[aj]+1, aj-1, a+2, j-1, b+2, l-1, NTRANS));
	  PushTracestack(dolist, 
	    AttachATrace(cur, dpT, ai, ct[aj]-1, i, a, k, b, NTRANS));
	} else { /* dpRy */
	  cur->transition = TRYB;
	  a = dealignedCoord(Xseq, ai, ct[aj]-1, i);
	  b = dealignedCoord(Yseq, ai, ct[aj]-1, k);
	  cur->emitLx = a+1; cur->emitLy = b+1;
	  PushTracestack(dolist, 
	    AttachATrace(cur, dpP, ct[aj]+1, aj-1, a+2, j-1, b+2, l-1, NTRANS));
	  PushTracestack(dolist, 
	    AttachATrace(cur, dpT, ai, ct[aj]-1, i, a, k, b, NTRANS));
	}
      } else if (cur->nonterminal == dpP) {
	cur->transition = TPN;
	cur->emitLx = -1; cur->emitRx = -1; 
	cur->emitLy = -1; cur->emitRy = -1;
	PushTracestack(dolist, 
	    AttachATrace(cur, dpN, ai, aj, i, j, k, l, NTRANS));
      } else {	/* dpN */
	cur->transition = TNB;
	a = dealignedCoord(Xseq, ai, ct[aj]-1, i);
	b = dealignedCoord(Yseq, ai, ct[aj]-1, k);
	cur->emitLx = a+1; cur->emitLy = b+1;
	PushTracestack(dolist, 
	    AttachATrace(cur, dpP, ct[aj]+1, aj-1, a+2, j-1, b+2, l-1, NTRANS));
	PushTracestack(dolist, 
	    AttachATrace(cur, dpT, ai, ct[aj]-1, i, a, k, b, NTRANS));
      }
    }
  }   /* while something's on dolist stack */
  return 1;
}

/********************* Antiques *****************************/

/* Function: cykDebugSTA
 * Date:     Sun Feb 16 19:14:43 CST 2003 [St Louis]
 *
 * Purpose:  Initialize CYK fill matrix 
 * 	with INFTY, can then later check for it.
 *
 * Args:     
 * 	seqX	sequences to align and fold
 * 	seqY
 * 	model	parameter and grammar info
 * 	mx	fill matrix (previously allocated)
 *
 * Returns:  -- void -- 
 */
  void
ccykDebugSTA(SEQUENCE *seqX, SEQUENCE *seqY, INTMOD *model, int *****mx)
{
  int j, dx, i;		/* Coordinates in Seq X */
  int l, dy, k;		/* Coordinates in Seq Y */
  int Xlen, Ylen;	/* Length - makes code more readable */

  Xlen = seqX->len;
  Ylen = seqY->len;

  for (dx = 0; dx <= Xlen; dx++) { 
    for (j = (dx > 0)? dx-1: dx; j < Xlen; j++) {
      i = j - dx +1;
      for (dy = 0; dy <= Ylen; dy++) {
	for (l = (dy > 0)? dy-1: dy; l < Ylen; l++) {
	  k = l - dy +1;
	  mx[dpS][j][dx][l][dy] = INFTY; 
	  mx[dpLx][j][dx][l][dy] = INFTY; 
	  mx[dpLy][j][dx][l][dy] = INFTY; 
	  mx[dpT][j][dx][l][dy] = INFTY; 
	  mx[dpRx][j][dx][l][dy] = INFTY; 
	  mx[dpRy][j][dx][l][dy] = INFTY;
	  mx[dpN][j][dx][l][dy] = INFTY; 
	  mx[dpP][j][dx][l][dy] = INFTY; 
	}
      }
    }
  }
}

/* Function: ccykFillSTA
 * Date:     Tue Aug 26 09:18:11 CDT 2003 [St Louis]
 *
 * Purpose:  Fills CYK matrix for STA grammar
 * Assumption: Fill matrix already allocated.
 *    No initalization assumed.  For debugging, use
 *    ccykDebugSTA to initalize -- this will set the 
 *    fill matrix to INFTY and we'll catch those problems
 *    in this function.
 *
 * Args:    
 * 	seqs	sequences and constraint info
 * 	model	parameter and grammar info
 * 	mx	fill matrix
 *
 * Returns:  void 
 */
  void
ccykFillSTA(SEQPR *seqs, INTMOD *model, int *****mx)
{
  int i, j, dx, a;	/* Sequence x indicies */
  int k, l, dy, b;	/* Sequence y indicies */
  int debug = FALSE;

  int ledge, bedge;
  int max, bifmax, cursc;      
  int Pap, Sm, Lx, Ly, Tm, Rx, Ry;

  int Xlen, Ylen;
  char *isXconstraint;
  char *isYconstraint;
  int *sL; int *sR, *Yval;

  /* Using local pointers to make the code more readable;
   * may also help with some compiler optimizations */
  Xlen = seqs->sequence[SEQX]->len;
  Ylen = seqs->sequence[SEQY]->len;
  sL = seqs->c_info->sL;
  sR = seqs->c_info->sR;
  /* Must define isXconstraint isYconstraint and Yval for NXOR macro to work */
  isXconstraint = seqs->c_info->isXconstraint;
  isYconstraint = seqs->c_info->isYconstraint;
  Yval = seqs->c_info->Yval;

  if (debug) { printf("X len %d Ylen %d\n", Xlen, Ylen); }

  for (dx = 0; dx <= Xlen; dx++) {
    if (debug) { printf("dx = %d\n", dx); }
    for (j = (dx > 0)? dx-1: 0; j < Xlen; j++) {
      i = j - dx +1;
      if (debug) { 
	if (isXconstraint[i] && isXconstraint[j]) 
	  printf("\t i* = %d j* = %d\n", i, j); 
	else if (isXconstraint[i]) printf("\t i* = %d j = %d\n", i, j); 
	else if (isXconstraint[j]) printf("\t i = %d j* = %d\n", i, j); 
	else printf("\t i = %d j = %d\n", i, j); 
	fflush(stdout);
      }

      for (dy = ((sL[j] >= sR[i]) ? (sL[j] - sR[i]+1): 0); 
	  dy <= (sR[j] - sL[i] +1); dy++) {
	if (debug) { printf(" dy = %d\n", dy); }

	/* Loop ends at min sR[j] unless 
	 * sR[i] != sR[j] and sR[i] + dy -1) */
	ledge = ((sR[i] == sR[j])?  sR[j] :  
	   /* ((dy == 0)?  sR[j]-1 : sR[j]) :   */
	    ((sR[i] + dy -1 < sR[j])? (sR[i] + dy -1) : sR[j])); 
	/* Loop begins at max (sL[j], sL[i] + dy -1) */
	for (l = ((sL[j] > sL[i] + dy -1)? sL[j] : sL[i] + dy -1); 
	    l <= ledge; l++) { 
	  k = l - dy +1;
	  if (debug) { 
	    if (isYconstraint[k] && isYconstraint[l]) 
	      printf("\t\t k* = %d l* = %d\n", k, l); 
	    else if (isYconstraint[k]) 
	      printf("\t\t k* = %d l = %d\n", k, l); 
	    else if (isYconstraint[l]) 
	      printf("\t\t k = %d l* = %d\n", k, l); 
	    else printf("\t\t k = %d l = %d\n", k, l); 
	  }       

	  if (debug) {
	    printf("j %d dx %d l %d dy %d \n", 
		j, dx, l, dy); fflush(stdout);
	  }

	  /* The distances are zero iterations are initialization
	   * instances.  We deal with them separately.  
	   */
	  if ((dx == 0) && (dy == 0)) {
	    mx[dpS][j][dx][l][dy] = model->transitions[TSE];
	    mx[dpLx][j][dx][l][dy] = model->transitions[TLXE];
	    mx[dpLy][j][dx][l][dy] = model->transitions[TLYE];
	    mx[dpT][j][dx][l][dy] = -BIGINT;
	    mx[dpRx][j][dx][l][dy] = -BIGINT;
	    mx[dpRy][j][dx][l][dy] = -BIGINT;
	    mx[dpP][j][dx][l][dy] = -BIGINT;
	    mx[dpN][j][dx][l][dy] = -BIGINT;
	  } else if (dx == 0) {
	    if (!isYconstraint[k]) {
	      mx[dpS][j][dx][l][dy] =
		mx[dpLy][j][dx][l][dy-1] +
		model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[k])] +
		model->transitions[TSLY];
	      mx[dpLy][j][dx][l][dy] =
		mx[dpLy][j][dx][l][dy-1] +
		model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[k])] +
		model->transitions[TLYY];
	      mx[dpN][j][dx][l][dy] =
		mx[dpLy][j][dx][l][dy-1] +
		model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[k])] +
		model->transitions[TNLY];
	    } else {
	      mx[dpS][j][dx][l][dy] = -BIGINT;
	      mx[dpLy][j][dx][l][dy] = -BIGINT;
	      mx[dpN][j][dx][l][dy] = -BIGINT;
	    }
	    mx[dpLx][j][dx][l][dy] = -BIGINT;
	    mx[dpT][j][dx][l][dy] = -BIGINT;
	    mx[dpRx][j][dx][l][dy] = -BIGINT;
	    mx[dpRy][j][dx][l][dy] = -BIGINT;
	    mx[dpP][j][dx][l][dy] = mx[dpN][j][dx][l][dy] +
	      model->transitions[TPN];
	  } else if (dy == 0) {

	    if (debug) {printf(" dy zero " ); fflush(stdout); }
	    if (!isXconstraint[i]) {
	      mx[dpS][j][dx][l][dy] =
		mx[dpLx][j][dx-1][l][dy] +
		model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[i])] +
		model->transitions[TSLX];
	      mx[dpLx][j][dx][l][dy] =
		mx[dpLx][j][dx-1][l][dy] +
		model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[i])] +
		model->transitions[TLXX];
	      mx[dpN][j][dx][l][dy] =
		mx[dpLx][j][dx-1][l][dy] +
		model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[i])] +
		model->transitions[TNLX];
	    } else {
	      mx[dpS][j][dx][l][dy] = -BIGINT;
	      mx[dpLx][j][dx][l][dy] = -BIGINT;
	      mx[dpN][j][dx][l][dy] = -BIGINT;
	    }
	    mx[dpLy][j][dx][l][dy] = -BIGINT;
	    mx[dpT][j][dx][l][dy] = -BIGINT;
	    mx[dpRx][j][dx][l][dy] = -BIGINT;
	    mx[dpRy][j][dx][l][dy] = -BIGINT;
	    mx[dpP][j][dx][l][dy] = mx[dpN][j][dx][l][dy] +
	      model->transitions[TPN];
	  } else {

	  /* We use the constraint information to know when an
	   * emission is permissible or not (at an edge of a 
	   * segment or a constraint).  */


	    /* (-y)Ly */
	    Ly = -BIGINT; 
	    if (!isYconstraint[k]) {	
	      if (mx[dpLy][j][dx][l][dy-1] == INFTY) {
		printf("Unitialized value dpLy! i %d j %d k %d l %d\n",
		    i, j, k, l);
	      }
	      Ly = mx[dpLy][j][dx][l][dy-1] 
		+ model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[k])];
	    }

	    /* (x-)Lx */
	    Lx = -BIGINT;
	    if (!isXconstraint[i]) { 
	      if (mx[dpLx][j][dx-1][l][dy] == INFTY) {
		printf("Unitialized value dpLx! i %d j %d k %d l %d\n",
		    i, j, k, l);
	      }
	      Lx = mx[dpLx][j][dx-1][l][dy] 
		+ model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[i])];
	    }

	    /* (xy)S */
	    Sm = -BIGINT;
	    if (NXOR(i,k)) { 
	      Sm = mx[dpS][j][dx-1][l][dy-1] 
		+ model->emissions[eAL(seqs->sequence[SEQX]->dseq[i],
		    seqs->sequence[SEQY]->dseq[k])];
	    }

	    /* Rx(x-) */
	    Rx = -BIGINT;
	    if (!isXconstraint[j]) { 
	      if (j == 0) {
		if (mx[dpRx][0][dx-1][l][dy] == INFTY) {
		  printf("Unitialized value dpRx (j=0)! ");
		  printf("i %d j %d k %d l %d\n", i, j, k, l);
		}
		Rx = mx[dpRx][0][dx-1][l][dy] 
		  + model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[j])];
	      } else {
		if (mx[dpRx][j-1][dx-1][l][dy] == INFTY) {
		  printf("Unitialized value dpRx! ");
		  printf("i %d j %d k %d l %d\n", i, j, k, l);
		}
		Rx = mx[dpRx][j-1][dx-1][l][dy] 
		  + model->emissions[eSS((int)seqs->sequence[SEQX]->dseq[j])];
	      }
	    }

	    /* Ry(-y) */
	    Ry = -BIGINT;
	    if (!isYconstraint[l]) {		
	      if (l == 0) {
		if (mx[dpRy][j][dx][0][dy-1] == INFTY) {
		  printf("Unitialized value dpRy (l=0)! ");
		  printf("i %d j %d k %d l %d\n", i, j, k, l);
		}
		Ry = mx[dpRy][j][dx][0][dy-1] 
		  + model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[l])];
	      } else {
		if (mx[dpRy][j][dx][l-1][dy-1] == INFTY) {
		  printf("Unitialized value dpRy! ");
		  printf("i %d j %d k %d l %d\n", i, j, k, l);
		}
		Ry = mx[dpRy][j][dx][l-1][dy-1] 
		  + model->emissions[eSS((int)seqs->sequence[SEQY]->dseq[l])];
	      }
	    }

	    /* T(xy) */
	    Tm = -BIGINT;
	    if (NXOR(j,l)) { 
	      if ((j == 0) && (l == 0)) {
		if (mx[dpT][0][dx-1][0][dy-1] == INFTY) {
		  printf("Unitialized value dpT (j&l=0)! ");
		  printf("i %d j %d k %d l %d\n", i, j, k, l);
		}

		Tm = mx[dpT][0][dx-1][0][dy-1] 
		  + model->emissions[eAL(seqs->sequence[SEQX]->dseq[j],
		      seqs->sequence[SEQY]->dseq[l])];
	      } else if (j == 0) {
		if (mx[dpT][0][dx-1][l-1][dy-1] == INFTY) {
		  printf("Unitialized value dpT (j=0)! ");
		  printf("i %d j %d k %d l %d\n", i, j, k, l);
		}
		Tm = mx[dpT][0][dx-1][l-1][dy-1] 
		  + model->emissions[eAL(seqs->sequence[SEQX]->dseq[j],
		      seqs->sequence[SEQY]->dseq[l])];
	      } else if (l == 0) {
		if (mx[dpT][j-1][dx-1][0][dy-1] == INFTY) {
		  printf("Unitialized value dpT (l=0)! ");
		  printf("i %d j %d k %d l %d\n", i, j, k, l);
		}
		Tm = mx[dpT][j-1][dx-1][0][dy-1] 
		  + model->emissions[eAL(seqs->sequence[SEQX]->dseq[j],
		      seqs->sequence[SEQY]->dseq[l])];
	      } else {
		if (mx[dpT][j-1][dx-1][l-1][dy-1] == INFTY) {
		  printf("Unitialized value dpT ! ");
		  printf("i %d j %d k %d l %d\n", i, j, k, l);
		}
		Tm = mx[dpT][j-1][dx-1][l-1][dy-1] 
		  + model->emissions[eAL(seqs->sequence[SEQX]->dseq[j],
		      seqs->sequence[SEQY]->dseq[l])];
	      }
	    }

	    /* (xy)P(x'y') */
	    Pap = -BIGINT;
	    if (NXOR(i,k) && NXOR(j,l)) { 
	      if ((l > 0) && (j > 0) && (dx > 1) && (dy > 1)) {
		if (mx[dpP][j-1][dx-2][l-1][dy-2] == INFTY) {
		  printf("Unitialized value dpP ! ");
		  printf("i %d j %d k %d l %d\n", i, j, k, l);
		}

		Pap = mx[dpP][j-1][dx-2][l-1][dy-2]
		  + model->emissions[ePR(idx(seqs->sequence[SEQX]->dseq[i],
			seqs->sequence[SEQX]->dseq[j]),
		      idx(seqs->sequence[SEQY]->dseq[k],
			seqs->sequence[SEQY]->dseq[l]))]; 
	      }
	    }

	    /* T (xy)P(x'y') */
	    bifmax = -BIGINT;
	    if (NXOR(j,l)) { 
	      for (a = i+1; a < (j-1); a++) {
		if (debug) printf("\t\t\t\t a = %d \n", a); 
		if (isXconstraint[a]) {	/* a is a constraint */
		  /* Then only time we can bifurcate is if b is
		   * a's matching pair */
		  b = seqs->c_info->Yval[a];
		  if (debug) { 
		    printf("\t\t\t\t\t *b = %d \n", b); fflush(stdout); 
		  }
		  if (mx[dpP][j-1][dist(a+1,j-1)][l-1][dist(b+1,l-1)] 
		      == INFTY) {
		    printf("Unitialized value dpP in bif ! ");
		    printf("i %d j %d a %d k %d l %d b %d \n", 
			i, j, a, k, l, b);
		  }
		  if (mx[dpT][a-1][dist(i,a-1)][b-1][dist(k,b-1)] == INFTY) {
		    printf("Unitialized value dpT in bif ! ");
		    printf("i %d j %d a %d k %d l %d b %d \n", 
			i, j, a, k, l, b);
		  }

		  cursc = mx[dpP][j-1][dist(a+1,j-1)][l-1][dist(b+1,l-1)] 
		    + mx[dpT][a-1][dist(i,a-1)][b-1][dist(k,b-1)] 
		    + model->emissions[ePR(idx(seqs->sequence[SEQX]->dseq[a], 
			  seqs->sequence[SEQX]->dseq[j]),
			idx(seqs->sequence[SEQY]->dseq[b], 
			  seqs->sequence[SEQY]->dseq[l]))];
		  if (cursc > bifmax) {
		    bifmax = cursc;
		    if (debug) printf(" select b %d\n", b);
		  }
		} else {
		  /* b must in the segment containing a */
		  bedge = ((l < sR[a])? l-1: sR[a]);
		  for (b = ((k > sL[a])? k+1: sL[a]); b < bedge; b++) {
		    /* If be is a constraint; but not a then we
		     * can't bifurcate at this coordinate.
		     */
		    if ((j > 0) && (l > 0) && (a > 0) && (b > 0)) {
		      if (!isYconstraint[b]) {
			if (mx[dpP][j-1][dist(a+1,j-1)][l-1][dist(b+1,l-1)] 
			    == INFTY) {
			  printf("Unitialized value dpP in bif ! ");
			  printf("i %d j %d a %d k %d l %d b %d \n", 
			      i, j, a, k, l, b);
			}
			if (mx[dpT][a-1][dist(i,a-1)][b-1][dist(k,b-1)] 
			    == INFTY) {
			  printf("Unitialized value dpT in bif ! ");
			  printf("i %d j %d a %d k %d l %d b %d \n", 
			      i, j, a, k, l, b);
			}

			if (debug) printf("\t\t\t\t\t b = %d \n", b); 
			cursc = 
			  mx[dpP][j-1][dist(a+1,j-1)][l-1][dist(b+1, l-1)] 
			  + mx[dpT][a-1][dist(i,a-1)][b-1][dist(k,b-1)] 
			  + model->emissions[
			  ePR(idx(seqs->sequence[SEQX]->dseq[a],
				seqs->sequence[SEQX]->dseq[j]),
			      idx(seqs->sequence[SEQY]->dseq[b], 
				seqs->sequence[SEQY]->dseq[l]))];
		      } else {
			cursc = -BIGINT;
		      }
		      if (cursc > bifmax) {
			bifmax = cursc;
			if (debug) printf(" select b %d\n", b);
		      }
		    }
		  }
		}
	      }
	    }
	    if (debug) { printf("\n"); fflush(stdout); }

	    /* Now that I've set which emissions are possible, I ought to be
	     * able to do the fills for each (i,j,k,l) accodingly. */

	    /* T -> T(xy) | Rx(x-) | Ry(-y) | (xy)P(x'y') | T (xy)P(x'y') */
	    max = -BIGINT;
	    cursc = Tm + model->transitions[TTT];
	    if (cursc > max) max = cursc;
	    cursc = Rx + model->transitions[TTRX];
	    if (cursc > max) max = cursc;
	    cursc = Ry + model->transitions[TTRY];
	    if (cursc > max) max = cursc;
	    cursc = Pap + model->transitions[TTP];
	    if (cursc > max) max = cursc;
	    cursc = bifmax + model->transitions[TTB];
	    if (cursc > max) max = cursc;
	    mx[dpT][j][dx][l][dy] = max;

	    /* S -> (xy)S | (x-)Lx | (-y)Ly | T | end */
	    max = -BIGINT;
	    cursc = Sm + model->transitions[TSS];
	    if (cursc > max) max = cursc;
	    cursc = Lx + model->transitions[TSLX];
	    if (cursc > max) max = cursc;
	    cursc = Ly + model->transitions[TSLY];
	    if (cursc > max) max = cursc;
	    cursc = mx[dpT][j][dx][l][dy] + model->transitions[TST];
	    if (cursc > max) max = cursc;
	    mx[dpS][j][dx][l][dy] = max;

	    /* Lx -> (xy)S | (x-)Lx | T | end */
	    max = -BIGINT;
	    cursc = Sm + model->transitions[TLXS];
	    if (cursc > max) max = cursc;
	    cursc = Lx + model->transitions[TLXX];
	    if (cursc > max) max = cursc;
	    cursc = mx[dpT][j][dx][l][dy] + model->transitions[TLXT];
	    if (cursc > max) max = cursc;
	    mx[dpLx][j][dx][l][dy] = max;

	    /* Ly -> (xy)S | (-y)Ly | T | end */
	    max = -BIGINT;
	    cursc = Sm + model->transitions[TLYS];
	    if (cursc > max) max = cursc;
	    cursc = Ly + model->transitions[TLYY];
	    if (cursc > max) max = cursc;
	    cursc = mx[dpT][j][dx][l][dy] + model->transitions[TLYT];
	    if (cursc > max) max = cursc;
	    mx[dpLy][j][dx][l][dy] = max;

	    /* Rx -> (xy)T | Rx(x-) | (xy)P(x'y') | T (xy)P(x'y') */
	    max = -BIGINT;
	    cursc = Tm + model->transitions[TRXT];
	    if (cursc > max) max = cursc;
	    cursc = Rx + model->transitions[TRXX];
	    if (cursc > max) max = cursc;
	    cursc = Pap + model->transitions[TRXP];
	    if (cursc > max) max = cursc;
	    cursc = bifmax + model->transitions[TRXB];
	    if (cursc > max) max = cursc;
	    mx[dpRx][j][dx][l][dy] = max;

	    /* Ry -> (xy)T | Ry(-y) | (xy)P(x'y') | T (xy)P(x'y') */
	    max = -BIGINT;
	    cursc = Tm + model->transitions[TRYT];
	    if (cursc > max) max = cursc;
	    cursc = Ry + model->transitions[TRYY];
	    if (cursc > max) max = cursc;
	    cursc = Pap + model->transitions[TRYP];
	    if (cursc > max) max = cursc;
	    cursc = bifmax + model->transitions[TRYB];
	    if (cursc > max) max = cursc;
	    mx[dpRy][j][dx][l][dy] = max;

	    /* N -> (xy)S | (x-)Lx | (-y)Ly | 
	     * T(xy) | Rx(x-) | Ry(-y) | T (xy)P(x'y') */
	    max = -BIGINT;
	    cursc = Sm + model->transitions[TNS];
	    if (cursc > max) max = cursc;
	    cursc = Lx + model->transitions[TNLX];
	    if (cursc > max) max = cursc;
	    cursc = Ly + model->transitions[TNLY];
	    if (cursc > max) max = cursc;
	    cursc = Tm + model->transitions[TNT];
	    if (cursc > max) max = cursc;
	    cursc = Rx + model->transitions[TNRX];
	    if (cursc > max) max = cursc;
	    cursc = Ry + model->transitions[TNRY];
	    if (cursc > max) max = cursc;
	    cursc = bifmax + model->transitions[TNB];
	    if (cursc > max) max = cursc;
	    mx[dpN][j][dx][l][dy] = max;

	    /* P -> (xy)P(x'y') | (xy)N(x'y') */
	    max = -BIGINT; 
	    cursc = Pap + model->transitions[TPP];
	    if (cursc > max) max = cursc;
	    /* N */
	    if (mx[dpN][j][dx][l][dy] == INFTY) {
	      printf("Unitialized value N ! ");
	      printf("i %d j %d k %d l %d\n", i, j, k, l);
	    }
	    cursc = mx[dpN][j][dx][l][dy] + model->transitions[TPN];
	    if (cursc > max) max = cursc;
	    mx[dpP][j][dx][l][dy] = max;

	  }
	}
      }
    }
  }
}

void
hcTransSTA(INTMOD *sc)
{
   /* Transitions : Adapted (loosely) on conus' unaY16S.mod */
   sc->transitions[TSS] = asIntLog(0.7596);
   sc->transitions[TSLX] = asIntLog(0.007375);
   sc->transitions[TSLY] = asIntLog(0.007375);
   sc->transitions[TST] = asIntLog(0.1792);
   sc->transitions[TSE] = asIntLog(0.1792);

   sc->transitions[TTT] = asIntLog(0.7596);
   sc->transitions[TTRX] = asIntLog(0.007375);
   sc->transitions[TTRY] = asIntLog(0.007375);
   sc->transitions[TTS] = asIntLog(0.1792);
   sc->transitions[TTP] = asIntLog(0.1792);
   sc->transitions[TTB] = asIntLog(0.1792);

   sc->transitions[TLXS] = asIntLog(0.2363);
   sc->transitions[TLXX] = asIntLog(0.2546);
   sc->transitions[TLXT] = asIntLog(0.5091);
   sc->transitions[TLXE] = asIntLog(0.5091);

   sc->transitions[TLYS] = asIntLog(0.2363);
   sc->transitions[TLYY] = asIntLog(0.2546);
   sc->transitions[TLYT] = asIntLog(0.5091);
   sc->transitions[TLYE] = asIntLog(0.5091);

   sc->transitions[TRXT] = asIntLog(0.3811);
   sc->transitions[TRXX] = asIntLog(0.19055);
   sc->transitions[TRXS] = asIntLog(0.19055);
   sc->transitions[TRXP] = asIntLog(0.2378);
   sc->transitions[TRXB] = asIntLog(0.2378);

   sc->transitions[TRYT] = asIntLog(0.3811);
   sc->transitions[TRYY] = asIntLog(0.19055);
   sc->transitions[TRYS] = asIntLog(0.19055);
   sc->transitions[TRYP] = asIntLog(0.2378);
   sc->transitions[TRYB] = asIntLog(0.2378);

   sc->transitions[TPP] = asIntLog(0.3811);
   sc->transitions[TPN] = asIntLog(0.19055);

   sc->transitions[TNS] = asIntLog(0.3811);
   sc->transitions[TNLX] = asIntLog(0.19055);
   sc->transitions[TNLY] = asIntLog(0.19055);
   sc->transitions[TNT] = asIntLog(0.2378);
   sc->transitions[TNRX] = asIntLog(0.2378);
   sc->transitions[TNRY] = asIntLog(0.2378);
   sc->transitions[TNB] = asIntLog(0.2378);
}

void
hcTransMNG(INTMOD *sc)
{
   /* Transitions : Adapted (loosely) on conus' unaY16S.mod */
   sc->transitions[TSS] = asIntLog(0.7596);
   sc->transitions[TSLX] = asIntLog(0.007375);
   sc->transitions[TSLY] = asIntLog(0.007375);
   sc->transitions[TST] = asIntLog(0.1792);
   sc->transitions[TSE] = asIntLog(0.1792);

   sc->transitions[TTT] = asIntLog(0.7596);
   sc->transitions[TTRX] = asIntLog(0.007375);
   sc->transitions[TTRY] = asIntLog(0.007375);
   sc->transitions[TTS] = asIntLog(0.1792);
   sc->transitions[TTP] = asIntLog(0.1792);
   sc->transitions[TTB] = asIntLog(0.1792);

   sc->transitions[TLXS] = asIntLog(0.2363);
   sc->transitions[TLXX] = asIntLog(0.2546);
   sc->transitions[TLXT] = asIntLog(0.5091);
   sc->transitions[TLXE] = asIntLog(0.5091);

   sc->transitions[TLYS] = asIntLog(0.2363);
   sc->transitions[TLYY] = asIntLog(0.2546);
   sc->transitions[TLYT] = asIntLog(0.5091);
   sc->transitions[TLYE] = asIntLog(0.5091);

   sc->transitions[TRXT] = asIntLog(0.3811);
   sc->transitions[TRXX] = asIntLog(0.19055);
   sc->transitions[TRXS] = asIntLog(0.19055);
   sc->transitions[TRXP] = asIntLog(0.2378);
   sc->transitions[TRXB] = asIntLog(0.2378);

   sc->transitions[TRYT] = asIntLog(0.3811);
   sc->transitions[TRYY] = asIntLog(0.19055);
   sc->transitions[TRYS] = asIntLog(0.19055);
   sc->transitions[TRYP] = asIntLog(0.2378);
   sc->transitions[TRYB] = asIntLog(0.2378);

}

