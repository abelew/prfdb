#ifndef OPTION_H_INCLUDED
#define OPTION_H_INCLUDED

#define ZDEF 100

/* Tie Types */
#define NOTIE   0
#define DPTIE   1
#define CTTIE   2
#define OETIE   3
#define LRTIE   4

struct opts {
  int grammar;		/* -g : Grammar requested on command line */
  char *modelfile;	/* -m : model file to load */
  FILE *ofp;		/* -o : where to write output (default stdout) */
  char *savefile;	/* -s : where to save subset of output */

  int verbose;		/* -v : verbose output */
  int debugg;		/* -d : debugging output */
  int traceback;	/* -t : print traceback stack */
  int parameterout;	/* -x : print out parameters of model */
  int stockout;		/* -q : output predictions in stockholm format */
  int linear;		/* -l : linear output */

  /* pin selection variables */
  int pinopt; 		/* -z : pin selection method */
  char *pinfile;        /* -p : use given pins listed in this file */
  char *tablefile; 	/* --pt <file> : read in posterior table */
  int usegiven;		/* --al : boolean to utilize alignment with seqs */

  /* mltrain_main specific options */
  int weights;		/* -n :if false, don't use weighting scheme */
  int voronoi;		/* -V :if TRUE, use Voronoi weights */
  int gscweights;	/* -G :if TRUE, use GSC weights */
  int tie;		/* -T :Tie type */

  /* comppair_main */
  int suppress;		/* -S : Suppress extra output */

  /* extractpairs_main */
  int selfvself; 	/* --self: only self comparisons */
  int allpairs; 	/* --all: all n*n pairs */

  /* Generic options, used many places */
  /* -P */
  int Poption;		/* generic int */
  int pset; 
  /* -C */
  int Coption;		/* generic int */
  int cset;  
  /* -Z */
  float Zoption;	/* generic float */
  int zset;
  /*  */
  char *Xoption;	/* generic string */
  int xset;
  /* -W */
  int Woption;		/* generic int */
  int wset; 
  /* -M */
  int mset; 		/* Used to indicate Mathews scoring method */
  int Moption;		/* Memory limit to enforce */
 
  int copt; 	   	/* -c : generic boolean */
  int fopt;		/* -f : generic boolean */
};

typedef struct opts OPTS;

extern int processOpts(OPTS *options, int *optid, int argc, char **argv, 
			char *usage, char *optsline);
extern int processGrammarChoice (char *grammar);
extern void printOptions (FILE *ofp, OPTS *options);
extern int setupWeights(MSA *msa, OPTS settings);
extern void standardizeMSA(MSA *msa);

/* cfgbuild.c */
extern void setupModel(OPTS *options, MODEL **loaded);
extern void setupModelQuiet(OPTS *options, MODEL **loaded);
#endif /* OPTION_H_INCLUDED */
