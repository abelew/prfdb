/* dprm.c
 * Sat Jan 25 10:25:19 CST 2003
 * 
 * Allocation, free'ing, printing of the fill matrix \
 * for reduced memory version.  This version requires 
 * knowledge of the constraints specified.
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>
#include <ctype.h> /* toupper */

#include "squid.h"
#include "cfg.h"
#include "consan.h"
#include "dps.h"

/* Function: allocRedFillMx, freeRedFillMx
 * Date:     Wed Nov 19 06:20:56 CST 2003 [Oxford, UK]
 *
 * Purpose: Allocate space for the DP fill matrix 
 *
 * Assumption:
 * 	Allocates only cells used by constraints
 * 	Assumes (j,dx,l,k/dy) notation
 * 	Allocates for an integer fill matrix
 *
 * Notes: This is a 5D matrix 
 * (Nonterminal * LengthX * 1/2 Length * SegLength(j) * SegLength(k))
 * The SegLength(k)*SegLength(j) can sometimes be trimmed when 
 * the segments of i and j overlap. 
 *
 * Args:     
 *      grammar	Current grammar to utilize
 *      sL, sR	segment coordinates of Y coords relative to X
 *	lenX, lenY	length of the sequences
 *	ret_mx	pointer to the allocated space (returned)
 *
 * Returns:  void
 */
void
allocRedFillMx(int grammar, CNSRNT *cinfo,
    int lenX, int lenY, int ******ret_mx)
{
  int *****mx;
  int v, j, i, d, l;	/* Indicies of matrix */
  int Xsize, Ysize;	/* size calculations */
  int Lsize, Ksize; 	/* Segment size for l and k */
  int Dsize;		/* Allocation size for inner most int matrix */
  int Rmve, Rsize;	/* Length of and removal amount */
  int lc;		/* l index in coordinate space */
  int kmax, Kmax;	/* maximum coordinate of k */
  int Kshift;		/* allocation coordinate of each k */

  int *sL, *sR;		/* Segment boundaries */
  char *isXconstraint;
  int debug = FALSE;

  sL = cinfo->sL;
  sR = cinfo->sR;
  isXconstraint = cinfo->isXconstraint;

  if ((mx = (int *****) malloc (NDPS * sizeof(int ****))) == NULL) 
    Die("malloc nonterminals failed");
  /* For each nonterminal, allocate a 4D matrix */
  for (v = 0; v < NDPS; v++) {
    if (Contains[grammar][v]) {
      if ((mx[v] = (int ****) malloc (lenX * sizeof(int ***))) == NULL)
	Die("malloc j failed");
      for (j = 0; j < lenX; j++) {
	Xsize = j + 1;	/* number of d1 cells */
	if ((mx[v][j] = (int ***) malloc ((Xsize+1) * sizeof(int **))) == NULL)
	  Die("malloc d1 failed");
	for (d = 0; d <= Xsize; d++) {
	  /* For each (j, d1) pair in seq X, allocate a seq Y 2D matrix 
	   * where the size of Y's matrix is defined in part by constraints 
	  if ((j == 24) && (d == 0) && (v == 0)) debug = TRUE;
	  else debug = FALSE;
	   * */
	  i = j - d + 1; 	
	  Lsize = sR[j] - sL[j] +1; 	/* Width of possible l */
	  if (debug) {
	    if (Lsize < 0) 
	      printf("\ni %d j %d Lsize %d\n", i, j, Lsize );
	  }
	  if ((mx[v][j][d] = (int **) malloc (Lsize * sizeof(int *))) == NULL)
	    Die("malloc l failed");

	  if (sR[j]+1 < sR[i]) {
	    Kmax = sR[j];
	  } else {
	    Kmax = sR[i];
	  }
	  Ksize = Kmax - sL[i] +1; 	/* Width of possible k */
	
	  /* In overlapping segments, we need only to allocate part of
	   * the full Lsize * Ksize matrix.  The Rmve value is the length
	   * index for the remove portion should we be able to cut a little
	   * more off.
	   */
	  Rmve = Kmax - sL[j];		
	  if (Rmve > 0) {	/* If we can trim more */
	     /* Quantity to remove */
	     Rsize = Rmve*(Rmve-1) / 2;
	     /* Rsize 1 cell too big when dx = 0 */
	     if (i > j) Rsize = Rsize -1;
	  } else {
	     Rsize = 0;
	  }

	  if (isXconstraint[j] && (i > j)) {
	    Dsize = Ksize * (Ksize+1) / 2 + Ksize;
	  } else {
	    /* Set the size of the inner most matrix */
	    Dsize = Lsize * Ksize - Rsize;
	  }
	  if (debug) {
	      printf("Lsize %d Ksize %d Rsize %d Dsize %d\n", 
		  Lsize, Ksize, Rsize, Dsize);
	  }
	  /* The +1 is necessary because when segment(i) overlaps
	   * segment(j) we'll need to be certain to have one 
	   * extra memory location for sL[j] (max l) for the dy = 0
	   * case (k + j+1). */
	  Dsize = Dsize +1; 

	  if ((mx[v][j][d][0] = (int *) malloc(Dsize*sizeof(int))) == NULL)
	    Die("malloc d2 failed %d", Dsize);
	  if (debug) printf("(%#12x)\n", (int) mx[v][j][d][0]); 

	  /* Set row coordinates at appropriate intervals */
	  Kshift = 0;	/* inner cell index */
	  for (l = 1; l < Lsize; l++) {
	     lc = sL[j] + l - 1;	/* Convert alloc l to coord lc */
	     /* biggest k value for this lc */
	     kmax = (lc+1 < sR[i])? lc + 1: sR[i];	
	     /* Resulting in this row being this size */
	     Ysize = kmax - sL[i] + 1;		
	     if (Ysize < 0) Ysize = 0;	/* i > j make this necessary */
	     /* Meaning the next rown is at this index */
	     Kshift = Kshift + Ysize;	
	     if (debug) printf("l %d al %d Kshift %d\n", lc, l, Kshift);
	     mx[v][j][d][l] = mx[v][j][d][0] + Kshift;
	  }	/* End for d */
	  if (debug) printf("Inner Loop complete!\n"); fflush(stdout);
	}	/* End for l */
      }	/* End for j */
    } else {	/* End if contains */
      mx[v] = NULL;
    }
  }
  *ret_mx = mx;
}

  void
freeRedFillMx(int grammar, int lenX, int *****mx) 
{
  int v, j, d;
  int Xsize;	

  for (v = 0; v < NDPS; v++) {
    if (Contains[grammar][v]) {
      for (j = 0; j < lenX; j++) {
	Xsize = j + 1;	/* number of d1 cells */
	for (d = 0; d <= Xsize; d++) {
	  free(mx[v][j][d][0]);
	  free(mx[v][j][d]);
	} /* for d */
	free(mx[v][j]);
      } /* for j */
      free(mx[v]);
    } /* if contains[v] */
  } /* for v */
  free(mx);
}

/* Function: patternRedFillMx, zeroRedFillMx
 * Date:     Sat Jan 25 19:07:45 CST 2003 [St Louis]
 *
 * Purpose: Fill allocated space with known values
 *
 * Args:     
 *      grammar	Current grammar to utilize
 *      sL, sR	segment coordinates of Y coords relative to X
 *	lenX, lenY	length of the sequences
 *	ret_mx	pointer to the allocated space (returned)
 *
 * Returns:  void
 */
  void
patternRedFillMx(int grammar, int *sL, int *sR, int lenX, int lenY, int *****mx) 
{
  int v, j, l, i, d1, d2;	
  int sd, ld;
  int cnt = 0;

  for (v = 0; v < NDPS; v++) {
    if (Contains[grammar][v]) {
      for (j = 0; j < lenX; j++) {
	for (d1 = 0; d1 < j+1; d1++) {
	  i = j - d1; 	/* excludes zero row */
	  for (l = 0; l < (sR[j]-sL[j]+1); l++) {
	    sd = l - sR[i]+1 > 0? l - sR[i]+1: 1;
	    ld = l - sL[i] +1;
	    for (d2 = 0; d2 < (ld-sd+1); d2++) {
	      mx[v][j][d1][l][d2] = cnt++;
	    }	/* End d2 */
	  }	/* End l */
	}	/* End d1 */
      }	/* End j */
    } /* End contains */
  }
}

  void
zeroRedFillMx(int grammar, int *sL, int *sR, int lenX, int lenY, int *****mx) 
{
  int v, j, l, sl, i, d1, d;
  int sd, ld;		/* Shifted coordinates */

  for (v = 0; v < NDPS; v++) {
    if (Contains[grammar][v]) {
      for (j = 0; j < lenX; j++) {
	for (d1 = 0; d1 < j+1; d1++) {
	  i = j - d1; 	/* excludes zero row: dnx */
	  for (l = sL[j]; l <= sR[j]; l++) {
	    sl = l - sL[j];
	    sd = l - sR[i]+1 > 0? l - sR[i]+1: 1;
	    ld = l - sL[i] +1;
	    for (d = 0; d < (ld-sd+1); d++) {
	      /* Recall that -BIGINT is log(0) */
	      mx[v][j][d1][sl][d] = 0;
	    }	/* End d2 */
	  }	/* End l */
	}	/* End d1 */
      }	/* End j */
    } /* End contains */
  }
}

/* Function: fakeRedAllocMx 
 * Date:     Sat Jan 25 12:11:50 CST 2003 [St Louis]
 *
 * Purpose: Estimate Memory Requirements for 
 * 	a sequence of a particular length
 *
 * Assumption: Allocation as per allocFillMx
 *
 * Args:     
 *      grammar	Current grammar to utilize
 *      sL, sR	segment coordinates of Y coords relative to X
 *	lenX, lenY	length of the sequences
 *
 * Returns: 
 * 	size in kilobytes of requested allocation
 */
  unsigned
fakeRedAllocMx(int grammar, int *sL, int *sR, int lenX, int lenY)
{
  unsigned bytes;
  unsigned kilos;
  int v, j, d, i;
  int Dsize, Xsize, Lsize;
  int Osize, Ksize;

  bytes = 0;
  kilos = 0;

  for (v = 0; v < NDPS; v++) {
    if (Contains[grammar][v]) {
      /* Outer allocation is for the X matrix (j, dx) */
      for (j = 0; j < lenX; j++) {
	/* printf("j=%d", j); */
	Xsize = j + 1;
	bytes = (Xsize * sizeof(int **));
	/* Inner allocation is for the Y matrix (l x dy) */
	for (d = 0; d < Xsize; d++) {
	  i = j - d; 	/* excludes zero row */
	  /* printf("\tdx=%d (i=%d)", d, i); */
	  Lsize = sR[j]-sL[j]+1;
	  /* printf("\tLsize %d "\t, Lsize); */
	  bytes += (Lsize * sizeof(int *));

	  /* Set the size of the inner most matrix (Dsize) */
	  Ksize = sR[i]-sL[i]+1;	/* i's segment length */
	  if (sR[i] > sL[j]) {	/* segments overlap */
	    /* Identical segment::full overlap */
	    if ((sR[i] == sR[j]) && (sL[i] == sL[j])) {	
	      Dsize = Ksize*(Ksize+1) / 2;
	    } else {		/* partial overlap */
	      if (sR[i] == sR[j]) {	/* i is constraint */
		Osize = sL[j]-sL[i]; /* portion not overlapping */
		Dsize = Osize*Lsize + Lsize*(Lsize+1)/2;
	      } else {	/* j is constraint */
		Osize = sR[j]-sR[i]; /* portion not overlapping */
		Dsize = Ksize*(Ksize+1) / 2 + Ksize*Osize;
	      }
	    }
	  } else {			/* non-overlapping segments */
	    Dsize = Lsize * Ksize;
	  }
	  bytes += (Dsize * sizeof(int));
	}
	kilos += (int)ceilf((float)bytes/1024.);
      }
      bytes = (lenX * sizeof(int ***));
      kilos += (int)ceilf((float)bytes/1024.);
    }
  }
  kilos += (NDPS * sizeof(int ****));
  return (kilos);
}

/* Function: printRedYFoldMx
 * Date:    Sat Jan 25 19:28:13 CST 2003 [St Louis]
 *
 * Purpose:  (debugging)
 *   For a particular v, j, d1 print the l, d2 matrix
 *
 * Args:     fp   - open FILE ptr to write to (stdout, perhaps)
 *           mx   - DP matrix, 
 *           seqs - sequences and their lengths
 *           v	  - for which non-terminal
 *           j    - position in X
 *           d1   - distance in X 
 *      sL, sR	segment coordinates of Y coords relative to X
 *
 * Notes: 
 *   - d1 is untranslated ... must translate into the proper 
 *     coordinates of the memory locations.
 *   - If we request a nonterminal illegal under this
 *     grammar then print a message to that effect.
 *   - if we request an illegal d1 then we must print a
 *     message to that effect.
 *
 * Return:   (void)
 */
void
printRedYFoldMx(FILE *fp, int *****mx, SEQUENCE *seqX, SEQUENCE *seqY, 
    int v, int j, int d1, int gmr, int *sL, int *sR)
{
  int l, i, d2;
  int dnx, sl, sdy, dmin; 	/* Shifted coordinates */
  int Xlen, Ylen;

  Xlen = seqX->len;
  Ylen = seqY->len;

  /* Check that the requested matrix cross-section is actually valid */
  if (mx[v] == NULL) {
    fprintf(fp, "The requested nonterminal unavailable in this matrix\n"); 
    return;
  }
  if (d1 > j+1) {
    fprintf(fp, "dx requested is too big\n");
    return;
  }

  /* Header information */
  fprintf(fp, "Printing %s (l,dy) matrix for j = %d (%c) dy = %d i = %d\n", 
      dpNAME[Gtype[gmr]][v], j, toupper(seqX->seq[j]), d1, j-d1+1);
  fprintf(fp, "%9s ", " ");
  for (d2 = 0; d2 < Ylen; d2++) {
    fprintf(fp, "%9d ", d2);
  }
  fputs("\n", fp);

  /* Coordinate shifts */
  dnx = d1 - 1;
  i = j - dnx;

  /* Y matrix */
  for (l = sL[j]; l <= sR[j]; l++) {
    sl = l - sL[j];
    fprintf(fp, "%4d%5c ", l, toupper(seqY->seq[l])); 
    dmin = l-sR[i]+1 > 0 ? l-sR[i]+1: 1;
    for (sdy = 0; sdy < ((l-sL[i]+1)-dmin+1); sdy++) {
      fprintf(fp, "%9d ", mx[v][j][dnx][sl][sdy]);
    }
    fputs("\n", fp);
  }
  fflush(stdout);
}

/* Function: printRedXFoldMx
 *
 * How can we print X for a particular Y if we are 
 * mapping X to Y and therefore don't know if a particular
 * Y coordinates are even valid?
 */
