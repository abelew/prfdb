R-entropy computes entropy, mean energy, Helmholtz free energy, standard deviation of energy based on the Turner energy model of secondary structures.

Reference:
"R-entropy: An algorithm for computing thermodynamic entropy of RNA secondary structures"
Hisanori Kiryu and Kiyoshi Asai.
submitted

Install:
$ cd ./src/
$ make
$ cd ..

Example:
$ ./src/rentropy/run_rentropy.exe -outfile=./example/rentropy_out.txt -command=compute_ent_subseq -seqfile=./example/seqs.fa -max_span=200 -length_set=100,200, 

options: -name=<type:default>          : description
  -help=<bool:false>                   : if true, print this help message and exit.
  -outfile=<string:rentropy_out.txt>   : name of output file.
  -command=<string:compute_ent>        : 'compute_ent' prints thermodynamic values for the entire input sequence, 'compute_ent_subseq' prints thermodynamic values for all the sequence windows specified by -length_set
  -seqfile=<string:NO FILE>            : input file in fasta format.
  -max_span=<int:10>                   : maximal base pair span
  -length_set=<VI:50,100,>             : comma delimited numbers representing sequence window sizes.

Output Format:
A tab delimited format with a fasta-like header line for each sequence.
Sequence ranges (start_pos, end_pos) are 0-based, exclusive-end format.
all the values are printed in unit of kcal/mol.
In particular, entropies are printed as (- RT \sum P log P),
where R=1.9872x10^{-3}[kcal/(mol K)] is gas constant, T=310.15[K] is temperature, and P is the Boltzmann probability distribution.
------------------------------------
>sequence_name_1  # header line
start_pos	end_pos	entropy	mean_energy	Helmholtz_free_energy	standard_devidation # five tab delimited columns for each row.
# There is a new line at the end of each table
>sequence_name_2

Output Example:
-----------------------------------------------------------------
>RF01407,STnc560,ABAN01000003.1/243410-243628
119	219	5.374	-38.696	-44.071	1.990
118	218	4.490	-40.224	-44.714	2.180
                 ........
0	200	9.579	-75.000	-84.580	2.922

>RF01085,TLS-PK4,K01778.1/151-266
16	116	4.261	-38.210	-42.471	1.867
                 ........
