/*
 * author: hisanori kiryu
 */
#ifndef RENTROPY__MATRIX_RING_INDEX_HPP
#define RENTROPY__MATRIX_RING_INDEX_HPP
#include "util/util.hpp"
namespace Rentropy { template <typename T> class MatrixRingIndex;}
template <typename T> class Rentropy::MatrixRingIndex {
public:
  typedef MatrixRingIndex Self;
  typedef T               IntT;
  IntT _nrow;
  IntT _ncol;
  IntT _size;
  MatrixRingIndex() : _nrow(0), _ncol(0), _size(0) {}
  bool empty() const { return (_size == 0);}
  IntT size() const { return _size;}
  void set_size(IntT nrow, IntT ncol) {
    _nrow = nrow;
    _ncol = ncol;
    _size = (_nrow * _ncol);
  }
  IntT nrow() const { return _nrow;}
  IntT ncol() const { return _ncol;}
  IntT ref(IntT i, IntT j) const 
  { return (cyclic_index(i, _nrow) * _ncol + cyclic_index(j, _ncol));}
};
#endif
