/*
 * run_rentropy.cpp
 */
#ifndef RUN_RENTROPY__RENTROPY_CPP
#define RUN_RENTROPY__RENTROPY_CPP
#include "rentropy.hpp"
static Rentropy::Rentropy obj;
int main(int argc, char** argv){return Rentropy::Rentropy::main(argc, argv, obj);}
#endif
