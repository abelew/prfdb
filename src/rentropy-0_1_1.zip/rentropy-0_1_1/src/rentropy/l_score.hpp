/*
 * author: hisanori kiryu
 */
#ifndef RENTROPY__L_SCORE_HPP
#define RENTROPY__L_SCORE_HPP
#include "util/util.hpp"
#include "rentropy/score.hpp"
namespace Rentropy { class LScore; class LScores;}
class Rentropy::LScore {
public:
  typedef signed char SignT;
  attr(ScoreT, z);
  attr(SignT , s); // +1 or -1
  LScore() : _z(NEG_INF()), _s(+1) {}
  LScore(const LScore& x) : _z(x._z), _s(x._s) {}
  LScore(ScoreT z, SignT s) : _z(z), _s(s) {}
  LScore(ScoreT x) {
    if (x == 0) { _z = NEG_INF(); _s = (+1);}
    else if (x > 0) { _z = log(x); _s = (+1);}
    else { _z = log(-x); _s = (-1);}
  }
  void assign(ScoreT z, SignT s) { _z = z; _s = s;}
  double value() const { return _s * exp(_z);}
  static void logadd(ScoreT& z, SignT& s, const ScoreT& z1, const SignT& s1) {
    // if (impossible(z1)) return;
    // if (impossible(z)) { z = z1; s = s1; return;}
    if (z == z1) {
      if (s == s1) {
	z += log(2);
      } else {
	z = NEG_INF();
	s = +1;
      }
    } else if (z > z1) {
      if (s == s1) { 
	z += log1p(exp(z1 - z));
      } else {
	z += log(-expm1(z1 - z));
      }
    } else {
      if (s == s1) {
	z = (z1 + log1p(exp(z - z1)));
      } else {
	z = (z1 + log(-expm1(z - z1)));
	s = s1;
      }
    }
  }
  static void logmax(ScoreT& z, SignT& s, const ScoreT& z1, const SignT& s1) {
    if (s < 0) { if (s1 > 0 || z1 < z) { z = z1; s = s1;}}
    else { if (s1 > 0 && z < z1) { z = z1; s = s1;}}
  }
  static void logadd(ScoreT& z, SignT& s, const LScore& x) { logadd(z, s, x.z(), x.s());}
  static void logadd(LScore& x, const LScore& x1) { logadd(x.z(), x.s(), x1.z(), x1.s());}
  static void logsub(ScoreT& z, SignT& s, const ScoreT& z1, const SignT& s1) 
  { logadd(z, s, z1, -s1);}
  static void logsub(ScoreT& z, SignT& s, const LScore& x) { logsub(z, s, x.z(), x.s());}
  static void logsub(LScore& x, const LScore& x1) { logsub(x.z(), x.s(), x1.z(), x1.s());}
  static void logmul(ScoreT& z, SignT& s, const ScoreT& z1, const SignT& s1) { z += z1; s *= s1;}
  static void logmul(ScoreT& z, SignT& s, const LScore& x) { logmul(z, s, x.z(), x.s());}
  static void logmul(LScore& x, const LScore& x1) { logmul(x.z(), x.s(), x1.z(), x1.s());}
  static void logdiv(ScoreT& z, SignT& s, const ScoreT& z1, const SignT& s1) { z -= z1; s *= s1;}
  static void logdiv(ScoreT& z, SignT& s, const LScore& x) { logdiv(z, s, x.z(), x.s());}
  static void logdiv(LScore& x, const LScore& x1) { logdiv(x.z(), x.s(), x1.z(), x1.s());}
  static void logmax(ScoreT& z, SignT& s, const LScore& x) { logmax(z, s, x.z(), x.s());}
  static void logmax(LScore& x, const LScore& x1) { logmax(x.z(), x.s(), x1.z(), x1.s());}

  LScore& operator+=(const LScore& x) { logadd(*this, x); return *this;}
  LScore& operator-=(const LScore& x) { logsub(*this, x); return *this;}
  LScore& operator*=(const LScore& x) { logmul(*this, x); return *this;}
  LScore& operator/=(const LScore& x) { logdiv(*this, x); return *this;}
  LScore& operator=(const LScore& x) { _z = x._z; _s = x._s; return *this;}
  LScore& operator=(const ScoreT& z) { return operator=(LScore(z));}
  LScore  inverse() const { return LScore(-_z, _s);}

  friend LScore operator+(const LScore& x1, const LScore& x2) 
  { LScore x(x1); return (x += x2);}
  friend LScore operator-(const LScore& x1, const LScore& x2) 
  { LScore x(x1); return (x -= x2);}
  friend LScore operator*(const LScore& x1, const LScore& x2) 
  { return LScore(x1.z() + x2.z(), x1.s() * x2.s());}
  friend LScore operator/(const LScore& x1, const LScore& x2) 
  { return LScore(x1.z() - x2.z(), x1.s() * x2.s());}

  friend LScore operator*(const ScoreT& z, const LScore& x) {
    if (z == 0 || impossible(x)) return LScore(NEG_INF(), +1);
    return (z > 0 ? LScore(x.z() + log(z), x.s()) : LScore(x.z() + log(-z), -x.s()));
  }
  friend LScore operator*(const LScore& x, const ScoreT& z) { return (z * x);}
  friend bool impossible(const LScore& x) { return impossible(x.z());}

  friend LScore operator+(const LScore& x) { return x;}
  friend LScore operator-(const LScore& x) { return LScore(x.z(), -x.s());}

  template <typename T1, typename T2> static bool is_equal(const T1& x1, const T2& x2) 
  { return (x1.z() == x2.z() && x1.s() == x2.s());}
  template <typename T1, typename T2> static bool is_less(const T1& x1, const T2& x2) {
    if (x1.s() != x2.s()) return (x1.s() < 0);
    return (x1.s() > 0 ? (x1.z() < x2.z()) : (x2.z() < x1.z()));
  }

  friend bool operator==(const LScore& x1, const LScore& x2) 
  { return LScore::is_equal<LScore, LScore>(x1, x2);}
  friend bool operator!=(const LScore& x1, const LScore& x2) { return !(x1 == x2);}
  friend bool operator<(const LScore& x1, const LScore& x2) 
  { return LScore::is_less<LScore, LScore>(x1, x2);}
  friend bool operator>(const LScore& x1, const LScore& x2) { return (x2 < x1);}
  friend bool operator<=(const LScore& x1, const LScore& x2) { return !(x2 < x1);}
  friend bool operator>=(const LScore& x1, const LScore& x2) { return !(x1 < x2);}

  template <typename T> void set_max(const T& x) { logmax(z(), s(), x.z(), x.s());}
};
class Rentropy::LScores : public LScore {
public:
  typedef vector<ScoreT> VZ;
  typedef vector<SignT>  VS;
  typedef ptrdiff_t      IntT;
  typedef LScore         value_type;
  class Reference {
  public:
    Reference() : _z(0), _s(0) {}
    Reference(const Reference& x) : _z(x._z), _s(x._s) {}
    ~Reference() {}
    Reference(ScoreT& z, SignT& s) : _z(&z), _s(&s) {}
    Reference& operator=(const Reference& x) { (*_z) = x.z(); (*_s) = x.s(); return *this;}
    Reference& operator=(const LScore& x) { (*_z) = x.z(); (*_s) = x.s(); return *this;}
    Reference& operator=(const ScoreT& x) { return operator=(LScore(x));}
    operator LScore() const { return LScore(z(), s());}

    Reference& operator+=(const LScore& x) { logadd(z(), s(), x.z(), x.s()); return *this;}
    Reference& operator-=(const LScore& x) { logsub(z(), s(), x.z(), x.s()); return *this;}
    Reference& operator*=(const LScore& x) { logmul(z(), s(), x.z(), x.s()); return *this;}
    Reference& operator/=(const LScore& x) { logdiv(z(), s(), x.z(), x.s()); return *this;}

    friend LScore operator+(const Reference& x, const Reference& t) 
    { return (LScore(x) + LScore(t));}
    template <typename T> friend LScore operator+(const Reference& x, const T& t) 
    { return (LScore(x) + LScore(t));}
    template <typename T> friend LScore operator+(const T& t, const Reference& x)
    { return (LScore(t) + LScore(x));}
    friend LScore operator-(const Reference& x, const Reference& t) 
    { return (LScore(x) - LScore(t));}
    template <typename T> friend LScore operator-(const Reference& x, const T& t) 
    { return (LScore(x) - LScore(t));}
    template <typename T> friend LScore operator-(const T& t, const Reference& x)
    { return (LScore(t) - LScore(x));}
    friend LScore operator*(const Reference& x, const Reference& t) 
    { return (LScore(x) * LScore(t));}
    template <typename T> friend LScore operator*(const Reference& x, const T& t) 
    { return (LScore(x) * LScore(t));}
    template <typename T> friend LScore operator*(const T& t, const Reference& x)
    { return (LScore(x) * LScore(t));}
    friend LScore operator/(const Reference& x, const Reference& t) 
    { return (LScore(x) / LScore(t));}
    template <typename T> friend LScore operator/(const Reference& x, const T& t) 
    { return (LScore(x) / LScore(t));}
    template <typename T> friend LScore operator/(const T& t, const Reference& x)
    { return (LScore(t) / LScore(x));}
    friend LScore operator-(const Reference& x) { return LScore(x.z(), -x.s());}
    friend LScore operator+(const Reference& x) { return LScore(x);}

    // comparison functions and set_max function // should have had trait abstraction ?
    friend bool operator==(const Reference& x1, const Reference& x2) 
    { return LScore::is_equal<Reference, Reference>(x1, x2);}
    friend bool operator!=(const Reference& x1, const Reference& x2) { return !(x1 == x2);}
    friend bool operator<(const Reference& x1, const Reference& x2) 
    { return LScore::is_less<Reference, Reference>(x1, x2);}
    friend bool operator>(const Reference& x1, const Reference& x2) { return (x2 < x1);}
    friend bool operator<=(const Reference& x1, const Reference& x2) { return !(x2 < x1);}
    friend bool operator>=(const Reference& x1, const Reference& x2) { return !(x1 < x2);}

    friend bool operator==(const Reference& x1, const LScore& x2) 
    { return LScore::is_equal<Reference, LScore>(x1, x2);}
    friend bool operator!=(const Reference& x1, const LScore& x2) { return !(x1 == x2);}
    friend bool operator<(const Reference& x1, const LScore& x2) 
    { return LScore::is_less<Reference, LScore>(x1, x2);}
    friend bool operator>(const Reference& x1, const LScore& x2) { return (x2 < x1);}
    friend bool operator<=(const Reference& x1, const LScore& x2) { return !(x2 < x1);}
    friend bool operator>=(const Reference& x1, const LScore& x2) { return !(x1 < x2);}

    friend bool operator==(const LScore& x1, const Reference& x2) 
    { return LScore::is_equal<LScore, Reference>(x1, x2);}
    friend bool operator!=(const LScore& x1, const Reference& x2) { return !(x1 == x2);}
    friend bool operator<(const LScore& x1, const Reference& x2) 
    { return LScore::is_less<LScore, Reference>(x1, x2);}
    friend bool operator>(const LScore& x1, const Reference& x2) { return (x2 < x1);}
    friend bool operator<=(const LScore& x1, const Reference& x2) { return !(x2 < x1);}
    friend bool operator>=(const LScore& x1, const Reference& x2) { return !(x1 < x2);}
   
    template <typename T> void set_max(const T& x) { logmax(z(), s(), x.z(), x.s());}

    ScoreT& z() const { return (*_z);}
    SignT& s() const { return (*_s);}
    ScoreT value() const { return LScore(z(), s()).value();}
  private:
    ScoreT* _z;
    SignT*  _s;
  };
 
  typedef Reference reference;
  typedef LScore    const_reference;
  VZ _vz;
  VS _vs;
  LScores() {}
  void resize(size_t n, const LScore& x = LScore()) { _vz.resize(n, x.z()); _vs.resize(n, x.s());}
  LScores& assign(size_t n, const LScore& x) 
  { _vz.assign(n, x.z()); _vs.assign(n, x.s()); return *this;}
  void fill(const LScore& x) { vfill(_vz, x.z()); vfill(_vs, x.s());}
  void clear() { _vz.clear(); _vs.clear();}
  bool empty() const { return _vz.empty();}
  size_t size() const { return _vz.size();}
  reference operator[](IntT i) { return reference(_vz[i], _vs[i]);}
  const_reference operator[](IntT i) const { return const_reference(_vz[i], _vs[i]);}

  class const_iterator 
    : public std::iterator<random_access_iterator_tag, LScore, ptrdiff_t, void, const_reference> {
  public:
    typedef const_iterator     Self;
    typedef ptrdiff_t          IntT;
    typedef VZ::const_iterator ZI;
    typedef VS::const_iterator SI;
    // forward iterator
    const_iterator() : _zi(), _si() {}
    const_iterator(const Self& it) : _zi(it._zi), _si(it._si) {}
    const_iterator(const LScores& v, IntT i) : _zi(&v._vz[i]), _si(&v._vs[i]) {}
    const_iterator(const ZI& zi, const SI& si) : _zi(zi), _si(si) {}
    Self& operator=(const Self& it) { _zi = it._zi; _si = it._si; return *this;}
    const_reference operator*() const { return const_reference(z(), s());}
    // pointer operator->() {}
    Self& operator++() { ++_zi; ++_si; return *this;}
    Self operator++(int) { Self tmp(*this); operator++(); return tmp;}
    bool operator==(const Self& it) const { return (_zi == it._zi);}
    bool operator!=(const Self& it) const { return !(*this == it);}
    // bidirectional iterator
    Self& operator--() { --_zi; --_si; return *this;}
    Self operator--(int) { Self tmp(*this); operator--(); return tmp;}
    // random_access_iterator
    const_reference operator[](IntT i) const { return *(*this + i);}
    Self& operator+=(IntT i) { _zi += i; _si += i; return *this;}
    Self& operator-=(IntT i) { return operator+=(-i);}
    Self operator+(IntT i) const { Self tmp(*this); return (tmp += i);}
    Self operator-(IntT i) const { Self tmp(*this); return (tmp -= i);}
    IntT operator-(const Self& it) const { return (_zi - it._zi);}
    bool operator<(const Self& it) const { return (_zi < it._zi);}
    bool operator>(const Self& it) const { return (it < *this);}
    bool operator<=(const Self& it) const { return !(it < *this);}
    bool operator>=(const Self& it) const { return !(*this < it);}
    const ScoreT& z() const { return (*_zi);}
    const SignT& s() const { return (*_si);}
  private:
    ZI _zi;
    SI _si;
  };
  class iterator 
    : public std::iterator<random_access_iterator_tag, LScore, ptrdiff_t, void, Reference> {
  public:
    typedef iterator     Self;
    typedef ptrdiff_t    IntT;
    typedef VZ::iterator ZI;
    typedef VS::iterator SI;
    // forward iterator
    iterator() : _zi(), _si() {}
    iterator(const Self& it) : _zi(it._zi), _si(it._si) {}
    iterator(const ZI& zi, const SI& si) : _zi(zi), _si(si) {}
    iterator(LScores& v, IntT i) : _zi(&v._vz[i]), _si(&v._vs[i]) {}
    Self& operator=(const Self& it) { _zi = it._zi; _si = it._si; return *this;}
    Reference operator*() { return Reference(z(), s());}
    // pointer operator->() {}
    Self& operator++() { ++_zi; ++_si; return *this;}
    Self operator++(int) { Self tmp(*this); operator++(); return tmp;}
    bool operator==(const Self& it) const { return (_zi == it._zi);}
    bool operator!=(const Self& it) const { return !(*this == it);}
    // bidirectional iterator
    Self& operator--() { --_zi; --_si; return *this;}
    Self operator--(int) { Self tmp(*this); operator--(); return tmp;}
    // random_access_iterator
    Reference operator[](IntT i) { return *(*this + i);}
    Self& operator+=(IntT i) { _zi += i; _si += i; return *this;}
    Self& operator-=(IntT i) { return operator+=(-i);}
    Self operator+(IntT i) const { Self tmp(*this); return (tmp += i);}
    Self operator-(IntT i) const { Self tmp(*this); return (tmp -= i);}
    IntT operator-(const Self& it) const { return (_zi - it._zi);}
    bool operator<(const Self& it) const { return (_zi < it._zi);}
    bool operator>(const Self& it) const { return (it < *this);}
    bool operator<=(const Self& it) const { return !(it < *this);}
    bool operator>=(const Self& it) const { return !(*this < it);}
    operator const_iterator() const 
    { return const_iterator(VZ::const_iterator(_zi), VS::const_iterator(_si));}
    ScoreT& z() const { return (*_zi);}
    SignT& s() const { return (*_si);}
  private:
    ZI _zi;
    SI _si;
  };
  
  const_iterator begin() const { return const_iterator(_vz.begin(), _vs.begin());}
  const_iterator end() const { return const_iterator(_vz.end(), _vs.end());}
  const_iterator iter(const IntT& i) const { return const_iterator(*this, i);}
  const_reference front() const { return *begin();}
  const_reference back() const { return *(end() - 1);}

  iterator begin() { return iterator(_vz.begin(), _vs.begin());}
  iterator end() { return iterator(_vz.end(), _vs.end());}
  iterator iter(const IntT& i) { return iterator(*this, i);}
  reference front() { return *begin();}
  reference back() { return *(end() - 1);}
};
#endif
