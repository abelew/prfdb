/*
 * author: hisanori kiryu
 */
#ifndef RENTROPY__RENTROPY_HPP
#define RENTROPY__RENTROPY_HPP
#include "util/util.hpp"
#include "rentropy/prob_model.hpp"
namespace Rentropy { class Rentropy;}
class Rentropy::Rentropy {
public:
  typedef Rentropy          Self;
  typedef Alpha::CodeT     CodeT;
  typedef Alpha::Codes     Seq;
  typedef vector<ScoreT>   V;
  typedef ScoreModel       SM;
  typedef ProbModel<false> PM;
  typedef PM::IntT         IntT;
  typedef vector<IntT>     VI;
  class PrintDeDf {
  public:
    ostream*       _fo;
    ostringstream* _os;
    IntT           _buf_size;
    const VI*      _len_frag;
    PrintDeDf(ostream& fo, ostringstream& os, const VI& len_frag) 
      : _fo(&fo), _os(&os), _buf_size(1000000), _len_frag(&len_frag) {}
    ~PrintDeDf() { flush_buf();}
    ostream& os() { return (*_os);}
    void seq_start(const string& name, const int& seqlen) { os() << '>' << name << '\n';}
    void seq_finish() { os() << '\n';}
    void flush_buf() { (*_fo) << _os->str(); _os->str("");}
    void operator()(int i, int j, const V& ve, const V& vz) {
      if (!((*_len_frag).empty() || (*_len_frag)[j - i])) return;
      if (_buf_size <= os().tellp()) { flush_buf();}
      double mu = ve[0];
      double sd = ve[1];
      double fe = vz[0];
      double ts = (mu - fe);
      print_row(os(), i, j, ts, mu, fe, sd);
    }
  };
  Seq _seq;
  SM  _sm;
  PM  _pm;
  VI  _len_frag;
  void run() {
    init_model();
    if      (_command == "compute_ent"       ) { compute_ent(); }
    else if (_command == "compute_ent_subseq") { compute_ent_subseq();  }
    else if (_command == "test"              ) { test();         }
    else { Die("bad command %s", _command.c_str());}
  }
  void init_model() {
    double length_factor = -0.541728723;
    _sm.initialize();
    _sm.set_param("external_unpaired"            , length_factor);
    _sm.set_param("external_paired_length_factor", length_factor);
    _pm.set_score_model(_sm);
    _pm.set_max_span(_max_span);
    _pm.set_length_factor(length_factor);
    if (!_length_set.empty()) {
      _len_frag.clear();
      for (IntT i = 0; i < (IntT)_length_set.size(); ++i) {
	if ((IntT)_len_frag.size() <= _length_set[i]) { _len_frag.resize(_length_set[i] + 1, 0);}
	_len_frag[_length_set[i]] = 1;
      }
      _pm.set_max_ene_span(_len_frag.size() - 1);
    }
  }
  void compute_ent() {
    ofstream_(fo, _outfile);
    ostringstream os;
    _len_frag.clear();
    PrintDeDf pdd(fo, os, _len_frag);
    ifstream_(fi, _seqfile);
    for (FastaIter i = FastaIter(fi); i != FastaIter(); ++i) {
      pdd.seq_start(i.name(), i.seq().size());
      _seq.resize(i.seq().size());
      Alpha::str_to_ncodes(i.seq().begin(), i.seq().end(), _seq.begin());
      compute_ene0(_seq, pdd);
      pdd.seq_finish();
    }
  }
  void compute_ent_subseq() {
    Check(!_length_set.empty());
    ofstream_(fo, _outfile);
    ostringstream os;
    PrintDeDf pdd(fo, os, _len_frag);
    ifstream_(fi, _seqfile);
    for (FastaIter i = FastaIter(fi); i != FastaIter(); ++i) {
      pdd.seq_start(i.name(), i.seq().size());
      _seq.resize(i.seq().size());
      Alpha::str_to_ncodes(i.seq().begin(), i.seq().end(), _seq.begin());
      compute_ene(_seq, pdd);
      pdd.seq_finish();
    }
  }
  template <typename Block> void compute_ene0(const Seq& seq, Block block) 
  { _sm.set_seq(seq); _pm.compute_ene0(block);}
  template <typename Block> void compute_ene(const Seq& seq, Block block) 
  { _sm.set_seq(seq); _pm.compute_ene(block);}
  void test() {
    test_ene();
  }
  class TestResults {
  public:
    TestResults() {}
    typedef pair<int, int> PI;
    typedef pair<V, V>     PD;
    typedef map<PI, PD>     Data;
    Data* _data;
    TestResults(Data& data) : _data(&data) {}
    void operator()(int i, int j, const V& ve, const V& vz) { 
      data()[PI(i, j)] = PD(ve, vz);
    }
    Data& data() { return (*_data);}
    void print(ostream& fo) {
      for (Data::const_iterator i = data().begin(); i != data().end(); ++i) {
	fo << i->first.first << '\t' << i->first.second << '\t';
	save_vec(fo, i->second.first); fo << '\t';
	save_vec(fo, i->second.second); fo << '\n';
      }
      cout << endl;
    }  
  };
  void test_ene() {
    typedef TestResults::PI   PI;
    typedef TestResults::PD   PD;
    typedef TestResults::Data Data;
    string _test_seq = "ACGGTT";
    int _max_ene_span = (_len_frag.size() - 1);
    const string& str = _test_seq;
    _seq.resize(str.size());
    Alpha::str_to_ncodes(str.begin(), str.end(), _seq.begin());
    Data data;
    TestResults tr(data);
    compute_ene(_seq, tr);
    // tr.print(cout);
    for (int i = 0; i < (int)_seq.size(); ++i) {
      for (int j = (i + 1); j <= min((i + _max_ene_span), (int)_seq.size()); ++j) {
	_seq.resize(j - i);
	Alpha::str_to_ncodes(str.begin() + i, str.end(), _seq.begin());
	Data data1;
	TestResults tr1(data1);
	compute_ene0(_seq, tr1);
	double e0  = 0;
	double e20 = 0;
	double z0  = NEG_INF();
	if (tr.data().find(PI(i, j)) != tr.data().end()) {
	  e0  = tr.data()[PI(i, j)].first[0];
	  e20 = tr.data()[PI(i, j)].first[1];
	  z0  = tr.data()[PI(i, j)].second[0];
	}
	double e1  = tr1.data()[PI(0, _seq.size())].first[0];
	double e21 = tr1.data()[PI(0, _seq.size())].first[1];
	double z1  = tr1.data()[PI(0, _seq.size())].second[0];
	double e_err = ((e0 - e1) / (1 + abs(e0) + abs(e1)));
	double e2_err = ((e20 - e21) / (1 + abs(e20) + abs(e21)));
	double z_err = ((z0 - z1) / (1 + abs(z0) + abs(z1)));
	double eps = 1e-12;
	if (abs(e_err) < eps && abs(e2_err) < eps && abs(z_err) < eps) continue;
	cout << i         << ' ' << j         << ' ' 
	     << e0        << ' ' << e1        << ' '
	     << e20        << ' ' << e21        << ' '
	     << z0        << ' ' << z1        << ' '
	     << e_err << ' ' 
	     << e2_err << ' ' 
	     << z_err << '\n';
      }
    }
  }
#define opt_items() \
  opt_item(help         , bool  , "false", "if true, print this help message and exit.") \
  opt_item(outfile      , string, "rentropy_out.txt", "name of output file.") \
  opt_item(command      , string, "compute_ent"     , "'compute_ent' prints thermodynamic values for the entire input sequence, 'compute_ent_subseq' prints thermodynamic values for all the sequence windows specified by -length_set") \
  opt_item(seqfile      , string, "NO FILE"         , "input file in fasta format.") \
  opt_item(max_span     , int   , "10"              , "maximal base pair span") \
  opt_item(length_set   , VI    , "50,100,"         , "comma delimited numbers representing sequence window sizes.") \

#include "util/def_opt_main.hpp"
#undef opt_items
};
#endif
