/*
 * author: hisanori kiryu
 */
#ifndef RENTROPY__PROB_MODEL_HPP
#define RENTROPY__PROB_MODEL_HPP
#include "util/util.hpp"
#include "util/tensor_index.hpp"
#include "rentropy/score.hpp"
#include "rentropy/l_score.hpp"
#include "rentropy/tri_matrix_index.hpp"
#include "rentropy/matrix_ring_index.hpp"
// #define USE_SCORE_MODEL_CONTRAFOLD
#if defined(USE_SCORE_MODEL_CONTRAFOLD)
#include "rentropy/score_model_contrafold.hpp"
typedef Rentropy::ScoreModelContrafold ScoreModel;
#else
#include "rentropy/score_model_energy.hpp"
typedef Rentropy::ScoreModelEnergy ScoreModel;
#endif
#define COMPUTE_VARIATION
namespace Rentropy { template <bool ZeroT> class ProbModel;}
template <bool ZeroT> class Rentropy::ProbModel {
public:
  typedef ProbModel                Self;
  typedef ProbModel                PM;
  typedef ScoreModel               SM;
  typedef SM::IntT                 IntT;
  typedef Alpha::CodeT             CodeT;
  typedef SM::Transition           Transition;
  typedef SM::TrType               TrType;
  typedef SM::OpType               OpType;
  typedef vector<ScoreT>           V;
  typedef vector<IntT>             VI;
  typedef TriMatrixIndex<IntT>     PairIndex;
  typedef TensorIndex<IntT, false> SingleIndex;
  typedef TensorIndex<IntT, false> OuterIndex;
  enum { _nsymb = Alpha::NNCODE };
  class DPMatrix {
  public:
    typedef LScores            V;
    typedef V::value_type      value_type;
    typedef V::reference       reference;
    typedef V::const_reference const_reference;
    typedef V::iterator        iterator;
    typedef V::const_iterator  const_iterator;
    PairIndex*   _pi;
    SingleIndex* _si;
    SingleIndex* _s1i;
    OuterIndex*  _oi;
    attr(V, p );
    attr(V, s );
    attr(V, s1);
    attr(V, o );
    DPMatrix() : _pi(0), _si(0), _s1i(0), _oi(0) {}
    void set_matrix_index(PairIndex& pi, SingleIndex& si, SingleIndex& s1i, OuterIndex& oi,
			  ScoreT z = 0) {
      _pi  = &pi;
      _si  = &si;
      _s1i = &s1i;
      _oi  = &oi;
      if (_pi ) { _p.assign(_pi->size(), LScore(z));  } else { _p.clear(); }
      if (_si ) { _s.assign(_si->size(), LScore(z));  } else { _s.clear(); }
      if (_s1i) { _s1.assign(_s1i->size(), LScore(z));} else { _s1.clear();}
      if (_oi ) { _o.assign(_oi->size(), LScore(z));  } else { _o.clear(); }
    }
    void fill_p(ScoreT z) { _p.fill(LScore(z));}
    void fill_s(ScoreT z) { _s.fill(LScore(z));}
    void fill_s1(ScoreT z) { _s1.fill(LScore(z));}
    void fill_o(ScoreT z) { _o.fill(LScore(z));}
    reference ref_p(IntT k, IntT i, IntT j)  
    { IntT n = _pi->ref(k, i, j); Assert(0 <= n && n < (IntT)_p.size()); return _p[n];}
    reference ref_s(IntT s, IntT h, IntT i)  
    { IntT n = _si->ref(s, h, i); Assert(0 <= n && n < (IntT)_s.size()); return _s[n];}
    reference ref_s1(IntT s, IntT h, IntT i) 
    { IntT n = _s1i->ref(s, h, i); Assert(0 <= n && n < (IntT)_s1.size()); return _s1[n];}
    reference ref_o(IntT h, IntT i)          
    { IntT n = _oi->ref(h, i); Assert(0 <= n && n < (IntT)_o.size()); return _o[n];}

    const_reference ref_p(IntT k, IntT i, IntT j) const
    { IntT n = _pi->ref(k, i, j); Assert(0 <= n && n < (IntT)_p.size()); return _p[n];}
    const_reference ref_s(IntT s, IntT h, IntT i) const
    { IntT n = _si->ref(s, h, i); Assert(0 <= n && n < (IntT)_s.size()); return _s[n];}
    const_reference ref_s1(IntT s, IntT h, IntT i) const
    { IntT n = _s1i->ref(s, h, i); Assert(0 <= n && n < (IntT)_s1.size()); return _s1[n];}
    const_reference ref_o(IntT h, IntT i) const         
    { IntT n = _oi->ref(h, i); Assert(0 <= n && n < (IntT)_o.size()); return _o[n];}

    iterator iter_p(IntT k, IntT i, IntT j)  
    { IntT n = _pi->ref(k, i, j); Assert(0 <= n && n < (IntT)_p.size()); return _p.iter(n);}
    iterator iter_s(IntT s, IntT h, IntT i)  
    { IntT n = _si->ref(s, h, i); Assert(0 <= n && n < (IntT)_s.size()); return _s.iter(n);}
    iterator iter_s1(IntT s, IntT h, IntT i) 
    { IntT n = _s1i->ref(s, h, i); Assert(0 <= n && n < (IntT)_s1.size()); return _s1.iter(n);}
    iterator iter_o(IntT h, IntT i)          
    { IntT n = _oi->ref(h, i); Assert(0 <= n && n < (IntT)_o.size()); return _o.iter(n);}

    const_iterator iter_p(IntT k, IntT i, IntT j) const
    { IntT n = _pi->ref(k, i, j); Assert(0 <= n && n < (IntT)_p.size()); return _p.iter(n);}
    const_iterator iter_s(IntT s, IntT h, IntT i) const
    { IntT n = _si->ref(s, h, i); Assert(0 <= n && n < (IntT)_s.size()); return _s.iter(n);}
    const_iterator iter_s1(IntT s, IntT h, IntT i) const
    { IntT n = _s1i->ref(s, h, i); Assert(0 <= n && n < (IntT)_s1.size()); return _s1.iter(n);}
    const_iterator iter_o(IntT h, IntT i) const         
    { IntT n = _oi->ref(h, i); Assert(0 <= n && n < (IntT)_o.size()); return _o.iter(n);}
  };
  typedef DPMatrix       DPM;
  typedef typename DPM::reference DPRef;
  typedef LScore::SignT  SignT;
  template <typename T, typename T1, typename T2> void add_prod(T& t, const T1& t1, const T2& t2) {
    if (ZeroT) { LScore::logmax(t.z(), t.s(), (t1.z() + t2.z()), (t1.s() * t2.s()));}
    else { LScore::logadd(t.z(), t.s(), (t1.z() + t2.z()), (t1.s() * t2.s()));} // { t += ((*i1) * (*i2));} // slower
  }
  template <typename T, typename Iter> void dot_pp(T& t, IntT n, Iter i1, Iter i2) 
  { while (n-- > 0) { add_prod(t, i1, i2); ++i1; ++i2;}}
  template <typename T, typename Iter> void dot_pm(T& t, IntT n, Iter i1, Iter i2) 
  { while (n-- > 0) { add_prod(t, i1, i2); ++i1; --i2;}}
  template <typename T, typename Iter> void dot_mp(T& t, IntT n, Iter i1, Iter i2) 
  { while (n-- > 0) { add_prod(t, i1, i2); --i1; ++i2;}}
  template <typename T, typename Iter> void dot_mm(T& t, IntT n, Iter i1, Iter i2)
  { while (n-- > 0) { add_prod(t, i1, i2); --i1; --i2;}}
  template <bool fwd> class FnInside {
  public:
    PM&  _pm;
    DPM* _inside;
    FnInside(PM& pm) : _pm(pm), _inside(0) {}
    void set_inside(DPM& inside) { _inside = &inside;}
    DPM& inside() { return *_inside;}
    void before_transition(IntT i, IntT j) {
      for (IntT s = 0; s < _pm.sm().nstate(); ++s) {
	for (IntT h = 0; h < _pm.sm().nop_type(); ++h) {
	  _pm.cur_sc(s, h) = 0;
	}
      }
    }
    void after_transition(IntT i, IntT j) {
      for (IntT s = 0; s < _pm.sm().nstate(); ++s) {
	for (IntT h = 0; h < _pm.sm().nop_type(); ++h) {
	  LScore sc = _pm.cur_sc(s, h);
	  if (impossible(sc)) { sc = 0;}
	  inside().ref_s(s, h, (j - i)) = sc;
	  IntT k = _pm.sm().layer_in(s, h);
	  if (k >= 0) { 
	    inside().ref_p(k, i, j) = sc;
	  }
	}
	// _pm.print_cur_sc(cout, (fwd ? "fn_inside_f" : "fn_inside_b"), i, j, s); // for test
      }
    }
    void on_transition(TrType type, IntT i, IntT j, IntT k, IntT l) {
      const Transition& t = _pm.sm().transitions(type);
      if (t.bf()) {
	IntT m = (l - k + 1);
	if (m > 0) {
	  // for (IntT m = k; m <= l; ++m) {
	  //   ScoreT sc1 = (_pm.inside_p(t.to(), i, m) + _pm.inside_p(t.to1(), m, j, false));
	  //   LOGADD(sc, sc1);
	  // }
	  for (IntT r = 0; r < _pm.sm().nop_transitions(); ++r) {
	    const OpType* h = _pm.sm().op_transitions(r);
	    LScore sc = 0;
	    if (fwd) {
	      _pm.dot_pm(sc, m, inside().iter_p(_pm.sm().layer_in(t.to(), h[1]), i, k),
			 inside().iter_s(t.to1(), h[2], (j - k)));
	    } else {
	      _pm.dot_pp(sc, m, inside().iter_s(t.to(), h[1], (k - i)),
			 inside().iter_p(_pm.sm().layer_in(t.to1(), h[2]), k, j));
	    }
	    if (h[1] == SM::OT_ENE && h[2] == SM::OT_ENE) {
	      _pm.add_cur_sc(t.from(), h[0], (2 * sc));
	    } else {
	      _pm.add_cur_sc(t.from(), h[0], sc);
	    }
	  }
	}
      } else {
	ScoreT tsc = _pm.sm().tsc(type, i, j, k, l);
	add_sc_tsc(t, i, j, k, l, tsc);
      }
    }
    void add_sc_tsc(const Transition& t, IntT i, IntT j, IntT k, IntT l, ScoreT tsc) {
      if (impossible(tsc)) return;
      for (IntT h = 0; h < _pm.sm().nop_type(); ++h) {
	const LScore& sc = (LScore(tsc, +1) * _pm.sc_in(inside(), t, k, l, h));
	_pm.add_cur_sc(t.from(), h, sc);
	switch (h) {
	case SM::OT_NONE:
	  _pm.add_cur_sc(t.from(), SM::OT_ENE, (tsc * sc));
	  _pm.add_cur_sc(t.from(), SM::OT_ENE2, ((tsc * tsc) * sc));
	  break;
	case SM::OT_ENE:
	  _pm.add_cur_sc(t.from(), SM::OT_ENE2, ((2 * tsc) * sc));
	  break;
	default: break;
	}
      }
    }
  };
  template <bool fwd> class FnForward {
  public:
    PM&  _pm;
    DPM* _inside;
    FnForward(PM& pm) : _pm(pm), _inside(0) {}
    void set_inside(DPM& inside) { _inside = &inside;}
    DPM& inside() { return *_inside;}
    void before_transition(IntT i, IntT j) {
      for (IntT h = 0; h < _pm.sm().nop_type(); ++h) {
	if (j <= (i + _pm.width())) { 
	  _pm.cur_sc(SM::INNER_BEG, h) = inside().ref_s(SM::INNER_BEG, h, (j - i));
	} else { 
	  _pm.cur_sc(SM::INNER_BEG, h) = 0;
	}
	_pm.cur_sc(SM::OUTER, h) = 0;
      }
    }
    void after_transition(IntT i, IntT j) {
      for (IntT h = 0; h < _pm.sm().nop_type(); ++h) {
	LScore sc = _pm.cur_sc(SM::OUTER, h);
	if (impossible(sc)) { sc = 0;}
	inside().ref_o(h, j) = sc;
	// _pm.print_cur_sc(cout, "fn_forward", i, j, SM::OUTER); // for test
      }
    }
    void on_transition(TrType type, IntT i, IntT j, IntT k, IntT l) {
      const Transition& t = _pm.sm().transitions(type);
      if (t.bf()) {
	IntT m = (l - k + 1);
	if (m > 0) {
	  // for (IntT m = k; m <= l; ++m) {
	  //   ScoreT sc1 = (_pm.inside_o(m) + _pm.inside_p(t.to1(), m, j, false));
	  //   LOGADD(sc, sc1);
	  // }
	  for (IntT r = 0; r < _pm.sm().nop_transitions(); ++r) {
	    const OpType* h = _pm.sm().op_transitions(r);
	    LScore sc = 0; // how to treat m <= 2 ?
	    if (fwd) {
	      _pm.dot_pm(sc, m, inside().iter_o(h[1], k), 
			 inside().iter_s(t.to1(), h[2], (j - k)));
	    } else {
	      _pm.dot_pp(sc, m, inside().iter_o(h[1], k),
			 inside().iter_p(_pm.sm().layer_in(t.to1(), h[2]), k, j));
	    }
	    if (h[1] == SM::OT_ENE && h[2] == SM::OT_ENE) {
	      _pm.add_cur_sc(t.from(), h[0], (2 * sc));
	    } else {
	      _pm.add_cur_sc(t.from(), h[0], sc);
	    }
	  }
	}
      } else { // OUTER -> OUTER_END, OUTER -> OUTER 
	ScoreT tsc = _pm.sm().tsc(type, i, j, k, l);
	add_sc_tsc(t, i, j, k, l, tsc);
      }
    }
    void add_sc_tsc(const Transition& t, IntT i, IntT j, IntT k, IntT l, ScoreT tsc) {
      if (impossible(tsc)) return;
      for (IntT h = 0; h < _pm.sm().nop_type(); ++h) {
	const LScore& sc = (LScore(tsc, +1) * _pm.sc_in(inside(), t, k, l, h));
	_pm.add_cur_sc(t.from(), h, sc);
	switch (h) {
	case SM::OT_NONE:
	  _pm.add_cur_sc(t.from(), SM::OT_ENE, (tsc * sc));
	  _pm.add_cur_sc(t.from(), SM::OT_ENE2, ((tsc * tsc) * sc));
	  break;
	case SM::OT_ENE:
	  _pm.add_cur_sc(t.from(), SM::OT_ENE2, ((2 * tsc) * sc));
	  break;
	default: break;
	}
      }
    }
  };
  SM*           _sm;
  IntT          _max_span;
  IntT          _max_ene_span;
  double        _length_factor;
  IntT          _seqlen; // seqpos in 1..seqlen,  dppos 0..seqlen
  IntT          _width;
  IntT          _period;
  IntT          _block_len;

  LScore        _mean_energy;
  LScore        _var_energy;
  LScore        _part_coeff;

  SingleIndex   _si_cur_sc;
  LScores       _cur_sc;

  PairIndex     _pi_in;
  SingleIndex   _si_in;
  OuterIndex    _oi_in;

  DPM           _inside;

  V             _ene_tmp;
  V             _var_tmp;
  V             _z_tmp;

  FnForward<true>  _fn_forward_f;
  FnForward<false> _fn_forward_b;
  FnInside<true>   _fn_inside_f;
  FnInside<false>  _fn_inside_b;
  ProbModel() : _length_factor(0), _fn_forward_f(*this), _fn_forward_b(*this), 
		_fn_inside_f(*this), _fn_inside_b(*this) {}
  ScoreModel& sm() { return *_sm;}
  void set_score_model(SM& sm) { _sm = &sm;}
  void set_max_span(const IntT& z) { _max_span = z;}
  void set_length_factor(double z) { _length_factor = z;}
  void set_max_ene_span(const IntT& z) { _max_ene_span = z;}
  IntT max_ene_span() const { return _max_ene_span;}
  IntT seqlen() { return _seqlen;}
  IntT width() { return _width;}
  IntT period() { return _period;}
  IntT block_len() { return _block_len;}
  CodeT seq(IntT i) { return sm().seq(i);}
  DPRef cur_sc(IntT s, IntT h) 
  { IntT n = _si_cur_sc.ref(s, h); Assert(0 <= n && n < (IntT)_cur_sc.size()); return _cur_sc[n];}
  void add_cur_sc(IntT s, IntT h, const LScore& sc) {
    if (ZeroT) { cur_sc(s, h).set_max(sc);} // only partition function has meaning mean energy has no meaning
    else { cur_sc(s, h) += sc;}
  }
  void print_cur_sc(ostream& fo, const string& tag, IntT i, IntT j, IntT s) {
    if (true) {
      const LScore& z  = LScore(cur_sc(s, SM::OT_NONE));
      const LScore& e  = LScore(cur_sc(s, SM::OT_ENE));
      const LScore& e2 = LScore(cur_sc(s, SM::OT_ENE2));
      fo << "cur_sc: " << tag << "," << i << "," << j << "," << sm().states(s).name() << ","
	 << setprecision(6) << z.value() << "," << e.value() << "," << e2.value() << "\n";
    }
  }
  DPM& inside() { return _inside;}
#if false
  IntT max_block() { return 10;} // for test
#else
  IntT max_block() { return 10000;}
#endif
  IntT compute_width(IntT max_span, IntT seqlen)
  { return (max_span > 0 ? std::min(max_span, seqlen) : seqlen);}
  IntT compute_period(IntT max_ene_span, IntT width) 
  { return max(1 * _width, (max_ene_span > 1 ? max_ene_span : 0));}
  IntT compute_block_len(IntT max_block, IntT period, IntT width, IntT seqlen) 
  { return min(seqlen, max(period, max_block));}
  void set_seqlen_width_period_block_len() {
    _seqlen    = sm().seqlen();
    _width     = compute_width(_max_span, _seqlen);
    _period    = compute_period(_max_ene_span, _width);
    _block_len = compute_block_len(max_block(), _period, _width, _seqlen);
  }
  void init_cur_sc() {
    _si_cur_sc.set_size(sm().nstate0(), sm().nop_type());
    _cur_sc.assign(_si_cur_sc.size(), LScore(0));
    for (IntT s = sm().nstate1(); s < sm().nstate0(); ++s) { // HAIRPIN_END,OUTER_BEG,OUTER_END
      cur_sc(s, SM::OT_NONE) = 1;
    }
  }
  template <typename Block> void compute_ene(Block block) {
    set_seqlen_width_period_block_len();
    compute_backward(proc_l(&Self::template compute_backward_block_len<Block>, *this, block));
  }
  template <typename Block> void compute_ene0(Block block) {
    set_seqlen_width_period_block_len();
    _part_coeff  = 0;
    _mean_energy = 0;
    _var_energy = 0;
    set_seqlen_width_period_block_len();
    compute_forward();
    _ene_tmp.assign(2, 0);
    _z_tmp.assign(1, NEG_INF());
    if (!impossible(_part_coeff)) {
      _ene_tmp[0] = (_mean_energy.value() - _length_factor * _seqlen);
      _ene_tmp[1] = _var_energy.value();
      _ene_tmp[1] = (_ene_tmp[1] <= 0 ? 0 : sqrt(_ene_tmp[1])); // standard deviation
      _z_tmp[0]   = (_part_coeff.z() - _length_factor * _seqlen);
      // convert to energy unit
      if (ZeroT) {
	_z_tmp[0]   = score_to_energy(_z_tmp[0]);
	_ene_tmp[0] = _z_tmp[0];
	_ene_tmp[1] = 0;
      } else {
	_ene_tmp[0] = score_to_energy(_ene_tmp[0]);
	_ene_tmp[1] = abs(score_to_energy(_ene_tmp[1]));
	_z_tmp[0]   = score_to_energy(_z_tmp[0]);
      }
    } else {
      Die("cannot parse sequence");
    }
    block(0, _seqlen, _ene_tmp, _z_tmp);
  }
  void compute_forward() {
    init_cur_sc();
    _pi_in.set_size(sm().nlayer_in(), (_width + 1), (min(_width, _seqlen) + 1), true);
    _si_in.set_size(sm().nstate(), sm().nop_type(), (_width + 1));
    _oi_in.set_size(sm().nop_type(), (_seqlen + 1)); 
    _inside.set_matrix_index(_pi_in, _si_in, _si_in, _oi_in);
    _fn_inside_f.set_inside(_inside);
    _fn_forward_f.set_inside(_inside);
    for (IntT b = 0; b <= _seqlen; b += (_block_len + 1)) {
      IntT e  = min(b + _block_len, _seqlen); // inclusive end
      IntT b0 = max((IntT)0, (b - _width));
      IntT e0 = e;
      _pi_in.set_range(b0, (e0 + 1));
      compute_forward_block_len(b, e);
    }
    _part_coeff  = compute_part_coeff();
    _mean_energy = compute_mean_energy();
    _var_energy  = compute_var_energy();
  }
  LScore compute_part_coeff() { return _inside.ref_o(SM::OT_NONE, _seqlen);}
  LScore compute_mean_energy() { return (_inside.ref_o(SM::OT_ENE, _seqlen) / _part_coeff);}
  LScore compute_var_energy() 
  { return ((_inside.ref_o(SM::OT_ENE2, _seqlen) / _part_coeff) - (_mean_energy * _mean_energy));}
  void compute_forward_block_len(IntT b, IntT e) {
    for (IntT j = b; j <= e; ++j) {
      IntT ib = max((IntT)0, (j - _width));
      for (IntT i = j; i >= ib; --i) { inside_transitions(_fn_inside_f, i, j);}
      forward_transitions(_fn_forward_f, 0, j);
    }
  }
  template <typename Block> void compute_backward(Block block) {
    init_cur_sc();
    _pi_in.set_size(sm().nlayer_in(), (_width + 1), (min(_period, _seqlen) + 1), false);
    _si_in.set_size(sm().nstate(), sm().nop_type(), (_width + 1));
    _oi_in.set_size(sm().nop_type(), (_seqlen + 1)); 
    _inside.set_matrix_index(_pi_in, _si_in, _si_in, _oi_in);
    _fn_inside_b.set_inside(_inside);
    _fn_forward_b.set_inside(_inside);
    for (IntT e = _seqlen; e >= 0; e -= (_block_len + 1)) {
      IntT b  = max((IntT)0, (e - _block_len));
      IntT b0 = b;
      IntT e0 = min((e + _period), _seqlen);
      _pi_in.set_range(b0, (e0 + 1));
      block(b, e);
    }
  }
  template <typename Block> void compute_backward_block_len(Block block, IntT b, IntT e) {
    for (IntT i = e; i >= b; --i) {
      compute_backward_pos(i);
      print_ene(block, i);
    }
  }
  void compute_backward_pos(IntT i) {
    IntT k = (i + _width);
    if (0 <= i) {
      IntT je = min(k, _seqlen);
      for (IntT j = i; j <= je; ++j) { inside_transitions(_fn_inside_b, i, j);}
      IntT je1 = min((i + _max_ene_span), _seqlen);
      for (IntT j = i; j <= je1; ++j) { forward_transitions(_fn_forward_b, i, j);}
    }
  }
  template <typename Block> void print_ene(Block block, IntT i) {
    _ene_tmp.assign(2, 0);
    _z_tmp.assign(1, NEG_INF());
    for (IntT j = (max((IntT)0, i) + 1); j <= min(i + _max_ene_span, _seqlen); ++j) {
      IntT  w  = (j - i);
      DPRef z  = _inside.ref_o(SM::OT_NONE, j);
      DPRef e  = _inside.ref_o(SM::OT_ENE, j);
      DPRef e2 = _inside.ref_o(SM::OT_ENE2, j);
      if (!impossible(LScore(z))) {
	LScore mu   = (e / z);
	LScore mu2  = (e2 / z);
	_ene_tmp[0] = (mu.value() - _length_factor * w);
	_ene_tmp[1] = (mu2 - (mu * mu)).value();
	_ene_tmp[1] = (_ene_tmp[1] <= 0 ? 0 : sqrt(_ene_tmp[1])); // standard deviation
	_z_tmp[0]   = (z.z() - _length_factor * w);
	// convert to energy unit
	if (ZeroT) {
	  _z_tmp[0]   = score_to_energy(_z_tmp[0]);
	  _ene_tmp[0] = _z_tmp[0];
	  _ene_tmp[1] = 0;
	} else {
	  _ene_tmp[0] = score_to_energy(_ene_tmp[0]);
	  _ene_tmp[1] = abs(score_to_energy(_ene_tmp[1]));
	  _z_tmp[0]   = score_to_energy(_z_tmp[0]);
	}
	block(i, j, _ene_tmp, _z_tmp);
      } else {
	Die("cannot parse subsequence %d,%d", i, j);
      }
      z = 0;
      e = 0;
      e2 = 0;
    }
  }
  void set_inside_s1_for_outside(DPM& inside, IntT i, IntT j) {
    for (IntT s = 0; s < sm().nstate(); ++s) {
      for (IntT h = 0; h < sm().nop_type(); ++h) {
	IntT k = sm().layer_in(s, h);
	if (k >= 0) { inside.ref_s1(s, h, (j - i)) = inside.ref_p(k, i, j);} 
	else { inside.ref_s1(s, h, (j - i)) = 0;}
      }
    }
  }
  DPRef sc_in(DPM& inside, const Transition& t, IntT k, IntT l, IntT h) {
    if (t.refer_cur_sc()) { return cur_sc(t.to(), h);}
    else { return sc_in_0(inside, t, k, l, h);}
  }
  DPRef sc_out(DPM& outside, const Transition& t, IntT k, IntT l, IntT h) {
    if (t.refer_cur_sc()) { return cur_sc(t.from(), h);}
    else { return sc_out_0(outside, t, k, l, h);}
  }
  DPRef sc_in_0(DPM& inside, const Transition& t, IntT k, IntT l, IntT h) {
    if (t.to() == SM::OUTER) { return inside.ref_o(h, l);} 
    else { return inside.ref_p(sm().layer_in(t.to(), h), k, l);}
  }
  DPRef sc_out_0(DPM& outside, const Transition& t, IntT k, IntT l, IntT h) {
    if (t.from() == SM::OUTER) { return outside.ref_o(h, l);}
    else { return outside.ref_p(sm().layer_out(t.from(), h), k, l);}
  }
  LScore compute_w(DPM& inside, const Transition& t, IntT k, IntT l, 
		   IntT ho, IntT hi, ScoreT tsc) {
    const DPRef& sc_o = cur_sc(t.from(), ho);
    const DPRef& sc_i = sc_in(inside, t, k, l, hi); 
    // be careful only outside is stored in cur_sc
    return (LScore(tsc, +1) * ((sc_i / _part_coeff) * sc_o));
  }
  bool allow_pair_0(IntT i, IntT j) { return Alpha::is_canonical(seq(i + 1), seq(j));}
  bool allow_outer_pair(IntT i, IntT j) { return allow_pair_0(i, j);}
  bool allow_inner_pair(IntT i, IntT j) { return allow_pair_0(i, j);}
  bool allow_emit_pair(IntT i, IntT j) { return allow_pair_0(i, j);}
  bool allow_inner_loop(IntT i, IntT j) { return true;}
  bool allow_outer_loop(IntT i, IntT j) { return true;}
  template <typename Fn> void forward_transitions(Fn& f, IntT i, IntT j) {
    f.before_transition(i, j);
    //Outer->
    if (i == j) {
      //->OuterEnd
      f.on_transition(SM::TR_O_X, i, j, i, j);
    } else {//if i < j
      //->Outer
      if (allow_outer_loop(j - 1, j)) { f.on_transition(SM::TR_O_O, i, j, i, j - 1);}
      //->InnerBeg // why was TR_O_IB necessary? <- perhaps TR_O_X emitted a nucleotide before.
      if (j <= (i + _width)) { f.on_transition(SM::TR_O_IB, i, j, i, j);}
      //OuterBF -> (Outer + InnerBeg) ( (i + 1) because i is included in TR_O_IB)
      f.on_transition(SM::TR_O_BF, i, j, max((i + 1), (j - _width)), (j - 1)); 
    }
    f.after_transition(i, j);
  }
  template <typename Fn> void backward_transitions(Fn& f, IntT i, IntT j) {
    f.before_transition(i, j);
    //->Outer
    if (j == _seqlen) {
      //OuterBeg->
      f.on_transition(SM::TR_X_O, i, j, i, j);
    } else {//if j < _seqlen
      if (allow_outer_loop(j, j + 1)) { f.on_transition(SM::TR_O_O, i, j, i, j + 1);}
      //Outer->(. + InnerBeg)
      f.on_transition(SM::TR_O_BFL, i, j, (j + 1), min((j + _width), _seqlen));
    }
    f.after_transition(i, j);
  }
  template <typename Fn> void inside_transitions(Fn& f, IntT i, IntT j) {
    f.before_transition(i, j);
    //Stem->
    IntT k = (i + 1);
    IntT l = (j - 1);
    if (k <= l) {
      if (allow_emit_pair(i, j)) {
	//->Stem
	if (k + 2 <= l) { 
	  if (allow_inner_pair(k, l)) { f.on_transition(SM::TR_S_S, i, j, k, l);}
	}
	//->StemEnd
	f.on_transition(SM::TR_S_E, i, j, k, l);
      }
    }
    //Multi->
    if (0 < i && j < _seqlen) {
      // MultiBF->(Multi1 + Multi2)
      f.on_transition(SM::TR_M_BF, i, j, (i + 1), (j - 1));
      //Multi2->
      //->Stem
      if ((i + 2 <= j) && allow_inner_pair(i, j)) { f.on_transition(SM::TR_M2_S, i, j, i, j);}
      //->Multi2
      if (i <= (j - 1)) {
	if (allow_inner_loop(j - 1, j)) { f.on_transition(SM::TR_M2_M2, i, j, i, j - 1);}
      }
      //Multi1->
      //->Multi2
      f.on_transition(SM::TR_M1_M2, i, j, i, j);
      //->MultiBF
      f.on_transition(SM::TR_M1_MBF, i, j, i, j);
      //Multi->
      //->Multi
      if ((i + 1) <= j) { 
	if (allow_inner_loop(i, i + 1)) { f.on_transition(SM::TR_M_M, i, j, i + 1, j);}
      }
      //->MultiBF
      f.on_transition(SM::TR_M_MBF, i, j, i, j);
    }
    //StemEnd->
    if (0 < i && j < _seqlen) {
      if (allow_outer_pair(i - 1, j + 1)) {
	//->Hairpin
	if ((i + SM::MINHPIN <= j) && allow_inner_loop(i, j)) { 
	  f.on_transition(SM::TR_E_H, i, j, j, j);
	}
	//->Interior Loop (includes Bulge)->Stem
	for (IntT li = 0; li <= min((j - i), (IntT)SM::MAXLOOP); ++li) {
	  IntT ip = (i + li);
	  if (allow_inner_loop(i, ip)) {
	    IntT ljb = max((IntT)0, 1 - li);
	    IntT lje = min((j - (ip + 2)), (SM::MAXLOOP - li));
	    for (IntT lj = ljb; lj <= lje; ++lj) { 
	      // (li + lj) >= 1
	      IntT jp = (j - lj);
	      if (allow_inner_loop(jp, j)) {
		if (allow_inner_pair(ip, jp)) { f.on_transition(SM::TR_E_I, i, j, ip, jp);}
	      }
	    }
	  }
	}
	//->Multi
	f.on_transition(SM::TR_E_M, i, j, i, j);
	// print_cur_sc(cout, "TR_E_M", i, j, SM::STEM_END);
      }
    }
    //InnerBeg->
    //->Stem
    if ((k <= l) && allow_inner_pair(i, j)) { f.on_transition(SM::TR_IB_S, i, j, i, j);}
    f.after_transition(i, j);
  }
  template <typename Fn> void outside_transitions(Fn& f, IntT i, IntT j) {
    f.before_transition(i, j);
    //->InnerBeg
    if (i == 0) {
      //Outer->  // why was TR_O_IB necessary? <- perhaps TR_O_X emitted a nucleotide before
      f.on_transition(SM::TR_O_IB, i, j, i, j);  
    } else if (i < j) {
      //Outer->(Outer + .)             // (0, 0) because (k, l) was used for range m = (l-k+1)
      f.on_transition(SM::TR_O_BFR, i, j, 0, 0); 
    }
    //->StemEnd
    IntT k = (i - 1);
    IntT l = (j + 1);
    if (0 <= k && l <= _seqlen && (l - k) <= _width) {
      if (allow_emit_pair(k, l)) {
	//Stem->
	f.on_transition(SM::TR_S_E, i, j, k, l);
      }
    }
    IntT i0 = max((IntT)0, (j - _width));
    IntT j0 = min((i + _width), _seqlen);
    //->Multi
    //StemEnd->
    if (0 < i && j < _seqlen) {
      if (allow_outer_pair(k, l)) { f.on_transition(SM::TR_E_M, i, j, i, j);}
      //Multi->
      if (max((IntT)0, (j - _width)) < i) {
	if (allow_inner_loop(i - 1, i)) { f.on_transition(SM::TR_M_M, i, j, (i - 1), j);}
      }
      //->Multi1
      //MultiBF->(. + Multi2)
      f.on_transition(SM::TR_M_BFL, i, j, (j + 1), (j0 - 1)); // (-1) for STEM state
      //->Multi2
      //Multi2->
      if (j < j0) {
	if (allow_inner_loop(j, (j + 1))) { f.on_transition(SM::TR_M2_M2, i, j, i, (j + 1));}
      }
      //Multi1->
      f.on_transition(SM::TR_M1_M2, i, j, i, j);
      //MultiBF->(Multi1 + .)
      f.on_transition(SM::TR_M_BFR, i, j, (i0 + 1), (i - 1)); // (+1) for STEM state
      //->MultiBF
      //Multi1->
      f.on_transition(SM::TR_M1_MBF, i, j, i, j);
      //Multi->
      f.on_transition(SM::TR_M_MBF, i, j, i, j);
    }
    //->Stem
    if ((i + 2 <= j) && allow_inner_pair(i, j)) {
      //->InnerBeg
      f.on_transition(SM::TR_IB_S, i, j, i, j);
      //Stem->Interior->
      // IntT lie = min((i - (max(0, (j - _width) + 1))), (IntT)SM::MAXLOOP);
      IntT lie = min((i - i0 - 1), (IntT)SM::MAXLOOP); // (-1) for STEM state
      for (IntT li = 0; li <= lie; ++li) {
	IntT ip = (i - li);
	if (allow_inner_loop(ip, i)) {
	  IntT jp0 = min((ip + _width), _seqlen);
	  IntT ljb = max((IntT)0, (1 - li));
	  // int lje = min((min(_seqlen, ((ip - 1) + _width)) - 1 - j), (SM::MAXLOOP - li));
	  IntT lje = min((jp0 - j - 1), ((IntT)SM::MAXLOOP - li)); // (-1) for STEM state
	  for (IntT lj = ljb; lj <= lje; ++lj) {
	    // (li+lj) > 0
	    IntT jp = (j + lj);
	    if (allow_inner_loop(j, jp)) {
	      if (allow_outer_pair(ip - 1, jp + 1)) { 
		f.on_transition(SM::TR_E_I, i, j, ip, jp);
	      }
	    }
	  }
	}
      }
      if (0 < i && j < _seqlen) {
	//Multi2->
	f.on_transition(SM::TR_M2_S, i, j, i, j);
      }
      IntT k = (i - 1);
      IntT l = (j + 1);
      if (0 <= k && l <= _seqlen && (l - k) <= _width) {
	//->STEM
	if (allow_emit_pair(k, l)) { f.on_transition(SM::TR_S_S, i, j, k, l);}
      }
    }
    f.after_transition(i, j);
  }
};
#endif
