ct --> rnaml conversion

This file is compiled through the normal gcc command.  It requires no
special libraries.  The progam requires a .ct file, and outputs a file
of the same name, except as a .rnaml file.  This file is an rnaml
file.  There are two optional parameters, which are entered on the
command line as follows.  analysis=xxxxxx , where xxxxxx is what the
user wants the analysis to be.  The second optional parameter is
method=xxxxxxx where xxxxxxx is again what the user wants the method
to be.
