short *make_pair_table(char *structure);
void nrerror(char *message);
void printRnaStruct(short* structure, int length);   
