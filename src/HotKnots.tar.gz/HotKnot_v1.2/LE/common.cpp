/***************************************************************************
                          common.cpp  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/


// This file contains common functions, that may be used throughout the library

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "constants.h"
#include "structs.h"
#include "externs.h"
#include "common.h"

int LEstacked_pair_energy (int i, int j, int *sequence)
{
    return stack [sequence[i]]
                     [sequence[j]]
                     [sequence[i+1]]
                     [sequence[j-1]];

    	printf("stacked_pair_energy in mirela for %d : %d ,%d: %d,%d: %d,%d: %d ",i,j, i+1,j-1,
    	sequence[i],sequence[j],sequence[i+1],sequence[j-1]);
}


int LEhairpin_loop_energy (int i, int j, int* sequence, char *csequence)
// PRE:  seq is the sequence of the loop; important for tetraloops
//       I assume i-j can pair
// POST: Help function to compute_hairpin_matrix
//       Return the energy of a hairpin
{
    int energy=0;

    int terminal_mismatch_energy = 0, bonus = 0, special_bonus = 0, AU_pen = 0;
    int k, is_poly_C;
    int size;
    char seq[6] = "";


    size = j-i-1;

	if (debug)
		printf("[hairpin] unpaired bases: %d\n", size);

    if (size < 3)
        return INF;
    else if (size == 3)
    {
        terminal_mismatch_energy = 0;
        AU_pen = AU_penalty (sequence[i], sequence[j]);
    }
    else
    {
        terminal_mismatch_energy =
             tstackh[sequence[i]]
                    [sequence[j]]
                    [sequence[i+1]]
                    [sequence[j-1]];

    }

    // check if it is a triloop
    if (size == 3)
    {
        substr (csequence, i, j, seq);
        for (k=0; k < nb_triloops; k++)
        {
            if (strcmp (seq, triloop[k].seq) == 0)
                bonus = triloop[k].energy;
        }
    }

    // check to see it is a tetraloop in tloop
    else if (size == 4)
    {
        substr (csequence, i, j, seq);
        for (k=0; k < nb_tloops; k++)   // nb_tloops should be the same as for energy
        {
            if (strcmp (seq, tloop[k].seq) == 0)
                bonus = tloop[k].energy;
        }

    }

    // special_bonus from miscloop file
    // check if we have to apply "GGG" loop special bonus
    // to come back - Vienna doesn't have it

    if (i > 1)
    {
        if (sequence[i-2] == G && sequence[i-1] == G &&
            sequence[i] == G && sequence[j] == U)
            special_bonus += misc.hairpin_GGG;
    }


    // check for the special case of "poly-C" hairpin loop
    is_poly_C = 1;
    for (k=i+1; k<j; k++)
    {
        if (sequence[k] != C)
        {
            is_poly_C = 0;
            break;
        }
    }
    if (is_poly_C)
    {
        if (size == 3)
            special_bonus += misc.hairpin_c3;
        else
            special_bonus += misc.hairpin_c2 + misc.hairpin_c1 * size;
    }

    energy = penalty_by_size (size, 'H') +
             terminal_mismatch_energy + bonus + special_bonus + AU_pen;

    return energy;
}


int LEinternal_loop_energy (int i, int j, int ip, int jp, int *sequence)
// PRE:  The energy matrix was calculated
// POST: Read from the read pool, write to nodes;
//       Store the node and return the energy.
{

    int minq;
    int energy;

    int penalty_size, asym_penalty, ip_jp_energy, i_j_energy, en;
    int branch1, branch2, l;


    branch1 = ip-i-1;
    branch2 = j-jp-1;


	if (debug)
		printf("[internal_loop_energy] branch1: %d , branch2: %d\n", branch1, branch2);


    if (branch1 != 0 || branch2 != 0)
	{
        // check if it is a bulge loop of size 1
        // check if it is int11 or int21 or int22
        if (branch1 == 1 && branch2 == 1)     // it is int11
        {
                        // int11[i][j][i+1][j-1][ip][jp]
            energy = int11 [sequence[i]][sequence[j]]
                           [sequence[i+1]][sequence[j-1]]
                           [sequence[ip]][sequence[jp]];
        }
        else if (branch1 == 1 && branch2 == 2)
        {
            // int21[i][j][i+1][j-1][ip][jp][jp+1]
            energy = int21 [sequence[i]][sequence[j]]
                           [sequence[i+1]][sequence[j-1]]

                           [sequence[ip]][sequence[jp]]
                           [sequence[jp+1]];
        }
        else if(branch1 == 2 && branch2 == 1)
        {
            // after rotation: int21[jp][ip][j-1][ip-1][j][i][i+1]
            energy = int21 [sequence[jp]][sequence[ip]]
                           [sequence[j-1]][sequence[ip-1]]
                           [sequence[j]][sequence[i]]
                           [sequence[i+1]];
        }
        else if (branch1 == 2 && branch2 == 2)
        {
            // int22[i][j][i+1][j-1][ip][jp][ip-1][jp+1]
            energy = int22 [sequence[i]][sequence[j]]
                           [sequence[i+1]][sequence[j-1]]
                           [sequence[ip]][sequence[jp]]
                           [sequence[ip-1]][sequence[jp+1]];
        }
        else
        {
            // this case is not int11, int21, int22

            // check if it is a bulge
            if (branch1 == 0 || branch2 == 0)
            {
                l = branch1+branch2;
                penalty_size = penalty_by_size (l, 'B');
                if (l == 1)
                {
                    // bulge of size 1
                    // stack[i][j][i+1][j-1]
                    energy = stack [sequence[i]][sequence[j]]
                                   [sequence[ip]][sequence[jp]] +
                               penalty_size;
                }
                else
                {
                    // bulge of size bigger than 1
                    // check if (i,j) and (ip,jp) can pair
                    energy = penalty_size +
                               AU_penalty (sequence[i],sequence[j]) +
                               AU_penalty (sequence[ip], sequence[jp]);
                }
            }
            // it is an internal loop (not a bulge)
            else
            {
                l = branch1+branch2;
                penalty_size = penalty_by_size (l, 'I');
                asym_penalty = asymmetry_penalty (branch1, branch2);

                if ((branch1 == 1 || branch2 == 1) && misc.gail_rule)
                // If gail_rule is set to 1 in miscloop file,
                // i_j_energy and ip_jp_energy will be calculated as if it was a loop of As
                {
                    i_j_energy  =  tstacki[sequence[i]][sequence[j]]
                                          [0][0];
                    ip_jp_energy = tstacki[sequence[jp]][sequence[ip]]
                                          [0][0];
                }
                else
                {
                    i_j_energy   = tstacki[sequence[i]][sequence[j]]
                                          [sequence[i+1]][sequence[j-1]];
                    ip_jp_energy = tstacki[sequence[jp]][sequence[ip]]
                                          [sequence[jp+1]][sequence[ip-1]];
                }
                energy = i_j_energy + ip_jp_energy + penalty_size +
                                         asym_penalty;
            }
        }
    }
    return energy;
}


