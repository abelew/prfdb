/*****************************************************************
         HotKnot: A heuristic algorithm for RNA secondary 
            structure prediction including pseudoknots
         File: LoopList.cpp
         Description: 
             Contains functions for calculating the free energy
             of interior-pseudoknotted and multi-pseudoknotted loops.
             Also contains a function (FindChildren) for figuring out the tuples 
             associated with a multi-pseudokntted loop.
             
 
    Date        : Oct. 16, 2004
    copyright   : (C) 2004 by Baharak Rastegari, Jihong Ren  
    email       : baharak@cs.ubc.ca, jihong@cs.ubc.ca        
******************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "LoopList.h"
#include "Loop.h"

#define NULL 0


LoopList::LoopList(ReadInput* R, int b1, int b2){

	base1 = b1;
	base2 = b2;
	Size = 0;
	Input = R;
 }

LoopList::~LoopList(){

}

/*********************************************************************************
FincChildren: figures out the tuples associated with a multi-pseudoknotted loop.
*********************************************************************************/
void LoopList::FindChildren(){
	Input->loops[base1].num_branches = 0;
	Input->loops[base1].pseudo_num_branches = 0;

	int i = Input->Next[base1];
	int j = base2;

	while (i < j){
		if (Input->ClosedRegions[i] != NULL){
			Input->loops[base1].bri[Input->loops[base1].num_branches++] = i;
			if (Input->ClosedRegions[i]->type == pseudo)
				Input->loops[base1].pseudo_num_branches += 2;
			else
				Input->loops[base1].pseudo_num_branches += 1;


			if (DEBUG)
				printf("$$$$$$$$$$$$$$$$[%d, %d] is a child of (%d, %d)\n", Input->ClosedRegions[i]->begin, Input->ClosedRegions[i]->end
									, base1, base2);
			i = Input->Next[Input->ClosedRegions[i]->end];
		}
		else
			i = Input->Next[i];
	};


	i = Input->Next[Input->BasePair(base2)];
	j = Input->BasePair(base1);
	while (i < j){
		if (Input->ClosedRegions[i] != NULL){
			Input->loops[base1].bri[Input->loops[base1].num_branches++] = i;
			if (Input->ClosedRegions[i]->type == pseudo)
				Input->loops[base1].pseudo_num_branches += 2;
			else
				Input->loops[base1].pseudo_num_branches += 1;
			if (DEBUG)
				printf("$$$$$$$$$$$$$$$$[%d, %d] is a child of (%d, %d)\n", Input->ClosedRegions[i]->begin, Input->ClosedRegions[i]->end
								, base1, base2);
			i = Input->Next[Input->ClosedRegions[i]->end];
		}
		else
			i = Input->Next[i];
	};

	if (DEBUG)
		printf("[VIRTUALNum_branches] usual: %d, pseudo: %d\n", Input->loops[base1].num_branches, Input->loops[base1].pseudo_num_branches);

};


/*********************************************************************************
stackEnergy: Calculates the free energy of an interior-pseudoknotted loop which
is acutally a stacked pair.
*********************************************************************************/
float	LoopList::stackEnergy(){
	if (DEBUG)
		printf("[stackPseudoEnergy] start\n");
	str_features * f = Input->loops;
	int * sequence = Input->type;
	int i = base1;

	int en = LEstacked_pair_energy (i, f[i].pair, sequence);

	return g_interiorPseudo* en;

}

/*********************************************************************************
interiorPseudoEnergy: Calculates the free energy of an interior-pseudoknotted loop
which is not a stacked pair.
*********************************************************************************/
float	LoopList::interiorPseudoEnergy(){

	if (DEBUG)
		printf("[interiorPseudoEnergy] start\n");
	str_features * f = Input->loops;
	int * sequence = Input->type;

	if (  (base2 == base1 + 1 ) && (f[base1].pair == f[base2].pair + 1) )
		return stackEnergy();

	int i = base1;

    int ip, jp;
    ip = base2;
    jp = f[ip].pair;

    Input->cannot_add_dangling[ip-1] = 1;
    Input->cannot_add_dangling[jp+1] = 1;
    int en = LEinternal_loop_energy (i, f[i].pair, ip, jp, sequence);
    return g_interiorPseudo* en;
};

/*********************************************************************************
multiPseudoEnergy:  Calculates the free energy of a multi-pseudoknotted Loop.
*********************************************************************************/
float	LoopList::multiPseudoEnergy(){
	if (DEBUG)
		printf("[multiPseudoEnergy] start\n");

	str_features * f = Input->loops;
	int * sequence = Input->type;
	int i = base1;
    int energy, en, AUpen, h, l;
    int dang;
    int misc_energy;



	dang = 0;
	misc_energy = 0;
	AUpen = 0;
	int special;
	special = 0;

	misc_energy += multi_OffsetPseudo;
	misc_energy += misc.multi_helix_penalty * f[i].pseudo_num_branches  + 2 * p_pairedMultiPseudo;

	// add AU_penalties for multi-loop
	AUpen += AU_penalty (sequence[i], sequence[f[i].pair]);

	for (h=0; h < f[i].num_branches; h++)
		AUpen += AU_penalty (sequence[f[i].bri[h]],sequence[f[f[i].bri[h]].pair]);

	// add dangling energies for multi-loop
	dang += dangling_energy_left (sequence, i, f[i].pair, f[i].bri[0], f[f[i].bri[0]].pair);
	for (l=0; l < f[i].num_branches - 1; l++)
		dang += dangling_energy (sequence, f[i].bri[l], f[f[i].bri[l]].pair, f[i].bri[l+1], f[f[i].bri[l+1]].pair);
	dang += dangling_energy_right (sequence, i, f[i].pair, f[i].bri[f[i].num_branches-1], f[f[i].bri[f[i].num_branches-1]].pair);

	// add "no-dangling" restriction
	for (l=0; l < f[i].num_branches; l++)
	{
		Input->cannot_add_dangling [f[i].bri[l] -1] = 1;
		Input->cannot_add_dangling [f[f[i].bri[l]].pair + 1] = 1;
	}
	return misc_energy + dang + AUpen;


};
