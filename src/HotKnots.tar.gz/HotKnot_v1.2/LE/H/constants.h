/***************************************************************************
                          constants.h  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef CONSTANTS_H
#define CONSTANTS_H


#define RNA 0
#define DNA 1

// change these if necessary
#define MAXSLEN         5000         // maximum of total sequence length
#define MAXENERGY       0            // the maximum energy that this program returns (usually 0)
#define MAX_BRANCHES    50           // maximum # of branches in multiloops

#define A               0
#define C               1
#define G               2
#define U               3
#define T               3

// do not change
#define INF             16000       // a very big value (infinity)
#define NUCL            4           // number of nucleotides: 4: A, C, G, T
#define MAXLOOP         30          // max loop for which the size of the loop is penalized - see loop.dat
#define MAXTRILOOPNO    100
#define MAXTLOOPNO      400
#define EPSILON         0.0001      // a very small value
#define TURN            3           // the minimum number of free bases in a hairpin loop


#define NONE            'N'
#define HAIRP           'H'
#define STACK           'S'
#define INTER           'I'
#define MULTI           'M'
#define BULGE           'B'


#endif

