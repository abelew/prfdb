/***************************************************************************
                          common.h  -  description
                             -------------------
    begin                : Thu Sep 5 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>
#include <math.h>

#define MIN(A, B)      ((A) < (B) ? (A) : (B))
#define MAX(A, B)      ((A) > (B) ? (A) : (B))

#define AU_penalty(X,Y)  ((((X) != C || (Y) != G) && ((X) != G || (Y) != C))?misc.terminal_AU_penalty:0)

#define AU_penalty_enthalpy(X,Y)  ((((X) != C || (Y) != G) && ((X) != G || (Y) != C))?enthalpy_misc.terminal_AU_penalty:0)

#define asymmetry_penalty(size1, size2) (MIN (misc.asymmetry_penalty_max_correction, abs (size1-size2) * misc.asymmetry_penalty_array [MIN (2, MIN ((size1), (size2)))-1]))

#define asymmetry_penalty_enthalpy(size1, size2) (MIN (enthalpy_misc.asymmetry_penalty_max_correction, abs (size1-size2) * enthalpy_misc.asymmetry_penalty_array [MIN (2, MIN ((size1), (size2)))-1]))



void giveup (char *string1, char *string2);
// to add: variable nb of parameters, as in scanf, printf

void giveup2 (char *string1, char *string2, FILE *file);
// to add: variable nb of parameters, as in scanf, printf


void empty_string (char * str);

int can_pair (int base1, int base2);
// PRE:  base1 and base2 are nucleotides over the alphabet {A, C, G, T, U}
// POST: return 1 if they can pair, 0 otherwise


int nuc_to_int (char nucleotide);
// PRE:  nucleotide is 'A', 'C', 'G' or 'T'
// POST: Return 0 for A, 1 for C, 2 for G, 3 for T


char int_to_nuc (int inuc);


int is_nucleotide (char base);
// PRE:  base is a character
// POST: return true if base is a nucleotide (A, C, G or T)
//       return false otherwise


void check_sequence (char *sequence);
// check sequence for length and alphabet


//int asymmetry_penalty (int size1, int size2);
// PRE:  size1 and size2 are the sizes of the two free base groups
// POST: Calculate the asymmetry penalty for internal loops
//       Note that if size1 == size2, pen is 0

//int asymmetry_penalty_enthalpy (int size1, int size2);


//int AU_penalty_enthalpy (int base_i, int base_j);
    
int penalty_by_size (int size, char type);
// PRE:  size is the size of the loop
//       type is HAIRP or INTER or BULGE
// POST: return the penalty by size of the loop


int penalty_by_size_enthalpy (int size, char type);


void substr (char *source, int begin, int end, char *dest);
// PRE:  begin and end are smaller than strlen(source)
// POST: Put in dest what is in source between position begin and position end


int dangling_energy (int *sequence, int i1, int i2, int i3, int i4);
// PRE:  (i1, i2) and (i3, i4) are pairs, i2 and i3 are neighbours, i2 < i3
// POST: return dangling energy between i2 and i3


int dangling_energy_left (int *sequence, int i1, int i2, int i3, int i4);
//      (....(    )   )
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling energy between i1 and i3


int dangling_energy_right (int *sequence, int i1, int i2, int i3, int i4);
//      (    (    )...)
//      i1   i3  i4  i2
// PRE:  (i1, i2) and (i3, i4) are pairs, i1 and i3 are neighbours, i3 < i2
// POST: return dangling energy between i4 and i2


int dangling_enthalpy (int *sequence, int i1, int i2, int i3, int i4);

void insert_space (char *structure, int place);

void detect_original_pairs(const char *structure, int *p_table);
// PRE:  structure contains the desired structure
// POST: pairs will contain the index of each base pair
//               or -1 if it does not pair


double free_energy_simfold (char *sequence, char *structure);


// GIven the sequence and the structure, calculates the free energy

int LEstacked_pair_energy (int i, int j, int *sequence);

int LEhairpin_loop_energy (int i, int j, int* sequence, char *csequence);
// PRE:  seq is the sequence of the loop; important for tetraloops
//       I assume i-j can pair
// POST: Help function to compute_hairpin_matrix
//       Return the energy of a hairpin

int LEinternal_loop_energy (int i, int j, int ip, int jp, int *sequence);
// PRE:  The energy matrix was calculated
// POST: Read from the read pool, write to nodes;
//       Store the node and return the energy.


//void init_data(char *config_file, int what, double temperature);
// the function that must be called by the main program to read data files
// PRE:  None
// POST: Read all data and configuration files


#endif
