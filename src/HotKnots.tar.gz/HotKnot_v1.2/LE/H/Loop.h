//#include "Sequence.h"
#ifndef LOOP_H
#define LOOP_H

#include "Defines.h"
#include "Input.h"
#include "Bands.h"
#include "LoopList.h"

class Loop {

public:

//FUNCTIONS


    Loop(int b, int e, ReadInput * R, Bands * B, Stack * S);				
	~Loop();

    void addLoop(int begin, int end);		//Adds a loop [begin,end] to the tree
    void Print(int i);						//Prints the loop tree in a hierarchical structure

	int NumUnpaired();					    //Calculate the Number of Unpaired bases in this loop
	void loopSetType();						
	void setTypes();						//Set the type of each Loop in the tree
											//(interior, hairin, pseudo, ...)
	void LoopFindBands();					//Finds the bands(band regions) of a pseudoknotted region
	
	void FindInnerLoops(int border1, int border2);		//Figuring out the span-Band loops regarding a 														
														//pseudoknotted closed region																		
	void PseudoNestedCheck();
	void WhereLocated();	//Find the locatin status of the children-loops of a pseudoknotted closed region

	//Free energy calculatin functions
	float Energy();			                //Calculating the free energy of the secondary structure
    float getEnergy();						//Computes the free energy of the loops
	float	pseudoEnergy();
	int	hairpinEnergy();
	int	stackEnergy();
	int	interiorEnergy();
	int	multiEnergy();
	
	
//ATTRIBUTES	
	T_IntList *ILoops, *MLoops; //interior-pseudoknotted loops list and multi-pseudoknotted loops list
	Stack * St;

    PseudoNestedType nested;   //location status of a loop
	int NumberOfUnBandChild;
	int NumberOfBandChild;
	int CurrentBandRegion;
    int NumberOfBands;
    int NumberOfChildren;					
	int NumberOfUnpaird;					//Number if unpaired bases within the loop
	int Pseudo_NumBranches;					//Number of Branches by considering pseudoknot children as 2.

	Loop* RightChild, *LeftSibling, *Parent; 
	int begin, end;				//The closed region borders
	LoopType type;
	
	ReadInput * Input;
	Bands  * bandpattern;	  //List of the band regions, sorted by the left border


};



#endif
