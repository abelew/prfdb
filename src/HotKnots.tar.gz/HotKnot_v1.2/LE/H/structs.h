/***************************************************************************
                          structs.h  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef STRUCTS_H
#define STRUCTS_H

#include "constants.h"


typedef struct
{
    short int i;
    short int j;
} pair;


struct W_node
{
    int energy;
    short int num_branches;           // 0 if this does not have any branch
    pair rbranch;                     // we need only the right branch, to calculate dangling energies with the next branch
    short int next_back;

    W_node ()
    {
        energy = MAXENERGY;
        num_branches = 0;        
        next_back = -1;
    }

};


// info from miscloop.dat
typedef struct
{
    // Extrapolation for large loops based on polymer theory
    // internal, bulge or hairpin loops > 30: dS(T)=dS(30)+param*ln(n/30)
    double param_greater30;
    // helix
    int terminal_AU_penalty;
    // hairpin data from miscloop file
    int hairpin_GGG;          // bonus for GGG hairpin
    int hairpin_c1;           // c hairpin slope
    int hairpin_c2;           // c hairpin intercept
    int hairpin_c3;           // c hairpin of 3
    // internal loops
    int asymmetry_penalty_max_correction;
    int asymmetry_penalty_array[4];
    int gail_rule;
    // multi-branched loops
    int multi_offset;
    int multi_helix_penalty;
    int multi_free_base_penalty;
    int intermolecular_initiation;
} miscinfo;


// info from tloop.dat
typedef struct
{
    char seq[6];
    int energy;
} hairpin_tloop;


typedef struct minimum_fold
{
    short int pair;
    char type;                   // type can be 'H', 'S', 'I', 'M'
    char filled;
    minimum_fold()
    {
        pair = -1;
        type = NONE;
        filled = 'N';
    }
} minimum_fold;

typedef struct str_features
{
    short int pair;
    char type;                   // type can be 'H', 'S', 'I', 'M'
    short int num_branches;
	short int pseudo_num_branches;
    int bri[MAX_BRANCHES];      // the i of each branch
    
    str_features()
    {
        pair = -1;
        type = NONE;
        num_branches = 0;
    }
} str_features;



typedef struct
{
        int top;
        int elem[MAXSLEN];
} stack_ds;



#endif

