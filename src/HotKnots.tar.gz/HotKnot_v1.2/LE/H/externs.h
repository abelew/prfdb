/***************************************************************************
                          externs.h  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef EXTERNS_H
#define EXTERNS_H

#include "constants.h"
#include "structs.h"
extern int debug;

// energies information
extern int stack [NUCL] [NUCL] [NUCL] [NUCL];
extern int tstackh [NUCL] [NUCL] [NUCL] [NUCL];
extern int tstacki [NUCL] [NUCL] [NUCL] [NUCL];
extern int int11   [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL];
extern int int21   [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL];
extern int int22   [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL];
extern int dangle_top  [NUCL] [NUCL] [NUCL];
extern int dangle_bot  [NUCL] [NUCL] [NUCL];
extern int internal_penalty_by_size [MAXLOOP+1];
extern int bulge_penalty_by_size [MAXLOOP+1];
extern int hairpin_penalty_by_size [MAXLOOP+1];
extern miscinfo misc;
extern hairpin_tloop triloop[MAXTRILOOPNO];
extern int nb_triloops;
extern hairpin_tloop tloop[MAXTLOOPNO];
extern int nb_tloops;

// enthalpies information
extern int enthalpy_stack [NUCL] [NUCL] [NUCL] [NUCL];
extern int enthalpy_tstackh [NUCL] [NUCL] [NUCL] [NUCL];
extern int enthalpy_tstacki [NUCL] [NUCL] [NUCL] [NUCL];
extern int enthalpy_int11   [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL];
extern int enthalpy_int21   [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL];
extern int enthalpy_int22   [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL];
extern int enthalpy_dangle_top  [NUCL] [NUCL] [NUCL];
extern int enthalpy_dangle_bot  [NUCL] [NUCL] [NUCL];
extern int enthalpy_internal_penalty_by_size [MAXLOOP+1];
extern int enthalpy_bulge_penalty_by_size [MAXLOOP+1];
extern int enthalpy_hairpin_penalty_by_size [MAXLOOP+1];
extern miscinfo enthalpy_misc;
extern hairpin_tloop enthalpy_triloop[MAXTRILOOPNO];
extern hairpin_tloop enthalpy_tloop[MAXTLOOPNO];
extern int enthalpy_nb_triloops;
extern int enthalpy_nb_tloops;

// parameters from the configuration file
extern int nb_params;
extern char par_name [56] [100];
extern char par_value [56] [100];
extern char * std_dir_par;
extern char * rna_stack_energy37_v31_par;
extern char * rna_stack_energy37_v23_par;
extern char * rna_stack_enthalpy_par;
extern char * rna_loop_energy37_v31_par;
extern char * rna_loop_energy37_v23_par;
extern char * rna_loop_enthalpy_par;
extern char * rna_triloop_energy37_v31_par;
extern char * rna_triloop_energy37_v23_par;
extern char * rna_triloop_enthalpy_par;
extern char * rna_tloop_energy37_v31_par;
extern char * rna_tloop_energy37_v23_par;
extern char * rna_tloop_enthalpy_par;
extern char * rna_tstackh_energy37_v31_par;
extern char * rna_tstackh_energy37_v23_par;
extern char * rna_tstackh_enthalpy_par;
extern char * rna_tstacki_energy37_v31_par;
extern char * rna_tstacki_energy37_v23_par;
extern char * rna_tstacki_enthalpy_par;
extern char * rna_int11_energy37_v31_par;
extern char * rna_int11_energy37_v23_par;
extern char * rna_int11_enthalpy_par;
extern char * rna_int21_energy37_v31_par;
extern char * rna_int21_energy37_v23_par;
extern char * rna_int21_enthalpy_par;
extern char * rna_int22_energy37_v31_par;
extern char * rna_int22_energy37_v23_par;
extern char * rna_int22_enthalpy_par;
extern char * rna_miscloop_energy37_v31_par;
extern char * rna_miscloop_energy37_v23_par;
extern char * rna_miscloop_enthalpy_par;
extern char * rna_dangle_energy37_v31_par;
extern char * rna_dangle_energy37_v23_par;
extern char * rna_dangle_enthalpy_par;

extern char * dna_stack_energy37_par;
extern char * dna_stack_enthalpy_par;
extern char * dna_loop_energy37_par;
extern char * dna_loop_enthalpy_par;
extern char * dna_triloop_energy37_par;
extern char * dna_triloop_enthalpy_par;
extern char * dna_tloop_energy37_par;
extern char * dna_tloop_enthalpy_par;
extern char * dna_tstackh_energy37_par;
extern char * dna_tstackh_enthalpy_par;
extern char * dna_tstacki_energy37_par;
extern char * dna_tstacki_enthalpy_par;
extern char * dna_int11_energy37_par;
extern char * dna_int11_enthalpy_par;
extern char * dna_int21_energy37_par;
extern char * dna_int21_enthalpy_par;
extern char * dna_int22_energy37_par;
extern char * dna_int22_enthalpy_par;
extern char * dna_miscloop_energy37_par;
extern char * dna_miscloop_enthalpy_par;
extern char * dna_dangle_energy37_par;
extern char * dna_dangle_enthalpy_par;


#endif
