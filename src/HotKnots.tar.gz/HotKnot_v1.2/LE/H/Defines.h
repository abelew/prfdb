/*****************************************************************
         HotKnot: A heuristic algorithm for RNA secondary 
            structure prediction including pseudoknots
         File: defines.h
 
    Date        : Oct. 16, 2004
    copyright   : (C) 2004 by Baharak Rastegari, Jihong Ren  
    email       : baharak@cs.ubc.ca, jihong@cs.ubc.ca        
******************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/


#ifndef DEFINES_H
#define DEFINES_H

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <assert.h>
#include <string.h>
#include <time.h>



#include "constants.h"
#include "structs.h"
#include "externs.h"
#include "common.h"


const int DEBUG = 0;
const int MaxN = 1600; //maximum number of bases in the RNA strand
const float g_interiorPseudo = 0.83;const int multi_OffsetPseudo = 843;const int q_unpairedMultiPseudo = 0;const int p_pairedMultiPseudo = 100;

struct T_IntList{	int Num;	T_IntList * Next;};
/******************************************
//elements of the stack
*******************************************/
struct T_stackelem { 
    int MarkB , MarkP , MarkN , next, prev, nextM, prevM;
    //$next and $prev keep track of the next and the previous elements on the stack
	//nextM and pervM are the same as next and prev with skipping those nodes who have markN&markP&!markB
};
/******************************************
//possible types of the loops
*******************************************/
enum LoopType{      stackloop, hairpin,	interior,	multi,	external,	pseudo
};
/******************************************
//possible location status for the loops
*******************************************/
enum PseudoNestedType{	nothing, inBand, unBand, inMulti
};
/******************************************
*******************************************/
struct T_AllLoops{	int base1, base2;
};

/******************************************
*******************************************/
struct B_pattern {

	bool BandBorder; // true for the indexs if it is recognized to be the left border of a band region
	int next, prev; // next and prev elements in the pattern	int OtherBorder; // right border of the band region
};

#endif
