/***************************************************************************
                          globals.h  -  description
                             -------------------
    begin                : Thu Apr 11 2002
    copyright            : (C) 2002 by Mirela Andronescu
    email                : andrones@cs.ubc.ca
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef GLOBALS_H
#define GLOBALS_H

#include "constants.h"
#include "structs.h"

int debug = 0;

// energies information
int stack [NUCL] [NUCL] [NUCL] [NUCL];
int tstackh [NUCL] [NUCL] [NUCL] [NUCL];
int tstacki [NUCL] [NUCL] [NUCL] [NUCL];
int int11   [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL];
int int21   [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL];
int int22   [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL];
int dangle_top  [NUCL] [NUCL] [NUCL];
int dangle_bot  [NUCL] [NUCL] [NUCL];
int internal_penalty_by_size [MAXLOOP+1];
int bulge_penalty_by_size [MAXLOOP+1];
int hairpin_penalty_by_size [MAXLOOP+1];
miscinfo misc;
hairpin_tloop triloop[MAXTRILOOPNO];
int nb_triloops = 0;
hairpin_tloop tloop[MAXTLOOPNO];
int nb_tloops = 0;

// enthalpies information
int enthalpy_stack [NUCL] [NUCL] [NUCL] [NUCL];
int enthalpy_tstackh [NUCL] [NUCL] [NUCL] [NUCL];
int enthalpy_tstacki [NUCL] [NUCL] [NUCL] [NUCL];
int enthalpy_int11   [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL];
int enthalpy_int21   [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL];
int enthalpy_int22   [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL] [NUCL];
int enthalpy_dangle_top  [NUCL] [NUCL] [NUCL];
int enthalpy_dangle_bot  [NUCL] [NUCL] [NUCL];
int enthalpy_internal_penalty_by_size [MAXLOOP+1];
int enthalpy_bulge_penalty_by_size [MAXLOOP+1];
int enthalpy_hairpin_penalty_by_size [MAXLOOP+1];
miscinfo enthalpy_misc;
hairpin_tloop enthalpy_triloop[MAXTRILOOPNO];
hairpin_tloop enthalpy_tloop[MAXTLOOPNO];
int enthalpy_nb_triloops = 0;
int enthalpy_nb_tloops = 0;

// parameters from the configuration file
int nb_params = 56;
char par_name [56] [100] = {
            "STD_DIR",
            "RNA_STACK_ENERGY37_V31",
            "RNA_STACK_ENERGY37_V23",            
            "RNA_STACK_ENTHALPY",            
            "RNA_LOOP_ENERGY37_V31",
            "RNA_LOOP_ENERGY37_V23",            
            "RNA_LOOP_ENTHALPY",            
            "RNA_TRILOOP_ENERGY37_V31",
            "RNA_TRILOOP_ENERGY37_V23",            
            "RNA_TRILOOP_ENTHALPY",                        
            "RNA_TLOOP_ENERGY37_V31",
            "RNA_TLOOP_ENERGY37_V23",            
            "RNA_TLOOP_ENTHALPY",            
            "RNA_TSTACKH_ENERGY37_V31",
            "RNA_TSTACKH_ENERGY37_V23",            
            "RNA_TSTACKH_ENTHALPY",            
            "RNA_TSTACKI_ENERGY37_V31",
            "RNA_TSTACKI_ENERGY37_V23",            
            "RNA_TSTACKI_ENTHALPY",            
            "RNA_INT11_ENERGY37_V31",
            "RNA_INT11_ENERGY37_V23",            
            "RNA_INT11_ENTHALPY",            
            "RNA_INT21_ENERGY37_V31",
            "RNA_INT21_ENERGY37_V23",            
            "RNA_INT21_ENTHALPY",            
            "RNA_INT22_ENERGY37_V31",
            "RNA_INT22_ENERGY37_V23",            
            "RNA_INT22_ENTHALPY",            
            "RNA_MISCLOOP_ENERGY37_V31",
            "RNA_MISCLOOP_ENERGY37_V23",            
            "RNA_MISCLOOP_ENTHALPY",            
            "RNA_DANGLE_ENERGY37_V31",
            "RNA_DANGLE_ENERGY37_V23",            
            "RNA_DANGLE_ENTHALPY",
            
            "DNA_STACK_ENERGY37",
            "DNA_STACK_ENTHALPY",
            "DNA_LOOP_ENERGY37",
            "DNA_LOOP_ENTHALPY",
            "DNA_TRILOOP_ENERGY37",
            "DNA_TRILOOP_ENTHALPY",
            "DNA_TLOOP_ENERGY37",

            "DNA_TLOOP_ENTHALPY",
            "DNA_TSTACKH_ENERGY37",
            "DNA_TSTACKH_ENTHALPY",
            "DNA_TSTACKI_ENERGY37",
            "DNA_TSTACKI_ENTHALPY",
            "DNA_INT11_ENERGY37",
            "DNA_INT11_ENTHALPY",
            "DNA_INT21_ENERGY37",
            "DNA_INT21_ENTHALPY",
            "DNA_INT22_ENERGY37",
            "DNA_INT22_ENTHALPY",
            "DNA_MISCLOOP_ENERGY37",
            "DNA_MISCLOOP_ENTHALPY",
            "DNA_DANGLE_ENERGY37",
            "DNA_DANGLE_ENTHALPY"
            };

char par_value [56] [100];
char * std_dir_par                  = par_value[0];

char * rna_stack_energy37_v31_par   = par_value[1];
char * rna_stack_energy37_v23_par   = par_value[2];
char * rna_stack_enthalpy_par       = par_value[3];
char * rna_loop_energy37_v31_par    = par_value[4];
char * rna_loop_energy37_v23_par    = par_value[5];
char * rna_loop_enthalpy_par        = par_value[6];
char * rna_triloop_energy37_v31_par = par_value[7];
char * rna_triloop_energy37_v23_par = par_value[8];
char * rna_triloop_enthalpy_par     = par_value[9];
char * rna_tloop_energy37_v31_par   = par_value[10];
char * rna_tloop_energy37_v23_par   = par_value[11];
char * rna_tloop_enthalpy_par       = par_value[12];
char * rna_tstackh_energy37_v31_par = par_value[13];
char * rna_tstackh_energy37_v23_par = par_value[14];
char * rna_tstackh_enthalpy_par     = par_value[15];
char * rna_tstacki_energy37_v31_par = par_value[16];
char * rna_tstacki_energy37_v23_par = par_value[17];
char * rna_tstacki_enthalpy_par     = par_value[18];
char * rna_int11_energy37_v31_par   = par_value[19];
char * rna_int11_energy37_v23_par   = par_value[20];
char * rna_int11_enthalpy_par       = par_value[21];
char * rna_int21_energy37_v31_par   = par_value[22];
char * rna_int21_energy37_v23_par   = par_value[23];
char * rna_int21_enthalpy_par       = par_value[24];
char * rna_int22_energy37_v31_par   = par_value[25];
char * rna_int22_energy37_v23_par   = par_value[26];
char * rna_int22_enthalpy_par       = par_value[27];
char * rna_miscloop_energy37_v31_par= par_value[28];
char * rna_miscloop_energy37_v23_par= par_value[29];
char * rna_miscloop_enthalpy_par    = par_value[30];
char * rna_dangle_energy37_v31_par  = par_value[31];
char * rna_dangle_energy37_v23_par  = par_value[32];
char * rna_dangle_enthalpy_par      = par_value[33];

char * dna_stack_energy37_par       = par_value[34];
char * dna_stack_enthalpy_par       = par_value[35];
char * dna_loop_energy37_par        = par_value[36];
char * dna_loop_enthalpy_par        = par_value[37];
char * dna_triloop_energy37_par     = par_value[38];
char * dna_triloop_enthalpy_par     = par_value[39];
char * dna_tloop_energy37_par       = par_value[40];
char * dna_tloop_enthalpy_par       = par_value[41];
char * dna_tstackh_energy37_par     = par_value[42];
char * dna_tstackh_enthalpy_par     = par_value[43];
char * dna_tstacki_energy37_par     = par_value[44];
char * dna_tstacki_enthalpy_par     = par_value[45];
char * dna_int11_energy37_par       = par_value[46];
char * dna_int11_enthalpy_par       = par_value[47];
char * dna_int21_energy37_par       = par_value[48];
char * dna_int21_enthalpy_par       = par_value[49];
char * dna_int22_energy37_par       = par_value[50];
char * dna_int22_enthalpy_par       = par_value[51];
char * dna_miscloop_energy37_par    = par_value[52];
char * dna_miscloop_enthalpy_par    = par_value[53];
char * dna_dangle_energy37_par      = par_value[54];
char * dna_dangle_enthalpy_par      = par_value[55];


#endif
