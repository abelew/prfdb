/*****************************************************************
         HotKnot: A heuristic algorithm for RNA secondary 
            structure prediction including pseudoknots
         File: Loop.cpp
         Description: 
             Contains functions for Constructing the tree of closedRegions-loops! 
             Each node in the tree corresponds to a closed region in the RNA secondary structure. 
             Each closed region is a loop (hairpin, interior, multi or pseudoknotted loops)
             but not every loop is a closed region (interior-pseudo and multi-pseudoknotted loops).
             Each node contains information which are essential for calculating the free energy
             of all loops in the structure and therefore calculating the free energy
             of a secondary structure.
             
             It also contains functions for calculating the free energy of the loops
             and the free energy of the secodary structure.
             
             

 
    Date        : Oct. 16, 2004
    copyright   : (C) 2004 by Baharak Rastegari, Jihong Ren  
    email       : baharak@cs.ubc.ca, jihong@cs.ubc.ca        
******************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/


#include "Loop.h"
#define NULL 0


/******************************************************************
Takes as input the right and left border of an identified closedRegion-loop (b, e),
plus the stack S (which contains the information about the current status of the closed 
region finding program).
It then creates a node corresponding to this closedRegion-loop!
*******************************************************************/
Loop::Loop(int b, int e,  ReadInput * R, Bands * B, Stack * S){
  ILoops = NULL;
  MLoops = NULL;
  St = S;
  LeftSibling   = NULL;
  RightChild    = NULL;
  Parent		= NULL;
  begin         = b;
  end           = e;
  Input			= R;
  bandpattern	= B;
  type = external;
  NumberOfChildren	= 0;
  NumberOfUnpaird	= 0;

  NumberOfUnBandChild = 0;
  NumberOfBandChild = 0; 
  nested = nothing;

}

/*********************************************************************************
*********************************************************************************/
Loop::~Loop(){
   if (RightChild != NULL)
     delete RightChild;
}

/*********************************************************************************
WhereLocated: It figures out the location status of the loop (in-Band or out-Band).
span-Band loops are identified when a pseudoknotted loops is identified 
in FindInnerLoops function.
*********************************************************************************/
void Loop::WhereLocated(){
	int previousRegion;

//Starting from the last band region, trying to find out the location status of the loop
	while (true){
		
		if (( end <= bandpattern->pattern[Parent ->CurrentBandRegion].OtherBorder) &&
			(end >= Parent->CurrentBandRegion) )
			{
			if (begin >= Parent->CurrentBandRegion) {
				nested = inBand;
				return;
			}
			// else is it cross-Band and will identified in FindInnerLoops function
			}
		else  // moving to the previous band region
			{ 
			previousRegion = bandpattern->pattern[Parent ->CurrentBandRegion].prev;
			if (( end > bandpattern->pattern[previousRegion].OtherBorder) &&
				(end < Parent->CurrentBandRegion) )
				{ 
				nested = unBand;
				return;
			}
			else {
				Parent ->CurrentBandRegion = previousRegion;				
			}
		}
	}
				
}

/*********************************************************************************
FindInnerLoops: It figures out the interior-pseudoknotted and multi-pseudoknotted 
loops (span-band loops) nested in a pseudoknotted closed region.
*********************************************************************************/
void Loop::FindInnerLoops(int border1, int border2){		
	
if (DEBUG)
	printf("[FindInnerLoops] 1\n"); fflush(stdout);

	int i=border1;
	while (i <= border2){
		int j = bandpattern->pattern[i].OtherBorder;
		if  (Input->BasePair(i) > i){

			int ip = Input->BasePair(i);
			int jp = Input->BasePair(j);
			//[i,j]|_| [jp,ip] is a band and i < i'
  
			int x = j;
			while (x > i){
				int y = St->PrevInStack[x];
				int xp = Input->BasePair(x);
				int yp = Input->BasePair(y);

				if (  (xp >= jp) && (yp >= jp) && (xp >= St->PrevInStack[yp]) ){
					if ( (x == Input->Next[y]) && (yp == Input->Next[xp])){
					//Interior-pseudoknotted loop have been found and should be added to ILoops list
						if  (Input->BasePair(i) > i){
							if (DEBUG)
								printf("[FindInnerLoops] InteriorAdding(%d, %d)\n", y, x); fflush(stdout);

							T_IntList * IntList = new T_IntList;
							IntList->Num = y;
							IntList->Next = NULL;
							Input->looplists[y] = new LoopList(Input, y, x);
							if (DEBUG)
								printf("Adding %d to ILOOPS\n", y); fflush(stdout);
							IntList->Next = ILoops;
							ILoops = IntList;
						};
					}
					
					else{
					//Multi-pseudoknotted loop have been found and should be added to MLoops list
					//Calling the FindChildren function to finding out the tuples regarding this
					//Multi-pseudoknotted loop
						if (DEBUG)
							printf("[FindInnerLoops]begin MultiAdding(%d, %d, %d, %d)\n", y, x, xp, yp); fflush(stdout);
						//MultiLoops->Add(y, x);
						T_IntList * IntList = new T_IntList;
						IntList->Num = y;
						IntList->Next = NULL;
						Input->looplists[y] = new LoopList(Input, y, x);
						Input->looplists[y]->FindChildren();
						IntList->Next = MLoops;
						MLoops = IntList;
						if (DEBUG){
							printf("Adding %d to MLOOPS\n", y); fflush(stdout);
							printf("[FindInnerLoops] MultiAdding(%d, %d)\n", y, x); fflush(stdout);
						}
	
					};
				};

				x = y;

			};
		}

		i = bandpattern->pattern[i].next;

	}

}

/*********************************************************************************
PseudoNestedCheck: It checks weather the type of a closed region is pseudonotted
and if then call appropriate function to find the location status of its children
besides calculating the number of in-Band and un-Band children.
*********************************************************************************/
void Loop::PseudoNestedCheck(){
	
	if (type != pseudo)
		return;


	Loop * L = RightChild;
	while (L != NULL){
		L ->WhereLocated();	
		
		if (L->nested == inBand){
			NumberOfBandChild = NumberOfBandChild + 1;
		}
		else if (L->nested == unBand)
			NumberOfUnBandChild = NumberOfUnBandChild +1;
		L = L->LeftSibling;
	};

}


/*******************************************************************************
LoopSetType: It figures out type of the loop based on the borders and the 
number/type of the children.
********************************************************************************/
void Loop::loopSetType(){

	if (Input->BasePair(begin) != end){
		type = pseudo;
		return;
	};
	
	if (!RightChild){
		type = hairpin;
		return;
	};

	if ( (!RightChild->LeftSibling) && (Input->BasePair(RightChild->begin) == RightChild->end)){
		if ((RightChild->begin == begin + 1) && (RightChild->end == end - 1 )){
			type = stackloop;
			return;
		};
		type = interior;
		return;
	};

	if ( (RightChild->LeftSibling) 	||	(Input->BasePair(RightChild->begin) != RightChild->end)) {
		type = multi;
		return;
	};


	type = external;
	return;    
}

/*******************************************************************************
LoopSetType: It assign to each loop its type by calling setTypes() function.
********************************************************************************/
void Loop::setTypes(){

		loopSetType();

		Loop * L = RightChild;
		if (!L)
			return;

		while (L){
			L->setTypes();
			L = L->LeftSibling;

		};    
}

/*******************************************************************************
UnpairedBases: It calculates the number of unpaired bases in a closed region!
********************************************************************************/
int UnpairedBases(ReadInput* Input, int from, int to){
	int k = 0;
	for (int j = from; j < to; j++)
		if (Input->BasePair(j) <= 0)
			k++;

	return k;
}



/*******************************************************************************
addLoop: It adds an identified closedRegion/loop to the tree (of closed region)!
And calls appropriate functions for setting different attributes of the loop.
********************************************************************************/
void Loop::addLoop(int begin, int end){

	Loop *L1 = new Loop(begin, end, Input, bandpattern, St);
	Input->ClosedRegions[begin] = L1;


	int last = end;
	int first = begin;

	L1->Parent = this;
    
    if (!RightChild){ //If its the first loop to be added to the tree
        RightChild = L1;
		if (begin != end)
			L1->NumberOfUnpaird = UnpairedBases(Input, first, last);
		L1->loopSetType();

		L1->LoopFindBands();
		L1 ->PseudoNestedCheck();

        return;
    };
	
	    
    Loop *L = RightChild;
    int HaveChild = (L->begin >= begin);
    
    if (HaveChild)
        L1->RightChild = L;
    
    Loop *L2 = L;
	Input->loops[begin].num_branches = 0;
	Input->loops[begin].pseudo_num_branches = 0;

    // Calculating the number of tuples (branches) in the closed region.
    // Calculating the number of tuples by assgining the value equal to 2 to 
    // pseudoknotted tuples.
    // Calculating the number of children for the closed region while making the appropriate father-child
    // relationship between them.
    while (L && (L->begin >= begin)){
		Input->loops[begin].bri[Input->loops[begin].num_branches++] = L->begin;
		if (L->type == pseudo)
			Input->loops[begin].pseudo_num_branches += 2;
		else
			Input->loops[begin].pseudo_num_branches += 1;

		if (begin != end)
			L1->NumberOfUnpaird += UnpairedBases(Input, L->end, last);
		last = L->begin;


		L1->NumberOfChildren++;
        L2 = L;
		L->Parent = L1;
        L = L->LeftSibling;
    };

	// Assigning the appropriate tuples (branches) to the closed region
	for (int index = 0; index < Input->loops[begin].num_branches; index++){
		int index2 = Input->loops[begin].num_branches - index - 1;
		if (index < index2){
			if (DEBUG)
				printf("[briChanging]num_br:%d  --  %d by %d\n", Input->loops[begin].num_branches, index, index2);
			int x = Input->loops[begin].bri[index];
			Input->loops[begin].bri[index] = Input->loops[begin].bri[index2];
			Input->loops[begin].bri[index2] = x;
		};
	};
	
	
	if (begin != end)
		L1->NumberOfUnpaird += UnpairedBases(Input, first, last);
    
    if (L)
        L1->LeftSibling = L;
        
    if (L2 && HaveChild)
        L2->LeftSibling = NULL;
        
    
    RightChild = L1;

	L1->loopSetType();

	L1->LoopFindBands();
	L1 ->PseudoNestedCheck();



	if (DEBUG)		printf("[Num_branches](begin:%d) usual: %d, pseudo_num_branches %d\n", begin, Input->loops[begin].num_branches, Input->loops[begin].pseudo_num_branches);

}

/*********************************************************************************
Print: It prints out the parsing tree!
*********************************************************************************/

void Loop::Print(int i){

    for (int j = 0; j < i; j++)
        printf(".");
	if (Parent)
		printf("[%d, %d] nested: %d\n",begin, end, nested);
    Loop * L = RightChild;
    
    if (L){
    do {
        L->Print(i+1);
        L = L->LeftSibling;
    } while (L != NULL);
    
    };
}

/*********************************************************************************
LoopFindBands: It finds the bands of a pseudoknotted region and store them
in bandpattern.
*********************************************************************************/
void Loop::LoopFindBands(){



	if ( (type != pseudo) || (begin == 0)){
		if (begin > 0)
			bandpattern->Update_links(bandpattern->Prev(begin) , bandpattern->Next(end));
		return;
	};

	bandpattern->aux_Find_bands(begin, end, &NumberOfBands,&CurrentBandRegion);
	bandpattern->Update_links(bandpattern->Prev(begin) , bandpattern->Next(end));

	if (DEBUG)
		printf("[udating links](%d, %d) ==> (%d, %d)\n",begin, end,   bandpattern->Prev(begin) , bandpattern->Next(end)); fflush(stdout);
	
//Finding the interior-pseudoknotted and multi-pseudoknotted loops nested in the pseudoknooted closed region
	FindInnerLoops(begin, end);
	
	if (DEBUG)
		printf("[FindInnerLoops]"); fflush(stdout);

	if (DEBUG)
		bandpattern->Output(begin, end, NumberOfBands);


}




/****************************************************
*           ENERGY CALCULATION PART					*
*													*
*****************************************************/

/*********************************************************************************
getEnergy: calculating the summation of the free energy of the loops in
the secondary structure.
*********************************************************************************/

float Loop::getEnergy(){
	float sum = 0;	

	Loop * L = RightChild;
	while (L != NULL){
			sum += L->getEnergy();
			L = L->LeftSibling;
	};

	switch (type){
		case	stackloop:
			sum += stackEnergy();
			break;
		case	hairpin	:
			sum += hairpinEnergy();
			break;
		case	interior:
			sum += interiorEnergy();
			break;
		case	multi	:
			sum += multiEnergy();
			break;
		case	pseudo	:
			sum += pseudoEnergy();
			break;
	};

	return sum;
}


/*********************************************************************************
*********************************************************************************/
char c(int i){
	switch(i){
		case 0:
			return 'A';
		case 1:
			return 'C';
		case 2:
			return 'G';
		case 3:
			return 'T';
	};

};


/*********************************************************************************
stackEnergy: calls the appropriate function from another program (simFold) to
calculate the free energy of stacked pair.
*********************************************************************************/
int	Loop::stackEnergy(){
	str_features * f = Input->loops;
	int * sequence = Input->type;
	int i = begin;
	
	int en = LEstacked_pair_energy (i, f[i].pair, sequence);

	if (DEBUG)            
         printf ("%d stack \t- add energy %6d\n", i, en);        
	return en;
}


/*********************************************************************************
hairpinEnergy: calls the appropriate function from another program (simFold) to
calculate the free energy of a hairpin Loop.
*********************************************************************************/
int	Loop::hairpinEnergy(){
	str_features * f = Input->loops;
	int * sequence = Input->type;
	int i = begin;
	char * csequence = Input->CSequence;
    int en = LEhairpin_loop_energy (i, f[i].pair, sequence, csequence);

    if (DEBUG)            
         printf ("%d hairpin \t- add energy %6d\n", i, en);        
	return en;
}


/*********************************************************************************
interiorEnergy: calls the appropriate function from another program (simFold) to
calculate the free energy of an interior Loop.
*********************************************************************************/
int	Loop::interiorEnergy(){
	str_features * f = Input->loops;
	int * sequence = Input->type;
	int i = begin;

    int ip, jp;
    ip = f[i].bri[0];
    jp = f[f[i].bri[0]].pair;
    Input->cannot_add_dangling[ip-1] = 1;
    Input->cannot_add_dangling[jp+1] = 1;
    int en = LEinternal_loop_energy (i, f[i].pair, ip, jp, sequence);
    if (DEBUG)            
         printf ("%d interior \t- add energy %6d\n", i, en);        
    return en;

}

/*********************************************************************************
multiEnergy: it calculates the free energy of a multiLoop.
The code is similar to the one in simFold but it has been changed slightly
to consider the pseudoknotted tuples, ....
*********************************************************************************/
int	Loop::multiEnergy(){
	str_features * f = Input->loops;
	int * sequence = Input->type;
	int i = begin;
    int energy, en, AUpen, h, l;
    int dang;
    int misc_energy;

	dang = 0;
	misc_energy = 0;
	AUpen = 0;
	int special;
	special = 0;
	
	// add the energies/enthalpies for free bases
	for (l=i+1; l < f[i].bri[0]; l++)
		misc_energy += misc.multi_free_base_penalty;

	if (DEBUG)
		printf("[misc_energy]1 is %d\n", misc_energy);
	for (h=0; h < f[i].num_branches-1; h++)
	{
		for (l = f[f[i].bri[h]].pair + 1; l < f[i].bri[h+1]; l++)
			misc_energy += misc.multi_free_base_penalty;
	}
	for (l = f[f[i].bri[f[i].num_branches-1]].pair + 1; l < f[i].pair; l++)
		misc_energy += misc.multi_free_base_penalty;

	if (DEBUG)
		printf("[misc_energy]2 is %d\n", misc_energy);
	misc_energy += misc.multi_offset;

	if (DEBUG)
		printf("[misc_energy]3 is %d\n", misc_energy);
	if (DEBUG)
		printf("[%%%%%%%%%%%%%%%%%%%%%%%%5]misc.u.tidfjfwrw = %d\n", misc.multi_offset);
	
	misc_energy += misc.multi_helix_penalty * (f[i].pseudo_num_branches + 1);




	// add AU_penalties for multi-loop
	AUpen += AU_penalty (sequence[i], sequence[f[i].pair]);

	for (h=0; h < f[i].num_branches; h++)
		AUpen += AU_penalty (sequence[f[i].bri[h]],sequence[f[f[i].bri[h]].pair]);

	// add dangling energies for multi-loop
	dang += dangling_energy_left (sequence, i, f[i].pair, f[i].bri[0], f[f[i].bri[0]].pair);

	for (l=0; l < f[i].num_branches - 1; l++){
		dang += dangling_energy (sequence, f[i].bri[l], f[f[i].bri[l]].pair, f[i].bri[l+1], f[f[i].bri[l+1]].pair);
	};
	dang += dangling_energy_right (sequence, i, f[i].pair, f[i].bri[f[i].num_branches-1], f[f[i].bri[f[i].num_branches-1]].pair);

	// add "no-dangling" restriction                                    
	for (l=0; l < f[i].num_branches; l++)
	{
		Input->cannot_add_dangling [f[i].bri[l] -1] = 1;
		Input->cannot_add_dangling [f[f[i].bri[l]].pair + 1] = 1;
	}
	if (DEBUG)
	{
		printf ("%d - multi m\t- add energy %6d\n", i, misc_energy);            
		printf ("%d - multi d\t- add energy %6d\n", i, dang);
		printf ("%d - multi AU\t- add energy %6d\n", i, AUpen);
	}                

    if (DEBUG)            
         printf ("%d multi \t- add energy %6d\n", i, misc_energy + dang + AUpen);        
			return misc_energy + dang + AUpen;  


}


/*********************************************************************************
pseudoEnergy: it calculates the free energy of a pseudoknotted loop.
It also calculates the free energy of interior-pseudoknotted and multi-pseudoknotted
loops regarding the pseudoknotted loop and add them to the energy
of pseudoknotted loop.
*********************************************************************************/

float	Loop::pseudoEnergy(){
	
	float P_tilda = 0.1; // pair in a pseudoknot
	float Q_tilda = 0.2; // unpaired bases in a pseudoknot
	float P_i = 0.1; // for E&R energy model
	float Gw = 7; //starting a pseudoknot loop
	float Gwh = 6; //each more band region

	float Energy;
	
	Energy = (Gw+   // Starting a pseudoloop
                         Gwh * (NumberOfBands -2 ) +
                     Q_tilda* NumberOfUnpaird + //unpaired bases part
                     P_tilda * 2 *NumberOfBands + //bands part
                         P_i * NumberOfUnBandChild);        //nested 
	if (DEBUG)
		printf("[PseudoEnergy] Energy: %.2f NumBands: %d,  NumUnpaired: %d,   NumberOfUnBandChild: %d\n", 100*Energy, 
			NumberOfBands, NumberOfUnpaird,  NumberOfUnBandChild);
	Energy *= 100;


//Calculating the free energy of interior-pseudoknotted loops
	T_IntList * L1 = ILoops;
	T_IntList * L2 = MLoops;

	while (L1 != NULL){
		float en = Input->looplists[L1->Num]->interiorPseudoEnergy();
		if (DEBUG)
			printf("[ILoops]: (%d, %d) Energy: %.2f \n", L1->Num, Input->BasePair(L1->Num), en); fflush(stdout);
		Energy += en;
		L1 = L1->Next;
	};

//Calculating the free energy of multi-pseudoknotted loops
	while (L2 != NULL){
		float en = Input->looplists[L2->Num]->multiPseudoEnergy();
		if (DEBUG)
			printf("[MLoops]: (%d, %d) Energy: %.2f\n", L2->Num, Input->BasePair(L2->Num), en); fflush(stdout);
		Energy += en;
		if (DEBUG)
			printf("[Resulted Energy} : %.2f \n", Energy);
		L2 = L2->Next;
	};

    if (DEBUG)            
		printf("[PseudoEnergy] energy of [%d, %d] is %f\n", begin, end, Energy);

	return Energy;

}

/*********************************************************************************
Energy: Calculate the free energy of RNA secondary structure by calling
getEnergy function for calculating the energy associated with the loops and
then adding some other penalties and other energy values corresponding to the
secondary structure (where some of them construct the free energy of the external loop).
The main part is calling functions from simFold program and is changed slightly to consider
pseudoknotted substructures.
*********************************************************************************/
float Loop::Energy(){


	str_features * f = Input->loops;
	int * sequence = Input->type;
    int energy = 0, en, AUpen = 0, h, l;
    int dang;
    int misc_energy;

	float GetEnergy = getEnergy();

	int nb_nucleotides = Input->Size + 1;

    for (int i=1; i < nb_nucleotides; i++)
	{
        // add some AU_penalties
        if (i==1 && f[i].pair > i)
        {
            AUpen = AU_penalty (sequence[i], sequence[f[i].pair]);
            if (DEBUG)
                printf ("%d - AUpen1 \t- add energy %6d\n", i, AUpen);
            energy += AUpen;            
        }            
        else if ( i > 1 && f[i].pair > i && f[i-1].pair < i-1 &&
             f[i-1].pair != 0 && !Input->cannot_add_dangling[i])
            //  )(  
        {            
            AUpen = AU_penalty (sequence[i], sequence[f[i].pair]);
            if (DEBUG)
                printf ("%d - AUpen2 \t- add energy %6d\n", i, AUpen);
            energy += AUpen;            
        }            
    
        // add dangling energies and AU_penalties
        if (f[i].pair == 0 && !Input->cannot_add_dangling[i])
		{
            if ((i == 1 || (i > 1 && f[i-1].pair == 0)) &&
                 i < nb_nucleotides-1 && f[i+1].pair > i+1)
                // .( or ..(
            {
                dang = MIN (0, dangle_bot [sequence[f[i+1].pair]] [sequence[i+1]] [sequence[i]]);
                AUpen = AU_penalty (sequence[i+1], sequence[f[i+1].pair]);
                if (DEBUG)
                {
                    printf ("%d - dangle1 \t- add energy %6d\n", i, dang);
                    printf ("%d - AUpen3 \t- add energy %6d\n", i, AUpen);
                }                    
                energy += dang + AUpen;
            }
            else if ((i == nb_nucleotides-1 || 
                     (i < nb_nucleotides-1 && f[i+1].pair == 0)) &&
                     i > 0 && f[i-1].pair > 0 && f[i-1].pair < i-1)
                // ). or )..
            {
                dang = MIN (0, dangle_top [sequence[i-1]] [sequence[f[i-1].pair]] [sequence[i]]);
                if (DEBUG)                
                    printf ("%d - dangle2 \t- add energy %6d\n", i, dang);
                energy += dang;
            }
            else if (i < nb_nucleotides-1 && f[i+1].pair > i+1 && f[i-1].pair < i-1 && f[i-1].pair != 0)
               // ).( 
            {
                dang = MIN (0, dangling_energy (sequence, f[i-1].pair, i-1, i+1, f[i+1].pair));
                AUpen = AU_penalty (sequence[i+1], sequence[f[i+1].pair]);
                if (DEBUG)
                {              
                    printf ("%d - dangle1 \t- add energy %6d\n", i, dang);
                    printf ("%d - AUpen4 \t- add energy %6d\n", i, AUpen);
                }    
                energy += dang + AUpen;
            }
            else
            {
                continue;
            }
        }
	};

	return -10*(energy + GetEnergy);
}



