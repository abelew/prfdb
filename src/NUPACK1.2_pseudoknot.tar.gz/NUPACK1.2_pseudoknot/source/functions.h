/*  functions.h by Robert Dirks 07/24/2001

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     


Functions called in pfunc.c (and/or fold.c) 

Functions that start with "Exp", such as
ExpHairpin, indicate the returned value is the exponential 
exp( -Energy of hairpin / RT ).  Functions that start with "SumExp"
indicate that they return the sum of exp( -E_s /RT) over all possible 
substructures s of a specific type e.g. SumExpInternal will find all possible 
internal loops and return the contribution of these internal loops to Q

*/

#define FUNCTIONS_H


/* ************************ */
// Macros

#define MIN(x,y) (((x)<(y)) ? (x) : (y))
//This macro returns the min of x,y, regardless of type

#define MAX(x,y) (((x)>(y)) ? (x) : (y))
/* ****************************** */
//Structs

typedef struct{
  char *seq;
  int seqlength;
  int *pairs;
  int *pknots;

} fold;     


/* ************************************** */
/* Functions in utils.c */

int gap_index(int, int, int, int, int);
// Calculate index for the gap matrix

int pf_index( int, int, int);
// Calculate the index for Qx (x = ' ', b, p, m, m1), for the partition
// function between i and j, inclusive.

int Equal( double, double);
//return TRUE if two doubles are within 0.0001
    
int Base2int( char);
// Convert A,C,G,T to 1,2,3,4, repsectively

int GetMismatchShift( char, char);
// Given a base pair, this does the following 
// A-T -> 0
// C-G -> 1
// G-C -> 2
// T-A -> 3
// G-T -> 4
// T-G -> 5

int GetPairType( char);
// same as GetMismatchShift except always < 4

int CanPair( char, char);
// Can the 2 inputs form a Watson Crick or Wobble base pair?
// returns TRUE or FALSE

/* ************************** */
/* functions in init.c */

void ReadSequence( int*, char**, char[]);
// Read in a DNA sequence

void InitDoublesMatrix( double**, int, char[]); 
// Allocate Memory for a double matrix with a specified size

void InitFloatMatrix( float**, int, char[]); 
// Allocate Memory for a double matrix with a specified size

void InitIntMatrix( int **Q, int size, char name[]);
//Allocate Memory for an int matrix of a specified size

void nonZeroInit( double*, char*, int);
//Initialize non zero elements
 
void LoadEnergyFromStandardFile( char[]);
// Data loading scheme.  

void InitFold( int, char**, int**);
// Initialize secondary structure.

 
/* ************************** */
/* Energy Functions  */
// exp_energy.c

double ExpHairpin( int i, int j, char[]);
// This gives the value of exp( -E/RT) where E is the energy of the 
// hairpin loop closed by bases i and j.  

double ExpInternal( int i, int j, int h, int m, char[] );
// This gives the value of exp( -E/RT) where E is the energy of the
// interior loop closed by i-j and h-m

/* **************************** */
// energy.c

double HelixEnergy( char i, char j, char h, char m);
// This gives the helix energy of the stack containing pairs i-j and
// h-m

double InteriorMM( char a, char b, char x, char y);
// This gives the energy of the interior loop mismatch with
// a-b paired and x-y as the terminal mismatch

double HairpinEnergy(  int i, int j, char[]);
// This gives the energy of the hairpin loop closed by bases i and j.  

double InteriorEnergy( int i, int j, int h, int m, char[]);
// Calculates energy of interior loop closed by i-j and h-m

double DangleEnergy( int, int, char[], int);
//Calculate the dangle energy of a single stranded region (i,j), assuming
//i-1 and j+1 are paired, assuming i != 0, j != seqlength - 1;

double DangleEnergyWithPairs( int, int, int[], char[], int);
/*Use this to properly handle wobbles if pairing info is known */

#ifdef COAXIAL
double CoaxDangle( int, int, int, int*, char*, int);
#endif

/* ************************** */
/* Functions in  Qb recursion */
double ExpDangle( int , int , char[], int);

#ifdef O_N3
void manageQx( double**, double**, double**, int, int);
void manageFx( double**, double**, double**, int, int);


double SumExpInextensibleIL( int , int , char[], int, double[]);
double MinInextensibleIL( int , int , char[], int, double[]);

double SumExpQm_N3( int, int, char[], int, double[], double[]);

void extendOldQx( int , int , char[], int,double[], double[], double[]);
void extendOldFx( int , int , char[], int,double[], double[], double[]);


void makeNewQx( int, int, char[], int, double[], double[]);
void makeNewFx( int, int, char[], int, double[], double[]);

void fastILoops( int, int, int, int, char[], double[], double[], double[]);
void fastILoops_Fb( int, int, int, int, char[], double, double[], 
		    double[], double[]);

double SumExpMultiBp_N3( int , int , char[], double[], double[], int);
// Decomposes the region inside pair i,j into multiloops, i.e.
// the number of pk + bp, including the closing pair is >= 3.
// returns sum of exponentials.  Places a non-pk as rightmost element
#endif

#if defined O_N4 || defined (PKNOTS)
double SumExpQb( int, int, char[], int, double[], double[]);
double MinFb( int, int, char[], int, double[], double[]);
#endif

#ifdef PKNOTS
double SumExpQb_Pk( int, int, char[], int, double[], double[]);
double MinFb_Pk(  int, int, char[], int, double[], double[]);
#endif
/* ********************** */
//Qp recursion
#ifdef O_N8
double SumExpQp_N8( int, int, char[], int, double[], double[]);
double MinFp_N8( int, int, char[], int, double[], double[]);

#endif
#ifdef O_N5
double SumExpQp_N5( int, int, char[], int, double[], double[]);
double MinFp_N5( int, int, char[], int, double[], double[]);
#endif

/* ************************** */
/* Functions in Qs, Qms recursion*/
#ifdef O_N3 
void MakeQs_Qms( int, int, char[], int, double[], double[], double[]);
/* Calculate the min values for the F_noPk matrix (no pseudoknots)
     Assume that j+1 is paired, unless j == seqlength - 1
     Likewise, assume i - 1 is paired, unless i == 0
*/  
void MakeFs_Fms( int, int, char[], int, double[], double[], double[]);

#endif
/* ****************************** */
// Functions in Q, Qm, Qz recursions
#ifdef O_N3
void MakeQ_Qm_N3( int, int, char[], int, double[], double[],
		 double[], double[]);
void MakeF_Fm_N3( int, int, char[], int, double[], double[],
		 double[], double[]);
#endif

#if defined(O_N4) || defined(PKNOTS)
void MakeQ_Qm_N4( int, int, char[], int, double[], double[],
		    double[]);
void MakeF_Fm_N4( int, int, char[], int, double[], double[],
		    double[]);
#endif

#ifdef PKNOTS
void MakeQ_Qm_Qz( int, int, char[], int, double[], double[], double[],
		  double[], double[]);
void MakeF_Fm_Fz( int, int, char[], int, double[], double[], double[],
		  double[], double[]);
#endif

/* ******************************** */
/* Functions in min.c */

#ifdef O_N3
double MinMultiBp_N3( int, int, char[], double[], double[], int);
// Gives minimum energy of a multiloop, with rightmost pair (excluding
// closing pair) not part of a pseudoknot
#endif


/* ******************************** */
/* functions in backtrack.c */

void Backtrack( int, char[], int[], double[], double[], double[], double[],
		double[], double[],
		double, char[]);
// This calculates a structure with the minimum free energy 

void bktr_open( int, int, double, int[],  
		double[], double[], double[], double[], double[],
		double[],  double, int, char[]);
// This subroutine is for the exterior loop

void bktr_bp( int, int, double, int[], double[], double[],
	      double[], double[], double[],
	      double[], double, int, char[]);
// This subroutine is for regions within a bp

void bktr_multi( int, int, double, int[], double[], double[],
		 double[], double[], double[], 
		 double[], double, int, char[] );
// This subroutine is for regions in a multiloop and containing at least 1 pair

int pknot_multi( int, int, int, int, double, 
		 int[], double[], 
		 double[], double[], double[], double[], double[],
		 double, int, char[]);
// This subroutine is for regions in a multiloop and containing at least 1 pk

int pknot_open( int, int, int, int, double, int[], double[], 
		  double[], double[], double[], double[], double[],
		  double, int, char[]); 
// This checks to see if a pknot is needed in "open" structure

int pknot_bp( int, int, int, int, double, int[], double[], 
		  double[], double[], double[], double[], 
		  double[], double, int, char[]); 
// This checks to see if a pknot is needed in a region with a closing pair


void bktr_pk( int, int, double, int[], 
	      double[], double[], double[],  
	      double[], double[], double[],  
	      double, int, char[]);
// This finds a pseudoknot with the specified energy

void bktr_pk_int( int, int, double, int[],
		 double[],  double[], double[], 
		 double[],  double[], double[],
		 int, char[]);
// This checks the interior of a pseudoknot for more basepairs between the
// 'helical' regions

void bktr_Fg(int, int, int, int, char[], int, 
	     double, double[], double[], double[],
	     double[], double[], double[], int[]);
// This finds a Gap Matrix with the specified energy

void PrintStructure( char[], int[], int);
// This prints out the structure of a mfe fold


/* ************************************ */
//Functions for Qg
#ifdef O_N8
void MakeQg_N8(int, int, char[], int, double[], double[]);
void MakeFg_N8(int, int, char[], int, double[], double[]);
#endif

#ifdef O_N5
void MakeQg_N5( int, int, char[], int, double[], double[], double[],
		double[], double[], double[], short[]);
void MakeFg_N5( int, int, char[], int, double[], double[], double[],
		double[], double[], double[], short[]);

void fastIloop_Qg( int, int, char[], int, double[], double[], double[],
		   short[]);
void fastIloop_Fg( int, int, char[], int, double[], double[], double[],
		   short[]);

void MakeQgls( int, int, char[], int, double[], double[], 
	       double[]);
void MakeFgls( int, int, char[], int, double[], double[], 
	       double[]);

void MakeQgrs( int, int, char[], int, double[], double[], 
	       double[]);
void MakeFgrs( int, int, char[], int, double[], double[], 
	       double[]);

void MakeQgl( int, int, char[], int, double[], double[], 
	      double[]);
void MakeFgl( int, int, char[], int, double[], double[], 
	      double[]);
void MakeQgr( int, int, char[], int, double[], double[], 
	      double[]);
void MakeFgr( int, int, char[], int, double[], double[], 
	      double[]);

#endif //O_N5




//*********************************


/* Functions for pknots.c */

void MakeFg( int, int, char[], int, double[], double[]);
// This fills in the entries of Gap Matrix, given the outer ends.

double MinPk( int, int, char[], int, double[], double[]);
// Finds the min energy pseudoknot

double MinInternalPk( int, int, char[], int, double[]);
// Find the minimum energy internal loop with a pseudoknot inside

double InteriorPkEnergy( int, int, int, int, char[]);
// Find energy between a regular base pair and a single pseudoknot

double MinMultiPk( int, int, char[], int,  double[], double[]);
// Gives minimum energy of a multiloop, with rightmost pair (excluding
// closing pair) part of a pseudoknot

double Min1pk( int, int, char[], int, double[]);
// Gives minimum energy of multiloop region where this pk is the last
// substructure in the multiloop.

double MinFmpk( int, int, char[], int, double[], double[]);
// Gives minimum energy of multiloop region containing a rightmost pk
// plus at least 1 bp or pk to the left (towards 5' end)

double MinRightPk( int, int, char[], int, double[], double[]);
// Gives minimum energy of a sequence with a rightmost pk


double PkIntEmpty( int, int, char[], int);
// This is calculates the energy of a singlestranded region inside of 
// pseudoknot

double PkIntEmpty_CW( int, int, char[], int, char);
// This is calculates the energy of a singlestranded region inside of 
// pseudoknot, allowing for wobble pairs on either side

double MinPkIntRightBp( int, int, char[], int, double[], double[]);
// This calculate the minimum energy structure in part of a pseudoknot
// that contains a rightmost, simple base pair

double MinPkIntRightPk( int, int, char[], int, double[], double[]);
// This calculate the minimum energy structure in part of a pseudoknot
// that contains a rightmost, simple base pair

#ifdef N5

void MakeFgl( int, int, char[], int, double[], double[], double[]);

void MakeFgr( int, int, char[], int, double[], double[], double[]);

#endif


//************* fast interior loop evaluation **************

#ifdef O_N5

void makeNewQgIx( int, int, char[], int, double[], double[]);
void makeNewFgIx( int, int, char[], int, double[], double[]);

void extendOldQgIx( int, int, int, int, char[], 
		    int, double[], double[], double[]);
void extendOldFgIx( int, int, int, int, char[], 
		    int, double[], double[], double[]);

void manageQgIx( double**, double**, double**, int, int);  
void manageFgIx( double**, double**, double**, int, int);  

int QgIxIndex( int, int , int , int , int , int);

double SumExpInextensibleIL_Qg( int, int, int, int, 
				char[], int, double[]);
double MinInextensibleIL_Fg( int, int, int, int, 
				char[], int, double[]);

void PrecomputeValues( int);
void PrecomputeValues_fold( int);

void CheckPossiblePairs( short**, int, char[]);
#endif

#ifdef O_N3
int fbixIndex(int, int, int, int);
#endif
/* ********************************************************* */

//Functions for GetEnergy.c CalculateEnergy.c (Energy.out functions)

void Getfold( fold *thefold, char filename[]);  
// Read in input file (seq? + graph connections)

void getStructureFromParens( char*, char*, int*, int);

double GetEnergy( fold *thefold);
/* this evaluates the sequence energy */

double EnergyF( int, int, fold*);
double EnergyFb( int, int, fold*);
double EnergyPk( int, int, fold*);
double EnergyFg( int, int, int, int, fold*);
double EnergyFz( int, int, fold*);

#ifdef COAXIAL
double minCoaxialStacking( fold*, int, int*, double);
double minCoax( int, int, int, int, int*, fold*);
double CoaxEnergy( char, char, char, char);
#endif
/* ***************************************** */
//Functions for pairsPr.c 

void calculatePairsN4( double[], double[], double[],
		       double[], int, char[]);

double rightmostInMulti( int, int, int, int, double[],
			 double[], char[], int);

double middleInMulti( int, int, int, int, double[],
			 double[], char[], int);

double leftmostInMulti( int, int, int, int, double[],
			 double[], char[], int);

void calculatePairsN8( double[], double[], double[],
		       double[], double[], double[],
		       double[], double[], double[], 
		       double[], double[], double[],
		       double[],
		       int,
		       char[]);

void PseudoknotLoop( int, int, int, 
		     double[], double[], double[], double[], double[],
		     double[], double[], char[], int);

void MakePg_N8( int i, int j, char seq[], int seqlength, double Qg[],
		double Qm[], double Pg[], double Pm[]);

void calculatePairsN3_OLD( double[], double[], double[],
			   double[],
			   double[], double[], double[],  
			   int, char[]);

void calculatePairsN3( double[], double[], double[],
		       double[], double[], double**,
		       double**, double**, double[],
		       double[], double[], double[],
		       double[], int, char[]);

void calculatePairsN5_old( double[], double[], double[],
			   double[], double[], double[], 
			   double[], double[], double[],
			   double[], double[], double[], 
			   double[], double[], double[],
			   double[], double[], double[], 
			   double[], double[], double[], 
			   int, char[]);

void calculatePairsN5( double[], double[], double[],
		       double[], double[], double[], 
		       double[], double[], double[],
		       double[], double**, double**, 
		       double**, double[], double[],
		       double[], double[], double[], 
		       double[], double[], double[],
		       double[], double[], double[],
		       int, char[]);

void MakeP_Pm_Pz( int, int, char[], int, double[], double[], double[],
		  double[], double[], double[], double[], double[], double[],
		  double[]);
void MakePgr( int i, int j, char seq[], int seqlength, 
	      double Qgr[], double Qgl[], double Qz[],
	      double Pgr[], double Pgl[], double Pz[]);

void MakePgl( int i, int j, char seq[], int seqlength, 
	      double Qg[], double Qgl[], double Qz[],
	      double Pg[], double Pgl[], double Pz[], double[]);

void MakePgrs( int i, int j, char seq[], int seqlength, double Qg[], 
	       double Qm[], double Qgrs[], double Pg[], double Pm[],
	       double Pgrs[]);

void MakePgls( int i, int j, char seq[], int seqlength, double Qg[], 
	       double Qm[],  double Qgls[], double Pg[], double Pm[],
	       double Pgls[]);
void MakePg_N5_old( int i, int j, char seq[], int seqlength, double Qg[],
		    double Qm[], double Qgls[], double Qgrs[], 
		    double Pg[], double Pm[], double Pgls[], double Pgrs[]);

void MakePg_N5( int i, int j, char seq[], int seqlength, double Qg[],
		double Qm[], double Qgls[], double Qgrs[], 
		double QgIx[], double QgIx_2[],  
		double Pg[], double Pm[], double Pgls[], double Pgrs[],
		double PgIx[], double PgIx_2[]);

void MakePb_N5( int i, int j, char seq[], int seqlength, 
		double Qm[], double Qb[], double Qp[], 
		double Pm[], double Pb[], double Pp[]);


void PseudoknotLoopN5( int, int, int, double[], double[], double[],
		       double[], double[], double[],  
		       char[], int);

#if defined (PAIRPR) && defined(O_N3)
void prFastILoops( int, int, int, int, char[], double[], double[],
		   double[], double[], double[], double[], double[]);

void prManageQx( double**, double**, double**, double**, double**,
	double**, int, int);
#endif

#if defined (PAIRPR) && defined(O_N5)
void prFastILoopsN5( int, int, char[], int, double[], double[],
		     double[], double[], double[], double[]);

void prManageQgIx( double**, double**, double**, double**, double**,
		   double**, int, int);

void MakePg_Inextensible( int, int,int, int, char[], int,
			  double[], double[]);
#endif			       
/* ************************* */

void header( void);
//print header

/* *************** */
