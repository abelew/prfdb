/* init.c by Robert Dirks 07/25/2001

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     

Functions to be run once at the beginning of my
partition function algorithm
*/

#ifndef CONSTANTS_H
#include"constants.h"
#endif

#ifndef FUNCTIONS_H
#include"functions.h"
#endif

#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include "DNAExternals.h"
/* ************************************************* */
void ReadSequence( int *seqlength, 
		   char **seq, 
		   char filename[ MAXLINE] ) {
  FILE *fp;
  char line[MAXLINE];
  int i; //position in line
  int linenumber; //line number
  char tempSeq[ MAXSEQLENGTH];


  *seqlength = 0;

#ifndef PRINTRESULTSONLY  
  printf("Reading Input File...\n");
#endif
  fp = fopen(filename, "r");
  if( fp == NULL) {  /* Make sure input file exits */
    printf("Error opening file %s\n", filename);
    exit(0);  
  }

  linenumber = 0;
  while( fgets(line, MAXLINE, fp)!= NULL ) {  // Read lines
    linenumber++;
    i = 0;

    while( line[0] != '>' && line[i] != '\n') {
      line[i] = toupper( line[i] );

#ifdef RNA
      if( line[i] == 'T') {
	line[i] = 'U';
      }
#else
      if( line[i] == 'U') {
	line[i] = 'T';
      }
#endif

      if( line[i] != 'A' && line[i] != 'T' && line[i] != 'C'
	    && line[i] != 'G' && line[i] != 'U') {
	if( line[i] != ' ' && line[i] != '\t') {
	  printf("Invalid base at line %d, position %d\n", linenumber, i+1);
	  exit(0);
	}
      }
      else {
	if( line[i] != ' ' && line[i] != '\t' && line[i] != '\n') {
	  tempSeq[ *seqlength] = line[i];
	  // seq[ *seqlength] = line[i];
	  (*seqlength)++;
	}
      }
      i++;
    }
  }

  *seq = (char *) calloc( *seqlength, sizeof( char) );
  if( *seq == NULL) {
    printf("Unable to allocate memory for '*seq'\n");
    exit(0);
  }

  for( i = 0; i < *seqlength; i++) {
    (*seq)[ i] = tempSeq[ i];
  }

}


/* ********************************************* */

void InitDoublesMatrix( double **Q, int size, char name[]) {

  // Allocate cleared memory for a doubles matrix.
 
  *Q =  (double *) calloc( size, sizeof( double));
 
  if( *Q == NULL) {
    printf("Unable to allocate memory for %s!\n", name);
    exit(0);
  }

}
/* ********************************************** */
void InitFloatMatrix( float **Q, int size, char name[]) {

  // Allocate cleared memory for a doubles matrix.
 
  *Q =  (float *) calloc( size, sizeof( float));
 
  if( *Q == NULL) {
    printf("Unable to allocate memory for %s!\n", name);
    exit(0);
  }

}
/* ********************************************** */


void InitIntMatrix( int **Q, int size, char name[]) {

  // Allocate cleared memory for a doubles matrix.

 
  *Q =  (int *) calloc( size+1, sizeof( int));

  if( *Q == NULL) {
    printf("Unable to allocate memory for %s!\n", name);
    exit(0);
  }

}
/* ******************************************** */
void nonZeroInit( double Q[], char seq[], int seqlength) {
  // Set Q[i, i-1] = 1.
  int i;
 
  for( i = 0; i <= seqlength; i++) {
    Q[ pf_index(i, i-1, seqlength)] = ExpDangle(i,i-1,seq,seqlength);
  }
}

/* ************************************** */

void InitFold( int seqlength, char **thefold, int **thepairs) {
  // thefold will be a character array containing a string of type
  // ...(((...))) with () representing pairs, and . representing unpaired 
  // bases.  thepairs[i] = j will indicate base i is paired with base j
  
  int i;

  *thefold = (char *) calloc( seqlength, sizeof( char));
  *thepairs = (int *) calloc( seqlength, sizeof( int ));

  if( *thefold == NULL || *thepairs == NULL) {
    printf("Unable to allocate memory for thefold or thepairs\n");
    exit(0);
  }

  for( i = 0; i < seqlength; i++) {
    (*thefold)[i] = '.';
    (*thepairs)[i] = -1;
  }
}

/* ***************************** */
#ifdef O_N5

void manageQgIx( double **QgIx, double **QgIx_1, 
		 double **QgIx_2, int d, int seqlength) {
  // Allocate and deallocate QgIx matrices
  
  long int maxStorage;
  long int dTest;
  double *temp;

  if( d == 16) { //First time
    
    maxStorage = 0;
    for( dTest = d; dTest < d+3; dTest++) {
      maxStorage = MAX( maxStorage, (seqlength-dTest)*(dTest-5)*
			((dTest-1)*(dTest-2)/2) );
    }
    
    *QgIx = (double *) calloc( maxStorage, 
			       sizeof( double));
    *QgIx_1 = (double *) calloc( maxStorage, 
				 sizeof( double));
    *QgIx_2 = (double *) calloc( maxStorage, 
				 sizeof( double));

    if( *QgIx == NULL || *QgIx_1 == NULL || *QgIx_2 == NULL) {
      printf("Unable to allocate memory for QgIx, QgIx_1 or QgIx_2\n");
      exit(0);
    }
    
  }       
  else if( d == seqlength - 1) {
    temp = *QgIx;
    *QgIx = *QgIx_1;
    *QgIx_1 = temp; //this is needed for pairs calculations
    /*
    *QgIx_2 = //this array is worthless
      (double *) calloc( maxStorage, sizeof( double));
    */
  }
  else if( d > 16) { // every case beyond the first
    maxStorage = 0;
    for( dTest = d; dTest < d+3; dTest++) {
      maxStorage = MAX( maxStorage, (seqlength-dTest)*(dTest-5)*
			((dTest-1)*(dTest-2)/2) );
    }
    temp = *QgIx;
    *QgIx = *QgIx_1;
    *QgIx_1 = *QgIx_2;
    free(temp);
    *QgIx_2 = (double *) calloc( maxStorage, sizeof(double) );
    if( *QgIx_2 == NULL) {
      printf("Error in QgIx_2 allocation! %ld %d %d\n", 
 	     maxStorage, d, seqlength);
      exit(0);
    }
  }
   
}

/* **************************************** */
void manageFgIx( double **FgIx, double **FgIx_1, 
		 double **FgIx_2, int d, int seqlength) {
  // Allocate and deallocate FgIx matrices

  int i;
  long int maxStorage;
  long int dTest;
  double *temp;

  if( d > 16) { // every case beyond the first
    maxStorage = 0;
    for( dTest = d; dTest < d+3; dTest++) {
      maxStorage = MAX( maxStorage, (seqlength-dTest)*(dTest-5)*
			((dTest-1)*(dTest-2)/2) );
    }
    temp = *FgIx;
    *FgIx = *FgIx_1;
    *FgIx_1 = *FgIx_2;
    free(temp);
    *FgIx_2 = (double *) calloc( maxStorage, sizeof(double) );
    if( *FgIx_2 == NULL) {
      printf("Error in QgIx_2 allocation! %ld %d %d\n", 
 	     maxStorage, d, seqlength);
      exit(0);
    }
    for( i = 0; i < maxStorage; i++) {
      (*FgIx_2)[i] = NAD_INFINITY;
    }
  }
  else if( d == 16) { //First time
    
    maxStorage = 0;
    for( dTest = d; dTest < d+3; dTest++) {
      maxStorage = MAX( maxStorage, (seqlength-dTest)*(dTest-5)*
			((dTest-1)*(dTest-2)/2) );
    }
  
    *FgIx = (double *) calloc( maxStorage, 
			       sizeof( double));
    *FgIx_1 = (double *) calloc( maxStorage, 
			       sizeof( double));
    *FgIx_2 = (double *) calloc( maxStorage, 
			       sizeof( double));

    if( *FgIx == NULL || *FgIx_1 == NULL || *FgIx_2 == NULL) {
      printf("Error in FgIx, FgIx_1, FgIx_2 allocation\n");
      exit(0);
    }

    for( i = 0; i < maxStorage; i++) {
      (*FgIx_2)[i] = (*FgIx_1)[i] = (*FgIx)[i] = NAD_INFINITY;
      
    }

  }       
}
#endif

/* ******************** */
#ifdef O_N5
void PrecomputeValues( int seqlength) {
  
  int i;
  extern double loop37[];
  extern double *sizeTerm;

  sizeTerm = (double *) calloc( seqlength, sizeof( double) );
  if( sizeTerm == NULL) {
    printf("Unable to allocate memory for sizeTerm!\n");
    exit(0);
  }

  for( i = 8; i < seqlength; i++) {
    
    if( i <= 30) {
      sizeTerm[i] = -loop37[ i - 1];
    }
    else {
      sizeTerm[i] = -loop37[ 30 - 1];
      sizeTerm[i] -= 1.75*R_GAS*TEMP_K*log( i/30.0); 
    }
    if( i + 2 <= 30) {
      sizeTerm[i] += loop37[ i+2 - 1];
    }
    else {
      sizeTerm[i] += loop37[ 30 - 1];
      sizeTerm[i] += 1.75*R_GAS*TEMP_K*log( (i+2)/30.0); 
    }
    sizeTerm[i] = exp( -sizeTerm[i]/(R_GAS*TEMP_K) );
    
  }

}

/* *********************** */

void PrecomputeValues_fold( int seqlength) {
  
  int i;
  extern double loop37[];
  extern double *sizeTerm;

  sizeTerm = (double *) calloc( seqlength, sizeof( double) );
  if( sizeTerm == NULL) {
    printf("Unable to allocate memory for sizeTerm!\n");
    exit(0);
  }

  for( i = 8; i < seqlength; i++) {
    
    if( i <= 30) {
      sizeTerm[i] = -loop37[ i - 1];
    }
    else {
      sizeTerm[i] = -loop37[ 30 - 1];
      sizeTerm[i] -= 1.75*R_GAS*TEMP_K*log( i/30.0); 
    }
    if( i + 2 <= 30) {
      sizeTerm[i] += loop37[ i+2 - 1];
    }
    else {
      sizeTerm[i] += loop37[ 30 - 1];
      sizeTerm[i] += 1.75*R_GAS*TEMP_K*log( (i+2)/30.0); 
    } 
  }
}
#endif //O_N5

#ifdef O_N3
/* *************************************************** */
void manageQx( double **Qx, double **Qx_1, 
		 double **Qx_2, int len, int seqlength) {
  // Allocate and deallocate QbIx matrices

  int i;
  int maxStorage;
  double *temp;

  maxStorage = (seqlength - len)*(len - 1);
  for( i = len+1; i <= len + 2; i++) {
    maxStorage = MAX( maxStorage, ( seqlength - i)*(i - 1) );
  }
 

  if( len == 14) { //first use of these matrices
    *Qx = (double *) calloc( maxStorage, sizeof( double));
    *Qx_1 = 
      (double *) calloc( maxStorage, sizeof( double));
    *Qx_2 = 
      (double *) calloc( maxStorage, sizeof( double));
    
    if( *Qx == NULL || *Qx_1 == NULL || *Qx_2 == NULL) {
      printf("Error in Qx, Qx_1, Qx_2 allocation\n");
      exit(0);
    }

  }
  else if( len == seqlength - 1 && len > 14) {
    temp = *Qx;
    *Qx = *Qx_1;
    *Qx_1 = temp; //this is needed for pairs calculations
    /*
    *Qx_2 = //this array is worthless
      (double *) calloc( maxStorage, sizeof( double));
    */
  }
  else if( len > 14) {
    
    temp = *Qx;
    *Qx = *Qx_1;
    *Qx_1 = *Qx_2;
    free( temp);
    *Qx_2 =
      (double *) calloc( maxStorage, sizeof( double));
    
    if( *Qx_2 == NULL) {
      printf("Unable to allocate memory for Qx_2\n");
      exit(0);
    }

  }
}

/* *************************************************** */
void manageFx( double **Fx, double **Fx_1, 
		 double **Fx_2, int len, int seqlength) {
  // Allocate and deallocate QbIx matrices

  int i;
  int maxStorage;
  double *temp;

  maxStorage = (seqlength - len)*(len - 1);
  for( i = len+1; i <= len + 2; i++) {
    maxStorage = MAX( maxStorage, ( seqlength - i)*(i - 1) );
  }
 

  if( len == 14) { //first use of these matrices
    *Fx = (double *) calloc( maxStorage, sizeof( double));
    *Fx_1 = 
      (double *) calloc( maxStorage, sizeof( double));
    *Fx_2 = 
      (double *) calloc( maxStorage, sizeof( double));
    
    if( *Fx == NULL || *Fx_1 == NULL || *Fx_2 == NULL) {
      printf("Error in Fx, Fx_1, Fx_2 allocation\n");
    }

    for( i = 0; i < maxStorage; i++) {
      (*Fx_2)[i] = (*Fx_1)[i] = (*Fx)[i] = NAD_INFINITY;      
    }

  }
  else if( len > 14) {
    
    temp = *Fx;
    *Fx = *Fx_1;
    *Fx_1 = *Fx_2;
    free( temp);
    *Fx_2 =
      (double *) calloc( maxStorage, sizeof( double));

    if( *Fx_2 == NULL) {
      printf("Error in Fx_2 allocation\n");
      exit(0);
    }


    for( i = 0; i < maxStorage; i++) {
      (*Fx_2)[i] = NAD_INFINITY;      
    }

  }
}

#endif //O_N3

/* ************************************** */
