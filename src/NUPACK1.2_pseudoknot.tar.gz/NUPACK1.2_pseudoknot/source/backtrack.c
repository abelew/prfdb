/* Backtrack.c 08/07/2001 by Robert Dirks

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE" 

The purpose of this collection of subroutines is to take the calculated 
values for the minimum energies on each contiguous subsequence and to find
a structure that has the minimum possible free energy (mfe).

This code is definitely not optimal, but still runs fast.  
Future versions of this software will hopefully clean it up.
*/

#ifndef CONSTANTS_H
#include"constants.h"
#endif

#ifndef FUNCTIONS_H
#include"functions.h"
#endif

#include<stdio.h>
#include<math.h>
#include<stdlib.h>

#include"DNAExternals.h"

/* ********************************************* */

void Backtrack( int seqlength, char thefold[], int thepairs[], 
		double F[], double Fb[], double Fm[], 
		double Fp[], double Fg[],
		double Fp_int_S[],  
		double mfe, char seq[] ) {
  // This program invokes the backtrack scheme

  double pre_energy = 0.0; 
  /*pre_energy is the energy of the computed structure "outside" of what 
    is being currently investigated */

  bktr_open( 0, seqlength - 1, pre_energy, thepairs, F, Fb, Fm, Fp,
	     Fg, Fp_int_S,  
	     mfe, seqlength, seq);

  PrintStructure( thefold, thepairs, seqlength);

  printf( "mfe = %0.2f kcal/mol\n", 
	  F[ pf_index( 0, seqlength - 1, seqlength) ]);

}

/* ***************************************************** */

void bktr_open( int i, int j, double pre_energy, int thepairs[], 
		double F[], double Fb[], double Fm[], double Fp[],
		double Fg[],
		double Fp_int_S[],  
		double mfe, int seqlength, char seq[]) {

  /* This function backtracks assuming there is no basepair or pk containing
     i - j (except for the possibility of i-j pair itself). in other words,
     i and j are part of the exterior loop 
    
  */

  int h, m;
  int done = FALSE;
  double dangle;
  double bp_penalty = 0.0;
  double new_pre_energy;

#ifdef DEBUG
  printf("bktr_open %d %d!\n", i, j);
#endif
  
  if( F[ pf_index( i, j, seqlength)] == DangleEnergy(i, j, seq, seqlength) ) { 
    return; // Leave i to j single stranded
  }

  h = i;
  m = h + 4;

  while( (h < j) && ( m <= j) && (done == FALSE) ) {

    //reset loop parameters
    bp_penalty = 0.0;

    if( CanPair( seq[h], seq[m]) == TRUE && 
	Base2int( seq[h]) + Base2int( seq[m]) != 7 ) {

      if( seq[h] != 'C' && seq[h] != 'G') {
	bp_penalty += AT_PENALTY;
      }

      dangle = DangleEnergy( m+1, j, seq, seqlength);

      new_pre_energy = pre_energy + dangle + bp_penalty;
      if( h == i)  {
	if( Equal( new_pre_energy +  Fb[ pf_index(h, m, seqlength) ], mfe) ) {
	  if( thepairs[h] != -1 || thepairs[m] != -1 ) {
	    printf("Error in assigning pairs in backtrack!\n");
	    exit(0);
	  }
	  thepairs[h] = m;
	  thepairs[m] = h;
	  
	  bktr_bp( h, m, new_pre_energy, thepairs,  F, Fb, Fm, Fp, 
		   Fg, Fp_int_S, mfe, seqlength, seq);
	  done = TRUE;
	}
      }
      else {
	if( Equal(new_pre_energy + Fb[ pf_index(h, m, seqlength) ] +
		  F[ pf_index( i, h-1, seqlength)], 
		  mfe) == TRUE ) {
	  if( thepairs[h] != -1 || thepairs[m] != -1 ) {
	    printf("Error in assigning pairs in backtrack!\n");
	    exit(0);
	  }
	  thepairs[h] = m;
	  thepairs[m] = h;
	  
	  bktr_bp( h, m, new_pre_energy + F[ pf_index( i, h-1, seqlength)] , 
		   thepairs,  F, Fb, Fm, Fp, 
		   Fg, Fp_int_S,  mfe, seqlength, seq);
	  bktr_open( i, h-1, new_pre_energy + Fb[ pf_index(h, m, seqlength) ],
		     thepairs,  F, Fb, Fm, Fp,
		     Fg, Fp_int_S,  
		     mfe, seqlength, seq);
	  done = TRUE;
	}
      }
    }
#ifdef PKNOTS
    //Insert pseudoknot check
    if( done == FALSE && m >= h+8) {
      done = pknot_open( i, j, h, m, pre_energy, thepairs, 
			 F, Fb, Fm, Fp, Fg,  
			 Fp_int_S, 
			 mfe, seqlength, seq); 
      //check if pseudoknot is in best structure
    }
#endif
    if( m < j) {
      m++;
    }
    else if( m == j) {
      if( h < j - 1) {
	h++;
	m = h + 4;
      }
      else {
	printf("mfe not found in bktr_open!\n");
	exit(0);
      }
    }
  }
  if( done == FALSE) {
    printf("mfe not found in bktr_open!!!\n");
    exit(0);
  }

}
    
/* **************************************************** */

void bktr_bp( int i, int j, double pre_energy, int thepairs[], 
	      double F[], double Fb[], double Fm[], double Fp[],
	      double Fg[],
	      double Fp_int_S[], 
	      double mfe, int seqlength, char seq[]) {
  /* This is the backtrack algorithm for i paired with j */


  int h, m;
  int done = FALSE;
  double new_pre_energy;
  double bp_penalty = 0.0;
  double dangle = 0.0;

#ifdef DEBUG
  printf("bktr_bp %d %d %f %f %f!\n", i, j, pre_energy, mfe,
	 Fb[ pf_index( i, j, seqlength)]);
#endif

  // Check if simple hairpin
  if( Fb[ pf_index( i, j, seqlength)] == HairpinEnergy( i, j, seq) ) { 
    return;
  }
  
  h = i + 1;
  m = h + 4;
  while( (h < j) && ( m < j) && (done == FALSE) ) {
       
    // The following cases could probably be combined, but this is
    // easier for now

    // Interior Loop - Bulge - stack
    if( CanPair( seq[h], seq[m]) == TRUE) {
      new_pre_energy = pre_energy + InteriorEnergy(i, j, h, m, seq);
    }
    else {
      new_pre_energy = NAD_INFINITY;
    }

    if( Equal( new_pre_energy + Fb[ pf_index(h, m, seqlength) ],
	       mfe) == TRUE ) {

      if( thepairs[h] != -1 || thepairs[m] != -1 ) {
	printf("Error in assigning pairs in backtrack!\n");
	exit(0);
      }
      thepairs[h] = m;
      thepairs[m] = h;
      
      bktr_bp( h, m, new_pre_energy, thepairs,  F, Fb, Fm, Fp, 
	       Fg, Fp_int_S, mfe, seqlength, seq);
      done = TRUE;
    }
    else if( h > i + 5 && Base2int( seq[i]) + Base2int( seq[j]) == 5 &&
	     Base2int( seq[h]) + Base2int( seq[m]) == 5 ) {
      //Multiloop

      bp_penalty = 0.0;
      if( seq[i] != 'C'  && seq[j] != 'C') {
	bp_penalty += AT_PENALTY;
      }
      if( seq[h] != 'C'  && seq[m] != 'C') {
	bp_penalty += AT_PENALTY;
      }
      
      // compute dangle on 3' side of h-m pair
      dangle = DangleEnergy( m+1, j-1, seq, seqlength);
    	
      new_pre_energy = pre_energy + dangle +  
	( ALPHA_1 + 2*ALPHA_2 + bp_penalty + (j - m - 1)*ALPHA_3 );
      if( Equal( new_pre_energy + Fb[ pf_index(h, m, seqlength) ] + 
	  Fm[ pf_index( i+1, h - 1, seqlength) ], mfe) == TRUE) {
	
	if( thepairs[h] != -1 || thepairs[m] != -1 ) {
	  printf("Error in assigning pairs in backtrack!\n");
	  exit(0);
	}
	
	thepairs[h] = m;
	thepairs[m] = h;
	
	bktr_bp( h, m, new_pre_energy + 
		 Fm[ pf_index( i+1, h - 1, seqlength) ],
		 thepairs,  F, Fb, Fm, Fp, Fg,  
		 Fp_int_S, mfe, seqlength, seq);


	bktr_multi( i+1, h-1, new_pre_energy+Fb[ pf_index(h, m, seqlength) ],
		    thepairs, F, Fb, Fm, Fp, 
		    Fg, 
		    Fp_int_S,  mfe, seqlength, seq);
	
	done = TRUE;
      }
      
    }
#ifdef PKNOTS
    if( Base2int( seq[i] ) + Base2int( seq[j]) != 7) {
      //Insert pseudoknot check
      if( done == FALSE && m >= h+8) {
	done = pknot_bp( i, j, h, m, pre_energy, thepairs, 
			 F, Fb, Fm, Fp, Fg,  
			 Fp_int_S, 
			 mfe, seqlength, seq); 
	//check if pseudoknot is in best structure
      }
    }
#endif
    if( m < j - 1) {
      m++;
    }
    else if( m == j - 1) {
      if( h < j - 2) {
	h++;
	m = h + 4;
      }
      else {
	printf("mfe not found in bktr_bp!\n");
	exit(0);
      }
    }
  }
   if( done == FALSE) {
    printf("mfe not found in bktr_bp!!!\n");
    exit(0);
  }
}


/* ***************************************************** */

void bktr_multi( int i, int j, double pre_energy, int thepairs[], 
		 double F[], double Fb[], double Fm[], double Fp[], 
		 double Fg[],
		 double Fp_int_S[], 
		 double mfe, int seqlength, char seq[]) {
  /* This is the backtrack algorithm for [i,j] in a multiloop
     with at least 1 bp in [i,j].  */

  int h, m;
  int done = FALSE;
  double new_pre_energy;
  double bp_penalty = 0.0;
  double dangle;

#ifdef DEBUG
  printf("bktr_multi %d %d %f %f!\n", i, j, pre_energy, mfe);
#endif
  

  h = i;
  m = h + 4;

  while( (h < j) && ( m <= j) && (done == FALSE) ) {

    // The following cases could probably be combined, but this is
    // easier for now

    // Case 1: h-m is final pair in multiloop
    if( Base2int( seq[h]) + Base2int( seq[m]) == 5 ) {
      bp_penalty = 0.0;
      if( seq[h] != 'C'  && seq[m] != 'C') {
	bp_penalty += AT_PENALTY;
      }

      dangle = DangleEnergy(i, h-1, seq, seqlength);
      dangle += DangleEnergy(m+1, j, seq,seqlength);

      new_pre_energy = pre_energy + dangle + ALPHA_2 + bp_penalty + 
	ALPHA_3*( (j - m) + (h - i) ); 
    }
    else {
      new_pre_energy = NAD_INFINITY;
    }
    
    if( Equal( new_pre_energy + Fb[ pf_index(h, m, seqlength) ], mfe) 
	== TRUE) {
      if( thepairs[h] != -1 || thepairs[m] != -1 ) {
	printf("Error in assigning pairs in backtrack!\n");
	exit(0);
      }
      thepairs[h] = m;
      thepairs[m] = h;
      
      bktr_bp( h, m, new_pre_energy, thepairs,  F, Fb, Fm, Fp, 
	       Fg,  Fp_int_S,  mfe, seqlength, seq);
      done = TRUE;
    }

    else if( h >= i + 5 && 
	     ( Base2int( seq[h]) + Base2int( seq[m]) == 5) ) { 
      //Case 2: At least 2 more pairs
      bp_penalty = 0.0;
      
      if( seq[h] != 'C'  && seq[m] != 'C') {
	bp_penalty += AT_PENALTY;
      }
      
      dangle = DangleEnergy( m+1, j, seq, seqlength);

      new_pre_energy = pre_energy + ALPHA_2 + bp_penalty + 
	dangle + ALPHA_3*( j - m);
      
      if( Equal( new_pre_energy + Fb[ pf_index(h, m, seqlength) ] + 
		 Fm[ pf_index( i, h - 1, seqlength) ], mfe) == TRUE) {
	
	if( thepairs[h] != -1 || thepairs[m] != -1 ) {
	  printf("Error in assigning pairs in backtrack!\n");
	  exit(0);
	}
	
	thepairs[h] = m;
	thepairs[m] = h;
	
	bktr_bp( h, m, new_pre_energy + 
		 Fm[ pf_index( i, h - 1, seqlength) ],
		 thepairs,  F, Fb, Fm, Fp, Fg, 
		 Fp_int_S,  mfe, seqlength, seq);
	
	bktr_multi( i, h-1, new_pre_energy+Fb[ pf_index(h, m, seqlength) ],
		    thepairs, F, Fb, Fm, Fp, 
		    Fg, 
		    Fp_int_S,  mfe, seqlength, seq);

	done = TRUE;
      }

    }
#ifdef PKNOTS
    //Insert pseudoknot check
    if( done == FALSE && m >= h+8) {
      done = pknot_multi( i, j, h, m, pre_energy, thepairs, 
			  F, Fb, Fm, Fp, Fg,  
			  Fp_int_S, 
			  mfe, seqlength, seq); 
      //check if pseudoknot is in best structure
    }
#endif
    if( m < j) {
      m++;
    }
    else if( m == j) {
      if( h < j - 2) {
	h++;
	m = h + 4;
      }
      else {
	printf("mfe not found in bktr_multi!\n");
	exit(0);
      }
    }
  }

  if( done == FALSE) {
    printf("mfe not found in bktr_multi!!!\n");
    exit(0);
  }
}


/* ***************************************************** */

int pknot_open(  int i, int j, int h, int s, double pre_energy, 
		 int thepairs[], double F[], double Fb[], double Fm[], 
		 double Fp[], double Fg[], 
		 double Fp_int_S[], 
		 double mfe, int seqlength, char seq[]) {
  
  // essentially identical to bktr_open, except checks for pk

  double dangle = 0.0;
  //  double bp_penalty = 0.0;
  double new_pre_energy = 0.0;
  int done = FALSE;

#ifdef DEBUG
  printf("pk_open %d %d %f!\n", i, j, mfe);
#endif

  dangle = DangleEnergy( s+1, j, seq, seqlength);
	
  new_pre_energy = pre_energy + dangle /*+ bp_penalty*/ + BETA_1;

  if( h == i) {
    if( Equal( new_pre_energy + Fp[ pf_index(h, s, seqlength) ], mfe) ==TRUE) {
 
      bktr_pk( h, s, new_pre_energy, thepairs, F, Fb, Fm, Fp, 
	       Fg,  Fp_int_S, 
	       mfe, seqlength, seq);
      done = TRUE;
    }
  }
  else {
    if( Equal( new_pre_energy +Fp[ pf_index(h, s, seqlength) ] +
	       F[ pf_index(i, h-1, seqlength)], mfe) == TRUE) {      
      bktr_open( i, h - 1, new_pre_energy + Fp[ pf_index(h, s, seqlength) ] , 
		 thepairs, F, Fb, Fm, Fp,
		 Fg, Fp_int_S,  
		 mfe, seqlength, seq);
      bktr_pk( h, s, new_pre_energy + F[ pf_index(i, h-1, seqlength)], 
	       thepairs, F, Fb, Fm, Fp, 
	       Fg,  Fp_int_S, 
	       mfe, seqlength, seq);

      done = TRUE;
    }
  }

  return done;
}

/* ********************************************************* */

void bktr_pk( int h5, int s3, double pre_energy, int thepairs[], 
	      double F[], double Fb[], double Fm[], double Fp[],  
	      double Fg[], 
	      double Fz[],
	      double mfe, int seqlength, char seq[]) { 
  // This finds a pseudoknot with the specified energy


  int i5, i3, k5, k3, h3, s5; // 4 pairs: h5-h3, i5-i3, s5-s3, k5-k3
  double energy;
  double bp_penalty;

  extern char pairsFileName[];
  FILE *pairfile;

  extern int containsPk;

#ifdef DEBUG
  printf("bktr_pk! %d %d\n", h5, s3);
#endif
  containsPk = TRUE;

  pairfile = fopen( pairsFileName, "a");
  fprintf( pairfile, "p %d %d\n", h5+1, s3+1);
  fclose( pairfile); 
  
  
  for( i5 = h5 + 1; i5 < s3 - 6; i5++) {
    for( s5 = i5+1; s5 < s3 - 5; s5++) {
      if( CanPair( seq[ s5], seq[ s3]) == TRUE &&
	  (s3 - s5) > 3 && 
	  Base2int( seq[s5]) + Base2int( seq[s3]) == 5
	  ) {
	for( k5 = s5 + 1; k5 < s3 - 4; k5++) {
	  for( i3 = k5 + 1; i3 < s3 - 2; i3++) {
	    if( CanPair( seq[ i5], seq[ i3]) == TRUE &&
		(i3 - i5) > 3 && 
		Base2int( seq[i5]) + Base2int( seq[i3]) == 5
		) {
	      for( h3 = i3+1; h3 < s3 - 1; h3++) {
		if( CanPair( seq[ h5], seq[ h3]) == TRUE &&
		    (h3 - h5) > 3 &&
		    Base2int( seq[h5]) + Base2int( seq[h3]) == 5
		    ) {
		  for( k3 = h3 + 1; k3 < s3; k3++) {
		    if( CanPair( seq[k5], seq[k3]) == TRUE &&
			(k3 - k5) > 3 &&
			Base2int( seq[k5]) + Base2int( seq[k3]) == 5
			) {

		      bp_penalty = 0.0;
		      if( seq[k5] != 'C' && seq[k3] != 'C') {
			bp_penalty += AT_PENALTY;
		      }
		      if( seq[i5] != 'C' && seq[i3] != 'C') {
			bp_penalty += AT_PENALTY;
		      }
		      if( seq[h5] != 'C' && seq[h3] != 'C') {
			bp_penalty += AT_PENALTY;
		      }
		      if( seq[s5] != 'C' && seq[s3] != 'C') {
			bp_penalty += AT_PENALTY;
		      }

		      energy = 
			Fg[ gap_index( h5, i5, i3, h3, seqlength)] +
			Fg[ gap_index( s5, k5, k3, s3, seqlength) ] + 
			bp_penalty /*+ BETA_1*/ + 2*BETA_2;


		      //if( h3 != k3 - 1) {
			energy += 
			  Fz[ pf_index( h3 + 1, k3 - 1, seqlength)];
			
			//} 
			//if( k5 != i3 - 1) {
			energy += 
			  Fz[ pf_index( k5 + 1, i3 - 1, seqlength)];
			//}
			//if( i5 != s5 - 1) {
			energy += 
			  Fz[ pf_index( i5 + 1, s5 - 1, seqlength)];
			//}

		      /*
		      printf("%d %d %d %d %d %d %d %d energy = %f, Fp = %f\n", 
			     h5, i5, s5, k5, i3, h3, k3, s3,
			     energy, Fp[ pf_index(h5, s3, seqlength)] );
		      */

		      if( Equal( pre_energy + energy, mfe)==TRUE) {
			
			if( thepairs[i5] != -1 || thepairs[i3] != -1 ) {
			  printf("Error in assigning pairs in backtrack!\n");
			  exit(0);
			}
			thepairs[ i5] = i3;
			thepairs[ i3] = i5;

			bktr_Fg( h5, i5, i3, h3, seq, seqlength,
				 Fg[ gap_index( h5, i5, i3, h3, seqlength)],
				 Fg, Fm, F, Fb, Fp, Fz, thepairs);

			if( thepairs[k5] != -1 || thepairs[k3] != -1 ) {
			  printf("Error in assigning pairs in backtrack!\n");
			  exit(0);
			}
			thepairs[ k5] = k3;
			thepairs[ k3] = k5;

			bktr_Fg( s5, k5, k3, s3, seq, seqlength,
				 Fg[ gap_index( s5, k5, k3, s3, seqlength)],
				 Fg, Fm, F, Fb, Fp, Fz, thepairs);

			if( h3 != k3 - 1) {
			  bktr_pk_int( h3+1, k3-1, 
				       Fz[ pf_index( h3 + 1, k3 - 1, 
							   seqlength)],
				       thepairs, F, Fb, Fm, Fp, 
				       Fg, Fz, 
				       seqlength, seq);  
			  //backtrack this interior portion
			}
			if( k5 != i3 - 1) {
			  bktr_pk_int( k5+1, i3-1, 
				       Fz[ pf_index( k5 + 1, i3 - 1, 
							   seqlength)],
				       thepairs, F, Fb, Fm, Fp, 
				       Fg, Fz, 
				       seqlength, seq);  
			  //backtrack this interior portion
			}
			if( i5 != s5 - 1) {
			  bktr_pk_int( i5+1, s5 - 1, 
				       Fz[ pf_index( i5 + 1, s5 - 1, 
							   seqlength)],
				       thepairs, F, Fb, Fm, Fp, 
				       Fg, Fz, 
				       seqlength, seq);  
			  //backtrack this interior portion
			}
			return;
		      }
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    }
  }
  printf("Error: Pseudoknot not found in bktr_pk! h5 = %d, s3 = %d\n",
	 h5, s3);
  exit(0);
}
  

/* **************************************** */
void bktr_Fg( int i, int d, int e, int j, char seq[], int seqlength, 
	      double energy, double Fg[], double Fm[], 
	      double F[], double Fb[], double Fp[], 
	      double Fz[],
	      int thepairs[]) {
  // This finds the pairs in a Gap Matrix with the specified energy
  
  int c, f;
  double new_energy;
  double preEnergy;
  double bp_penalty;
  double IJ_bp_penalty;

#ifdef DEBUG
  printf("bktr_Fg! %d %d %d %d %f\n", i, d,e,j, energy);
#endif
  

  if( thepairs[i] != -1 || thepairs[j] != -1 ) {
    printf("Error in assigning pairs in backtrack!\n");
    exit(0);
  }
  thepairs[ i] = j;
  thepairs[ j] = i;
  
  if( Equal( InteriorEnergy( i,j,d,e,seq), energy) == TRUE ) {
    return;
  }

  IJ_bp_penalty = 0;
  if( seq[i] != 'C' && seq[j] != 'C') {
    IJ_bp_penalty = AT_PENALTY;
  }

  bp_penalty = IJ_bp_penalty;
  if( seq[d] != 'C' && seq[e] != 'C') {
    bp_penalty += AT_PENALTY;
  }

  //check multiloop left
  if( d >= i+7) {
    new_energy = Fm[ pf_index( i+1, d-1, seqlength)] +
      ALPHA_1 + 2*ALPHA_2 + (j-e-1)*ALPHA_3 + bp_penalty + 
      DangleEnergy( e+1, j-1, seq, seqlength);
  
    if( Equal( new_energy, energy) == TRUE) {
      preEnergy = ALPHA_1 + 2*ALPHA_2 + (j-e-1)*ALPHA_3 + bp_penalty +
	DangleEnergy( e+1, j-1, seq, seqlength);
      bktr_multi( i+1, d-1, preEnergy, thepairs, F, Fb, Fm, Fp, Fg, 
		  Fz, energy, seqlength, seq);
      return;
    }
  }

  if( j >= e+7) {
    //check multiloop right
    new_energy = 
      Fm[ pf_index( e+1, j-1, seqlength)] +
      ALPHA_1 + 2*ALPHA_2 + (d-i-1)*ALPHA_3 + bp_penalty + 
      DangleEnergy( i+1, d-1, seq, seqlength);
  
    if( Equal( new_energy, energy) == TRUE) {
      preEnergy = ALPHA_1 + 2*ALPHA_2 + (d-i-1)*ALPHA_3 + bp_penalty + 
	DangleEnergy( i+1, d-1, seq, seqlength);
      bktr_multi( e+1, j-1, preEnergy, thepairs, F, Fb, Fm, Fp, Fg, 
		  Fz, energy, seqlength, seq);
      return;
    }
  }

  if( d>= i+7 && j >= e+7) {
    //check multiloop both sides
    new_energy = 
      Fm[ pf_index( i+1, d-1, seqlength)] +
      Fm[ pf_index( e+1, j-1, seqlength)] +
      ALPHA_1 + 2*ALPHA_2 + bp_penalty;
  
    if( Equal(new_energy, energy) == TRUE) {
      preEnergy = Fm[ pf_index( e+1, j-1, seqlength)] +
	ALPHA_1 + 2*ALPHA_2 + bp_penalty;
      bktr_multi( i+1, d-1, preEnergy, thepairs, F, Fb, Fm, Fp, Fg, Fz, 
		  energy, seqlength, seq);
      preEnergy = Fm[ pf_index( i+1, d-1, seqlength)] +
	ALPHA_1 + 2*ALPHA_2 + bp_penalty;
      bktr_multi( e+1, j-1, preEnergy, thepairs, F, Fb, Fm, Fp, Fg, Fz, 
		  energy, seqlength, seq);
      return;
    }
  }

  for( c = i+1; c < d; c++) {
    for( f = e+1; f < j; f++) {
      if( CanPair( seq[c], seq[f]) == TRUE) {

	//Simple Interior Loop
	new_energy = InteriorEnergy( i, j, c, f, seq) + 
	  Fg[ gap_index( c, d, e, f, seqlength)];
	if( Equal( new_energy, energy)==TRUE) {
	  bktr_Fg( c, d, e, f, seq, seqlength, 
		   Fg[ gap_index( c, d, e, f, seqlength)],
		   Fg, Fm, F, Fb, Fp, Fz, thepairs);
	  return;
	}

	bp_penalty = IJ_bp_penalty;
	if( seq[c] != 'C' && seq[f] != 'C') {
	  bp_penalty += AT_PENALTY;
	}

	if( Base2int( seq[c]) + Base2int( seq[f]) == 5) {
	  if( c>= i+7) {
	    
	    //Multiloop left + more Fg
	    new_energy =   Fm[ pf_index( i+1, c-1, seqlength)] +
	      ALPHA_1+2*ALPHA_2+(j-f-1)*ALPHA_3 + bp_penalty + 
	      Fg[ gap_index( c, d, e, f, seqlength)] + 
	      DangleEnergy( f+1, j-1, seq, seqlength);
	    if( Equal( new_energy, energy)==TRUE) {
	      bktr_Fg( c, d, e, f, seq, seqlength, 
		       Fg[ gap_index( c, d, e, f, seqlength)],
		       Fg, Fm, F, Fb, Fp, Fz, thepairs);
	      preEnergy = ALPHA_1+2*ALPHA_2+(j-f-1)*ALPHA_3 + bp_penalty + 
		Fg[ gap_index( c, d, e, f, seqlength)]  + 
		DangleEnergy( f+1, j-1, seq, seqlength);
	      bktr_multi( i+1, c-1, preEnergy, thepairs, F, Fb, Fm, Fp, Fg, Fz, 
			  energy, seqlength, seq);
	      return;
	    }
	  }
	  
	  if( j>= f+7) {
	    
	    //Multiloop Right + more Fg
	    new_energy = 
	      Fm[ pf_index( f+1, j-1, seqlength)]+
	      ALPHA_1+2*ALPHA_2+(c-i-1)*ALPHA_3+bp_penalty+
	      Fg[ gap_index( c, d, e, f, seqlength)] + 
	      DangleEnergy( i+1, c-1, seq, seqlength);
	    
	    if( Equal( new_energy, energy) == TRUE) {
	      bktr_Fg( c, d, e, f, seq, seqlength, 
		       Fg[ gap_index( c, d, e, f, seqlength)],
		       Fg, Fm, F, Fb, Fp, Fz, thepairs);
	      preEnergy = ALPHA_1+2*ALPHA_2+(c-i-1)*ALPHA_3 + bp_penalty + 
		Fg[ gap_index( c, d, e, f, seqlength)] + 
		DangleEnergy( i+1, c-1, seq, seqlength);
	      bktr_multi( f+1, j-1, preEnergy, thepairs, F, Fb, Fm, Fp, Fg, Fz, 
			  energy, seqlength, seq);
	      return;
	    }
	  }

	  if( c>= i+7 && j>=f+7) {
	    //Multiloop both sides + moreFg
	    new_energy = Fm[ pf_index( i+1, c-1, seqlength)]+
	      Fm[ pf_index( f+1, j-1, seqlength)]+
	      ALPHA_1+2*ALPHA_2+bp_penalty +
	      Fg[ gap_index( c, d, e, f, seqlength)];
	    
	    if( Equal( new_energy, energy) == TRUE) {
	      bktr_Fg( c, d, e, f, seq, seqlength, 
		       Fg[ gap_index( c, d, e, f, seqlength)],
		       Fg, Fm, F, Fb, Fp, Fz, thepairs);
	      preEnergy =  Fm[ pf_index( f+1, j-1, seqlength)]+
		ALPHA_1+2*ALPHA_2+bp_penalty +
		Fg[ gap_index( c, d, e, f, seqlength)];
	      bktr_multi( i+1, c-1, preEnergy, thepairs, F, Fb, Fm, Fp, Fg, Fz, 
			  energy, seqlength, seq);
	      preEnergy = Fm[ pf_index( i+1, c-1, seqlength)]+
		ALPHA_1+2*ALPHA_2+bp_penalty +
		Fg[ gap_index( c, d, e, f, seqlength)];
	      bktr_multi( f+1, j-1, preEnergy, thepairs, F, Fb, Fm, Fp, Fg, Fz, 
			  energy, seqlength, seq);
	      return;
	    }
	  }
	}
      }
    }
  }
    
  printf("Error in bktr_Fg!\n");
  exit(0);

}

/* ************************************************* */

int pknot_bp(  int i, int j, int h, int s, double pre_energy, 
	       int thepairs[], double F[], double Fb[], double Fm[], 
	       double Fp[], double Fg[], 
	       double Fp_int_S[], 
	       double mfe, int seqlength, char seq[]) {
  //determine min energy with i-j paired and h-s ends of a pk  
  
  int done = FALSE;
  double new_pre_energy;
  double bp_penalty = 0.0;
  double dangle = 0.0;

#ifdef DEBUG
  printf("pk_bp! %d %d %d %d\n",i,j,h,s);
#endif
  
  new_pre_energy = pre_energy + DangleEnergy( i+1, h-1, seq, seqlength) +
    DangleEnergy( s+1, j-1, seq, seqlength) + BETA_1M + 
    3*ALPHA_2 + ALPHA_1 + (j-s-1 + h-i-1)*ALPHA_3;
   
  if( Equal( new_pre_energy + Fp[ pf_index(h, s, seqlength) ], mfe)==TRUE) {
    bktr_pk( h, s, new_pre_energy, thepairs, F, Fb, Fm, Fp,  
	     Fg,  Fp_int_S,  mfe, seqlength, seq);
    done = TRUE;
  }
  else if( h > i + 5) { //multiloops
    bp_penalty = 0.0;
    if( seq[i] != 'C'  && seq[j] != 'C') {
      bp_penalty += AT_PENALTY;
    }
    // compute dangle on 3' side of s pair

    dangle = DangleEnergy( s+1,j-1,seq,seqlength);
       
    new_pre_energy = pre_energy + dangle + BETA_1M +  
      ( ALPHA_1 + 3*ALPHA_2 + bp_penalty + (j - s - 1)*ALPHA_3 );
    
    if( Equal( new_pre_energy + Fp[ pf_index(h, s, seqlength) ] + 
	       Fm[ pf_index( i+1, h - 1, seqlength) ], mfe)==TRUE) {
      
      bktr_pk( h, s, new_pre_energy + 
	       Fm[ pf_index( i+1, h - 1, seqlength) ],
	       thepairs,  F, Fb, Fm, Fp, Fg, 
	       Fp_int_S, mfe, seqlength, seq);
      
      bktr_multi( i+1, h-1, new_pre_energy + Fp[ pf_index(h, s, seqlength) ],
		  thepairs, F, Fb, Fm, Fp, 
		  Fg, 
		  Fp_int_S, 
		  mfe, seqlength, seq);
      
      done = TRUE;
    }
    
  }
  return done;
}

/* ********************************************* */

int pknot_multi( int i, int j, int h, int s, double pre_energy, 
		 int thepairs[], double F[], double Fb[], double Fm[], 
		 double Fp[], double Fg[], 
		 double Fp_int_S[], 
		 double mfe, int seqlength, char seq[]) {
  //determine min energy with h-s ends of a pk as part of [i,j] region  

  int done = FALSE;
  double new_pre_energy;
  double bp_penalty = 0.0;
  double dangle;

#ifdef DEBUG
  printf("pk_multi!\n");
#endif
  
  // Case 1: h-s is final element in multiloop
  bp_penalty = 0.0;

  dangle = DangleEnergy( i, h-1,seq,seqlength);
  dangle += DangleEnergy( s+1, j,seq, seqlength);
  
  new_pre_energy = pre_energy + dangle + 2*ALPHA_2 + bp_penalty + 
    ALPHA_3*( (j - s) + (h - i) ) + BETA_1M; 

  if( Equal( new_pre_energy + Fp[ pf_index(h, s, seqlength) ], mfe)==TRUE) {
      
    bktr_pk( h, s, new_pre_energy, thepairs,  F, Fb, Fm, Fp, 
	     Fg,  Fp_int_S,  
	     mfe, seqlength, seq);
    done = TRUE;
  }
  else if( h > i + 5) { //Case 2: At least 2 more pairs (multi)
    // bp_penalty is the same;

    dangle = DangleEnergy( s+1, j,seq,seqlength);
  
    new_pre_energy = pre_energy + 2*ALPHA_2 + bp_penalty + 
      dangle + ALPHA_3*( j - s) + BETA_1M;
    
    if( Equal( new_pre_energy + Fp[ pf_index(h, s, seqlength) ] + 
	Fm[ pf_index( i, h - 1, seqlength) ], mfe)==TRUE) {
      
      bktr_pk( h, s, new_pre_energy + 
	       Fm[ pf_index( i, h - 1, seqlength) ],
	       thepairs,  F, Fb, Fm, Fp, Fg, 
	       Fp_int_S, 
	       mfe, seqlength, seq);
      
      bktr_multi( i, h-1, new_pre_energy+Fp[ pf_index(h, s, seqlength) ],
		  thepairs, F, Fb, Fm, Fp, 
		  Fg, 
		  Fp_int_S, 
		  mfe, seqlength, seq);
      
      done = TRUE;
    }

  }
  
  return done;
}
/* *********************************************** */
void bktr_pk_int( int i, int j, double ref_energy, int thepairs[], 
		  double F[], double Fb[], double Fm[], double Fp[], 
		  double Fg[], 
		  double Fp_int_S[], 
		  int seqlength, char seq[]) {
  // Backtrack an interior region of a pseudoknot

  int h, m; //h paired with m, or h, s are ends of pseudoknot region
  double energy; //energy of the current structure
  double pre_energy;  //energy of everything minus the 'current' structure
  double bp_penalty;
  double dangle;

#ifdef PKNOTS
  int s;
#endif //PKNOTS

#ifdef DEBUG
  printf("bktr_pk_int! %d %d\n", i, j);
#endif
  
  if( Equal( DangleEnergy(i, j, seq, seqlength) + (j-i+1)*BETA_3, 
	     ref_energy) == TRUE
      
      ) {

    return;
  }
  else {

    for( h = i; h <= j - 4; h++) {
      for( m = h+4; m <= j; m++) {
 
	dangle = DangleEnergy( m+1, j, seq, seqlength);

	if( CanPair( seq[h], seq[m]) == TRUE && 
	    (Base2int( seq[h]) + Base2int( seq[m]) != 7) ) {
	  bp_penalty = 0.0;

	  if( seq[h] != 'C' && seq[m] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }

	  pre_energy = dangle + bp_penalty + BETA_2 + BETA_3*( j - m);
	
	    energy = pre_energy + Fp_int_S[ pf_index( i, h-1, seqlength)] +
	      Fb[ pf_index(h, m, seqlength) ];
		  
	  if( Equal( energy, ref_energy) == TRUE) {
	    if( thepairs[h] != -1 || thepairs[m] != -1 ) {
	      printf("Error in assigning pairs in backtrack!\n");
	      exit(0);
	    }
	    thepairs[h] = m;
	    thepairs[m] = h;

	
	      bktr_bp( h, m, 
		       pre_energy + Fp_int_S[ pf_index( i, h-1, seqlength)], 
		       thepairs,  F, Fb, Fm, Fp, 
		       Fg, Fp_int_S,  ref_energy, 
		       seqlength, seq);
	      
	      bktr_pk_int( i, h-1, Fp_int_S[ pf_index( i, h-1, seqlength)],
			   thepairs, 
			   F, Fb, Fm, Fp, 
			   Fg, 
			   Fp_int_S, 
			   seqlength, seq);
	     
	      return;
	
	  }       
	}
#ifdef PKNOTS
	// Check for pknot possibility (i.e. this is equivalent
	// to pknot_pk_int() )
	if( m >= h + 8) {
	  s = m;
	  bp_penalty = 0.0;

	  pre_energy = dangle + bp_penalty + 2*BETA_2 + 
	    (j - s)*BETA_3 + BETA_1P;

	    energy = pre_energy + Fp_int_S[ pf_index( i, h-1, seqlength)] +
	      Fp[ pf_index(h, s, seqlength) ];
	  
	  if( Equal( energy, ref_energy) == TRUE) {

	      bktr_pk( h, s, 
		       pre_energy + Fp_int_S[ pf_index( i, h-1, seqlength)], 
		       thepairs,  F, Fb, Fm, Fp, 
		       Fg, Fp_int_S, ref_energy, 
		       seqlength, seq);
	      
	      bktr_pk_int( i, h-1, Fp_int_S[ pf_index( i, h-1, seqlength)],
			   thepairs, 
			   F, Fb, Fm, Fp, 
			   Fg, 
			   Fp_int_S, 
			   seqlength, seq);
	     
	      return;

	  }
	}
#endif
      }      
    }
  }
  printf("Backtrack Error: mfe not found in Interior Region of PK!\n");
  exit(0);
}


/* ********************************************* */

void PrintStructure( char thefold[], int thepairs[], int seqlength) {
  /* This prints the structure of the fold using a '.' for 
     unpaired bases, and ( ) and { } for pairs. 

     Initially, thefold[i] = '.' for all i

     Needs to be upgraded.
  */
  
  int i;
  int helix_end = seqlength;
  char pair[] = { '(', ')', '{','}' };
  int type = 0;
  FILE *pairfile;
  FILE *pairfile2;
  extern char pairsFileName[];

  pairfile = fopen( pairsFileName, "a");
  pairfile2 = fopen( "out.pair", "w");

  for( i = 0; i < seqlength; i++) {
   
    if( thepairs[i] != -1 && thepairs[i] > i) {

      fprintf(pairfile, "%d %d %d\n", i+1, thepairs[i]+1, 1);
      printf("%d %d\n", i+1, thepairs[i] +1);

      if( thepairs[i] < helix_end) {
	thefold[i] = pair[ 2*type];
	thefold[ thepairs[i] ] = pair[ 2*type + 1];
      }
      else {
	type = 1 - type;
	thefold[i] = pair[ 2*type];
	thefold[ thepairs[i] ] = pair[ 2*type+1];
      }
      helix_end = thepairs[i];
      
    }
  }
  fprintf(pairfile, ".\n");
  fclose( pairfile);
  fclose( pairfile2);

  for( i = 0; i < seqlength; i++) {
    printf("%c", thefold[ i]);
  }
  printf("\n");
  
}




