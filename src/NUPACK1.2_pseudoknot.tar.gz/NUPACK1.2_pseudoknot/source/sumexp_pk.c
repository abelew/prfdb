/* sumexp_pk.c by Robert Dirks 09/04/2001

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     

This file contains the functions that calculate the sum of exponentials
in order to calculate a given partition function matrix.  This deals with
pseudoknot cases

See functions.h for more specific descriptions of each function.
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#ifndef CONSTANTS_H
#include"constants.h"
#endif

#ifndef FUNCTIONS_H
#include"functions.h"
#endif


#include "DNAExternals.h"
/* ************************************** */
#ifdef PKNOTS
double SumExpQb_Pk( int i, int j, char seq[], int seqlength, 
			double Qp[], double Qm[] ) {
  // Determine all possible, rightmost pseudoknots 
  // contained in i,j "loop" and calculate SumExp
  

  double bp_penalty = 0;
  double sum_exp = 0.0;
  int d, e; //the left and right ends of a pseudoknot
  int pf_de;

  if( Base2int( seq[i]) + Base2int( seq[j]) != 5) {
    return 0;
  }

  if( seq[i] != 'C'  && seq[j] != 'C') {
    bp_penalty = AT_PENALTY;
  }
  
  for( d = i+1; d <= j - 9; d++) {
    for( e = d + 8; e <= j - 1; e++) {
      pf_de = pf_index( d, e, seqlength);

      sum_exp += 
	exp( -( BETA_1M + ALPHA_1 + 3*ALPHA_2 + 
		(j-e-1 + d-i-1)*ALPHA_3 + bp_penalty)
	     /(R_GAS*TEMP_K) )*
	ExpDangle( i+1, d-1, seq, seqlength) *
	ExpDangle( e+1, j-1, seq, seqlength) *
	Qp[ pf_de];

      sum_exp += Qm[ pf_index( i+1, d-1, seqlength)] * 
	Qp[ pf_de] * 
	exp( -( BETA_1M + ALPHA_1 + 3*ALPHA_2 + bp_penalty + 
		(j - e - 1)*ALPHA_3) / (R_GAS*TEMP_K) ) *
	ExpDangle( e+1, j-1, seq, seqlength);

    }
  }

  return sum_exp;
}

/* *********************************************** */
#ifdef O_N8
void MakeQg_N8( int i, int j, char seq[], int seqlength, double Qg[],
	     double Qm[]) {
  //  Make the gap matrix for Qg
  int c,d,e,f;
  int gap_idej;
  double IJ_bp_penalty = 0.0;
  double bp_penalty = 0;

  if( CanPair( seq[i], seq[j]) == FALSE) {
    return;
  }

  IJ_bp_penalty = 0.0;
  if( seq[i] != 'C' && seq[j] != 'C') {
    IJ_bp_penalty = AT_PENALTY;
  }


  //Case 1:  Terminal Inner Pair
  for( d = i+1; d <= j-5; d++) {
    for( e = d+4; e <= j-1; e++) {      
      if( CanPair( seq[d], seq[e] ) == TRUE) {	
    
	Qg[ gap_index( i,d,e,j, seqlength)] += 
	  exp( -InteriorEnergy( i, j, d, e, seq)/(R_GAS*TEMP_K) ); 
      }
    }
  }
  

  //Case 2:  Simple Interior Loop
  for( d = i+2; d <= j-6; d++) {
    for( e = d+4; e <= j-2; e++) {      
      gap_idej = gap_index(i,d,e,j,seqlength);
      if( CanPair( seq[d], seq[e] ) == TRUE) { 
	
	for( c = i+1; c <= d-1; c++) {
	  for( f = e+1; f <= j-1; f++) {
	    if( CanPair( seq[c], seq[f]) == TRUE) {
	     
	      Qg[ gap_idej] += 
		exp( -InteriorEnergy( i, j, c, f, seq)/(R_GAS*TEMP_K)) * 
		Qg[ gap_index( c, d, e, f, seqlength)];
	      
	    }
	  }
	}
      }
    }
  }


  if( CanPair( seq[i], seq[j]) == TRUE && 
      Base2int( seq[i]) + Base2int( seq[j]) == 5) {
  
    //Case 3:  Multiloop Left
    for( d = i+6; d <= j-5; d++) {
      for( e = d+4; e <= j-1; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE &&
	    Base2int( seq[d]) + Base2int( seq[e]) == 5) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }
	  
	  Qg[ gap_idej] += 
	    Qm[ pf_index( i+1, d-1, seqlength)] *
	    exp( -(ALPHA_1 + 2*ALPHA_2 + 
		   (j-e-1)*ALPHA_3 + bp_penalty)/(R_GAS*TEMP_K)) *
	    ExpDangle( e+1, j-1, seq, seqlength);
	  
	}
      }
    }
    
    //Case 4:  Multiloop Right
    for( d = i+1; d <= j-10; d++) {
      for( e = d+4; e <= j-6; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE &&
	    Base2int( seq[d]) + Base2int( seq[e]) == 5) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }
	  
	  Qg[ gap_idej] += 
	    Qm[ pf_index( e+1, j-1, seqlength)] *
	    exp( -(ALPHA_1 + 2*ALPHA_2 + 
		   (d-i-1)*ALPHA_3 + bp_penalty)/(R_GAS*TEMP_K)) *
	    ExpDangle( i+1, d-1, seq, seqlength);
	  
	  
	}
      }
    }
    
    //Case 5: Multiloop Both Sides
    for( d = i+6; d <= j-10; d++) {
      for( e = d+4; e <= j-6; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE && 
	    Base2int( seq[d]) + Base2int( seq[e]) == 5) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }
	  
	  Qg[ gap_idej] += 
	    Qm[ pf_index( i+1, d-1, seqlength)] *
	    Qm[ pf_index( e+1, j-1, seqlength)] *
	    exp( -(ALPHA_1 + 2*ALPHA_2 + bp_penalty)/(R_GAS*TEMP_K));
	  
	}
      }
    }
    
    
    //Case 6: Multiloop Left + More Qg
    for( d = i+7; d <= j-6; d++) {
      for( e = d+4; e <= j-2; e++) {      
	gap_idej = gap_index(i,d,e,j,seqlength);
	if( CanPair( seq[d], seq[e] ) == TRUE) { 
	  
	  for( c = i+6; c <= d-1; c++) {
	    for( f = e+1; f <= j-1; f++) {
	      if( CanPair( seq[c], seq[f]) == TRUE &&
		  Base2int( seq[c]) + Base2int( seq[f]) == 5) {
		
		bp_penalty = IJ_bp_penalty;
		if( seq[c] != 'C' && seq[f] != 'C') {
		  bp_penalty += AT_PENALTY;
		}
		
		Qg[ gap_idej] += 
		  Qm[ pf_index( i+1, c-1, seqlength)]*
		  exp( -(ALPHA_1+2*ALPHA_2+(j-f-1)*ALPHA_3 + bp_penalty)
		       /(R_GAS*TEMP_K)) * 
		  Qg[ gap_index( c, d, e, f, seqlength)] *
		  ExpDangle( f+1, j-1, seq, seqlength);
	      }
	    }
	  }
	}
      }
    }
    
    //Case 7: Multiloop Right + More Qg
    for( d = i+2; d <= j-11; d++) {
      for( e = d+4; e <= j-7; e++) {      
	gap_idej = gap_index(i,d,e,j,seqlength);
	if( CanPair( seq[d], seq[e] ) == TRUE) { 
	  
	  for( c = i+1; c <= d-1; c++) {
	    for( f = e+1; f <= j-6; f++) {
	      if( CanPair( seq[c], seq[f]) == TRUE &&
		  Base2int( seq[c]) + Base2int( seq[f]) == 5) {
		
		bp_penalty = IJ_bp_penalty;
		if( seq[c] != 'C' && seq[f] != 'C') {
		  bp_penalty += AT_PENALTY;
		} 
		
		Qg[ gap_idej] += 
		  Qm[ pf_index( f+1, j-1, seqlength)]*
		  exp( -(ALPHA_1+2*ALPHA_2+(c-i-1)*ALPHA_3+bp_penalty)
		       /(R_GAS*TEMP_K)) * 
		  Qg[ gap_index( c, d, e, f, seqlength)] *
		  ExpDangle( i+1, c-1, seq, seqlength);
	      }
	    }
	  }
	}
      }
    }
    
    
    //Case 8: Multiloop Both sides + More Qg
    for( d = i+7; d <= j-11; d++) {
      for( e = d+4; e <= j-7; e++) {      
	gap_idej = gap_index(i,d,e,j,seqlength);
	if( CanPair( seq[d], seq[e] ) == TRUE) { 
	  
	  for( c = i+6; c <= d-1; c++) {
	    for( f = e+1; f <= j-6; f++) {
	      if( CanPair( seq[c], seq[f]) == TRUE &&
		  Base2int( seq[c]) + Base2int( seq[f]) == 5) {
		
		bp_penalty = IJ_bp_penalty;
		if( seq[c] != 'C' && seq[f] != 'C') {
		  bp_penalty += AT_PENALTY;
		}
		
		Qg[ gap_idej] += 
		  Qm[ pf_index( i+1, c-1, seqlength)]*
		  Qm[ pf_index( f+1, j-1, seqlength)]*
		  exp( -(ALPHA_1+2*ALPHA_2+bp_penalty)
		       /(R_GAS*TEMP_K)) * 
		  Qg[ gap_index( c, d, e, f, seqlength)];
	      }
	    }
	  }
	}
      }
    }   
  }

}
#endif //O_N8
/* ******************************************* */
#ifdef O_N5
void MakeQg_N5( int i, int j, char seq[], int seqlength, double Qg[],
		double Qm[], double Qgls[], double Qgrs[], double QgIx[],
		double QgIx_2[], short possiblePairs[]) {
  //  Make the gap matrix for Qg
  int c,d,e,f;
  int gap_idej;
  double IJ_bp_penalty = 0.0;
  double bp_penalty = 0;

  IJ_bp_penalty = 0.0;
  if( seq[i] != 'C' && seq[j] != 'C') {
    IJ_bp_penalty = AT_PENALTY;
  }


  if( CanPair( seq[i], seq[j]) == TRUE) {

    //Case 1:  Terminal Inner Pair
    for( d = i+1; d <= j-5; d++) {
      for( e = d+4; e <= j-1; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE) {
	  
	  Qg[ gap_index( i,d,e,j, seqlength)] += 
	    exp( -InteriorEnergy( i, j, d, e, seq)/(R_GAS*TEMP_K) ); 

	}
      }
    }
  }

  fastIloop_Qg(i, j, seq, seqlength, Qg, QgIx, QgIx_2, possiblePairs);

  if( CanPair( seq[i], seq[j]) == TRUE && 
      Base2int( seq[i]) + Base2int( seq[j]) == 5) {

    //Case 2:  Multiloop Left
    for( d = i+6; d <= j-5; d++) {
      for( e = d+4; e <= j-1; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE 
	    && Base2int( seq[d]) + Base2int( seq[e]) == 5) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }
	  
	  Qg[ gap_idej] += 
	    Qm[ pf_index( i+1, d-1, seqlength)] *
	    exp( -(ALPHA_1 + 2*ALPHA_2 + 
		   (j-e-1)*ALPHA_3 + bp_penalty)/(R_GAS*TEMP_K)) *
	    ExpDangle( e+1, j-1, seq, seqlength);
	  
	}
      }
    }

    //Case 3:  Multiloop Right
    for( d = i+1; d <= j-10; d++) {
      for( e = d+4; e <= j-6; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE
	    && Base2int( seq[d]) + Base2int( seq[e]) == 5 
	    ) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }
	  
	  Qg[ gap_idej] += 
	    Qm[ pf_index( e+1, j-1, seqlength)] *
	    exp( -(ALPHA_1 + 2*ALPHA_2 + 
		   (d-i-1)*ALPHA_3 + bp_penalty)/(R_GAS*TEMP_K)) *
	    ExpDangle( i+1, d-1, seq, seqlength) ;
	  
	}
      }
    }
     
    //Case 4: Multiloop Both Sides
    for( d = i+6; d <= j-10; d++) {
      for( e = d+4; e <= j-6; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE
	    && Base2int( seq[d]) + Base2int( seq[e]) == 5
	    ) {
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  
	  bp_penalty = IJ_bp_penalty;
	  if( seq[d] != 'C' && seq[e] != 'C') {
	    bp_penalty += AT_PENALTY;
	  }	
	  
	  Qg[ gap_idej] += 
	    Qm[ pf_index( i+1, d-1, seqlength)] *
	    Qm[ pf_index( e+1, j-1, seqlength)] *
	    exp( -(ALPHA_1 + 2*ALPHA_2 + bp_penalty)/(R_GAS*TEMP_K));
	  
	}
      }
    }

    //Case 5: Interior loop + multi left
    for( d = i+7; d <= j-6; d++) {
      for( e = d+4; e <= j-2; e++) {      
	gap_idej = gap_index(i,d,e,j,seqlength);
	if( CanPair( seq[d], seq[e] ) == TRUE) {
	 
	  for( f = e+1; f <= j-1; f++) {
	    bp_penalty = IJ_bp_penalty;
	    
	    Qg[ gap_idej] += 
	      exp( -(ALPHA_1+ALPHA_2 + (j-f-1)*ALPHA_3+ bp_penalty)/
		   (R_GAS*TEMP_K)) * 
	      Qgls[ gap_index( i+1, d, e, f, seqlength)] *
	      ExpDangle( f+1, j-1, seq, seqlength);
	  }	
	}
      }
    }

    //Case6: Interior loop + multi right
    for( d = i+2; d <= j-11; d++) {
      for( e = d+4; e <= j-7; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE) {
       
	  gap_idej = gap_index(i,d,e,j,seqlength);
	  for( c = i+1; c <= d-1; c++) {
	    bp_penalty = IJ_bp_penalty;
	    
	    Qg[ gap_idej] += 
	      exp( -(ALPHA_1+ALPHA_2 + (c-i-1)*ALPHA_3 + 
		     bp_penalty)/(R_GAS*TEMP_K)) * 
	      Qgrs[ gap_index( c, d, e, j-1, seqlength)] *
	      ExpDangle( i+1, c-1, seq, seqlength);
	  }	
	}
      }
    }
   
    //Case 7: Interior loop + multi both sides
    for( d = i+7; d <= j-11; d++) {
      for( e = d+4; e <= j-7; e++) {      
	if( CanPair( seq[d], seq[e] ) == TRUE) {

	  gap_idej = gap_index(i,d,e,j,seqlength);
	  for( c = i+6; c <= d-1; c++) {	
	    bp_penalty = IJ_bp_penalty;
	    
	    Qg[ gap_idej] += 
	      Qm[ pf_index( i+1, c-1, seqlength)] *
	      exp( -(ALPHA_1+ALPHA_2+bp_penalty)/(R_GAS*TEMP_K)) * 
	      Qgrs[ gap_index( c, d, e, j-1, seqlength)];
	  }	
	}
      }
    }
  } // Can Pair


}
/* ************************************** */
void fastIloop_Qg(int i, int j, char seq[], int seqlength, 
		  double Qg[], double QgIx[], double QgIx_2[],
		  short possiblePairs[]) {
  
  int d, e, size;
  int L = j - i + 1;
  int pf_ij = pf_index(i, j, seqlength);
  int index;
  double expInteriorMM;
  int gap_idej;

  if( CanPair( seq[i], seq[j]) == TRUE) {
    expInteriorMM = exp( -InteriorMM( seq[i], seq[j], seq[i+1], 
				      seq[j-1])/(R_GAS*TEMP_K));
  }

  //QgIx recurions
  //Explicitly add in base cases to QgIx (smallest extensible loops) 
  
  if( L >= 17 && possiblePairs[pf_ij] == TRUE) {
    makeNewQgIx( i, j, seq, seqlength, Qg, QgIx);
  }
  

  for( d = i+1; d <= j-5; d++) {
    for( e = d+4; e <= j-1; e++) {
      if(  CanPair( seq[d], seq[e]) == TRUE) {
		
	gap_idej = gap_index( i,d,e,j, seqlength);
	
	if( L>=17 &&  CanPair( seq[i], seq[j]) == TRUE) { 
		  
	  index = QgIxIndex( j-i, i, 8, d, e, seqlength);
	  
	  for( size = 8; size <= L - 9; size++) {
	    Qg[ gap_idej] += QgIx[ index] * 
	      expInteriorMM;
	    index = index + (L-2)*(L-3)/2;
	  }
	  
	}
	
	if( i != 0 && j != seqlength - 1) {
	   extendOldQgIx( i, j, d, e, seq, seqlength, 
			  Qg, QgIx, QgIx_2);
	}
	

	Qg[ gap_idej] += SumExpInextensibleIL_Qg( i, j, d, e, seq, seqlength,
						  Qg);
      }
    }
  }
}


  

/* ************************************ */
void MakeQgls( int i, int j, char seq[], int seqlength, double Qg[], 
	       double Qm[],  double Qgls[]) {
  int c, d, e;
  int pf_ic1;
  double bp_penalty = 0;

  for( c = i + 5; c <= j-6; c++) {
    if( CanPair( seq[c], seq[j]) == TRUE 
	 && Base2int( seq[c]) + Base2int( seq[j]) == 5 
	) {

      bp_penalty = 0.0;
      if( seq[c] != 'C' && seq[j] != 'C') {
	bp_penalty = AT_PENALTY;
      }

      pf_ic1 = pf_index( i, c-1, seqlength);
      for( d = c+1; d <= j-5; d++) {
	
	for( e = d+4; e <= j-1; e++) {
	  if( CanPair( seq[d], seq[e]) == TRUE) { 
	  
	    // The d-e bp_penalty already counted in MakeQgl
       
	    Qgls[ gap_index(i, d, e, j, seqlength)] +=
	      Qm[ pf_ic1] *
	      Qg[ gap_index(c, d, e, j, seqlength)] *
	      exp( -(ALPHA_2 + bp_penalty)/(R_GAS*TEMP_K) );
	  }
	}
      }
    }
  }
}
/* ************************** */
void MakeQgrs( int i, int j, char seq[], int seqlength, double Qg[], 
	       double Qm[], double Qgrs[]) {

  int d, e, f;
  int gap_idej;
  double bp_penalty = 0;
   
  for( d = i + 1; d <= j-10; d++) {
    for( e = d+4; e <= j-6; e++) {
      if( CanPair( seq[d], seq[e]) == TRUE) { 

	gap_idej = gap_index(i,d,e,j,seqlength);
	for( f = e+1; f <= j-5; f++) {
	  if( CanPair( seq[i], seq[f]) == TRUE &&
	      Base2int( seq[i]) + Base2int( seq[f]) == 5 
	      ) {
	
	    bp_penalty = 0;
	    if( seq[i] != 'C' && seq[f] != 'C') {
	      bp_penalty = AT_PENALTY;
	    }

	    Qgrs[ gap_idej] +=
	      Qm[ pf_index( f+1, j, seqlength)] * 
	      Qg[ gap_index( i, d, e, f, seqlength)] *
	      exp( -(ALPHA_2 + bp_penalty)/(R_GAS*TEMP_K) );
	  }
	}
      }
    }
  }
}
/* *************************************** */

void MakeQgl( int i, int j, char seq[], int seqlength, 
	      double Qg[], double Qgl[], double Qz[]) {
  //make sure to call this AFTER MakeQg and BEFORE MakeQgr
  
  int d, e, f;
  int gap_idfj;
  double bp_penalty = 0.0;
  
  for( d = i+1; d <= j-5; d++) {
    for( f = d+4; f <= j-1; f++) {
      if( CanPair( seq[d], seq[f]) == TRUE &&
	  Base2int( seq[d]) + Base2int( seq[f]) == 5
	  ) {
	bp_penalty = 0.0;
	if( seq[d] != 'C' && seq[f] != 'C') {
	  bp_penalty = AT_PENALTY;
	}
	
	gap_idfj =  gap_index(i, d, f, j, seqlength);
	for( e = d; e <= f-3; e++) {
	  
	  Qgl[ gap_index( i, e, f, j, seqlength) ] +=
	    Qg[ gap_idfj]*Qz[ pf_index( d+1, e, seqlength)] *
	    exp( -(BETA_2 + bp_penalty)/(R_GAS*TEMP_K) );

	}
      }
    }
  }
}

/* ******************************** */

void MakeQgr( int i, int j, char seq[], int seqlength, 
	      double Qgr[], double Qgl[], double Qz[]) {
  
  //make sure to call this AFTER MakeQg and AFTER MakeQgl
  
  int d, e, f;
  int gap_idej;
  

  for( d = i+1; d <= j-4; d++) {
    for( e = d+3; e <= j-1; e++) {
      gap_idej =  gap_index(i, d, e, j, seqlength);
      for( f = e; f <= j-1; f++) {
	Qgr[ gap_idej ] +=
	  Qgl[ gap_index(i,d,f,j,seqlength)]*
	  Qz[ pf_index( e, f-1, seqlength)];
	  
      }
    }
  }  
}
/* ********************************** */
double SumExpQp_N5( int i, int j, char seq[], int seqlength, 
		    double Qgl[], double Qgr[]) {
  
  int d, e, f;
  double bp_penalty, new_bp_penalty;
  double sumexp = 0.0;

  if( j - i < 8) {// not enough room for pk
    return 0.0;
  }
  for( d = i + 2; d <= j-4; d++) {
    if( CanPair( seq[d], seq[j]) == TRUE &&
	Base2int( seq[d]) + Base2int( seq[j]) == 5
	) {
      bp_penalty = 0;
      if( seq[d] != 'C' && seq[j] != 'C') {
	bp_penalty = AT_PENALTY;
      }

      for( e = MAX(d+2, i+5); e <= j-3; e++) {
	for( f = e+1; f <= j-2; f++) {
	  
	  if( CanPair( seq[i], seq[f]) == TRUE &&
	      Base2int( seq[i]) + Base2int( seq[f]) == 5
	      ) {
	    new_bp_penalty = bp_penalty;
	    if( seq[i] != 'C' && seq[f] != 'C') {
	      new_bp_penalty += AT_PENALTY;
	    }
	  
	    sumexp += Qgl[ gap_index(i, d-1, e, f, seqlength)] *
	      Qgr[ gap_index(d, e-1, f+1, j, seqlength)] *
	      exp( -(new_bp_penalty)/(R_GAS*TEMP_K) );

	  }
	}
      }
    }
  }
 
  return sumexp;
}


#endif //O_N5


/* *************************************** */
#ifdef O_N8
double SumExpQp_N8( int i, int j, char seq[], int seqlength, 
		 double Qg[], double Qz[]) {
  // Add all pseudoknots with ends i, j.
  // No penalty for non-AT, terminal basepairs need to be added for the
  // h and s pairs because they are included elsewhere.  However,
  // non-AT penalty is calculated here for the two "interior" pairs,
  // i.e. i5-i3 and k5-k3
  // Dangles calculated in Qp_int_* matrixes

  int a, d, c, f, e, b; // 4 pairs: i-e, a-d, b-j, c-f
  double bp_penalty = 0.0;
  double sum_exp = 0.0;

  if( j - i < 8) {// not enough room for pk
    return 0.0;
  }
  for( a = i + 1; a <= j - 7; a++) {
    for( b = a+1; b <= j - 6; b++) {
      if( CanPair( seq[ b], seq[ j]) == TRUE	  
	  && Base2int( seq[b]) + Base2int( seq[j]) == 5) {
	for( c = b + 1; c <= j - 5; c++) {
	  for( d = MAX(c+1,a+4); d <= j - 3; d++) {
	    if( CanPair( seq[ a], seq[ d]) == TRUE
		&& Base2int( seq[a]) + Base2int( seq[d]) == 5) {
	      for( e = d+1; e <= j - 2; e++) {
		if( CanPair( seq[ i], seq[ e]) == TRUE
		    && Base2int( seq[i]) + Base2int( seq[e]) == 5) {
		  for( f = MAX(e+1,c+4); f <= j-1; f++) {
		    if( CanPair( seq[c], seq[f]) == TRUE
			&& Base2int( seq[c]) + Base2int( seq[f]) == 5) {
		      
		      bp_penalty = 0.0;
		      if( seq[a] != 'C' && seq[d] != 'C') {
			bp_penalty += AT_PENALTY;
		      }
		      if( seq[c] != 'C' && seq[f] != 'C') {
			bp_penalty += AT_PENALTY;
		      }
		      if( seq[i] != 'C' && seq[e] != 'C') {
			bp_penalty += AT_PENALTY;
		      }
		      if( seq[b] != 'C' && seq[j] != 'C') {
			bp_penalty += AT_PENALTY;
		      }

		      sum_exp += 
			Qg[ gap_index( i, a, d, e, seqlength) ] *
			Qg[ gap_index( b, c, f, j, seqlength) ] *
			exp( -(bp_penalty + 2*BETA_2)/
			     (R_GAS*TEMP_K) ) * 
			Qz[ pf_index( e + 1, f - 1, seqlength)]*
			Qz[ pf_index( c + 1, d - 1, seqlength)]*
			Qz[ pf_index( a + 1, b - 1, seqlength)];
		      
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
    }
  }

  return sum_exp;
}
#endif //O_N8

/* *************************************** */

void MakeQ_Qm_Qz( int i, int j, char seq[], int seqlength,
		  double Q[], double Qm[], double Qz[],
		  double Qb[], double Qp[]) {
  
  int d, e; // d - e is internal basepair or pk boundary
  double bp_penalty;
  int pf_ij = pf_index(i, j, seqlength);
  int pf_de;

  Q[ pf_ij] = ExpDangle(i, j, seq, seqlength);  //Empty Graph

  
  if( i != 0 && j != seqlength - 1) { 
    Qz[ pf_ij] = ExpDangle(i, j, seq, seqlength)*
      exp( -BETA_3*(j-i+1)/(R_GAS*TEMP_K) );
  }  

  for( d = i; d <= j - 4; d++) {
    for( e = d + 4; e <= j; e++) {
      if( CanPair( seq[d], seq[e]) == TRUE &&
	  Base2int( seq[d]) + Base2int( seq[e]) == 5 ) {
	bp_penalty = 0;
	if( seq[d] != 'C' && seq[e] != 'C') {
	  bp_penalty = AT_PENALTY;
	}

	pf_de = pf_index( d, e, seqlength);

	Q[ pf_ij] += Q[ pf_index(i, d-1, seqlength)] *
	  Qb[ pf_de ] *
	  exp( -bp_penalty/(R_GAS*TEMP_K) ) *
	  ExpDangle( e+1, j, seq, seqlength); 

	if( i != 0 && j != seqlength - 1) {
	  
	  Qm[ pf_ij] +=
	    exp( -(ALPHA_2 + ALPHA_3*(d-i + j-e) + bp_penalty)/
		 (R_GAS*TEMP_K) )*
	    Qb[ pf_de] *
	    ExpDangle( e+1, j, seq, seqlength) *
	    ExpDangle( i, d-1, seq, seqlength);
	  
	  
	  if( d >= i+5) {
	    Qm[ pf_ij] += Qm[ pf_index(i, d-1, seqlength)] *
	      Qb[ pf_de] *
	      exp( -(ALPHA_2 + ALPHA_3*(j-e) + bp_penalty)/
		   (R_GAS*TEMP_K) )*
	      ExpDangle( e+1, j, seq, seqlength);
	  }
	  
	  
	  Qz[ pf_ij] += Qz[ pf_index(i, d-1, seqlength)]*
	    Qb[ pf_de] * exp( -(BETA_2 + BETA_3*(j-e) + bp_penalty)/
			      (R_GAS*TEMP_K) )*
	    ExpDangle( e+1, j, seq, seqlength);
	}
	
      }
      
    }
  }

  for( d = i; d <= j - 8; d++) {
    for( e = d + 8; e <= j; e++) {
      
      pf_de = pf_index( d, e, seqlength);

      Q[ pf_ij] += Q[ pf_index(i, d-1, seqlength)] *
	Qp[ pf_de ] *
	exp( -BETA_1/(R_GAS*TEMP_K) ) *
	ExpDangle( e+1, j, seq, seqlength); 

      if( i != 0 && j != seqlength - 1) {
      
	Qm[ pf_ij] +=
	  exp( -(BETA_1M + 2*ALPHA_2 + ALPHA_3*(d-i + j-e))/
	       (R_GAS*TEMP_K) )*
	  Qp[ pf_de] *
	  ExpDangle( e+1, j, seq, seqlength) *
	  ExpDangle( i, d-1, seq, seqlength);
	
	
	if( d >= i+5) {
	  Qm[ pf_ij] += Qm[ pf_index(i, d-1, seqlength)] *
	    Qp[ pf_de] *
	    exp( -(BETA_1M + 2*ALPHA_2 + ALPHA_3*(j-e))/
		 (R_GAS*TEMP_K) )*
	    ExpDangle( e+1, j, seq, seqlength);
	}
      
	Qz[ pf_ij] += Qz[ pf_index(i, d-1, seqlength)]*
	  Qp[ pf_de] * exp( -(BETA_1P + 2*BETA_2 + BETA_3*(j-e) )/
			    (R_GAS*TEMP_K) )*
	  ExpDangle( e+1, j, seq, seqlength);	
      }
    }    
  }
}


/* ************************************************************ */

#ifdef O_N5
double SumExpInextensibleIL_Qg( int i, int j, int d, int e, 
				char seq[], int seqlength, 
				double Qg[]) {
  /* This finds the minimum energy IL that has a special energy 
     calculation, i.e. small loops, bulge loops or GAIL case */
  
  /* This finds the minimum energy IL that has a special energy 
     calculation, i.e. small loops, bulge loops or GAIL case */
  
  double energy;
  int c, f; //Internal pair.(c, f will be restricted to special cases)
  
  int L1, L2; //size parameters: L1 + L2 = size, L1 = c-i-1, L2 = j-f-1
 
  double sumexp = 0;

  if( CanPair( seq[i], seq[j]) == FALSE) { 
    return 0;
  }

  /* First consider small loops */
  // L1 <= 3, L2 <= 3
  for( L1 = 0; L1 <= MIN(3, d-i-2); L1++) {
    c = i + L1 + 1;
    for( L2 = 0; L2 <= MIN( 3, j-e-2); L2++) {      
      f = j - L2 - 1;
      if( CanPair( seq[c], seq[f]) == TRUE) {

	energy = InteriorEnergy( i, j, c, f, seq);

	sumexp += exp( -energy/(R_GAS*TEMP_K)) *
	  Qg[ gap_index( c, d, e, f, seqlength)];
      }
    }
  }

  /* Next consider large bulges or large asymmetric loops */
  // Case 2a  L1 = 0,1,2,3, L2 >= 4;
  for( L1 = 0; L1 <= MIN(3, d-i-2); L1++) {
    c = i + L1 + 1;
    for( L2 = 4; L2 <= j - e - 2; L2++) {
      f = j - L2 - 1;
      if( CanPair( seq[c], seq[f]) == TRUE) { //c < d && f > e
	energy = InteriorEnergy( i, j, c, f, seq);	
	sumexp += exp( -energy/(R_GAS*TEMP_K)) *
	  Qg[ gap_index( c, d, e, f, seqlength)]; 
      }
    }
  }

  // Case 2b L1 >= 4, L2 = 0,1,2,3;
  for( L2 = 0; L2 <= MIN(3,j-e-2) ; L2++) {
    f = j - L2 - 1;
    for( L1 = 4; L1 <= d-i-2; L1++) {
      c = i + L1 + 1;
      if( CanPair( seq[c], seq[f]) == TRUE) { //c < d && f > e
	
	energy = InteriorEnergy( i, j, c, f, seq);
	sumexp += exp( -energy/(R_GAS*TEMP_K)) *
	  Qg[ gap_index( c, d, e, f, seqlength)];
     
      }
    }
  }    

  return sumexp;

}  
/* *********************************************** */
 

void makeNewQgIx( int i, int j, char seq[], int seqlength, 
  double Qg[], double QgIx[]) {

 /*Determine the new entries of QgIx(i,j,d,e,size) that are not extended 
    versions of QgIx(i+1, j-1, h1, e, size-2) */
  
  extern double loop37[];
  extern double asymmetry_penalty[];
  extern double max_asymmetry;

  double energy;
  int c, f; //Internal pair.(c, f will be restricted to special cases)
  int d,e;// Internal pair of gap matrix (no restrictions);

  int size, L1, L2; //size parameters: L1 + L2 = size, L1 = c-i-1, L2 = j-f-1
  int asymmetry;
  int asymmetry_index;
  int partial_index; //used to limit calls to QgIxIndex
  int len1_len2 = (j-i-1)*(j-i-2)/2;

  //Add in all the cases that are not an extended version of an
  //extensible case.

  
  for( d = i + 6; d <= j - 10; d++) {
    for( e = d + 4; e <= j-6; e++) {
      if( CanPair( seq[d], seq[e]) == TRUE) {
	partial_index = QgIxIndex( j-i, i, 0, d, e, seqlength);

	//Case 1:  L1 = 4, L2 >= 4;
	L1 = 4;
	c= i + L1 + 1;
	for( L2 = 4; L2 <= j - e - 2; L2++) {
	  f = j - L2 - 1;
	  size = L1 + L2;
	  
	  if( CanPair( seq[c], seq[f]) == TRUE)  {
	    asymmetry = abs( L1 - L2);
	    //Loop Size Energy
	    if( size <= 30) {
	      energy = loop37[ size - 1];
	    }
	    else {
	      energy = loop37[ 30 - 1];
	      energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
	    }
	    
	    //Asymmetry rountine copied from efn.f in Zuker's mfold package.
	    asymmetry_index = 4;
	    
	    if( asymmetry*asymmetry_penalty[ asymmetry_index - 1] < max_asymmetry ) {
	      energy += asymmetry*asymmetry_penalty[ asymmetry_index - 1];
	    }
	    else {
	      energy += max_asymmetry; // MAX asymmetry penalty
	    }
	    
	    energy += InteriorMM( seq[f], seq[c], seq[f+1], seq[c-1]);
	    /*Exclude the i-j stacking energy here, just in case i-j 
	      don't pair */
	    
	    QgIx[ partial_index+size*len1_len2 ] += 
	      exp(-energy/(R_GAS*TEMP_K))*
	      Qg[ gap_index( c, d, e, f, seqlength)];
	  }
	}    
	  
	//Case 2  L1 > 4, L2 = 4
	if( d >= i+7) {
	  L2 = 4;
	  f = j-L2-1;
	  for( L1 = 5; L1 <= d-i-2; L1++) {
	    c = i + L1 + 1;
	    size = L1 + L2;
	    
	    if( CanPair( seq[c], seq[f]) == TRUE)  {
	      asymmetry = abs( L1 - L2);
	      //Loop Size Energy
	      if( size <= 30) {
		energy = loop37[ size - 1];
	      }
	      else {
		energy = loop37[ 30 - 1];
		energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
	      }
	      
	      
	      //Asymmetry rountine copied from efn.f in Zuker's mfold package.
	      asymmetry_index = 4;
	      
	      if( asymmetry*asymmetry_penalty[ asymmetry_index - 1] < max_asymmetry ) {
		energy += asymmetry*asymmetry_penalty[ asymmetry_index - 1];
	      }
	      else {
		energy += max_asymmetry; // MAX asymmetry penalty
	      }
	      energy += InteriorMM( seq[f], seq[c], seq[f+1], seq[c-1]);
	      /*Exclude the i-j stacking energy here, just in case i-j 
	      don't pair */
	    
	    
	      QgIx[ partial_index + size*len1_len2] +=
		exp(-energy/(R_GAS*TEMP_K))*
		Qg[ gap_index( c, d,e,f, seqlength)];
	    
	    }
	  }
	}
      } 
    }
  }
 
}


/* ************ for FASTILOOP ************** */

void extendOldQgIx( int i, int j, int d, int e, char seq[], int seqlength, 
		    double Qg[], double QgIx[], double QgIx_2[]) {
  /* Extends all entries of QgIx */

  int L = j - i + 1;
  int size;
  extern double *sizeTerm; //precomputed
  
  //These following variables are to minimze calls to QgIxIndex;
  int partial_index, partial_index2;  
  int len_12 = (L-2)*(L-3)/2;
  int len10 = L*(L-1)/2;

  partial_index2 = QgIxIndex( j-i+2, i-1, 0, d, e, seqlength);
  partial_index = QgIxIndex( j-i, i, 0, d, e, seqlength);
  
  for( size = 8; size <= L - 9; size++) {
    QgIx_2[ partial_index2 + (size+2)*len10] = 
      QgIx[ partial_index + size*len_12]
      * sizeTerm[ size];    
  }
}
#endif //O_N5

/* ************************************ */
#endif //PKNOTS




