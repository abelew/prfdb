/* constants.h by Robert Dirks 07/24/2001

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     

Constants for PFunc.c
*/

#define CONSTANTS_H

//choose either DNA or RNA (not both)
//#define DNA
#define RNA

/* 
Default is for standard Zuker treatment of dangles.  
Uncommenting the next line will result in using the vienna package -D2 option.
This will approximate coaxially stacking but can introduce spurious basepairs
*/
//#define VIENNA_D2

/* Choose one of the following 4 options.  O_N3 and O_N4 do not consider 
   pseudoknots.  O_N3 is faster, but uses more Memory.
   Similarly, O_N5 and O_N8 are for pseudoknots, with O_N5 being faster, 
   but more memory intensive
*/

//#define O_N3
//#define O_N4
#define O_N5 //PKNOTS
//#define O_N8 //PKNOTS

/* 
Uncomment PAIRPR in if you want to calculate pairs probabilities, output is
as a symmetric, square matrix (one entry per line) in a file
called Pb_N5.txt (or Pb_N3, Pb_N4, Pb_N8).  See README for more details.
Using this option will approximately double the time of each calculation.
*/
//#define PAIRPR

//--------------------------------------
//No need to change anything below this

#if defined (O_N5) || defined (O_N8)
#define PKNOTS
#endif

//#define PRINTRESULTSONLY
//#define NODANGLES
//#define NOGU
//#define DEBUG

#define MAXSEQLENGTH 100000
#define MAXLINE 100000

//This version does not support changing the Temperature
#define R_GAS .00198717 // kcal/(mol K)
#define TEMP_K 310.15 // K
#define TRUE 1
#define FALSE 0
#define NAD_INFINITY 100000

#define BASE_A 1  //do not change!
#define BASE_C 2  // Watson crick bp add to 5
#define BASE_G 3  // Wobble bp add to 7
#define BASE_T 4









