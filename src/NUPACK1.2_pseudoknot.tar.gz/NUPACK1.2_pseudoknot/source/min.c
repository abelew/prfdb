/* min.c by Robert Dirks 08/06/2001

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     

This collection of functions for fold.c calculate the energy of the minimum
fold on a subsequence of a DNA sequence, given various restraints.  
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#ifndef CONSTANTS_H
#include"constants.h"
#endif

#ifndef FUNCTIONS_H
#include"functions.h"
#endif

#include "DNAExternals.h"
/* ***************************** */ 

#if defined (O_N4) || defined (PKNOTS)

double MinFb( int i, int j, char seq[], int seqlength, 
		 double Fm[], double Fb[] ){
// This finds all possible internal loops (no pseudoknots)
// closed on the "outside" by bases i and j, as well as all 
// multiloops


  double min_energy = NAD_INFINITY;
  double tempMin;
  int d, e; // d - e is internal basepair 
  double bp_penalty = 0;


  for( d = i+1; d <= j - 5; d++) {
    for( e = d + 4; e <= j - 1; e++) {
      if( CanPair( seq[d], seq[e]) == TRUE) {
	bp_penalty = 0.0;

			
	tempMin = InteriorEnergy( i, j, d, e, seq) +
	  Fb[ pf_index( d, e, seqlength) ];
	min_energy = MIN( tempMin, min_energy);

	if( seq[d] != 'C' && seq[e] != 'C') {
	  bp_penalty = AT_PENALTY;
	}
	if( seq[i] != 'C' && seq[j] != 'C') {
	  bp_penalty += AT_PENALTY;
	}
	
	if( d>= i+6 && Base2int( seq[d]) + Base2int( seq[e]) == 5 &&
	    Base2int( seq[i]) + Base2int( seq[j]) == 5) {
	  tempMin = Fm[ pf_index(i+1, d-1, seqlength)] +
	    Fb[ pf_index( d, e, seqlength)] +
	    (ALPHA_1 + 2*ALPHA_2 + ALPHA_3*(j-e-1) + bp_penalty) +
	    DangleEnergy( e+1, j-1, seq, seqlength);
	  min_energy = MIN( tempMin, min_energy);

	}
      }
    }
    
  }

  return min_energy;
}
#endif

/* ******************************* */

#ifdef O_N3
double MinMultiBp_N3( int i, int j, char seq[], 
		      double Fms[], double Fm[], int seqlength){
// Decomposes the region inside pair i,j into multiloops, i.e.
// and excludes the possibility of "top level" pseudoknots

  double min_energy = NAD_INFINITY;
  double tempMin;
  double bp_penalty = 0.0;
  int d; // d is the left base of a rightmost paired base between i, j.
  
  if( Base2int( seq[i]) + Base2int( seq[j]) == 5) {
    for( d = i+6; d <= j - 5; d++) {
      //reset loop parameters
      bp_penalty = 0.0;
      
      if( seq[i] != 'C'  && seq[j] != 'C') {
	bp_penalty += AT_PENALTY;
      }
      
      tempMin = Fm[ pf_index( i+1, d-1, seqlength)] +
	Fms[ pf_index(d, j-1, seqlength)] +
	( ALPHA_1 + ALPHA_2 + bp_penalty);

      min_energy = MIN( tempMin, min_energy);
    }
  }

  return min_energy;  
}

/* ***************************************** */
void fastILoops_Fb( int i, int j, int L, int seqlength, char seq[], 
		    double min_energy, 
		    double Fb[], double Fx[], double Fx_2[]) {
  
  int size;
  int pf_ij = pf_index( i, j, seqlength);
  double tempMin;

  if( L >= 15) {
    makeNewFx( i, j, seq, seqlength, Fb, Fx);
  }
  
  //Use extensible cases              
  if( CanPair( seq[ i], seq[j]) == TRUE) {
    for( size = 8; size <= L - 7; size++) {
      tempMin = 
	Fx[ fbixIndex( j-i, i, size, seqlength)] + 
	InteriorMM( seq[i], seq[j], seq[i+1], 
		    seq[j-1]);
      Fb[ pf_ij] = MIN( tempMin, Fb[ pf_ij]);
    }
  }
  
  if( L >= 15 && i != 0 && j != seqlength -1) {
    extendOldFx( i, j, seq, seqlength, Fb, Fx,
		 Fx_2);
  }
  
  /* Add in inextensible cases */  
  if( CanPair( seq[ i], seq[j]) == TRUE) {
    //first check inextensible cases
    tempMin = 
      MinInextensibleIL( i,j, seq, seqlength, Fb);    
    Fb[ pf_ij] = MIN( tempMin, Fb[ pf_ij]);
  } 
}

/* ******************************************* */
void makeNewFx( int i, int j, char seq[], int seqlength, 
		    double Fb[], double Fx[]) {

  /*Determine the new entries of Fx(i,j,size) that are not extended 
    versions of Fx(i+1, j-1, size-2) */
  
  extern double loop37[];
  extern double asymmetry_penalty[];
  extern double max_asymmetry;

  double energy;
  double tempMin;
  int d, e; //Internal pair.(d, e will be restricted to special cases)
  int index;

  int size, L1, L2; //size parameters: L1 + L2 = size, L1 = h-i-1, L2 = j-m-1
  int asymmetry;
  int asymmetry_index;

  //Add in all the cases that are not an extended version of an
  //extensible case.

  //Case 1:  L1 = 4, L2 >= 4;
  L1 = 4;
  d = i + L1 + 1;
  for( L2 = 4; L2 <= j - d - 5; L2++) {
    size = L1 + L2;
    e = j - L2 - 1;
    
    if( CanPair( seq[d], seq[e]) == TRUE) {
      asymmetry = abs( L1 - L2);
      //Loop Size Energy
      if( size <= 30) {
	energy = loop37[ size - 1];
      }
      else {
	energy = loop37[ 30 - 1];
	energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
      }
      
      //Asymmetry rountine copied from efn.f in Zuker's mfold package.
      asymmetry_index = 4;
      
      if( asymmetry*asymmetry_penalty[ asymmetry_index - 1] < max_asymmetry ) {
	energy += asymmetry*asymmetry_penalty[ asymmetry_index - 1];
      }
      else {
	energy += max_asymmetry; // MAX asymmetry penalty
      }
      
      energy += InteriorMM( seq[e], seq[d], seq[e+1], seq[d-1]);
      /*Exclude the i-j stacking energy here, just in case i-j 
	don't pair */
  
      tempMin = energy + Fb[ pf_index(d, e, seqlength)];
      index = fbixIndex( j-i, i, size, seqlength);
      Fx[ index] = MIN( tempMin, Fx[ index]); 
    }
  }
	
  //Case 2  L1 > 4, L2 = 4
  L2 = 4;
  e = j - L2 -1;
  for( L1 = 5; L1 <= e-i-5; L1++) {   
    size = L1 + L2;
    d = i + L1 + 1;
    
    if( CanPair( seq[d], seq[e]) == TRUE) {
      asymmetry = abs( L1 - L2);
      //Loop Size Energy
      if( size <= 30) {
	energy = loop37[ size - 1];
      }
      else {
	energy = loop37[ 30 - 1];
	energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
      }
      
      
      //Asymmetry rountine copied from efn.f in Zuker's mfold package.
      asymmetry_index = 4;
      
      if( asymmetry*asymmetry_penalty[ asymmetry_index - 1] < max_asymmetry ) {
	energy += asymmetry*asymmetry_penalty[ asymmetry_index - 1];
      }
      else {
	energy += max_asymmetry; // MAX asymmetry penalty
      }
      energy += InteriorMM( seq[e], seq[d], seq[e+1], seq[d-1]);
      /*Exclude the i-j stacking energy here, just in case i-j 
	don't pair */
      
      tempMin = energy + Fb[ pf_index(d, e, seqlength)];
      index = fbixIndex( j-i, i, size, seqlength);
      Fx[ index] = MIN( tempMin, Fx[ index]);
    }
  }
    
}

/* ************************** */

void extendOldFx( int i, int j, char seq[], int seqlength, 
		  double Fb[], double Fx[], double Fx_2[]) {
  /* Extends all entries of Qx */

  extern double loop37[];
  int size;
  double oldSizeEnergy;
  double newSizeEnergy;

  for( size = 8; size <= (j - i + 1) - 7; size++) {
    if( size <= 30) {
      oldSizeEnergy = loop37[ size - 1];
    }
    else {
      oldSizeEnergy = loop37[ 30 - 1];
      oldSizeEnergy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
    }
    if( size + 2 <= 30) {
      newSizeEnergy = loop37[ size+2 - 1];
    }
    else {
      newSizeEnergy = loop37[ 30 - 1];
      newSizeEnergy += 1.75*R_GAS*TEMP_K*log( (size+2)/30.0); 
    }
    
    Fx_2[ fbixIndex( j-i+2, i-1, size+2, seqlength)] = 
      Fx[ fbixIndex( j-i, i, size, seqlength)] +
      newSizeEnergy - oldSizeEnergy;
  }
}

/* ************************ */

double MinInextensibleIL( int i, int j, char seq[], int seqlength, 
			  double Fb[]) {
  /* This finds the minimum energy IL that has a special energy 
     calculation, i.e. small loops, bulge loops or GAIL case */

  double energy;
  int d, e; //Internal pair.(h, m will be restricted to special cases)  
  int L1, L2; //size parameters: L1 + L2 = size, L1 = h-i-1, L2 = j-m-1

  double min_energy = NAD_INFINITY;
  double tempMin;

  /* Consider "small" loops with special energy functions */  
  for( L1 = 0; L1 <= 3; L1++) {
    d = i + L1 + 1;
    for( L2 = 0; L2 <= MIN( 3, j-d-5); L2++) {
      e = j - L2 - 1;
   
      if( CanPair( seq[d], seq[e]) == TRUE) {
	energy = InteriorEnergy( i, j, d, e, seq);
	
	tempMin = energy + Fb[ pf_index( d, e, seqlength)];
	min_energy = MIN( tempMin, min_energy);
      }
    }
  }

  /* Next consider large bulges or large asymmetric loops */
  // Case 2a  L1 = 0,1,2,3, L2 >= 4;
  for( L1 = 0; L1 <= 3; L1++) {
    d = i + L1 + 1;
    for( L2 = 4; L2 <= j - d - 5; L2++) {
      e = j - L2 - 1;
      
      if( CanPair( seq[d], seq[e]) == TRUE) { 
	energy = InteriorEnergy( i, j, d, e, seq);
	tempMin = energy + Fb[ pf_index( d, e, seqlength)]; 
	min_energy = MIN( tempMin, min_energy);

      }
    }
  }

  // Case 2b L1 >= 4, L2 = 0,1,2,3;
  for( L2 = 0; L2 <= 3; L2++) {
    e = j - L2 - 1;
    for( L1 = 4;  L1 <= e - i - 5; L1++) {
      d = i + L1 + 1;
   
      if( CanPair( seq[d], seq[e]) == TRUE) { 
	energy = InteriorEnergy( i, j, d, e, seq);
	tempMin = energy + Fb[ pf_index( d, e, seqlength)];
	min_energy = MIN( tempMin, min_energy);
      }
    }
  }    

  return min_energy;
}


/* ******************************************************* */
/* Fs, Fms  Recursion */

void MakeFs_Fms( int i, int j, char seq[], int seqlength, 
		 double Fs[], double Fms[], double Fb[]) {
  /* Calculate the min values for the F_noPk matrix (no pseudoknots)
     Assume that j+1 is paired, unless j == seqlength - 1
  */  

  int d; //rightmost base pair is i,d
  double bp_penalty = 0.0;
  int pf_ij = pf_index( i, j, seqlength);
  double tempMin;

  for( d = i+4; d <= j; d++) {
    bp_penalty = 0.0;
    
    if( CanPair( seq[i], seq[ d]) == TRUE &&
	Base2int( seq[i]) + Base2int( seq[d]) == 5) {
      if( seq[i] != 'C' && seq[d] != 'C') {
	bp_penalty = AT_PENALTY;
      }
		
      tempMin =  Fb[ pf_index( i, d, seqlength) ] + 
	DangleEnergy( d+1, j, seq, seqlength) +
	(bp_penalty);           
      Fs[ pf_ij] = MIN( tempMin, Fs[pf_ij]);

      tempMin = Fb[ pf_index( i, d, seqlength) ] + 
	DangleEnergy( d+1, j, seq, seqlength) + 
	(bp_penalty + ALPHA_2 + ALPHA_3*(j-d));        
      Fms[ pf_ij] = MIN( tempMin, Fms[ pf_ij]);
    }
  }
}


/* ******************************* */
/* F, Fm Recursions */
void MakeF_Fm_N3( int i, int j, char seq[], int seqlength, 
		    double F[], double Fs[], 
		    double Fms[], double Fm[]) {

  int d;//left base of rightmost base pair.
  int pf_ij = pf_index( i, j, seqlength);
  double tempMin;

  F[ pf_ij] = //replace this with "ExpDangle"?
    DangleEnergy(i, j, seq, seqlength);  //Empty Graph

  for( d = i; d <= j - 4; d++) {
    tempMin= F[ pf_index(i, d-1, seqlength)] +
      Fs[ pf_index( d, j, seqlength)];
    F[ pf_ij] = MIN( tempMin, F[pf_ij]);
    
    tempMin = Fms[ pf_index( d, j, seqlength)] +
      DangleEnergy( i, d-1, seq, seqlength) +
      (ALPHA_3)*(d-i); //Single Pair
    Fm[ pf_ij] = MIN( tempMin, Fm[ pf_ij]);
    
    if( d >= i+5) { //else Qm(i, d-1) = 0;
      tempMin = Fm[ pf_index( i, d - 1, seqlength) ] +
	Fms[ pf_index( d, j, seqlength) ];

      Fm[ pf_ij] = MIN( Fm[ pf_ij], tempMin);

    }
    
    
  }
}
#endif //O_N3
/* **************** */
#ifdef O_N4

void MakeF_Fm_N4( int i, int j, char seq[], int seqlength, 
		      double F[], double Fm[], double Fb[] ){

  int d, e; // d - e is internal basepair 
  double bp_penalty = 0;
  int pf_ij = pf_index(i, j, seqlength);
  double tempMin;

  F[ pf_ij] = DangleEnergy(i, j, seq, seqlength);  //Empty Graph

  for( d = i; d <= j - 4; d++) {
    for( e = d + 4; e <= j; e++) {
      if( CanPair( seq[d], seq[e]) == TRUE &&
	  Base2int( seq[d]) + Base2int( seq[e]) == 5 ) {
	bp_penalty = 0;
	if( seq[d] != 'C' && seq[e] != 'C') {
	  bp_penalty = AT_PENALTY;
	}

	tempMin = F[ pf_index(i, d-1, seqlength)] +
	  Fb[ pf_index( d, e, seqlength) ] +
	  bp_penalty + 
	  DangleEnergy( e+1, j, seq, seqlength); 
	F[ pf_ij] = MIN( tempMin, F[ pf_ij]);
	
	tempMin =
	  (ALPHA_2 + ALPHA_3*(d-i + j-e) + bp_penalty) +
	  Fb[ pf_index( d, e, seqlength)] +
	  DangleEnergy( e+1, j, seq, seqlength) +
	  DangleEnergy( i, d-1, seq, seqlength);
	Fm[ pf_ij] = MIN( tempMin, Fm[ pf_ij]);

	
	if( d >= i+5) {
	  tempMin = Fm[ pf_index(i, d-1, seqlength)] +
	    Fb[ pf_index( d, e, seqlength)] +
	    (ALPHA_2 + ALPHA_3*(j-e) + bp_penalty) +
	    DangleEnergy( e+1, j, seq, seqlength);
	  Fm[ pf_ij] = MIN( tempMin, Fm[ pf_ij]);
	
	}
	
      }
    
    }
  }


}
#endif

/* *********************** */







