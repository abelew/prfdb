/*  PFunc.c by Robert Dirks 07/23/2001

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     

The purpose of this program is to calculate the partition function of
all possible secondary structures of a given strand of DNA/RNA, allowing for 
the simplest kinds of pseudoknots.  The Partition Function algorithm will 
follow the general format of (McCaskill 1990, Biopolymers, 29.  1105-19).  
The inclusion of pseudoknots and their corresponding energies relies heavily
on the ideas presented by (Rivas and Eddy 1999, J Mol Bio, 285, 2053-68) 
allow their exact Gap matrices are not used.  

The method used in this program will not allow for as general structures as 
Rivas and Eddy, but will have unique representations of each structure.  
This is accomplished by explicitly creating pseudoknots in the recursions.

The type of pseudoknots allowed in version 1 are of the form
i paired with j, h paired with m and i < h < j < m. i-j can be part of a 
helical region, as can h-m.  The helical regions can be interrupted by at most
an interior loop of size 2. 

Input:  Input will be a DNA sequence with or without spaces and on multiple
lines if necessary.  Lines beginning with > will be treated as a comment
The sequence can consist only of A,C,T or U,G (case insensitive).  
T's and U's will be interconverted as needed, based on whether DNA or RNA is 
used as a compile directive in constants.h

Output:  The output will be a numerical value for the partition function of
the sequence.

A secondary output will be a file with the pair probabilities in it.  
The default name of this file is Pb_N5.txt

Running: To run, type PFunc.out filename
Where filename is the name of the input file containing the sequence

This version of the algorithm mirrors the pseudocode found in my paper
(Dirks, Pierce JCC 24:, 1664-77, 2003).

*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#ifndef CONSTANTS_H
#include"constants.h"
#endif

#ifndef FUNCTIONS_H
#include"functions.h"
#endif

/* Declare Global Variables.  This will only include data to be read in from
   a file and used multiple times by energy evaluations */

#include "DNAGlobals.h"

/* End Global Variables */


/* ************************************************ */

int main( int argc, char *argv[] ) {
  
  char *seq;
  int seqlength = 0; 
  double *Q, *Qb, *Qm; //O(N^2)

#ifdef O_N3
  double *Qx, *Qx_1, *Qx_2; 
  double *Qs, *Qms;
#endif //O_N3

#ifdef PKNOTS
  double *Qp, *Qz; //O(N^2)
  double *Qg; //(O(N^4) space
  
#ifdef O_N5
  double *QgIx, *QgIx_1, *QgIx_2;
  double *Qgls, *Qgrs; //O(N^4) 
  double *Qgl, *Qgr; //O(N^4) space
#endif //O_N5

#endif //PKNOTS

#if defined(PAIRPR) && defined(O_N4)
  double *Pb;
#endif
#if defined(PAIRPR) && defined(O_N3)
  double *P, *Pb, *Pm, *Pms, *Ps;
#endif
#if defined(PAIRPR) && defined(O_N8)
  double *P, *Pb, *Pz, *Pp, *Pg, *Pbg, *Pm;
#endif
#if defined(PAIRPR) && defined(O_N5)
  double *P, *Pb, *Pz, *Pp, *Pg, *Pbg, *Pm, *Pgl, *Pgr, *Pgls, *Pgrs;
#endif

  /*  
      The above matrices are dynamically allocated matrices that
      contain partition functions restricted to a subsequence of the
      strand.  Each of the above should be accessed by the call
      Q[ pf_index(i, j)] to indicate the partition function between
      i and j, inclusive. 
      
      They are described in the paper mentioned above.
  */

  int i, j;// the beginning and end bases for Q
  int L; //This the length of the current subsequence 
  int pf_ij; //index for O(N^2) matrixes; used to reduce calls to pf_index

  extern long int maxGapIndex; 
  //used to minimize memory allocation for fastiloops
#ifdef O_N5
  short *possiblePairs; //a speedup for fastiloops (not in paper)
#endif

  header();
#ifndef PRINTRESULTSONLY
  printf("PFunc.out Version 1.1: Complexity ");
#ifdef O_N3
  printf("O(N^3)\n");
#endif
#ifdef O_N4
  printf("O(N^4)\n");
#endif
#ifdef O_N5
  printf("O(N^5) (pseudoknots enabled)\n");
#endif
#ifdef O_N8
  printf("O(N^8) (pseudoknots enabled)\n");
#endif
#endif

  ReadSequence( &seqlength, &seq, argv[1]);
  maxGapIndex = seqlength*(seqlength-1)*(seqlength-2)*(seqlength-3)/24;
  
#ifndef PRINTRESULTSONLY 
  printf("Sequence Read.\n");
#endif
  
  //GetEnergyParameters();
#ifdef RNA
  LoadEnergyFromStandardFile( "dataS_G.rna");
#else
  LoadEnergyFromStandardFile( "dataS_G.dna");
#endif
  //  WriteEnergyParameters("test.out");

#ifdef O_N5
  PrecomputeValues( seqlength);
#endif

#ifndef PRINTRESULTSONLY 
  printf("Energy Parameters Loaded\n");
#endif

  // Allocate and Initialize Matrices
  InitDoublesMatrix( &Q, seqlength*(seqlength+1)/2+(seqlength+1), "Q");
  InitDoublesMatrix( &Qb, seqlength*(seqlength+1)/2+(seqlength+1), "Qb");
  InitDoublesMatrix( &Qm, seqlength*(seqlength+1)/2+(seqlength+1), "Qm");

#ifdef O_N3
  InitDoublesMatrix( &Qs, seqlength*(seqlength+1)/2+(seqlength+1), "Qs");
  InitDoublesMatrix( &Qms, seqlength*(seqlength+1)/2+(seqlength+1), "Qms");
#endif //O_N3

  nonZeroInit( Q, seq, seqlength);
 
#ifdef PKNOTS
  InitDoublesMatrix( &Qp, seqlength*(seqlength+1)/2 + (seqlength+1), "Qp");
  InitDoublesMatrix( &Qz, seqlength*(seqlength+1)/2 + (seqlength+1), "Qz");
  nonZeroInit( Qz, seq, seqlength);
 
  InitDoublesMatrix( &Qg, seqlength*(seqlength-1)*(seqlength-2)*
			     (seqlength-3)/24, "Qg");
 
  
#ifdef O_N5
  InitDoublesMatrix( &Qgl, seqlength*(seqlength-1)*(seqlength-2)*
			     (seqlength-3)/24, "Qgl");
  InitDoublesMatrix( &Qgr, seqlength*(seqlength-1)*(seqlength-2)*
			     (seqlength-3)/24, "Qgr");
  InitDoublesMatrix( &Qgls, seqlength*(seqlength-1)*(seqlength-2)*
		     (seqlength-3)/24, "Qgls");
  InitDoublesMatrix( &Qgrs, seqlength*(seqlength-1)*(seqlength-2)*
		     (seqlength-3)/24, "Qgrs");
  CheckPossiblePairs( &possiblePairs, seqlength, seq);
#endif //O_N5
#endif //PKNOTS

#ifndef PRINTRESULTSONLY 
  printf( "SeqLength = %d\n", seqlength);
  printf( "Seq: ");
  for( i = 0; i < seqlength; i++) {
    printf("%c", seq[i]);
  }
  printf("\n");

#endif

  for( L = 1; L <= seqlength; L++) {
    /* Calculate all sub partition functions for
       distance = 0, then 1, then 2.... */

#ifdef O_N3
    manageQx( &Qx, &Qx_1, &Qx_2, L-1, seqlength);   
    //allocate/deallocate memory
#endif //O_N3

#ifdef O_N5
    manageQgIx( &QgIx, &QgIx_1, &QgIx_2, L-1, seqlength);
    //manageQgIx manages the temporary matrices needed for 
    //calculating Qg_closed in time n^5
#endif //PKNOTS

    for( i = 0; i <= seqlength - L; i++) {
      j = i + L - 1;
      pf_ij = pf_index( i, j, seqlength);

      /* Recursions for Qb.  See figure 13 of paper */
      /* bp = base pairs, pk = pseudoknots */

      if( CanPair( seq[ i], seq[ j]) == FALSE || j - i < 4) {
	Qb[ pf_ij] = 0.0;
      }
      else {
       	Qb[ pf_ij] = 
	  ExpHairpin( i, j, seq); //exactly 1 bp, 0 pk

#if defined (O_N4) || defined (PKNOTS)
	// Interior Loop and Multiloop Case
	Qb[ pf_ij] += SumExpQb( i, j, seq, seqlength, Qm, Qb);
#endif //O_N4 || O_N8

#ifdef O_N3
	//Multiloop Case
	Qb[ pf_ij] += SumExpMultiBp_N3(i, j, seq, Qms, Qm,
				       seqlength); 	 	  
#endif //O_N3
	
#ifdef PKNOTS
	Qb[ pf_ij] +=	  
	  SumExpQb_Pk( i, j, seq, seqlength, Qp, Qm );
#endif //PKNOTS 

      }
#ifdef O_N3
      fastILoops( i, j, L, seqlength, seq, Qb, Qx, Qx_2);
     

#endif


      /* Recursions for Qg.  Figures 16, 19 of paper */
#ifdef O_N8
      MakeQg_N8( i, j, seq, seqlength, Qg, Qm);
#endif


#ifdef O_N5     
      MakeQg_N5( i, j, seq, seqlength, Qg, Qm, Qgls, Qgrs, QgIx, QgIx_2,
		 possiblePairs);
     
      //figure 20
      MakeQgls( i, j, seq, seqlength, Qg, Qm, Qgls);
      MakeQgrs( i, j, seq, seqlength, Qg, Qm, Qgrs);
      
      //figure 18
      MakeQgl(i, j, seq, seqlength, Qg, Qgl, Qz);
      MakeQgr(i, j, seq, seqlength, Qgr, Qgl, Qz);
    
#endif

      /* Recursions for Qp.  figure 15, 17 */
#ifdef O_N8
      Qp[ pf_ij] += SumExpQp_N8( i, j, seq, seqlength, Qg, Qz);
#endif

#ifdef O_N5
      Qp[ pf_ij] += SumExpQp_N5( i, j, seq, seqlength, Qgl, Qgr);
#endif

#ifdef O_N3
      /* Recursions for Qms, Qs */
      MakeQs_Qms( i, j, seq, seqlength, Qs, Qms, Qb);
#endif    

      /* Recursions for Q, Qm, Qz */
#ifdef O_N3 
      MakeQ_Qm_N3( i, j, seq, seqlength, Q, Qs, Qms, Qm);
#endif //O_N3
      
#ifdef O_N4
      MakeQ_Qm_N4( i, j, seq, seqlength, Q, Qm, Qb);
#endif //O_N4

#ifdef PKNOTS
      //figures 12, 14
      MakeQ_Qm_Qz(i, j, seq, seqlength, Q, Qm, Qz, Qb, Qp);
#endif //PKNOTS

    }
  }

#ifndef PRINTRESULTSONLY 
  printf( "Q[ 1..N] = %12.16e\n", Q[ pf_index( 0, seqlength - 1, seqlength) ]);
  printf( "energy = %6.2f kcal/mol\n", 
	  -R_GAS*TEMP_K*log( Q[ pf_index( 0, seqlength - 1, seqlength) ]));
#else
  printf( "%12.16e\n", Q[ pf_index( 0, seqlength - 1, seqlength) ]);
#endif //PRINTRESULTSONLY


  //Next calculate Pair Probabilities (recompiling without PAIRPR will 
  //Cut runtime in half.)

#ifdef PAIRPR

#ifdef O_N4
  InitDoublesMatrix( &Pb, seqlength*(seqlength+1)/2+(seqlength+1), "Pb");
  calculatePairsN4( Q, Qb, Qm, Pb, seqlength, seq);
  
#endif
#ifdef O_N3
  InitDoublesMatrix(  &P, seqlength*(seqlength+1)/2+(seqlength+1), "P");
  InitDoublesMatrix(  &Pb, seqlength*(seqlength+1)/2+(seqlength+1), "Pb");
  InitDoublesMatrix(  &Pm, seqlength*(seqlength+1)/2+(seqlength+1), "Pm");
  InitDoublesMatrix(  &Pms, seqlength*(seqlength+1)/2+(seqlength+1), "Pms");
  InitDoublesMatrix(  &Ps, seqlength*(seqlength+1)/2+(seqlength+1), "Ps");

#ifdef OLD_N3PAIRS
  calculatePairsN3_OLD( Q, Qb, Qm, Qms, Pb, Pm, Pms, seqlength, seq);
#else 
  calculatePairsN3( Q, Qb, Qm, Qms, Qs, &Qx, &Qx_1, &Qx_2, P, Pb, Pm, Pms, 
		    Ps, seqlength, seq);
#endif

#endif
  
#ifdef O_N8
  InitDoublesMatrix( &P, seqlength*(seqlength+1)/2+(seqlength+1), "P");
  InitDoublesMatrix( &Pb, seqlength*(seqlength+1)/2+(seqlength+1), "Pb");
  InitDoublesMatrix( &Pm, seqlength*(seqlength+1)/2+(seqlength+1), "Pm");
  InitDoublesMatrix( &Pp, seqlength*(seqlength+1)/2+(seqlength+1), "Pp");
  InitDoublesMatrix( &Pz, seqlength*(seqlength+1)/2+(seqlength+1), "Pz");
  InitDoublesMatrix( &Pg, 
		     seqlength*(seqlength-1)*(seqlength-2)*(seqlength-3)/24,
		     "Pg");
  InitDoublesMatrix( &Pbg, seqlength*(seqlength+1)/2+(seqlength+1), "Pbg");

  P[ pf_index( 0, seqlength-1, seqlength)] = 1.0;
  calculatePairsN8( Q, Qb, Qm, Qp, Qz, Qg, P, Pb, Pp, Pz, Pg, Pbg, Pm,
		    seqlength, seq);
#endif

#ifdef O_N5
  InitDoublesMatrix( &P, seqlength*(seqlength+1)/2+(seqlength+1), "P");
  InitDoublesMatrix( &Pb, seqlength*(seqlength+1)/2+(seqlength+1), "Pb");
  InitDoublesMatrix( &Pm, seqlength*(seqlength+1)/2+(seqlength+1), "Pm");
  InitDoublesMatrix( &Pp, seqlength*(seqlength+1)/2+(seqlength+1), "Pp");
  InitDoublesMatrix( &Pz, seqlength*(seqlength+1)/2+(seqlength+1), "Pz");
  InitDoublesMatrix( &Pg, 
		   seqlength*(seqlength-1)*(seqlength-2)*(seqlength-3)/24,
		   "Pg");
  InitDoublesMatrix( &Pgl, 
		   seqlength*(seqlength-1)*(seqlength-2)*(seqlength-3)/24,
		   "Pgl");
  InitDoublesMatrix( &Pgr, 
		   seqlength*(seqlength-1)*(seqlength-2)*(seqlength-3)/24,
		   "Pgr");
  InitDoublesMatrix( &Pgls, 
		   seqlength*(seqlength-1)*(seqlength-2)*(seqlength-3)/24,
		   "Pgls");
  InitDoublesMatrix( &Pgrs, 
		   seqlength*(seqlength-1)*(seqlength-2)*(seqlength-3)/24,
		   "Pgrs");
  InitDoublesMatrix( &Pbg, seqlength*(seqlength+1)/2, "Pbg");
    
  P[ pf_index( 0, seqlength-1, seqlength)] = 1.0;
  
#ifndef OLD_N5PAIRS
  calculatePairsN5( Q, Qb, Qm, Qp, Qz, Qg, Qgl, Qgr, Qgls, Qgrs, &QgIx,
		    &QgIx_1, &QgIx_2, P,
		    Pb, Pp, Pz, Pg, Pbg, Pm, Pgl, Pgr, Pgls, Pgrs,
		    seqlength, seq);
#else
  calculatePairsN5_old( Q, Qb, Qm, Qp, Qz, Qg, Qgl, Qgr, Qgls, Qgrs, P,
		    Pb, Pp, Pz, Pg, Pbg, Pm, Pgl, Pgr, Pgls, Pgrs,
		    seqlength, seq);
#endif

  
#endif 

#endif

  return 1;
}
/* ****** */













