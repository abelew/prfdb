/* exp_energy.c by Robert Dirks 07/26/2001

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     

This file contains the energy functions (in the form of Exp"Structure") for 
computating the enrgies of each substrucure in the partition function
calculations. 

See functions.h for more specific descriptions of each function.
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

#ifndef CONSTANTS_H
#include"constants.h"
#endif

#ifndef FUNCTIONS_H
#include"functions.h"
#endif

//#include "DNAExternals.h"

double ExpHairpin( int i, int j, char seq[]) {

  // This gives the value of exp( -E/RT) where E is the energy of the 
  // hairpin loop closed by bases i and j.

  double energy = HairpinEnergy( i, j, seq);
  if( energy == NAD_INFINITY) {
    return 0.0;
  }
  
  return exp( -energy/( R_GAS*TEMP_K) );
}

/* *********************************************** */
double ExpInternal( int i, int j, int h, int m, char seq[]) {
  // Calculates E^(-energy/RT) of interior loop closed by i-j and h-m    
  
  double energy = InteriorEnergy( i, j, h, m, seq);
  if( energy == NAD_INFINITY) {
    return 0.0;
  }
  return exp( -energy/( R_GAS*TEMP_K));
}

/* *********************************************** */  

/*
double ExpPk( int i, int j, int h, int s, char seq[]) {
  // Calculates energy of interior loop closed by i-j and by a pk
  // with ends h, s

  return exp( -InteriorPkEnergy( i, j, h, s, seq)/ (R_GAS*TEMP_K) );
}
*/





