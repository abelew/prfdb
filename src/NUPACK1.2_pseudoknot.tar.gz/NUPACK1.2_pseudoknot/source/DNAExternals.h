//Include this in source files that use it

/*
The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     
*/

extern double AT_PENALTY;
extern double POLYC3;
extern double POLYCSLOPE;
extern double POLYCINT;
extern double ALPHA_1; //multiloop penalties
extern double ALPHA_2;
extern double ALPHA_3;
extern double BETA_1; //pseudoknot penalties
extern double BETA_2;
extern double BETA_3;
extern double BETA_1M;
extern double BETA_1P;
