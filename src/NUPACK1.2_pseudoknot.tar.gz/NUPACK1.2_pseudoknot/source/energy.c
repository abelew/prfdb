/*  energy.c  by Robert Dirks.  

The code in this file may only be used subject to agreement with the terms 
contained in the accompanying file "LICENSE"     

This file contains energy functions used for determining energies
*/


#ifndef CONSTANTS_H
#include "constants.h"
#endif // Make sure this file isn't included multiple times

#ifndef FUNCTIONS_H
#include "functions.h"
#endif // Make sure this file isn't included multiple times

#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>
 
#include"DNAExternals.h"

/* ************************************** */

double HelixEnergy( char i, char j, char h, char m) {
  // Calculate the energy of the helical region closed by pair
  // i-j and h-m.  Data from Zuker's mfold file stack.dgd

  int shift_ij; // Type of base pair 
  int shift_hm; // Type of base pair

  extern double Stack[];

  shift_ij = GetMismatchShift( i, j);
  shift_hm = GetMismatchShift( h, m);
  
  if( shift_ij < 4 && shift_hm < 4) {
    //printf("%f\n",Stack[ (Base2int( i) - 1)*6 + (Base2int( h) - 1) ]);
    return Stack[ (Base2int( i) - 1)*6 + (Base2int( h) - 1) ];
  }
  if( shift_ij < 4 && shift_hm >= 4) {
    return Stack[ (Base2int( i) - 1)*6 + (Base2int( h) + 1) ];
  }
  if( shift_ij >= 4 && shift_hm < 4) {
    return Stack[ (Base2int( i) + 1)*6 + (Base2int( h) - 1) ];
  }
  if( shift_ij >= 4 && shift_hm >= 4) {
    return Stack[ (Base2int( i) + 1)*6 + (Base2int( h) + 1) ];
  }
  else {
    printf("Error in HelixEnergy!");
    exit(0);
    return NAD_INFINITY; // This never is returned
  }
} 

// *******************************************************************


double InteriorMM( char a, char b, char x, char y) {
/*
  Interior Mismatch calculation 

  This calculates the Mismatch interaction energies between positions
  1 -> 5' a x 3'
  2 -> 3' b y 5'
Interactions energies taken from file tstacki2.dgd.
*/

  extern double MMEnergiesIL[];

  int cp_shift;
  double energy = 0.0;

  cp_shift = GetMismatchShift( a, b );

  energy = MMEnergiesIL[ (4*(Base2int( x) - 1) + 
			  (Base2int( y) - 1) )*6
			 + cp_shift];

  return energy;
  
}

/* ********************************************** */


double HairpinEnergy( int i, int j, char seq[] ) {
  
  // This gives the energy of the hairpion closed by bases i and j

  extern double loop37[];
  extern double tloop_energy[];
  extern double triloop_energy[];
  extern double MMEnergiesHP[];

  double energy;  //energy of hairpin

  int triloopnumber; //Index for specific triloop
  int tloopnumber; //index for tloops

  int size; //Doesn't include closing pair i-j

  int cp_shift; //Classification of base-pair for energy mismatch

  int polyC = TRUE;  //Is the hairpin a poly-C?
  int k;
  for( k = i+1; k < j; k++) {
    if( seq[k] != 'C') {
      polyC = FALSE;
      break;
    }
  }


  size = j - i - 1;

  if( size < 3) {
    return NAD_INFINITY;
  }

  if( CanPair( seq[i], seq[j]) == FALSE ) {
    return NAD_INFINITY;
  }
  
  if( size <= 30) {
    energy = loop37[ 60 + size - 1];
  }
  else {
    energy = loop37[ 60 + 30 - 1];
    energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
  }


  if( size == 3) {
    //Get Triloop energy
    
    if( seq[i] != 'C' && seq[j] != 'C') {
      energy += AT_PENALTY;
    }
    

    triloopnumber = 256*(Base2int( seq[i]) - 1) + 
		64*(Base2int( seq[i + 1]) - 1) + 
		16*(Base2int( seq[i + 2]) - 1) + 
		4*( Base2int( seq[j - 1]) - 1) + 
		1*( Base2int( seq[j]) - 1);
  
    // 0 mismatch energy for triloops

    energy += triloop_energy[ triloopnumber];

    //Poly-C loop
    if( polyC == TRUE) {
      energy += POLYC3;
    }
    
  }
  else if (size == 4) {
  
    tloopnumber = 1024*(Base2int( seq[i]) - 1) + 
		256*(Base2int( seq[i + 1]) - 1) + 
		64*( Base2int( seq[i + 2]) - 1) + 
		16*( Base2int( seq[j - 2]) - 1) + 
		4*(  Base2int( seq[j - 1]) - 1) + 
		1*(  Base2int( seq[j])- 1);
    energy +=  tloop_energy[ tloopnumber];
    
    //Next do mismatches.
    cp_shift = GetMismatchShift( seq[i], seq[j]);
    
    energy += MMEnergiesHP[(4*(Base2int( seq[i + 1]) - 1) + 
			  (Base2int( seq[j - 1]) - 1) )*6
			  + cp_shift];
    //Poly-C loop
    if( polyC == TRUE) {
      energy += POLYCSLOPE*size + POLYCINT;
    }

  }

  else if (size > 4) {
    // Calculate mismatch
    cp_shift = GetMismatchShift( seq[i], seq[j]);
    
    energy += MMEnergiesHP[(4*(Base2int( seq[i + 1]) - 1) + 
			  (Base2int( seq[j - 1]) - 1) )*6
			  + cp_shift];

    //Poly-C loop
    if( polyC == TRUE) {
      energy += POLYCSLOPE*size + POLYCINT;
    }
    
  }

  return energy;

}



/* ****************************************** */


double InteriorEnergy(  int i, int j, int h, int m, char seq[]) {
  // Calculates energy of interior loop closed by i-j and h-m 
  
  extern double loop37[];
  extern double IL_SInt2[];
  extern double IL_SInt4[];
  extern double IL_AsInt1x2[];
  extern double asymmetry_penalty[];
  extern double max_asymmetry;

  double energy = 0.0;
  int L1, L2; //lengths of the 2 single stranded regions
  int size;
  
  int asymmetry;
  int asymmetry_index;

  int cp_shift, ip_shift;  // For classifying basepairs


  if( i >= h || h >= m || m >= j) {
    printf("Invalid boundary to interior loop!\n");
    exit(0);
  }
  
  if( m - h < 4) { //Not enough room for pair 
    printf("Bases too close for internal pair!");
    exit(0);
  }

  L1 = h - i - 1;
  L2 = j - m - 1;
  size = L1 + L2;

  if( size == 0) { //Helical region
    energy = HelixEnergy( seq[i], seq[j], seq[h], seq[m] );
  }

  else if ( L1*L2 == 0) { //Bulge
    if( size <= 30) {
      energy = loop37[ 30 + size - 1];
    }
    else {
      energy = loop37[ 30 + 30 - 1];
      energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
    }
    
    if( L1 + L2 == 1 ) { //single bulge...treat as a stacked region
      energy += HelixEnergy( seq[i], seq[j], seq[h], seq[m] );
    }
    else {

      // Next do AT_Penalty for no GC termination, assuming size >= 2
      if( seq[i] != 'C' && seq[j] != 'C') {
	energy += AT_PENALTY;
      }
      if( seq[h] != 'C' && seq[m] != 'C') {
	energy += AT_PENALTY;
      }
    }

  }
  else if ( L1 > 0 && L2 > 0) {
    asymmetry = abs( L1 - L2);
    if( asymmetry > 1 || size > 4) { //data not tabulated

      //Loop Size Energy
      if( size <= 30) {
	energy = loop37[ size - 1];
      }
      else {
	energy = loop37[ 30 - 1];
	energy += 1.75*R_GAS*TEMP_K*log( size/30.0); 
      }
	 
      //Asymmetry rountine copied from efn.f in Zuker's mfold package.
      asymmetry_index = 4;
      if( L1 < asymmetry_index) {
	asymmetry_index = L1;
      }
      if( L2 < asymmetry_index) {
	asymmetry_index = L2;
      }
      if( asymmetry*asymmetry_penalty[ asymmetry_index - 1] < max_asymmetry ) {
	energy += asymmetry*asymmetry_penalty[ asymmetry_index - 1];
      }
      else {
	energy += max_asymmetry; // MAX asymmetry penalty
      }

      //Stacking Energy
      if( L1 > 1 && L2 > 1) { //Non-GAIL Version
	energy += InteriorMM( seq[i], seq[j], seq[i+1], seq[j-1])
	  + InteriorMM( seq[m], seq[h], seq[m+1], seq[h-1]);
      }
      else if( L1 == 1 || L2 == 1) {// GAIL =>assume AA terminal mismatch
#ifndef NO_GAIL
	energy += InteriorMM( seq[i], seq[j], 'A', 'A') +
	  InteriorMM( seq[m], seq[h], 'A', 'A');
#else
	energy += InteriorMM( seq[i], seq[j], seq[i+1], seq[j-1])
	  + InteriorMM( seq[m], seq[h], seq[m+1], seq[h-1]);
#endif
	
      }
      else {
	printf("Error: Unclassified interior loop!\n");
	exit(0);
      }
      
    }
    else { //get tabulated data
      if( asymmetry == 0 && size == 2) {
	cp_shift = GetMismatchShift( seq[i], seq[j]);
	ip_shift = GetMismatchShift( seq[h], seq[m]);
	energy += IL_SInt2[ 96*cp_shift + 16*ip_shift + 
			  4*(Base2int( seq[i+1]) - 1) + 
			  (Base2int( seq[ j -1]) - 1) ];
      }
      else if( asymmetry == 0 && size == 4) {
	cp_shift = GetMismatchShift( seq[i], seq[j]);
	ip_shift = GetMismatchShift( seq[h], seq[m]);
	energy += IL_SInt4[ cp_shift*256*6 +  ip_shift*256 +
			  (4*(Base2int( seq[ i+1])  - 1) + 
			   Base2int( seq[ j - 1])   - 1)*16 +
			  (4*( Base2int( seq[ i+2]) - 1) + 
			   Base2int( seq[ j - 2])   - 1) ];
      }
      else if( asymmetry == 1 && L1 == 1) {
	cp_shift = GetMismatchShift( seq[i], seq[j]);
	ip_shift = GetMismatchShift( seq[h], seq[m]);
	energy += IL_AsInt1x2[ cp_shift*4*24*4 + 
			     (Base2int( seq[ j - 2]) - 1)*24*4 +
			     (Base2int( seq[ i + 1]) - 1)*24 + 
			     4*ip_shift +	
			     ((Base2int( seq[ j - 1]) - 1) % 4) ]; 
      }
      else if( asymmetry == 1 && L1 == 2) {
	cp_shift = GetMismatchShift( seq[j], seq[i]);
	ip_shift = GetMismatchShift( seq[m], seq[h]);
	//note reversed order of inputs above.  
	//This is to comply with the format of asint1x2

	energy += IL_AsInt1x2[ ip_shift*4*24*4 + 
			     (Base2int( seq[i + 1]) - 1)*24*4 +
			     (Base2int( seq[j - 1]) - 1)*24 + 
			     4*cp_shift +
			     ((Base2int( seq[i + 2]) - 1) % 4) ]; 
      }
      else {
	printf("Error in tabulated Interior Loop!\n");
	exit(1);
      }
    }  
  }
  else {
    printf( "Improperly classified Interior Loop!\n");
    exit(0);
  }

  return energy;
}
  


/* ********************************************** */
double DangleEnergyWithPairs( int i, int j, int pairs[], 
			     char seq[], int seqlength) {
  
  double dangle5 = 0;
  double dangle3 = 0;
  int dangle_shift;
  extern double dangle_energy[];

  int pairi1 = pairs[i-1];
  int pairj1 = pairs[j+1];

  //  printf("%d %d\n", i, j);

#ifndef VIENNA_D2
  if( j == i - 1) {
    return 0;
  }
  
#else
  if( j == i - 1 && (i == 0 || j == seqlength - 1) ) {
    return 0;
  }
#endif


  if( j == seqlength - 1) {
    dangle3 = 0;
  }
  else {
   
    //dangle_shift = 3 - GetPairType( seq[ j + 1]);
    dangle_shift = GetMismatchShift( seq[ pairj1], seq[ j+1]);
#ifdef MATCH_PF
    if( dangle_shift >= 4) {
      printf("Error! This struture not in PF because of wobble %d %d\n", i, j);
      exit(0);
    }
#endif

    dangle3 = dangle_energy[ 24 + dangle_shift*4 + 
			      Base2int( seq[ j]) - 1];
  }
  
  if( i == 0) {
    dangle5 = 0;
  }
  else {
    dangle_shift = GetMismatchShift( seq[ i-1], seq[ pairi1]);
    //dangle_shift = GetPairType( seq[i-1]);
#ifdef MATCH_PF
    if( dangle_shift >= 4) {
      printf("Error! This struture not in PF because of wobble- %d %d\n",i,j);
      exit(0);
    }
#endif

    dangle5 = dangle_energy[ dangle_shift*4 + 
			     Base2int( seq[ i]) - 1];
  }
#ifndef VIENNA_D2
  if( i == j && i != 0 && j != seqlength - 1) {
    return MIN(dangle3, dangle5 );
  }
  else {
    return dangle3 + dangle5;
  }
#else 
  return dangle3 + dangle5;
#endif
}

/* ******************************** */

#ifdef COAXIAL
double CoaxDangle( int whichDangle, int i, int j, int pairs[], 
		   char seq[], int seqlength) {
  
  double dangle5 = 0;
  double dangle3 = 0;
  int dangle_shift;
  extern double dangle_energy[];

  int pairi1 = pairs[i-1];
  int pairj1 = pairs[j+1];

  //  printf("%d %d\n", i, j);

#ifdef MATCH_PF
  printf("Coaxially Stacking needs to be off to match PF calculations!\n");
  exit(0);
#endif

#ifndef VIENNA_D2
  if( j == i - 1) {
    return 0;
  }
  
#else
  if( j == i - 1 && (i == 0 || j == seqlength - 1) ) {
    return 0;
  }
#endif


  if( j == seqlength - 1) {
    dangle3 = 0;
  }
  else {
   
    dangle_shift = GetMismatchShift( seq[ pairj1], seq[ j+1]);
#ifdef MATCH_PF
    if( dangle_shift >= 4) {
      printf("Error! This struture not in PF because of wobble %d %d\n", i, j);
      exit(0);
    }
#endif

    dangle3 = dangle_energy[ 24 + dangle_shift*4 + 
			      Base2int( seq[ j]) - 1];
  }
  
  if( i == 0) {
    dangle5 = 0;
  }
  else {
    dangle_shift = GetMismatchShift( seq[ i-1], seq[ pairi1]);
#ifdef MATCH_PF
    if( dangle_shift >= 4) {
      printf("Error! This struture not in PF because of wobble- %d %d\n",i,j);
      exit(0);
    }
#endif

    dangle5 = dangle_energy[ dangle_shift*4 + 
			     Base2int( seq[ i]) - 1];
  }

  if( whichDangle == 3) {
    return dangle3;
  }
  if( whichDangle == 5) {
    return dangle5;
  }
  if( whichDangle == 53) {

#ifndef VIENNA_D2
    if( i == j && i != 0 && j != seqlength - 1) {
      return MIN(dangle3, dangle5 );
    }
    else {
      return dangle3 + dangle5;
    }
#else 
    return dangle3 + dangle5;
#endif
  }
  else {
    printf("Invalid whichDangle Value of %d in CoaxDangle\n", whichDangle);
    exit(0);
  }
}
#endif
/* ******************************** */



double DangleEnergy( int i, int j, char seq[], int seqlength) {
  //0 energy except for dangles

  double dangle5 = 0;
  double dangle3 = 0;
  int dangle_shift;
  extern double dangle_energy[];

  //  printf("%d %d\n", i, j);

#ifndef VIENNA_D2
  if( j == i - 1) {
    return 0;
  }
  
#else
  if( j == i - 1 && (i == 0 || j == seqlength - 1) ) {
    return 0;
  }
#endif


  if( j == seqlength - 1) {
    dangle3 = 0;
  }
  else {
   
    dangle_shift = 3 - GetPairType( seq[ j + 1]);
    dangle3 = dangle_energy[ 24 + dangle_shift*4 + 
			      Base2int( seq[ j]) - 1];
  }
  
  if( i == 0) {
    dangle5 = 0;
  }
  else {
   
    dangle_shift = GetPairType( seq[i-1]);
    dangle5 = dangle_energy[ dangle_shift*4 + 
			     Base2int( seq[ i]) - 1];
  }
#ifndef VIENNA_D2
  if( i == j && i != 0 && j != seqlength - 1) {
    return MIN(dangle3, dangle5 );
  }
  else {
    return dangle3 + dangle5;
  }
#else 
  return dangle3 + dangle5;
#endif
}

/* ******************************** */


double ExpDangle( int i, int j, char seq[], int seqlength) {
  //0 energy except for dangles

  double dangle5 = 0;
  double dangle3 = 0;
  int dangle_shift;
  extern double dangle_energy[];

#ifndef VIENNA_D2
  if( j == i - 1) {
    return 1.0;
  }
  
#else
  if( j == i - 1 && (i == 0 || j == seqlength - 1) ) {
    return 1.0;
  }
#endif

  if( j == seqlength - 1) {
    dangle3 = 0;
  }
  else {
    dangle_shift = 3 - GetPairType( seq[ j + 1]);
    dangle3 = dangle_energy[ 24 + dangle_shift*4 + 
			      Base2int( seq[ j]) - 1];
  }
  
  if( i == 0) {
    dangle5 = 0;
  }
  else {
    dangle_shift = GetPairType( seq[i-1]);
    dangle5 = dangle_energy[ dangle_shift*4 + 
			     Base2int( seq[ i]) - 1];
  }
#ifndef VIENNA_D2
  if( i == j && i != 0 && j != seqlength - 1) {
    return exp( -MIN(dangle3, dangle5)/(TEMP_K*R_GAS) );
  }
  else {
    return exp( -(dangle3 + dangle5)/(TEMP_K*R_GAS) );
  }
#else 
  return exp( -(dangle3 + dangle5)/(TEMP_K*R_GAS) );
#endif
}

/* *************************************** */

void LoadEnergyFromStandardFile( char filename[]) {
  
  extern double loop37[];  
  extern double tloop_energy[];
  extern double triloop_energy[];
  extern double MMEnergiesHP[];
  extern double MMEnergiesIL[];
  extern double IL_SInt2[];
  extern double IL_SInt4[];
  extern double IL_AsInt1x2[];
  extern double dangle_energy[];
  extern double asymmetry_penalty[];
  extern double max_asymmetry;
  extern double Stack[];
  
  //temporary storage of data
  int nRead;
  int array[MAXLINE];
  char *token;
  char tetraloop[6];
  char triloop[5];
  int index, tmpIndex;

  FILE *fp;

  char line[MAXLINE];
  int i, j, k;
  char *energy_file = getenv( "ENERGY_FILE" );
  if (energy_file != NULL) {
    filename = energy_file;
  }
  
  fp = fopen( filename, "r");
  if( fp == NULL) {  /* Make sure input file exits */
    printf("Error opening loop data file: %s\n", filename);
    exit(0);  
  }
  
  fgets( line, MAXLINE, fp);
  while( line[0] == '>') {
    fgets( line, MAXLINE, fp);
  }

  //Read in Stacking data
  for( i = 0; i < 6; i++) {

    nRead = 0;
    token = strtok( line, " ");
    while( token != NULL) {
      if( sscanf( token, "%d", &(array[ nRead]) ) == 1) {
	nRead++;
      }
      token = strtok( NULL, " ");
    }

    if( nRead != 6) {
      printf("Error in stacking data format\n");
      exit(0);
    }
    for( j = 0; j < 6; j++) {
      Stack[i*6+j] = (double) array[j]/100.0;
    }
   
    fgets( line, MAXLINE, fp);
  }

  for( i = 0; i < 3; i++) {
    while( line[0] == '>') {
      fgets( line, MAXLINE, fp);
    }
    
    nRead = 0;
    token = strtok( line, " ");
    while( token != NULL) {
      if( sscanf( token, "%d", &(array[ nRead]) )==1) {
	nRead++;
      }
      token = strtok( NULL, " ");
    }

    if( nRead != 30) {
      printf("Error in Loop energies data\n");
      exit(0);
    }
    for( j = 0; j < 30; j++) {
      loop37[30*(2-i)+j] = (double) array[j]/100.0;
    }
    
    fgets( line, MAXLINE, fp);
  }

  while( line[0] == '>') {
    fgets( line, MAXLINE, fp);
  }
	
  nRead = 0;
  token = strtok( line, " ");
  while( token != NULL) {
    if( sscanf( token, "%d", &(array[ nRead]) )==1 ) {
      nRead++;
    }
    token = strtok( NULL, " ");
  }

  if( nRead != 5) {
    printf("Error in asymmetry terms!\n");
    exit(0);
  }

  for( j = 0; j < 4; j++) {
    asymmetry_penalty[j] = (double) array[j]/100.0;
  }
  max_asymmetry = (double) array[4]/100.0;

  //Triloops
  fgets( line, MAXLINE, fp);
  while( line[0] == '>') {
    fgets( line, MAXLINE, fp);
  }
  for( i = 0; i < 2048; i++) {
    triloop_energy[i] = 0;
  }
  while( line[0] != '>') {
   
    if( sscanf( line, "%s %d", triloop, &(array[0]) ) == 2) {
      index = 0;
      for( i = 0 ; i < 5; i++) {
	tmpIndex = 1;
	for( j = 0; j < i; j++) {
	  tmpIndex *= 4;
	}
	if( triloop[4-i] == 'C') {
	  index += tmpIndex;
	}
	else if( triloop[4-i] == 'G') {
	  index += tmpIndex*2;
	}
	else if( triloop[4-i] == 'U' || triloop[4-i] == 'T') {
	  index += tmpIndex*3;
	}
	else if( triloop[4-i] != 'A') {
	  printf("Error in triloop indexing %s\n", triloop);
	}
      }
      triloop_energy[ index] = (double) array[0]/100.0;
    }
    else {
      printf("Error in triloop data\n%s\n",line);
    }
    fgets( line, MAXLINE, fp);
  }

  //Tetraloops
  while( line[0] == '>') {
    fgets( line, MAXLINE, fp);
  }
  for( i = 0; i < 4096; i++) {
    tloop_energy[i] = 0;
  }
  while( line[0] != '>') {
   
    if( sscanf( line, "%s %d", tetraloop, &(array[0]) ) == 2) {
      index = 0;
      for( i = 0 ; i < 6; i++) {
	tmpIndex = 1;
	for( j = 0; j < i; j++) {
	  tmpIndex *= 4;
	}
	if( tetraloop[5-i] == 'C') {
	  index += tmpIndex;
	}
	else if( tetraloop[5-i] == 'G') {
	  index += tmpIndex*2;
	}
	else if( tetraloop[5-i] == 'U' || tetraloop[5-i] == 'T') {
	  index += tmpIndex*3;
	}
	else if( tetraloop[5-i] != 'A') {
	  printf("Error in tetraloop indexing %s\n", tetraloop);
	}
      }
      tloop_energy[ index] = (double) array[0]/100.0;
    }
    else {
      printf("Error in tetraloop data\n%s\n",line);
    }
    fgets( line, MAXLINE, fp);
  }

  while( line[0] == '>') {
    fgets( line, MAXLINE, fp);
  }

  //fprintf(fp, "Mismatch Hairpin: \n");
  for( i = 0; i < 16; i++) {
    
    nRead = 0;
    token = strtok( line, " ");
    while( token != NULL) {
      if( sscanf( token, "%d", &(array[ nRead]) )==1 ) {
	nRead++;
      }
      token = strtok( NULL, " ");
    }

    if( nRead != 6) {
      printf("Error in mismatch hairpin format! %d\n", nRead);
      exit(0);
    }
    
    for( j = 0; j < 6; j++) {
      MMEnergiesHP[ 6*i + j] = (double) array[j]/100.0;
    }

    fgets( line, MAXLINE, fp);
  }

  while( line[0] == '>') {
    fgets( line, MAXLINE, fp);
  }

  //fprintf(fp, "Mismatch Interior: \n");
  for( i = 0; i < 16; i++) {

    nRead = 0;
    token = strtok( line, " ");
    while( token != NULL) {
      if( sscanf( token, "%d", &(array[ nRead]) )==1 ) {
	nRead++;
      }
      token = strtok( NULL, " ");
    }

    if( nRead != 6) {
      printf("Error in mismatch Interior format!\n");
      exit(0);
    }
    
    for( j = 0; j < 6; j++) {
      MMEnergiesIL[ 6*i + j] = (double) array[j]/100.0;
    }

    fgets( line, MAXLINE, fp);
  }

  while( line[0] == '>') {
    fgets( line, MAXLINE, fp);
  }

  //Read in Dangles
  for( i = 0; i < 6; i++) {
    nRead = 0;
    token = strtok( line, " ");
    while( token != NULL) {
      if( sscanf( token, "%d", &(array[ nRead]) )==1 ) {
	nRead++;
      }
      token = strtok( NULL, " ");
    }

    if( nRead != 4) {
      printf("Error in dangle data format!\n");
      exit(0);
    }
    for( j = 0; j < 4; j++) {
      dangle_energy[i*4+j] = (double) array[j]/100.0;
#ifdef NODANGLES
      dangle_energy[i*4+j] = 0;
#endif
    }
   
    fgets( line, MAXLINE, fp);
  }

  while( line[0] == '>') {
    fgets( line, MAXLINE, fp);
  }

  //Read in Dangles
  for( i = 0; i < 6; i++) {
    nRead = 0;
    token = strtok( line, " ");
    while( token != NULL) {
      if( sscanf( token, "%d", &(array[ nRead]) )==1 ) {
	nRead++;
      }
      token = strtok( NULL, " ");
    }

    if( nRead != 4) {
      printf("Error in dangle data format!\n");
      exit(0);
    }
    for( j = 0; j < 4; j++) {
      dangle_energy[24+ i*4+j] = (double) array[j]/100.0;
#ifdef NODANGLES
      dangle_energy[24+ i*4+j] = 0;
#endif
    }
   
    fgets( line, MAXLINE, fp);
  }

  while( line[0] == '>') {
    fgets( line, MAXLINE, fp);
  }
  //Multiloop parameters
  nRead = 0;
  token = strtok( line, " ");
  while( token != NULL) {
    if( sscanf( token, "%d", &(array[ nRead]) ) ==1) {
      
      nRead++;
    }
    token = strtok( NULL, " ");
  }


  if( nRead != 3) {
    printf("Error in dangle data format!\n");
    exit(0);
  }

  ALPHA_1 = (double) array[0]/100.0;
  ALPHA_2 = (double) array[1]/100.0;
  ALPHA_3 = (double) array[2]/100.0;

  fgets( line, MAXLINE, fp);
  while( line[0] == '>') {
    fgets( line, MAXLINE, fp);
  }

  //AT PENALTY
  if( sscanf(line, "%d", &(array[0]) ) == 1) {
    AT_PENALTY = (double) array[0]/100.0;
  }
  else {
    printf("Error in AT PENALTY data\n");
    exit(0);
  }

  fgets( line, MAXLINE, fp);
  while( line[0] == '>') {
    fgets( line, MAXLINE, fp);
  }

  //1x1 interior loop
  for( i = 0; i < 36; i++) {
    fgets( line, MAXLINE, fp); //read in label
    for( j = 0; j < 4; j++) {
      
      nRead = 0;
      token = strtok( line, " ");
      while( token != NULL) {
	if( sscanf( token, "%d", &(array[ nRead]) )==1 ) {
	 
	  nRead++;
	}
	token = strtok( NULL, " ");
      }
      
      if( nRead != 4) {
	printf("Error in 1x1 format!\n");
	exit(0);
      }
      
      for( k = 0; k < 4; k++) {
	IL_SInt2[ i*16 + j*4 + k] = (double) array[ k]/100.0;
      }

      fgets( line, MAXLINE, fp);
    }
  }

  
  while( line[0] == '>') {
    fgets( line, MAXLINE, fp);
  }

  //2x2 interior loop
  for( i = 0; i < 36*16; i++) {
    fgets( line, MAXLINE, fp); //read in label
    for( j = 0; j < 4; j++) {
      
      nRead = 0;
      token = strtok( line, " ");
      while( token != NULL) {
	if( sscanf( token, "%d", &(array[ nRead]) )==1 ) {
	 
	  nRead++;
	}
	token = strtok( NULL, " ");
      }
      
      if( nRead != 4) {
	printf("Error in 1x1 format!\n");
	exit(0);
      }
      
      for( k = 0; k < 4; k++) {
	IL_SInt4[ 1536*(i/96)+256*((i%96)/16) +
		  64*((i%16)/4) + 4*(i%4) + k*16 + j] = 
	  (double) array[ k]/100.0;
      }

      fgets( line, MAXLINE, fp);
    }
  }

  while( line[0] == '>') {
    fgets( line, MAXLINE, fp);
  }

  //1x2 interior loop
  for( i = 0; i < 144; i++) {
    fgets( line, MAXLINE, fp); //read in label
    for( j = 0; j < 4; j++) {
      
      nRead = 0;
      token = strtok( line, " ");
      while( token != NULL) {
	if( sscanf( token, "%d", &(array[ nRead]) )==1 ) {
	
	  nRead++;
	}
	token = strtok( NULL, " ");
      }
      
      if( nRead != 4) {
	printf("Error in 1x1 format!\n");
	exit(0);
      }
      
      for( k = 0; k < 4; k++) {
	IL_AsInt1x2[ 384*(i/24) + 4*((i%24)/4) + 24*(i%4) +
		     96*j + k] = (double) array[ k]/100.0;
      }
      
      fgets( line, MAXLINE, fp);
    }
  }

  while( line[0] == '>') {
    fgets( line, MAXLINE, fp);
  }

  //polyC hairpin parameters
  nRead = 0;
  token = strtok( line, " ");
  while( token != NULL) {
    if( sscanf( token, "%d", &(array[ nRead]) )==1 ) {
    
      nRead++;
    }
    token = strtok( NULL, " ");
  }

  if( nRead != 3) {
    printf("Error in dangle data format!\n");
    exit(0);
  }

  POLYC3 = (double) array[0]/100.0;
  POLYCSLOPE = (double) array[1]/100.0;
  POLYCINT = (double) array[2]/100.0;

  fgets( line, MAXLINE, fp);
  while( line[0] == '>') {
    fgets( line, MAXLINE, fp);
  }


  //Pseudoknot parameters
  nRead = 0;
  token = strtok( line, " ");
  while( token != NULL) {
    if( sscanf( token, "%d", &(array[ nRead]) )==1 ) {
     
      nRead++;
    }
    token = strtok( NULL, " ");
  }

  if( nRead != 5) {
    printf("Error in dangle data format!\n");
    exit(0);
  }

  BETA_1 = (double) array[0]/100.0;
  BETA_2 = (double) array[1]/100.0;
  BETA_3 = (double) array[2]/100.0;
  BETA_1M = (double) array[3]/100.0;
  BETA_1P = (double) array[4]/100.0;

  fclose( fp);
}

/* ********************** */
//This should be moved

void header() {
  printf("****************************************************************\n");
  printf("NUPACK 1.2\n");
  printf("Copyright 2003, 2004 by Robert M. Dirks & Niles A. Pierce\n"); 
  printf("California Institute of Technology\n");
  printf("Pasadena, CA 91125 USA\n\n");
  printf("Last Modified: 03/18/2004\n");
  printf("****************************************************************\n");
  printf("\n\n");
}
    

/*
void WriteEnergyParameters( char filename[]) {

  extern double loop37[];  
  extern double tloop_energy[];
  extern double triloop_energy[];
  extern double MMEnergiesHP[];
  extern double MMEnergiesIL[];
  extern double IL_SInt2[];
  extern double IL_SInt4[];
  extern double IL_AsInt1x2[];
  extern double dangle_energy[];
  extern double asymmetry_penalty[];
  extern double max_asymmetry;
  extern double Stack[];
  FILE *fp;

  int i;

  fp = fopen( filename, "w");
  fprintf(fp,"Stacking: AT/AT, AT/CG, AT/GC, AT/TA, AT/GT, AT/TG; CG/AT...\n");
  for( i = 0; i < 36; i++) {
    fprintf(fp, "%0.3f\n", Stack[i]);
  }
  fprintf(fp, "Asymmetry Penalty\n");
  for( i = 0; i < 4; i++) {
    fprintf(fp, "%0.3f\n", asymmetry_penalty[i]);
  }
  fprintf(fp, "loop37: (0-29) Internal, 30-59 = BULGE, 60-89 = HAIRPIN\n");
  for( i = 0; i < 90; i++) {
     fprintf(fp, "%0.3f\n", loop37[i]);
  }
  fprintf(fp, "Triloops Energies:\n");
  for( i = 0; i < 1024; i++) {
    fprintf(fp, "%0.3f\n", triloop_energy[i]);
  }
  fprintf(fp, "Tetraloop Energies: \n");
  for( i = 0; i < 4096; i++) {
    fprintf(fp, "%0.3f\n", tloop_energy[i]);
  }
  fprintf(fp, "Mismatch Hairpin: \n");
  for( i = 0; i < 96; i++) {
    fprintf(fp, "%0.3f\n", MMEnergiesHP[i]);
  }
  fprintf(fp, "Mismatch Interior Loop: \n");
  for( i = 0; i < 96; i++) {
    fprintf(fp, "%0.3f\n", MMEnergiesIL[i]);
  }
  fprintf(fp, "1x1 Interior Loop: \n");
  for( i = 0; i < 16*36; i++) {
    fprintf(fp, "%0.3f\n", IL_SInt2[i]);
  }
  fprintf(fp, "2x2 Interior Loop: \n");
  for( i = 0; i < 256*36; i++) {
    fprintf(fp, "%0.3f\n", IL_SInt4[i]);
  }
  fprintf(fp, "1x2 Interior Loop: \n");
  for( i = 0; i < 64*36; i++) {
    fprintf(fp, "%0.3f\n", IL_AsInt1x2[i]);
  }
  fprintf(fp, "Dangle Energy: \n");
  for( i = 0; i < 48; i++) {
    fprintf(fp, "%0.3f\n", dangle_energy[i]);
  }
  fprintf(fp, "AT PENALTY: \n");
  fprintf(fp, "%0.3f\n", AT_PENALTY);
  fprintf(fp, "POLY C3: \n");
  fprintf(fp, "%0.3f\n", POLYC3);
  fprintf(fp, "POLYC SLOPE: \n");
  fprintf(fp, "%0.3f\n", POLYCSLOPE);
  fprintf(fp, "POLYC INT: \n");
  fprintf(fp, "%0.3f\n", POLYCINT);
  fprintf(fp, "ALPHA 1: \n");
  fprintf(fp, "%0.3f\n", ALPHA_1); 
  fprintf(fp, "ALPHA 2: \n");
  fprintf(fp, "%0.3f\n", ALPHA_2);
  fprintf(fp, "ALPHA 3: \n");
  fprintf(fp, "%0.3f\n", ALPHA_3);
  fprintf(fp, "BETA 1: \n");
  fprintf(fp, "%0.3f\n", BETA_1);
  fprintf(fp, "BETA 2: \n");
  fprintf(fp, "%0.3f\n", BETA_2);
  fprintf(fp, "BETA 3: \n");
  fprintf(fp, "%0.3f\n", BETA_3);
  fprintf(fp, "BETA 1M: \n");
  fprintf(fp, "%0.3f\n", BETA_1M);
  fprintf(fp, "BETA 1P: \n");
  fprintf(fp, "%0.3f\n", BETA_1P);

  fclose( fp);
}

*/
