function dotplot(testcase)
figure(1);
clf;

data = 3;  % 3 = full pairs, 4 = nested pairs only (Pb), 5 = gap
           % pairs only (Pbg)
bins = 2;
scale = 1;  %1: log10, 2: 10 percent
intercept = 5;  % only for log version (scale = 1)--
% bins are intercept*(.1 .01 .001 ...)
 
pairs = load(sprintf('%s',testcase));
 
n = sqrt(length(pairs(:,data)));
pairs = reshape(pairs(:,data),n,n);
   
plot([.5 n+.5],[.5 n+.5],'k-')
axis('square')
axis([.5 n+.5 .5 n+.5])
axis ij
box on
hold;

count = 0;
for row=1:n
  for col=1:row-1
    if (pairs(row,col)>0)
      if scale == 1
	logprob = floor(log10(pairs(row,col))-log10(intercept));
	if logprob >= -bins
	  count = count+1;
	  size = 1 + (1/bins)*(1 + logprob);
	  a = fill([row-size/2 row+size/2 row+size/2 row-size/2 ],...
		   [col-size/2 col-size/2 col+size/2 col+size/2], 'm');
	  set(a,'EdgeColor','m');
	end
      elseif scale==2
	prob = floor(100*pairs(row,col));
	if prob >= (100-10*bins)
	  count = count+1;
	  size = .1 + .01*prob;
	  a = fill([row-size/2 row+size/2 row+size/2 row-size/2 ],...
		   [col-size/2 col-size/2 col+size/2 col+size/2],colstr);
	  set(a,'EdgeColor',colstr);
	end            
      end
    end
  end
end
    
		  
     

