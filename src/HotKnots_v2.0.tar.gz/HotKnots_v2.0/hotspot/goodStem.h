extern void GenerateStemList(int length, char* sequence, char* structure); //This function generates a list of hotspots and stores it in hotspots.

