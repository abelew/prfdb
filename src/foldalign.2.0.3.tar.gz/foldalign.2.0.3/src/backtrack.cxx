#ifndef BACKTRACK
#define BACKTRACK
#include <iostream>
#include <math.h>
#include "helper.cxx"
#include "output.cxx"
#include "fold.cxx"
#include "matrix_D.cxx"
#include "multistacks.cxx"
#include "arguments.cxx"
#include "results.cxx"

/******************************************************************************
*                                                                             *
*   Copyright 2004 - 2005 Jakob Hull Havgaard, hull@bioinf.kvl.dk             *
*                                                                             *
*   This file is part of Foldalign                                            *
*                                                                             *
*   Foldalign is free software; you can redistribute it and/or modify         *
*   it under the terms of the GNU General Public License as published by      *
*   the Free Software Foundation; either version 2 of the License, or         *
*   (at your option) any later version.                                       *
*                                                                             *
*   Foldalign is distributed in the hope that it will be useful,              *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of            *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
*   GNU General Public License for more details.                              *
*                                                                             *
*   You should have received a copy of the GNU General Public License         *
*   along with Foldalign; if not, write to the Free Software                  *
*   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
*                                                                             *
******************************************************************************/


//****************************************************************//
// This class implements a sliding window version of              //
// the FOLDALIGN algorithm.                                       //
// Based on:                                                      //
// Gorodkin et al. Nucleic Acids Reseacrch 1997 25 (18) 3724--32  //
// Implemented by Jakob Hull Havgaard                             //
// 2004 hull@bioinf.kvl.dk                                                    //
//****************************************************************//
class backtrack {
public:
//*************************************
// The constructor intialize the dp matrix,
// the arguments and sequences.

	inline backtrack(sequence* one, sequence* two, arguments& argu, scorematrix<int>& score, matrix_D<int>*& D_mat, matrix_D<char>*& S_mat, matrix_D<short>*& L_mat);

//*************************************
// Tracebacks with the coordinates given in the
// results object. If the current matrix is out
// of range the align function is called with
// the current range. Also outputs the alignment

	inline void traceback(results<int>*& res);

//*************************************
// Nothing special about the destructor

	inline ~backtrack();

private:
//*************************************
// The global variables

	sequence* seq_1; // Stores the sequences
	sequence* seq_2;
	arguments& arg;
	scorematrix<int>& s_matrix; // Contains the score matrixs
	matrix_D<int>* D; // The dynamic programing matrix
	matrix_D<char>* S; // The state matrix
	matrix_D<short>* L; // The state matrix
	int len_1; // The length of the sequences
	int len_2;
	int end_1;
	int end_2;
	int best_score; // The stores the starting point for the
	stack<int>* leftPos_1; // Stacks used during traceback
	stack<int>* leftPos_2;
	stack<int>* leftBasepair_1;
	stack<int>* leftBasepair_2;
	stack<int>* rightPos_1;
	stack<int>* rightPos_2;
	stack<int>* rightBasepair_1;
	stack<int>* rightBasepair_2;
	stack<stack<int>* >* rightStackPos_1; // Stacks for storing traceback stacks
	stack<stack<int>* >* rightStackPos_2;
	stack<stack<int>* >* rightStackBasepair_1;
	stack<stack<int>* >* rightStackBasepair_2;
	int delta; // Parameters
	int lambda;
	int min_loop;
	bool plot_score;
	bool back;
	int chunk_size;
	int gap_bonus;       // Affine gap bonus
	string id;           // Alignment ID
	string score_matrix; // The name of the score_matrix
	bool nobranch;       // Nobranch (true) or branch (false) version
	int mbl;
	int mblAffine;
	int mblNuc;
	static const int big_neg = -114748364; // A large negative number
	bool flip; // Is the order of the sequences switched
	output* out; //Object containing the functions for outputing
	static const int p2calc_size = 70;
	int coord_I[p2calc_size];
	int coord_J[p2calc_size];
	int coord_K[p2calc_size];
	int coord_L[p2calc_size];
	bool branch_left[p2calc_size];
	bool branch_right[p2calc_size];
	std::string state_explain[p2calc_size];
//*****************************************************
// These functions are used during back track         *
//*****************************************************

//*************************************
// Trace_state finds the previous state and position in
// the dynamicprograming matrix

	inline int trace_state(const int score, int pos[], int old_state, multistacks<int, 4>& bstack);	

//*************************************
// These functions are used during traceback to control the branching

	inline void branch_state(const int pos[]);
	inline void end_state();
	inline void branch_info(const int pos[], int& b_count, int& b_current);

//*************************************
// This function is used by minimum stem length function to trace-back negative states
//	inline int localTrace(const int i, const int Wi, const int k, const int Wk);
	inline char trace(const int score, int* pos);
	
//*************************************
// This function is used for backtracking bifurcated loops
	inline int branchCore(const int i, const int Wi, const int k,const int Wk, const int m, const int n);

//*****************************************************
// Small helper functions. Used by other functions    *
//*****************************************************
	inline void print_space(const int number);
	template<class type> inline void init_array(type array[], int size, type val) {for(int i=0; i<size; i++) {array[i] = val;}}
};

#ifdef AARHUS // This piece of code is needed by the Xlc compiler on AIX systems
const int backtrack::big_neg;
#endif /* AARHUS */

//******************************************
// The constructor                         *
//******************************************

inline backtrack::backtrack(sequence* one, sequence* two, arguments& argu, scorematrix<int>& score, matrix_D<int>*& D_mat, matrix_D<char>*& S_mat, matrix_D<short>*& L_mat) : seq_1(one), seq_2(two), arg(argu), s_matrix(score), D(D_mat), S(S_mat), L(L_mat) {
// Initialise objects and variabels

	// From the argument object
	min_loop = arg.intopt("-min_loop")+1;
	delta = arg.intopt("-max_diff");
	lambda = arg.intopt("-max_length");
	chunk_size = arg.intopt("-chunk_size");
	id = arg.stringopt("-ID");
	score_matrix = arg.stringopt("-score_matrix");
	nobranch = arg.boolopt("-nobranch");
	plot_score = arg.boolopt("-plot_score");
	flip = arg.boolopt("switch");
	back = arg.boolopt("-backtrack_info");
	
	// From the score matrix
	mblAffine = 2*s_matrix.getMblAffine();
	mbl = 2*s_matrix.getMbl();
	mblNuc = s_matrix.getMblNuc();
	gap_bonus = s_matrix.getGap();

	out = new output(arg, seq_1, seq_2, s_matrix);

	end_1 = len_1 = seq_1->getLength(); // Store the length of the sequences
	end_2 = len_2 = seq_2->getLength();
	
// These arrays are needed by the quickback function.
// The size array shows have much the length of a loop grows by the state
// The coord array holds the change in coordinates needed by to backtrack
	init_array(coord_I, p2calc_size, 0);
	init_array(coord_J, p2calc_size, 0);
	init_array(coord_K, p2calc_size, 0);
	init_array(coord_L, p2calc_size, 0);

	int index; // index for the size array
// Begin
	index =  0;	index =  9; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 0; coord_L[index] = 0;
	index =  1;	index =  9; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 0; coord_L[index] = 0;
// i,j,k,l
	index =  4; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
	index =  5; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
	index = 21; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
	index = 29; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
	index = 41; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
	index = 49; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
	index = 61; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
	index = 63; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
// i,j
	index = 30; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 0; coord_L[index] = 0;
	index = 32; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 0; coord_L[index] = 0;
// k,l
	index = 31; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 1; coord_L[index] = -2;
	index = 33; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 1; coord_L[index] = -2;
// i,k
	index =  2; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 1; coord_L[index] = -1;
	index = 10; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 1; coord_L[index] = -1;
	index = 26; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 1; coord_L[index] = -1;
	index = 42; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 1; coord_L[index] = -1;
	index = 52; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 1; coord_L[index] = -1;
// j,l
	index =  3; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = -1;
	index = 11; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = -1;
	index = 27; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = -1;
	index = 43; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = -1;
// i
	index =  6; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
	index = 12; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
	index = 22; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
	index = 44; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
	index = 54; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
// j
	index =  7; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
	index = 13; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
	index = 23; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
	index = 45; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
// k
	index =  8; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 1; coord_L[index] = -1;
	index = 14; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 1; coord_L[index] = -1;
	index = 24; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 1; coord_L[index] = -1;
	index = 46; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 1; coord_L[index] = -1;
	index = 56; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 1; coord_L[index] = -1;
// l
	index =  9; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 0; coord_L[index] = -1;
	index = 15; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 0; coord_L[index] = -1;
	index = 25; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 0; coord_L[index] = -1;
	index = 47; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 0; coord_L[index] = -1;

// This array holds an explaination of each state
	std::string error_msg = "Program error. Illegal state.";
	init_array(state_explain, p2calc_size, error_msg);
	state_explain[0] = "Hairpin init state.";
	state_explain[1] = "Hairpin init state.";
	state_explain[2] = "Hairpin align (i,k).";
	state_explain[3] = "Hairpin align (j,l).";
	state_explain[4] = "Hairpin align (i,k) and (j,l). No bp.";
	state_explain[5] = "Hairpin align (i,k) and (j,l). Pot. Bp.";
	state_explain[6] = "Hairpin align (i,-).";
	state_explain[7] = "Hairpin align (j,-).";
	state_explain[8] = "Hairpin align (-,k).";
	state_explain[9] = "Hairpin align (-,l).";
	state_explain[10] = "Internal loop align (i,k). Pot. Bulge.";
	state_explain[11] = "Internal loop align (j,l). Pot. Bulge.";
	state_explain[12] = "Internal loop align (i,-). Pot. Bulge.";
	state_explain[13] = "Internal loop align (j,-). Pot. Bulge.";
	state_explain[14] = "Internal loop align (-,k). Pot. Bulge.";
	state_explain[15] = "Internal loop align (-,l). Pot. Bulge.";
	state_explain[21] = "Internal loop align (i,k) and (j,l).";
	state_explain[22] = "Internal loop align (i,-).";
	state_explain[23] = "Internal loop align (j,-).";
	state_explain[24] = "Internal loop align (-,k).";
	state_explain[25] = "Internal loop align (-,l).";
	state_explain[26] = "Internal loop align (i,k).";
	state_explain[27] = "Internal loop align (j,l).";
	state_explain[29] = "Internal loop align (i,k) and (j,l). Pot. Bp.";
	state_explain[30] = "Insert (i,j,-,-) bp.";
	state_explain[31] = "Insert (-,-,k,l) bp.";
	state_explain[40] = "Branch point";
	state_explain[41] = "Mbl. Align (i,j,k,l).";
	state_explain[42] = "Mbl. Align (i,k).";
	state_explain[43] = "Mbl. Align (j,l).";
	state_explain[44] = "Mbl. Align (i,-).";
	state_explain[45] = "Mbl. Align (j,-).";
	state_explain[46] = "Mbl. Align (-,k).";
	state_explain[47] = "Mbl. Align (-,l).";
	state_explain[49] = "Mbl. Align (i,j,k,l). Pot. closing bp.";
	state_explain[52] = "Mbl. Align (i,k). Can branch again.";
	state_explain[54] = "Mbl. Align (i,-). Can branch again.";
	state_explain[56] = "Mbl. Align (-,k). Can branch again.";
	state_explain[61] = "Pot. bp. closing bulge longer than one nucleotide. Align (i,j,k,l).";
	state_explain[63] = "Basepair align (i,j,k,l).";

// If the sequences are swithch, then some of the explanations must be fliped too
	if (flip) {
		helper::swap(state_explain[6], state_explain[8]);
		helper::swap(state_explain[7], state_explain[9]);
		helper::swap(state_explain[12], state_explain[14]);
		helper::swap(state_explain[13], state_explain[15]);
		helper::swap(state_explain[22], state_explain[24]);
		helper::swap(state_explain[23], state_explain[25]);
		helper::swap(state_explain[30], state_explain[31]);
		helper::swap(state_explain[44], state_explain[46]);
		helper::swap(state_explain[45], state_explain[47]);
		helper::swap(state_explain[54], state_explain[56]);
	}

	

// These two arrays controls which states are allowed to be part of a branch
// point.
// The left side of a branch point can only be a stem (only state 63)
// The right side can be either a stem, a branch point, or an ik bulge and a
// stem (states 10, 12 ,14, 40, 61 and 63)
	init_array(branch_left, p2calc_size, false);
	init_array(branch_right, p2calc_size, false);

	branch_left[63] = true;

	branch_right[10] = true;
	branch_right[12] = true;
	branch_right[14] = true;
	branch_right[40] = true;
	branch_right[52] = true;
	branch_right[54] = true;
	branch_right[56] = true;
	branch_right[63] = true;
}

//*******************************************************
// The functions in this section handels the back track *
//*******************************************************

inline void backtrack::traceback(results<int>*& res) {
// Get the best hit and its position from the result object
	best_score = res->getScore();// best_score holds the score
	int best_pos[4];
	res->getPos(best_pos);
	end_1 = best_pos[1];
	end_2 = best_pos[3];
// Check to see if realignment is nessecary
	if (!arg.boolopt("-global") && ((best_pos[0] < D-> getI()) || (best_pos[0] + best_pos[1] > D->getEndI()) || (best_pos[2] < D->getK()) || (best_pos[2] + best_pos[3] > D->getEndK()))) {
// Get ready for realignment
		bool change_plot = false;
		if (plot_score) {arg.setBool("-plot_score",false); change_plot = true;}
		std::cout << "; REALIGNING          (" << best_pos[0] << " " << (best_pos[0]+best_pos[1]) << ", " << best_pos[2] << " " << best_pos[2]+best_pos[3] << ")" << endl;
		D->setEndI(best_pos[0]+best_pos[1]);
		D->setEndK(best_pos[2]+best_pos[3]);
		D->setStartK(best_pos[2]);
		S->setEndI(best_pos[0]+best_pos[1]);
		S->setEndK(best_pos[2]+best_pos[3]);
		S->setStartK(best_pos[2]);
		arg.setBool("realigning", true);
		results<int>* r = new results<int>();
		fold align(seq_1, seq_2, arg, s_matrix, D, S, L); // The fold object.
		align.run_align(best_pos[0], best_pos[0]+best_pos[1], best_pos[2], best_pos[2]+best_pos[3], r);
/*		if (r->getScore() != best_score) {
// Check the score. It must be the same!
			cerr << "Program error. Realignment scoring problem. New score = " << r->getScore() << " Old score = " << best_score << " Coords (" << best_pos[0] << ", " << best_pos[0]+best_pos[1] << "), (" << best_pos[2] << ", " << best_pos[2]+best_pos[3] << ")" << endl;
			delete r;
			throw -1;
		}*/
		delete r;
		best_score = res->getScore();
		res->getPos(best_pos);
		if (change_plot) {arg.setBool("-plot_score", true); plot_score = true;}
	}
// The stacks used for backtracking
	multistacks<int, 4> bstack((len_1+len_2)); //Stacks for storing the right part of a branch point
	int stack_size_1 = 2*(len_1+1);
	int stack_size_2 = 2*(len_1+1);
	int align_start_1 = best_pos[0];
	int align_start_2 = best_pos[2];
	int align_len_1 = best_pos[1];
	int align_len_2 = best_pos[3];
	int align_score = best_score;
	leftPos_1 = new stack<int>(stack_size_1);
	leftPos_2 = new stack<int>(stack_size_2);
	leftBasepair_1 = new stack<int>(stack_size_1);
	leftBasepair_2 = new stack<int>(stack_size_2);
	rightPos_1 = new stack<int>(stack_size_1);
	rightPos_2 = new stack<int>(stack_size_2);
	rightBasepair_1 = new stack<int>(stack_size_1);
	rightBasepair_2 = new stack<int>(stack_size_2);
	rightStackPos_1 = new stack<stack<int>* >(stack_size_1);
	rightStackPos_2 = new stack<stack<int>* >(stack_size_2);
	rightStackBasepair_1 = new stack<stack<int>* >(stack_size_1);
	rightStackBasepair_2 = new stack<stack<int>* >(stack_size_2);
	rightStackPos_1->push(rightPos_1);
	rightStackPos_2->push(rightPos_2);
	rightStackBasepair_1->push(rightBasepair_1);
	rightStackBasepair_2->push(rightBasepair_2);
	int b_count=0; // Counts the number of branch points. Not used by the algorithm. Output only
	int b_current=0; // Another output only variable. Keeping the number of current branch points
// trace_state back-tracks one step.
	if (back) {
// Outputs backtrack information if wanted
		branch_info(best_pos, b_count, b_current);
	}
	int branch = trace_state(best_score, best_pos, 0, bstack);
	while (true) { // Keep going
// check for branch point
		if (branch != 40) {
// This is not a branch point.
			if ((branch == 0) || (branch == 1)) {
// This is an end point
				end_state();
// There are two kinds of end points. Those that ends a substructure
// and those that ends the trace-back
				if (back) {
// Outputs backtrack information if wanted
					if (b_current > 0) {
						std::cout << "; BACKTRACK";
						helper::print_space(11);
						std::cout << "Branch end" << endl;
						b_current--;
					}
				}
				if (bstack.getsize() == 0) { // If the state is zero and the branch stack is empty it is time to go home
					break; // Its all over. Break out of the while(true) loop so the program terminates
				}
				else { // Get the next right branch
// There is still at least one right side of a branch point left
// Get the coordinates from bstack
					bstack.pop(best_pos);
				}
			}
			if (back) {
// Outputs backtrack information if wanted
				branch_info(best_pos, b_count,b_current);
			}
		}
		else {
// Branch point handling
			if (back) {
// Outputs backtrack information if wanted
				branch_info(best_pos, b_count,b_current);
			}
// Store the right side stacks and get the new right side stacks ready
			branch_state(best_pos);
		}
// Get the score
		best_score = D->getD(best_pos[0], best_pos[1], best_pos[2], best_pos[3]);
		if ((branch == 30) || (branch== 31) || (branch== 32) || (branch== 33)) {branch=63;}
// Do the back-track
		branch = trace_state(best_score, best_pos, branch, bstack);
	}
//	delete[] best_pos;
// The printing of the output is handled by the foldout function of the output class
	out->foldout(leftPos_1, leftBasepair_1, leftPos_2, leftBasepair_2,align_start_1, align_len_1, align_start_2, align_len_2, align_score);
// Clean up
	delete leftPos_1;
	delete leftPos_2;
	delete leftBasepair_1;
	delete leftBasepair_2;
	delete rightStackPos_1;
	delete rightStackPos_2;
	delete rightStackBasepair_1;
	delete rightStackBasepair_2;
}

inline void backtrack::branch_info(const int pos[], int& b_count, int& b_current) {
	int gotHere = S->getD(pos[0],pos[1],pos[2],pos[3]);
	int score = D->getD(pos[0],pos[1],pos[2],pos[3]);
	std::cout << "; BACKTRACK";
	helper::print_space(11);
	if (!flip) {
		std::cout << score  << " ("<< pos[0] <<" "<< (pos[0]+pos[1]) <<","<<pos[2] <<" "<<(pos[2]+pos[3])<<") "<< gotHere << " " << state_explain[gotHere] << endl;
	}
	else {
		std::cout << score  << " ("<< pos[2] <<" "<< (pos[2]+pos[3]) <<","<<pos[0] <<" "<<(pos[0]+pos[1])<<") "<< gotHere << " " << state_explain[gotHere] <<endl;
	}
	if (gotHere == 40) {
		b_count++;
		b_current+=2;
		std::cout << "; BACKTRACK";
		helper::print_space(11);
		std::cout << "Branch start " << b_count << endl;
	}
}

//**********************************************************
// The back-track helper functions                         *
//**********************************************************

inline void backtrack::branch_state(const int pos[]) {
// The branch_state function stores the right side stacks on
// the stack of stacks,
// and makes a new set of right side stacks ready

// Store the right stacks in a stack of stacks
	rightStackPos_1->push(rightPos_1);
	rightStackPos_2->push(rightPos_2);
	rightStackBasepair_1->push(rightBasepair_1);
	rightStackBasepair_2->push(rightBasepair_2);
// Make new stacks
	int size = 2*(pos[1]+pos[3])+2;
	rightPos_1 = new stack<int>(size);
	rightPos_2 = new stack<int>(size);
	rightBasepair_1 = new stack<int>(size);
	rightBasepair_2 = new stack<int>(size);
}

	
inline void backtrack::end_state() {
// The end_state function empties the content of the right stacks into
// the coresponding left stack. Then the right side stacks are deleted'
// and the next set of right side stacks are poped from the stacks of stacks.

// Empty the right stacks
	while(rightPos_1->getsize() > 0) {
		leftPos_1->push(rightPos_1->pop());
		leftPos_2->push(rightPos_2->pop());
		leftBasepair_1->push(rightBasepair_1->pop());
		leftBasepair_2->push(rightBasepair_2->pop());
	}
// Delete the right stacks
	delete rightPos_1;
	delete rightPos_2;
	delete rightBasepair_1;
	delete rightBasepair_2;
// Get the next right stacks from the stacks of stacks
	rightPos_1 = rightStackPos_1->pop();
	rightPos_2 = rightStackPos_2->pop();
	rightBasepair_1 = rightStackBasepair_1->pop();
	rightBasepair_2 = rightStackBasepair_2->pop();
}


inline int backtrack::trace_state(const int score, int pos[], int old_state, multistacks<int, 4>& bstack) { // Calculates the previous position for the traceback
	int i = pos[0];
	int Wi = pos[1];
	int k = pos[2];
	int Wk = pos[3];
	int ii=i, Wii=Wi, kk=k, Wkk=Wk; // More indicies to use
	if ((Wi == 0) && (Wk == 0)) { // Handle the null state/end state
		helper::assign(pos, i, Wi, k, Wk);
		leftPos_1->push(i);
		leftPos_2->push(k);
		leftBasepair_2->push(-1);
		leftBasepair_1->push(-1);
		return 0;
	}
	const char state = S->getD(i, Wi, k, Wk);
	switch (state) {
		case 0:
std::cerr << "Program error. Warning state 0 found" << std::endl;
			helper::assign(pos, i, Wi, k, Wk);
			leftPos_1->push(i);
			leftPos_2->push(k);
			leftBasepair_2->push(-1);
			leftBasepair_1->push(-1);
			return 0;
		
		case 1: // Align both ends. With a base-pair
std::cerr << "Program error. State == 1 found in backtrack something wrong" << std::endl;
throw;
		case 5: // Align both ends. With a base-pair
		case 29:
		case 49:
		case 61:
			ii = i+1; Wii = Wi-2; kk=k+1; Wkk=Wk-2; // The new indicies
			helper::assign(pos, ii, Wii, kk, Wkk);
			leftPos_1->push(i);
			rightPos_1->push(i+Wi);
			leftPos_2->push(k);
			rightPos_2->push(k+Wk);
			if (old_state == 63) {
				leftBasepair_2->push(k+Wk);
				rightBasepair_2->push(k);
				leftBasepair_1->push(i+Wi);
				rightBasepair_1->push(i);
			}
			else {
				leftBasepair_2->push(-1);
				rightBasepair_2->push(-1);
				leftBasepair_1->push(-1);
				rightBasepair_1->push(-1);
			}
			
			return state;
		case 63: // Align both ends. With a base-pair
			ii = i+1; Wii = Wi-2; kk=k+1; Wkk=Wk-2; // The new indicies
			helper::assign(pos, ii, Wii, kk, Wkk);
			leftPos_1->push(i);
			leftBasepair_2->push(k+Wk);
			rightBasepair_2->push(k);
			rightPos_1->push(i+Wi);
			leftPos_2->push(k);
			rightPos_2->push(k+Wk);
			leftBasepair_1->push(i+Wi);
			rightBasepair_1->push(i);
			return state;
		case 30: // Align both ends. With a potential base-pair in the I sequence
		case 32:
			ii = i+1; Wii = Wi-2; kk=k; Wkk=Wk; // The new indicies
			helper::assign(pos, ii, Wii, kk, Wkk);
			leftPos_1->push(i);
			rightPos_1->push(i+Wi);
			leftPos_2->push(0);
			rightPos_2->push(0);
			if (old_state == 63) {
				leftBasepair_2->push(-1);
				rightBasepair_2->push(-1);
				leftBasepair_1->push(i+Wi);
				rightBasepair_1->push(i);
			}
			else {
				leftBasepair_2->push(-1);
				rightBasepair_2->push(-1);
				leftBasepair_1->push(-1);
				rightBasepair_1->push(-1);
			}
			
			return state;
		case 31: // Align both ends. With a potential base-pair in the I sequence
		case 33:
			ii = i; Wii = Wi; kk=k+1; Wkk=Wk-2; // The new indicies
			helper::assign(pos, ii, Wii, kk, Wkk);
			leftPos_1->push(0);
			rightPos_1->push(0);
			leftPos_2->push(k);
			rightPos_2->push(k+Wk);
			if (old_state == 63) {
				leftBasepair_2->push(k+Wk);
				rightBasepair_2->push(k);
				leftBasepair_1->push(-1);
				rightBasepair_1->push(-1);
			}
			else {
				leftBasepair_2->push(-1);
				rightBasepair_2->push(-1);
				leftBasepair_1->push(-1);
				rightBasepair_1->push(-1);
			}
			
			return state;
		case 4: // Align both ends. Without basepair
		case 21:
		case 41:
			ii = i+1; Wii = Wi-2; kk=k+1; Wkk=Wk-2; // The new indicies
			helper::assign(pos, ii, Wii, kk, Wkk);
			leftPos_1->push(i);
			leftBasepair_2->push(-1);
			rightBasepair_2->push(-1);
			rightPos_1->push(i+Wi);
			leftPos_2->push(k);
			rightPos_2->push(k+Wk);
			leftBasepair_1->push(-1);
			rightBasepair_1->push(-1);
			return state;
		case 2: // Align i and k
		case 10: // Align i and k
		case 26: // Align i and k
		case 42:
		case 52:
			ii = i+1; Wii = Wi-1; kk=k+1; Wkk=Wk-1; // The new indicies
			helper::assign(pos, ii, Wii, kk, Wkk);
			leftPos_1->push(i);
			leftPos_2->push(k);
			leftBasepair_1->push(-1);
			leftBasepair_2->push(-1);
			return state;
		case 3: // Align j and l
		case 11: // Align j and l
		case 27: // Align j and l
		case 43:
			ii = i; Wii = Wi-1; kk=k; Wkk=Wk-1; // The new indicies
			helper::assign(pos, ii, Wii, kk, Wkk);
			rightPos_1->push(i+Wi);
			rightPos_2->push(k+Wk);
			rightBasepair_1->push(-1);
			rightBasepair_2->push(-1);
			return state;
		case 6: // Align i gap
		case 12: // Align i gap
		case 22: // Align i gap
		case 44: // Align i gap
		case 54: // Align i gap
			ii = i+1; Wii = Wi-1; kk=k; Wkk=Wk; // The new indicies
			helper::assign(pos, ii, Wii, kk, Wkk);
			leftPos_1->push(i);
			leftPos_2->push(0);
			leftBasepair_1->push(-1);
			leftBasepair_2->push(-1);
			return state;
		case 7: // Align j gap
		case 13: // Align j gap
		case 23: // Align j gap
		case 45: // Align j gap
			ii = i; Wii = Wi-1; kk=k; Wkk=Wk; // The new indicies
			helper::assign(pos, ii, Wii, kk, Wkk);
			rightPos_1->push(i+Wi);
			rightPos_2->push(0);
			rightBasepair_1->push(-1);
			rightBasepair_2->push(-1);
			return state;
		case 8: // Align k gap
		case 14: // Align k gap
		case 24: // Align k gap
		case 46: // Align k gap
		case 56: // Align k gap
			ii = i; Wii = Wi; kk=k+1; Wkk=Wk-1; // The new indicies
			helper::assign(pos, ii, Wii, kk, Wkk);
			leftPos_1->push(0);
			leftPos_2->push(k);
			leftBasepair_1->push(-1);
			leftBasepair_2->push(-1);
			return state;
		case 9: // Align l gap
		case 15: // Align l gap
		case 25: // Align l gap
		case 47: // Align l gap
			ii = i; Wii = Wi; kk=k; Wkk=Wk-1; // The new indicies
			helper::assign(pos, ii, Wii, kk, Wkk);
			rightPos_1->push(0);
			rightPos_2->push(k+Wk);
			rightBasepair_1->push(-1);
			rightBasepair_2->push(-1);
			return state;
		case 40: // Branching
			if (nobranch) {
				cerr << "Program error. Branch point found in nobranch run. Program error" << endl;
				throw -1;
			}
			{ // Keeps the following delarations within a separate scope
				// Most of the code in this part of the function is the same and
				// should be the same as that in the fold::branch function.
				const int size_diff = Wk - Wi;
				int bottom = size_diff;
				int top = 0;
				if (size_diff <= 0) {
					bottom = 0;
					top = size_diff;
				}
				// The minimum length of a branch is min_loop plus two base-pairs
				const int min = min_loop +3;
				const int nuc_i = seq_1->getPos(i);
				for(int m = min; m < Wi-min+1; m++) { // For all positions between i and j
					if (!s_matrix.getBasepair(nuc_i,seq_1->getPos(i+m))) {continue;}
					int n_start = (((m-delta+bottom)>min) ? (m-delta+bottom) : min);
					int n_stop  = (((m+delta+top)<(Wk-min)) ? (m+delta+top) : (Wk-min));
					for(int n = n_start; n < n_stop+1; n++) {// For all positions between k and l
						if (!(branch_left[S->getD(i,m,k,n)] && branch_right[S->getD((i+m+1),(Wi-m-1),(k+n+1),(Wk-n-1))])) {continue;}
						int res = branchCore(i, Wi, k, Wk, m, n);
						if (res == score) { // Is it better ?
							if (back) {
								// Outputs backtrack information if wanted
								if (!flip) {
									std::cout << "; BACKTRACK";
									helper::print_space(11);
									std::cout << "Left  branch " << D->getD(i,m,k,n) << " (" << i << " " << i+m << "," << k << " " << k+ n << ")" << endl;
									std::cout << "; BACKTRACK";
									helper::print_space(11);
									std::cout << "Right branch " << D->getD((i+m+1),(Wi-m-1),(k+n+1),(Wk-n-1)) << " (" << i+m+1 << " " << i+Wi << "," << k+n+1 << " " << k+Wk << ")" << endl;
								}
								else {
									std::cout << "; BACKTRACK";
									helper::print_space(11);
									std::cout << "Left  branch " << D->getD((i+m+1),(Wi-m-1),(k+n+1),(Wk-n-1)) << " (" << i+m+1 << " " << i+Wi << "," << k+n+1 << " " << k+Wk << ")" << endl;
									std::cout << "; BACKTRACK";
									helper::print_space(11);
									std::cout << "Right branch " << D->getD(i,m,k,n) << " (" << i << " " << i+m << "," << k << " " << k+ n << ")" << endl;
								}
							}
							helper::assign(pos, i, m, k, n);
							int* store = new int[4];
							helper::assign(store, i+m+1, Wi-m-1, k+n+1, Wk-n-1);
							bstack.push(store);
							delete[] store;
							return state;
						}
					}
				}
				std::cerr << "Program error. Branch state not found (" << i << "," << (i+Wi) << ") (" << k << "," << (k+Wk) << ") score " << score <<endl;
				throw -1;
			}
		default: // Should not be possible.
			int dummy = state;
			std::cerr << "Program error. Unknown state " << dummy << " (" << i << "," << Wi<<") ("<<k<<","<<Wk<<")"<<endl;
			throw -1;
	}
}


inline int backtrack::branchCore(const int i, const int Wi, const int k,const int Wk, const int m, const int n) {// Calculate the D and the state
	// BranchCore calculates the score of a branch point

	// The following variables holds the coordinates of the right part of
	// branch point
	int pi=i+m+1;
	int pj=Wi-m-1;
	int pk=k+n+1;
	int pl=Wk-n-1;
	// The state of the right part of the branch point
	char rs = S->getD_us(pi,pj,pk,pl);

	// A backtrack on the right side of the branch point is performed to
	// find the end stem or branch point coordinates
	while((rs != 63) && (rs != 40)) {
		// Using the L matrix should speed up the backtrack
		short len = 1;
		// Update the coordinates
		pi = pi + len*coord_I[rs];
		pj = pj + len*coord_J[rs];
		pk = pk + len*coord_K[rs];
		pl = pl + len*coord_L[rs];
		// Get the new state
		rs = S->getD(pi, pj, pk, pl);
	}

	// The length of the two single strand regions between the two mbl
	// stems
	const int singleLengthI = pi-i-m-1;
	const int singleLengthK = pk-k-n-1;
	// Calculate the score of the branch site
	// Add the score for the two substructures
	int res = D->getD_us(i,m,k,n);
	res+= D->getD_us((i+m+1),(Wi-m-1),(k+n+1),(Wk-n-1));
	// Add the loop close cost for non GC base-pairs on the left stem
	res+= s_matrix.getNonGCEnd(seq_1->getPos(i), seq_1->getPos(i+m), seq_2->getPos(k), seq_2->getPos(k+n));
	// Handle dangles between the two stems
	int d5 = s_matrix.getDangle5(seq_1->getPos(pi), seq_1->getPos(pi+pj), seq_1->getPos(pi-1), seq_2->getPos(pk), seq_2->getPos(pk+pl), seq_2->getPos(pk-1));
	int d3 = s_matrix.getDangle3(seq_1->getPos(i), seq_1->getPos(i+m), seq_1->getPos(i+m+1), seq_2->getPos(k), seq_2->getPos(k+n), seq_2->getPos(k+n+1));
	res+=mblAffine;
	if (rs == 63) {
		// Since the state is the stem state and not a branch state
		// the mbl cost has to be mbl and not mbl affine
		// Add the loop close cost for non GC base-pairs on the right stem
		res+= s_matrix.getNonGCEnd(seq_1->getPos(pi), seq_1->getPos(pi+pj), seq_2->getPos(pk), seq_2->getPos(pk+pl));
		// Add the score for the single nucleotide regions
		res+= singleLengthI*mblNuc;
		res+= singleLengthK*mblNuc;
		// Remove the internal loop length cost
		// It has to be the internal loop length cost eventhough the state is a
		// bulge state because branch states are treated like internal
		// loops until they closed by a basepair
		res-=s_matrix.getIntLoopLength(singleLengthI,0)+s_matrix.getIntLoopLength(singleLengthK,0);
		// The internal loop opening cost has to be removed if the two
		// stems are seperated by any nucleotides
		if (S->getD_us((i+m+1),(Wi-m-1),(k+n+1),(Wk-n-1)) != 63) {
			if (((pi+pj+1) <= len_1) && ((pk+pl+1) <= len_2)) {
				res-=s_matrix.getIntLoopOpen(seq_1->getPos(pi),seq_1->getPos(pi+pj),seq_1->getPos(pi-1),seq_1->getPos(pi+pj+1),seq_2->getPos(pk),seq_2->getPos(pk+pl),seq_2->getPos(pk-1),seq_2->getPos(pk+pl+1));
			}
		}
		// Handle the dangles
		// if the distance between the stems is one 
		// nucleotide in atleast one sequence only one dangle is added
		// if its longer both dangles are added
		if (((singleLengthI == 1) && (singleLengthK >= 1)) || ((singleLengthI >= 1) && (singleLengthK == 1))) {
			// In this case only one dangle is allowed
			if (d3 > d5) {res+=d3;}
			else {res+=d5;}
		}
		else if ((singleLengthI > 1) && (singleLengthK > 1)) {
			//add both dangles
			res+=d5+d3;
		}
	}
	else {
		// Handle the stem branchpoint case
		// Add the affine multibranch cost
		// Handle the dangles dependend on the distance between the
		// branch points
		if ((singleLengthI == 0) || (singleLengthK == 0)) {
			// There is no 5 dangle base stacking and the bonus is subtracted
			res-=d5;
		}
		else if (((singleLengthI == 1) && (singleLengthK >= 1)) || ((singleLengthI >= 1) && (singleLengthK == 1))) {
			// In this case only the best dangle is allowed
			if (d3 > d5) {
				res-=d5;
				res+=d3;
			}
		}
		if ((singleLengthI > 1) && (singleLengthK > 1)) {
			// The d5 dangle has already been added
			res+=d3;

		}
	}
	// Add the outside dangles if possible
	int dang5 = 0;
	int dang3 = 0;
	if ((i>1) && (k>1)) {
		// 5'
		dang5 = s_matrix.getDangle5(seq_1->getPos(i), seq_1->getPos(i+m), seq_1->getPos(i-1), seq_2->getPos(k), seq_2->getPos(k+n), seq_2->getPos(k-1));
		res+=dang5;
	}
	// The length of sequence is used to avoid the the confinements of a hit
	// disturbs the score
	if (((pi+pj+1) <= len_1) && ((pk+pl+1) <= len_2)) {
		// 3'  
		dang3 = s_matrix.getDangle3(seq_1->getPos(pi), seq_1->getPos(pi+pj), seq_1->getPos(pi+pj+1), seq_2->getPos(pk), seq_2->getPos(pk+pl), seq_2->getPos(pk+pl+1));
		res+=dang3;
	}
	return res;
}

//**********************************************************
// The destructor                                          *
//**********************************************************

inline backtrack::~backtrack() {
	delete out;
}
#endif /*BACKTRACK*/
