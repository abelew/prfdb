#ifndef SCOREMATRIX
#define SCOREMATRIX
#include <string>
#include <fstream>
#include <iostream>
#include <math.h>
#include "helper.cxx"

/******************************************************************************
*                                                                             *
*   Copyright 2004 - 2005 Jakob Hull Havgaard, hull@bioinf.kvl.dk             *
*                                                                             *
*   This file is part of Foldalign                                            *
*                                                                             *
*   Foldalign is free software; you can redistribute it and/or modify         *
*   it under the terms of the GNU General Public License as published by      *
*   the Free Software Foundation; either version 2 of the License, or         *
*   (at your option) any later version.                                       *
*                                                                             *
*   Foldalign is distributed in the hope that it will be useful,              *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of            *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
*   GNU General Public License for more details.                              *
*                                                                             *
*   You should have received a copy of the GNU General Public License         *
*   along with Foldalign; if not, write to the Free Software                  *
*   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
*                                                                             *
******************************************************************************/

//*********************************************************
// This class holds the scoremtricies needed by foldalign *
//                                                        *
// The class do not function as a template since the atoi *
// function is used to translate the values in functions  *
// setMatrix4, getValue, and setInitMatrix                *
//*********************************************************

using namespace std;

template<class type> class scorematrix {
public:
//*******************************
// The class has 4 constructors.
// a default which sets up the default values
// one which updates the default values with those read from a file
// the last two are the assignment and copy constructors

// A default constructor
	scorematrix() {score_matrix();};
// One that reads all or some of the matrices from a file
	scorematrix(std::string& filename);
// and an assignment constructor
	scorematrix& operator=(const scorematrix& s);
// The copy constructor
	scorematrix(const scorematrix& s);
//*******************************
// Functions for accessing the information

// The stacking bonus
	type getStack(const int i, const int j, const int ii, const int jj,const int k, const int l, const int kk, const int ll) const {return (stack_matrix[i][j][ii][jj] + stack_matrix[k][l][kk][ll]);};
// The affine gap penalty
	type getGap() const {return elongation;};
// The cost of aligning
	type getScore(int i, int j, int k, int l) const {return s_matrix[i][j][k][l];};
// The name of the matrix: default or filename
	std::string getName() const {return matrixname;};
// The cost of initial alignment
	type getInit(int i, int k) const {return i_matrix[i][k];};
// True if the bases basepairs
	bool getBasepair(int i, int k) const {return basepair[i][k];};
// The size of the alfabet
	int alfaSize() const {return alfa_size;};
// The letter at position pos in the alfabet
	char getLetter(int pos) const {return alfabet[pos];};
// The alfabet position of the letter letter
	inline int alfa(char letter) const;
// Returns the multibranch loop opening score
	type getMbl() const {return mbl;}
// Returns the affine multibranch loop cost
	type getMblAffine() const {return mblAffine;}
// Returns the cost for adding a nucleotide to a mbl
	type getMblNuc() const {return mblNuc;}
// Returns a value from the 5' dangle matrix (dangle5)
	type getDangle5(const int i, const int j, const int ii, const int k, const int l, const int kk) {return dangle5[i][j][ii] + dangle5[k][l][kk];}
// Returns a value from the 3' dangle matrix (dangle3)
	type getDangle3(const int i, const int j, const int ii, const int k, const int l, const int kk) {return dangle3[i][j][ii] + dangle3[k][l][kk];}
// Returns the endNonGC value
	type getNonGCEnd(const int i, const int j, const int k, const int l) {return endNonGC[i][j] + endNonGC[k][l];}
	type getNonGCEnd(const int i, const int j) {return endNonGC[i][j];}
// These functions are for handling the loop close scores
	type getHpClose(const int i, const int j, const int ii, const int jj,const int k, const int l, const int kk, const int ll) const {return hp_close_matrix[i][j][ii][jj]+hp_close_matrix[k][l][kk][ll];}
	type getIntLoopOpen(const int i, const int j, const int ii, const int jj,const int k, const int l, const int kk, const int ll) const {return internal_loop_matrix[i][j][ii][jj]+internal_loop_matrix[k][l][kk][ll];}
	type getIntLoopClose(const int i, const int j, const int ii, const int jj,const int k, const int l, const int kk, const int ll) const {return internal_loop_matrix[i][j][ii][jj]+internal_loop_matrix[k][l][kk][ll];}
	type getHpLength(const int i, const int j);
	type getIntLoopLength(const int i, const int j);
	type getBulgeLength(const int i, const int j);
	inline void checkSize(const int size);
// The destructor. Nothing fancy
	~scorematrix();
private:
	type**** s_matrix;  // The scorematrix
	type**** stack_matrix;  // The stacking matrix
	type**** hp_close_matrix;  // The hair-pin open matrix
	type**** internal_loop_matrix;  // The internal loop open/close matrix
	type*** dangle5;  // The 5' dangle matrix
	type*** dangle3;  // The 3' dangle matrix
	type** i_matrix;    // The scorematrix for initial alignment
	type** endNonGC;	// The extra cost for terminal non GC base-pair. Zero for GC-pairs.
	bool** basepair;   // The basepairing matrix
	char* alfabet;     // The alfabet
	type* hpLength;		 // The hairpin loop length cost
	type* bulgeLength; // The bulge loop length cost
	type* ilLength;    // The internal loop length cost
	int alfa_size;     // The size of the alfabet
	int tmp_alfa_size; // A tmp variable alfa_size. Used when the size of the matrices is changed
	bool alfadie;      // Used to make sure the matricies in a file is ordered correctly
	std::string matrixname; // Default or filename
	type gap_open;      // The gap open score
	type elongation;    // The gap elongation score
	int loopTableLength; // The length of the loop cost table
	type ilLong;         // The scale factor for long internal loops
	type bulgeLong;      // The scale factor for long bulge loops
	type hpLong;         // The scale factor for long hairpin loops
	type asym;				// The per base cost for asymetric internal loops
	type masym;				// The per base cost for asymetric internal loops
	type mbl;				// Multibranchloop opening cost
	type mblAffine;	   // The affine multibranch cost
	type mblNuc;         // The cost of adding a nucleotide to the mbl
	inline void setAlfabet(std::ifstream& file);     // Read a new alfabet from file
	inline void setBasepair(std::ifstream& file);    // Read a new basepairings matrix from file
	inline void setInitMatrix(std::ifstream& file); // Read a new init matrix from file
	inline void setLoopTable(std::ifstream&file);    // Read a new loop cost table
	inline void setMisc(std::ifstream& file);        // Read the misc values
	inline void store(std::string name, type value);        // A helper function to setMisc
	inline void score_matrix();   // Set up the default matrix
	inline void get_line(std::ifstream& file, std::string& line); // Read a line ignoring comments
	inline void setMatrix4(std::ifstream& file, type****& matrix); // Read a 4x4x4x4 matrix and store it
	inline void setMatrix3(std::ifstream& file, type***& matrix); // Read a 4x4x4 matrix and store it
	inline void parseLine(std::string line, int*& i_letters, int& len); // Parse a annotation line
	inline type getValue(int& prev, std::string& line); // Extract a value from a line
	template<class local_type> inline void makeMatrix4(local_type****& matrix, const int size); // Copy a 4-dimensional matrix
	template<class local_type> inline void deleteMatrix4(local_type****& matrix, const int size); // Delete a 4-dimensional matrix
	template<class local_type> inline void copyMatrix4(local_type****& matrix, local_type**** const& old_matrix, const int size);
	template<class local_type> inline void assignMatrix4(local_type****& matrix, const int size, const int value); // assigns value to all positions in the 4-dimensional matrix
	template<class local_type> inline void makeMatrix3(local_type***& matrix, const int size); // Copy a 3-dimensional matrix
	template<class local_type> inline void deleteMatrix3(local_type***& matrix, const int size); // Delete a 3-dimensional matrix
	template<class local_type> inline void copyMatrix3(local_type***& matrix, local_type*** const& old_matrix, const int size);
	template<class local_type> inline void assignMatrix3(local_type***& matrix, const int size, const int value); // assigns value to all positions in the 4-dimensional matrix
	template<class local_type> inline void makeMatrix2(local_type**& matrix, const int size); // Copy a 2-dimensional matrix
	template<class local_type> inline void deleteMatrix2(local_type**& matrix, const int size); // Delete a 2-dimensional matrix
	template<class local_type> inline void copyMatrix2(local_type**& matrix, local_type** const& old_matrix, const int size);
	template<class local_type> inline void assignMatrix2(local_type**& matrix, const int size, const int value); // assigns value to all positions in the 4-dimensional matrix
	template<class local_type> inline void copyArray(local_type*& matrix, local_type* const& old_matrix, const int size);
	template<class local_type> inline void assignArray(local_type*& matrix, const local_type value, const int size);
	inline void calcScore(const int factor, const int size, type*& array);
	inline std::string findName(int& prev, std::string& line);
	inline void setGap4(type****& matrix);
	inline void setGap3(type***& matrix);
	inline void dumpArray(const type* array);
};

//********************************************
// Read a scorematrix file

template<class type> inline scorematrix<type>::scorematrix(std::string& filename) {
	score_matrix();
	matrixname = filename;
	std::string line;
	std::ifstream file;
	file.open(filename.c_str(),ios::in);
	if (file.fail()) {
	std::cerr << "It is not possible to open the scorematrix file " << filename << "\n";
		throw -1;
	}
	get_line(file,line);
	while (!file.fail()) {
		if (!line.compare("Alfabet:")) {setAlfabet(file);}
		else if (!line.compare("Base-pair:")) {setBasepair(file);}
		else if (!line.compare("Base-pair substitution:")) {setMatrix4(file, s_matrix);}
		else if (!line.compare("Single strand substitution:")) {setInitMatrix(file);}
		else if (!line.compare("Stacking:")) {setMatrix4(file, stack_matrix);}
		else if (!line.compare("Hairpin Close:")) {setMatrix4(file, hp_close_matrix);}
		else if (!line.compare("Internal loop:")) {setMatrix4(file, internal_loop_matrix);}
		else if (!line.compare("5' Dangle:")) {setMatrix3(file, dangle5);}
		else if (!line.compare("3' Dangle:")) {setMatrix3(file, dangle3);}
		else if (!line.compare("Loop length costs:")) {setLoopTable(file);}
		else if (!line.compare("Miscellaneous:")) {setMisc(file);}
		else if (!line.compare("")) {}
		else {std::cerr << "The score matrix do not have the right format\n" << line << std::endl; throw -1;}
		get_line(file,line);
	}
	file.close();
	alfa_size = tmp_alfa_size;
// Setup the gap opening cost
	for(int i=0; i<alfa_size; i++) {
		i_matrix[i][0] = gap_open;
		i_matrix[0][i] = gap_open;
	}
	i_matrix[0][0] = 0;
	setGap4(s_matrix);
	setGap4(stack_matrix);
	setGap4(hp_close_matrix);
	setGap4(internal_loop_matrix);
	setGap3(dangle5);
	setGap3(dangle3);
}

template<class type> inline void scorematrix<type>::setGap4(type****& matrix) {
	for(int i=0; i<alfa_size; i++) {
		for(int j=0; j<alfa_size; j++) {
			for(int k=0; k<alfa_size; k++) {
				for(int l=0; l<alfa_size; l++) {
					if ((i==0) || (j==0) || (k==0) || (l==0)) {
						matrix[i][j][k][l] = i_matrix[i][j] + i_matrix[k][l];
					}
				}
			}
		}
	}
}

template<class type> inline void scorematrix<type>::setGap3(type***& matrix) {
	for(int i=0; i<alfa_size; i++) {
		for(int j=0; j<alfa_size; j++) {
			for(int k=0; k<alfa_size; k++) {
				if ((i==0) || (j==0) || (k==0)) {
					matrix[i][j][k] = 0;
				}
			}
		}
	}
}

//*********************************************
// Assignment operator for the scorematrix object

template<class type> inline scorematrix<type>& scorematrix<type>::operator=(const scorematrix& s) {
	if (this != &s) {
		int i_size=alfaSize();
		int as = s.alfaSize();
		deleteMatrix4(s_matrix, i_size);
		deleteMatrix4(stack_matrix, i_size);
		deleteMatrix4(internal_loop_matrix, as);
		deleteMatrix4(hp_close_matrix, as);
		deleteMatrix3(dangle5, i_size);
		deleteMatrix3(dangle3, i_size);
		deleteMatrix2(i_matrix, i_size);
		deleteMatrix2(basepair, i_size);
		deleteMatrix2(endNonGC, i_size);
		delete[] alfabet;
		delete[] hpLength;
		delete[] bulgeLength;
		delete[] ilLength;
		loopTableLength = s.loopTableLength;
		hpLong = s.hpLong;
		bulgeLong = s.bulgeLong;
		ilLong = s.ilLong;
		asym = s.asym;
		masym = s.masym;
		mbl = s.mbl;
		mblAffine = s.mblAffine;
		mblNuc = s.mblNuc;
		gap_open = s.gap_open;
		hpLength = new type[loopTableLength];
		bulgeLength = new type[loopTableLength];
		ilLength = new type[loopTableLength];
		copyArray(hpLength, s.hpLength, loopTableLength);
		copyArray(bulgeLength, s.bulgeLength, loopTableLength);
		copyArray(ilLength, s.ilLength, loopTableLength);
		matrixname = s.matrixname;
		alfa_size = s.alfaSize();
		makeMatrix4(s_matrix, as);
		copyMatrix4(s_matrix, s.s_matrix, as);
		makeMatrix4(stack_matrix, as);
		copyMatrix4(stack_matrix, s.stack_matrix, as);
		makeMatrix4(hp_close_matrix, as);
		copyMatrix4(hp_close_matrix, s.hp_close_matrix, as);
		makeMatrix4(internal_loop_matrix, as);
		copyMatrix4(internal_loop_matrix, s.internal_loop_matrix, as);
		makeMatrix3(dangle5, as);
		copyMatrix3(dangle5, s.dangle5, as);
		makeMatrix3(dangle3, as);
		copyMatrix3(dangle3, s.dangle3, as);
		makeMatrix2(i_matrix, as);
		copyMatrix2(i_matrix, s.i_matrix, as);
		makeMatrix2(basepair, as);
		copyMatrix2(basepair, s.basepair, as);
		makeMatrix2(endNonGC, as);
		copyMatrix2(endNonGC, s.endNonGC, as);
		alfabet = new char[as];
		copyArray(alfabet, s.alfabet, as);
		elongation = s.elongation;
	}
	return *this;
}

//*********************************************
// copy constructor for the scorematrix object
template<class type> inline scorematrix<type>::scorematrix(const scorematrix& s) {
	alfa_size = s.alfaSize();
	matrixname = s.matrixname;
	int as = s.alfaSize();
	makeMatrix4(s_matrix, as);
	copyMatrix4(s_matrix, s.s_matrix, as);
	makeMatrix4(stack_matrix, as);
	copyMatrix4(stack_matrix, s.stack_matrix, as);
	makeMatrix4(hp_close_matrix, as);
	copyMatrix4(hp_close_matrix, s.hp_close_matrix, as);
	makeMatrix4(internal_loop_matrix, as);
	copyMatrix4(internal_loop_matrix, s.internal_loop_matrix, as);
	makeMatrix3(dangle5, as);
	copyMatrix3(dangle5, s.dangle5, as);
	makeMatrix3(dangle3, as);
	copyMatrix3(dangle3, s.dangle3, as);
	makeMatrix2(i_matrix, as);
	copyMatrix2(i_matrix, s.i_matrix, as);
	makeMatrix2(basepair, as);
	copyMatrix2(basepair, s.basepair, as);
	makeMatrix2(endNonGC, as);
	copyMatrix2(endNonGC, s.endNonGC, as);
	alfabet = new char[as];
	copyArray(alfabet, s.alfabet, as);
	loopTableLength = s.loopTableLength;
	hpLong = s.hpLong;
	bulgeLong = s.bulgeLong;
	ilLong = s.ilLong;
	asym = s.asym;
	masym = s.masym;
	mbl = s.mbl;
	mblAffine = s.mblAffine;
	mblNuc = s.mblNuc;
	hpLength = new type[loopTableLength];
	bulgeLength = new type[loopTableLength];
	ilLength = new type[loopTableLength];
	copyArray(hpLength, s.hpLength, loopTableLength);
	copyArray(bulgeLength, s.bulgeLength, loopTableLength);
	copyArray(ilLength, s.ilLength, loopTableLength);
	gap_open = s.gap_open;
	elongation = s.elongation;
}

template<class type> inline int scorematrix<type>::alfa(char letter) const {
	char upper = toupper(letter);
	for(int i =0; i<alfa_size; i++) {
		if (alfabet[i]==upper) {return i;}
	}
	if(upper=='T') {return 4;}
	std::cerr << "Unknown nucleotide: " << letter << " found. Nucleotide treated as a gap " << alfabet[0] << " Score matrix used: " << matrixname << std::endl;
	return 0;
}

template<class type> inline type scorematrix<type>::getHpLength(const int i, const int j) {
	return hpLength[i]+hpLength[j];
}

template<class type> inline type scorematrix<type>::getBulgeLength(const int i, const int j) {
	return bulgeLength[i]+bulgeLength[j];
}

template<class type> inline type scorematrix<type>::getIntLoopLength(const int i, const int j) {
	type res= ilLength[i+j];
	// The Ninno equation
	// The value of 5 is ten times the values set in the miscloop file of dynalign
	type asymScore = asym*(i-j);
	// The final cost has to be negative
	if (asymScore > 0) {asymScore*=-1;}
	// Limits the maximum asymmetric cost
	if (asymScore < masym) {asymScore = masym;}
	res+=asymScore;
	return res;
}

//*************************************************
// The destructor

template<class type> inline scorematrix<type>::~scorematrix() {
	int i_size=alfaSize();
	deleteMatrix4(s_matrix, i_size);
	deleteMatrix4(stack_matrix, i_size);
	deleteMatrix4(hp_close_matrix, i_size);
	deleteMatrix4(internal_loop_matrix, i_size);
	deleteMatrix3(dangle5, i_size);
	deleteMatrix3(dangle3, i_size);
	deleteMatrix2(i_matrix, i_size);
	deleteMatrix2(basepair, i_size);
	deleteMatrix2(endNonGC, i_size);
	delete[] alfabet;
	delete[] hpLength;
	delete[] bulgeLength;
	delete[] ilLength;
}

//******************************************************
// The private functions


// A simple way of calculate the cost of very long loops.
// A better function would be based on the log of i scaled with the factor and the top value
template<class type> inline void scorematrix<type>::calcScore(const int factor, const int size, type*& array) {
	type* tmp = new type[size+1];
	copyArray(tmp, array, loopTableLength);
	if (factor != 0) {
		for(int i=loopTableLength; i<=size; i++) {
			tmp[i] = static_cast<type>(-10*log((static_cast<float>(factor*i)/static_cast<float>(factor*(loopTableLength-1))))) + array[loopTableLength-1];
		}
	}
	else {
		for(int i=loopTableLength; i<=size; i++) {
			tmp[i] = 0;
		}
	}
	delete[] array;
	array = tmp;
}

template<class type> inline void scorematrix<type>::dumpArray(const type* array) {
	for(int i=0; i<loopTableLength; i++) {std::cerr << i << " " << array[i] << std::endl;}
}

template<class type> inline void scorematrix<type>::checkSize(const int size) {
	if (size > loopTableLength) {
		calcScore(hpLong, size, hpLength);
		calcScore(bulgeLong, size, bulgeLength);
		calcScore(ilLong, size, ilLength);
		loopTableLength = size+1;
	}
}

//******************************************************
// These function templates makes or deletes
// 2 or 4 dimensional matrixes

template<class type> template<class local_type> inline void scorematrix<type>::makeMatrix2(local_type**& matrix, const int size) {
	matrix = new local_type*[size];
	for(int i=0; i<size; i++) {
		matrix[i] = new local_type[size];
	}
}

template<class type> template<class local_type> inline void scorematrix<type>::deleteMatrix2(local_type**& matrix, const int size) {
	for(int i=0; i<size; i++) {
		delete[] matrix[i];
	}
	delete[] matrix;
}

template<class type> template<class local_type> inline void scorematrix<type>::copyMatrix2(local_type**& matrix, local_type** const& old_matrix, const int size) {
	for(int i=0; i<size; i++) {
		for(int j=0; j < size; j++) {
			matrix[i][j] = old_matrix[i][j];
		}
	}
}

template<class type> template<class local_type> inline void scorematrix<type>::assignMatrix2(local_type**& matrix, const int size, const int value) {
	for(int i=0; i<size; i++) {
		for(int j=0; j < size; j++) {
			matrix[i][j] = value;
		}
	}
}

template<class type> template<class local_type> inline void scorematrix<type>::copyArray(local_type*& matrix, local_type* const& old_matrix, const int size) {
	for(int i=0; i<size; i++) {matrix[i] = old_matrix[i];}
}

template<class type> template<class local_type> inline void scorematrix<type>::assignArray(local_type*& matrix, const local_type value, const int size) {
	for(int i=0; i<size; i++) {matrix[i] = value;}
}

template<class type> template<class local_type> inline void scorematrix<type>::makeMatrix3(local_type***& matrix, const int size) {
	matrix = new local_type**[size];
	for(int i=0; i<size; i++) {
		matrix[i] = new local_type*[size];
		for(int j=0; j < size; j++) {
			matrix[i][j] = new local_type[size];
		}
	}
}

template<class type> template<class local_type> inline void scorematrix<type>::assignMatrix3(local_type***& matrix, const int size, const int value) {
	for(int i=0; i<size; i++) {
		for(int j=0; j < size; j++) {
			for(int k=0; k<size; k++) {
				matrix[i][j][k] = value;
			}
		}
	}
}

template<class type> template<class local_type> inline void scorematrix<type>::copyMatrix3(local_type***& matrix, local_type*** const& old_matrix, const int size) {
	for(int i=0; i<size; i++) {
		for(int j=0; j < size; j++) {
			for(int k=0; k<size; k++) {
				matrix[i][j][k] = old_matrix[i][j][k];
			}
		}
	}
}


template<class type> template<class local_type> inline void scorematrix<type>::deleteMatrix3(local_type***& matrix, const int size) {
	for(int i=0; i<size; i++) {
		for(int j=0; j < size; j++) {
			delete[] matrix[i][j];
		}
		delete[] matrix[i];
	}
	delete[] matrix;
}

template<class type> template<class local_type> inline void scorematrix<type>::makeMatrix4(local_type****& matrix, const int size) {
	matrix = new local_type***[size];
	for(int i=0; i<size; i++) {
		matrix[i] = new local_type**[size];
		for(int j=0; j < size; j++) {
			matrix[i][j] = new local_type*[size];
			for(int k=0; k<size; k++) {
				matrix[i][j][k] = new local_type[size];
			}
		}
	}
}

template<class type> template<class local_type> inline void scorematrix<type>::assignMatrix4(local_type****& matrix, const int size, const int value) {
	for(int i=0; i<size; i++) {
		for(int j=0; j < size; j++) {
			for(int k=0; k<size; k++) {
				for(int l=0; l<size; l++) {
					matrix[i][j][k][l] = value;
				}
			}
		}
	}
}

template<class type> template<class local_type> inline void scorematrix<type>::copyMatrix4(local_type****& matrix, local_type**** const& old_matrix, const int size) {
	for(int i=0; i<size; i++) {
		for(int j=0; j < size; j++) {
			for(int k=0; k<size; k++) {
				for(int l=0; l<size; l++) {
					matrix[i][j][k][l] = old_matrix[i][j][k][l];
				}
			}
		}
	}
}


template<class type> template<class local_type> inline void scorematrix<type>::deleteMatrix4(local_type****& matrix, const int size) {
	for(int i=0; i<size; i++) {
		for(int j=0; j < size; j++) {
			for(int k=0; k<size; k++) {
				delete[] matrix[i][j][k];
			}
			delete[] matrix[i][j];
		}
		delete[] matrix[i];
	}
	delete[] matrix;
}

//********************
// Functions for reading matrixes

template<class type> inline void scorematrix<type>::setAlfabet(std::ifstream& file) {
	if (alfadie) {
		std::cerr << "The alfabet has to be defined before anything else in the score matrix file\n";
		throw -1;
	}
	delete[] alfabet;
	int prev = 0;
	int pos, end_pos;
	std::string line;
	get_line(file,line);
	pos = line.find_last_not_of(" ");
	end_pos = line.find_last_of(" ", pos);
	
	tmp_alfa_size = atoi(line.substr(pos, (end_pos - pos)).c_str());
	alfabet = new char[tmp_alfa_size];
	for(int i=0; i<tmp_alfa_size; i++) {
		pos = line.find_first_not_of(" ", prev);
		alfabet[i] = line[pos];
		prev=pos+1;
	}
}

template<class type> inline void scorematrix<type>::setBasepair(std::ifstream& file) {
	alfadie=true;
	int as = alfaSize();
	deleteMatrix2(basepair, as);
	as = tmp_alfa_size;
	makeMatrix2(basepair, as);
	std::string line;
	int len = as;
	int prev = 0;
	int pos, end_pos;
	int* i_letters = new int[len];
	int k_letter;
	char letter;
	get_line(file,line);
	parseLine(line, i_letters, len);
	for(int i=0; i<len; i++) {
		get_line(file,line);
		pos = line.find_last_not_of(" ");
		letter = line[pos];
		k_letter = alfa(letter);
		prev = 0;
		for(int j=0; j<len; j++) {
			pos = line.find_first_not_of(" ", prev);
			end_pos = line.find(" ", pos);
			if (!line.substr(pos, (end_pos - pos)).compare("1")) {
				basepair[i_letters[j]][k_letter] = true;
			}
			else {
				basepair[i_letters[j]][k_letter] = false;
			}
			prev = end_pos+1;
		}
	}
	delete[] i_letters;
}

template<class type> inline void scorematrix<type>::setMatrix3(std::ifstream& file, type***& matrix) {
	alfadie=true;
	int as = alfaSize();
	deleteMatrix3(matrix, as);
	as = tmp_alfa_size;
	makeMatrix3(matrix, as);
	std::string line;
	int len = (as-1)*(as-1);
	int prev = 0;
	int pos;
	int* i_letters = new int[len];
	int* j_letters = new int[len];
	int k_letter;
	char letter;
	// Read and parse the index lines
	get_line(file,line);
	parseLine(line, i_letters, len);
	get_line(file,line);
	parseLine(line, j_letters, len);
	for(int i=0; i<(as-1); i++) {
		get_line(file,line);
		// Get the last karakter on the line so it can be used as index
		pos = line.find_last_not_of(" ");
		letter = line[pos];
		k_letter = alfa(letter);
		prev = 0;
		// Parse the rest of the line
		for(int j=0; j<len; j++) {
			matrix[i_letters[j]][j_letters[j]][k_letter] = getValue(prev, line);
		}
	}
	delete[] i_letters;
	delete[] j_letters;	
}
	
template<class type> inline void scorematrix<type>::setMatrix4(std::ifstream& file, type****& matrix) {
	alfadie=true;
	int as = alfaSize();
	deleteMatrix4(matrix, as);
	as = tmp_alfa_size;
	makeMatrix4(matrix, as);
	std::string line;
	int len = (as-1)*(as-1);
	int prev = 0;
	int pos;
	int* i_letters = new int[len];
	int* j_letters = new int[len];
	int k_letter;
	int l_letter;
	char letter;
	get_line(file,line);
	parseLine(line, i_letters, len);
	get_line(file,line);
	parseLine(line, j_letters, len);
	for(int i=0; i<len; i++) {
		prev=0;
		get_line(file,line);
		pos = line.find_last_not_of(" ");
		letter = line[pos];
		l_letter = alfa(letter);
		prev = pos-1;
		pos = line.find_last_not_of(" ", prev);
		letter = line[pos];
		k_letter = alfa(letter);
		prev = 0;
		for(int j=0; j<len; j++) {
			matrix[i_letters[j]][j_letters[j]][k_letter][l_letter] = getValue(prev, line);
		}
	}
	delete[] i_letters;
	delete[] j_letters;	
	
}
	
template<class type> inline void scorematrix<type>::setInitMatrix(std::ifstream& file) {
	alfadie=true;
	int as = alfaSize();
	deleteMatrix2(i_matrix, as);
	as = tmp_alfa_size;
	makeMatrix2(i_matrix, as);
	std::string line;
	int len = as-1;
	int prev = 0;
	int pos; //, end_pos;
	int* i_letters = new int[len];
	int k_letter;
	char letter;
	get_line(file,line);
	parseLine(line, i_letters, len);
	for(int i=0; i<len; i++) {
		get_line(file,line);
		pos = line.find_last_not_of(" ");
		letter = line[pos];
		k_letter = alfa(letter);
		prev = 0;
		for(int j=0; j<len; j++) {
			i_matrix[i_letters[j]][k_letter] = getValue(prev, line);
		}
	}
	delete[] i_letters;
}


template<class type> inline void scorematrix<type>::setLoopTable(std::ifstream& file) {
	alfadie=true; // It is no longer allowed to change the alfabet.
	std::string line;
	int prev = 0;
	get_line(file,line);
	int n_lines = getValue(prev, line);
	n_lines++; // The array is not zero based but starts with index 1
	if (n_lines != loopTableLength) {
		// Remove the preloaded values
		delete[] hpLength;
		delete[] bulgeLength;
		delete[] ilLength;
		// Allocate the new arrays
		hpLength = new type[n_lines];
		bulgeLength = new type[n_lines];
		ilLength = new type[n_lines];
		loopTableLength = n_lines;
	}
	hpLength[0] = 0;
	bulgeLength[0] = 0;
	ilLength[0] = 0;
	for(int i=1; i<loopTableLength; i++) {
		prev = 0;
		get_line(file,line);
		int index = getValue(prev, line);
		if (index != i) {std::cerr << "Warning: Line " << i << " in the Loop length costs table are index " << index << ". Parts of the table may be corrupt or missing" << std::endl;}
		hpLength[index] = getValue(prev, line);
		bulgeLength[index] = getValue(prev, line);
		ilLength[index] = getValue(prev, line);
	}
}
			
template<class type> inline void scorematrix<type>::setMisc(std::ifstream& file) {
	std::string line;
	std::string name;
	type value;
	while (true) {
		int prev = 0;
		get_line(file,line);
		if (!line.compare("")) {break;}
		name = findName(prev, line);
		value = getValue(prev,line);
		store(name, value);
	}
	elongation = elongation - gap_open;
}

template<class type> inline void scorematrix<type>::store(std::string name, type value) {
	if (!name.compare("Gap_open:")) {gap_open=value;}
	else if (!name.compare("Elongation_bonus:")) {elongation=value;}
	else if (!name.compare("Multibranchloop:")) {mbl=value;}
	else if (!name.compare("Multibranchloop_helix:")) {mblAffine=value;}
	else if (!name.compare("Multibranchloop_nucleotide:")) {mblNuc=value;}
	else if (!name.compare("Multibranchloop_non_GC_stem_end:")) {assignMatrix2(endNonGC, alfaSize(), value); endNonGC[2][3] = 0; endNonGC[3][2] = 0;}
	else if (!name.compare("Asymmetric_cost:")) {asym=value;}
	else if (!name.compare("Asymmetric_cost_limit:")) {masym=value;}
	else if (!name.compare("Long_hairpin_loop_factor:")) {ilLong=value;}
	else if (!name.compare("Long_bulge_loop_factor:")) {bulgeLong=value;}
	else if (!name.compare("Long_Internal_loop_factor:")) {hpLong=value;}
	else {std::cerr << "Warning: Unknown parameter " << name << " with value " << value << " found" << std::endl;}
}
	
template<class type> inline type scorematrix<type>::getValue(int& prev, std::string& line) {
	return atoi(findName(prev, line).c_str());
}
	
template<class type> inline std::string scorematrix<type>::findName(int& prev, std::string& line) {
	int pos;
	int end_pos = -1;
	int len = line.length();
	for(pos=prev; pos < len; pos++) {
		if ((line[pos] != ' ') && (line[pos] != '\t')) {
			end_pos = pos+1;
			while ((line[end_pos] != ' ') && (line[end_pos] != '\t') && (end_pos < len)) {end_pos++;}
			break;
		}
	}
	if (end_pos == -1) {std::cerr << "Could not read score matrix. Somethings wrong with this line\n" << line << std::endl; throw -1;}
	prev = end_pos+1;
	return line.substr(pos, (end_pos - pos));
}

//*****************************************************
// These function reads and parses an input line

template<class type> inline void scorematrix<type>::parseLine(std::string line, int*& i_letters, int& len) {
	char letter;
	int pos=0;
	int length = line.length();
	for(int i=0; i<len; i++) {
		while ((line[pos] == ' ') || (line[pos] == '\t')) {pos++;}
		if (pos > length) {std::cerr << "Could not read score matrix. Somethings wrong with this line\n" << line << std::endl; throw -1;}
		letter = line[pos];
		i_letters[i] = alfa(letter);
		pos++;
	}
}

template<class type> inline void scorematrix<type>::get_line(std::ifstream& file, std::string& line) {
	std::getline(file,line);
	while ((line[0] == '#') && (!file.fail())){
		std::getline(file,line);
	}
}

//*****************************************************
// This function sets the default values.

template<class type> inline void scorematrix<type>::score_matrix() {
		alfadie=false;
		alfa_size = tmp_alfa_size = 5;
		int i_size=alfaSize();
		makeMatrix4(s_matrix, i_size);
		makeMatrix4(stack_matrix, i_size);
		makeMatrix4(hp_close_matrix, i_size);
		makeMatrix4(internal_loop_matrix, i_size);
		makeMatrix3(dangle5, i_size);
		makeMatrix3(dangle3, i_size);
		makeMatrix2(i_matrix, i_size);
		makeMatrix2(basepair, i_size);
		makeMatrix2(endNonGC, i_size);
		assignMatrix2(endNonGC, alfa_size, -5); 
		endNonGC[2][3] = 0; 
		endNonGC[3][2] = 0;
		alfabet = new char[alfa_size];
		alfabet[0] = '-';
		alfabet[1] = 'A';
		alfabet[2] = 'C';
		alfabet[3] = 'G';
		alfabet[4] = 'U';
		matrixname ="Default";
		gap_open = -50;
		elongation = 25; // This value has to be positive: e=e-g_o
		loopTableLength = 31;
		ilLong = -11;
		bulgeLong = -11;
		hpLong = -11;
		asym = -5;
		masym = -30;
		mbl=-34;
		mblAffine=-4;
		mblNuc=0;
		hpLength = new type[loopTableLength];
		bulgeLength = new type[loopTableLength];
		ilLength = new type[loopTableLength];
		int index=0;
// There are a few lines of code at the bottom of the file
		basepair[0][0]=false;
		basepair[0][1]=false;
		basepair[0][2]=false;
		basepair[0][3]=false;
		basepair[0][4]=false;
		basepair[1][0]=false;
		basepair[1][1]=false;
		basepair[1][2]=false;
		basepair[1][3]=false;
		basepair[1][4]=true;
		basepair[2][0]=false;
		basepair[2][1]=false;
		basepair[2][2]=false;
		basepair[2][3]=true;
		basepair[2][4]=false;
		basepair[3][0]=false;
		basepair[3][1]=false;
		basepair[3][2]=true;
		basepair[3][3]=false;
		basepair[3][4]=true;
		basepair[4][0]=false;
		basepair[4][1]=true;
		basepair[4][2]=false;
		basepair[4][3]=true;
		basepair[4][4]=false;
stack_matrix[1][1][1][1] = 0;
stack_matrix[1][2][1][1] = 0;
stack_matrix[1][3][1][1] = 0;
stack_matrix[1][4][1][1] = 0;
stack_matrix[2][1][1][1] = 0;
stack_matrix[2][2][1][1] = 0;
stack_matrix[2][3][1][1] = 0;
stack_matrix[2][4][1][1] = 0;
stack_matrix[3][1][1][1] = 0;
stack_matrix[3][2][1][1] = 0;
stack_matrix[3][3][1][1] = 0;
stack_matrix[3][4][1][1] = 0;
stack_matrix[4][1][1][1] = 0;
stack_matrix[4][2][1][1] = 0;
stack_matrix[4][3][1][1] = 0;
stack_matrix[4][4][1][1] = 0;
stack_matrix[1][1][1][2] = 0;
stack_matrix[1][2][1][2] = 0;
stack_matrix[1][3][1][2] = 0;
stack_matrix[1][4][1][2] = 0;
stack_matrix[2][1][1][2] = 0;
stack_matrix[2][2][1][2] = 0;
stack_matrix[2][3][1][2] = 0;
stack_matrix[2][4][1][2] = 0;
stack_matrix[3][1][1][2] = 0;
stack_matrix[3][2][1][2] = 0;
stack_matrix[3][3][1][2] = 0;
stack_matrix[3][4][1][2] = 0;
stack_matrix[4][1][1][2] = 0;
stack_matrix[4][2][1][2] = 0;
stack_matrix[4][3][1][2] = 0;
stack_matrix[4][4][1][2] = 0;
stack_matrix[1][1][1][3] = 0;
stack_matrix[1][2][1][3] = 0;
stack_matrix[1][3][1][3] = 0;
stack_matrix[1][4][1][3] = 0;
stack_matrix[2][1][1][3] = 0;
stack_matrix[2][2][1][3] = 0;
stack_matrix[2][3][1][3] = 0;
stack_matrix[2][4][1][3] = 0;
stack_matrix[3][1][1][3] = 0;
stack_matrix[3][2][1][3] = 0;
stack_matrix[3][3][1][3] = 0;
stack_matrix[3][4][1][3] = 0;
stack_matrix[4][1][1][3] = 0;
stack_matrix[4][2][1][3] = 0;
stack_matrix[4][3][1][3] = 0;
stack_matrix[4][4][1][3] = 0;
stack_matrix[1][1][1][4] = 0;
stack_matrix[1][2][1][4] = 0;
stack_matrix[1][3][1][4] = 0;
stack_matrix[1][4][1][4] = 9;
stack_matrix[2][1][1][4] = 0;
stack_matrix[2][2][1][4] = 0;
stack_matrix[2][3][1][4] = 21;
stack_matrix[2][4][1][4] = 0;
stack_matrix[3][1][1][4] = 0;
stack_matrix[3][2][1][4] = 24;
stack_matrix[3][3][1][4] = 0;
stack_matrix[3][4][1][4] = 13;
stack_matrix[4][1][1][4] = 13;
stack_matrix[4][2][1][4] = 0;
stack_matrix[4][3][1][4] = 10;
stack_matrix[4][4][1][4] = 0;
stack_matrix[1][1][2][1] = 0;
stack_matrix[1][2][2][1] = 0;
stack_matrix[1][3][2][1] = 0;
stack_matrix[1][4][2][1] = 0;
stack_matrix[2][1][2][1] = 0;
stack_matrix[2][2][2][1] = 0;
stack_matrix[2][3][2][1] = 0;
stack_matrix[2][4][2][1] = 0;
stack_matrix[3][1][2][1] = 0;
stack_matrix[3][2][2][1] = 0;
stack_matrix[3][3][2][1] = 0;
stack_matrix[3][4][2][1] = 0;
stack_matrix[4][1][2][1] = 0;
stack_matrix[4][2][2][1] = 0;
stack_matrix[4][3][2][1] = 0;
stack_matrix[4][4][2][1] = 0;
stack_matrix[1][1][2][2] = 0;
stack_matrix[1][2][2][2] = 0;
stack_matrix[1][3][2][2] = 0;
stack_matrix[1][4][2][2] = 0;
stack_matrix[2][1][2][2] = 0;
stack_matrix[2][2][2][2] = 0;
stack_matrix[2][3][2][2] = 0;
stack_matrix[2][4][2][2] = 0;
stack_matrix[3][1][2][2] = 0;
stack_matrix[3][2][2][2] = 0;
stack_matrix[3][3][2][2] = 0;
stack_matrix[3][4][2][2] = 0;
stack_matrix[4][1][2][2] = 0;
stack_matrix[4][2][2][2] = 0;
stack_matrix[4][3][2][2] = 0;
stack_matrix[4][4][2][2] = 0;
stack_matrix[1][1][2][3] = 0;
stack_matrix[1][2][2][3] = 0;
stack_matrix[1][3][2][3] = 0;
stack_matrix[1][4][2][3] = 22;
stack_matrix[2][1][2][3] = 0;
stack_matrix[2][2][2][3] = 0;
stack_matrix[2][3][2][3] = 33;
stack_matrix[2][4][2][3] = 0;
stack_matrix[3][1][2][3] = 0;
stack_matrix[3][2][2][3] = 34;
stack_matrix[3][3][2][3] = 0;
stack_matrix[3][4][2][3] = 25;
stack_matrix[4][1][2][3] = 24;
stack_matrix[4][2][2][3] = 0;
stack_matrix[4][3][2][3] = 15;
stack_matrix[4][4][2][3] = 0;
stack_matrix[1][1][2][4] = 0;
stack_matrix[1][2][2][4] = 0;
stack_matrix[1][3][2][4] = 0;
stack_matrix[1][4][2][4] = 0;
stack_matrix[2][1][2][4] = 0;
stack_matrix[2][2][2][4] = 0;
stack_matrix[2][3][2][4] = 0;
stack_matrix[2][4][2][4] = 0;
stack_matrix[3][1][2][4] = 0;
stack_matrix[3][2][2][4] = 0;
stack_matrix[3][3][2][4] = 0;
stack_matrix[3][4][2][4] = 0;
stack_matrix[4][1][2][4] = 0;
stack_matrix[4][2][2][4] = 0;
stack_matrix[4][3][2][4] = 0;
stack_matrix[4][4][2][4] = 0;
stack_matrix[1][1][3][1] = 0;
stack_matrix[1][2][3][1] = 0;
stack_matrix[1][3][3][1] = 0;
stack_matrix[1][4][3][1] = 0;
stack_matrix[2][1][3][1] = 0;
stack_matrix[2][2][3][1] = 0;
stack_matrix[2][3][3][1] = 0;
stack_matrix[2][4][3][1] = 0;
stack_matrix[3][1][3][1] = 0;
stack_matrix[3][2][3][1] = 0;
stack_matrix[3][3][3][1] = 0;
stack_matrix[3][4][3][1] = 0;
stack_matrix[4][1][3][1] = 0;
stack_matrix[4][2][3][1] = 0;
stack_matrix[4][3][3][1] = 0;
stack_matrix[4][4][3][1] = 0;
stack_matrix[1][1][3][2] = 0;
stack_matrix[1][2][3][2] = 0;
stack_matrix[1][3][3][2] = 0;
stack_matrix[1][4][3][2] = 21;
stack_matrix[2][1][3][2] = 0;
stack_matrix[2][2][3][2] = 0;
stack_matrix[2][3][3][2] = 24;
stack_matrix[2][4][3][2] = 0;
stack_matrix[3][1][3][2] = 0;
stack_matrix[3][2][3][2] = 33;
stack_matrix[3][3][3][2] = 0;
stack_matrix[3][4][3][2] = 21;
stack_matrix[4][1][3][2] = 21;
stack_matrix[4][2][3][2] = 0;
stack_matrix[4][3][3][2] = 14;
stack_matrix[4][4][3][2] = 0;
stack_matrix[1][1][3][3] = 0;
stack_matrix[1][2][3][3] = 0;
stack_matrix[1][3][3][3] = 0;
stack_matrix[1][4][3][3] = 0;
stack_matrix[2][1][3][3] = 0;
stack_matrix[2][2][3][3] = 0;
stack_matrix[2][3][3][3] = 0;
stack_matrix[2][4][3][3] = 0;
stack_matrix[3][1][3][3] = 0;
stack_matrix[3][2][3][3] = 0;
stack_matrix[3][3][3][3] = 0;
stack_matrix[3][4][3][3] = 0;
stack_matrix[4][1][3][3] = 0;
stack_matrix[4][2][3][3] = 0;
stack_matrix[4][3][3][3] = 0;
stack_matrix[4][4][3][3] = 0;
stack_matrix[1][1][3][4] = 0;
stack_matrix[1][2][3][4] = 0;
stack_matrix[1][3][3][4] = 0;
stack_matrix[1][4][3][4] = 6;
stack_matrix[2][1][3][4] = 0;
stack_matrix[2][2][3][4] = 0;
stack_matrix[2][3][3][4] = 14;
stack_matrix[2][4][3][4] = 0;
stack_matrix[3][1][3][4] = 0;
stack_matrix[3][2][3][4] = 15;
stack_matrix[3][3][3][4] = 0;
stack_matrix[3][4][3][4] = 5;
stack_matrix[4][1][3][4] = 10;
stack_matrix[4][2][3][4] = 0;
stack_matrix[4][3][3][4] = -3;
stack_matrix[4][4][3][4] = 0;
stack_matrix[1][1][4][1] = 0;
stack_matrix[1][2][4][1] = 0;
stack_matrix[1][3][4][1] = 0;
stack_matrix[1][4][4][1] = 11;
stack_matrix[2][1][4][1] = 0;
stack_matrix[2][2][4][1] = 0;
stack_matrix[2][3][4][1] = 21;
stack_matrix[2][4][4][1] = 0;
stack_matrix[3][1][4][1] = 0;
stack_matrix[3][2][4][1] = 22;
stack_matrix[3][3][4][1] = 0;
stack_matrix[3][4][4][1] = 14;
stack_matrix[4][1][4][1] = 9;
stack_matrix[4][2][4][1] = 0;
stack_matrix[4][3][4][1] = 6;
stack_matrix[4][4][4][1] = 0;
stack_matrix[1][1][4][2] = 0;
stack_matrix[1][2][4][2] = 0;
stack_matrix[1][3][4][2] = 0;
stack_matrix[1][4][4][2] = 0;
stack_matrix[2][1][4][2] = 0;
stack_matrix[2][2][4][2] = 0;
stack_matrix[2][3][4][2] = 0;
stack_matrix[2][4][4][2] = 0;
stack_matrix[3][1][4][2] = 0;
stack_matrix[3][2][4][2] = 0;
stack_matrix[3][3][4][2] = 0;
stack_matrix[3][4][4][2] = 0;
stack_matrix[4][1][4][2] = 0;
stack_matrix[4][2][4][2] = 0;
stack_matrix[4][3][4][2] = 0;
stack_matrix[4][4][4][2] = 0;
stack_matrix[1][1][4][3] = 0;
stack_matrix[1][2][4][3] = 0;
stack_matrix[1][3][4][3] = 0;
stack_matrix[1][4][4][3] = 14;
stack_matrix[2][1][4][3] = 0;
stack_matrix[2][2][4][3] = 0;
stack_matrix[2][3][4][3] = 21;
stack_matrix[2][4][4][3] = 0;
stack_matrix[3][1][4][3] = 0;
stack_matrix[3][2][4][3] = 25;
stack_matrix[3][3][4][3] = 0;
stack_matrix[3][4][4][3] = -13;
stack_matrix[4][1][4][3] = 13;
stack_matrix[4][2][4][3] = 0;
stack_matrix[4][3][4][3] = 5;
stack_matrix[4][4][4][3] = 0;
stack_matrix[1][1][4][4] = 0;
stack_matrix[1][2][4][4] = 0;
stack_matrix[1][3][4][4] = 0;
stack_matrix[1][4][4][4] = 0;
stack_matrix[2][1][4][4] = 0;
stack_matrix[2][2][4][4] = 0;
stack_matrix[2][3][4][4] = 0;
stack_matrix[2][4][4][4] = 0;
stack_matrix[3][1][4][4] = 0;
stack_matrix[3][2][4][4] = 0;
stack_matrix[3][3][4][4] = 0;
stack_matrix[3][4][4][4] = 0;
stack_matrix[4][1][4][4] = 0;
stack_matrix[4][2][4][4] = 0;
stack_matrix[4][3][4][4] = 0;
stack_matrix[4][4][4][4] = 0;
hp_close_matrix[1][1][1][1] = 0;
hp_close_matrix[1][2][1][1] = 0;
hp_close_matrix[1][3][1][1] = 0;
hp_close_matrix[1][4][1][1] = 3;
hp_close_matrix[2][1][1][1] = 0;
hp_close_matrix[2][2][1][1] = 0;
hp_close_matrix[2][3][1][1] = 15;
hp_close_matrix[2][4][1][1] = 0;
hp_close_matrix[3][1][1][1] = 0;
hp_close_matrix[3][2][1][1] = 11;
hp_close_matrix[3][3][1][1] = 0;
hp_close_matrix[3][4][1][1] = -2;
hp_close_matrix[4][1][1][1] = 5;
hp_close_matrix[4][2][1][1] = 0;
hp_close_matrix[4][3][1][1] = 5;
hp_close_matrix[4][4][1][1] = 0;
hp_close_matrix[1][1][1][2] = 0;
hp_close_matrix[1][2][1][2] = 0;
hp_close_matrix[1][3][1][2] = 0;
hp_close_matrix[1][4][1][2] = 5;
hp_close_matrix[2][1][1][2] = 0;
hp_close_matrix[2][2][1][2] = 0;
hp_close_matrix[2][3][1][2] = 15;
hp_close_matrix[2][4][1][2] = 0;
hp_close_matrix[3][1][1][2] = 0;
hp_close_matrix[3][2][1][2] = 15;
hp_close_matrix[3][3][1][2] = 0;
hp_close_matrix[3][4][1][2] = 5;
hp_close_matrix[4][1][1][2] = 3;
hp_close_matrix[4][2][1][2] = 0;
hp_close_matrix[4][3][1][2] = 3;
hp_close_matrix[4][4][1][2] = 0;
hp_close_matrix[1][1][1][3] = 0;
hp_close_matrix[1][2][1][3] = 0;
hp_close_matrix[1][3][1][3] = 0;
hp_close_matrix[1][4][1][3] = 3;
hp_close_matrix[2][1][1][3] = 0;
hp_close_matrix[2][2][1][3] = 0;
hp_close_matrix[2][3][1][3] = 14;
hp_close_matrix[2][4][1][3] = 0;
hp_close_matrix[3][1][1][3] = 0;
hp_close_matrix[3][2][1][3] = 13;
hp_close_matrix[3][3][1][3] = 0;
hp_close_matrix[3][4][1][3] = 3;
hp_close_matrix[4][1][1][3] = 6;
hp_close_matrix[4][2][1][3] = 0;
hp_close_matrix[4][3][1][3] = 6;
hp_close_matrix[4][4][1][3] = 0;
hp_close_matrix[1][1][1][4] = 0;
hp_close_matrix[1][2][1][4] = 0;
hp_close_matrix[1][3][1][4] = 0;
hp_close_matrix[1][4][1][4] = 3;
hp_close_matrix[2][1][1][4] = 0;
hp_close_matrix[2][2][1][4] = 0;
hp_close_matrix[2][3][1][4] = 18;
hp_close_matrix[2][4][1][4] = 0;
hp_close_matrix[3][1][1][4] = 0;
hp_close_matrix[3][2][1][4] = 21;
hp_close_matrix[3][3][1][4] = 0;
hp_close_matrix[3][4][1][4] = 3;
hp_close_matrix[4][1][1][4] = 5;
hp_close_matrix[4][2][1][4] = 0;
hp_close_matrix[4][3][1][4] = 5;
hp_close_matrix[4][4][1][4] = 0;
hp_close_matrix[1][1][2][1] = 0;
hp_close_matrix[1][2][2][1] = 0;
hp_close_matrix[1][3][2][1] = 0;
hp_close_matrix[1][4][2][1] = 1;
hp_close_matrix[2][1][2][1] = 0;
hp_close_matrix[2][2][2][1] = 0;
hp_close_matrix[2][3][2][1] = 10;
hp_close_matrix[2][4][2][1] = 0;
hp_close_matrix[3][1][2][1] = 0;
hp_close_matrix[3][2][2][1] = 11;
hp_close_matrix[3][3][2][1] = 0;
hp_close_matrix[3][4][2][1] = 1;
hp_close_matrix[4][1][2][1] = 2;
hp_close_matrix[4][2][2][1] = 0;
hp_close_matrix[4][3][2][1] = 2;
hp_close_matrix[4][4][2][1] = 0;
hp_close_matrix[1][1][2][2] = 0;
hp_close_matrix[1][2][2][2] = 0;
hp_close_matrix[1][3][2][2] = 0;
hp_close_matrix[1][4][2][2] = 2;
hp_close_matrix[2][1][2][2] = 0;
hp_close_matrix[2][2][2][2] = 0;
hp_close_matrix[2][3][2][2] = 9;
hp_close_matrix[2][4][2][2] = 0;
hp_close_matrix[3][1][2][2] = 0;
hp_close_matrix[3][2][2][2] = 7;
hp_close_matrix[3][3][2][2] = 0;
hp_close_matrix[3][4][2][2] = 2;
hp_close_matrix[4][1][2][2] = 1;
hp_close_matrix[4][2][2][2] = 0;
hp_close_matrix[4][3][2][2] = 1;
hp_close_matrix[4][4][2][2] = 0;
hp_close_matrix[1][1][2][3] = 0;
hp_close_matrix[1][2][2][3] = 0;
hp_close_matrix[1][3][2][3] = 0;
hp_close_matrix[1][4][2][3] = 15;
hp_close_matrix[2][1][2][3] = 0;
hp_close_matrix[2][2][2][3] = 0;
hp_close_matrix[2][3][2][3] = 29;
hp_close_matrix[2][4][2][3] = 0;
hp_close_matrix[3][1][2][3] = 0;
hp_close_matrix[3][2][2][3] = 24;
hp_close_matrix[3][3][2][3] = 0;
hp_close_matrix[3][4][2][3] = 15;
hp_close_matrix[4][1][2][3] = 12;
hp_close_matrix[4][2][2][3] = 0;
hp_close_matrix[4][3][2][3] = 17;
hp_close_matrix[4][4][2][3] = 0;
hp_close_matrix[1][1][2][4] = 0;
hp_close_matrix[1][2][2][4] = 0;
hp_close_matrix[1][3][2][4] = 0;
hp_close_matrix[1][4][2][4] = 2;
hp_close_matrix[2][1][2][4] = 0;
hp_close_matrix[2][2][2][4] = 0;
hp_close_matrix[2][3][2][4] = 8;
hp_close_matrix[2][4][2][4] = 0;
hp_close_matrix[3][1][2][4] = 0;
hp_close_matrix[3][2][2][4] = 5;
hp_close_matrix[3][3][2][4] = 0;
hp_close_matrix[3][4][2][4] = 2;
hp_close_matrix[4][1][2][4] = 0;
hp_close_matrix[4][2][2][4] = 0;
hp_close_matrix[4][3][2][4] = 0;
hp_close_matrix[4][4][2][4] = 0;
hp_close_matrix[1][1][3][1] = 0;
hp_close_matrix[1][2][3][1] = 0;
hp_close_matrix[1][3][3][1] = 0;
hp_close_matrix[1][4][3][1] = 11;
hp_close_matrix[2][1][3][1] = 0;
hp_close_matrix[2][2][3][1] = 0;
hp_close_matrix[2][3][3][1] = 22;
hp_close_matrix[2][4][3][1] = 0;
hp_close_matrix[3][1][3][1] = 0;
hp_close_matrix[3][2][3][1] = 24;
hp_close_matrix[3][3][3][1] = 0;
hp_close_matrix[3][4][3][1] = 9;
hp_close_matrix[4][1][3][1] = 14;
hp_close_matrix[4][2][3][1] = 0;
hp_close_matrix[4][3][3][1] = 8;
hp_close_matrix[4][4][3][1] = 0;
hp_close_matrix[1][1][3][2] = 0;
hp_close_matrix[1][2][3][2] = 0;
hp_close_matrix[1][3][3][2] = 0;
hp_close_matrix[1][4][3][2] = 12;
hp_close_matrix[2][1][3][2] = 0;
hp_close_matrix[2][2][3][2] = 0;
hp_close_matrix[2][3][3][2] = 20;
hp_close_matrix[2][4][3][2] = 0;
hp_close_matrix[3][1][3][2] = 0;
hp_close_matrix[3][2][3][2] = 29;
hp_close_matrix[3][3][3][2] = 0;
hp_close_matrix[3][4][3][2] = 11;
hp_close_matrix[4][1][3][2] = 12;
hp_close_matrix[4][2][3][2] = 0;
hp_close_matrix[4][3][3][2] = 12;
hp_close_matrix[4][4][3][2] = 0;
hp_close_matrix[1][1][3][3] = 0;
hp_close_matrix[1][2][3][3] = 0;
hp_close_matrix[1][3][3][3] = 0;
hp_close_matrix[1][4][3][3] = 2;
hp_close_matrix[2][1][3][3] = 0;
hp_close_matrix[2][2][3][3] = 0;
hp_close_matrix[2][3][3][3] = 16;
hp_close_matrix[2][4][3][3] = 0;
hp_close_matrix[3][1][3][3] = 0;
hp_close_matrix[3][2][3][3] = 14;
hp_close_matrix[3][3][3][3] = 0;
hp_close_matrix[3][4][3][3] = 3;
hp_close_matrix[4][1][3][3] = 7;
hp_close_matrix[4][2][3][3] = 0;
hp_close_matrix[4][3][3][3] = 3;
hp_close_matrix[4][4][3][3] = 0;
hp_close_matrix[1][1][3][4] = 0;
hp_close_matrix[1][2][3][4] = 0;
hp_close_matrix[1][3][3][4] = 0;
hp_close_matrix[1][4][3][4] = -2;
hp_close_matrix[2][1][3][4] = 0;
hp_close_matrix[2][2][3][4] = 0;
hp_close_matrix[2][3][3][4] = 11;
hp_close_matrix[2][4][3][4] = 0;
hp_close_matrix[3][1][3][4] = 0;
hp_close_matrix[3][2][3][4] = 12;
hp_close_matrix[3][3][3][4] = 0;
hp_close_matrix[3][4][3][4] = 0;
hp_close_matrix[4][1][3][4] = 2;
hp_close_matrix[4][2][3][4] = 0;
hp_close_matrix[4][3][3][4] = 7;
hp_close_matrix[4][4][3][4] = 0;
hp_close_matrix[1][1][4][1] = 0;
hp_close_matrix[1][2][4][1] = 0;
hp_close_matrix[1][3][4][1] = 0;
hp_close_matrix[1][4][4][1] = 3;
hp_close_matrix[2][1][4][1] = 0;
hp_close_matrix[2][2][4][1] = 0;
hp_close_matrix[2][3][4][1] = 17;
hp_close_matrix[2][4][4][1] = 0;
hp_close_matrix[3][1][4][1] = 0;
hp_close_matrix[3][2][4][1] = 19;
hp_close_matrix[3][3][4][1] = 0;
hp_close_matrix[3][4][4][1] = 3;
hp_close_matrix[4][1][4][1] = 3;
hp_close_matrix[4][2][4][1] = 0;
hp_close_matrix[4][3][4][1] = 6;
hp_close_matrix[4][4][4][1] = 0;
hp_close_matrix[1][1][4][2] = 0;
hp_close_matrix[1][2][4][2] = 0;
hp_close_matrix[1][3][4][2] = 0;
hp_close_matrix[1][4][4][2] = 3;
hp_close_matrix[2][1][4][2] = 0;
hp_close_matrix[2][2][4][2] = 0;
hp_close_matrix[2][3][4][2] = 14;
hp_close_matrix[2][4][4][2] = 0;
hp_close_matrix[3][1][4][2] = 0;
hp_close_matrix[3][2][4][2] = 10;
hp_close_matrix[3][3][4][2] = 0;
hp_close_matrix[3][4][4][2] = 3;
hp_close_matrix[4][1][4][2] = 1;
hp_close_matrix[4][2][4][2] = 0;
hp_close_matrix[4][3][4][2] = 1;
hp_close_matrix[4][4][4][2] = 0;
hp_close_matrix[1][1][4][3] = 0;
hp_close_matrix[1][2][4][3] = 0;
hp_close_matrix[1][3][4][3] = 0;
hp_close_matrix[1][4][4][3] = 6;
hp_close_matrix[2][1][4][3] = 0;
hp_close_matrix[2][2][4][3] = 0;
hp_close_matrix[2][3][4][3] = 18;
hp_close_matrix[2][4][4][3] = 0;
hp_close_matrix[3][1][4][3] = 0;
hp_close_matrix[3][2][4][3] = 22;
hp_close_matrix[3][3][4][3] = 0;
hp_close_matrix[3][4][4][3] = 4;
hp_close_matrix[4][1][4][3] = 5;
hp_close_matrix[4][2][4][3] = 0;
hp_close_matrix[4][3][4][3] = 6;
hp_close_matrix[4][4][4][3] = 0;
hp_close_matrix[1][1][4][4] = 0;
hp_close_matrix[1][2][4][4] = 0;
hp_close_matrix[1][3][4][4] = 0;
hp_close_matrix[1][4][4][4] = 11;
hp_close_matrix[2][1][4][4] = 0;
hp_close_matrix[2][2][4][4] = 0;
hp_close_matrix[2][3][4][4] = 20;
hp_close_matrix[2][4][4][4] = 0;
hp_close_matrix[3][1][4][4] = 0;
hp_close_matrix[3][2][4][4] = 15;
hp_close_matrix[3][3][4][4] = 0;
hp_close_matrix[3][4][4][4] = 11;
hp_close_matrix[4][1][4][4] = 8;
hp_close_matrix[4][2][4][4] = 0;
hp_close_matrix[4][3][4][4] = 8;
hp_close_matrix[4][4][4][4] = 0;
internal_loop_matrix[1][1][1][1] = 0;
internal_loop_matrix[1][2][1][1] = 0;
internal_loop_matrix[1][3][1][1] = 0;
internal_loop_matrix[1][4][1][1] = -7;
internal_loop_matrix[2][1][1][1] = 0;
internal_loop_matrix[2][2][1][1] = 0;
internal_loop_matrix[2][3][1][1] = 0;
internal_loop_matrix[2][4][1][1] = 0;
internal_loop_matrix[3][1][1][1] = 0;
internal_loop_matrix[3][2][1][1] = 0;
internal_loop_matrix[3][3][1][1] = 0;
internal_loop_matrix[3][4][1][1] = -7;
internal_loop_matrix[4][1][1][1] = -7;
internal_loop_matrix[4][2][1][1] = 0;
internal_loop_matrix[4][3][1][1] = -7;
internal_loop_matrix[4][4][1][1] = 0;
internal_loop_matrix[1][1][1][2] = 0;
internal_loop_matrix[1][2][1][2] = 0;
internal_loop_matrix[1][3][1][2] = 0;
internal_loop_matrix[1][4][1][2] = -7;
internal_loop_matrix[2][1][1][2] = 0;
internal_loop_matrix[2][2][1][2] = 0;
internal_loop_matrix[2][3][1][2] = 0;
internal_loop_matrix[2][4][1][2] = 0;
internal_loop_matrix[3][1][1][2] = 0;
internal_loop_matrix[3][2][1][2] = 0;
internal_loop_matrix[3][3][1][2] = 0;
internal_loop_matrix[3][4][1][2] = -7;
internal_loop_matrix[4][1][1][2] = -7;
internal_loop_matrix[4][2][1][2] = 0;
internal_loop_matrix[4][3][1][2] = -7;
internal_loop_matrix[4][4][1][2] = 0;
internal_loop_matrix[1][1][1][3] = 0;
internal_loop_matrix[1][2][1][3] = 0;
internal_loop_matrix[1][3][1][3] = 0;
internal_loop_matrix[1][4][1][3] = 4;
internal_loop_matrix[2][1][1][3] = 0;
internal_loop_matrix[2][2][1][3] = 0;
internal_loop_matrix[2][3][1][3] = 11;
internal_loop_matrix[2][4][1][3] = 0;
internal_loop_matrix[3][1][1][3] = 0;
internal_loop_matrix[3][2][1][3] = 11;
internal_loop_matrix[3][3][1][3] = 0;
internal_loop_matrix[3][4][1][3] = 4;
internal_loop_matrix[4][1][1][3] = 4;
internal_loop_matrix[4][2][1][3] = 0;
internal_loop_matrix[4][3][1][3] = 4;
internal_loop_matrix[4][4][1][3] = 0;
internal_loop_matrix[1][1][1][4] = 0;
internal_loop_matrix[1][2][1][4] = 0;
internal_loop_matrix[1][3][1][4] = 0;
internal_loop_matrix[1][4][1][4] = -7;
internal_loop_matrix[2][1][1][4] = 0;
internal_loop_matrix[2][2][1][4] = 0;
internal_loop_matrix[2][3][1][4] = 0;
internal_loop_matrix[2][4][1][4] = 0;
internal_loop_matrix[3][1][1][4] = 0;
internal_loop_matrix[3][2][1][4] = 0;
internal_loop_matrix[3][3][1][4] = 0;
internal_loop_matrix[3][4][1][4] = -7;
internal_loop_matrix[4][1][1][4] = -7;
internal_loop_matrix[4][2][1][4] = 0;
internal_loop_matrix[4][3][1][4] = -7;
internal_loop_matrix[4][4][1][4] = 0;
internal_loop_matrix[1][1][2][1] = 0;
internal_loop_matrix[1][2][2][1] = 0;
internal_loop_matrix[1][3][2][1] = 0;
internal_loop_matrix[1][4][2][1] = -7;
internal_loop_matrix[2][1][2][1] = 0;
internal_loop_matrix[2][2][2][1] = 0;
internal_loop_matrix[2][3][2][1] = 0;
internal_loop_matrix[2][4][2][1] = 0;
internal_loop_matrix[3][1][2][1] = 0;
internal_loop_matrix[3][2][2][1] = 0;
internal_loop_matrix[3][3][2][1] = 0;
internal_loop_matrix[3][4][2][1] = -7;
internal_loop_matrix[4][1][2][1] = -7;
internal_loop_matrix[4][2][2][1] = 0;
internal_loop_matrix[4][3][2][1] = -7;
internal_loop_matrix[4][4][2][1] = 0;
internal_loop_matrix[1][1][2][2] = 0;
internal_loop_matrix[1][2][2][2] = 0;
internal_loop_matrix[1][3][2][2] = 0;
internal_loop_matrix[1][4][2][2] = -7;
internal_loop_matrix[2][1][2][2] = 0;
internal_loop_matrix[2][2][2][2] = 0;
internal_loop_matrix[2][3][2][2] = 0;
internal_loop_matrix[2][4][2][2] = 0;
internal_loop_matrix[3][1][2][2] = 0;
internal_loop_matrix[3][2][2][2] = 0;
internal_loop_matrix[3][3][2][2] = 0;
internal_loop_matrix[3][4][2][2] = -7;
internal_loop_matrix[4][1][2][2] = -7;
internal_loop_matrix[4][2][2][2] = 0;
internal_loop_matrix[4][3][2][2] = -7;
internal_loop_matrix[4][4][2][2] = 0;
internal_loop_matrix[1][1][2][3] = 0;
internal_loop_matrix[1][2][2][3] = 0;
internal_loop_matrix[1][3][2][3] = 0;
internal_loop_matrix[1][4][2][3] = -7;
internal_loop_matrix[2][1][2][3] = 0;
internal_loop_matrix[2][2][2][3] = 0;
internal_loop_matrix[2][3][2][3] = 0;
internal_loop_matrix[2][4][2][3] = 0;
internal_loop_matrix[3][1][2][3] = 0;
internal_loop_matrix[3][2][2][3] = 0;
internal_loop_matrix[3][3][2][3] = 0;
internal_loop_matrix[3][4][2][3] = -7;
internal_loop_matrix[4][1][2][3] = -7;
internal_loop_matrix[4][2][2][3] = 0;
internal_loop_matrix[4][3][2][3] = -7;
internal_loop_matrix[4][4][2][3] = 0;
internal_loop_matrix[1][1][2][4] = 0;
internal_loop_matrix[1][2][2][4] = 0;
internal_loop_matrix[1][3][2][4] = 0;
internal_loop_matrix[1][4][2][4] = -7;
internal_loop_matrix[2][1][2][4] = 0;
internal_loop_matrix[2][2][2][4] = 0;
internal_loop_matrix[2][3][2][4] = 0;
internal_loop_matrix[2][4][2][4] = 0;
internal_loop_matrix[3][1][2][4] = 0;
internal_loop_matrix[3][2][2][4] = 0;
internal_loop_matrix[3][3][2][4] = 0;
internal_loop_matrix[3][4][2][4] = -7;
internal_loop_matrix[4][1][2][4] = -7;
internal_loop_matrix[4][2][2][4] = 0;
internal_loop_matrix[4][3][2][4] = -7;
internal_loop_matrix[4][4][2][4] = 0;
internal_loop_matrix[1][1][3][1] = 0;
internal_loop_matrix[1][2][3][1] = 0;
internal_loop_matrix[1][3][3][1] = 0;
internal_loop_matrix[1][4][3][1] = 4;
internal_loop_matrix[2][1][3][1] = 0;
internal_loop_matrix[2][2][3][1] = 0;
internal_loop_matrix[2][3][3][1] = 11;
internal_loop_matrix[2][4][3][1] = 0;
internal_loop_matrix[3][1][3][1] = 0;
internal_loop_matrix[3][2][3][1] = 11;
internal_loop_matrix[3][3][3][1] = 0;
internal_loop_matrix[3][4][3][1] = 4;
internal_loop_matrix[4][1][3][1] = 4;
internal_loop_matrix[4][2][3][1] = 0;
internal_loop_matrix[4][3][3][1] = 4;
internal_loop_matrix[4][4][3][1] = 0;
internal_loop_matrix[1][1][3][2] = 0;
internal_loop_matrix[1][2][3][2] = 0;
internal_loop_matrix[1][3][3][2] = 0;
internal_loop_matrix[1][4][3][2] = -7;
internal_loop_matrix[2][1][3][2] = 0;
internal_loop_matrix[2][2][3][2] = 0;
internal_loop_matrix[2][3][3][2] = 0;
internal_loop_matrix[2][4][3][2] = 0;
internal_loop_matrix[3][1][3][2] = 0;
internal_loop_matrix[3][2][3][2] = 0;
internal_loop_matrix[3][3][3][2] = 0;
internal_loop_matrix[3][4][3][2] = -7;
internal_loop_matrix[4][1][3][2] = -7;
internal_loop_matrix[4][2][3][2] = 0;
internal_loop_matrix[4][3][3][2] = -7;
internal_loop_matrix[4][4][3][2] = 0;
internal_loop_matrix[1][1][3][3] = 0;
internal_loop_matrix[1][2][3][3] = 0;
internal_loop_matrix[1][3][3][3] = 0;
internal_loop_matrix[1][4][3][3] = -7;
internal_loop_matrix[2][1][3][3] = 0;
internal_loop_matrix[2][2][3][3] = 0;
internal_loop_matrix[2][3][3][3] = 0;
internal_loop_matrix[2][4][3][3] = 0;
internal_loop_matrix[3][1][3][3] = 0;
internal_loop_matrix[3][2][3][3] = 0;
internal_loop_matrix[3][3][3][3] = 0;
internal_loop_matrix[3][4][3][3] = -7;
internal_loop_matrix[4][1][3][3] = -7;
internal_loop_matrix[4][2][3][3] = 0;
internal_loop_matrix[4][3][3][3] = -7;
internal_loop_matrix[4][4][3][3] = 0;
internal_loop_matrix[1][1][3][4] = 0;
internal_loop_matrix[1][2][3][4] = 0;
internal_loop_matrix[1][3][3][4] = 0;
internal_loop_matrix[1][4][3][4] = -7;
internal_loop_matrix[2][1][3][4] = 0;
internal_loop_matrix[2][2][3][4] = 0;
internal_loop_matrix[2][3][3][4] = 0;
internal_loop_matrix[2][4][3][4] = 0;
internal_loop_matrix[3][1][3][4] = 0;
internal_loop_matrix[3][2][3][4] = 0;
internal_loop_matrix[3][3][3][4] = 0;
internal_loop_matrix[3][4][3][4] = -7;
internal_loop_matrix[4][1][3][4] = -7;
internal_loop_matrix[4][2][3][4] = 0;
internal_loop_matrix[4][3][3][4] = -7;
internal_loop_matrix[4][4][3][4] = 0;
internal_loop_matrix[1][1][4][1] = 0;
internal_loop_matrix[1][2][4][1] = 0;
internal_loop_matrix[1][3][4][1] = 0;
internal_loop_matrix[1][4][4][1] = -7;
internal_loop_matrix[2][1][4][1] = 0;
internal_loop_matrix[2][2][4][1] = 0;
internal_loop_matrix[2][3][4][1] = 0;
internal_loop_matrix[2][4][4][1] = 0;
internal_loop_matrix[3][1][4][1] = 0;
internal_loop_matrix[3][2][4][1] = 0;
internal_loop_matrix[3][3][4][1] = 0;
internal_loop_matrix[3][4][4][1] = -7;
internal_loop_matrix[4][1][4][1] = -7;
internal_loop_matrix[4][2][4][1] = 0;
internal_loop_matrix[4][3][4][1] = -7;
internal_loop_matrix[4][4][4][1] = 0;
internal_loop_matrix[1][1][4][2] = 0;
internal_loop_matrix[1][2][4][2] = 0;
internal_loop_matrix[1][3][4][2] = 0;
internal_loop_matrix[1][4][4][2] = -7;
internal_loop_matrix[2][1][4][2] = 0;
internal_loop_matrix[2][2][4][2] = 0;
internal_loop_matrix[2][3][4][2] = 0;
internal_loop_matrix[2][4][4][2] = 0;
internal_loop_matrix[3][1][4][2] = 0;
internal_loop_matrix[3][2][4][2] = 0;
internal_loop_matrix[3][3][4][2] = 0;
internal_loop_matrix[3][4][4][2] = -7;
internal_loop_matrix[4][1][4][2] = -7;
internal_loop_matrix[4][2][4][2] = 0;
internal_loop_matrix[4][3][4][2] = -7;
internal_loop_matrix[4][4][4][2] = 0;
internal_loop_matrix[1][1][4][3] = 0;
internal_loop_matrix[1][2][4][3] = 0;
internal_loop_matrix[1][3][4][3] = 0;
internal_loop_matrix[1][4][4][3] = -7;
internal_loop_matrix[2][1][4][3] = 0;
internal_loop_matrix[2][2][4][3] = 0;
internal_loop_matrix[2][3][4][3] = 0;
internal_loop_matrix[2][4][4][3] = 0;
internal_loop_matrix[3][1][4][3] = 0;
internal_loop_matrix[3][2][4][3] = 0;
internal_loop_matrix[3][3][4][3] = 0;
internal_loop_matrix[3][4][4][3] = -7;
internal_loop_matrix[4][1][4][3] = -7;
internal_loop_matrix[4][2][4][3] = 0;
internal_loop_matrix[4][3][4][3] = -7;
internal_loop_matrix[4][4][4][3] = 0;
internal_loop_matrix[1][1][4][4] = 0;
internal_loop_matrix[1][2][4][4] = 0;
internal_loop_matrix[1][3][4][4] = 0;
internal_loop_matrix[1][4][4][4] = 0;
internal_loop_matrix[2][1][4][4] = 0;
internal_loop_matrix[2][2][4][4] = 0;
internal_loop_matrix[2][3][4][4] = 7;
internal_loop_matrix[2][4][4][4] = 0;
internal_loop_matrix[3][1][4][4] = 0;
internal_loop_matrix[3][2][4][4] = 7;
internal_loop_matrix[3][3][4][4] = 0;
internal_loop_matrix[3][4][4][4] = 0;
internal_loop_matrix[4][1][4][4] = 0;
internal_loop_matrix[4][2][4][4] = 0;
internal_loop_matrix[4][3][4][4] = 0;
internal_loop_matrix[4][4][4][4] = 0;
dangle5[1][1][1] = 0;
dangle5[1][2][1] = 0;
dangle5[1][3][1] = 0;
dangle5[1][4][1] = 3;
dangle5[2][1][1] = 0;
dangle5[2][2][1] = 0;
dangle5[2][3][1] = 2;
dangle5[2][4][1] = 0;
dangle5[3][1][1] = 0;
dangle5[3][2][1] = 5;
dangle5[3][3][1] = 0;
dangle5[3][4][1] = 3;
dangle5[4][1][1] = 3;
dangle5[4][2][1] = 0;
dangle5[4][3][1] = 3;
dangle5[4][4][1] = 0;
dangle5[1][1][2] = 0;
dangle5[1][2][2] = 0;
dangle5[1][3][2] = 0;
dangle5[1][4][2] = 1;
dangle5[2][1][2] = 0;
dangle5[2][2][2] = 0;
dangle5[2][3][2] = 3;
dangle5[2][4][2] = 0;
dangle5[3][1][2] = 0;
dangle5[3][2][2] = 3;
dangle5[3][3][2] = 0;
dangle5[3][4][2] = 1;
dangle5[4][1][2] = 3;
dangle5[4][2][2] = 0;
dangle5[4][3][2] = 3;
dangle5[4][4][2] = 0;
dangle5[1][1][3] = 0;
dangle5[1][2][3] = 0;
dangle5[1][3][3] = 0;
dangle5[1][4][3] = 2;
dangle5[2][1][3] = 0;
dangle5[2][2][3] = 0;
dangle5[2][3][3] = 0;
dangle5[2][4][3] = 0;
dangle5[3][1][3] = 0;
dangle5[3][2][3] = 2;
dangle5[3][3][3] = 0;
dangle5[3][4][3] = 2;
dangle5[4][1][3] = 4;
dangle5[4][2][3] = 0;
dangle5[4][3][3] = 4;
dangle5[4][4][3] = 0;
dangle5[1][1][4] = 0;
dangle5[1][2][4] = 0;
dangle5[1][3][4] = 0;
dangle5[1][4][4] = 2;
dangle5[2][1][4] = 0;
dangle5[2][2][4] = 0;
dangle5[2][3][4] = 0;
dangle5[2][4][4] = 0;
dangle5[3][1][4] = 0;
dangle5[3][2][4] = 1;
dangle5[3][3][4] = 0;
dangle5[3][4][4] = 2;
dangle5[4][1][4] = 2;
dangle5[4][2][4] = 0;
dangle5[4][3][4] = 2;
dangle5[4][4][4] = 0;
dangle3[1][1][1] = 0;
dangle3[1][2][1] = 0;
dangle3[1][3][1] = 0;
dangle3[1][4][1] = 8;
dangle3[2][1][1] = 0;
dangle3[2][2][1] = 0;
dangle3[2][3][1] = 17;
dangle3[2][4][1] = 0;
dangle3[3][1][1] = 0;
dangle3[3][2][1] = 11;
dangle3[3][3][1] = 0;
dangle3[3][4][1] = 8;
dangle3[4][1][1] = 7;
dangle3[4][2][1] = 0;
dangle3[4][3][1] = 7;
dangle3[4][4][1] = 0;
dangle3[1][1][2] = 0;
dangle3[1][2][2] = 0;
dangle3[1][3][2] = 0;
dangle3[1][4][2] = 5;
dangle3[2][1][2] = 0;
dangle3[2][2][2] = 0;
dangle3[2][3][2] = 8;
dangle3[2][4][2] = 0;
dangle3[3][1][2] = 0;
dangle3[3][2][2] = 4;
dangle3[3][3][2] = 0;
dangle3[3][4][2] = 5;
dangle3[4][1][2] = 1;
dangle3[4][2][2] = 0;
dangle3[4][3][2] = 1;
dangle3[4][4][2] = 0;
dangle3[1][1][3] = 0;
dangle3[1][2][3] = 0;
dangle3[1][3][3] = 0;
dangle3[1][4][3] = 8;
dangle3[2][1][3] = 0;
dangle3[2][2][3] = 0;
dangle3[2][3][3] = 17;
dangle3[2][4][3] = 0;
dangle3[3][1][3] = 0;
dangle3[3][2][3] = 13;
dangle3[3][3][3] = 0;
dangle3[3][4][3] = 8;
dangle3[4][1][3] = 7;
dangle3[4][2][3] = 0;
dangle3[4][3][3] = 7;
dangle3[4][4][3] = 0;
dangle3[1][1][4] = 0;
dangle3[1][2][4] = 0;
dangle3[1][3][4] = 0;
dangle3[1][4][4] = 6;
dangle3[2][1][4] = 0;
dangle3[2][2][4] = 0;
dangle3[2][3][4] = 12;
dangle3[2][4][4] = 0;
dangle3[3][1][4] = 0;
dangle3[3][2][4] = 6;
dangle3[3][3][4] = 0;
dangle3[3][4][4] = 6;
dangle3[4][1][4] = 1;
dangle3[4][2][4] = 0;
dangle3[4][3][4] = 1;
dangle3[4][4][4] = 0;
s_matrix[1][1][1][1] = 0;
s_matrix[1][2][1][1] = 0;
s_matrix[1][3][1][1] = 0;
s_matrix[1][4][1][1] = 0;
s_matrix[2][1][1][1] = 0;
s_matrix[2][2][1][1] = 0;
s_matrix[2][3][1][1] = 0;
s_matrix[2][4][1][1] = 0;
s_matrix[3][1][1][1] = 0;
s_matrix[3][2][1][1] = 0;
s_matrix[3][3][1][1] = 0;
s_matrix[3][4][1][1] = 0;
s_matrix[4][1][1][1] = 0;
s_matrix[4][2][1][1] = 0;
s_matrix[4][3][1][1] = 0;
s_matrix[4][4][1][1] = 0;
s_matrix[1][1][1][2] = 0;
s_matrix[1][2][1][2] = 0;
s_matrix[1][3][1][2] = 0;
s_matrix[1][4][1][2] = 0;
s_matrix[2][1][1][2] = 0;
s_matrix[2][2][1][2] = 0;
s_matrix[2][3][1][2] = 0;
s_matrix[2][4][1][2] = 0;
s_matrix[3][1][1][2] = 0;
s_matrix[3][2][1][2] = 0;
s_matrix[3][3][1][2] = 0;
s_matrix[3][4][1][2] = 0;
s_matrix[4][1][1][2] = 0;
s_matrix[4][2][1][2] = 0;
s_matrix[4][3][1][2] = 0;
s_matrix[4][4][1][2] = 0;
s_matrix[1][1][1][3] = 0;
s_matrix[1][2][1][3] = 0;
s_matrix[1][3][1][3] = 0;
s_matrix[1][4][1][3] = 0;
s_matrix[2][1][1][3] = 0;
s_matrix[2][2][1][3] = 0;
s_matrix[2][3][1][3] = 0;
s_matrix[2][4][1][3] = 0;
s_matrix[3][1][1][3] = 0;
s_matrix[3][2][1][3] = 0;
s_matrix[3][3][1][3] = 0;
s_matrix[3][4][1][3] = 0;
s_matrix[4][1][1][3] = 0;
s_matrix[4][2][1][3] = 0;
s_matrix[4][3][1][3] = 0;
s_matrix[4][4][1][3] = 0;
s_matrix[1][1][1][4] = 0;
s_matrix[1][2][1][4] = 0;
s_matrix[1][3][1][4] = 0;
s_matrix[1][4][1][4] = 11;
s_matrix[2][1][1][4] = 0;
s_matrix[2][2][1][4] = 0;
s_matrix[2][3][1][4] = 3;
s_matrix[2][4][1][4] = 0;
s_matrix[3][1][1][4] = 0;
s_matrix[3][2][1][4] = 5;
s_matrix[3][3][1][4] = 0;
s_matrix[3][4][1][4] = 0;
s_matrix[4][1][1][4] = 2;
s_matrix[4][2][1][4] = 0;
s_matrix[4][3][1][4] = -3;
s_matrix[4][4][1][4] = 0;
s_matrix[1][1][2][1] = 0;
s_matrix[1][2][2][1] = 0;
s_matrix[1][3][2][1] = 0;
s_matrix[1][4][2][1] = 0;
s_matrix[2][1][2][1] = 0;
s_matrix[2][2][2][1] = 0;
s_matrix[2][3][2][1] = 0;
s_matrix[2][4][2][1] = 0;
s_matrix[3][1][2][1] = 0;
s_matrix[3][2][2][1] = 0;
s_matrix[3][3][2][1] = 0;
s_matrix[3][4][2][1] = 0;
s_matrix[4][1][2][1] = 0;
s_matrix[4][2][2][1] = 0;
s_matrix[4][3][2][1] = 0;
s_matrix[4][4][2][1] = 0;
s_matrix[1][1][2][2] = 0;
s_matrix[1][2][2][2] = 0;
s_matrix[1][3][2][2] = 0;
s_matrix[1][4][2][2] = 0;
s_matrix[2][1][2][2] = 0;
s_matrix[2][2][2][2] = 0;
s_matrix[2][3][2][2] = 0;
s_matrix[2][4][2][2] = 0;
s_matrix[3][1][2][2] = 0;
s_matrix[3][2][2][2] = 0;
s_matrix[3][3][2][2] = 0;
s_matrix[3][4][2][2] = 0;
s_matrix[4][1][2][2] = 0;
s_matrix[4][2][2][2] = 0;
s_matrix[4][3][2][2] = 0;
s_matrix[4][4][2][2] = 0;
s_matrix[1][1][2][3] = 0;
s_matrix[1][2][2][3] = 0;
s_matrix[1][3][2][3] = 0;
s_matrix[1][4][2][3] = 3;
s_matrix[2][1][2][3] = 0;
s_matrix[2][2][2][3] = 0;
s_matrix[2][3][2][3] = 13;
s_matrix[2][4][2][3] = 0;
s_matrix[3][1][2][3] = 0;
s_matrix[3][2][2][3] = 5;
s_matrix[3][3][2][3] = 0;
s_matrix[3][4][2][3] = 0;
s_matrix[4][1][2][3] = 5;
s_matrix[4][2][2][3] = 0;
s_matrix[4][3][2][3] = 1;
s_matrix[4][4][2][3] = 0;
s_matrix[1][1][2][4] = 0;
s_matrix[1][2][2][4] = 0;
s_matrix[1][3][2][4] = 0;
s_matrix[1][4][2][4] = 0;
s_matrix[2][1][2][4] = 0;
s_matrix[2][2][2][4] = 0;
s_matrix[2][3][2][4] = 0;
s_matrix[2][4][2][4] = 0;
s_matrix[3][1][2][4] = 0;
s_matrix[3][2][2][4] = 0;
s_matrix[3][3][2][4] = 0;
s_matrix[3][4][2][4] = 0;
s_matrix[4][1][2][4] = 0;
s_matrix[4][2][2][4] = 0;
s_matrix[4][3][2][4] = 0;
s_matrix[4][4][2][4] = 0;
s_matrix[1][1][3][1] = 0;
s_matrix[1][2][3][1] = 0;
s_matrix[1][3][3][1] = 0;
s_matrix[1][4][3][1] = 0;
s_matrix[2][1][3][1] = 0;
s_matrix[2][2][3][1] = 0;
s_matrix[2][3][3][1] = 0;
s_matrix[2][4][3][1] = 0;
s_matrix[3][1][3][1] = 0;
s_matrix[3][2][3][1] = 0;
s_matrix[3][3][3][1] = 0;
s_matrix[3][4][3][1] = 0;
s_matrix[4][1][3][1] = 0;
s_matrix[4][2][3][1] = 0;
s_matrix[4][3][3][1] = 0;
s_matrix[4][4][3][1] = 0;
s_matrix[1][1][3][2] = 0;
s_matrix[1][2][3][2] = 0;
s_matrix[1][3][3][2] = 0;
s_matrix[1][4][3][2] = 5;
s_matrix[2][1][3][2] = 0;
s_matrix[2][2][3][2] = 0;
s_matrix[2][3][3][2] = 5;
s_matrix[2][4][3][2] = 0;
s_matrix[3][1][3][2] = 0;
s_matrix[3][2][3][2] = 14;
s_matrix[3][3][3][2] = 0;
s_matrix[3][4][3][2] = 2;
s_matrix[4][1][3][2] = 2;
s_matrix[4][2][3][2] = 0;
s_matrix[4][3][3][2] = -1;
s_matrix[4][4][3][2] = 0;
s_matrix[1][1][3][3] = 0;
s_matrix[1][2][3][3] = 0;
s_matrix[1][3][3][3] = 0;
s_matrix[1][4][3][3] = 0;
s_matrix[2][1][3][3] = 0;
s_matrix[2][2][3][3] = 0;
s_matrix[2][3][3][3] = 0;
s_matrix[2][4][3][3] = 0;
s_matrix[3][1][3][3] = 0;
s_matrix[3][2][3][3] = 0;
s_matrix[3][3][3][3] = 0;
s_matrix[3][4][3][3] = 0;
s_matrix[4][1][3][3] = 0;
s_matrix[4][2][3][3] = 0;
s_matrix[4][3][3][3] = 0;
s_matrix[4][4][3][3] = 0;
s_matrix[1][1][3][4] = 0;
s_matrix[1][2][3][4] = 0;
s_matrix[1][3][3][4] = 0;
s_matrix[1][4][3][4] = 0;
s_matrix[2][1][3][4] = 0;
s_matrix[2][2][3][4] = 0;
s_matrix[2][3][3][4] = 0;
s_matrix[2][4][3][4] = 0;
s_matrix[3][1][3][4] = 0;
s_matrix[3][2][3][4] = 2;
s_matrix[3][3][3][4] = 0;
s_matrix[3][4][3][4] = 8;
s_matrix[4][1][3][4] = -1;
s_matrix[4][2][3][4] = 0;
s_matrix[4][3][3][4] = -4;
s_matrix[4][4][3][4] = 0;
s_matrix[1][1][4][1] = 0;
s_matrix[1][2][4][1] = 0;
s_matrix[1][3][4][1] = 0;
s_matrix[1][4][4][1] = 2;
s_matrix[2][1][4][1] = 0;
s_matrix[2][2][4][1] = 0;
s_matrix[2][3][4][1] = 5;
s_matrix[2][4][4][1] = 0;
s_matrix[3][1][4][1] = 0;
s_matrix[3][2][4][1] = 2;
s_matrix[3][3][4][1] = 0;
s_matrix[3][4][4][1] = -1;
s_matrix[4][1][4][1] = 12;
s_matrix[4][2][4][1] = 0;
s_matrix[4][3][4][1] = 0;
s_matrix[4][4][4][1] = 0;
s_matrix[1][1][4][2] = 0;
s_matrix[1][2][4][2] = 0;
s_matrix[1][3][4][2] = 0;
s_matrix[1][4][4][2] = 0;
s_matrix[2][1][4][2] = 0;
s_matrix[2][2][4][2] = 0;
s_matrix[2][3][4][2] = 0;
s_matrix[2][4][4][2] = 0;
s_matrix[3][1][4][2] = 0;
s_matrix[3][2][4][2] = 0;
s_matrix[3][3][4][2] = 0;
s_matrix[3][4][4][2] = 0;
s_matrix[4][1][4][2] = 0;
s_matrix[4][2][4][2] = 0;
s_matrix[4][3][4][2] = 0;
s_matrix[4][4][4][2] = 0;
s_matrix[1][1][4][3] = 0;
s_matrix[1][2][4][3] = 0;
s_matrix[1][3][4][3] = 0;
s_matrix[1][4][4][3] = -3;
s_matrix[2][1][4][3] = 0;
s_matrix[2][2][4][3] = 0;
s_matrix[2][3][4][3] = 1;
s_matrix[2][4][4][3] = 0;
s_matrix[3][1][4][3] = 0;
s_matrix[3][2][4][3] = -1;
s_matrix[3][3][4][3] = 0;
s_matrix[3][4][4][3] = -4;
s_matrix[4][1][4][3] = 0;
s_matrix[4][2][4][3] = 0;
s_matrix[4][3][4][3] = 8;
s_matrix[4][4][4][3] = 0;
s_matrix[1][1][4][4] = 0;
s_matrix[1][2][4][4] = 0;
s_matrix[1][3][4][4] = 0;
s_matrix[1][4][4][4] = 0;
s_matrix[2][1][4][4] = 0;
s_matrix[2][2][4][4] = 0;
s_matrix[2][3][4][4] = 0;
s_matrix[2][4][4][4] = 0;
s_matrix[3][1][4][4] = 0;
s_matrix[3][2][4][4] = 0;
s_matrix[3][3][4][4] = 0;
s_matrix[3][4][4][4] = 0;
s_matrix[4][1][4][4] = 0;
s_matrix[4][2][4][4] = 0;
s_matrix[4][3][4][4] = 0;
s_matrix[4][4][4][4] = 0;
i_matrix[1][1] = 19;
i_matrix[2][1] = -22;
i_matrix[3][1] = -18;
i_matrix[4][1] = -19;
i_matrix[1][0] = gap_open;
i_matrix[1][2] = -22;
i_matrix[2][2] = 11;
i_matrix[3][2] = -25;
i_matrix[4][2] = -15;
i_matrix[2][0] = gap_open;
i_matrix[1][3] = -18;
i_matrix[2][3] = -25;
i_matrix[3][3] = 9;
i_matrix[4][3] = -20;
i_matrix[3][0] = gap_open;
i_matrix[1][4] = -19;
i_matrix[2][4] = -15;
i_matrix[3][4] = -20;
i_matrix[4][4] = 13;
i_matrix[4][0] = gap_open;
i_matrix[0][0] = 0;
i_matrix[0][1] = gap_open;
i_matrix[0][2] = gap_open;
i_matrix[0][3] = gap_open;
i_matrix[0][4] = gap_open;
index = 0; hpLength[index] = 0; bulgeLength[index] = 0; ilLength[index] = 0;
index = 1; hpLength[index] = -57; bulgeLength[index] = -38; ilLength[index] = -17;
index = 2; hpLength[index] = -57; bulgeLength[index] = -28; ilLength[index] = -17;
index = 3; hpLength[index] = -57; bulgeLength[index] = -32; ilLength[index] = -17;
index = 4; hpLength[index] = -56; bulgeLength[index] = -36; ilLength[index] = -17;
index = 5; hpLength[index] = -56; bulgeLength[index] = -40; ilLength[index] = -18;
index = 6; hpLength[index] = -54; bulgeLength[index] = -44; ilLength[index] = -20;
index = 7; hpLength[index] = -59; bulgeLength[index] = -46; ilLength[index] = -22;
index = 8; hpLength[index] = -56; bulgeLength[index] = -47; ilLength[index] = -23;
index = 9; hpLength[index] = -64; bulgeLength[index] = -48; ilLength[index] = -24;
index = 10; hpLength[index] = -65; bulgeLength[index] = -49; ilLength[index] = -25;
index = 11; hpLength[index] = -66; bulgeLength[index] = -50; ilLength[index] = -26;
index = 12; hpLength[index] = -67; bulgeLength[index] = -51; ilLength[index] = -27;
index = 13; hpLength[index] = -68; bulgeLength[index] = -52; ilLength[index] = -28;
index = 14; hpLength[index] = -69; bulgeLength[index] = -53; ilLength[index] = -29;
index = 15; hpLength[index] = -69; bulgeLength[index] = -54; ilLength[index] = -30;
index = 16; hpLength[index] = -70; bulgeLength[index] = -54; ilLength[index] = -30;
index = 17; hpLength[index] = -71; bulgeLength[index] = -55; ilLength[index] = -31;
index = 18; hpLength[index] = -71; bulgeLength[index] = -55; ilLength[index] = -31;
index = 19; hpLength[index] = -72; bulgeLength[index] = -56; ilLength[index] = -32;
index = 20; hpLength[index] = -72; bulgeLength[index] = -57; ilLength[index] = -33;
index = 21; hpLength[index] = -73; bulgeLength[index] = -57; ilLength[index] = -33;
index = 22; hpLength[index] = -73; bulgeLength[index] = -58; ilLength[index] = -34;
index = 23; hpLength[index] = -74; bulgeLength[index] = -58; ilLength[index] = -34;
index = 24; hpLength[index] = -74; bulgeLength[index] = -58; ilLength[index] = -34;
index = 25; hpLength[index] = -75; bulgeLength[index] = -59; ilLength[index] = -35;
index = 26; hpLength[index] = -75; bulgeLength[index] = -59; ilLength[index] = -35;
index = 27; hpLength[index] = -75; bulgeLength[index] = -60; ilLength[index] = -36;
index = 28; hpLength[index] = -76; bulgeLength[index] = -60; ilLength[index] = -36;
index = 29; hpLength[index] = -76; bulgeLength[index] = -60; ilLength[index] = -36;
index = 30; hpLength[index] = -77; bulgeLength[index] = -61; ilLength[index] = -37;
	setGap4(s_matrix);
	setGap4(stack_matrix);
	setGap4(hp_close_matrix);
	setGap4(internal_loop_matrix);
	setGap3(dangle5);
	setGap3(dangle3);
}

#endif /* SCOREMATRIX */
