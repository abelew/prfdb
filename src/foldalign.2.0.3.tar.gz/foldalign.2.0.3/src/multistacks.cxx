#ifndef MULTISTACK
#define MULTISTACK
#include "stack.cxx" // The stack class

/******************************************************************************
*                                                                             *
*   Copyright 2004 - 2005 Jakob Hull Havgaard, hull@bioinf.kvl.dk             *
*                                                                             *
*   This file is part of Foldalign                                            *
*                                                                             *
*   Foldalign is free software; you can redistribute it and/or modify         *
*   it under the terms of the GNU General Public License as published by      *
*   the Free Software Foundation; either version 2 of the License, or         *
*   (at your option) any later version.                                       *
*                                                                             *
*   Foldalign is distributed in the hope that it will be useful,              *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of            *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
*   GNU General Public License for more details.                              *
*                                                                             *
*   You should have received a copy of the GNU General Public License         *
*   along with Foldalign; if not, write to the Free Software                  *
*   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
*                                                                             *
******************************************************************************/


// Written by Jakob Hull Havgaard, 2004, hull@bioinf.kvl.dk.
// This class coordinates a number of stacks.
// The class is quite unsafe from over- and underflows
template< class items, int n_stacks>
class multistacks {
private:
	stack<items>* stacks[n_stacks]; // The stacks
	int next; // The current stack size
	int prev; // The fifo read position
	
public:
	multistacks(int size) {
		next = 0; // The stacks are empty
		prev = -1;
		for(int n=0; n<n_stacks; n++) {
			stacks[n] = new stack<items>(size);
		}
	};
	
	void push(items in[]) { // Store the values
		for(int n=0; n<n_stacks; n++) {
			stacks[n]->push(in[n]);
		}
		next++;
	};
	
	void pop(items out[]) { // Get the values
		next--;
		for(int n=0; n<n_stacks; n++) {
			out[n] = stacks[n]->pop();
		}
	};
	
	void fifo(items out[]) { // Get the values
		prev++;
		for(int n=0; n<n_stacks; n++) {
			out[n] = stacks[n]->fifo();
		}
	};

	int getsize() { // Return the current stack size
		return(next);
	};

	int getfifosize() { // Return the current stack size
		return(next-prev-1);
	};
	~multistacks() {
		for(int n=0; n<n_stacks; n++) {
			delete stacks[n];
		}
	}

};
#endif /*MULTISTACK*/
