#ifndef RESULTS
#define RESULTS
#include <iostream>


/******************************************************************************
*                                                                             *
*   Copyright 2004 - 2005 Jakob Hull Havgaard, hull@bioinf.kvl.dk             *
*                                                                             *
*   This file is part of Foldalign                                            *
*                                                                             *
*   Foldalign is free software; you can redistribute it and/or modify         *
*   it under the terms of the GNU General Public License as published by      *
*   the Free Software Foundation; either version 2 of the License, or         *
*   (at your option) any later version.                                       *
*                                                                             *
*   Foldalign is distributed in the hope that it will be useful,              *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of            *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
*   GNU General Public License for more details.                              *
*                                                                             *
*   You should have received a copy of the GNU General Public License         *
*   along with Foldalign; if not, write to the Free Software                  *
*   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
*                                                                             *
******************************************************************************/

//************************************************************
// This class strores the results from a Foldalign alignment *
// Currently only the score and position of the best hit is  *
// stored                                                    *
// Written by Jakob Hull Havgaard 2004                       *
// hull@bioinf.kvl.dk                                        *
//************************************************************

template<class type>
class results {
public:
// Set up the result object (allocate memory for 4 position parameters)
	results() {positions = new int[4];};
// Return the score
	type getScore() const {return score;};
// Return the positions through a reference
	void getPos(int pos[4])  const {for(int i=0; i<4; i++) {pos[i] = positions[i];}};
// Save a score and its position
	void store(type new_score, int i,int Wi,int k,int Wk);
// Clean up
	~results() {delete[] positions;};
private:
	type score;       // Holds the best score
	int* positions;  // Array that holds the position of the best score
};

template<class type> inline void results<type>::store(type new_score, int i,int Wi,int k,int Wk) {
	score = new_score;
	positions[0] = i;
	positions[1] = Wi;
	positions[2] = k;
	positions[3] = Wk;
}
#endif /*RESULTS*/
