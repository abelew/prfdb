#ifndef SEQUENCE
#define SEQUENCE
#include <string>
#include <fstream>
#include <iostream>
#include "scorematrix.cxx"


/******************************************************************************
*                                                                             *
*   Copyright 2004 - 2005 Jakob Hull Havgaard, hull@bioinf.kvl.dk             *
*                                                                             *
*   This file is part of Foldalign                                            *
*                                                                             *
*   Foldalign is free software; you can redistribute it and/or modify         *
*   it under the terms of the GNU General Public License as published by      *
*   the Free Software Foundation; either version 2 of the License, or         *
*   (at your option) any later version.                                       *
*                                                                             *
*   Foldalign is distributed in the hope that it will be useful,              *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of            *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
*   GNU General Public License for more details.                              *
*                                                                             *
*   You should have received a copy of the GNU General Public License         *
*   along with Foldalign; if not, write to the Free Software                  *
*   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
*                                                                             *
******************************************************************************/

//*********************************************************************
// This class holds a sequence. The sequence can be supplied directly *
// or read from a fasta file                                          *
// Written by Jakob Hull Havgaard 2004, hull@bioinf.kvl.dk            *
//*********************************************************************

class sequence { // Stores a RNA sequence with gaps.
public:
	sequence(const sequence& s);

	sequence& operator=(const sequence& s);
	
	// Read the sequence from a fasta file
	inline sequence(std::string& filename, scorematrix<int>& score, int groupNum);

	// Store the sequence without reading a file
	inline sequence(std::string& sek_name, std::string& sek, scorematrix<int>& score, int groupNum=1, std::string com = "", std::string filename="<commandline>");// Store the sequence

	// Return the value at position pos (position 1..len allowed)
	int getPos(int pos) const {return (seq[pos]);};

	// Return the length of the sequence
	int getLength() const {return len;};

	// Return the sequence name
	std::string getName() const {return name;}

	// Return the sequence comment
	std::string getComment() const {return comment;}

	// Return the sequence filename
	std::string getFilename() const {return fil;}

	// Return the sequence group number
	int getGroupNumber() const {return group;}

	~sequence() {delete[] seq;};

private:
	int len;  		// The sequence length
	std::string name; 	// Sequence name
	int* seq; 		// The sequence
	const int group; 	// The sequence's group number
	std::string comment; 	// Store the sequence comment
	std::string fil; 	// Name of the file the sequence orginated from
	sequence(); 		//No default constructor
};

inline sequence::sequence(std::string& filename, scorematrix<int>& score, int groupNum=1): group(groupNum) {
	fil = filename;
	std::string line;
	std::string sequence = "";
	int pos;
	std::ifstream file;
	file.open(filename.c_str(),ios::in);
	if (file.fail()) {
	std::cerr << "It is not possible to open the fasta file " << filename << "\n";
		throw -1;
	}
	std::getline(file,line);
	if (line.substr(0,1).compare(">")) {
		cerr << "File " << filename << " is not in fasta format. Aborting" << endl;
		throw -1;
	}
	pos = line.find(" ");
	pos--;
	name = line.substr(1, pos);
	if (pos > 0) {
		int start = pos+2;
		pos = line.find_first_not_of(" ", start);
		comment = line.substr((pos));}
	else {comment = "";}
	std::getline(file,line);
	while (!file.fail()) {
		if (!line.substr(0,1).compare(">")) {break;}
		sequence+=line;
		std::getline(file,line);
	}
	len = sequence.length();
	seq = new int[len+1];
	seq[0] = 0;
	for(int n=0; n < len; n++) { // For all positions in the sequence
		seq[n+1] = score.alfa(sequence[n]);
	}
}

inline sequence::sequence(std::string& sek_name, std::string& sek, scorematrix<int>& score, int groupNum, std::string com, std::string filename): name(sek_name), group(groupNum), comment(com), fil(filename)  { // Store the sequence
	len = sek.length(); // Get the length and store it
	seq = new int[len+1]; // Set the size of seq
	seq[0] = 0; // The 0 position is a gap
	for(int n=0; n < len; n++) { // For all positions in the sequence
		seq[n+1] = score.alfa(sek[n]);
	}
}

inline sequence& sequence::operator=(const sequence& s) {
	if (&s != this) {
		comment = s.getComment();
		name = s.getName();
		len = s.getLength();
		delete seq;
		seq = new int[len+1];
		for(int n=0; n <= len; n++) {
			seq[n] = s.getPos(n);
		}
	}
	return *this;
}

inline sequence::sequence(const sequence& s) : group(1) {
	len = s.getLength();
	name = s.getName();
	comment = s.getComment();
	seq = new int[len+1];
	for(int n=0; n <= len; n++) {
		seq[n] = s.getPos(n);
	}
}	
#endif /* SEQUENCE */
