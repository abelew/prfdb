#ifndef FOLD
#define FOLD
#include <iostream>
#include <math.h>
#include "output.cxx"
#include "helper.cxx"
#include "matrix_D.cxx"
#include "multistacks.cxx"
#include "arguments.cxx"
#include "results.cxx"


/******************************************************************************
*                                                                             *
*   Copyright 2004 - 2005 Jakob Hull Havgaard, hull@bioinf.kvl.dk             *
*                                                                             *
*   This file is part of Foldalign                                            *
*                                                                             *
*   Foldalign is free software; you can redistribute it and/or modify         *
*   it under the terms of the GNU General Public License as published by      *
*   the Free Software Foundation; either version 2 of the License, or         *
*   (at your option) any later version.                                       *
*                                                                             *
*   Foldalign is distributed in the hope that it will be useful,              *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of            *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
*   GNU General Public License for more details.                              *
*                                                                             *
*   You should have received a copy of the GNU General Public License         *
*   along with Foldalign; if not, write to the Free Software                  *
*   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
*                                                                             *
******************************************************************************/

//****************************************************************//
// This class implements a sliding window version of              //
// the FOLDALIGN algorithm.                                       //
// Based on:                                                      //
// Gorodkin et al. Nucleic Acids Reseacrch 1997 25 (18) 3724--32  //
// Implemented by Jakob Hull Havgaard  hull@bioinf.kvl.dk         //
// Spring 2003                                                    //
// Revised, expanded and reimplemented spring 2004                //
//****************************************************************//
class fold {
public:
//*************************************
// The constructor intialize the dp matrix,
// the arguments and sequences.

	inline fold(sequence* one, sequence* two, arguments& argu, scorematrix<int>& score, matrix_D<int>*& D_mat, matrix_D<char>*& S_mat, matrix_D<short>*& L_mat);

//*************************************
// The alignment part of the algorithm
// builds up the dp matrix D
// The subsequence 
// begin_1 --> end_1
// in the first sequence is aligned to subsequence
// begin_2 --> end_2
// in the second sequence

	inline void run_align(int begin_1, int end_1, int begin_2, int end_2, results<int>*& r);
	
//*************************************
// Nothing special about the destructor

	inline ~fold();

private:
//*************************************
// The global variables

	sequence* seq_1; // Stores the sequences
	sequence* seq_2;
	arguments& arg;
	scorematrix<int>& s_matrix; // Contains the score matrixs
	matrix_D<int>* D; // The dynamic programing matrix
	matrix_D<char>* S; // The state matrix
	matrix_D<short>* L; // The state matrix
	int len_1; // The real length of the sequences
	int len_2;
	int new_len_1; // The length of the subsequences being aligned
	int new_len_2;
	int new_begin_1; // The current subsequence start coordinate
	int new_begin_2;
	int new_end_1;   // The current subsequence end coordinate
	int new_end_2;
	int best_score; // The stores the starting point for the
	int* best_pos;  // Alignment coordinates
	int delta; // Parameters
	int lambda;
	int min_loop;
	bool plot_score;
	bool backtrack;
	int chunk_size;
	int gap_bonus;       // Affine gap bonus
	int mblNuc;          // The cost of adding a new nucleotide to a mbl
	string version;// Holds the version number of foldalign
	string id;           // Alignment ID
	string score_matrix; // The name of the score_matrix
	bool nobranch;       // Nobranch (true) or branch (false) version
	int mbl;           // The cost of opening a multibranch loop
	int mblAffine;     // The cost for adding a stem to multibranch loop
	int branch_cost;   // The largest of mbl and mblAffine
	static const int big_neg = -114748364; // A large negative number
	static const int min_hp_loop_bonus_length = 4;  // A hairpin-loop has to be longer than this -1 before the hairpin close bonus is added
	bool flip; // Is the order of the sequences switched
	output* out; //Object containing the functions for outputing
	static const int p2calc_size = 70;
	int (fold::*p2calc[p2calc_size])(const int, const int, const int, const int, const int, const int, const int, const int, char&, int);
	int (fold::*p2calc_c1[p2calc_size])(const int, const int, const int, const int, const int, const int, const int, const int, char&, int);
	int (fold::*p2calc_c2[p2calc_size])(const int, const int, const int, const int, const int, const int, const int, const int, char&, int);
	int (fold::*p2calc_d1[p2calc_size])(const int, const int, const int, const int, const int, const int, const int, const int, char&, int);
	int (fold::*p2calc_d2[p2calc_size])(const int, const int, const int, const int, const int, const int, const int, const int, char&, int);
	int (fold::*p2calc_f1[p2calc_size])(const int, const int, const int, const int, const int, const int, const int, const int, char&, int);
	int (fold::*p2calc_f2[p2calc_size])(const int, const int, const int, const int, const int, const int, const int, const int, char&, int);
	int (fold::*p2calc_f3[p2calc_size])(const int, const int, const int, const int, const int, const int, const int, const int, char&, int);
	int (fold::*p2calc_f4[p2calc_size])(const int, const int, const int, const int, const int, const int, const int, const int, char&, int);
	int size_I[p2calc_size];
	int size_J[p2calc_size];
	int size_K[p2calc_size];
	int size_L[p2calc_size];
	int coord_I[p2calc_size];
	int coord_J[p2calc_size];
	int coord_K[p2calc_size];
	int coord_L[p2calc_size];
	bool branch_left[p2calc_size];
	bool branch_right[p2calc_size];
//*****************************************************
// These functions are used in the dynamic programing *
//*****************************************************

//*************************************
// align() does the alignment. Controled by run_align()

	inline void align(const int begin_1, const int end_1, const int begin_2, const int end_2, results<int>*& r, const bool lastRun = false);

//*************************************
// Functions used by align()
// calc() this function calculates the "normal" score
// the calc scores are calculated by base
// init_calc_d() is used when there can not be basepairing
// the d scores are calculated by no_basepair
// init_calc_f12() is used when the first two f cases are legal
// init_calc_f34() is used when the last two f cases are legal
// the f scores are calculated by gap
// init_calc_branch is used when branching is legal
// calc and the init functions call no

	inline int calc(const int i, const int Wi, const int k, const int Wk, char& state, int max);
	inline int calc_nobranch(const int i, const int Wi, const int k, const int Wk, char& state, int max);
	inline int functionerror(const int i, const int j, const int k, const int l, const int ii, const int jj, const int kk, const int ll, char& s, int m) {int st = S->getD(ii,jj,kk,ll); cerr << "Foldalign program error: Wrong state used for calling function. State: " << st << " Coordinates: " << ii << ", " << (ii+jj) << ", " << kk << ", " << (kk+ll) << endl; throw -1;}
	inline int bigneg(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {return max;}

	inline char foldstore(int& i, int& Wi, int& k, int& Wk, int& v, char& state, results<int>*& r, results<int>*& r_local);
	inline char foldstore2(int& i, int& Wi, int& k, int& Wk, int& v, char& state, results<int>*& r, results<int>*& r_local);
	inline char foldstore3(int& i, int& Wi, int& k, int& Wk, int& v, char& state, results<int>*& r, results<int>*& r_local);
	inline char foldstore4(int& i, int& Wi, int& k, int& Wk, int& v, char& state, results<int>*& r, results<int>*& r_local);
	inline int init_calc_d(const int i,const int Wi,const int k,const int Wk, char& state, int max); // Calculate the D and the state
	inline int init_calc_hpmla(const int i,const int Wi,const int k,const int Wk, char& state, int max); // Calculate the D and the state
	inline int init_calc_hpf12(const int i,const int Wi,const int k,const int Wk, char& state, int max); // Calculate the D and the state
	inline int init_calc_hpf34(const int i,const int Wi,const int k,const int Wk, char& state, int max); // Calculate the D and the state
	inline int branch(const int i,const int Wi,const int k,const int Wk, char& state, int max);// Calculate the D and the state
	inline int branchCore(const int i, const int Wi, const int k,const int Wk, const int m, const int n, int& dang5, int& dang3);// Calculate the D and the state

	inline int hairpin_end(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state, const int max);
	inline int hairpin(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state, const int max);
	inline int hairpinIK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int hairpinJL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int second_hpbp(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state, const int max);
	inline int bulge(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgestem(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeJ(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeI(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeJL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeIK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeIK2bulge(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeJL2bulge(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeI2bulge(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeK2bulge(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeI2bulgegap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeK2bulgegap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeJ2bulge(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeL2bulge(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeJ2bulgegap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int bulgeL2bulgegap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int internalLoop(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int stem(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int second_ilbp(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);

	inline int stem2bulgeJL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int stem2bulgeIK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int hairpinI(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int hairpinK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int hairpinJ(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int hairpinL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int hairpinIgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int hairpinKgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int hairpinJgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int hairpinLgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int internalIK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int internalJL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int internalI(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int internalK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int internalJ(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int internalL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int internalIgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int internalKgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int internalJgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int internalLgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int stem2bulgeI(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int stem2bulgeK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int stem2bulgeJ(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int stem2bulgeL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);

	inline int mblLast(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblDS(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblSSLgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblSSJgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblSSKgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblSSIgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblSSL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblSSJ(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblSSK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblSSI(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblSSIK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblSSJL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblSSKpMbl(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblSSKpMblgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblSSIpMbl(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblSSIpMblgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int mblSSIKpMbl(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);

	inline void quickback(int& length_I, int&  length_J, int& length_K, int& length_L, int ii, int Wii, int kk, int Wkk);
	inline void backBranch(const int i, const int Wi, const int k, const int Wk, int& di, int& dj, int& dk, int& dl);

	inline char quickcore(int& length_I, int&  length_J, int& length_K, int& length_L, int& ii, int& Wii, int& kk, int& Wkk, char& state, short len);
	inline char quickbackBulge(int& length_I, int&  length_J, int& length_K, int& length_L, int& ii, int& Wii, int& kk, int& Wkk);

	inline int stem2singleBpI(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int stem2singleBpK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int singleBpK2stem(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);
	inline int singleBpI2stem(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max);

	inline void interOpen(const int ii, const int Wii, const int kk, const int Wkk, int& res);
	inline int newIlLength(int i, int j, int k, int l, int lii, int ljj, int lkk, int lll);
	inline int newHpLength(const int i, const int j, const int li, const int lj);

	template<class type> inline void init_array(type array[], int size, type val);
	inline int maxres(const int res, const int max, const char new_state, char& state);

	inline void init_p2calc();

};

#ifdef AARHUS // This piece of code is needed by the Xlc compiler on AIX systems
const int fold::big_neg;
const int fold::min_hp_loop_bonus_length;
const int p2calc_size;
#endif /* AARHUS */


//******************************************
// The constructor                         *
//******************************************

inline fold::fold(sequence* one, sequence* two, arguments& argu, scorematrix<int>& score, matrix_D<int>*& D_mat, matrix_D<char>*& S_mat, matrix_D<short>*& L_mat) : seq_1(one), seq_2(two), arg(argu), s_matrix(score), D(D_mat), S(S_mat), L(L_mat), version(argu.stringopt("version")) {
// init_p2calc initializes the array of function pointers which controls which
// function is called when the previous state was <number>
// The function is at the very bottom of the code
	init_p2calc();

// Initialise objects and variabels

	// From the argument object
	min_loop = arg.intopt("-min_loop")+1;
	delta = arg.intopt("-max_diff");
	lambda = arg.intopt("-max_length");
	chunk_size = arg.intopt("-chunk_size");
	id = arg.stringopt("-ID");
	score_matrix = arg.stringopt("-score_matrix");
	nobranch = arg.boolopt("-nobranch");
	plot_score = arg.boolopt("-plot_score");
	flip = arg.boolopt("switch");

	// From the score matrix
	mblAffine = 2*s_matrix.getMblAffine(); // This score is multiplied by two to account for branching in both sequences
	mbl=2*s_matrix.getMbl(); // This score is multiplied by two to account for branching in both sequences
	mblNuc = s_matrix.getMblNuc();
	gap_bonus = s_matrix.getGap();

	out = new output(arg, seq_1, seq_2, s_matrix);

	new_len_1 = len_1 = seq_1->getLength(); // Store the length of the sequences
	new_len_2 = len_2 = seq_2->getLength();

}

//***************************************************
// The functions in this section do the alignment   *
//***************************************************

inline void fold::run_align(int begin_1, int end_1, int begin_2, int end_2, results<int>*& r) {
// Splits the shortest sequence into chuncks of size 2*lambda and call align.
	r->store(big_neg, 0, 0, 0, 0);
	int stop = end_2 - lambda;
	if (stop < begin_2) {stop = begin_2+1;}
	if (plot_score || arg.boolopt("-all_scores")) {
			out->localscorehead();
	}
	else {if (!arg.boolopt("realigning")) {out->head();}} // Do not print if is the realignment step
	bool lastRun = false;
	for(int begin = begin_2; begin <= stop; begin+=2*chunk_size-lambda) {
		int end = begin +2*chunk_size-1;
		if (end >= end_2) {end = end_2; lastRun = true;}
		align(begin_1, end_1, begin, end, r, lastRun);
	}
	if (plot_score || arg.boolopt("-all_scores")) {
		std::cout <<"; ******************************************************************************" << endl;
		if (!arg.boolopt("-no_backtrack")) {out->head();}
	}
}

//***********************************************************
// This function do the alignment

inline void fold::align(const int begin_1, const int end_1, const int begin_2, const int end_2, results<int>*& r, const bool lastRun) {
// Align two sequence chunks

	new_end_1 = len_1+1;
	new_end_2 = len_2+1;
	new_begin_1 = 1;
	new_begin_2 = 1;
	new_len_1 = end_1 - begin_1 +1;
	new_len_2 = end_2 - begin_2 +1;
	D->setEndI(end_1);
	D->setEndK(end_2);
	D->setStartK(begin_2);
	S->setEndI(end_1);
	S->setEndK(end_2);
	S->setStartK(begin_2);
	L->setEndI(end_1);
	L->setEndK(end_2);
	L->setStartK(begin_2);
// Pointers to the functions used in the branching version
	int (fold::*p2calc)(const int, const int, const int, const int, char&, int) = &fold::calc;
	if (nobranch) {
// Change the function pointers if the nobranched version is required
		p2calc = &fold::calc_nobranch;
	}
// Use the correct foldcore function to ensure that r_local stores the correct coordinates
	char (fold::*p2foldstore)(int&, int&, int&, int&, int&, char&, results<int>*&, results<int>*&) = &fold::foldstore;
	if (flip) {p2foldstore = &fold::foldstore2;}
	if (arg.boolopt("-all_scores")) {if (flip) {p2foldstore = &fold::foldstore4;} else {p2foldstore = &fold::foldstore3;}}
	results<int>* r_local = new results<int>(); // Object for storing the best local alignment(s)
	r_local->store(big_neg, 0, 0, 0, 0);
	for(int i=end_1; i >= begin_1; i--) { // The i position
		for(int k=end_2; k >= begin_2; k--) { // The k position

//*******************************
// Wi = 0, Wk = 0
#ifdef DEBUG
cerr << "1 ********************* " << i << "," << 0 << " " << k << "," <<0 <<  " **********************" << endl;	
#endif /* DEBUG */
			int Wi = 0;
			int Wk = 0;
			int v = s_matrix.getInit(seq_1->getPos(i),seq_2->getPos(k));
			v+=s_matrix.getHpLength(1,1);
			char state = 0;
			// The first length is intiallized to zero
			L->setD(i,Wi, k, Wk, 0);
			(this->*p2foldstore)(i,Wi,k,Wk,v,state, r, r_local);
//*******************************
// Wi = 0, 0 < Wk < delta +1
			int end = (delta+1 < lambda ? delta+1 : lambda);
			if ((k + end) > begin_2+new_len_2) { end = begin_2+new_len_2 - k;}
			for(Wk = 1; Wk < end; Wk++) {
#ifdef DEBUG
cerr << "2 ********************* " << i << "," << Wi << " " << k << "," <<0 <<  " **********************" << endl;
#endif /* DEBUG */
				v=big_neg;
				v=init_calc_hpf34(i,Wi,k,Wk,state,v);
				(this->*p2foldstore)(i,Wi,k,Wk,v,state, r, r_local);
			}

//*******************************
// Wi = 1
			Wi=1;
			if ((i+Wi) < (begin_1+ new_len_1)) {
				if (delta > 0) {
	//*******************************
	// Wk = 0
#ifdef DEBUG
cerr << "3 ********************* " << i << "," << Wi << " " << k << "," <<0 <<  " **********************" << endl;
#endif /* DEBUG */
					Wk=0;
					v=big_neg;
					v=init_calc_hpf12(i,Wi,k,Wk,state,v);
					(this->*p2foldstore)(i,Wi,k,Wk,v,state, r, r_local);
				}
	//*******************************
	// Wk = 1
				Wk=1;
				if ((k+Wk) < (begin_2 + new_len_2)) {
					v=big_neg;
					if (min_loop == 0) {
						v=s_matrix.getInit(seq_1->getPos(i),seq_2->getPos(k))+s_matrix.getInit(seq_1->getPos(i+Wi),seq_2->getPos(k+Wk));
						// The first length is intiallized to zero
						L->setD(i,Wi, k, Wk, 0);
						if (s_matrix.getBasepair(seq_1->getPos(i),seq_2->getPos(k)) && s_matrix.getBasepair(seq_1->getPos(i+Wi),seq_2->getPos(k+Wk))) {state=1;} // if both subsequences base-pairs
						else {state = 0;}
					}
					v=init_calc_d(i,Wi,k,Wk,state,v);
					(this->*p2foldstore)(i,Wi,k,Wk,v,state, r, r_local);
					end = Wi + delta +1;
					if (end > lambda) {end=lambda;}
					if ((k + end) > begin_2 + new_len_2) { end = new_len_2 +begin_2 - k;}
					for(Wk = 2; Wk < end; Wk++) {
	//*******************************
	// 1 < Wk < min_loop + delta +1
#ifdef DEBUG
cerr << "4 ********************* " << i << "," << Wi << " " << k << "," <<Wk <<  " **********************" << endl;	
#endif /* DEBUG */
						v=big_neg;
						v=init_calc_d(i,Wi,k,Wk,state,v);
						(this->*p2foldstore)(i,Wi,k,Wk,v,state, r, r_local);
					}
				}
			}
//*******************************
// 2 < Wi < min_loop
			int i_end = min_loop;
			if ((i+i_end) > begin_1+ new_len_1) {i_end = begin_1 + new_len_1 - i;}
			for(Wi = 2; Wi < i_end; Wi++) {
				int begin = Wi - delta;
				int end = ((Wi +delta+1 ) < lambda ? Wi +delta +1 : lambda);
				if ((k + end) > begin_2 + new_len_2) { end = new_len_2 +begin_2 - k;}
				if ((begin <= 0) && (end > 0)) {
	//*******************************
	// Wk = 0
#ifdef DEBUG
cerr << "5 ********************* " << i << "," << Wi << " " << k << "," <<0 <<  " **********************" << endl;
#endif /* DEBUG */
					Wk = 0;
					v=big_neg;
					v=init_calc_hpf12(i,Wi,k,Wk,state,v);
					(this->*p2foldstore)(i,Wi,k,Wk,v,state, r, r_local);
					begin = 1;
				}
				if ((begin == 1) && (end > 1)) {
	//*******************************
	// Wk = 1
#ifdef DEBUG
cerr << "6 ********************* " << i << "," << Wi << " " << k << "," <<0 <<  " **********************" << endl;
#endif /* DEBUG */
					Wk = 1;
					v=big_neg;
					v=init_calc_d(i,Wi,k,Wk,state,v);
					(this->*p2foldstore)(i,Wi,k,Wk,v,state, r, r_local);
					begin = 2;
				}
				for(Wk = begin; Wk < end; Wk++) {
	//*******************************
	// 0 < Wk < min_loop + delta +1
#ifdef DEBUG
cerr << "7 ********************* " << i << "," << Wi << " " << k << "," <<Wk <<  " **********************" << endl;	
#endif /* DEBUG */
					v=big_neg;
					v=init_calc_hpmla(i,Wi,k,Wk,state,v);
					(this->*p2foldstore)(i,Wi,k,Wk,v,state, r, r_local);
				}
			}
//*******************************
// min_loop =< Wi < min_loop +delta +1
			i_end = min_loop +delta+1;
			if (i_end >= lambda) {i_end = lambda;}
			if ((i+i_end) >= (new_len_1+begin_1)) { i_end = begin_1+new_len_1 - i;}
			for(Wi = min_loop; Wi < i_end; Wi++) {
				int begin = Wi - delta;
				int end = Wi + delta +1; // min_loop;
				if ((k + end) > begin_2 + new_len_2) { end = new_len_2 + begin_2- k;}
				if (end > (lambda)) {end = lambda;}
				if ((begin <= 0) && (end > 0)) {
	//*******************************
	// Wk = 0
					Wk = 0;
#ifdef DEBUG
cerr << "8 ********************* " << i << "," << Wi << " " << k << "," <<Wk <<  " **********************" << endl;	
#endif /* DEBUG */
					v=big_neg;
					v=init_calc_hpf12(i,Wi,k,Wk,state,v);
					(this->*p2foldstore)(i,Wi,k,Wk,v,state, r, r_local);
					begin = 1;
				}
				if ((begin == 1) && (end > 1)) {
	//*******************************
	// Wk = 1
					Wk = 1;
#ifdef DEBUG
cerr << "9 ********************* " << i << "," << Wi << " " << k << "," <<Wk <<  " **********************" << endl;	
#endif /* DEBUG */
					v=big_neg;
					v=init_calc_d(i,Wi,k,Wk,state,v);
					(this->*p2foldstore)(i,Wi,k,Wk,v,state, r, r_local);
					begin++;
				}
				if (end > min_loop) {
					for(Wk = begin; Wk < min_loop; Wk++) {
	//*******************************
	// 0 < Wk < min_loop
#ifdef DEBUG
cerr << "10 ********************* " << i << "," << Wi << " " << k << "," <<Wk <<  " **********************" << endl;	
#endif /* DEBUG */
						v=big_neg;
						v=init_calc_hpmla(i,Wi,k,Wk,state,v);
						(this->*p2foldstore)(i,Wi,k,Wk,v,state, r, r_local);
					}
					for(Wk = min_loop; Wk < end; Wk++) {
	//*******************************
	// min_loop =< Wk < min_loop+delta+1
#ifdef DEBUG
cerr << "11 ********************* " << i << "," << Wi << " " << k << "," <<Wk <<  " **********************" << endl;	
#endif /* DEBUG */
						v=big_neg;
						v=(this->*p2calc)(i,Wi,k,Wk,state,v);
						(this->*p2foldstore)(i,Wi,k,Wk,v,state, r, r_local);
					}
				}
				else {
					for(Wk = begin; Wk < end; Wk++) {
	//*******************************
	// 0 < Wk < end < min_loop
#ifdef DEBUG
cerr << "12 ********************* " << i << "," << Wi << " " << k << "," <<Wk <<  " **********************" << endl;	
#endif /* DEBUG */
						v=big_neg;
						v=init_calc_hpmla(i,Wi,k,Wk,state,v);
						(this->*p2foldstore)(i,Wi,k,Wk,v,state, r, r_local);
					}
				}
			}
			int i_start = min_loop + delta+1;
			i_end = lambda;
			if (i+i_end > (new_len_1+begin_1)) { i_end = begin_1+new_len_1 - i;}
			for(Wi = i_start; Wi < i_end; Wi++) {
//*******************************
// min_loop + delta+1 =< Wi < lambda
				int begin = Wi - delta;
				int end = ((Wi+delta+1) < lambda ? Wi+delta+1 : lambda);
				if ((k + end) > begin_2 + new_len_2) { end = new_len_2 + begin_2- k;}
				for(Wk = begin; Wk < end; Wk++) {
	//*******************************
	// 1 < Wk < Wi + delta +1
#ifdef DEBUG
cerr << "13 ********************* " << i << "," << Wi << " " << k << "," <<Wk <<  " **********************" << endl;	
#endif /* DEBUG */
					v=big_neg;
					v=(this->*p2calc)(i,Wi,k,Wk,state,v);
					(this->*p2foldstore)(i,Wi,k,Wk,v,state, r, r_local);
				}
			}
			if (plot_score) {
				if (k < (end_2 -lambda+1)) {
					int local_max_score = r_local->getScore();// best_score holds the score
					int local_pos[4];
					r_local->getPos(local_pos);
					std::cout << "LS ";
					std::cout << local_pos[0] << " " << local_pos[0]+local_pos[1] << " " << local_pos[2] << " " << local_pos[2]+local_pos[3] << " " << local_max_score << endl;
				}
				else { if (lastRun) {
					int local_max_score = r_local->getScore();// best_score holds the score
					int local_pos[4];// = r_local->getPos();
					r_local->getPos(local_pos);
					std::cout << "LS ";
					std::cout << local_pos[0] << " " << local_pos[0]+local_pos[1] << " " << local_pos[2] << " " << local_pos[2]+local_pos[3] << " " << local_max_score  << endl;
				}}
				r_local->store(big_neg, 0, 0, 0, 0);
			}
		}
	//	D->dump_pos();
		if (i > begin_1) {
			D->shiftI(i);
			S->shiftI(i);
			L->shiftI(i);
		}
	}
	delete r_local;
}


//************************************
// The four functions foldstore -> foldcore4
// are the same functions with the exception
// that the coordinates (i,Wi) and (k,Wk) are
// switched in r_local in foldcore2 and 4. foldcore2 and 4
// stores (k,Wk), (i,Wi)
// And functions 3 and 4 prints out the position, S and D
// before storing them (the -all_scores option)

inline char fold::foldstore(int& i, int& Wi, int& k, int& Wk, int& v, char& state, results<int>*& r, results<int>*& r_local) {
	// Store the D and S values, calculates and stores the L value.
	// Check if the score is a new local and global max
	D->setD(i, Wi, k, Wk, v);
	S->setD(i, Wi, k, Wk, state);
	int bi = i + coord_I[state];
	int bj = Wi + coord_J[state];
	int bk = k + coord_K[state];
	int bl = Wk + coord_L[state];
	char old_state = S->getD(bi, bj, bk, bl);
	// If the state has not change then L is increased
	// else it is set to one
	if (state == old_state) {L->setD(i,Wi, k, Wk, L->getD(bi, bj, bk, bl)+1);}
	else {L->setD(i,Wi, k, Wk, 1);}
	// If the score is better than the local score then update the local score
	if (v > r_local->getScore()) { // Traceback starts with the highest scoring D
		r_local->store(v, i, Wi, k, Wk);
		// If the score is better than the global score then update the global
		// score
		if (v > r->getScore()) { // Traceback starts with the highest scoring D
			r->store(v, i, Wi, k, Wk);
		}
	}
	return state;
}

inline char fold::foldstore2(int& i, int& Wi, int& k, int& Wk, int& v, char& state, results<int>*& r, results<int>*& r_local) {
	// Store the D and S values, calculates and stores the L value.
	// Check if the score is a new local and global max
	// This function is used when the sequences are flipped
	D->setD(i, Wi, k, Wk, v);
	S->setD(i, Wi, k, Wk, state);
	int bi = i + coord_I[state];
	int bj = Wi + coord_J[state];
	int bk = k + coord_K[state];
	int bl = Wk + coord_L[state];
	char old_state = S->getD(bi, bj, bk, bl);
	if (state == old_state) {L->setD(i,Wi, k, Wk, L->getD(bi, bj, bk, bl)+1);}
	else {L->setD(i,Wi, k, Wk, 1);}
	if (v > r_local->getScore()) { // Traceback starts with the highest scoring D
		r_local->store(v, k, Wk, i, Wi);
		if (v > r->getScore()) { // Traceback starts with the highest scoring D
			r->store(v, i, Wi, k, Wk);
		}
	}
	return state;
}

inline char fold::foldstore3(int& i, int& Wi, int& k, int& Wk, int& v, char& state, results<int>*& r, results<int>*& r_local) {
	// Prints the extra information when option -all_scores are used
	cout << "; AS " << i << " " << (i+Wi) << " " << k << " " << (k+Wk)<< " Score " << v;
	int st = state;
	cout << " State " << st << endl;
	foldstore(i, Wi, k, Wk, v, state, r, r_local);
	return state;
}

inline char fold::foldstore4(int& i, int& Wi, int& k, int& Wk, int& v, char& state, results<int>*& r, results<int>*& r_local) {
	// Prints the extra information when option -all_scores are used and the
	// sequences are flipped
	cout << "; AS " << k << " " << (k+Wk) << " " << i << " " << (i+Wi) << " Score " << v;
	int st = state;
	cout << " State " << st << endl;
	foldstore2(i, Wi, k, Wk, v, state, r, r_local);
	return state;
}

//***************************************
// The score calculation controller functions
// Which of the score calculation functions
// are to be called with which parameters

inline int fold::calc(const int i, const int Wi, const int k, const int Wk, char& state, int max) {// Calculate the D and the state
	// This function calculates the scores of all different cases.
	// To see the list of cases please see Gorodkin 1997 or 2001 NAR articles
	// The scores are calculated by different functions depended on the previous
	// state. The list of functions are held in arrays defined at the end of this
	// file.

	// ii, Wii, kk and Wkk are the coordinates of the previous state
	int ii=i, Wii=Wi, kk=k, Wkk=Wk;
	// These are the nucleotides at the i, i+Wi, k and k+Wk positions
	const int i_pos = seq_1->getPos(i);
	const int j_pos = seq_1->getPos(i+Wi);
	const int k_pos = seq_2->getPos(k);
	const int l_pos = seq_2->getPos(k+Wk);
	// a The letters are same as in Gorodkin 2001 NAR, and in the other methods
	// Calculate the coordinates of the previous state
	ii = i+1; Wii = Wi-2; kk=k+1; Wkk=Wk-2; // The new indicies
	// Choose the function to calculate the score based on the previous state
	max = (this->*p2calc[S->getD(ii,Wii,kk,Wkk)])(i_pos,j_pos,k_pos,l_pos,ii,Wii,kk,Wkk,state,max);
	// c
	ii = i+1; Wii = Wi-2; kk=k; Wkk=Wk; // The new indicies
	max = (this->*p2calc_c1[S->getD(ii,Wii,kk,Wkk)])(i_pos,j_pos,0,0,ii,Wii,kk,Wkk,state,max);
	ii = i; Wii = Wi; kk=k+1; Wkk=Wk-2; // The new indicies
	max = (this->*p2calc_c2[S->getD(ii,Wii,kk,Wkk)])(0,0,k_pos,l_pos,ii,Wii,kk,Wkk,state,max);
	//d and f cases are handled in a similar way by the other functions
	max = init_calc_d(i,Wi,k,Wk,state,max);
	// Branching
	max = branch(i,Wi,k,Wk,state, max); // Do branch
	return(max);
}

inline int fold::init_calc_d(const int i,const int Wi,const int k,const int Wk, char& state, int max) {// Calculate the D and the state
	// This function calculates scores for the two d cases and then calls the
	// two f cases functions.
	// For further comments see the calc function
	const int i_pos = seq_1->getPos(i);
	const int j_pos = seq_1->getPos(i+Wi);
	const int k_pos = seq_2->getPos(k);
	const int l_pos = seq_2->getPos(k+Wk);
	int ii=i, Wii=Wi, kk=k, Wkk=Wk; // More indicies to use
// d
	ii = (i+1); Wii = (Wi-1); kk=(k+1); Wkk=(Wk-1);
	max = (this->*p2calc_d1[S->getD(ii,Wii,kk,Wkk)])(i_pos,0,k_pos,0,ii,Wii,kk,Wkk,state,max);
	ii = (i); Wii = (Wi-1); kk=(k); Wkk=(Wk-1);
	max = (this->*p2calc_d2[S->getD(ii,Wii,kk,Wkk)])(0,j_pos,0,l_pos,ii,Wii,kk,Wkk,state,max);
// Call f
	max = init_calc_hpf12(i,Wi,k,Wk,state,max); // Do first half of f
	max = init_calc_hpf34(i,Wi,k,Wk,state,max); // Do second half of f
	return max;
}

inline int fold::init_calc_hpmla(const int i,const int Wi,const int k,const int Wk, char& state, int max) {// Calculate the D and the state
	// This function is used when it is possible to elongate an alignment on both
	// sides, but base-pairing is not allowed. It is only used with hairpin
	// states
	// For further comments see the calc function
	const int i_pos = seq_1->getPos(i);
	const int j_pos = seq_1->getPos(i+Wi);
	const int k_pos = seq_2->getPos(k);
	const int l_pos = seq_2->getPos(k+Wk);
	int ii=i+1, Wii=Wi-2, kk=k+1, Wkk=Wk-2; // More indicies to use
// a
	max = hairpin(i_pos, j_pos, k_pos, l_pos, ii, Wii, kk, Wkk, state, max);
// d
	max = init_calc_d(i,Wi,k,Wk,state,max);
	return max;
}

inline int fold::init_calc_hpf12(const int i,const int Wi,const int k,const int Wk, char& state, int max) {// Calculate the D and the state
	// This function handles the calculation of the f1 and f2 case
	// For further comments see the calc function
	int ii=i, Wii=Wi, kk=k, Wkk=Wk; // More indicies to use
	const int i_pos = seq_1->getPos(i);
	const int j_pos = seq_1->getPos(i+Wi);
	ii=(i+1); Wii=(Wi-1);
	max = (this->*p2calc_f1[S->getD(ii,Wii,kk,Wkk)])(i_pos,0,0,0,ii,Wii,kk,Wkk,state,max);
	ii=(i); Wii=(Wi-1);
	max = (this->*p2calc_f2[S->getD(ii,Wii,kk,Wkk)])(0,j_pos,0,0,ii,Wii,kk,Wkk,state,max);
	return max;
}

inline int fold::init_calc_hpf34(const int i,const int Wi,const int k,const int Wk, char& state, int max) {// Calculate the D and the state
	// This function handles the calculation of the f3 and f4 case
	// For further comments see the calc function
	int ii=i, Wii=Wi, kk=k, Wkk=Wk; // More indicies to use
	const int k_pos = seq_2->getPos(k);
	const int l_pos = seq_2->getPos(k+Wk);
	kk=(k+1); Wkk=(Wk-1);
	max = (this->*p2calc_f3[S->getD(ii,Wii,kk,Wkk)])(0,0,k_pos,0,ii,Wii,kk,Wkk,state,max);
	kk=(k); Wkk=(Wk-1);
	max = (this->*p2calc_f4[S->getD(ii,Wii,kk,Wkk)])(0,0,0,l_pos,ii,Wii,kk,Wkk,state,max);
	return max;
}

inline int fold::branch(const int i,const int Wi,const int k,const int Wk, char& state, int max) {// Calculate the D and the state
// Handle branchpoint
	const int size_diff = Wk - Wi; // The difference in size between the two windows
	// bottom and top are used to make sure that the length difference between 
	// a substructure in the two sequences is no more than delta
	int bottom = size_diff;
	int top = 0;
	if (size_diff <= 0) {
		bottom = 0;
		top = size_diff;
	}
	// The minimum length of a branch is min_loop plus two base-pairs
	// In the constructor min_loop is increased with one, therefor only
	// three and not four is added here
	const int min = min_loop +3;
	const int nuc_i = seq_1->getPos(i);
	// Loop of the possible branch positions in the first sequence
	for(int m = min; m < Wi-min+1; m++) { // For all positions between i and j
		// Unless positions i and m basepair there can be no branch point here
		// this speeds up the algorithm.
		if (!s_matrix.getBasepair(nuc_i,seq_1->getPos(i+m))) {continue;}
		// Calculate the range in which a branch point can be placed in the second
		// sequence
		int n_start = (((m-delta+bottom)>min) ? (m-delta+bottom) : min);
		int n_stop  = (((m+delta+top)<(Wk-min)) ? (m+delta+top) : (Wk-min));
		// Loop of the possible branch positions in the second sequence
		for(int n = n_start; n < n_stop+1; n++) {// For all positions between k and l
			// Check that the left side of the branch point is a stem
			// and that the right side ends with a basepair (this is checked
			// with branch left and right arrays. These are true for allowed states
			// and false otherwise
			if (!(branch_left[S->getD(i,m,k,n)] && branch_right[S->getD((i+m+1),(Wi-m-1),(k+n+1),(Wk-n-1))])) {continue;}
			int dummy1, dummy2; // Dummy variables. The values stored in these variables are not used for any thing
			int res = branchCore(i, Wi, k, Wk, m, n, dummy1, dummy2);
			// Check the score against the old max
			max = maxres(res, max, 40, state);
		}
	}
	return max;
}

inline int fold::branchCore(const int i, const int Wi, const int k,const int Wk, const int m, const int n, int& dang5, int& dang3) {// Calculate the D and the state
	// BranchCore calculates the score of a branch point

	// The following variables holds the coordinates of the right part of
	// branch point
	int pi=i+m+1;
	int pj=Wi-m-1;
	int pk=k+n+1;
	int pl=Wk-n-1;
	// The state of the right part of the branch point
	char rs = S->getD_us(pi,pj,pk,pl);
	// A backtrack on the right side of the branch point is performed to
	// find the end stem or branch point coordinates
	while((rs != 63) && (rs != 40)) {
		// Using the L matrix should speed up the backtrack
		short len = L->getD(pi, pj, pk, pl);
		// Update the coordinates
		pi = pi + len*coord_I[rs];
		pj = pj + len*coord_J[rs];
		pk = pk + len*coord_K[rs];
		pl = pl + len*coord_L[rs];
		// Get the new state
		rs = S->getD(pi, pj, pk, pl);
	}
	// The length of the two single strand regions between the two mbl
	// stems
	const int singleLengthI = pi-i-m-1;
	const int singleLengthK = pk-k-n-1;
	// Calculate the score of the branch site
	// Add the score for the two substructures
	int res = D->getD_us(i,m,k,n);
	res+= D->getD_us((i+m+1),(Wi-m-1),(k+n+1),(Wk-n-1));
	// Add the loop close cost for non GC base-pairs on the left stem
	res+= s_matrix.getNonGCEnd(seq_1->getPos(i), seq_1->getPos(i+m), seq_2->getPos(k), seq_2->getPos(k+n));
	// Handle dangles between the two stems
	int d5 = s_matrix.getDangle5(seq_1->getPos(pi), seq_1->getPos(pi+pj), seq_1->getPos(pi-1), seq_2->getPos(pk), seq_2->getPos(pk+pl), seq_2->getPos(pk-1));
	int d3 = s_matrix.getDangle3(seq_1->getPos(i), seq_1->getPos(i+m), seq_1->getPos(i+m+1), seq_2->getPos(k), seq_2->getPos(k+n), seq_2->getPos(k+n+1));
	res+=mblAffine;
	if (rs == 63) {
		// Since the state is the stem state and not a branch state
		// the mbl cost has to be mbl and not mbl affine
		// Add the loop close cost for non GC base-pairs on the right stem
		res+= s_matrix.getNonGCEnd(seq_1->getPos(pi), seq_1->getPos(pi+pj), seq_2->getPos(pk), seq_2->getPos(pk+pl));
		// Add the score for the single nucleotide regions
		res+= singleLengthI*mblNuc;
		res+= singleLengthK*mblNuc;
		// Remove the internal loop length cost
		// It has to be the internal loop length cost eventhough the state is a
		// bulge state because branch states are treated like internal
		// loops until they closed by a basepair
		res-=s_matrix.getIntLoopLength(singleLengthI,0)+s_matrix.getIntLoopLength(singleLengthK,0);
		// The internal loop opening cost has to be removed if the two
		// stems are seperated by any nucleotides
		if (S->getD_us((i+m+1),(Wi-m-1),(k+n+1),(Wk-n-1)) != 63) {
			if (((pi+pj+1) < len_1+1) && ((pk+pl+1) < len_2+1)) {
				res-=s_matrix.getIntLoopOpen(seq_1->getPos(pi),seq_1->getPos(pi+pj),seq_1->getPos(pi-1),seq_1->getPos(pi+pj+1),seq_2->getPos(pk),seq_2->getPos(pk+pl),seq_2->getPos(pk-1),seq_2->getPos(pk+pl+1));
			}
		}
		// Handle the dangles
		// if the distance between the stems is one 
		// nucleotide in atleast one sequence only one dangle is added
		// if its longer both dangles are added
		if (((singleLengthI == 1) && (singleLengthK >= 1)) || ((singleLengthI >= 1) && (singleLengthK == 1))) {
			// In this case only one dangle is allowed
			if (d3 > d5) {res+=d3;}
			else {res+=d5;}
		}
		else if ((singleLengthI > 1) && (singleLengthK > 1)) {
			//add both dangles
			res+=d5+d3;
		}
	}
	else {
		// Handle the stem branchpoint case
		// Add the affine multibranch cost
		// Handle the dangles dependend on the distance between the
		// branch points
		if ((singleLengthI == 0) || (singleLengthK == 0)) {
			// There is no 5 dangle base stacking and the bonus is subtracted
			res-=d5;
		}
		else if (((singleLengthI == 1) && (singleLengthK >= 1)) || ((singleLengthI >= 1) && (singleLengthK == 1))) {
			// In this case only the best dangle is allowed
			if (d3 > d5) {
				res-=d5;
				res+=d3;
			}
		}
		if ((singleLengthI > 1) && (singleLengthK > 1)) {
			// The d5 dangle has already been added
			res+=d3;
		}
	}
	// Add the outside dangles if possible
	dang5 = dang3 = 0;
	if ((i>1) && (k>1)) {
		// 5'
		dang5 = s_matrix.getDangle5(seq_1->getPos(i), seq_1->getPos(i+m), seq_1->getPos(i-1), seq_2->getPos(k), seq_2->getPos(k+n), seq_2->getPos(k-1));
		res+=dang5;
	}
	if (((pi+pj+1) < len_1+1) && ((pk+pl+1) < len_2+1)) {
		// 3'  
		dang3 = s_matrix.getDangle3(seq_1->getPos(pi), seq_1->getPos(pi+pj), seq_1->getPos(pi+pj+1), seq_2->getPos(pk), seq_2->getPos(pk+pl), seq_2->getPos(pk+pl+1));
		res+=dang3;
	}
	return res;
}

//************************************
// The nobranching functions

inline int fold::calc_nobranch(const int i, const int Wi, const int k, const int Wk, char& state, int max) {// Calculate the D and the state
	// ii, Wii, kk and Wkk are the coordinates of the previous state
	int ii=i, Wii=Wi, kk=k, Wkk=Wk; // More indicies to use
	// These are the nucleotides at the i, i+Wi, k and k+Wk positions
	const int i_pos = seq_1->getPos(i);
	const int j_pos = seq_1->getPos(i+Wi);
	const int k_pos = seq_2->getPos(k);
	const int l_pos = seq_2->getPos(k+Wk);
// a The letters are same as in Gorodkin 2001 NAR, and in the other methods
	// Calculate the coordinates of the previous state
	ii = i+1; Wii = Wi-2; kk=k+1; Wkk=Wk-2; // The new indicies
	// Choose the function to calculate the score based on the previous state
	max = (this->*p2calc[S->getD(ii,Wii,kk,Wkk)])(i_pos,j_pos,k_pos,l_pos,ii,Wii,kk,Wkk,state,max);
// c
	ii = i+1; Wii = Wi-2; kk=k; Wkk=Wk; // The new indicies
	max = (this->*p2calc_c1[S->getD(ii,Wii,kk,Wkk)])(i_pos,j_pos,k_pos,l_pos,ii,Wii,kk,Wkk,state,max);
	ii = i; Wii = Wi; kk=k+1; Wkk=Wk-2; // The new indicies
	max = (this->*p2calc_c2[S->getD(ii,Wii,kk,Wkk)])(i_pos,j_pos,k_pos,l_pos,ii,Wii,kk,Wkk,state,max);
//d The rest of the cases (d and f) are calculate by other functions
	max = init_calc_d(i,Wi,k,Wk,state,max);
	// There is no branch step here
	return(max);
}

//************************************
// The score calculation functions
	

//************************************
// The following group of functions 
// calculates the scores for hairpin 
// loops

inline int fold::hairpin(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state, const int max) {
	// Two nucleotides in both sequences
	// No possiblity for base-pairing
	// Se also the comments in the hairpinIK
	// function
	int res = D->getD(ii,Wii,kk,Wkk);
	res += s_matrix.getInit(i,k) + s_matrix.getInit(j,l);
	res +=newHpLength(Wii, Wkk, 2,2);
	return maxres(res, max, 3, state);
}

inline int fold::hairpin_end(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state, const int max) {
	// Two nucleotides in both sequences
	// If the nucleotides in both sequences
	// base-pairs then it is a potential
	// end of loop
	// Se also the comments in the hairpinIK
	// function
	int res = D->getD(ii,Wii,kk,Wkk);
	res += s_matrix.getInit(i,k) + s_matrix.getInit(j,l);
	res +=newHpLength(Wii, Wkk, 2,2);
	if (res > max) {
		if (s_matrix.getBasepair(i,j) && s_matrix.getBasepair(k,l)) {state=5;} // if both subsequences base-pairs
		else {state = 4;}
		return res;
	}
	return max;
}

inline int fold::hairpinIK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// One nucleotide in each sequence
	// downstream of the previous aligned
	// nucleotides

	// Get the old score
	int res = D->getD(ii,Wii,kk,Wkk);
	// Add the similarity score
	res += s_matrix.getInit(i,k);
	// Add the length dependent cost
	// 1,1 indicates that the alignment
	// grows with one nucleotide in each
	// sequence
	res +=newHpLength(Wii, Wkk, 1,1);
	// If the score is better than the previous
	// max then max = res and state = 2
	return maxres(res, max, 2, state);
}

inline int fold::hairpinJL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// One nucleotide in each sequence
	// upstream of the previous aligned
	// nucleotides
	// Se also the comments in the hairpinIK
	// function
	int res = D->getD(ii,Wii,kk,Wkk);
	res += s_matrix.getInit(j,l);
	res +=newHpLength(Wii, Wkk, 1,1);
	return maxres(res, max, 3, state);
}

inline int fold::hairpinI(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// One upstream nucleotide in the first
	// sequence (also known as the I sequence)
	// Gap cost is already added in scorematrix
	// Se also the comments in the hairpinIK
	// function
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=newHpLength(Wii, Wkk, 1, 0);
	return maxres(res,max,6,state);
}

inline int fold::hairpinK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// One upstream nucleotide in the second
	// sequence (also known as the K sequence)
	// Gap cost is already added in scorematrix
	// Se also the comments in the hairpinIK
	// function
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=newHpLength(Wii, Wkk, 0, 1);
	return maxres(res,max,8,state);
}

inline int fold::hairpinJ(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// One downstream nucleotide in the first
	// sequence (also known as the I sequence)
	// Gap cost is already added in scorematrix
	// Se also the comments in the hairpinIK
	// function
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=newHpLength(Wii, Wkk, 1, 0);
	return maxres(res,max,7,state);
}

inline int fold::hairpinL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// One downstream nucleotide in the second
	// sequence (also known as the K sequence)
	// Gap cost is already added in scorematrix
	// Se also the comments in the hairpinIK
	// function
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=newHpLength(Wii, Wkk, 0, 1);
	return maxres(res,max,9,state);
}

inline int fold::hairpinIgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// One upstream nucleotide in the first
	// sequence (also known as the I sequence)
	// with an affine gap
	// Se also the comments in the hairpinIK
	// function
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=newHpLength(Wii, Wkk, 1, 0);
	// The affine gap bonus is added
	res+=gap_bonus;
	return maxres(res,max,6,state);
}

inline int fold::hairpinKgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// One upstream nucleotide in the second
	// sequence (also known as the K sequence)
	// with an affine gap
	// Se also the comments in the hairpinIK
	// function
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=newHpLength(Wii, Wkk, 0, 1);
	// The affine gap bonus is added
	res+=gap_bonus;
	return maxres(res,max,8,state);
}

inline int fold::hairpinJgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// One downstream nucleotide in the first
	// sequence (also known as the I sequence)
	// with an affine gap
	// Se also the comments in the hairpinIK
	// function
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=newHpLength(Wii, Wkk, 1, 0);
	// The affine gap bonus is added
	res+=gap_bonus;
	return maxres(res,max,7,state);
}

inline int fold::hairpinLgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// One downstream nucleotide in the second
	// sequence (also known as the K sequence)
	// with an affine gap
	// Se also the comments in the hairpinIK
	// function
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=newHpLength(Wii, Wkk, 0, 1);
	// The affine gap bonus is added
	res+=gap_bonus;
	return maxres(res,max,9,state);
}

inline int fold::second_hpbp(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// This function is called if the previous
	// nucleotides in both sequence base-pairs
	// and are potentially the first in stem
	// closing the base-pair.
	// If the nucleotides in both stems
	// base-pairs then the hairpin loop is closed
	// and a stem of length 2 (maybe longer) is 
	// started
	// If the nucleotides do not both base-pairs
	// then the previous potential base-pair is an
	// isolated base-pair and is part of the loop.
	// The loop continues as if nothing had happend.
	int res = D->getD(ii,Wii,kk,Wkk);
	if(s_matrix.getBasepair(i,j) && s_matrix.getBasepair(k,l)) {
		// Add the substitution score
		res+=s_matrix.getScore(i,j,k,l);
		// Add the stacking scores
		res+=s_matrix.getStack(i,j,seq_1->getPos(ii),seq_1->getPos(ii+Wii), k, l,seq_2->getPos(kk),seq_2->getPos(kk+Wkk)); // and the previous position was a double base-pair add stacking bonus
		// Add the previous base-paired substitution score
		res+=s_matrix.getScore(seq_1->getPos(ii),seq_1->getPos(ii+Wii), seq_2->getPos(kk),seq_2->getPos(kk+Wkk));
		// Substrackt the previous non-base-paired substitution score
		res-=(s_matrix.getInit(seq_1->getPos(ii),seq_2->getPos(kk)) + s_matrix.getInit(seq_1->getPos(ii+Wii),seq_2->getPos(kk+Wkk)));
		// Added the hairpin loop closure cost if the loop is longer than 3 nucleotides
		// The cost is not depended on the previous-previous state just the
		// Nucleotides
		if ((Wii > min_hp_loop_bonus_length) && (Wkk > min_hp_loop_bonus_length)) {
			res+=(s_matrix.getHpClose(seq_1->getPos(ii),seq_1->getPos(ii+Wii),seq_1->getPos(ii+1),seq_1->getPos(ii+Wii-1),seq_2->getPos(kk),seq_2->getPos(kk+Wkk),seq_2->getPos(kk+1),seq_2->getPos(kk+Wkk-1)));
		}
		// Add the cost for the true length of the loop
		res+=s_matrix.getHpLength(Wii-1, Wkk-1);
		// Subtract the hp length cost for the first base-pair
		res-=s_matrix.getHpLength(Wii+1, Wkk+1);
		return maxres(res, max, 63, state);
	}
	// Add the similarity cost
	res += s_matrix.getInit(i,k) + s_matrix.getInit(j,l);
	// Add the length cost
	res +=newHpLength(Wii, Wkk, 2,2);
	return maxres(res, max, 4, state);
}

inline int fold::newHpLength(int i, int j, const int li, const int lj) {
	// Calculates the length cost of the hairpin so far.
	// The length of the loop is equal to Wxx +1 
	// since both the first and the last
	// nucleotide is included in the window
	i++; j++;
	// Add the new length cost
	int res = s_matrix.getHpLength(i+li,j+lj);
	// Subtract the old cost
	res-=s_matrix.getHpLength(i,j);
	return res;
}

inline int fold::second_ilbp(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// This function either continues an internal loop
	// or close it for good with the second base-pair in
	// the closing stem.
	// If the two nucleotide from each of the two sequences
	// base-pairs then this the base-pair is the second
	// base-pair in the closing stem. The score for the
	// previous base-pair is correct from internal loop to
	// base-pair.
	// If the nucleotides do not base-pair then  the loop
	// continues un interrupted.

	int res = D->getD(ii,Wii,kk,Wkk);
	if(s_matrix.getBasepair(i,j) && s_matrix.getBasepair(k,l)) {
		// Add the substitution score
		res+=s_matrix.getScore(i,j,k,l);
		// Add the stacking scores
		res+=s_matrix.getStack(i,j,seq_1->getPos(ii),seq_1->getPos(ii+Wii), k, l,seq_2->getPos(kk),seq_2->getPos(kk+Wkk)); // and the previous position was a double base-pair add stacking bonus
		// Add the previous base-paired substitution score
		res+=s_matrix.getScore(seq_1->getPos(ii),seq_1->getPos(ii+Wii), seq_2->getPos(kk),seq_2->getPos(kk+Wkk));
		// Substrackt the previous non-base-paired substitution score
		res-=(s_matrix.getInit(seq_1->getPos(ii),seq_2->getPos(kk)) + s_matrix.getInit(seq_1->getPos(ii+Wii),seq_2->getPos(kk+Wkk)));
		// Define the loop begin positions and the lengths
		// The positions are corrected because it is the second base-pair in the stem
		int bi=ii+1; int bj=Wii-2; int bk=kk+1; int bl=Wkk-2;
		int li=0, lj=0, lk=0, ll=0;
		// Use the quickback function to find the length of the loop and the
		// closing base-pair
		quickback(li, lj, lk, ll, bi, bj, bk, bl);
		// Added the internal loop closure cost
		// The cost is not depended on the previous-previous state just the
		// Nucleotides
		res+=(s_matrix.getIntLoopClose(seq_1->getPos(ii),seq_1->getPos(ii+Wii),seq_1->getPos(ii+1),seq_1->getPos(ii+Wii-1),seq_2->getPos(kk),seq_2->getPos(kk+Wkk),seq_2->getPos(kk+1),seq_2->getPos(kk+Wkk-1)));
		// Change the loop cost to the shorter loop
		res-=s_matrix.getIntLoopLength(li+1,lj+1)+s_matrix.getIntLoopLength(lk+1,ll+1);
	   res+=s_matrix.getIntLoopLength(li,lj)+s_matrix.getIntLoopLength(lk,ll);
		return maxres(res, max, 63, state);
	}
	res += s_matrix.getInit(i,k) + s_matrix.getInit(j,l);
	// Add the new loop length score
	res+=newIlLength(ii, Wii, kk, Wkk, 1, 1, 1, 1);
	return maxres(res, max, 21, state);
}

inline int fold::newIlLength(int i, int j, int k, int l, int lii, int ljj, int lkk, int lll) {
	// This function is used when an internal loop
	// is extended.
	// The old loop length cost is subtracted and the
	// new loop length cost is added.
	// In order to know how long the loop is
	// a backtrack is performed
	// These variables holds the length of each side
	// of the loop in the two sequences
	int li=0, lj=0, lk=0, ll=0;
	// Do a backtrack to get the lengths
	quickback(li, lj, lk, ll, i, j, k, l);
	// Add the new length score
	int res=s_matrix.getIntLoopLength(li+lii,lj+ljj)+s_matrix.getIntLoopLength(lk+lkk,ll+lll);
	// Subtract the old length score
	   res-=s_matrix.getIntLoopLength(li,lj)+s_matrix.getIntLoopLength(lk,ll);
	return res;
}

inline int fold::stem(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// This function either extends a stem or
	// terminates it.
	// If the nucleotides in both sequences base-pairs
	// then the stem is extended
	// if they do not base-pair the stem is terminated

	// Get the previous score
	int res = D->getD(ii,Wii,kk,Wkk);
	if(s_matrix.getBasepair(i,j) && s_matrix.getBasepair(k,l)) {
		// Extend the stem
		
		// Add the substitution score
		res+=s_matrix.getScore(i,j,k,l);
		// Add the stacking scores
		res+=s_matrix.getStack(i,j,seq_1->getPos(ii),seq_1->getPos(ii+Wii), k, l,seq_2->getPos(kk),seq_2->getPos(kk+Wkk)); // and the previous position was a double base-pair add stacking bonus
		return maxres(res, max, 63, state);
	}
	// Terminate the stem
	
	// Add the substitution cost
	res += s_matrix.getInit(i,k) + s_matrix.getInit(j,l);
	// Add the opening cost (a kind of stacking)
	res+=(s_matrix.getIntLoopOpen(seq_1->getPos(ii),seq_1->getPos(ii+Wii),seq_1->getPos(ii+1),seq_1->getPos(ii+Wii-2),seq_2->getPos(kk),seq_2->getPos(kk+Wkk),seq_2->getPos(kk+1),seq_2->getPos(kk+Wkk-2)));
	// Add the loop length cost
	res+=s_matrix.getIntLoopLength(1,1)+s_matrix.getIntLoopLength(1,1);
	return maxres(res, max, 21, state);
}

inline int fold::stem2singleBpI(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	if (!s_matrix.getBasepair(i,j)) {return big_neg;}
	// Get the previous score
	int res = D->getD(ii,Wii,kk,Wkk);
	// Add the substitution cost
	res += s_matrix.getInit(i,k) + s_matrix.getInit(j,l);
	// If possible add the opening cost (a kind of stacking)
	// Only the positions in the second sequence has to be checked
	// because those in the first are known to be ok
	if ((kk > new_begin_2) && (kk+Wkk+1 < new_end_2)) {
		res+=(s_matrix.getIntLoopOpen(seq_1->getPos(ii),seq_1->getPos(ii+Wii),seq_1->getPos(ii-1),seq_1->getPos(ii+Wii+1),seq_2->getPos(kk),seq_2->getPos(kk+Wkk),seq_2->getPos(kk-1),seq_2->getPos(kk+Wkk+1)));
	}
	// Add the loop length cost
	res+=s_matrix.getIntLoopLength(1,1);
	return maxres(res, max, 30, state);
}

inline int fold::stem2singleBpK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	if (!s_matrix.getBasepair(k,l)) {return big_neg;}
	// Get the previous score
	int res = D->getD(ii,Wii,kk,Wkk);
	// Add the substitution cost
	res += s_matrix.getInit(i,k) + s_matrix.getInit(j,l);
	// If possible add the opening cost (a kind of stacking)
	// Only the positions in the first sequence has to be checked
	// because those in the second are known to be ok
	if ((ii > new_begin_1) && (ii+Wii+1 < new_end_1)) {
		res+=(s_matrix.getIntLoopOpen(seq_1->getPos(ii),seq_1->getPos(ii+Wii),seq_1->getPos(ii-1),seq_1->getPos(ii+Wii+1),seq_2->getPos(kk),seq_2->getPos(kk+Wkk),seq_2->getPos(kk-1),seq_2->getPos(kk+Wkk+1)));
	}
	// Add the loop length cost
	res+=s_matrix.getIntLoopLength(1,1);
	return maxres(res, max, 31, state);
}
	
inline int fold::singleBpI2stem(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Get the previous score
	int res = D->getD(ii,Wii,kk,Wkk);
	if (s_matrix.getBasepair(i,j) && s_matrix.getBasepair(k,l)) { // if both subsequences base-pairs
		res+=s_matrix.getScore(i,j,k,l);
		res+=s_matrix.getStack(i,j,seq_1->getPos(ii),seq_1->getPos(ii+Wii), k, l,seq_2->getPos(kk),seq_2->getPos(kk+Wkk)); // and the previous position was a double base-pair add stacking bonus
		// Subtract the internal loop open
		res-=s_matrix.getIntLoopOpen(seq_1->getPos(ii+1),seq_1->getPos(ii+Wii-1),seq_1->getPos(ii),seq_1->getPos(ii+Wii),seq_2->getPos(kk+1),seq_2->getPos(kk+Wkk-1),seq_2->getPos(kk),seq_2->getPos(kk+Wkk));
		// Subtract the internal length score
		res-=s_matrix.getIntLoopLength(1,1);
		return maxres(res, max, 63, state);
	}
	// The substitution score
	res+=s_matrix.getInit(i,k) + s_matrix.getInit(j,l);
	// The end of stem stacking
	res+=newIlLength(ii, Wii, kk, Wkk, 1, 1, 1, 1);
	return maxres(res, max, 21, state);
}
	
inline int fold::singleBpK2stem(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Get the previous score
	int res = D->getD(ii,Wii,kk,Wkk);
	if (s_matrix.getBasepair(i,j) && s_matrix.getBasepair(k,l)) { // if both subsequences base-pairs
		res+=s_matrix.getScore(i,j,k,l);
		res+=s_matrix.getStack(i,j,seq_1->getPos(ii),seq_1->getPos(ii+Wii), k, l,seq_2->getPos(kk),seq_2->getPos(kk+Wkk)); // and the previous position was a double base-pair add stacking bonus
		// Subtract the internal loop open
		res-=s_matrix.getIntLoopOpen(seq_1->getPos(ii+1),seq_1->getPos(ii+Wii-1),seq_1->getPos(ii),seq_1->getPos(ii+Wii),seq_2->getPos(kk+1),seq_2->getPos(kk+Wkk-1),seq_2->getPos(kk),seq_2->getPos(kk+Wkk));
		// Subtract the internal length score
		res-=s_matrix.getIntLoopLength(1,1);
		return maxres(res, max, 63, state);
	}
	// The substitution score
	res+=s_matrix.getInit(i,k) + s_matrix.getInit(j,l);
	// The end of stem stacking
	res+=newIlLength(ii, Wii, kk, Wkk, 1, 1, 1, 1);
	return maxres(res, max, 21, state);
}

inline int fold::internalLoop(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// This function continues an internal loop
	// in both sequences in both directions.
	// If the nucleotides in both sequences
	// can form base-pairs the state is set to
	// potential end of loop

	// Get the previous score
	int res = D->getD(ii,Wii,kk,Wkk);
	// Add the similarity cost
	res += s_matrix.getInit(i,k) + s_matrix.getInit(j,l);
	// Add the new loop length score
	res+=newIlLength(ii, Wii, kk, Wkk, 1, 1, 1, 1);
	if (res > max) {
		// Both base-pairs mark the state as potential base-pair
		if (s_matrix.getBasepair(i,j) && s_matrix.getBasepair(k,l)) {state=29;} // if both subsequences base-pairs
		else {state = 21;}
		return res;
	}
	return max;
}

inline int fold::bulge(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
// This function continues after a bulge
// the state can either be stem or internal loop.
// Since the bulge is treated as an internal loop
// from the begining the score has to be adjusted
// if it a bulge (ie the two sets of nucleotides
// base-pairs)

	int res = D->getD(ii,Wii,kk,Wkk);
	if (s_matrix.getBasepair(i,j) && s_matrix.getBasepair(k,l)) { // if both subsequences base-pairs
	// If the new state is a stem and the bulge is only one nucleotide long
	// the new base-pair stacks on top of the previous base-pair
		int bi=ii; int bj=Wii; int bk=kk; int bl=Wkk;
		int li=0, lj=0, lk=0, ll=0;
		if (quickbackBulge(li, lj, lk, ll, bi, bj, bk, bl) == 63) {
		// One nucleotide bulges
		// Stem continues past the one nucleotide bulge
			res+=s_matrix.getScore(i,j,k,l);
			res+=s_matrix.getStack(i,j,seq_1->getPos(bi),seq_1->getPos(bi+bj), k, l,seq_2->getPos(bk),seq_2->getPos(bk+bl)); // and the previous position was a double base-pair add stacking bonus
			// Subtract the internal loop open
			res-=s_matrix.getIntLoopOpen(seq_1->getPos(bi),seq_1->getPos(bi+bj),seq_1->getPos(bi-1),seq_1->getPos(bi+bj+1),seq_2->getPos(bk),seq_2->getPos(bk+bl),seq_2->getPos(bk-1),seq_2->getPos(bk+bl+1));
			// Subtract the internal length score
			res-=s_matrix.getIntLoopLength(li,lj)+s_matrix.getIntLoopLength(lk,ll);
			// add the bulge length cost
			res+=s_matrix.getBulgeLength(li, lk)+s_matrix.getBulgeLength(lj, ll);
			return maxres(res, max, 63, state);
		}
		// Bulge longer than one nucleotide
		res+=s_matrix.getInit(i,k) + s_matrix.getInit(j,l);
		// Subtract the old internal loop length score and add the new
		bi=ii; bj=Wii; bk=kk; bl=Wkk;
		li=0, lj=0, lk=0, ll=0;
		quickback(li, lj, lk, ll, bi, bj, bk, bl);
		res-=s_matrix.getIntLoopLength(li,lj)+s_matrix.getIntLoopLength(lk,ll);
		res+=s_matrix.getIntLoopLength(li+1,lj+1)+s_matrix.getIntLoopLength(lk+1,ll+1);
		// Mark the state as potential base-pair
		return maxres(res, max, 61, state);
	}
	// The substitution score
	res+=s_matrix.getInit(i,k) + s_matrix.getInit(j,l);
	// The end of stem stacking
	res+=newIlLength(ii, Wii, kk, Wkk, 1, 1, 1, 1);
	return maxres(res, max, 21, state);
}

inline int fold::bulgestem(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// The previous state is a potential base-pair preceeded by a
	// bulge.
	// If these four nucleotides (two from each sequence)
	// also base-pairs then the potential base-pair is a
	// base-pair and there are now two base-pairs in the
	// stem.
	// If they do not base-pair then the bulge is an internal
	// loop and continues as such.

	int res = D->getD(ii,Wii,kk,Wkk);
	if (s_matrix.getBasepair(i,j) && s_matrix.getBasepair(k,l)) { // if both subsequences base-pairs
		// Add the substitution score
		res+=s_matrix.getScore(i,j,k,l);
		// Add the stacking scores
		res+=s_matrix.getStack(i,j,seq_1->getPos(ii),seq_1->getPos(ii+Wii), k, l,seq_2->getPos(kk),seq_2->getPos(kk+Wkk)); // and the previous position was a double base-pair add stacking bonus
		// Add the previous base-paired substitution score
		res+=s_matrix.getScore(seq_1->getPos(ii),seq_1->getPos(ii+Wii), seq_2->getPos(kk),seq_2->getPos(kk+Wkk));
		// Substrackt the previous non-base-paired substitution score
		res-=(s_matrix.getInit(seq_1->getPos(ii),seq_2->getPos(kk)) + s_matrix.getInit(seq_1->getPos(ii+Wii),seq_2->getPos(kk+Wkk)));
		// Define the loop begin positions and the lengths
		int bi=ii+1; int bj=Wii-2; int bk=kk+1; int bl=Wkk-2;
		int li=0, lj=0, lk=0, ll=0;
		// Use the quickback function to find the length of the loop and the
		// closing base-pair
		quickback(li, lj, lk, ll, bi, bj, bk, bl);
		// Add the length cost
		res+=s_matrix.getBulgeLength(li, lk)+s_matrix.getBulgeLength(lj, ll);
		// Already added the internal loop cost for the previous position. It is now subtracted
		res-=s_matrix.getIntLoopLength(li+1,lj+1)+s_matrix.getIntLoopLength(lk+1,ll+1);
		// Remove the internal loop open cost
		res-=s_matrix.getIntLoopOpen(seq_1->getPos(bi),seq_1->getPos(bi+bj),seq_1->getPos(bi-1),seq_1->getPos(bi+bj+1),seq_2->getPos(bk),seq_2->getPos(bk+bl),seq_2->getPos(bk-1),seq_2->getPos(bk+bl+1));
		// Add the non-GC stem end penalty
		// Add the non-GC stem end penalty but only if the bulge length is larger than 0
		// since there might not be a bulge in both sequences
		if ((li > 0) || (lj > 0)) {
			res+=s_matrix.getNonGCEnd(seq_1->getPos(bi), seq_1->getPos(bi+bj));
			res+=s_matrix.getNonGCEnd(seq_1->getPos(ii), seq_1->getPos(ii+Wii));
		}
		if ((lk > 0) || (ll > 0)) {
			res+=s_matrix.getNonGCEnd(seq_2->getPos(bk), seq_2->getPos(bk+bl));
			res+=s_matrix.getNonGCEnd(seq_2->getPos(kk), seq_2->getPos(kk+Wkk));
		}

		return maxres(res, max, 63, state);
	}
	// The substitution score
	res+=s_matrix.getInit(i,k) + s_matrix.getInit(j,l);
	// The loop continues
	res+=newIlLength(ii, Wii, kk, Wkk, 1, 1, 1, 1);
	return maxres(res, max, 21, state);
}

inline void fold::interOpen(const int ii, const int Wii, const int kk, const int Wkk, int& res) {
	// This function adds the internal loop stacking of the
	// first mismatch on the last base-pair score

	// The coordinates of the closing base-pair
	int bi=ii; int bj=Wii; int bk=kk; int bl=Wkk;
	// The length of the bulge
	int li=0, lj=0, lk=0, ll=0;
	// Use the quickback function to find the closing base-pair
	quickback(li, lj, lk, ll, bi, bj, bk, bl);
	// The end of stem stacking
	if ((bi > new_begin_1) && (bk > new_begin_2) && (bi+bj+1 < new_end_1) && (bk+bl+1 < new_end_2)) {
		res+=(s_matrix.getIntLoopOpen(seq_1->getPos(bi),seq_1->getPos(bi+bj),seq_1->getPos(bi-1),seq_1->getPos(bi+bj+1),seq_2->getPos(bk),seq_2->getPos(bk+bl),seq_2->getPos(bk-1),seq_2->getPos(bk+bl+1)));
	}
}

inline int fold::bulgeIK2bulge(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continues a bulge in both sequences
	// on the upstream side of the alignment
	// Note that the bulge is scored as an
	// internal loop until the it is closed
	// by a base-pair.
	
	// Get the previous score
	int res = D->getD(ii,Wii,kk,Wkk);
	// add the substitution score
	res+=s_matrix.getInit(i,k);
	// Adjust the length cost. The length
	// is increased by one in the two upstream
	// postions.
	res+=newIlLength(ii, Wii, kk, Wkk, 1, 0, 1, 0);
	// If the score is better than the previous best score
	// max = res and the state is set to 10
	return maxres(res,max,10,state);
}

inline int fold::bulgeI2bulge(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continue an upstream bulge in the first sequence (I)
	// and add a gap in the second sequence (K)
	// See also comments in the bulgeIK2bulge
	// function
	
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=newIlLength(ii, Wii, kk, Wkk, 1, 0, 0, 0);
	return maxres(res,max,12,state);
}

inline int fold::bulgeK2bulge(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continue an upstream bulge in the second sequence (K)
	// and add a gap in the first sequence (I)
	// See also comments in the bulgeIK2bulge
	// function
	
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=newIlLength(ii, Wii, kk, Wkk, 0, 0, 1, 0);
	return maxres(res,max,14,state);
}

inline int fold::bulgeI2bulgegap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continue an upstream bulge in the first sequence (I)
	// and continues a gap in the second sequence (K)
	// The affine gap_bonus is added
	// See also comments in the bulgeIK2bulge
	// function
	
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=newIlLength(ii, Wii, kk, Wkk, 1, 0, 0, 0);
	res+=gap_bonus;
	return maxres(res,max,12,state);
}

inline int fold::bulgeK2bulgegap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continue an upstream bulge in the second sequence (K)
	// and continues a gap in the first sequence (I)
	// The affine gap_bonus is added
	// See also comments in the bulgeIK2bulge
	// function
	
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=newIlLength(ii, Wii, kk, Wkk, 0, 0, 1, 0);
	res+=gap_bonus;
	return maxres(res,max,14,state);
}

inline int fold::bulgeJL2bulge(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continue a downstream bulge in both sequences
	// on the upstream side
	// See also comments in the bulgeIK2bulge
	// function

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=newIlLength(ii, Wii, kk, Wkk, 0, 1, 0, 1);
	return maxres(res,max,11,state);
}

inline int fold::bulgeJ2bulge(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continue a downstream bulge in the first sequence (I)
	// and add a gap in the second sequence (K)
	// See also comments in the bulgeIK2bulge
	// function
	
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=newIlLength(ii, Wii, kk, Wkk, 0, 1, 0, 0);
	return maxres(res,max,13,state);
}

inline int fold::bulgeL2bulge(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continue a downstream bulge in the second sequence (K)
	// and add a gap in the first sequence (I)
	// See also comments in the bulgeIK2bulge
	// function
	
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=newIlLength(ii, Wii, kk, Wkk, 0, 0, 0, 1);
	return maxres(res,max,15,state);
}

inline int fold::bulgeJ2bulgegap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continue a downstream bulge in the first sequence (I)
	// and continues a gap in the second sequence (K)
	// The affine gap_bonus is added
	// See also comments in the bulgeIK2bulge
	// function
	
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=newIlLength(ii, Wii, kk, Wkk, 0, 1, 0, 0);
	res+=gap_bonus;
	return maxres(res,max,13,state);
}

inline int fold::bulgeL2bulgegap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continue a downstream bulge in the second sequence (K)
	// and continues a gap in the first sequence (I)
	// The affine gap_bonus is added
	// See also comments in the bulgeIK2bulge
	// function
	
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=newIlLength(ii, Wii, kk, Wkk, 0, 0, 0, 1);
	res+=gap_bonus;
	return maxres(res,max,15,state);
}

inline int fold::internalIK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continues an internal loop on the upstream side
	// in both sequences

	// Get the previous score
	int res = D->getD(ii,Wii,kk,Wkk);
	// Add the similarity score
	res+=s_matrix.getInit(i,k);
	// Adjust the length cost
	res+=newIlLength(ii, Wii, kk, Wkk, 1, 0, 1, 0);
	// if the res is better than max the max=res and state=26
	return maxres(res,max,26,state);
}

inline int fold::internalJL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continues an internal loop on the downstream side
	// in both sequences
	// See also comments in the internalIK function

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=newIlLength(ii, Wii, kk, Wkk, 0, 1, 0, 1);
	return maxres(res,max,27,state);
}

inline int fold::internalI(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continues an internal loop on the upstream side
	// with a nucleotide in the first sequence
	// and a gap in the second
	// See also comments in the internalIK function

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=newIlLength(ii, Wii, kk, Wkk, 1, 0, 0, 0);
	return maxres(res,max,22,state);
}

inline int fold::internalK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continues an internal loop on the upstream side
	// with a nucleotide in the second sequence
	// and a gap in the first
	// See also comments in the internalIK function

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=newIlLength(ii, Wii, kk, Wkk, 0, 0, 1, 0);
	return maxres(res,max,24,state);
}

inline int fold::internalJ(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continues an internal loop on the downstream side
	// with a nucleotide in the first sequence
	// and a gap in the second
	// See also comments in the internalIK function

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=newIlLength(ii, Wii, kk, Wkk, 0, 1, 0, 0);
	return maxres(res,max,23,state);
}

inline int fold::internalL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continues an internal loop on the downstream side
	// with a nucleotide in the second sequence
	// and a gap in the first
	// See also comments in the internalIK function

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=newIlLength(ii, Wii, kk, Wkk, 0, 0, 0, 1);
	return maxres(res,max,25,state);
}

inline int fold::internalIgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continues an internal loop on the upstream side
	// with a nucleotide in the first sequence
	// and an affine gap in the second
	// See also comments in the internalIK function

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=newIlLength(ii, Wii, kk, Wkk, 1, 0, 0, 0);
	res+=gap_bonus;
	return maxres(res,max,22,state);
}

inline int fold::internalKgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continues an internal loop on the upstream side
	// with a nucleotide in the second sequence
	// and an affine gap in the first
	// See also comments in the internalIK function

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=newIlLength(ii, Wii, kk, Wkk, 0, 0, 1, 0);
	res+=gap_bonus;
	return maxres(res,max,24,state);
}

inline int fold::internalJgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continues an internal loop on the downstream side
	// with an affine nucleotide in the first sequence
	// and a gap in the second
	// See also comments in the internalIK function

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=newIlLength(ii, Wii, kk, Wkk, 0, 1, 0, 0);
	res+=gap_bonus;
	return maxres(res,max,23,state);
}

inline int fold::internalLgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Continues an internal loop on the downstream side
	// with an affine nucleotide in the second sequence
	// and a gap in the first
	// See also comments in the internalIK function

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=newIlLength(ii, Wii, kk, Wkk, 0, 0, 0, 1);
	res+=gap_bonus;
	return maxres(res,max,25,state);
}

inline int fold::stem2bulgeIK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Starts a bulge in both sequences on the upsteam side

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	// The bulge is not bulge untill it is closed by a base-pair
	// hence its has the loop cost of an internal loop
	// The bulge is expected to be an internal loop and hence the internal loop open cost is added
	// if it is possible to put a complete set of mismatch pairs on the outside of ii,Wii,kk,Wkk
	if ((ii>new_begin_1+1) && (kk > new_begin_2+1) && (ii+Wii+1 < new_end_1) && (kk+Wkk+1 < new_end_2)) {
		res+=(s_matrix.getIntLoopOpen(seq_1->getPos(ii),seq_1->getPos(ii+Wii),seq_1->getPos(ii-1),seq_1->getPos(ii+Wii+1),seq_2->getPos(kk),seq_2->getPos(kk+Wkk),seq_2->getPos(kk-1),seq_2->getPos(kk+Wkk+1)));
	}
	// the internal loop length cost (times two because the bulge is in both sequences)
	res+=2*s_matrix.getIntLoopLength(1,0);
	return maxres(res,max,10,state);
}

inline int fold::stem2bulgeJL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Starts a bulge in both sequences on the downsteam side

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	// The bulge is not bulge untill it is closed by a base-pair
	// hence its has the loop cost of an internal loop
	// The internal loop open
	if ((ii>new_begin_1+1) && (kk > new_begin_2+1) && (ii+Wii+1 < new_end_1) && (kk+Wkk+1 < new_end_2)) {
		res+=(s_matrix.getIntLoopOpen(seq_1->getPos(ii),seq_1->getPos(ii+Wii),seq_1->getPos(ii-1),seq_1->getPos(ii+Wii+1),seq_2->getPos(kk),seq_2->getPos(kk+Wkk),seq_2->getPos(kk-1),seq_2->getPos(kk+Wkk+1)));
	}
	// the internal loop length cost (times two because the bulge is in both sequences)
	res+=2*s_matrix.getIntLoopLength(1,0);
	return maxres(res,max,11,state);
}

inline int fold::stem2bulgeI(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Starts an upstream bulge in the first sequence
	// and add a gap in the second
	// See also comments in stem2bulgeIK or stem2bulgeJL

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	if ((ii>new_begin_1+1) && (kk > new_begin_2+1) && (ii+Wii+1 < new_end_1) && (kk+Wkk+1 < new_end_2)) {
		res+=(s_matrix.getIntLoopOpen(seq_1->getPos(ii),seq_1->getPos(ii+Wii),seq_1->getPos(ii-1),seq_1->getPos(ii+Wii+1),seq_2->getPos(kk),seq_2->getPos(kk+Wkk),seq_2->getPos(kk-1),seq_2->getPos(kk+Wkk+1)));
	}
	// the internal loop length cost
	res+=s_matrix.getIntLoopLength(1,0);
	return maxres(res,max,12,state);
}

inline int fold::stem2bulgeK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Starts an upstream bulge in the second sequence
	// and add a gap in the first
	// See also comments in stem2bulgeIK or stem2bulgeJL

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	if ((ii>new_begin_1+1) && (kk > new_begin_2+1) && (ii+Wii+1 < new_end_1) && (kk+Wkk+1 < new_end_2)) {
		res+=(s_matrix.getIntLoopOpen(seq_1->getPos(ii),seq_1->getPos(ii+Wii),seq_1->getPos(ii-1),seq_1->getPos(ii+Wii+1),seq_2->getPos(kk),seq_2->getPos(kk+Wkk),seq_2->getPos(kk-1),seq_2->getPos(kk+Wkk+1)));
	}
	// the internal loop length cost
	res+=s_matrix.getIntLoopLength(1,0);
	return maxres(res,max,14,state);
}

inline int fold::stem2bulgeJ(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Starts a downstream bulge in the first sequence
	// and add a gap in the second
	// See also comments in stem2bulgeIK or stem2bulgeJL

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	if ((ii>new_begin_1+1) && (kk > new_begin_2+1) && (ii+Wii+1 < new_end_1) && (kk+Wkk+1 < new_end_2)) {
		res+=(s_matrix.getIntLoopOpen(seq_1->getPos(ii),seq_1->getPos(ii+Wii),seq_1->getPos(ii-1),seq_1->getPos(ii+Wii+1),seq_2->getPos(kk),seq_2->getPos(kk+Wkk),seq_2->getPos(kk-1),seq_2->getPos(kk+Wkk+1)));
	}
	// the internal loop length cost
	res+=s_matrix.getIntLoopLength(0,1);
	return maxres(res,max,13,state);
}

inline int fold::stem2bulgeL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Starts a downstream bulge in the second sequence
	// and add a gap in the first
	// See also comments in stem2bulgeIK or stem2bulgeJL

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	if ((ii> new_begin_1+1) && (kk > new_begin_2+1) && (ii+Wii+1 < new_end_1) && (kk+Wkk+1 < new_end_2)) {
		res+=(s_matrix.getIntLoopOpen(seq_1->getPos(ii),seq_1->getPos(ii+Wii),seq_1->getPos(ii-1),seq_1->getPos(ii+Wii+1),seq_2->getPos(kk),seq_2->getPos(kk+Wkk),seq_2->getPos(kk-1),seq_2->getPos(kk+Wkk+1)));
	}
	// the internal loop length cost
	res+=s_matrix.getIntLoopLength(0,1);
	return maxres(res,max,15,state);
}

inline int fold::mblSSIK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds an upstream nucleotide in a multibranch loop
	// in both sequences

	// Get the previous score
	int res = D->getD(ii,Wii,kk,Wkk);
	// Add the similarity cost
	res+=s_matrix.getInit(i,k);
	// Add the multibranch single strand nucleotide length cost
	// multiply the score by two because one
	// nucleotide is added in both sequences
	res+=2*mblNuc;
	// If the score is better then max=res and state = 42
	return maxres(res,max,42,state);
}

inline int fold::mblSSIKpMbl(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds an upstream nucleotide in a multibranch loop
	// in both sequences
	// This state can form right part of mbl

	// Get the previous score
	int res = D->getD(ii,Wii,kk,Wkk);
	// Add the similarity cost
	res+=s_matrix.getInit(i,k);
	// Add the multibranch single strand nucleotide length cost
	// multiply the score by two because one
	// nucleotide is added in both sequences
	res+=2*mblNuc;
	// If the score is better then max=res and state = 52
	return maxres(res,max,52,state);
}

inline int fold::mblSSJL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds an downstream nucleotide in a multibranch loop
	// in both sequences
	// mblSSIK for further comments
	
	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=2*mblNuc;
	return maxres(res,max,43,state);
}

inline int fold::mblSSI(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds an upstream nucleotide in a multibranch loop
	// in the first sequence and a gap in the second
	// mblSSIK for further comments

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=mblNuc;
	return maxres(res,max,44,state);
}

inline int fold::mblSSIpMbl(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds an upstream nucleotide in a multibranch loop
	// in the first sequence and a gap in the second
	// This state can form right part of mbl
	// mblSSIK for further comments

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=mblNuc;
	return maxres(res,max,54,state);
}

inline int fold::mblSSK(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds an upstream nucleotide in a multibranch loop
	// in the second sequence and a gap in the first
	// mblSSIK for further comments

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=mblNuc;
	return maxres(res,max,46,state);
}

inline int fold::mblSSKpMbl(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds an upstream nucleotide in a multibranch loop
	// in the second sequence and a gap in the first
	// This state can form right part of mbl
	// mblSSIK for further comments

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=mblNuc;
	return maxres(res,max,56,state);
}

inline int fold::mblSSJ(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds a downstream nucleotide in a multibranch loop
	// in the first sequence and a gap in the second
	// mblSSIK for further comments

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=mblNuc;
	return maxres(res,max,45,state);
}

inline int fold::mblSSL(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds a downstream nucleotide in a multibranch loop
	// in the second sequence and a gap in the first
	// mblSSIK for further comments

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=mblNuc;
	return maxres(res,max,47,state);
}

inline int fold::mblSSIgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds an upstream nucleotide in a multibranch loop
	// in the first sequence and an affine gap in the second
	// mblSSIK for further comments

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=gap_bonus;
	res+=mblNuc;
	return maxres(res,max,44,state);
}

inline int fold::mblSSIpMblgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds an upstream nucleotide in a multibranch loop
	// in the first sequence and an affine gap in the second
	// This state can form the right part of an mbl
	// mblSSIK for further comments

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=gap_bonus;
	res+=mblNuc;
	return maxres(res,max,54,state);
}

inline int fold::mblSSKgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds an upstream nucleotide in a multibranch loop
	// in the second sequence and an affine gap in the first
	// mblSSIK for further comments

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=gap_bonus;
	res+=mblNuc;
	return maxres(res,max,46,state);
}

inline int fold::mblSSKpMblgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds an upstream nucleotide in a multibranch loop
	// in the second sequence and an affine gap in the first
	// This state can form the right part of an mbl
	// mblSSIK for further comments

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=gap_bonus;
	res+=mblNuc;
	return maxres(res,max,56,state);
}

inline int fold::mblSSJgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds a downstream nucleotide in a multibranch loop
	// in the first sequence and an affine gap in the second
	// mblSSIK for further comments

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=gap_bonus;
	res+=mblNuc;
	return maxres(res,max,45,state);
}

inline int fold::mblSSLgap(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds a downstream nucleotide in a multibranch loop
	// in the second sequence and an affine gap in the first
	// mblSSIK for further comments

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(j,l);
	res+=gap_bonus;
	res+=mblNuc;
	return maxres(res,max,47,state);
}

inline int fold::mblDS(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// Adds single strand nucleotides on both sides
	// of a multibranch loop.
	// The nucleotide base-pairs in both sequences
	// then the state is marked as a potential base-pair

	int res = D->getD(ii,Wii,kk,Wkk);
	res+=s_matrix.getInit(i,k);
	res+=s_matrix.getInit(j,l);
	res+=4*mblNuc;
	if (s_matrix.getBasepair(i,j) && s_matrix.getBasepair(k,l)) { // if both subsequences base-pairs
		// mark the state as potential base-pair
		return maxres(res,max,49,state);
	}
	return maxres(res,max,41,state);
}

inline int fold::mblLast(const int i, const int j, const int k, const int l, const int ii, const int Wii, const int kk, const int Wkk, char& state,const int max) {
	// The previous state is a potential base-pair
	// if the nucleotides in both sequences base-pair then it
	// was a base-pair and the multibranch loop is enden and the
	// score is recalculated to reflect this
	// If the nucleotides do not base-pair the multibranch loop
	// continues

	int res = D->getD(ii,Wii,kk,Wkk);
	if (s_matrix.getBasepair(i,j) && s_matrix.getBasepair(k,l)) { // if both subsequences base-pairs
		// Add the substitution score
		res+=s_matrix.getScore(i,j,k,l);
		// Add the stacking scores
		res+=s_matrix.getStack(i,j,seq_1->getPos(ii),seq_1->getPos(ii+Wii), k, l,seq_2->getPos(kk),seq_2->getPos(kk+Wkk)); // and the previous position was a double base-pair add stacking bonus
		// Add the previous base-paired substitution score
		res+=s_matrix.getScore(seq_1->getPos(ii),seq_1->getPos(ii+Wii), seq_2->getPos(kk),seq_2->getPos(kk+Wkk));
		// Substrackt the previous non-base-paired substitution score
		res-=(s_matrix.getInit(seq_1->getPos(ii),seq_2->getPos(kk)) + s_matrix.getInit(seq_1->getPos(ii+Wii),seq_2->getPos(kk+Wkk)));
		// Subtrackt the mbl elongation cost for the first base-pair
		res-=4*mblNuc;
		// Added the internal loop closure cost
		// The cost is not depended on the previous-previous state just the
		// Nucleotides
		res+= s_matrix.getNonGCEnd(seq_1->getPos(ii), seq_1->getPos(ii+Wii), seq_2->getPos(kk), seq_2->getPos(kk+Wkk));
		int di, dj, dk, dl;
		res+=mbl - mblAffine;
		backBranch(ii, Wii, kk, Wkk, di, dj, dk, dl);
		if (di > 1 && dk > 1 && dj > 1 && dl > 1) {
			// A dangling end can be added to both sequences
			res+=s_matrix.getDangle3(seq_1->getPos(ii), seq_1->getPos(ii+Wii), seq_1->getPos(ii+1), seq_2->getPos(kk), seq_2->getPos(kk+Wkk), seq_2->getPos(kk+1));
			res+=s_matrix.getDangle5(seq_1->getPos(ii), seq_1->getPos(ii+Wii), seq_1->getPos(ii+Wii-1), seq_2->getPos(kk), seq_2->getPos(kk+Wkk), seq_2->getPos(kk+Wkk-1));
		}
		else {
			int pi = ii+di+1;
			int pWi = Wii-dj-di-2;
			int pk = kk+dk+1;
			int pWk = Wkk-dl-dk-2;
			int pScore = D->getD(pi, pWi, pk, pWk);
			const int size_diff = pWk - pWi; // The difference in size between the two windows
			// bottom and top are used to make sure that the length difference between 
			// a substructure in the two sequences is no more than delta
			int bottom = size_diff;
			int top = 0;
			if (size_diff <= 0) {
				bottom = 0;
				top = size_diff;
			}
			// The minimum length of a branch is min_loop plus two base-pairs
			// In the constructor min_loop is increased with one, therefor only
			// three and not four is added here
			const int min = min_loop +3;
			const int nuc_i = seq_1->getPos(pi);
			// These variabels stores the 5' and 3' dangle scores
			int dang3;
			int dang5;
			// Loop of the possible branch positions in the first sequence
			for(int m = min; m < pWi-min+1; m++) { // For all positions between i and j
				// Unless positions i and m basepair there can be no branch point here
				// this speeds up the algorithm.
				if (!s_matrix.getBasepair(nuc_i,seq_1->getPos(pi+m))) {continue;}
				// Calculate the range in which a branch point can be placed in the second
				// sequence
				int n_start = (((m-delta+bottom)>min) ? (m-delta+bottom) : min);
				int n_stop  = (((m+delta+top)<(pWk-min)) ? (m+delta+top) : (pWk-min));
				// Loop of the possible branch positions in the second sequence
				for(int n = n_start; n < n_stop+1; n++) {// For all positions between k and l
					// Check that the left side of the branch point is a stem
					// and that the right side ends with a basepair (this is checked
					// with branch left and right arrays. These are true for allowed states
					// and false otherwise
					if (!(branch_left[S->getD(pi,m,pk,n)] && branch_right[S->getD((pi+m+1),(pWi-m-1),(pk+n+1),(pWk-n-1))])) {continue;}
					int score = branchCore(pi, pWi, pk, pWk, m, n, dang5, dang3);
					// Check the score against the old max
					if (pScore == score) {m = pWi+1; break;}
				}
			}
			if (di > 1 && dk > 1) {
				// A dangling end can be added to both sequences
				res+=s_matrix.getDangle3(seq_1->getPos(ii), seq_1->getPos(ii+Wii), seq_1->getPos(ii+1), seq_2->getPos(kk), seq_2->getPos(kk+Wkk), seq_2->getPos(kk+1));
				if (dj == 0 || dl == 0) {res -= dang5;}
				else {
					int d5=s_matrix.getDangle5(seq_1->getPos(ii), seq_1->getPos(ii+Wii), seq_1->getPos(ii+Wii-1), seq_2->getPos(kk), seq_2->getPos(kk+Wkk), seq_2->getPos(kk+Wkk-1));
					if (d5 > dang5) {res += d5-dang5;}
				}
			}
			else {
				if (di == 0 || dk == 0) {res -= dang3;}
				else {
					int d3 = s_matrix.getDangle3(seq_1->getPos(ii), seq_1->getPos(ii+Wii), seq_1->getPos(ii+1), seq_2->getPos(kk), seq_2->getPos(kk+Wkk), seq_2->getPos(kk+1));
					if (d3 > dang3) {res += d3-dang3;}
				}

				if (dj > 1 && dl > 1) {
					res+=s_matrix.getDangle5(seq_1->getPos(ii), seq_1->getPos(ii+Wii), seq_1->getPos(ii+Wii-1), seq_2->getPos(kk), seq_2->getPos(kk+Wkk), seq_2->getPos(kk+Wkk-1));
				}
				else if (dj == 0 || dl == 0) {res -= dang5;}
				else {
					int d5=s_matrix.getDangle5(seq_1->getPos(ii), seq_1->getPos(ii+Wii), seq_1->getPos(ii+Wii-1), seq_2->getPos(kk), seq_2->getPos(kk+Wkk), seq_2->getPos(kk+Wkk-1));
					if (d5 > dang5) {res += d5-dang5;}
				}
			}
		}
		return maxres(res, max, 63, state);
	}
	// Continue the multibranch loop

	// Add the similarity scores for both sides
	res+=s_matrix.getInit(i,k);
	res+=s_matrix.getInit(j,l);
	// Add the length cost
	res+=4*mblNuc;
	return maxres(res,max,41,state);
}
	
//**********************************
// The following function are used to backtrack
// to get loop lengths and end postion

inline void fold::backBranch(const int i, const int Wi, const int k, const int Wk, int& di, int& dj, int& dk, int& dl) {
	// used to backtrack when a mbl is closed.
	// the di2, dj2, dk2, dl2 can be used to check how the dangling end should
	// stack

	int pi=i+1;
	int pj=Wi-2;
	int pk=k+1;
	int pl=Wk-2;
	
	// The state of the right part of the branch point
	char rs = S->getD_us(pi,pj,pk,pl);
	// A backtrack on the right side of the branch point is performed to
	// find the end stem or branch point coordinates
	while (rs != 40) {
		// Using the L matrix should speed up the backtrack
		short len = L->getD(pi, pj, pk, pl);
		// Update the coordinates
		pi = pi + len*coord_I[rs];
		pj = pj + len*coord_J[rs];
		pk = pk + len*coord_K[rs];
		pl = pl + len*coord_L[rs];
		// Get the new state
		rs = S->getD(pi, pj, pk, pl);
	}
	di = pi - i -1;
	dk = pk - k -1;
	dj = i+Wi - pi - pj -1;
	dl = k+Wk - pk - pl -1;
}

inline void fold::quickback(int& length_I, int&  length_J, int& length_K, int& length_L, int ii, int Wii, int kk, int Wkk) {
	// Backtrack until either a stem or branch point
	// is fund

	// Get the first state
	char state = S->getD(ii, Wii, kk, Wkk);
	// The length (len) holds the number of times
	// uninterrupted the state has been used.
	short len;
	while ((state != 63) && (state != 40)) { 
		// As long as the state is a loop state keep going
		// Get the length of the current state
		len = L->getD(ii, Wii, kk, Wkk);
		// Backtrack one length of state
		// and get the new state
		state = quickcore(length_I, length_J, length_K, length_L, ii, Wii, kk, Wkk, state, len);
	}
}

inline char fold::quickbackBulge(int& length_I, int&  length_J, int& length_K, int& length_L, int& ii, int& Wii, int& kk, int& Wkk) {
	// This function backtracks one step only
	
	char state = S->getD(ii, Wii, kk, Wkk);
	length_I = 0; // The length of i-side of the loop
	length_J = 0; // The length of j-side of the loop
	length_K = 0; // The length of k-side of the loop
	length_L = 0; // The length of l-side of the loop
	return quickcore(length_I, length_J, length_K, length_L, ii, Wii, kk, Wkk, state, 1);
}

inline char fold::quickcore(int& length_I, int&  length_J, int& length_K, int& length_L, int& ii, int& Wii, int& kk, int& Wkk, char& state, short len) {
	// Backtrack on state
	// The size array holds the change in length for each side of the stem
	// depended on the state
	// If there has been a row of the same state then the total change is
	// len * size. Using the length matrix should therefor speed up the
	// calculation
	// The same is true for the change coordinates

	// The change in length is equal to the product of the number of changes
	// and the change pr nucleotide.
	length_I+=len*size_I[state];
	length_J+=len*size_J[state];
	length_K+=len*size_K[state];
	length_L+=len*size_L[state];
	// The change in coordinates are equal to the product of the "length" of the
	// state and the change pr state
	ii+=len*coord_I[state];
	Wii+=len*coord_J[state];
	kk+=len*coord_K[state];
	Wkk+=len*coord_L[state];
	// Return the new state
	return S->getD(ii, Wii, kk, Wkk);
}

//*******************************************
// Some helper functions

template<class type> inline void fold::init_array(type array[], int size, type val) {
	// This template assigns a value to all positions in an array
	// up to position size -1
	for(int i=0; i<size; i++) {array[i] = val;}
}

inline int fold::maxres(const int res, const int max, const char new_state, char& state) {
	// Check is the result is better than the old best score
	// if it is then max=res and the state is set to the functions
	// state
	if (res > max) {
		state = new_state;
		return res;
	}
	return max;
}

//**********************************************************
// The destructor                                          *
//**********************************************************

inline fold::~fold() {
	delete out;
}

inline void fold::init_p2calc() {

// These arrays are needed by the quickback function.
// The size array shows have much the length of a loop grows by the state
// The coord array holds the change in coordinates needed by to backtrack
	init_array(size_I, p2calc_size, 0);
	init_array(size_J, p2calc_size, 0);
	init_array(size_K, p2calc_size, 0);
	init_array(size_L, p2calc_size, 0);
	init_array(coord_I, p2calc_size, 0);
	init_array(coord_J, p2calc_size, 0);
	init_array(coord_K, p2calc_size, 0);
	init_array(coord_L, p2calc_size, 0);

	int index; // index for the size array
// Begin
	index =  0;	index =  9; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 0; coord_L[index] = 0;
	index =  1;	index =  9; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 0; coord_L[index] = 0;
// i,j,k,l
	index =  4; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
	index =  5; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
	index = 21; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
	index = 29; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
	index = 41; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
	index = 49; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
	index = 61; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
	index = 63; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 1; coord_L[index] = -2;
// i,j
	index = 30; coord_I[index] = 1; coord_J[index] = -2; coord_K[index] = 0; coord_L[index] = 0;
// k,l
	index = 31; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 1; coord_L[index] = -2;
// i,k
	index =  2; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 1; coord_L[index] = -1;
	index = 10; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 1; coord_L[index] = -1;
	index = 26; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 1; coord_L[index] = -1;
	index = 42; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 1; coord_L[index] = -1;
	index = 52; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 1; coord_L[index] = -1;
// j,l
	index =  3; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = -1;
	index = 11; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = -1;
	index = 27; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = -1;
	index = 43; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = -1;
// i
	index =  6; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
	index = 12; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
	index = 22; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
	index = 44; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
	index = 54; coord_I[index] = 1; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
// j
	index =  7; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
	index = 13; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
	index = 23; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
	index = 45; coord_I[index] = 0; coord_J[index] = -1; coord_K[index] = 0; coord_L[index] = 0;
// k
	index =  8; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 1; coord_L[index] = -1;
	index = 14; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 1; coord_L[index] = -1;
	index = 24; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 1; coord_L[index] = -1;
	index = 46; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 1; coord_L[index] = -1;
	index = 56; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 1; coord_L[index] = -1;
// l
	index =  9; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 0; coord_L[index] = -1;
	index = 15; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 0; coord_L[index] = -1;
	index = 25; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 0; coord_L[index] = -1;
	index = 47; coord_I[index] = 0; coord_J[index] = 0; coord_K[index] = 0; coord_L[index] = -1;

// i,j,k,l
	index =  4; size_I[index] = 1; size_J[index] = 1; size_K[index] = 1; size_L[index] = 1;
	index =  5; size_I[index] = 1; size_J[index] = 1; size_K[index] = 1; size_L[index] = 1;
	index = 21; size_I[index] = 1; size_J[index] = 1; size_K[index] = 1; size_L[index] = 1;
	index = 29; size_I[index] = 1; size_J[index] = 1; size_K[index] = 1; size_L[index] = 1;
	index = 41; size_I[index] = 1; size_J[index] = 1; size_K[index] = 1; size_L[index] = 1;
	index = 49; size_I[index] = 1; size_J[index] = 1; size_K[index] = 1; size_L[index] = 1;
	index = 61; size_I[index] = 1; size_J[index] = 1; size_K[index] = 1; size_L[index] = 1;
	index = 63; size_I[index] = 1; size_J[index] = 1; size_K[index] = 1; size_L[index] = 1;
// i,j
	index = 30; size_I[index] = 1; size_J[index] = 1; size_K[index] = 0; size_L[index] = 0;
// k,l
	index = 31; size_I[index] = 0; size_J[index] = 0; size_K[index] = 1; size_L[index] = 1;
// i,k
	index =  2; size_I[index] = 1; size_J[index] = 0; size_K[index] = 1; size_L[index] = 0;
	index = 10; size_I[index] = 1; size_J[index] = 0; size_K[index] = 1; size_L[index] = 0;
	index = 26; size_I[index] = 1; size_J[index] = 0; size_K[index] = 1; size_L[index] = 0;
	index = 42; size_I[index] = 1; size_J[index] = 0; size_K[index] = 1; size_L[index] = 0;
	index = 52; size_I[index] = 1; size_J[index] = 0; size_K[index] = 1; size_L[index] = 0;
// j,l
	index =  3; size_I[index] = 0; size_J[index] = 1; size_K[index] = 0; size_L[index] = 1;
	index = 11; size_I[index] = 0; size_J[index] = 1; size_K[index] = 0; size_L[index] = 1;
	index = 27; size_I[index] = 0; size_J[index] = 1; size_K[index] = 0; size_L[index] = 1;
	index = 43; size_I[index] = 0; size_J[index] = 1; size_K[index] = 0; size_L[index] = 1;
// i
	index =  6; size_I[index] = 1; size_J[index] = 0; size_K[index] = 0; size_L[index] = 0;
	index = 12; size_I[index] = 1; size_J[index] = 0; size_K[index] = 0; size_L[index] = 0;
	index = 22; size_I[index] = 1; size_J[index] = 0; size_K[index] = 0; size_L[index] = 0;
	index = 44; size_I[index] = 1; size_J[index] = 0; size_K[index] = 0; size_L[index] = 0;
	index = 54; size_I[index] = 1; size_J[index] = 0; size_K[index] = 0; size_L[index] = 0;
// j
	index =  7; size_I[index] = 0; size_J[index] = 1; size_K[index] = 0; size_L[index] = 0;
	index = 13; size_I[index] = 0; size_J[index] = 1; size_K[index] = 0; size_L[index] = 0;
	index = 23; size_I[index] = 0; size_J[index] = 1; size_K[index] = 0; size_L[index] = 0;
	index = 45; size_I[index] = 0; size_J[index] = 1; size_K[index] = 0; size_L[index] = 0;
// k
	index =  8; size_I[index] = 0; size_J[index] = 0; size_K[index] = 1; size_L[index] = 0;
	index = 14; size_I[index] = 0; size_J[index] = 0; size_K[index] = 1; size_L[index] = 0;
	index = 24; size_I[index] = 0; size_J[index] = 0; size_K[index] = 1; size_L[index] = 0;
	index = 46; size_I[index] = 0; size_J[index] = 0; size_K[index] = 1; size_L[index] = 0;
	index = 56; size_I[index] = 0; size_J[index] = 0; size_K[index] = 1; size_L[index] = 0;
// l
	index =  9; size_I[index] = 0; size_J[index] = 0; size_K[index] = 0; size_L[index] = 1;
	index = 15; size_I[index] = 0; size_J[index] = 0; size_K[index] = 0; size_L[index] = 1;
	index = 25; size_I[index] = 0; size_J[index] = 0; size_K[index] = 0; size_L[index] = 1;
	index = 47; size_I[index] = 0; size_J[index] = 0; size_K[index] = 0; size_L[index] = 1;

// These functions is used to pick the function dependent on the previous state
	// As default point to the error function
	init_array(p2calc,    p2calc_size, &fold::functionerror);
	init_array(p2calc_c1, p2calc_size, &fold::functionerror);
	init_array(p2calc_c2, p2calc_size, &fold::functionerror);
	init_array(p2calc_d1, p2calc_size, &fold::functionerror);
	init_array(p2calc_d2, p2calc_size, &fold::functionerror);
	init_array(p2calc_f1, p2calc_size, &fold::functionerror);
	init_array(p2calc_f2, p2calc_size, &fold::functionerror);
	init_array(p2calc_f3, p2calc_size, &fold::functionerror);
	init_array(p2calc_f4, p2calc_size, &fold::functionerror);

	p2calc[0] = &fold::hairpin_end;
	p2calc[1] = &fold::hairpin_end;
	p2calc[2] = &fold::hairpin_end;
	p2calc[3] = &fold::hairpin_end;
	p2calc[4] = &fold::hairpin_end;
	p2calc[5] = &fold::second_hpbp;
	p2calc[6] = &fold::hairpin_end;
	p2calc[7] = &fold::hairpin_end;
	p2calc[8] = &fold::hairpin_end;
	p2calc[9] = &fold::hairpin_end;
	p2calc[10] = &fold::bulge;
	p2calc[11] = &fold::bulge;
	p2calc[12] = &fold::bulge;
	p2calc[13] = &fold::bulge;
	p2calc[14] = &fold::bulge;
	p2calc[15] = &fold::bulge;
	p2calc[21] = &fold::internalLoop;
	p2calc[22] = &fold::internalLoop;
	p2calc[23] = &fold::internalLoop;
	p2calc[24] = &fold::internalLoop;
	p2calc[25] = &fold::internalLoop;
	p2calc[26] = &fold::internalLoop;
	p2calc[27] = &fold::internalLoop;
	p2calc[28] = &fold::internalLoop;
	p2calc[29] = &fold::second_ilbp;
	p2calc[30] = &fold::singleBpI2stem;
	p2calc[31] = &fold::singleBpK2stem;
	p2calc[40] = &fold::mblDS;
	p2calc[41] = &fold::mblDS;
	p2calc[42] = &fold::mblDS;
	p2calc[43] = &fold::mblDS;
	p2calc[44] = &fold::mblDS;
	p2calc[45] = &fold::mblDS;
	p2calc[46] = &fold::mblDS;
	p2calc[47] = &fold::mblDS;
	p2calc[49] = &fold::mblLast;
	p2calc[52] = &fold::mblDS;
	p2calc[54] = &fold::mblDS;
	p2calc[56] = &fold::mblDS;
	p2calc[61] = &fold::bulgestem;
	p2calc[63] = &fold::stem;
	p2calc[p2calc_size-1] = &fold::bigneg;

	p2calc_c1[0] = &fold::bigneg;
	p2calc_c1[1] = &fold::bigneg;
	p2calc_c1[2] = &fold::bigneg;
	p2calc_c1[3] = &fold::bigneg;
	p2calc_c1[4] = &fold::bigneg;
	p2calc_c1[5] = &fold::bigneg;
	p2calc_c1[6] = &fold::bigneg;
	p2calc_c1[7] = &fold::bigneg;
	p2calc_c1[8] = &fold::bigneg;
	p2calc_c1[9] = &fold::bigneg;
	p2calc_c1[10] = &fold::bigneg;
	p2calc_c1[11] = &fold::bigneg;
	p2calc_c1[12] = &fold::bigneg;
	p2calc_c1[13] = &fold::bigneg;
	p2calc_c1[14] = &fold::bigneg;
	p2calc_c1[15] = &fold::bigneg;
	p2calc_c1[21] = &fold::bigneg;
	p2calc_c1[22] = &fold::bigneg;
	p2calc_c1[23] = &fold::bigneg;
	p2calc_c1[24] = &fold::bigneg;
	p2calc_c1[25] = &fold::bigneg;
	p2calc_c1[26] = &fold::bigneg;
	p2calc_c1[27] = &fold::bigneg;
	p2calc_c1[28] = &fold::bigneg;
	p2calc_c1[29] = &fold::bigneg;
	p2calc_c1[30] = &fold::bigneg;
	p2calc_c1[31] = &fold::bigneg;
	p2calc_c1[40] = &fold::bigneg;
	p2calc_c1[41] = &fold::bigneg;
	p2calc_c1[42] = &fold::bigneg;
	p2calc_c1[43] = &fold::bigneg;
	p2calc_c1[44] = &fold::bigneg;
	p2calc_c1[45] = &fold::bigneg;
	p2calc_c1[46] = &fold::bigneg;
	p2calc_c1[47] = &fold::bigneg;
	p2calc_c1[49] = &fold::bigneg;
	p2calc_c1[52] = &fold::bigneg;
	p2calc_c1[54] = &fold::bigneg;
	p2calc_c1[56] = &fold::bigneg;
	p2calc_c1[61] = &fold::bigneg;
	p2calc_c1[63] = &fold::stem2singleBpI;
	p2calc_c1[p2calc_size-1] = &fold::bigneg;


	p2calc_c2[0] = &fold::bigneg;
	p2calc_c2[1] = &fold::bigneg;
	p2calc_c2[2] = &fold::bigneg;
	p2calc_c2[3] = &fold::bigneg;
	p2calc_c2[4] = &fold::bigneg;
	p2calc_c2[5] = &fold::bigneg;
	p2calc_c2[6] = &fold::bigneg;
	p2calc_c2[7] = &fold::bigneg;
	p2calc_c2[8] = &fold::bigneg;
	p2calc_c2[9] = &fold::bigneg;
	p2calc_c2[10] = &fold::bigneg;
	p2calc_c2[11] = &fold::bigneg;
	p2calc_c2[12] = &fold::bigneg;
	p2calc_c2[13] = &fold::bigneg;
	p2calc_c2[14] = &fold::bigneg;
	p2calc_c2[15] = &fold::bigneg;
	p2calc_c2[21] = &fold::bigneg;
	p2calc_c2[22] = &fold::bigneg;
	p2calc_c2[23] = &fold::bigneg;
	p2calc_c2[24] = &fold::bigneg;
	p2calc_c2[25] = &fold::bigneg;
	p2calc_c2[26] = &fold::bigneg;
	p2calc_c2[27] = &fold::bigneg;
	p2calc_c2[28] = &fold::bigneg;
	p2calc_c2[29] = &fold::bigneg;
	p2calc_c2[30] = &fold::bigneg;
	p2calc_c2[31] = &fold::bigneg;
	p2calc_c2[40] = &fold::bigneg;
	p2calc_c2[41] = &fold::bigneg;
	p2calc_c2[42] = &fold::bigneg;
	p2calc_c2[43] = &fold::bigneg;
	p2calc_c2[44] = &fold::bigneg;
	p2calc_c2[45] = &fold::bigneg;
	p2calc_c2[46] = &fold::bigneg;
	p2calc_c2[47] = &fold::bigneg;
	p2calc_c2[49] = &fold::bigneg;
	p2calc_c2[52] = &fold::bigneg;
	p2calc_c2[54] = &fold::bigneg;
	p2calc_c2[56] = &fold::bigneg;
	p2calc_c2[61] = &fold::bigneg;
	p2calc_c2[63] = &fold::stem2singleBpK;
	p2calc_c2[p2calc_size-1] = &fold::bigneg;

	p2calc_d1[0] = &fold::hairpinIK;
	p2calc_d1[1] = &fold::hairpinIK;
	p2calc_d1[2] = &fold::hairpinIK;
	p2calc_d1[3] = &fold::hairpinIK;
	p2calc_d1[4] = &fold::hairpinIK;
	p2calc_d1[5] = &fold::hairpinIK;
	p2calc_d1[6] = &fold::hairpinIK;
	p2calc_d1[7] = &fold::hairpinIK;
	p2calc_d1[8] = &fold::hairpinIK;
	p2calc_d1[9] = &fold::hairpinIK;
	p2calc_d1[10] = &fold::bulgeIK2bulge;
	p2calc_d1[11] = &fold::internalIK;
	p2calc_d1[12] = &fold::bulgeIK2bulge;
	p2calc_d1[13] = &fold::internalIK;
	p2calc_d1[14] = &fold::bulgeIK2bulge;
	p2calc_d1[15] = &fold::internalIK;
	p2calc_d1[20] = &fold::internalIK;
	p2calc_d1[21] = &fold::internalIK;
	p2calc_d1[22] = &fold::internalIK;
	p2calc_d1[23] = &fold::internalIK;
	p2calc_d1[24] = &fold::internalIK;
	p2calc_d1[25] = &fold::internalIK;
	p2calc_d1[26] = &fold::internalIK;
	p2calc_d1[27] = &fold::internalIK;
	p2calc_d1[28] = &fold::internalIK;
	p2calc_d1[29] = &fold::internalIK;
	p2calc_d1[30] = &fold::internalIK;
	p2calc_d1[31] = &fold::internalIK;
	p2calc_d1[40] = &fold::mblSSIKpMbl;
	p2calc_d1[41] = &fold::mblSSIK;
	p2calc_d1[42] = &fold::mblSSIK;
	p2calc_d1[43] = &fold::mblSSIK;
	p2calc_d1[44] = &fold::mblSSIK;
	p2calc_d1[45] = &fold::mblSSIK;
	p2calc_d1[46] = &fold::mblSSIK;
	p2calc_d1[47] = &fold::mblSSIK;
	p2calc_d1[49] = &fold::mblSSIK;
	p2calc_d1[52] = &fold::mblSSIKpMbl;
	p2calc_d1[54] = &fold::mblSSIKpMbl;
	p2calc_d1[56] = &fold::mblSSIKpMbl;
	p2calc_d1[61] = &fold::internalIK;
	p2calc_d1[63] = &fold::stem2bulgeIK;
	p2calc_d1[p2calc_size-1] = &fold::bigneg;

	p2calc_d2[0] = &fold::hairpinJL;
	p2calc_d2[1] = &fold::hairpinJL;
	p2calc_d2[2] = &fold::hairpinJL;
	p2calc_d2[3] = &fold::hairpinJL;
	p2calc_d2[4] = &fold::hairpinJL;
	p2calc_d2[5] = &fold::hairpinJL;
	p2calc_d2[6] = &fold::hairpinJL;
	p2calc_d2[7] = &fold::hairpinJL;
	p2calc_d2[8] = &fold::hairpinJL;
	p2calc_d2[9] = &fold::hairpinJL;
	p2calc_d2[10] = &fold::internalJL;
	p2calc_d2[11] = &fold::bulgeJL2bulge;
	p2calc_d2[12] = &fold::internalJL;
	p2calc_d2[13] = &fold::bulgeJL2bulge;
	p2calc_d2[14] = &fold::internalJL;
	p2calc_d2[15] = &fold::bulgeJL2bulge;
	p2calc_d2[20] = &fold::internalJL;
	p2calc_d2[21] = &fold::internalJL;
	p2calc_d2[22] = &fold::internalJL;
	p2calc_d2[23] = &fold::internalJL;
	p2calc_d2[24] = &fold::internalJL;
	p2calc_d2[25] = &fold::internalJL;
	p2calc_d2[26] = &fold::internalJL;
	p2calc_d2[27] = &fold::internalJL;
	p2calc_d2[28] = &fold::internalJL;
	p2calc_d2[29] = &fold::internalJL;
	p2calc_d2[30] = &fold::internalJL;
	p2calc_d2[31] = &fold::internalJL;
	p2calc_d2[40] = &fold::mblSSJL;
	p2calc_d2[41] = &fold::mblSSJL;
	p2calc_d2[42] = &fold::mblSSJL;
	p2calc_d2[43] = &fold::mblSSJL;
	p2calc_d2[44] = &fold::mblSSJL;
	p2calc_d2[45] = &fold::mblSSJL;
	p2calc_d2[46] = &fold::mblSSJL;
	p2calc_d2[47] = &fold::mblSSJL;
	p2calc_d2[49] = &fold::mblSSJL;
	p2calc_d2[52] = &fold::mblSSJL;
	p2calc_d2[54] = &fold::mblSSJL;
	p2calc_d2[56] = &fold::mblSSJL;
	p2calc_d2[61] = &fold::internalJL;
	p2calc_d2[63] = &fold::stem2bulgeJL;
	p2calc_d2[p2calc_size-1] = &fold::bigneg;

	p2calc_f1[0] = &fold::hairpinI;
	p2calc_f1[1] = &fold::hairpinI;
	p2calc_f1[2] = &fold::hairpinI;
	p2calc_f1[3] = &fold::hairpinI;
	p2calc_f1[4] = &fold::hairpinI;
	p2calc_f1[5] = &fold::hairpinI;
	p2calc_f1[6] = &fold::hairpinIgap;
	p2calc_f1[7] = &fold::hairpinI;
	p2calc_f1[8] = &fold::hairpinI;
	p2calc_f1[9] = &fold::hairpinI;
	p2calc_f1[10] = &fold::bulgeI2bulge;
	p2calc_f1[11] = &fold::internalI;
	p2calc_f1[12] = &fold::bulgeI2bulgegap;
	p2calc_f1[13] = &fold::internalI;
	p2calc_f1[14] = &fold::bulgeI2bulge;
	p2calc_f1[15] = &fold::internalI;
	p2calc_f1[20] = &fold::internalI;
	p2calc_f1[21] = &fold::internalI;
	p2calc_f1[22] = &fold::internalIgap;
	p2calc_f1[23] = &fold::internalI;
	p2calc_f1[24] = &fold::internalI;
	p2calc_f1[25] = &fold::internalI;
	p2calc_f1[26] = &fold::internalI;
	p2calc_f1[27] = &fold::internalI;
	p2calc_f1[28] = &fold::internalI;
	p2calc_f1[29] = &fold::internalI;
	p2calc_f1[30] = &fold::internalI;
	p2calc_f1[31] = &fold::internalI;
	p2calc_f1[40] = &fold::mblSSIpMbl;
	p2calc_f1[41] = &fold::mblSSI;
	p2calc_f1[42] = &fold::mblSSI;
	p2calc_f1[43] = &fold::mblSSI;
	p2calc_f1[44] = &fold::mblSSIgap;
	p2calc_f1[45] = &fold::mblSSI;
	p2calc_f1[46] = &fold::mblSSI;
	p2calc_f1[47] = &fold::mblSSI;
	p2calc_f1[49] = &fold::mblSSI;
	p2calc_f1[52] = &fold::mblSSIpMbl;
	p2calc_f1[54] = &fold::mblSSIpMblgap;
	p2calc_f1[56] = &fold::mblSSIpMbl;
	p2calc_f1[61] = &fold::internalI;
	p2calc_f1[63] = &fold::stem2bulgeI;
	p2calc_f1[p2calc_size-1] = &fold::bigneg;

	p2calc_f2[0] = &fold::hairpinJ;
	p2calc_f2[1] = &fold::hairpinJ;
	p2calc_f2[2] = &fold::hairpinJ;
	p2calc_f2[3] = &fold::hairpinJ;
	p2calc_f2[4] = &fold::hairpinJ;
	p2calc_f2[5] = &fold::hairpinJ;
	p2calc_f2[6] = &fold::hairpinJ;
	p2calc_f2[7] = &fold::hairpinJgap;
	p2calc_f2[8] = &fold::hairpinJ;
	p2calc_f2[9] = &fold::hairpinJ;
	p2calc_f2[10] = &fold::internalJ;
	p2calc_f2[11] = &fold::bulgeJ2bulge;
	p2calc_f2[12] = &fold::internalJ;
	p2calc_f2[13] = &fold::bulgeJ2bulgegap;
	p2calc_f2[14] = &fold::internalJ;
	p2calc_f2[15] = &fold::bulgeJ2bulge;
	p2calc_f2[20] = &fold::internalJ;
	p2calc_f2[21] = &fold::internalJ;
	p2calc_f2[22] = &fold::internalJ;
	p2calc_f2[23] = &fold::internalJgap;
	p2calc_f2[24] = &fold::internalJ;
	p2calc_f2[25] = &fold::internalJ;
	p2calc_f2[26] = &fold::internalJ;
	p2calc_f2[27] = &fold::internalJ;
	p2calc_f2[28] = &fold::internalJ;
	p2calc_f2[29] = &fold::internalJ;
	p2calc_f2[30] = &fold::internalJ;
	p2calc_f2[31] = &fold::internalJ;
	p2calc_f2[40] = &fold::mblSSJ;
	p2calc_f2[41] = &fold::mblSSJ;
	p2calc_f2[42] = &fold::mblSSJ;
	p2calc_f2[43] = &fold::mblSSJ;
	p2calc_f2[44] = &fold::mblSSJ;
	p2calc_f2[45] = &fold::mblSSJgap;
	p2calc_f2[46] = &fold::mblSSJ;
	p2calc_f2[47] = &fold::mblSSJ;
	p2calc_f2[49] = &fold::mblSSJ;
	p2calc_f2[52] = &fold::mblSSJ;
	p2calc_f2[54] = &fold::mblSSJ;
	p2calc_f2[56] = &fold::mblSSJ;
	p2calc_f2[61] = &fold::internalJ;
	p2calc_f2[63] = &fold::stem2bulgeJ;
	p2calc_f2[p2calc_size-1] = &fold::bigneg;

	p2calc_f3[0] = &fold::hairpinK;
	p2calc_f3[1] = &fold::hairpinK;
	p2calc_f3[2] = &fold::hairpinK;
	p2calc_f3[3] = &fold::hairpinK;
	p2calc_f3[4] = &fold::hairpinK;
	p2calc_f3[5] = &fold::hairpinK;
	p2calc_f3[6] = &fold::hairpinK;
	p2calc_f3[7] = &fold::hairpinK;
	p2calc_f3[8] = &fold::hairpinKgap;
	p2calc_f3[9] = &fold::hairpinK;
	p2calc_f3[10] = &fold::bulgeK2bulge;
	p2calc_f3[11] = &fold::internalK;
	p2calc_f3[12] = &fold::bulgeK2bulge;
	p2calc_f3[13] = &fold::internalK;
	p2calc_f3[14] = &fold::bulgeK2bulgegap;
	p2calc_f3[15] = &fold::internalK;
	p2calc_f3[20] = &fold::internalK;
	p2calc_f3[21] = &fold::internalK;
	p2calc_f3[22] = &fold::internalK;
	p2calc_f3[23] = &fold::internalK;
	p2calc_f3[24] = &fold::internalKgap;
	p2calc_f3[25] = &fold::internalK;
	p2calc_f3[26] = &fold::internalK;
	p2calc_f3[27] = &fold::internalK;
	p2calc_f3[28] = &fold::internalK;
	p2calc_f3[29] = &fold::internalK;
	p2calc_f3[30] = &fold::internalK;
	p2calc_f3[31] = &fold::internalK;
	p2calc_f3[40] = &fold::mblSSKpMbl;
	p2calc_f3[41] = &fold::mblSSK;
	p2calc_f3[42] = &fold::mblSSK;
	p2calc_f3[43] = &fold::mblSSK;
	p2calc_f3[44] = &fold::mblSSK;
	p2calc_f3[45] = &fold::mblSSK;
	p2calc_f3[46] = &fold::mblSSKgap;
	p2calc_f3[47] = &fold::mblSSK;
	p2calc_f3[49] = &fold::mblSSK;
	p2calc_f3[52] = &fold::mblSSKpMbl;
	p2calc_f3[54] = &fold::mblSSKpMbl;
	p2calc_f3[56] = &fold::mblSSKpMblgap;
	p2calc_f3[61] = &fold::internalK;
	p2calc_f3[63] = &fold::stem2bulgeK;
	p2calc_f3[p2calc_size-1] = &fold::bigneg;

	p2calc_f4[0] = &fold::hairpinL;
	p2calc_f4[1] = &fold::hairpinL;
	p2calc_f4[2] = &fold::hairpinL;
	p2calc_f4[3] = &fold::hairpinL;
	p2calc_f4[4] = &fold::hairpinL;
	p2calc_f4[5] = &fold::hairpinL;
	p2calc_f4[6] = &fold::hairpinL;
	p2calc_f4[7] = &fold::hairpinL;
	p2calc_f4[8] = &fold::hairpinL;
	p2calc_f4[9] = &fold::hairpinLgap;
	p2calc_f4[10] = &fold::internalL;
	p2calc_f4[11] = &fold::bulgeL2bulge;
	p2calc_f4[12] = &fold::internalL;
	p2calc_f4[13] = &fold::bulgeL2bulge;
	p2calc_f4[14] = &fold::internalL;
	p2calc_f4[15] = &fold::bulgeL2bulgegap;
	p2calc_f4[20] = &fold::internalL;
	p2calc_f4[21] = &fold::internalL;
	p2calc_f4[22] = &fold::internalL;
	p2calc_f4[23] = &fold::internalL;
	p2calc_f4[24] = &fold::internalL;
	p2calc_f4[25] = &fold::internalLgap;
	p2calc_f4[26] = &fold::internalL;
	p2calc_f4[27] = &fold::internalL;
	p2calc_f4[28] = &fold::internalL;
	p2calc_f4[29] = &fold::internalL;
	p2calc_f4[30] = &fold::internalL;
	p2calc_f4[31] = &fold::internalL;
	p2calc_f4[40] = &fold::mblSSL;
	p2calc_f4[41] = &fold::mblSSL;
	p2calc_f4[42] = &fold::mblSSL;
	p2calc_f4[43] = &fold::mblSSL;
	p2calc_f4[44] = &fold::mblSSL;
	p2calc_f4[45] = &fold::mblSSL;
	p2calc_f4[46] = &fold::mblSSL;
	p2calc_f4[47] = &fold::mblSSLgap;
	p2calc_f4[49] = &fold::mblSSL;
	p2calc_f4[52] = &fold::mblSSL;
	p2calc_f4[54] = &fold::mblSSL;
	p2calc_f4[56] = &fold::mblSSL;
	p2calc_f4[61] = &fold::internalL;
	p2calc_f4[63] = &fold::stem2bulgeL;
	p2calc_f4[p2calc_size-1] = &fold::bigneg;


// These two arrays controls which states are allowed to be part of a branch
// point.
// The left side of a branch point can only be a stem (only state 63)
// The right side can be either a stem, a branch point, or an ik bulge and a
// stem (states 10, 12 ,14, 40, 52, 54, 56 and 63)
	init_array(branch_left, p2calc_size, false);
	init_array(branch_right, p2calc_size, false);

	branch_left[63] = true;

	branch_right[10] = true;
	branch_right[12] = true;
	branch_right[14] = true;
	branch_right[40] = true;
	branch_right[52] = true;
	branch_right[54] = true;
	branch_right[56] = true;
	branch_right[63] = true;
}

#endif /*FOLD */
