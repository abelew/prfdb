#include "fold.cxx" // The foldalign algorithm
#include "backtrack.cxx" // The backtrack algorithm
#include "sequence.cxx" // Stores the sequences
#include "sequenceArg.cxx"
#include "scorematrix.cxx"
#include "seqs.cxx"
#include "arguments.cxx"
#include "helper.cxx"
#include <stdlib.h>
#include <string>
#include <unistd.h>

/******************************************************************************
*                                                                             *
*   Copyright 2004 - 2005 Jakob Hull Havgaard, hull@bioinf.kvl.dk             *
*                                                                             *
*   This file is part of Foldalign                                            *
*                                                                             *
*   Foldalign is free software; you can redistribute it and/or modify         *
*   it under the terms of the GNU General Public License as published by      *
*   the Free Software Foundation; either version 2 of the License, or         *
*   (at your option) any later version.                                       *
*                                                                             *
*   Foldalign is distributed in the hope that it will be useful,              *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of            *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
*   GNU General Public License for more details.                              *
*                                                                             *
*   You should have received a copy of the GNU General Public License         *
*   along with Foldalign; if not, write to the Free Software                  *
*   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
*                                                                             *
******************************************************************************/

void errorDelete(matrix_D<int>*& D, matrix_D<char>*& S, matrix_D<short>*& L, results<int>*& res) {
	// This function is used to try to clean up during an error
	try {
		// if this point is reached then D, S and res must have been allocated
		// and is therefor deleted
		delete D;
		delete S;
		delete L;
		delete res;
	}
	catch (...) {
		cerr << "A serious error occurred during the clean up after the error." << endl;
		cerr << "Foldalign will still attempt to continue with any remaining alignments." << endl;
	}
}

int align(sequence* seq_1, sequence* seq_2, arguments arg, scorematrix<int>& score) {
	int len_1; // Short names for the length of the sequences
	int len_2;
	matrix_D<int>* D;
	matrix_D<char>* S;
	matrix_D<short>* L;
	results<int>* res;
	int i = arg.intopt("-i");
	int j = arg.intopt("-j");
	int k = arg.intopt("-k");
	int l = arg.intopt("-l");
	try {
		if ((i != 1) || (j != -1)) {
			if (i > seq_1->getLength()) {cerr << "The start position -i " << i << " in sequence: " << seq_1->getName() << " is higher than the length of the sequence: " << seq_1->getLength() << endl; throw -1;}
			if (i < 1) {
				cerr << "The start position -i " << i << " must be 1 or larger. The start position has been set to 1" << endl;
				i = 1;
			}
			if ((j < i) && (j != -1)) {cerr << "The end position -j " << j << " is less than the start position -i " << i << endl; throw -1;}
			if (j > seq_1->getLength()) {
				cerr << "The end position -j " << j << " is higher than the length of sequence: " << seq_1->getName() << "'s length. The end position has been set to the sequence length: " << seq_1->getLength() << endl;
				j = -1;
			}
			if (j == -1) {j = seq_1->getLength(); arg.setInt("-j", j);}
			len_1 = j - i +1;
		}
		else {
			len_1 = seq_1->getLength(); // Short names for the length of the sequences
			arg.setInt("-j", len_1);
			j = len_1;
		}
		if ((k != 1) || (l != -1)) {
			if (k > seq_2->getLength()) {cerr << "The start position -k " << k << " in sequence: " << seq_2->getName() << " is higher than the length of the sequence: " << seq_2->getLength() << endl; throw -1;}
			if (k < 1) {
				cerr << "The start position -k " << k << " must be 1 or larger. The start position has been set to 1" << endl;
				k = 1;
			}
			if ((l < k) && (l != -1)) {cerr << "The end position -l " << l << " is less than the start position -k " << k << endl; throw -1;}
			if (l > seq_2->getLength()) {
				cerr << "The end position -l " << l << " is higher than the length of sequence: " << seq_2->getName() << "'s length. The end position has been set to the sequence length: " << seq_2->getLength() << endl;
				l = -1;
			}
			if (l == -1) {l = seq_2->getLength(); arg.setInt("-l", l);}
			len_2 = l - k +1;
		}
		else {
			len_2 = seq_2->getLength(); // Short names for the length of the sequences
			arg.setInt("-l", len_2);
			l = len_2;
		}
		if (len_1 == 0) {
			cerr << "Sequence " << seq_1->getName() << " is empty. Skipping" << endl;
			return -1;
		}
		if (len_2 == 0) {
			cerr << "Sequence " << seq_2->getName() << " is empty. Skipping" << endl;
			return -1;
		}
		if (len_1 < len_2) {
			helper::swap<sequence*>(seq_1, seq_2);
			arg.addBool("switch", true);
			helper::swap<int>(len_1, len_2);
			helper::swap<int>(i,k);
			helper::swap<int>(j,l);
		}
		else {arg.addBool("switch", false);}
		score.checkSize(len_1);
// Handle lambda and delta < 1
		if (arg.boolopt("-global") && (arg.intopt("-max_length") > 0) && (arg.intopt("-max_length") < len_1)) {cerr << "Using option -global with a -max_length shorter than the longest of the two sequence is not possible. Please remove either option -global or -max_length. Skipping sequences" << endl; return -1;}
		if (arg.intopt("-max_diff") < 1) {arg.setInt("-max_diff", len_1);}
		if (arg.intopt("-max_diff") > len_1) {arg.setInt("-max_diff", len_1);}
		if (arg.intopt("-max_length") < 1) {arg.setInt("-max_length", len_2+arg.intopt("-max_diff"));}
		if ((arg.intopt("-max_length") > (len_2 + arg.intopt("-max_diff"))) && !arg.boolopt("-global") ) {arg.setInt("-max_length", len_2+arg.intopt("-max_diff"));}
		if (arg.intopt("-max_length") > len_1 ) {arg.setInt("-max_length", len_1);}
		if (arg.intopt("-min_loop") > arg.intopt("-max_length")) {arg.setInt("-min_loop", arg.intopt("-max_length"));}
		if (arg.intopt("-chunk_size") < arg.intopt("-max_length")) {arg.setInt("-chunk_size",arg.intopt("-max_length"));}
		if (arg.boolopt("-global")) {arg.setInt("-chunk_size",((len_1+1)/2+1));}
		if (arg.intopt("-chunk_size") > (((len_1+1)/2)+1)) { arg.setInt("-chunk_size",((len_1+1)/2+1));}
		if (arg.boolopt("-global") && ((arg.intopt("-max_diff") + len_2) < len_1)) {cerr << "The length difference between the two sequences " << seq_1->getName() << " and " << seq_2->getName() << " is " << (len_1 - len_2) << " nucleotides which is more than the maximum length difference -max_diff " << arg.intopt("-max_diff") << ". It is therefore not possible to use option -global. Please increase -max_diff or remove option -global. Skipping sequences" << endl; return -1;}

// Since it makes no sense to run foldalign with option -no_backtrack without
// also using option -plot_score option -plot_score is set when -no_backtrack
// is set
		if (arg.boolopt("-no_backtrack")) {
			if (!arg.boolopt("-plot_score")) {
				arg.setBool("-plot_score", true);
			}
		}
// Initialize the matrix objects
		arg.addBool("realigning", false); // Used to indicate if this is a realignment run or not

		try {
			D = new matrix_D<int>(len_1, arg, -114748364);
		}
		catch (...) {
			throw;
		}
		try {
			S = new matrix_D<char>(len_1, arg, 69);
		}
		catch (...) {
			// if this point is reached then D must have been allocated
			// and is therefor deleted
			delete D;
			throw;
		}
		try {
			L = new matrix_D<short>(len_1, arg, -15000);
		}
		catch (...) {
			delete D;
			delete S;
			throw;
		}
		try {
			res = new results<int>();
		}
		catch (...) {
			// if this point is reached then D and S must have been allocated
			// and is therefor deleted
			delete D;
			delete S;
			delete L;
			throw;
		}
	}
	catch (...) {
		cerr << "A serious error occurred during setup stage before the alignment of sequence " << seq_1->getName() << " and sequence " << seq_2->getName() << "." << endl;
		cerr << "Foldalign will attempt to continue with any remaining alignments." << endl;
		return -1;
	}
	try {
// Initialize the fold object
		fold RNA(seq_1, seq_2, arg, score, D, S, L);
// do the aligning
		RNA.run_align(i, j, k, l, res);
	}
	catch (...) {
		cerr << "A serious error occurred during the alignment of sequence " << seq_1->getName() << " and sequence " << seq_2->getName() << "." << endl;
		cerr << "Foldalign will attempt to continue with any remaining alignments." << endl;
		cout << "; ==============================================================================" << endl;
		cout << "; ******************************************************************************" << endl;
		cout << "; ******************************************************************************" << endl;
		errorDelete(D, S, L, res);
		return -1;
	}
	try {
// and finish with the traceback
		if (!arg.boolopt("-no_backtrack")) {
			backtrack hit(seq_1, seq_2, arg, score, D, S, L);
		// First case non-global default traceback of the best hit
			if (!arg.boolopt("-global")) {hit.traceback(res);}
			else {
		// Traceback of the global alignment
				res->store(D->getD(i, (len_1-1), k, (len_2-1)), i, (len_1-1), k, (len_2-1));
				hit.traceback(res);
			}
		}
	}
	catch (...) {
		cerr << "A serious error occurred during the backtrack of sequence " << seq_1->getName() << " and sequence " << seq_2->getName() << "." << endl;
		cerr << "Foldalign will attempt to continue with any remaining alignments." << endl;
		cout << "; ******************************************************************************" << endl;
		cout << "; ******************************************************************************" << endl;
		errorDelete(D, S, L, res);
		return -1;
	}
	try {
		delete res;
		delete D;
		delete S;
		delete L;
	}
	catch (...) {
		cerr << "A serious error occurred during the clean up after the alignment of sequence " << seq_1->getName() << " and sequence " << seq_2->getName() << "." << endl;
		cerr << "Foldalign will attempt to continue with any remaining alignments." << endl;
		return -1;
	}
	return 0;
}
	
int main(int argc, char* argv[]) {
// Setup the posible options
	arguments arg(argc, argv); // pass the options

	std::string version = "2.0.3";
	std::string description = "Copyright by Jakob Hull Havgaard, 2004 - 2005\nReference: Havgaard et al. Bioinformatics 21(9), 1815-1824, 2005";
	arg.addString("version", version);

// Handle -version option
	if (arg.boolopt("-version")) {
		std::cout << "FOLDALIGN " << version << std::endl;
		std::cout << description << std::endl;
		exit(0);
	}

// Handle -help and -h options
	if (arg.boolopt("-help") || arg.boolopt("-h") || ((arg.numberOfArguments()!=2) && (arg.numberOfArguments()!=1)) ) {
		std::cout << "FOLDALIGN " << version << std::endl;
		std::cout << description << std::endl;
		std::cout << "Usage:\nfoldalign [<options>] <file_1> [<file_2>]\n";
		std::cout << "FOLDALIGN makes pairwise alignments between two sequence.\n";
		std::cout << "The options are:\n";
		arg.printOptions();
		exit(0);
	}

// Handle the -score_matrix option
	std::string score_name = arg.stringopt("-score_matrix");
	scorematrix<int> score;
	if (score_name.compare("<default>")) {
		scorematrix<int> newscore(score_name);
		score = newscore;
	}

// Read the sequences and align them
	seqs input(arg, score);
	bool more_seq = true;
	while (more_seq) {
		sequence* seq1;
		sequence* seq2;
		more_seq = input.get_next_pair(seq1, seq2, arg, score);
		align(seq1, seq2, arg, score);
	}
	return 0;
}
