#ifndef ARGUMENTS
#define ARGUMENTS
#include<string>
#include<iostream>
#include<stdlib.h>
#include "helper.cxx"

/******************************************************************************
*                                                                             *
*   Copyright 2004 - 2005 Jakob Hull Havgaard, hull@bioinf.kvl.dk             *
*                                                                             *
*   This file is part of FOLDALIGN                                            *
*                                                                             *
*   FOLDALIGN is free software; you can redistribute it and/or modify         *
*   it under the terms of the GNU General Public License as published by      *
*   the Free Software Foundation; either version 2 of the License, or         *
*   (at your option) any later version.                                       *
*                                                                             *
*   FOLDALIGN is distributed in the hope that it will be useful,              *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of            *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
*   GNU General Public License for more details.                              *
*                                                                             *
*   You should have received a copy of the GNU General Public License         *
*   along with FOLDALIGN; if not, write to the Free Software                  *
*   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
*                                                                             *
******************************************************************************/

/* This class is intended to handle the parameters given to the main function
   Written by Jakob Hull Havgaard 2004 hull@bioinf.kvl.dk

   The option parameters are set in the top of arguments function
*/

class arguments {
public:
//Set up and pass the parameters
	inline arguments(int argc, char* argv[]);

// Copy constructor
	inline arguments(const arguments& arg);
	
// Assignment constructor
	inline arguments& operator=(const arguments& arg);
	
// These functions return the value of argument.
// One function pr type of argument
	inline bool boolopt(std::string opt);
	inline int intopt(std::string opt);
	inline std::string stringopt(std::string opt);

// Return the default value of an option
	inline std::string getDefault(std::string name);

// Functions used for returning information about the options
	inline int numberOfOptions() const {return num_arg;};
	inline std::string optionNumber(const int num) const;
	inline std::string descriptionNumber(const int num) const;

// Returns the argument indicated by num
	inline std::string argument(const int num) const;

// Returns the number of arguments
	inline int numberOfArguments() const;

// Set the value of an option
	inline void setInt(const std::string opt, const int val);
	inline void setString(const std::string opt, const std::string val);
	inline void setBool(const std::string opt, const bool val);

// Add a new parameter
	inline void addBool(const std::string opt, const bool val);
	inline void addString(const std::string opt, const std::string val);
	inline void addInt(const std::string opt, const int val);

// Check for the existance of an argument of the given name
	inline bool existIntOpt(const std::string opt) const;
	inline bool existStringOpt(const std::string opt) const;
	inline bool existBoolOpt(const std::string opt) const;

// Print all options and describtions
   inline void printOptions(const int length_name = 20, const int length_desc = 59) const;

// Cleans up
	inline ~arguments();

private:
	int num_arg; // The number of possible arguments. The size of options, defaults and types
	int n_int; // Number of possible int arguments
	int n_bool; // Number of possible bool arguments
	int n_string; // Number of possible string arguments
	std::string* int_opt; // Array of int option names
	int* int_val;         // Array with the int option values
	std::string* bool_opt;// Etc bool
	bool* bool_val;       // Etc bool
	std::string* string_opt; // Etc string
	std::string* string_val; // Etc string
	std::string* arg;		// The arguments
	int n_arg;				// The number of arguments
	std::string* options; // The name of the option
	std::string* value;   // The default value of the option
	std::string* types;   // The type of the option. int, bool and string allowed
	std::string* description; // The description of the option
	// This function defines the options
	inline void setOptions(int& n, std::string*& opt, std::string*& val, std::string*& typ, std::string*& des);
	// This is a helper function for the add parameter functions
	// It copies two arrays
	template<class type1, class type2> inline void assign(type1& to1, type1& from1,type2& to2, type2& from2, int size);
	inline void copyassign(const  arguments& a); // The copy constructor in a form the assignment operator can use
	inline void clean(); // The destructor in a form that can be used by the assignment operator

};	

inline void arguments::setOptions(int& n, std::string*& opt, std::string*& val, std::string*& typ, std::string*& des) {
//************************************************************
// This function defines the options                         *
// When an option is added five things must be added/changed *
// The int num must be set to the number of possible options *
// When adding a new option add one to this number.          *
// An opt line must be made. This line defines the name      *
// of the option.                                            *
// A val line must be added. This is the default value of    *
// the option                                                *
// A typ line indicating the type of the option must be      *
// added. Possible types are bool, int and string.           *
// Finally a description text should be written.             *
// Remember of to use the correct index when writting these  *
// lines                                                     *
//************************************************************
// This number must be updated when new options are added
	n = 22;
	opt = new std::string[n];
// This array contains the name of the option
	opt[0] = "-max_diff";
	opt[1] = "-max_length";
	opt[2] = "-min_loop";
	opt[3] = "-score_matrix";
	opt[4] = "-chunk_size";
	opt[5] = "-ID";
	opt[6] = "-nobranch";
	opt[7] = "-no_backtrack";
	opt[8] = "-global";
	opt[9] = "-i";
	opt[10] = "-j";
	opt[11] = "-k";
	opt[12] = "-l";
	opt[13] = "-format";
	opt[14] = "-plot_score";
	opt[15] = "-align_self";
	opt[16] = "-backtrack_info";
	opt[17] = "-all_scores";
	opt[18] = "-summary";
	opt[19] = "-version";
	opt[20] = "-help";
	opt[21] = "-h";
	val = new std::string[n];
// This array contains the default value
	val[0] = "-1";
	val[1] = "-1";
	val[2] = "3";
	val[3] = "<default>";
	val[4] = "-1";
	val[5] = "n.a.";
	val[6] = "false";
	val[7] = "false";
	val[8] = "false";
	val[9] = "1";
	val[10] = "-1";
	val[11] = "1";
	val[12] = "-1";
	val[13] = "fasta";
	val[14] = "false";
	val[15] = "false";
	val[16] = "false";
	val[17] = "false";
	val[18] = "false";
	val[19] = "false";
	val[20] = "false";
	val[21] = "false";
	typ = new std::string[n];
// This array defines the type of the option
// There three possible types: bool, int and string
	typ[0] ="int";
	typ[1] ="int";
	typ[2] ="int";
	typ[3] ="string";
	typ[4] ="int";
	typ[5] ="string";
	typ[6] ="bool";
	typ[7] ="bool";
	typ[8] ="bool";
	typ[9] ="int";
	typ[10] ="int";
	typ[11] ="int";
	typ[12] ="int";
	typ[13] ="string";
	typ[14] ="bool";
	typ[15] ="bool";
	typ[16] ="bool";
	typ[17] ="bool";
	typ[18] ="bool";
	typ[19] ="bool";
	typ[20] ="bool";
	typ[21] ="bool";
	des = new std::string[n];
// This array holds the description of the option
// used by the help option.
	des[0] = "The maximum length difference between two sequences being aligned. Also known as delta. Default value: infinity.";
	des[1] = "The maximum length of the alignment, not counting gaps. Also known as lambda. Default value: Sequence length.";
	des[2] = "The minimum loop length. Default value 3.";
	des[3] = "Path and filename of a score matrix file.";
	des[4] = "A memory control option. This option controls the length of the sections which one of the sequences is split into. Low values make FOLDALIGN use less memory but run slower. High values make FOLDALIGN use more memory but run faster. Chunk_size must be at least -max_length. Default value: -max_length.";
	des[5] = "Alignment id. Default value: n.a.";
	des[6] = "Turns FOLDALIGN into a stemloop only algorithm. This speeds up the program. Default: off.";
	des[7] = "Turns off backtracking. The best local alignment scores will be print as if option -plot_score had been used.";
	des[8] = "Do global alignments.";
	des[9] = "Start aligning from this position in the first sequence. Default: Position one.";
	des[10] = "Stop aligning at this position in the first sequence. Default: End of the sequence.";
	des[11] = "Start aligning from this position in the second sequence. Default: Position one.";
	des[12] = "Stop aligning at this position in the second sequence. Default: End of the sequence.";
	des[13] = "Specifies the input format. Allowed values: fasta, tab, pair, and commandline. Default: fasta.";
	des[14] = "Print the best local alignment score and its coordinates at all pair of positions between the two sequences.";
	des[15] = "When set, a sequence is also aligned against it self (this is only relevant if only one fasta or tab file is used as input). Default value: off.";
	des[16] = "Adds extra backtrack information to the output. General format score, positions, state. Default value: off.";
	des[17] = "Dumps all the scores and states before storage in the matrixes. Warning: Using this option will generate an extreme amount of output.";
	des[18] = "Output is limited to only the parts above (and including) the ; ======== line.";
	des[19] = "Prints the version number and exits.";
	des[20] = "Prints this text,";
	des[21] = "also prints this text.";
//************************************************************
// End of option setting section.                            *
// Nothing below this point needs changing when options are  *
// added or changed                                          *
//************************************************************
}

// Constructor which parses the main arguments
inline arguments::arguments(int argc, char* argv[]) {
	bool* notFound; //Options not yet found in argv
	int c_int; // current number of int arguments
	int c_bool; // current number of bool arguments
	int c_string; // current number of string arguments
// Define all allowed options and setup the arrays
	setOptions(num_arg, options, value, types, description);
// Array used to check if an option has been handled
// needed because bool option only take one value from argv
// and int and string takes two.
	notFound = new bool[argc];
	for(int j =0; j < argc; j++) {
		notFound[j] = true;
	}
// The number of options
	n_int = c_int = n_bool = c_bool = n_string = c_string = 0;
// Count the number of different types of options
	for(int i=0; i < num_arg; i++) { // At the begining nothing has been found
		if (types[i].compare("int")==0) {n_int++;}
		else {if (types[i].compare("bool")==0) {n_bool++;}
		else {if (types[i].compare("string")==0) {n_string++;}}}
	}
// Allocate memory for the different types of options
	int_opt = new std::string[n_int];
	int_val = new int[n_int];
	bool_opt = new std::string[n_bool];
	bool_val = new bool[n_bool];
	string_opt = new std::string[n_string];
	string_val = new std::string[n_string];
// Handle the bool options
	int next_j=0; // count how far into the option array the count has reached
	for(int i=0; i < n_bool; i++) {
// Setup the default bool options from the arrays
		for(int j=next_j; j < num_arg; j++) {
			if (types[j].compare("bool")==0) {
				bool_opt[i] = options[j];
				if (value[j] .compare( "true")==0) {
					bool_val[i] = true;
				}
				else {
					bool_val[i] = false;
				}
				next_j = j +1;
				break;
			}
		}
// Check the commandline inputs and change the value if necessary
		for(int j =0; j < argc; j++) { // and check if it has been set
			if (bool_opt[i].compare(argv[j])==0) {
				bool_val[i] = !bool_val[i]; // If set change value to the opposite of the default value
				notFound[j] = false;
				c_bool++;
				break;
			}
		}
	}
// Handle int options
	next_j=0; // How far into the option array the count has come
	for(int i=0; i < n_int; i++) {
// Setup the default int options
		for(int j=next_j; j < num_arg; j++) {
			if (types[j].compare("int")==0) {
				int_opt[i] = options[j];
				const char* c_string = value[j].c_str();// new char[len+1];
				int_val[i] = atoi(c_string);
				next_j = j +1;
				break;
			}
		}
// Check the commandline options
		for(int j =1; j < argc; j++) { // and check if it has been set
			if (int_opt[i].compare(argv[j])==0) {
				int_val[i] = atoi(argv[j+1]);
				notFound[j] = false;
				notFound[j+1] = false;
				c_int++;
				break;
			}
		}
	}
// Handle the string options
	next_j=0;
	for(int i=0; i < n_string; i++) {
// Setup the default values
		for(int j=next_j; j < num_arg; j++) {
			if (types[j].compare("string")==0) {
				string_opt[i] = options[j];
				string_val[i] = value[j];
				next_j = j +1;
				break;
			}
		}
// Handle the commandline options
		for(int j =0; j < argc; j++) { // and check if it has been set
			if (string_opt[i].compare(argv[j])==0) {
				string_val[i] = argv[j+1];
				notFound[j] = false;
				notFound[j+1] = false;
				c_string++;
				break;
			}
		}
	}
// Calculate the number of files
	n_arg = argc - c_bool - 2*c_int - 2*c_string-1;
// If any filenames is given - store them
	if (n_arg > 0) {
		arg = new std::string[n_arg];
		for(int i = (argc-n_arg); i < argc; i++) {
			if (argv[i][0] != '-') { // if its starts with a '-' then its not a file but an option
				arg[i - argc + n_arg] = argv[i];
				notFound[i] = false;
			}
		}
	}
// Check for unknown options			
	bool exitFlag = false;
	for(int j =1; j < argc; j++) {
		if(notFound[j]) {
			std::cerr << "Unknown option: " << argv[j] << std::endl;
			exitFlag=true;
		}
	}
	if (exitFlag) {throw -1; exit(-1);}
	delete[] notFound;
}

// Copy constructor
inline arguments::arguments(const arguments& a) {
	copyassign(a);
}

// Assignment constructor
inline arguments& arguments::operator=(const arguments& a) {
	if (this != &a) { // If not the same object
		// Clean up
		clean();
		// Assign the new values
		copyassign(a);
	}
	return *this;
}

inline void arguments::copyassign(const  arguments& a) {
	// Assign the new values
	setOptions(num_arg, options, value, types, description);
	n_int = a.n_int;
	n_bool = a.n_bool;
	n_string = a.n_string;
	n_arg = a.n_arg;
	if (n_arg > 0) {arg = new std::string[n_arg];}
	for(int i=0; i<n_arg; i++) {arg[i] = a.arg[i];}
	int_opt = new std::string[n_int];
	int_val = new int[n_int];
	for(int i=0; i<n_int; i++) {
		int_opt[i] = a.int_opt[i];
		int_val[i] = a.int_val[i];
	}
	string_opt = new std::string[n_string];
	string_val = new std::string[n_string];
	for(int i=0; i<n_string; i++) {
		string_opt[i] = a.string_opt[i];
		string_val[i] = a.string_val[i];
	}
	bool_opt = new std::string[n_bool];
	bool_val = new bool[n_bool];
	for(int i=0; i<n_bool; i++) {
		bool_opt[i] = a.bool_opt[i];
		bool_val[i] = a.bool_val[i];
	}
}

inline std::string arguments::optionNumber(const int num) const {
	if (num >= num_arg) {
		std::string error = "Option number too high. Program error!";
		std::cerr << error << std::endl;
		throw error;
	}
	return options[num];
}

inline std::string arguments::descriptionNumber(const int num) const {
	if (num >= num_arg) {
		std::string error = "Description number too high. Program error!";
		std::cerr << error << std::endl;
		throw error;
	}
	return description[num];
}

inline bool arguments::boolopt(std::string opt) {
	for(int i =0; i<n_bool; i++) {
		if (opt.compare(bool_opt[i])==0) {
			return bool_val[i];
		}
	}
	std::string error = "Non defined option " + opt + ". Program error!";
	std::cerr << error << std::endl;
	throw error;
	return false;
}
	
inline int arguments::intopt(std::string opt) {
	for(int i =0; i<n_int; i++) {
		if (opt.compare(int_opt[i])==0) {
			return int_val[i];
		}
	}
	std::string error = "Non defined option " + opt + ". Program error!";
	std::cerr << error << std::endl;
	throw error;
	return -1;
}

	
inline std::string arguments::stringopt(std::string opt) {
	for(int i =0; i<n_string; i++) {
		if (opt.compare(string_opt[i])==0) {
			return string_val[i];
		}
	}
	std::string error = "Non defined option " + opt + ". Program error!";
	std::cerr << error << std::endl;
	throw error;
	return "";
}


// Return the default argument of an option
inline std::string arguments::getDefault(std::string name) {
	for(int i = 0; i < num_arg; i++) {
		if (options[i].compare(name) == 0) {return value[i];}
	}
	std::cerr << "Program error: No default value for option: " << name << std::endl;
	throw -1;
	return "";
}

inline std::string arguments::argument(const int num) const {
	return arg[num];
}

inline int arguments::numberOfArguments() const {
	return n_arg;
}
	
/**************************************************************
* These functions are used to change the value of an argument *
***************************************************************/

inline void arguments::setInt(const std::string opt, const int val) {
	bool found_flag = false; // False - option not found. True - option found
	for(int i=0; i<n_int; i++) { // Loop through all int options
		if (opt.compare(int_opt[i]) == 0) {
			int_val[i] = val;
			found_flag = true;
			break;
		}
	}
	if (!found_flag) {
		std::string error = "Option not found. Program error.";
		std::cerr << error << std::endl;
		throw error;
	}
}

inline void arguments::setString(const std::string opt, const std::string val) {
	bool found_flag = false; // False - option not found. True - option found
	for(int i=0; i<n_string; i++) { // Loop through all int options
		if (opt.compare(string_opt[i]) == 0) {
			string_val[i] = val;
			found_flag = true;
			break;
		}
	}
	if (!found_flag) {
		std::string error = "Option not found. Program error.";
		std::cerr << error << std::endl;
		throw error;
	}
}

inline void arguments::setBool(const std::string opt, const bool val) {
	bool found_flag = false; // False - option not found. True - option found
	for(int i=0; i<n_bool; i++) { // Loop through all int options
		if (opt.compare(bool_opt[i]) == 0) {
			bool_val[i] = val;
			found_flag = true;
			break;
		}
	}
	if (!found_flag) {
		std::string error = "Option not found. Program error.";
		std::cerr << error << std::endl;
		throw error;
	}
}


/************************************************************
* The functions adds a new parameter to the list of options *
*************************************************************/

template<class type1, class type2> inline void arguments::assign(type1& to1, type1& from1,type2& to2, type2& from2, int size) {
	for(int i=0; i<size; i++) {to1[i] = from1[i]; to2[i] = from2[i];}
}

inline void arguments::addInt(const std::string opt, const int val) {
	std::string* tmp_opt = new std::string[n_int];
	int* tmp_val = new int[n_int];
	assign<std::string*, int*>(tmp_opt, int_opt, tmp_val, int_val, n_int);
	delete[] int_opt;
	delete[] int_val;
	int_opt = new std::string[n_int+1];
	int_val = new int[n_int+1];
	assign<std::string*, int*>(int_opt, tmp_opt, int_val, tmp_val, n_int);
	delete[] tmp_opt;
	delete[] tmp_val;
	int_opt[n_int] = opt;
	int_val[n_int] = val;
	n_int++;
}
	
inline void arguments::addString(const std::string opt, const std::string val) {
	std::string* tmp_opt = new std::string[n_string];
	std::string* tmp_val = new std::string[n_string];
	assign<std::string*, std::string*>(tmp_opt, string_opt, tmp_val, string_val, n_string);
	delete[] string_opt;
	delete[] string_val;
	string_opt = new std::string[n_string+1];
	string_val = new std::string[n_string+1];
	assign<std::string*, std::string*>(string_opt, tmp_opt, string_val, tmp_val, n_string);
	delete[] tmp_opt;
	delete[] tmp_val;
	string_opt[n_string] = opt;
	string_val[n_string] = val;
	n_string++;
}
	
inline void arguments::addBool(const std::string opt, const bool val) {
	std::string* tmp_opt = new std::string[n_bool];
	bool* tmp_val = new bool[n_bool];
	assign<std::string*, bool*>(tmp_opt, bool_opt, tmp_val, bool_val, n_bool);
	delete[] bool_opt;
	delete[] bool_val;
	bool_opt = new std::string[n_bool+1];
	bool_val = new bool[n_bool+1];
	assign<std::string*, bool*>(bool_opt, tmp_opt, bool_val, tmp_val, n_bool);
	delete[] tmp_opt;
	delete[] tmp_val;
	bool_opt[n_bool] = opt;
	bool_val[n_bool] = val;
	n_bool++;
}



/****************************************************************************
* The functions check the existance of an option of the given type and name *
*****************************************************************************/

inline bool arguments::existIntOpt(const std::string opt) const {
	for(int i = 0; i < n_int; i++) {
		if (!int_opt[i].compare(opt)) {return true;}
	}
	return false;
}

inline bool arguments::existStringOpt(const std::string opt) const {
	for(int i = 0; i < n_string; i++) {
		if (!string_opt[i].compare(opt)) {return true;}
	}
	return false;
}

inline bool arguments::existBoolOpt(const std::string opt) const {
	for(int i = 0; i < n_bool; i++) {
		if (!bool_opt[i].compare(opt)) {return true;}
	}
	return false;
}

/**********************************************************************
* This function prints all the options and their descriptions to cout *
**********************************************************************/

inline void arguments::printOptions(const int length_name, const int length_desc) const {
	for (int i=0; i < num_arg; i++) {
		const int len_name = options[i].length();
		std::cout << options[i];
		helper::print_space((length_name - len_name));
		helper::print_line(description[i], length_name, length_desc);
	}
}

inline void arguments::clean() {
	if (n_arg > 0) {delete[] arg;}
	delete[] options;
	delete[] value;
	delete[] types;
	delete[] description;
	delete[] int_opt;
	delete[] int_val;
	delete[] bool_opt;
	delete[] bool_val;
	delete[] string_opt;
	delete[] string_val;
}

/*******************************
* Destructor - nothing special *
********************************/

inline arguments::~arguments() {
	clean();
}

#endif /* ARGUMENTS */
