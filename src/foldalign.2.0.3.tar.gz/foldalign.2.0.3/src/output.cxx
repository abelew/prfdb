#ifndef OUTPUT
#define OUTPUT
#include "arguments.cxx"
#include "sequence.cxx"
#include "helper.cxx"
#include "stack.cxx"
#include <iostream>
#include <string>
#include <math.h>
#include <iomanip>

/******************************************************************************
*                                                                             *
*   Copyright 2004 - 2005 Jakob Hull Havgaard, hull@bioinf.kvl.dk             *
*                                                                             *
*   This file is part of Foldalign                                            *
*                                                                             *
*   Foldalign is free software; you can redistribute it and/or modify         *
*   it under the terms of the GNU General Public License as published by      *
*   the Free Software Foundation; either version 2 of the License, or         *
*   (at your option) any later version.                                       *
*                                                                             *
*   Foldalign is distributed in the hope that it will be useful,              *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of            *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
*   GNU General Public License for more details.                              *
*                                                                             *
*   You should have received a copy of the GNU General Public License         *
*   along with Foldalign; if not, write to the Free Software                  *
*   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
*                                                                             *
******************************************************************************/


// Written by Jakob Hull Havgaard, 2004, hull@bioinf.kvl.dk.
class output {
public:
	inline output(arguments& argu, sequence* one, sequence* two, scorematrix<int>& score) : arg(argu), s_matrix(score) {
		if (arg.boolopt("switch")) {
			seq_1 = two;
			seq_2 = one;
		}
		else {
			seq_1 = one;
			seq_2 = two;
		}
	};
	
	inline void head();
	
	inline void localscorehead();
	
	inline void foldout(stack<int>*& leftPos_1, stack<int>*& leftBasepair_1,stack<int>*& leftPos_2, stack<int>*& leftBasepair_2, int align_start_1, int align_len_1, int align_start_2, int align_len_2, int align_score);

private:
	// These are character used to indicate base-pairs
	// There are two sets. The first one is used when the base-pair is conserved
	// between the sequences, the second is used for insert base-pairs.
	static const char open  = '(';
	static const char close = ')';
	static const char open_one_seq  = '(';
	static const char close_one_seq = ')';
	// This is the unpaired character
	static const char unpaired = '.';

	inline void entry_head(const string name, const string file, const int seq_length, const int score, const int group, const int start, const int end, const int length, char seq[], int org_pos[], int org_bp[], int ali_bp[]);

	inline int makeSequences(char*& seq_1, char*& seq_2, char*& struc, int*& org_pos_1, int*& org_bp_1, int*& ali_bp_1, stack<int>*& leftPos_1, stack<int>*& leftBasepair_1, sequence*& sequ_1, int*& org_pos_2, int*& org_bp_2, int*& ali_bp_2, stack<int>*& leftPos_2, stack<int>*& leftBasepair_2, sequence*& sequ_2);

	inline void outputAlign(std::string name_1, std::string name_2, char sequen_1[], char sequen_2[], char struc[], int length);

	inline void printLine(char line[], int start, int end, string head, int head_space, string title, int title_space);

	inline void parameters();
	
	inline float identity(char sequence1[], char sequence2[], int len, float& similar, float& total);
	
	arguments arg;
	sequence* seq_1; // Stores the sequences
	sequence* seq_2;
	scorematrix<int>& s_matrix; // Contains the score matrixs
};

inline void output::head() {
	std::cout << "; FOLDALIGN           " << arg.stringopt("version") << endl;
	std::cout << "; REFERENCE           J.H. Havgaard, R.B. Lyngs\xF8, G.D. Stormo, J. Gorodkin" <<endl;
	std::cout << "; REFERENCE           Pairwise local structural alignment of RNA sequences" << endl;
	std::cout << "; REFERENCE           with sequence similarity less than 40%" << endl;
	std::cout << "; REFERENCE           Bioinformatics 21(9), 1815-1824, 2005" << endl;
	std::cout << "; ALIGNMENT_ID        " << arg.stringopt("-ID") << endl;
	std::cout << "; ALIGNING            " << seq_1->getName() << " against " << seq_2->getName() << endl;

}

inline void output::localscorehead() {
	head();
	std::cout << "; SEQUENCE_1_COMMENT  " << seq_1->getComment() << endl;
	std::cout << "; SEQUENCE_2_COMMENT  " << seq_2->getComment() << endl;
	std::cout << "; LENGTH_SEQUENCE_1   " << seq_1->getLength() << endl;
	std::cout << "; LENGTH_SEQUENCE_2   " << seq_2->getLength() << endl;
	if (seq_2->getFilename().compare(seq_1->getFilename())) {
	std::cout << "; FILENAMES           " << seq_1->getFilename() << " and " << seq_2->getFilename() << endl;
	}
	else {std::cout << "; FILENAME            " << seq_1->getFilename() << endl;}
	parameters();
	std::cout << "; TYPE                Foldalign_local_scores" << endl;
	std::cout << "; COL 1               label" << endl;
	std::cout << "; COL 2               Alignment_start_position_sequence_1" << endl;
	std::cout << "; COL 3               Alignment_end_position_sequence_1" << endl;
	std::cout << "; COL 4               Alignment_start_position_sequence_2" << endl;
	std::cout << "; COL 5               Alignment_end_position_sequence_2" << endl;
	std::cout << "; COL 6               Alignment_score" << endl;
	std::cout <<"; ------------------------------------------------------------------------------" << endl;
}

inline void output::foldout(stack<int>*& leftPos_1, stack<int>*& leftBasepair_1,stack<int>*& leftPos_2, stack<int>*& leftBasepair_2, int align_start_1, int align_len_1, int align_start_2, int align_len_2, int align_score) {
	if (arg.boolopt("switch")) {
// Switch back. The orginal switch was done in foldalign.cxx
// The constructor switches seq_1 and seq_2 so they are not switched here
		helper::swap(leftBasepair_1, leftBasepair_2);
		helper::swap(leftPos_1, leftPos_2);
		helper::swap(align_start_1, align_start_2);
		helper::swap(align_len_1, align_len_2);
	}

// Setting up
	int lambda = arg.intopt("-max_length");
	char* sequence_1 = new char[2*lambda]; // Stores the sequence
	char* sequence_2 = new char[2*lambda];
	char* structure = new char[2*lambda];  // Stores the structure of the first sequence
	int* org_pos_1 = new int[2*lambda];   // Position in original sequence
	int* org_pos_2 = new int[2*lambda];
	int* org_bp_1 = new int[2*lambda];    // Base-pairing in original coordinates
	int* org_bp_2 = new int[2*lambda];
	int* ali_bp_1 = new int[2*lambda];    // Base-pairing in the new coordinates
	int* ali_bp_2 = new int[2*lambda];
	int len_name_1 = seq_1->getName().length();
	int len_name_2 = seq_2->getName().length();
	std::string local_name_1;
	std::string local_name_2;
	int length_name_field = 13;
	int length_comment = 43;
	int length_space = 15;
	for(int i=0; i < 2*lambda; i++) {structure[i] = '!';}
// Build the sequences and the structure

	int total_length = makeSequences(sequence_1, sequence_2, structure, org_pos_1, org_bp_1, ali_bp_1, leftPos_1, leftBasepair_1, seq_1, org_pos_2, org_bp_2, ali_bp_2, leftPos_2, leftBasepair_2, seq_2);

// Ready to start printing
	if (len_name_1 > length_name_field) {local_name_1 = seq_1->getName().substr(0,length_name_field);}
	else {
		int tmp = length_name_field - len_name_1;
		local_name_1 = seq_1->getName();
		for(int i=0; i<tmp; i++) {local_name_1+=' ';}
	}
	if (len_name_2 > length_name_field) {local_name_2 = seq_2->getName().substr(0,length_name_field);}
	else {
		int tmp = length_name_field - len_name_2;
		local_name_2 = seq_2->getName();
		for(int i=0; i<tmp; i++) {local_name_2+=' ';}
	}
	std::cout << "; ALIGN";
	helper::print_space(length_space);
	std::cout << local_name_1 << " " << seq_1->getComment().substr(0,length_comment) << endl;
	std::cout << "; ALIGN";
	helper::print_space(length_space);
	std::cout << local_name_2 << " " << seq_2->getComment().substr(0,length_comment) << endl;
	std::cout << "; ALIGN";
	helper::print_space(length_space);
	std::cout << "Score: " << align_score << endl;
	std::cout << "; ALIGN";
	helper::print_space(length_space);
	float similar;
	float total;
	float sim = 100*identity(sequence_1, sequence_2, total_length, similar, total);
	int pres = 2;
	if (sim >= 100) {pres=3;}
	std::cout << "Identity: " << setprecision(pres) << sim << setprecision(6) << " % ( " << similar << " / " << total << " )" << endl;
	std::cout << "; ALIGN";
	helper::print_space(length_space);
	std::cout << "Begin" << endl;
	std::cout << "; ALIGN" << endl;
	outputAlign(local_name_1, local_name_2, sequence_1, sequence_2, structure, total_length);
	std::cout << "; ALIGN " << endl;
	std::cout << "; ALIGN";
	helper::print_space(length_space);
	std::cout << "End" << endl;
	std::cout <<"; ==============================================================================" << endl;
	if(!arg.boolopt("-summary")) {
		entry_head(seq_1->getName(), seq_1->getFilename(), seq_1->getLength(), align_score, seq_1->getGroupNumber(), align_start_1, (align_start_1+align_len_1), total_length, sequence_1, org_pos_1, org_bp_1, ali_bp_1);
		entry_head(seq_2->getName(), seq_2->getFilename(), seq_2->getLength(), align_score, seq_2->getGroupNumber(), align_start_2, (align_start_2+align_len_2), total_length, sequence_2, org_pos_2, org_bp_2, ali_bp_2);
	}

// Clean up
	delete[] sequence_1;
	delete[] sequence_2;
	delete[] structure;
	delete[] org_pos_1;
	delete[] org_pos_2;
	delete[] org_bp_1;
	delete[] org_bp_2;
	delete[] ali_bp_1;
	delete[] ali_bp_2;
}

inline void output::parameters() {
	std::cout <<"; PARAMETER           max_length=" << arg.intopt("-max_length") << endl;
	std::cout <<"; PARAMETER           max_diff=" << arg.intopt("-max_diff") << endl;
	std::cout <<"; PARAMETER           min_loop=" << arg.intopt("-min_loop") << endl;
	std::cout <<"; PARAMETER           score_matrix=" << arg.stringopt("-score_matrix") << endl;
	std::cout <<"; PARAMETER           nobranching=";
	if (arg.boolopt("-nobranch")) {cout << "<true>" << endl;}
	else {cout << "<false>" << endl;}
	std::cout <<"; PARAMETER           global=";
	if (arg.boolopt("-global")) {cout << "<true>" << endl;}
	else {cout << "<false>" << endl;}
}

inline void output::entry_head(const string name, const string file, const int seq_length, const int score, const int group, const int start, const int end, const int length, char seq[], int org_pos[], int org_bp[], int ali_bp[]) {
// Output an alignment entry
	std::cout <<"; TYPE                RNA" << endl;
	std::cout <<"; COL 1               label" << endl;
	std::cout <<"; COL 2               residue" << endl;
	std::cout <<"; COL 3               seqpos" << endl;
	std::cout <<"; COL 4               alignpos" << endl;
	std::cout <<"; COL 5               align_bp" << endl;
	std::cout <<"; COL 6               seqpos_bp" << endl;
	std::cout <<"; ENTRY               " << name << endl;
	std::cout <<"; ALIGNMENT_ID        " << arg.stringopt("-ID") << endl;
	std::cout <<"; ALIGNMENT_LIST      " << seq_1->getName() << " " << seq_2->getName() << endl;
	std::cout <<"; FOLDALIGN_SCORE     " << score << endl;
	std::cout <<"; GROUP               " << group << endl;
	std::cout <<"; FILENAME            " << file << endl;
	std::cout <<"; START_POSITION      " << start << endl;
	std::cout <<"; END_POSITION        " << end << endl;
	std::cout <<"; ALIGNMENT_SIZE      2" << endl;
	std::cout <<"; ALIGNMENT_LENGTH    " << length << endl;
	std::cout <<"; SEQUENCE_LENGTH     " << seq_length << endl;
	parameters();
	std::cout <<"; ------------------------------------------------------------------------------" << endl;
	int space = 10;
	for (int i=0; i<length; i++) {
		if (seq[i] != '-') {
			std::cout << "N";
			helper::print_space(space-1);
			std::cout << seq[i];
			int size = static_cast<int>(log10(static_cast<double>(org_pos[i])));
			helper::print_space(space-size);
			std::cout << org_pos[i];
			size = static_cast<int>(log10(static_cast<double>(i+1)));
			helper::print_space(space-size-1);
			std::cout << (i+1);
			if (ali_bp[i] !=-1) {
				size = static_cast<int>(log10(static_cast<double>(ali_bp[i]+1)));
				helper::print_space(space-size-1);
				std::cout << (ali_bp[i]+1);
				size = static_cast<int>(log10(static_cast<double>(org_bp[i])));
				helper::print_space(space-size-1);
				std::cout << org_bp[i] << endl;
			}
			else {
				helper::print_space(space-1);
				std::cout << ".";
				helper::print_space(space-1);
				std::cout << "." << endl;
			}
		}
		else {
			std::cout << "G         -          .";
			int size = static_cast<int>(log10(static_cast<double>(i+1)));
			helper::print_space(space-size-1);
			std::cout << (i+1);
			std::cout << "         .         ." << endl;
		}
	}
	std::cout <<"; ******************************************************************************" << endl;
}


inline int output::makeSequences(char*& seq_1, char*& seq_2, char*& struc, 
              int*& org_pos_1, int*& org_bp_1, int*& ali_bp_1, stack<int>*& leftPos_1, stack<int>*& leftBasepair_1, sequence*& sequ_1,
              int*& org_pos_2, int*& org_bp_2, int*& ali_bp_2, stack<int>*& leftPos_2, stack<int>*& leftBasepair_2, sequence*& sequ_2)
{
// Get a sequence and a structure from the backtrack stacks.
// Returns the length of the sequence
	int counter = 0;
	int length = 2*(arg.intopt("-max_length"));
	stack<int> bp_1(length);
	stack<int> bp_2(length);
	while (leftPos_1->getfifosize() > 0) {

		// Get the position
		int pos_1 = leftPos_1->fifo();
		int pos_2 = leftPos_2->fifo();

		// Get the nucleotide value at this position
		int nuc_1 = sequ_1->getPos(pos_1);
		int nuc_2 = sequ_2->getPos(pos_2);

		// Build the sequences
		if (pos_1 > 0) { // Handles nucleotides (not gaps)
			seq_1[counter] = s_matrix.getLetter(nuc_1);
			org_pos_1[counter] = pos_1;
		}
		else { // Handle gaps
			seq_1[counter] = s_matrix.getLetter(0);
			org_pos_1[counter] = 0;
		}

		if (pos_2 > 0) { // Handles nucleotides (not gaps)
			seq_2[counter] = s_matrix.getLetter(nuc_2);
			org_pos_2[counter] = pos_2;
		}
		else { // Handle gaps
			seq_2[counter] = s_matrix.getLetter(0);
			org_pos_2[counter] = 0;
		}

		// Get the base-pairing information
		int basepair_1 = leftBasepair_1->fifo();
		int basepair_2 = leftBasepair_2->fifo();
		
		
		if ((basepair_1 > -1) && (basepair_2 > -1)) {
			if (pos_1 < basepair_1) {
				struc[counter] = open;
				bp_1.push(counter);
				bp_2.push(counter);
			}
			else {
				struc[counter] = close;
				int left_1 = bp_1.pop();
				int left_2 = bp_2.pop();
				ali_bp_1[counter] = left_1;
				ali_bp_2[counter] = left_2;
				ali_bp_1[left_1] = counter;
				ali_bp_2[left_2] = counter;
			}
			org_bp_1[counter] = basepair_1;
			org_bp_2[counter] = basepair_2;
		}
		else if ((basepair_1 > -1) || (basepair_2 > -1)) {
		
			if (basepair_1 > -1) {
				org_bp_1[counter] = basepair_1;
				org_bp_2[counter] = 0;
				ali_bp_2[counter] = -1;
				if (pos_1 < basepair_1) {
					struc[counter] = open_one_seq;
					bp_1.push(counter);
				}
				else {
					struc[counter] = close_one_seq;
					int left_1 = bp_1.pop();
					ali_bp_1[counter] = left_1;
					ali_bp_1[left_1] = counter;
				}
			}
			else {
				org_bp_1[counter] = 0;
				org_bp_2[counter] = basepair_2;
				ali_bp_1[counter] = -1;
				if (pos_2 < basepair_2) {
					struc[counter] = open_one_seq;
					bp_2.push(counter);
				}
				else {
					struc[counter] = close_one_seq;
					int left_2 = bp_2.pop();
					ali_bp_2[counter] = left_2;
					ali_bp_2[left_2] = counter;
				}
			}
		}		
		else {
			struc[counter] = unpaired;
			org_bp_1[counter] = 0;
			org_bp_2[counter] = 0;
			ali_bp_1[counter] = -1;
			ali_bp_2[counter] = -1;
		}
		counter++;
	}
	seq_1[counter] = '\0';
	seq_2[counter] = '\0';
	struc[counter] = '\0';
	return counter;
}

inline float output::identity(char sequence1[], char sequence2[], int len, float& similar, float& total) {
	total = 0; // The total number of nucleotides. Two aligned gaps are not counted
	similar = 0; // The number of similar nucleotides. Gaps do not count as similar
	for(int i=0; i < len; i++) {
		if ((sequence1[i] == '\0') || (sequence2[i] == '\0')) {
			if (sequence1[i] != sequence2[i]) {
				std::cerr << "Program error. The two sequences in the identity function do not have the same length" << std::endl;
				throw -1;
			}
			return similar/total;
		}
		if (sequence1[i] == sequence2[i]) {
			// The nucleotides are similar
			if (sequence1[i] != '-') {
				// They are not gaps
				total++;
				similar++;
			}
		}
		else {
			total++;
		}
	}
	return similar/total;
}

inline void output::outputAlign(std::string name_1, std::string name_2, char sequen_1[], char sequen_2[], char struc[], int length) {
// Output the summary alignment
	int line_length = 40; // Number of characters to be printed pr line
	int num_lines = length/line_length; // Calculate the number of lines (-1). Integer divison intended
	string head = "ALIGN";
	int head_space = 15;
	for(int i=0; i < num_lines; i++) {
		printLine(sequen_1, (i*line_length), ((i+1)*line_length), head, head_space, name_1, 1);
		printLine(struc, (i*line_length), ((i+1)*line_length), head, head_space, "Structure", 5);
		printLine(sequen_2, (i*line_length), ((i+1)*line_length), head, head_space, name_2, 1);
		std::cout << "; " << head << " " << endl;
	}
	if (num_lines*line_length != length) {
		printLine(sequen_1, (num_lines*line_length), length, head, head_space, name_1, 1);
		printLine(struc, (num_lines*line_length), length, head, head_space, "Structure", 5);
		printLine(sequen_2, (num_lines*line_length), length, head, head_space, name_2, 1);
	}
}

inline void output::printLine(char line[], int start, int end, string head, int head_space, string title, int title_space) {
// Output an alignment line
	int length = end - start +1; // The length of the line
	int num_space = length/10; // The number of spaces to be added
	std::cout << "; " << head;
	helper::print_space(head_space);
	std::cout << title;
	helper::print_space(title_space-1);
	int pos = start;
	int stop = start;
	for(int i =0; i<=num_space; i++) {
		pos = stop;
		stop+=10;
		if (stop > end) {stop = end;}
		if (pos < stop) {std::cout << ' ';}
		for(int j=pos; j<stop; j++) {
			std::cout << line[j];
		}
	}
	cout << endl;
}


#endif
