#ifndef MATRIXD
#define MATRIXD
#include "arguments.cxx"
#include <iostream>

/******************************************************************************
*                                                                             *
*   Copyright 2004 - 2005 Jakob Hull Havgaard, hull@bioinf.kvl.dk             *
*                                                                             *
*   This file is part of Foldalign                                            *
*                                                                             *
*   Foldalign is free software; you can redistribute it and/or modify         *
*   it under the terms of the GNU General Public License as published by      *
*   the Free Software Foundation; either version 2 of the License, or         *
*   (at your option) any later version.                                       *
*                                                                             *
*   Foldalign is distributed in the hope that it will be useful,              *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of            *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             *
*   GNU General Public License for more details.                              *
*                                                                             *
*   You should have received a copy of the GNU General Public License         *
*   along with Foldalign; if not, write to the Free Software                  *
*   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA *
*                                                                             *
******************************************************************************/

// Written by Jakob Hull Havgaard, 2004, hull@bioinf.kvl.dk.
template<class type> class matrix_D {
// This class holds the dynamic programming matrix D and its state (used for traceback)
// for the foldalign algorithm. See Havgaard 2004 Bioinformaitcs.
public:

//******************************
// One matrix is used for all the calculations
// It is set up in the constructor
	matrix_D(int end1, arguments& argu, type neg); // Allocate the memory

//******************************
// Read values from either D or its state

	type getD(int i, const int Wi, int k, const int Wk); // Get the value of D
	type getD_us(int i, const int Wi, int k, const int Wk); // Get the value of D

//******************************
// Assigns values to D or its state

	void setD(int i, const int Wi, int k, const int Wk,const type value); // assign value to D

//******************************
// Slides the matrix along one of the sequences

	void shiftI(const int i);
	void shiftI_init(const int i);

//******************************
// Returns the current i or k positions

	int getI() const {return current_i;};
	int getK() const {return startK;};
	int getEndI() const {return endI;};
	int getEndK() const {return endK;};

//******************************
// Set the length of the sequences

	void setEndI(const int i) {current_i = endI= i;};
	void setEndK(const int k) {endK = k;};
	void setStartK(const int k) {startK =  k;};
	
//******************************
// Sets all values of the matrix to zero

	void init();

//******************************
// Just and ordinary destructor

	~matrix_D();

private:
	arguments& arg; // Holds the arguments and options to the program
	type**** D; // This is the dynamic programming matrix
	int delta; // The maximum difference between windowsizes
	int lambda;// The maximum alignment length
	int current_i;   // Position in i sequence
	int i_size;      // Size of the lambda matrix. Default value lambda
	int* k_size;     // Size of the delta matrix (a function of lambda)
	int* k_zero;     // Position of delta=0 in the delta-matrix. Depends on Wi
	const int big_neg; // A large negative number. Used as illegal score
	int endK;  // The end of the k sequence
	int endI;  // The end of the i sequence
	int startK; // Start of the k sequence
	int deltaSize; // the 1-dimension of the delta matrix. k_size holdes the other dimension
};

template<class type> inline matrix_D<type>::matrix_D(int end1, arguments& argu, type neg) : arg(argu), big_neg(neg) { // Allocate the memory
	lambda = arg.intopt("-max_length");
	delta = arg.intopt("-max_diff");
	deltaSize = 2*arg.intopt("-chunk_size")+1;
	endI = current_i = end1;
	i_size = lambda;
#ifdef DEBUG_MATRIX
	std::cerr << "Warning matrix_D has been compiled with option -DDEBUG_MATRIX. This will slow down the branch point calculation a lot" << std::endl;
#endif /* DEBUG_MATRIX */
	try {
		k_size = new int[lambda];
		k_zero = new int[lambda];
		D = new type***[i_size]; // allocate the first dimension of the lambda matirx
		for(int i=0; i < i_size; i++) { 
			D[i] = new type**[lambda]; // allocate the second dimension of lambda
			for(int Wi=0; Wi < lambda-i; Wi++) {
				k_zero[Wi] = delta; // Default position of delta=0 in the second dimension of the delta matrix.
				k_size[Wi] = 2*delta +1; // Default size of the second dimension of the delta matrix
				if (Wi < (delta)) { k_zero[Wi] += Wi- delta; k_size[Wi] -= (delta  - Wi);} // If Wi is small the number of postive windowsizes smalller than Wi is less than delta
				if ((lambda - Wi) < (delta )) { k_size[Wi] += lambda - Wi - delta;} // If Wi is large the number of windowsizes larger than Wi but smaller than lambda is less than delta
				D[i][Wi] = new type*[deltaSize]; // Allocate the first dimension of the delta-matrix
				for(int k=0; k < deltaSize ; k++) { // allocate l
					D[i][Wi][k] = new type[k_size[Wi]]; // allocate the second dimension of delta
				}
			}
		}
	}
	catch (...) {
// I wish this worked on all machines when the machine runs out of memory but it only works on some machines
		std::cerr << "Could not allocate memory. Most likely cause: Out of memory" << std::endl;
		throw;
	}
}

template<class type> inline void matrix_D<type>::init() {
// Sets all values in the matrix to zero
	for(int i=0; i < i_size; i++) { 
		for(int Wi=0; Wi < lambda-i; Wi++) {
			for(int k=0; k < deltaSize ; k++) {
				for(int Wk=0; Wk < k_size[Wi]; Wk++) {
					D[i][Wi][k][Wk] = 0;
				}
			}
		}
	}
}

template<class type> inline void matrix_D<type>::shiftI_init(const int i) { //Move along the i sequence
// Shift the matrix and set the new parts to zero
	shiftI(i);
	int ii = 0;
	for(int Wi=0; Wi < lambda; Wi++) {
		for(int k=0; k < deltaSize ; k++) {
			for(int Wk=0; Wk < k_size[Wi]; Wk++) {
				D[ii][Wi][k][Wk] = 0;
			}
		}
	}
}

template<class type> inline void matrix_D<type>::shiftI(const int i) { //Move along the i sequence
	current_i = i-1;
	if ((current_i+lambda) <= endI) {endI--;}
	type*** tmp = D[i_size-1];
	for(int m=i_size-1; m>0; m--) {
		tmp[lambda - m] = D[m-1][lambda-m];
		D[m-1][lambda-m] = 0;
		D[m] = D[m-1];
	}
	D[0]=tmp;
}

template<class type> inline type matrix_D<type>::getD(int i, const int Wi, int k, const int Wk) { // Get the value of D
	int Wd = k_zero[Wi]+(Wk - Wi);
	if ((Wk - Wi) > delta) {return big_neg;} // Handels underflow due to the delta limit. Could also be handled by 2 extra memory cells at the bottem of the matrix
	if ((Wi - Wk) > delta) {return big_neg;} // Handels underflow due to the delta limit. Could also be handled by 2 extra memory cells at the bottem of the matrix
	i -= current_i ;
	k-=startK;
	return D[i][Wi][k][Wd];
}


template<class type> inline type matrix_D<type>::getD_us(int i, const int Wi, int k, const int Wk) { // Get the value of D
	int Wd = k_zero[Wi]+(Wk - Wi);
#ifdef DEBUG_MATRIX
	if ((Wk - Wi) > delta) {std::cerr << "Window size difference larger than delta found in getD_us" << std::endl; return big_neg;} // Handels underflow due to the delta limit. Could also be handled by 2 extra memory cells at the bottem of the matrix
	if ((Wi - Wk) > delta) {std::cerr << "Window size difference larger than delta found in getD_us" << std::endl; return big_neg;} // Handels underflow due to the delta limit. Could also be handled by 2 extra memory cells at the bottem of the matrix
#endif /* DEBUG_MATRIX */
	i -= current_i ;
	k-=startK;
	return D[i][Wi][k][Wd];
}

template<class type> inline void matrix_D<type>::setD(int i, const int Wi, int k, int Wk, const type value) { // assign value to D
	i=0; // Speed up. It is not needed for FOLDALIGN to be able to write in a i!=0 cell
//	i -= current_i;
	k -= startK;
	int Wd = k_zero[Wi] +(Wk - Wi);
	D[i][Wi][k][Wd] = value;
}

template<class type> inline matrix_D<type>::~matrix_D() {
	try {
		for(int i=0; i < i_size; i++) { // allocate j
			for(int Wi=0; Wi < lambda-i; Wi++) { // allocate k
				for(int k=0; k <deltaSize; k++) { // allocate l
					delete[] D[i][Wi][k];
				}
				delete[] D[i][Wi];
			}
			delete[] D[i];
		}
		delete[] D;
		delete[] k_size;
		delete[] k_zero;
	}
	catch (...) {
// For some reason this does not work
		std::cerr << "Program error destructing matrix_D object" << std::endl;
		throw;
	}
}
#endif /*MATRIXD*/
