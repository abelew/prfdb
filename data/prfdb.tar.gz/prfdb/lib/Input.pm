package Randomize;
use strict;

sub new {
  my ( $class, %arg ) = @_;
  my $me = bless {}, $class;
  return ($me);
}

sub Coin_Random {
  my $me       = shift;
  my $sequence = shift;

}

1;
